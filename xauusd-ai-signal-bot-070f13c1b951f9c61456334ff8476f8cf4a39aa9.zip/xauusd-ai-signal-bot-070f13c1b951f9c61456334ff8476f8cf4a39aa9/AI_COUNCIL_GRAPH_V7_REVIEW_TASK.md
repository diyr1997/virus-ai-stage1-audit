# AI Council Task — Graph Scenario V7 Review

## User intent
Improve the Telegram XAU/USD charts as a group decision before production code changes. The chart must become more informative, more honest about uncertainty, and more useful for understanding entry/continuation/reversal scenarios. This remains DEMO-only and the chart must never become independent evidence for opening a trade.

## Current implementation to review
Current Graph V6 uses `forecast-v6-engine.js` plus `graph-v6-bootstrap.js` to replace the legacy `buildTradePlan(...)` implementation at runtime. V6 currently produces one smooth central scenario path with an uncertainty corridor, 5/10/15 minute milestones, entry/confirmation/invalidation/SL/TP1/TP2/TP3, and renders it into the existing Telegram SVG chart.

Known characteristics of V6 that require critical review:
- Forecast shape contains predetermined pullback/continuation bumps via fixed Gaussian centers and widths.
- One central directional path can visually look more certain than the evidence actually supports.
- Strength is direction strength, not calibrated win probability.
- MTF disagreement is not clearly represented inside the chart scenario itself.
- `scenarioMarkers` is currently empty.
- Forecast horizon is 15 minutes for most TFs and 60 minutes for H1; evaluate whether horizons should instead be TF-aware.
- Rendering is injected through a runtime bootstrap patch of `index.js`; evaluate maintainability and whether Graph V7 should become an explicit module/API instead of another text patch.

## Required council workflow
Every available advisor must first review independently using the same frozen project context and the supplied graph source files. Then every successful advisor must peer-review the other responses. Do not decide by majority vote; prefer measurable evidence, honest uncertainty, maintainability, and DEMO safety.

## Design goals to evaluate
1. Preserve realistic historical candles from real closed market data. Never invent the left/history side.
2. Keep M1/M5/M15/M30/H1 separate; do not convert one TF into another.
3. Use fresh MT5 BID/ASK when available and visibly mark quote freshness/spread state.
4. Distinguish analysis price, executable entry side, confirmation, cancellation/invalidation, SL, TP1, TP2, TP3.
5. Make the forecast section probabilistically honest. Do not show a single decorative path as if it were a predicted future.
6. Evaluate a multi-scenario representation such as:
   - PRIMARY continuation scenario;
   - ALTERNATIVE pullback/reversal scenario;
   - NO-TRADE/uncertain state when evidence conflicts.
7. Do not attach numerical probabilities unless they are calibrated out-of-sample. If calibration is absent, use qualitative confidence/uncertainty labels.
8. Show MTF agreement/disagreement compactly, including M1/M5/M15/M30/H1 direction and strength.
9. Consider regime/session/spread/news context only if it measurably improves OOS forecast quality; do not clutter the visual for weak signals.
10. Forecast horizon must be TF-aware and measurable. Compare fixed 5/10/15 minute milestones versus horizons aligned to the selected timeframe.
11. Show why the current scenario exists: trend/momentum/volatility/MTF/news/market-state contributions, but keep the chart readable on a phone.
12. Add meaningful scenario markers for pullback zone, continuation trigger, reversal trigger, invalidation, or uncertainty expansion only when backed by defined rules.
13. The graph must explicitly say that strength/confidence is not guaranteed win probability.
14. Rendering must remain fast enough for Telegram and must not create duplicate messages or block the bot loop.
15. Preserve closed-candle-only policy and freshness guards.

## Forecast engine questions
- Should Graph V7 continue using a hand-shaped deterministic curve, or switch to data-driven scenario envelopes / historical analogs / model quantiles / regime-conditioned paths?
- If data-driven, which approach is simplest and most robust with existing project data?
- How should uncertainty widen over time and react to realized volatility/spread?
- How should MTF disagreement affect the central scenario and corridor width?
- How should WAIT be visualized so it does not look like a weak BUY/SELL prediction?
- How should reversal risk be represented without encouraging close-and-flip before Reversal V4 is validated?
- Should the forecast engine output quantiles (for example lower/median/upper) instead of a decorative center line?
- Which metrics should be used to score forecast quality: coverage of actual price by forecast bands, MAE, directional accuracy, calibration, interval width, reversal false-positive rate, or others?

## Rendering / Telegram questions
Review the current SVG layout and propose a phone-first layout. Decide what belongs directly on the image versus the accompanying Telegram text.

At minimum consider:
- clear current/analysis price;
- candle history;
- forecast boundary between history and future;
- entry/confirmation/invalidation/SL/TP levels;
- spread/freshness badge;
- selected TF;
- MTF compact strip;
- primary vs alternative scenario labeling;
- uncertainty zone;
- 5/10/15 or TF-aware milestone zones;
- reason/driver summary;
- candidate state such as WAIT_CONFIRMATION / CONFIRMED / ACTIVE / CANCELLED where relevant.

Avoid excessive labels that overlap candles or make the chart unreadable on a phone.

## Architecture review
Evaluate whether to keep `graph-v6-bootstrap.js` runtime source patching or migrate Graph V7 to explicit imports/interfaces. Identify exact files to change and files that should remain untouched. Minimize risk to `index.js` and Telegram polling.

## Mandatory validation before rollout
The council must specify deterministic tests and OOS/shadow tests including at least:
1. BUY, SELL and WAIT render without invalid values.
2. All five TFs render correctly.
3. Historical candle section is unchanged real data.
4. Fresh/stale MT5 quote state is represented correctly.
5. Forecast bands always satisfy lower < center/median < upper when applicable.
6. No NaN/Infinity or impossible price levels.
7. Forecast intervals are evaluated against later realized candles on chronological OOS data.
8. Compare V7 against V6 using MAE, interval coverage/width, directional error and false reversal rate.
9. MTF disagreement increases uncertainty or degrades confidence according to explicit rules, not visual intuition.
10. WAIT does not masquerade as a directional prediction.
11. Rendering stays within acceptable Telegram image-generation latency.
12. No duplicate Telegram sends are introduced.
13. Graph changes do not modify DEMO order execution decisions.
14. Image regression/snapshot checks verify labels and levels do not overlap catastrophically.

## Promotion rule
Graph V7 is promoted only if it is more truthful/usable and either improves measured forecast diagnostics or clearly improves presentation without worsening predictive calibration. A more attractive image alone is not enough to claim a better forecast.

## Output format
Return:
- assessment_of_v6
- recommended_v7_design
- forecast_engine_design
- uncertainty_representation
- mtf_representation
- telegram_layout
- exact_files_to_change
- files_to_leave_untouched
- validation_metrics
- deterministic_tests
- oos_shadow_tests
- rollout_plan
- rollback_plan
- rejected_or_doubtful_ideas
- disagreements_and_unknowns
- confidence

Do not modify production graph/trading code automatically. Produce the joint design/review first; implementation follows only after reconciliation and tests.
