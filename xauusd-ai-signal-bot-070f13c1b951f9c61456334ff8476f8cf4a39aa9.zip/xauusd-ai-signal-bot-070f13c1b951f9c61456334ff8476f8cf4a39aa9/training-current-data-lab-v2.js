"use strict";

console.log("🧪 CURRENT DATA LAB V2 MODULE_LOADED");

const fs = require("fs");
const os = require("os");
const path = require("path");
const { promisify } = require("util");
const { execFile } = require("child_process");
const { Pool } = require("pg");
const {
  classifyTrainingTier,
  auditCandles,
  dataFingerprint,
  shouldRunNewDataExperiment,
} = require("./training-data-policy");

const execFileAsync = promisify(execFile);
const TZ = process.env.CURRENT_DATA_LAB_TIMEZONE || "Asia/Tashkent";
const DATABASE_URL = String(process.env.DATABASE_URL || process.env.DATABASE_PUBLIC_URL || "").trim();
const BOT_TOKEN = String(process.env.TELEGRAM_BOT_TOKEN || "").trim();
const PYTHON = process.env.PYTHON_BIN || path.join(__dirname, ".venv", "bin", "python");
const EXPLORATORY_TRAINER = path.join(__dirname, "exploratory_train_h1.py");
const CHALLENGER_TRAINER = path.join(__dirname, "weekend_train_h1.py");
const BUILTIN_MODEL = path.join(__dirname, "xauusd_ai_final_h1_full_period.joblib");
const ACTIVE_MODEL_TMP = path.join(os.tmpdir(), "xauusd_ai_h1_active.joblib");
const ENABLED = !/^(0|false|no|disabled)$/i.test(String(process.env.CURRENT_DATA_LAB_ENABLED || "1"));
const RUN_NOW = String(process.env.CURRENT_DATA_LAB_RUN_NOW || "").trim();
const CHECK_MS = Math.max(30_000, Number(process.env.CURRENT_DATA_LAB_CHECK_MS || 60_000));
const START_HOUR = Math.max(3, Math.min(10, Number(process.env.CURRENT_DATA_LAB_START_HOUR || 5)));
const SLOT_HOURS = Math.max(2, Math.min(6, Number(process.env.CURRENT_DATA_LAB_SLOT_HOURS || 4)));
const LAST_HEAVY_HOUR = Math.max(18, Math.min(22, Number(process.env.CURRENT_DATA_LAB_LAST_HOUR || 20)));
const NEW_DATA_STEP = Math.max(250, Number(process.env.CURRENT_DATA_LAB_NEW_DATA_STEP || 1000));
const NEW_DATA_COOLDOWN_MS = Math.max(60 * 60_000, Number(process.env.CURRENT_DATA_LAB_NEW_DATA_COOLDOWN_MS || 6 * 60 * 60_000));
const PROMOTION_MIN_ROWS = Math.max(8000, Number(process.env.CURRENT_DATA_LAB_PROMOTION_MIN_ROWS || 15000));
const PROMOTION_MIN_DAYS = Math.max(5, Number(process.env.CURRENT_DATA_LAB_PROMOTION_MIN_DAYS || 10));
const MAX_ROWS_IN_MEMORY = Math.max(50_000, Number(process.env.CURRENT_DATA_LAB_MAX_ROWS_IN_MEMORY || 500_000));
const TRAIN_LOCK_ID = 82622026;
const SCHEMA_TIMEOUT_MS = 30_000;
const STALE_RUN_MS = 30 * 60_000;

const pool = DATABASE_URL ? new Pool({ connectionString: DATABASE_URL, max: 3, idleTimeoutMillis: 30_000 }) : null;
let running = false;
let lastSchedulerDecisionKey = null;

function localParts(now = new Date()) {
  const fmt = new Intl.DateTimeFormat("en-CA", {
    timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit", weekday: "short",
    hour: "2-digit", minute: "2-digit", hourCycle: "h23",
  });
  const parts = Object.fromEntries(fmt.formatToParts(now).filter((p) => p.type !== "literal").map((p) => [p.type, p.value]));
  return { date: `${parts.year}-${parts.month}-${parts.day}`, weekday: parts.weekday, hour: Number(parts.hour), minute: Number(parts.minute) };
}

function weekendSlot(local) {
  if (!["Sat", "Sun"].includes(local.weekday)) return null;
  const dayStart = local.weekday === "Sat" ? START_HOUR : 0;
  if (local.hour < dayStart || local.hour > LAST_HEAVY_HOUR) return null;
  const slotIndex = Math.floor((local.hour - dayStart) / SLOT_HOURS);
  const slotHour = dayStart + slotIndex * SLOT_HOURS;
  if (slotHour > LAST_HEAVY_HOUR) return null;
  const saturdaySlots = Math.floor((LAST_HEAVY_HOUR - START_HOUR) / SLOT_HOURS) + 1;
  const sundaySlots = Math.floor(LAST_HEAVY_HOUR / SLOT_HOURS) + 1;
  const trial = local.weekday === "Sat" ? slotIndex : saturdaySlots + slotIndex;
  const final = local.weekday === "Sun" && slotIndex === sundaySlots - 1;
  return { slotIndex, slotHour, trial, final };
}

function withTimeout(promise, ms, label) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      const error = new Error(`${label}_TIMEOUT_${ms}ms`);
      error.code = `${label}_TIMEOUT`;
      reject(error);
    }, ms);

    Promise.resolve(promise).then(
      (value) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve(value);
      },
      (error) => {
        if (settled) {
          console.error(`❌ CURRENT DATA LAB V2 ${label} LATE_REJECTION: ${error?.message || error}`);
          return;
        }
        settled = true;
        clearTimeout(timer);
        reject(error);
      }
    );
  });
}

async function ensureSchema() {
  await pool.query(`CREATE TABLE IF NOT EXISTS training_current_data_runs (
    run_key TEXT PRIMARY KEY, kind TEXT NOT NULL, status TEXT NOT NULL, tier TEXT,
    source_rows INTEGER, trading_days INTEGER, data_hash TEXT,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), finished_at TIMESTAMPTZ,
    metrics JSONB NOT NULL DEFAULT '{}'::jsonb, report JSONB NOT NULL DEFAULT '{}'::jsonb, error TEXT)`);
  await pool.query(`CREATE TABLE IF NOT EXISTS model_registry (
    id BIGSERIAL PRIMARY KEY, model_key VARCHAR(40) NOT NULL, version VARCHAR(120) NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), active BOOLEAN NOT NULL DEFAULT FALSE,
    source VARCHAR(40) NOT NULL DEFAULT 'AUTO_TRAINING', metrics JSONB NOT NULL DEFAULT '{}'::jsonb,
    model_bytes BYTEA NOT NULL, payload JSONB NOT NULL DEFAULT '{}'::jsonb)`);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_model_registry_active ON model_registry(model_key,active,created_at DESC)`);
}

async function reapStaleRuns(nowMs = Date.now()) {
  const cutoff = new Date(nowMs - STALE_RUN_MS);
  const result = await pool.query(
    `UPDATE training_current_data_runs
     SET status='STALE', finished_at=NOW(), error=COALESCE(error,'stale_running_reaped_after_30m')
     WHERE status='RUNNING' AND started_at < $1
     RETURNING run_key`,
    [cutoff]
  );
  console.log(`🧪 CURRENT DATA LAB V2: Reaped ${result.rowCount} stale RUNNING rows`);
  return result.rowCount;
}

async function tryTrainingLock() {
  const client = await pool.connect();
  try {
    const result = await client.query("SELECT pg_try_advisory_lock($1) AS locked", [TRAIN_LOCK_ID]);
    if (!result.rows[0]?.locked) {
      client.release();
      return null;
    }
    return client;
  } catch (error) {
    client.release();
    throw error;
  }
}

async function releaseTrainingLock(client) {
  if (!client) return;
  try { await client.query("SELECT pg_advisory_unlock($1)", [TRAIN_LOCK_ID]); } finally { client.release(); }
}

async function claimRun(runKey, kind) {
  // DO NOTHING alone meant a slot whose run died mid-flight was lost for good:
  // reapStaleRuns marks the row STALE, but the row still exists, so the insert
  // kept conflicting and the scheduler re-decided START and immediately skipped
  // on every tick, forever. Only a STALE row is retaken - SUCCESS is finished
  // work and FAILED is a real failure, and re-running either on a timer is how
  // you get an unbounded retry loop.
  const result = await pool.query(
    `INSERT INTO training_current_data_runs(run_key,kind,status) VALUES($1,$2,'RUNNING')
     ON CONFLICT(run_key) DO UPDATE
       SET status='RUNNING', kind=EXCLUDED.kind, started_at=NOW(),
           finished_at=NULL, error=NULL
       WHERE training_current_data_runs.status='STALE'
     RETURNING run_key`, [runKey, kind]
  );
  return result.rowCount === 1;
}

// A run is reclaimable only once its own row says the previous attempt died.
function claimableStatus(status) {
  return String(status || "").toUpperCase() === "STALE";
}

async function finishRun(runKey, status, fields = {}) {
  await pool.query(
    `UPDATE training_current_data_runs SET status=$2,tier=$3,source_rows=$4,trading_days=$5,data_hash=$6,
      finished_at=NOW(),metrics=$7::jsonb,report=$8::jsonb,error=$9 WHERE run_key=$1`,
    [runKey,status,fields.tier||null,fields.sourceRows??null,fields.tradingDays??null,fields.dataHash||null,
     JSON.stringify(fields.metrics||{}),JSON.stringify(fields.report||{}),fields.error||null]
  );
}

async function currentM1Count() {
  const result = await pool.query(`SELECT COUNT(*)::int AS rows FROM xauusd_candles WHERE timeframe='M1'`);
  return Number(result.rows[0]?.rows || 0);
}

function assertMemorySafety(rowCount, maxRows = MAX_ROWS_IN_MEMORY) {
  if (rowCount > maxRows) {
    const error = new Error(`CURRENT_DATA_MEMORY_GUARD rows=${rowCount} max=${maxRows}; chunked trainer required before proceeding`);
    error.code = "CURRENT_DATA_MEMORY_GUARD";
    throw error;
  }
  return true;
}

async function exportAllCandles(expectedCount) {
  assertMemorySafety(expectedCount);
  const result = await pool.query(`SELECT (EXTRACT(EPOCH FROM candle_time)*1000)::bigint AS timestamp,
    open::float8,high::float8,low::float8,close::float8,volume::float8
    FROM xauusd_candles WHERE timeframe='M1' ORDER BY candle_time ASC`);
  if (result.rowCount !== expectedCount) {
    const error = new Error(`CURRENT_DATA_COUNT_MISMATCH expected=${expectedCount} exported=${result.rowCount}`);
    error.code = "CURRENT_DATA_COUNT_MISMATCH";
    throw error;
  }
  return result.rows.map((row) => ({ ...row, timestamp: Number(row.timestamp) }));
}

async function materializeChampion() {
  const result = await pool.query(`SELECT version,model_bytes FROM model_registry
    WHERE model_key='H1' AND active=TRUE ORDER BY created_at DESC LIMIT 1`);
  if (result.rows[0]?.model_bytes) {
    fs.writeFileSync(ACTIVE_MODEL_TMP, result.rows[0].model_bytes);
    return { path: ACTIVE_MODEL_TMP, version: result.rows[0].version, source: "registry" };
  }
  return { path: BUILTIN_MODEL, version: "builtin", source: "repository" };
}

async function promoteModel(training, candidatePath, dataHash, tier, audit) {
  if (!training?.accepted || !training?.promotion_eligible || !tier?.canPromote) return false;
  if (audit.rows < PROMOTION_MIN_ROWS || audit.tradingDays < PROMOTION_MIN_DAYS) return false;
  const bytes = fs.readFileSync(candidatePath);
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const current = await client.query(`SELECT version FROM model_registry
      WHERE model_key='H1' AND active=TRUE ORDER BY created_at DESC LIMIT 1 FOR UPDATE`);
    const activeVersion = current.rows[0]?.version || "builtin";
    if (String(activeVersion) !== String(training.champion_version || "builtin")) {
      throw new Error(`CHAMPION_CHANGED_DURING_TRAINING active=${activeVersion} trained_against=${training.champion_version}`);
    }
    await client.query(`UPDATE model_registry SET active=FALSE WHERE model_key='H1' AND active=TRUE`);
    await client.query(`INSERT INTO model_registry(model_key,version,active,source,metrics,model_bytes,payload)
      VALUES('H1',$1,TRUE,'CURRENT_DATA_LAB',$2::jsonb,$3,$4::jsonb)`,
      [training.version,JSON.stringify(training),bytes,JSON.stringify({promoted_at:new Date().toISOString(),data_hash:dataHash,source_rows:audit.rows,trading_days:audit.tradingDays})]);
    await client.query("COMMIT");
    fs.writeFileSync(ACTIVE_MODEL_TMP, bytes);
    return true;
  } catch (error) {
    await client.query("ROLLBACK").catch(() => {});
    throw error;
  } finally { client.release(); }
}

function parseLastJsonLine(stdout) {
  const line = String(stdout || "").trim().split(/\r?\n/).filter(Boolean).pop();
  return JSON.parse(line || "{}");
}

async function runTraining(candles, tier, trial, audit, dataHash) {
  const champion = await materializeChampion();
  const stamp = Date.now();
  const candlesPath = path.join(os.tmpdir(), `current_data_candles_${stamp}.json`);
  const candidatePath = path.join(os.tmpdir(), `current_data_candidate_${stamp}.joblib`);
  fs.writeFileSync(candlesPath, JSON.stringify(candles), "utf8");
  try {
    if (!tier.canTrain) return {ok:true,experiment_tier:tier.tier,promotion_eligible:false,promoted:false,source_rows:audit.rows,trading_days:audit.tradingDays,reason:tier.reason};
    if (!tier.canPromote) {
      const {stdout,stderr} = await execFileAsync(PYTHON,[EXPLORATORY_TRAINER,"--champion",champion.path,"--candles",candlesPath,"--trial",String(trial)],
        {timeout:15*60_000,maxBuffer:4*1024*1024});
      if (stderr?.trim()) console.log("🧪 CURRENT DATA exploratory stderr:",stderr.trim().slice(0,1200));
      const training = parseLastJsonLine(stdout);
      if (!training.ok) throw new Error(training.error || "exploratory training failed");
      Object.assign(training,{experiment_tier:tier.tier,promotion_eligible:false,promoted:false,promotion_block_reason:tier.reason,data_hash:dataHash,champion_source:champion.source});
      return training;
    }
    const {stdout,stderr} = await execFileAsync(PYTHON,[CHALLENGER_TRAINER,"--champion",champion.path,"--candles",candlesPath,
      "--output",candidatePath,"--mode","weekend","--trial",String(trial)],{timeout:30*60_000,maxBuffer:4*1024*1024});
    if (stderr?.trim()) console.log("🧠 CURRENT DATA challenger stderr:",stderr.trim().slice(0,1200));
    const training = parseLastJsonLine(stdout);
    if (!training.ok) throw new Error(training.error || "challenger training failed");
    Object.assign(training,{experiment_tier:tier.tier,promotion_eligible:true,data_hash:dataHash,champion_source:champion.source});
    training.promoted = await promoteModel(training,candidatePath,dataHash,tier,audit);
    return training;
  } finally { fs.unlink(candlesPath,()=>{}); fs.unlink(candidatePath,()=>{}); }
}

async function ownerChatId() {
  const env = Number(process.env.TELEGRAM_OWNER_CHAT_ID || 0); if (env) return env;
  const result = await pool.query(`SELECT value FROM bot_settings WHERE key='owner_chat_id' LIMIT 1`);
  return Number(result.rows[0]?.value || 0);
}
async function notify(text) {
  const chatId = await ownerChatId().catch(()=>0); if (!BOT_TOKEN || !chatId) return;
  await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({chat_id:chatId,text:String(text).slice(0,3900)})}).catch(()=>{});
}

async function lastSuccessfulRun() {
  const result = await pool.query(`SELECT source_rows,finished_at FROM training_current_data_runs
    WHERE status='SUCCESS' AND source_rows IS NOT NULL ORDER BY finished_at DESC NULLS LAST LIMIT 1`);
  return { rows:Number(result.rows[0]?.source_rows||0), finishedAt:result.rows[0]?.finished_at ? new Date(result.rows[0].finished_at).getTime() : 0 };
}
function newDataCooldownPassed(lastFinishedAt, now=Date.now()) {
  return !lastFinishedAt || now-lastFinishedAt >= NEW_DATA_COOLDOWN_MS;
}

async function executeRun(kind, runKey, options={}) {
  const lockClient = await tryTrainingLock();
  if (!lockClient) { console.log(`🧪 CURRENT DATA LAB SKIP LOCKED | ${runKey}`); return false; }
  try {
    if (!(await claimRun(runKey,kind))) { console.log(`🧪 CURRENT DATA LAB V2 Scheduler decision: SKIP_ALREADY_CLAIMED run=${runKey}`); return false; }
    console.log(`🧪 CURRENT DATA LAB START | ${runKey}`);
    try {
      const expectedCount = await currentM1Count();
      assertMemorySafety(expectedCount);
      const candles = await exportAllCandles(expectedCount);
      const audit = auditCandles(candles);
      if (audit.rows !== expectedCount) throw new Error(`CURRENT_DATA_AUDIT_COUNT_MISMATCH expected=${expectedCount} audit=${audit.rows}`);
      const tier = classifyTrainingTier({rows:audit.rows,tradingDays:audit.tradingDays},{promotionMinRows:PROMOTION_MIN_ROWS,promotionMinTradingDays:PROMOTION_MIN_DAYS});
      const fingerprint = dataFingerprint(candles);
      if (!audit.qualityPass) {
        await finishRun(runKey,"FAILED",{tier:tier.tier,sourceRows:audit.rows,tradingDays:audit.tradingDays,dataHash:fingerprint,metrics:{audit},error:`data_quality_failed_duplicates=${audit.duplicates}_invalid=${audit.invalid}`});
        return false;
      }
      const training = await runTraining(candles,tier,Number(options.trial||0),audit,fingerprint);
      const report={audit,training,owner_policy:"use every verified current M1 row when dataset fits safe in-memory envelope; never silently subset",memory_policy:`fail closed above ${MAX_ROWS_IN_MEMORY} rows until chunked trainer is available`,promotion_gate:`>=${PROMOTION_MIN_ROWS} rows and >=${PROMOTION_MIN_DAYS} trading days plus existing OOS acceptance`};
      await finishRun(runKey,"SUCCESS",{tier:tier.tier,sourceRows:audit.rows,tradingDays:audit.tradingDays,dataHash:fingerprint,
        metrics:{direction_accuracy_gain:training.direction_accuracy_gain??null,challenger_metrics:training.challenger_metrics||{},champion_metrics:training.champion_metrics||{}},report});
      console.log(`🧪 CURRENT DATA LAB DONE | ${runKey} | tier=${tier.tier} | rows=${audit.rows} | days=${audit.tradingDays} | promoted=${Boolean(training.promoted)}`);
      if (kind==="DAILY"||options.final||training.promoted||options.notifyExploratory) await notify(`🧪 ОБУЧЕНИЕ НА ТЕКУЩИХ ДАННЫХ\nM1: ${audit.rows} • дней: ${audit.tradingDays}\nРежим: ${tier.tier}\nЭксперимент: ${training?.profile?.name||"data audit"}\n${training.promoted?`✅ Champion заменён: ${training.version}`:"🛡 Champion не менялся"}\nВсе доступные данные этого запуска использованы; результат сохранён.`);
      return true;
    } catch(error) {
      await finishRun(runKey,"FAILED",{error:String(error?.message||error)}).catch(()=>{});
      console.error(`❌ CURRENT DATA LAB | ${runKey}:`,error);
      if (options.final||kind==="DAILY") await notify(`❌ CURRENT DATA LAB FAILED\n${String(error?.message||error).slice(0,1200)}\nChampion не менялся.`);
      return false;
    }
  } finally { await releaseTrainingLock(lockClient); }
}

function logSchedulerDecision(local, action, reason, runKey = null) {
  const key = `${local.date}:${local.hour}:${action}:${reason}:${runKey||"none"}`;
  if (key === lastSchedulerDecisionKey) return;
  lastSchedulerDecisionKey = key;
  console.log(`🧪 CURRENT DATA LAB V2 Scheduler decision: ${action} reason=${reason}${runKey?` run=${runKey}`:""}`);
}

async function schedulerTick() {
  if (!ENABLED||!pool||running) return;
  // Reaping only at start() meant a run that died was never released while the
  // process stayed up, which on a long-lived deploy is always.
  await reapStaleRuns().catch((error) =>
    console.warn(`CURRENT DATA LAB V2 reap: ${String(error?.message || error).slice(0, 300)}`)
  );
  const local=localParts(); let kind=null,runKey=null,options={};
  if (RUN_NOW) {
    kind="MANUAL";
    runKey=`MANUAL:${RUN_NOW}`;
    options={trial:0,final:true,notifyExploratory:true};
  } else if (["Mon","Tue","Wed","Thu","Fri"].includes(local.weekday)&&local.hour===2&&local.minute>=5) { kind="DAILY"; runKey=`${local.date}:CURRENT_DATA_DAILY`; }
  else {
    const slot=weekendSlot(local);
    if (slot) { kind=local.weekday==="Sat"?"WEEKEND_SAT":"WEEKEND_SUN"; runKey=`${local.date}:CURRENT_DATA:${kind}:H${String(slot.slotHour).padStart(2,"0")}`; options={trial:slot.trial,final:slot.final,notifyExploratory:local.weekday==="Sat"&&slot.slotIndex===0}; }
  }
  if (!kind&&["Sat","Sun"].includes(local.weekday)) {
    const [currentRows,last]=await Promise.all([currentM1Count(),lastSuccessfulRun()]);
    if (newDataCooldownPassed(last.finishedAt)&&shouldRunNewDataExperiment({currentRows,lastRows:last.rows,step:NEW_DATA_STEP})) {
      const bucket=Math.floor(currentRows/NEW_DATA_STEP); kind="NEW_DATA"; runKey=`${local.date}:CURRENT_DATA:NEW:${bucket}`; options={trial:bucket,notifyExploratory:false};
    }
  }
  if (!kind) { logSchedulerDecision(local,"SKIP","no_due_slot_or_new_data"); return; }
  logSchedulerDecision(local,"START",kind,runKey);
  running=true; try { await executeRun(kind,runKey,options); } finally { running=false; }
}

async function start() {
  console.log(`🧪 CURRENT DATA LAB V2 start() called enabled=${ENABLED} db=${Boolean(pool)}`);
  if (!ENABLED) { console.log("🧪 CURRENT DATA LAB V2: disabled"); return; }
  if (!pool) { console.warn("⚠️ CURRENT DATA LAB V2: PostgreSQL unavailable"); return; }
  console.log("🧪 CURRENT DATA LAB V2 ensureSchema START");
  try {
    await withTimeout(ensureSchema(),SCHEMA_TIMEOUT_MS,"CURRENT_DATA_SCHEMA");
    console.log("🧪 CURRENT DATA LAB V2 ensureSchema DONE");
  } catch(error) {
    console.error(`❌ CURRENT DATA LAB V2 ensureSchema FAILED: ${error.message}`);
    throw error;
  }
  await reapStaleRuns();
  console.log(`✅ CURRENT DATA LAB V2: all current verified M1 under memory guard; exploratory >=1000; promotion >=${PROMOTION_MIN_ROWS} rows + ${PROMOTION_MIN_DAYS} days; cooldown=${Math.round(NEW_DATA_COOLDOWN_MS/3600000)}h`);
  setTimeout(()=>schedulerTick().catch((e)=>console.error("CURRENT DATA LAB V2 tick:",e)),20_000);
  setInterval(()=>schedulerTick().catch((e)=>console.error("CURRENT DATA LAB V2 tick:",e)),CHECK_MS).unref();
}

if (!/^(1|true|yes)$/i.test(String(process.env.CURRENT_DATA_LAB_DISABLE_AUTOSTART||"0"))) start().catch((error)=>console.error("❌ CURRENT DATA LAB V2 INIT:",error));

module.exports={localParts,weekendSlot,withTimeout,reapStaleRuns,claimableStatus,currentM1Count,assertMemorySafety,exportAllCandles,newDataCooldownPassed,tryTrainingLock,releaseTrainingLock,executeRun,schedulerTick,start};
