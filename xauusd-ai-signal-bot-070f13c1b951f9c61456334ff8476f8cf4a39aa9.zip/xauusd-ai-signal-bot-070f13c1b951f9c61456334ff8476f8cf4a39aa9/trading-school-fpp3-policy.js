"use strict";

const DEFAULT_FPP3_FETCH_GAP_MS = 1500;

function canonicalizeFpp3Url(raw, base = "https://otexts.com/fpp3/") {
  try {
    const u = new URL(raw, base);
    if (!["http:", "https:"].includes(u.protocol)) return null;
    if (u.hostname.toLowerCase() !== "otexts.com") return null;
    u.hash = "";
    u.search = "";
    const pathname = u.pathname;
    if (pathname === "/fpp3" || pathname === "/fpp3/") {
      u.pathname = "/fpp3/";
      return u.toString();
    }
    if (!/^\/fpp3\/[^/]+\.html$/i.test(pathname)) return null;
    return u.toString();
  } catch {
    return null;
  }
}

function isTextualContentType(value) {
  const contentType = String(value || "").toLowerCase();
  return (
    contentType.includes("text/html") ||
    contentType.includes("application/xhtml+xml") ||
    contentType.includes("text/plain")
  );
}

function visibleTextLength(html) {
  const text = String(html || "")
    .replace(/<script\b[\s\S]*?<\/script>/gi, " ")
    .replace(/<style\b[\s\S]*?<\/style>/gi, " ")
    .replace(/<svg\b[\s\S]*?<\/svg>/gi, " ")
    .replace(/<noscript\b[\s\S]*?<\/noscript>/gi, " ")
    .replace(/<nav\b[\s\S]*?<\/nav>/gi, " ")
    .replace(/<footer\b[\s\S]*?<\/footer>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&(?:nbsp|amp|lt|gt|quot|apos);/gi, " ")
    .replace(/&#(?:x[0-9a-f]+|\d+);/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
  return text.length;
}

function fpp3WaitMs(lastRequestAt, now = Date.now(), gapMs = DEFAULT_FPP3_FETCH_GAP_MS) {
  const gap = Math.max(0, Number(gapMs) || 0);
  const last = Math.max(0, Number(lastRequestAt) || 0);
  const current = Math.max(0, Number(now) || 0);
  if (!last || current >= last + gap) return 0;
  return last + gap - current;
}

module.exports = {
  DEFAULT_FPP3_FETCH_GAP_MS,
  canonicalizeFpp3Url,
  isTextualContentType,
  visibleTextLength,
  fpp3WaitMs,
};
