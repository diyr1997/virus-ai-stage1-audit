# VIRUS AI — ПОЛНЫЙ ТЕХНИЧЕСКИЙ АУДИТ

**Дата:** 2026-09-21
**Ветка:** `claude/ollama-local-advisor-r9jvfu`, HEAD `90247fb`
**Назначение:** передача другому AI-инженеру для дальнейшей конфигурации.
**Статус работ:** все исправления остановлены. Ничего не удалено, не переустановлено,
архитектура не менялась, обучение не запускалось, новые датасеты не создавались.

## Легенда достоверности

| Метка | Значение |
|---|---|
| **VERIFIED** | Проверено в этой сессии: файл прочитан, команда выполнена, лог получен, сервис опрошен. Основание указано. |
| **NOT VERIFIED** | Утверждение существует в коде/документах, но текущее фактическое состояние в этой сессии не подтверждено. |
| **UNKNOWN** | Данных нет. Указано, какой доступ/файл/команда нужны. |

Ни одна цифра в этом документе не придумана. Где числа приведены — рядом стоит источник.

## ГЛАВНОЕ, ЧТО НУЖНО ЗНАТЬ ПЕРВЫМ

1. **Полноценно обученная модель существует и она настоящая.** `xauusd_ai_final_h1_full_period.joblib`
   в корне репозитория: 111 признаков, 9 297 980 просмотренных сырых строк, 1 545 615 обучающих
   примеров, период 2003-05-05 → 2026-08-14. Метаданные прочитаны прямо из pickle. **VERIFIED.**
2. **Но в продакшене активна НЕ она.** Активная модель H1 — `school-v1-h1-daily-t00-20260917T210606Z`,
   обученная на ~13 800 строках M1 (≈11 торговых дней) из живой БД. Она заменила полнопериодную
   модель через путь без гейта по объёму данных. **VERIFIED** (лог Railway + код).
3. **Исторических данных на 6,1 млн строк M1 физически НЕТ ни в репозитории, ни в контейнере.**
   Есть только манифест с SHA256. Где лежат сами zip-файлы — **UNKNOWN**.
4. **Школа книг никуда не подключена.** Её знания читают только её собственные 4 файла.
   Ни сигнальный движок, ни Совет, ни тренер их не используют. **VERIFIED.**
5. **Gemini сейчас в 429 RESOURCE_EXHAUSTED.** Это был последний работающий советник Совета.
   **VERIFIED** (лог Railway, 2026-09-21T10:40Z).

---

# 1. ТЕКУЩАЯ АРХИТЕКТУРА

## 1.1 Ядро (Core)

| Компонент | Назначение | Где лежит | Состояние | Проверено |
|---|---|---|---|---|
| `index.js` | Главный процесс: Telegram-бот, приём свечей M1, БД, сигналы, оркестрация bootstrap-модулей | корень репо, 1 файл | RUNNING | **VERIFIED** (Railway service `xauusd-ai-signal-bot`, deployment `6341fc4e`, статус SUCCESS, логи каждую минуту) |
| Bootstrap-цепочка | 11 модулей подгружаются через `node -r` перед `index.js` | `package.json:scripts.start` | RUNNING | **VERIFIED** (прочитан `package.json`) |
| `ai_h1.js` | Обёртка вызова ML-модели H1 | корень | ACTIVE | **VERIFIED** (файл есть, ссылается на joblib) |
| `ai_predict_h1.py` | Инференс: строит 111 признаков, зовёт 2 модели, применяет пороги, выдаёт BUY/SELL/WAIT | корень, 363 строки | ACTIVE | **VERIFIED** (прочитан целиком) |
| `model-registry.js` | Берёт активную модель H1 из Postgres (`model_registry`), пишет во временный файл | корень, 64 строки | ACTIVE | **VERIFIED** (прочитан; лог «MODEL REGISTRY: active H1 …» в 09:14:51Z) |

Порядок загрузки bootstrap (**VERIFIED**, `package.json`):
`today-signal-audit` → `telegram-autosignal-dedup` → `news-xau` → `graph-v6` → `signal-ui-compact` →
`trading-school` → `deepseek-first-review` → `telegram-public-access` →
`telegram-public-signal-cache` → `direction-status` → `virus-ai-chat` → `index.js`.

## 1.2 Агенты / советники (AI Council)

| Советник | Состояние | Основание |
|---|---|---|
| gemini | **БЫЛ рабочим, сейчас 429 RESOURCE_EXHAUSTED** | лог Railway 2026-09-21T09:14:52Z, 09:25, 09:36, 09:57, 10:19, 10:40 — шесть подряд |
| deepseek | `TEMPORARY_ERROR: AI API 402: Insufficient Balance` | диагностика Совета (прошлая сессия), ключ `DEEPSEEK_API_KEY` в переменных есть |
| grok | `AUTH_OR_CREDITS: xAI API 403 permission-denied` | там же; `XAI_API_KEY` в переменных есть |
| chatgpt | `NOT_CONFIGURED` | **VERIFIED**: в списке переменных сервиса `OPENAI_API_KEY` отсутствует |
| local-qwen (Ollama) | `TIMEOUT: Ollama request timed out after 120000 ms` | диагностика Совета; модель `qwen2.5:3b` (1.93 GB) скачана, ~7 tok/s |

**Вывод:** кворум Совета сейчас не собирается ни при каком значении `AI_COUNCIL_MIN_READY_ADVISORS`.
**VERIFIED** по логам и переменным.

`ai-council-gateway.js` на сервисе бота — **выключен**: лог `🧠 AI COUNCIL GATEWAY: disabled` (09:14:32Z). **VERIFIED.**

## 1.3 Сервисы Railway

Проект `virus-ai-clean-20260912` (`18b6f02a-7477-4c61-9049-03d07d151c13`),
окружение `production` (`d3319bbd-9f33-433c-8aa5-8c41a8dbb19c`), **17 сервисов**. **VERIFIED** (`list-services`).

| Сервис | ID | Состояние | Проверено |
|---|---|---|---|
| `xauusd-ai-signal-bot` | `f8710e22…` | **ONLINE**, деплой SUCCESS | **VERIFIED** (логи каждую минуту) |
| `ai-global-trader` | `ad17d34e…` | **CRASHED** (replicas running=0, crashed=1), деплой от 2026-09-12 | **VERIFIED** (`environment-status`); причина краха — логи не сохранились, **UNKNOWN** |
| `Postgres` | `e3838235…` | без issues | **VERIFIED** (в сводке проблем не значится) |
| `ai-council-gateway` | `dac13135…` | без issues; но бот к нему не обращается (gateway disabled) | **VERIFIED** частично |
| `ollama` | `7e620a9a…` | без issues | **VERIFIED** частично |
| `ollama-puller` | `be2ff561…` | без issues | **VERIFIED** частично |
| `virus-ai-intelligence` | `fadf3796…` | **NOT VERIFIED** — не опрашивался |
| `ctrader-m1-demo`, `ctrader-execution-demo`, `ctrader-trading-oauth-demo`, `ctrader-depth-demo`, `ctrader-oauth-demo` | 5 сервисов | **NOT VERIFIED** — не опрашивались |
| `backup-rv-range-20260914`, `rv-benchmark-readonly-20260914`, `live-m1-probe-20260914`, `replay-sep10-db-readonly`, `claude-autofire-db-test` | 5 сервисов | похоже на временные/диагностические; назначение и статус **NOT VERIFIED** |

Сводка Railway: `totalServices: 17, servicesWithIssues: 1`. **VERIFIED.**

Другие проекты Railway (из прошлой сессии, **NOT VERIFIED** сегодня):
`virus-ai-core-llm`, `virus-ai-3d-office-web`, `virus-ai-agent-toolbox-20260910`,
`virus-ai-v9-pr198-ci-20260909`, `radiant-energy`.

## 1.4 Локальные компоненты (не на сервере)

| Компонент | Где | Состояние |
|---|---|---|
| `demo_mt5_worker/` | репо, 40 файлов, 7 версий `trader_v9_hardened_v1…v7.py` | код есть; **NOT VERIFIED**, что где-то запущен. Это Windows-воркер (`.bat`, `windows_launcher.py`) |
| `binance_xau/` | репо, 2 файла: `README.md`, `build_v9_download.py` | заготовка, **не реализовано** |

## 1.5 Коммуникация

- Пользователь ↔ система: **Telegram**, `node-telegram-bot-api` polling. **VERIFIED** (`index.js`, переменные `TELEGRAM_BOT_TOKEN`, `TELEGRAM_OWNER_CHAT_ID`).
- `virus-ai-chat-bootstrap.js`: дверь владельца. `mode=council`, `owner_only=true`, `council_timeout=480s`. **VERIFIED** (лог 09:14:32Z).
- Внутри процесса: прямые вызовы функций Node + Postgres как общая шина состояния.
- Внешние ИИ: HTTPS к Gemini / DeepSeek / xAI / Ollama.
- Node ↔ Python: `child_process.execFile` с передачей свечей через временный JSON-файл. **VERIFIED**.

---

# 2. ЧТО УЖЕ УСТАНОВЛЕНО

## 2.1 Реестр инструментов Совета

`tools/ai_toolbox/SHARED_COUNCIL_TOOLS.json`, `updated_at: 2026-09-14`, **24 записи**.
`canonical_advisors: ["chatgpt","deepseek","claude"]`. Плюс `drive_candidates: 19`. **VERIFIED** (файл распарсен).

**Важно:** поле `status` у всех 24 записей — `None` (отсутствует). То есть сам реестр
статусы не хранит; статусы живут только в `AI_AGENT_TOOLBOX_STATUS.md`. Это расхождение. **VERIFIED.**

## 2.2 Статусы по `AI_AGENT_TOOLBOX_STATUS.md` (обновлён 2026-09-15)

| Инструмент | GitHub | Статус в ledger | Реально работает? |
|---|---|---|---|
| NVIDIA SkillSpector 2.11.2 | `NVIDIA/SkillSpector` | **ACTIVE** — обязательный security-гейт | по ledger установлен и прогнан; сегодня **NOT VERIFIED** |
| Graphify 0.9.61 | `Graphify-Labs/graphify` | **ACTIVE** — проиндексировал репо: 3841 узел, 9160 рёбер, 345 файлов | по ledger; сегодня **NOT VERIFIED** |
| Ponytail 4.10.0 | `DietrichGebert/ponytail` | **READY** — нужны 2 команды `/plugin` от пользователя | не активирован |
| purgedcv | — | **READY** (понижен с ACTIVE) — дублирует нативный walk-forward | не нужен сейчас |
| orderflow-metrics | — | **WATCH** — формулы сверены, но L1-данные нельзя выдавать за order flow | не используется |
| OmniRoute | `diegosouzapw/OmniRoute` | **NEEDS_CONFIG** | не блокер |
| Strix | `usestrix/strix` | **BLOCKED** — 9 HIGH, `curl \| bash` в payload | не ставить |
| Google Skills | `google/skills` | **BLOCKED** — скан неполный (coverage 0%), + нет Google Cloud в проекте | не ставить |
| Matt Pocock Skills | `mattpocock/skills` | **REJECTED** — дубликат `CONTEXT.md`/`PROJECT_STATE.md` | — |
| Anthropic Skills | `anthropics/skills` | **REJECTED** — уже включены нативно | — |
| Остальные 14 (Context7, AirLLM, ruflo, hermes-agent, QM, claude-mem, headroom, public-apis, supabase, playwright-cli, OpenCLI, Agent-Reach, Humanizer, DeepSeek Harness, Karpathy Skills) | см. реестр | статуса в реестре нет | **UNKNOWN** |

**Честный вывод:** из 24 записей реестра доказательно активны в проекте **2** (SkillSpector, Graphify),
и то по ledger от 2026-09-15, а не по сегодняшней проверке. Остальное — «известно Совету», но не работает.

## 2.3 NPM-зависимости (реально установлены)

`package.json` → `dependencies` (**VERIFIED**):
`@perplexity-ai/perplexity_ai@0.38.5`, `dukascopy-node@^1.45.0`,
`node-telegram-bot-api@^0.66.0`, `sharp@^0.34.0`, `pg@^8`, `ws@8.21.3`.

Шесть зависимостей на весь проект. `dukascopy-node` — установлена ради бэкфилла, **ни разу не использована**.

## 2.4 Python-окружение

- В **этом контейнере** `sklearn` НЕ установлен (`ModuleNotFoundError`), `.venv` отсутствует. **VERIFIED.**
- На Railway Python-окружение есть — иначе `ai_predict_h1.py` и `weekend_train_h1.py` не отработали бы,
  а модель `school-v1-h1-daily-t00-20260917T210606Z` была бы невозможна. Точные версии — **UNKNOWN**
  (нужен `pip freeze` на сервисе или `requirements.txt`, которого в корне нет).

---

# 3. ДАННЫЕ И БАЗЫ ДАННЫХ (КРИТИЧЕСКИЙ РАЗДЕЛ)

## 3.1 Общая инвентаризация таблиц PostgreSQL

**38 таблиц** создаются кодом (`CREATE TABLE IF NOT EXISTS`). **VERIFIED** (grep по всему репо).

Полный список: `ai_council_claude_bridge`, `ai_council_gateway_files`, `ai_council_gateway_issues`,
`ai_council_runs`, `ai_council_tasks`, `ai_global_market_experience`,
`ai_global_trader_binance_demo_orders`, `ai_global_trader_binance_paper_trades`,
`ai_global_trader_forward_evaluations`, `ai_global_trader_models`,
`ai_global_trader_shadow_predictions`, `ai_global_trader_shadow_sessions`,
`ai_global_trader_signal_events`, `ai_global_trader_trade_events`, `ai_integration_reviews`,
`analysis_results`, `analysis_runs`, `bot_settings`, `council_intake_audit`,
`council_intake_requests`, `demo_trade_alerts`, `demo_trader_events`, `demo_trades`,
`demo_worker_fence`, `demo_worker_state`, `model_registry`, `research_historical_news_v2_*`,
`signal_alerts`, `trade_candidates`, `trading_school_book_memory`, `trading_school_books`,
`trading_school_bootstrap_runs`, `trading_school_chunks`, `trading_school_pages`,
`training_current_data_runs`, `weekend_improvement_proposals`, `weekend_upgrade_runs`,
`xauusd_candles`.

**Ограничение аудита:** прямого SQL-доступа к продакшн-Postgres в этой сессии нет
(строка подключения — секрет, инжектировать её сюда запрещено политикой AGENTS.md).
Все числа по строкам получены из логов сервиса, а не из `SELECT COUNT(*)`.
**Чтобы получить точные размеры — нужен доступ:** `psql $DATABASE_PUBLIC_URL` или
readonly-сервис `replay-sep10-db-readonly`.

## 3.2 XAU/USD M1 — живые данные

| Поле | Значение | Проверено |
|---|---|---|
| Таблица | `xauusd_candles` | **VERIFIED** |
| Схема | `id BIGSERIAL, timeframe VARCHAR(5), candle_time TIMESTAMPTZ, open/high/low/close NUMERIC(18,6), volume NUMERIC(24,8), source VARCHAR(32) DEFAULT 'live', created_at, UNIQUE(timeframe,candle_time)` | **VERIFIED** (`index.js:~300`) |
| Объём M1 | ≈ **13 849 строк / 11 торговых дней** | **VERIFIED** в прошлой сессии (лог `rows=13849 \| days=11`); сегодня свежего замера нет — **NOT VERIFIED на 2026-09-21** |
| Свежесть | последняя закрытая свеча 2026-09-21T10:46:00Z, возраст 32 с | **VERIFIED** (лог 10:47:37Z) |
| Окно в память | 7000 свечей | **VERIFIED** (лог `UNIFIED CORE SERIES U..Z: 7000 real M1 candles loaded once`) |
| Источник | `source='live'`, поток MT5/cTrader | **VERIFIED** (`index.js:895`) |
| Сырые/обработанные | СЫРЫЕ OHLCV | **VERIFIED** |
| Риск утечки | нет (только закрытые свечи) | **VERIFIED** |

**Структурный блокер (VERIFIED, `index.js:895`):**
```js
const fresh = candles.filter((candle) => candle.time > maxTime);
```
Запись только вперёд. **Историю в эту таблицу дозалить штатным путём НЕЛЬЗЯ по конструкции.**

## 3.3 XAU/USD M1 — историческая база (6,1 млн строк)

**Манифест существует и подробен. Самих данных нет.**

`trading_ai/history_manifest.json` (**VERIFIED**, распарсен):

| Поле | Значение |
|---|---|
| dataset | XAUUSD M1 HistData verified Library archives |
| verified_at_utc | 2026-08-27T16:35:00Z |
| total_files | **25** (`HISTDATA_COM_ASCII_XAUUSD_M1{2009..2025}.zip` + `HISTDATA_COM_MS_XAUUSD_M1{202601..202608}.zip`) |
| total_raw_rows | **6 100 989** |
| total_rows (канонических) | **6 099 893** |
| дубликатов удалено | 420 |
| конфликтов в карантине | 332 таймстампа |
| first_utc | **2009-03-15T22:00:00Z** |
| last_utc | **2026-08-14T21:58:00Z** |
| часовой пояс источника | фиксированный EST UTC-05:00, без перехода на летнее время |
| у каждого файла | SHA256, raw_rows, canonical_rows, first_utc, last_utc |

`trading_ai/history_quarantine.json` + `.sha256` — политика «удаляем все варианты
конфликтного таймстампа, победителя не выбираем». **VERIFIED.**

**ПРОБЛЕМА (VERIFIED):**
```
find / -iname "*HISTDATA*"  →  ничего
find . \( -name "*.csv" -o "*.parquet" -o "*.zip" … \)  →  только xauusd_ai_final_h1_full_period.joblib
```
**Ни одного из 25 zip-файлов нет ни в репозитории, ни на диске контейнера.**
Загружены ли они в `xauusd_candles` — **NOT VERIFIED** (в живой таблице по последнему
замеру 13 849 строк, а не 6,1 млн, что говорит скорее «нет»).

**Где эти 6,1 млн строк физически — UNKNOWN.** Нужно проверить: Google Drive пользователя,
локальный ПК, Railway volume, или архив, к которому у агента нет доступа.
Команда для проверки БД: `SELECT source, COUNT(*), MIN(candle_time), MAX(candle_time) FROM xauusd_candles GROUP BY source;`

## 3.4 Датасет AI H1 (заявленные 9,3 млн / 1,545 млн / 111 признаков) — **ПОДТВЕРЖДЁН**

Метаданные извлечены прямо из `xauusd_ai_final_h1_full_period.joblib`
(zlib-распаковка + чтение pickle-строк, **без исполнения кода**). **VERIFIED:**

| Поле метаданных | Значение |
|---|---|
| `version` | `xauusd_ai_final_h1_full_period` |
| `raw_rows_scanned` | **9 297 980** |
| `training_samples` | **1 545 615** |
| `sample_every` | **5** (каждая 5-я строка) |
| `period_start_utc` | **2003-05-05T03:21:00+00:00** |
| `period_end_utc` | **2026-08-14T19:55:00+00:00** |
| `cost_bps_metadata` | **1.0** |
| `historical_validation_source` | **«V5 rolling walk-forward 2020-2026»** |
| `deployment_status` | **«candidate_for_forward/demo validation»** |
| `warning` | **«This final model has seen the whole historical period. It must be judged next on NEW future data, not re-tested on the same history.»** |

Ваша цифра «~9,3 млн строк, ~1,545 млн примеров, ~111 признаков, walk-forward 2020–2026»
**подтверждается посимвольно.** Это не выдумка и не оценка.

**Но два расхождения, которые надо решить:**
1. Модель обучена с **2003-05-05**, а манифест HistData начинается с **2009-03-15**.
   Откуда данные 2003–2009 — **UNKNOWN**. Источник не задокументирован ни в одном найденном файле.
2. `historical_validation_source` — это **строка в метаданных**, а не сохранённые метрики.
   **Ни одной цифры результата walk-forward (accuracy, MAE, PnL) в артефакте нет.** **VERIFIED** —
   искал, в pickle только гиперпараметры и пороги.

## 3.5 Новости

| Датасет | Объём | Статус |
|---|---|---|
| `research_historical_news_v2_events` | **ровно 72 события** (CHECK-констрейнт `expected_count=72`), семейства `CPI` и `EMPLOYMENT_SITUATION`, годы **2003–2005**, источник — только `https://www.bls.gov/news.release/(history\|archives)/(cpi\|empsit)_YYYYMMDD.txt` | **VERIFIED** (`research/import_historical_news_v2_phase1.js:47-57`). Схема образцовая: SHA256 на каждый документ, проверка EST/EDT, `UNIQUE`, откат при частичном импорте. Но **72 события — для ML это ничто.** Загружены ли они в прод — **NOT VERIFIED** |
| Оперативная лента новостей | `news.js`, Gemini + Google News | RUNNING, но Gemini в 429 → **деградирована**. Лог: «основной новостной движок продолжает работать» |

## 3.6 CFTC

`cftc.js` подключён в `index.js:35`. Явно отделён от новостной ленты
(`news.js:13`: «CFTC здесь НЕ смешивается»). В `trade_candidates` есть поле
`cftc_direction VARCHAR(12)` (`index.js:323`). **VERIFIED.**
По аудиту источников: `CFTC: PRIMARY, WEEKLY, historical_status: REPLAYED`
(`research/global_gold_source_audit_v3.js:74`).
**Объём накопленных CFTC-данных — UNKNOWN** (нужен SQL-запрос к БД).

## 3.7 Макро-контекст

`research/GLOBAL_GOLD_INTELLIGENCE_V3_FILTERED_MASTER.md` перечисляет 14 первичных источников:
Fed/FOMC, NY Fed, BLS, BEA, US Treasury/FiscalData, OFAC, CFTC, CME/COMEX, US Census,
White House, USTR, FRED, USGS, EIA. **VERIFIED** (файл есть).
**Реально собранных макро-рядов в БД — UNKNOWN.** Таблицы под них в списке из 38 нет.

## 3.8 Признаки (features)

**Два независимых набора признаков. Это ключевое архитектурное расхождение.**

**Набор A — тот, что реально работает (111 признаков).** Извлечён из joblib, **VERIFIED**:
- **M1 (39):** `ret1,2,3,5,10,15,30,60`; `body_pct`, `range_pct`, `upper_wick_pct`, `lower_wick_pct`;
  `ema{5,10,20,50,100,200}_gap`; `ema5_20_spread`, `ema20_50_spread`, `ema50_100_spread`;
  `vol{5,15,30,60}`; `rsi{7,14,28}`; `atr14_pct`, `atr50_pct`;
  `dist_high/low{20,60,120}`; `momentum_5_20`, `momentum_15_60`; `range_ratio_5_30`
- **Время (4):** `hour_sin`, `hour_cos`, `dow_sin`, `dow_cos`
- **M5 / M15 / M30 / M60 (по 17 каждый = 68):** `ret1,2,3`, `body_pct`, `range_pct`,
  `ema{5,10,20}_gap`, `ema5_20_spread`, `vol{5,10}`, `rsi14`, `atr14_pct`, `dist_high/low{10,20}`
- **Итого 39 + 4 + 68 = 111.** Совпадает с `n_features_in_ = 111` в самой модели.
- Генератор: `ai_predict_h1.py` (инференс) и `weekend_train_h1.py` (обучение) — одна и та же логика.

**Набор B — исследовательский, в проде не используется:** `trading_ai/` —
`features.py`, `classic_indicators.py`, `all_indicator_stack.py` (299 стр.),
`indicator_universe.py` (418 стр.), `kaufman.py`, `anchored_price.py`,
`market_structure.py`, `mtf.py`, `sampled_quotes.py`, `session_context.py`,
`video_context.py`, `economic_labels.py`. Всего 4308 строк Python.
**VERIFIED, что он мёртв в рантайме:** `trading_ai` упоминается только в двух workflow
(`trading-ai-tests.yml`, `current-safety-reaudit-tests.yml`), т.е. только в CI-тестах.
Ни один рантайм-файл его не импортирует.

**Школьные признаки:** `ai_predict_h1.py` импортирует
`from trading_school.features_v1 import add_trading_school_features` и считает их,
но **ни один `school_*` признак не входит в список 111 признаков модели** — они только
выводятся в поле `trading_school` ответа, как справка. **VERIFIED.**

## 3.9 Метки (labels)

**Тоже два несовместимых набора.**

**Набор A — рабочий (`weekend_train_h1.py:59-73`). VERIFIED:**
```python
x["future_close_60"]   = x["close"].shift(-60)
x["future_ts_60"]      = x["timestamp"].shift(-60)
x["future_delta_min"]  = (x["future_ts_60"] - x["timestamp"]) / 60_000.0
x["target_return_bps"] = (x["future_close_60"] / x["close"] - 1.0) * 10_000.0
x["target_direction"]  = np.where(x["target_return_bps"] >= 0.0, 1, -1)
x = x[(x["future_delta_min"] >= 55.0) & (x["future_delta_min"] <= 70.0)]
```
- Горизонт: **ровно 60 баров M1 вперёд**.
- Класса **два: +1 и −1. Класса WAIT в метках НЕТ.**
- Порог: `>= 0` — **нулевая мёртвая зона**.
- Спред, комиссия, проскальзывание в метку **не заложены**.
- Фильтр 55–70 минут отбрасывает строки, перепрыгивающие выходные и дыры. Это правильно.

**Набор B — исследовательский (`trading_ai/labels.py`, 99 строк). VERIFIED, в проде не используется:**
трёхклассовый `BUY/WAIT/SELL` с адаптивным порогом
`threshold = max(0.00002, causal_abs_return_mean * 0.60)`, горизонты `(1,3,5,10,15,30,60)`,
причём порог считается **строго причинно** — используются только уже разрешённые исходы
(`i + h <= index`, по индексу бара, а не по часам, — специально ради выходных и пропусков).
В докстринге прямо сказано, что исполняемый контракт с BID/ASK живёт в `economic_labels.py`.

**Вывод:** более правильный (трёхклассовый, причинный, с адаптивной мёртвой зоной) лейблер
написан — и не подключён. Работает более примитивный.

## 3.10 Артефакты моделей

| Артефакт | Где | Что внутри | Проверено |
|---|---|---|---|
| `xauusd_ai_final_h1_full_period.joblib` | корень репо, **981 845 байт** (2 262 713 после распаковки) | dict: `version`, `features` (111), `horizons: [60]`, `direction_models: {60: HistGradientBoostingClassifier}`, `return_models: {60: HistGradientBoostingRegressor}`, `thresholds: {60: {...}}`, `metadata` | **VERIFIED** — распакован и разобран |
| `model_registry` (Postgres) | таблица, колонка `model_bytes BYTEA` | активная модель H1 | **VERIFIED** — схема прочитана |
| Активная H1 | `school-v1-h1-daily-t00-20260917T210606Z` | обучена `weekend_train_h1.py --mode daily` 2026-09-17T21:06:06Z | **VERIFIED** — лог Railway 09:14:51Z + шаблон имени `weekend_train_h1.py:277` |
| `ai_global_trader_models` | таблица | модели крипто-ветки | **NOT VERIFIED** — содержимое неизвестно |

## 3.11 Данные бэктеста и валидации

**Отдельных сохранённых датасетов бэктеста/валидации НЕТ.** **VERIFIED.**
Валидация делается на лету: `purged_chronological_split` режет тот же массив свечей
на train/valid в момент обучения, результаты пишутся в `metrics JSONB` таблицы
`training_current_data_runs` / `model_registry`. Никакого зафиксированного
hold-out-набора, который можно было бы переиспользовать, не существует.

## 3.12 Данные школы книг

| Источник | Страниц | Чанков понято | Символов | Статус |
|---|---|---|---|---|
| `stefan_jansen_ml4t_companion` | 28/28 | **46/46** | 338 297 | INGESTED |
| `sutton_barto_rl2` | 548/548 | **0/539** | 1 524 221 | INGESTED |
| `nist_statistics_handbook` | 90/300 | **0/93** | 248 172 | READING |
| `zerodha_ta` | — | идёт (лог `UNDERSTOOD … part 5` в 10:44) | — | READING |
| `babypips_pipsology` | 0/1 | 0/0 | 0 | **STUCK: HTTP 403** |
| `islr2` | 0/0 | 0/0 | 0 | **ERROR** |
| `quantinsti_2026`, `brooks_*` ×3, `bulkowski_*`, `chan_*` ×2, `elder_*`, `grimes_*`, `jansen_book`, `kaufman_*`, `lopez_de_prado_afml`, `murphy_*`, `pardo_*`, `shannon_*` ×2 | 0/0 | 0/0 | 0 | **WAITING_USER_COPY** (17 источников) |

Все строки — **VERIFIED**, лог Railway 2026-09-21T10:44:37Z.

**Главный факт о школе (VERIFIED, grep по всему репо, кроме node_modules и tests):**
таблицы `trading_school_book_memory` и `trading_school_chunks` читают ровно
**4 файла — и все 4 принадлежат самой школе**:
`trading-school-reader.js`, `trading-school-open-companions.js`,
`trading-school-core-priority.js`, `trading-school-fpp3-guard.js`.

**Ни сигнальный движок, ни Совет, ни тренер, ни чат-дверь эти знания не читают.**
Школа платит Gemini за пересказ публичных учебников в таблицы, которые никто не открывает,
и **ни один весовой коэффициент модели от этого не меняется.**

---

# 4. ТОРГОВАЯ AI-МОДЕЛЬ

## 4.1 Архитектура

**Не одна модель, а связка из двух + пороговое правило.** **VERIFIED**
(структура pickle + `ai_predict_h1.py:264-290`).

| Часть | Класс | Задача |
|---|---|---|
| `direction_models[60]` | `sklearn.ensemble.HistGradientBoostingClassifier` | знак движения через 60 минут |
| `return_models[60]` | `sklearn.ensemble.HistGradientBoostingRegressor` | величина движения в bps |
| `thresholds[60]` | dict | превращает два предсказания в BUY / SELL / **WAIT** |

**Гиперпараметры (VERIFIED, декодированы из pickle):**

| Параметр | Классификатор | Регрессор |
|---|---|---|
| loss | `log_loss` (`HalfBinomialLoss`) | `squared_error` |
| learning_rate | 0.04 | 0.04 |
| max_iter | 280 | 280 |
| max_leaf_nodes | 31 | 31 |
| max_depth | None | None |
| min_samples_leaf | 110 | 110 |
| l2_regularization | 2.0 | 2.0 |
| max_features | 1.0 | 1.0 |
| max_bins | 255 | 255 |
| early_stopping | **True** | True |
| validation_fraction | **0.1** | 0.1 |
| n_iter_no_change | 25 | 25 |
| class_weight | **`balanced`** | — |
| random_state | 58828 | 58828 |
| `n_features_in_` | **111** | 111 |
| `n_trees_per_iteration_` | **1** | — |
| `classes_` | **`[-1, +1]`, dtype int8** | — |

## 4.2 Признаки, цель, горизонт, таймфреймы

- **Признаков:** 111 (полный список — раздел 3.8). **VERIFIED.**
- **Таймфреймы признаков:** M1, M5, M15, M30, M60. **M30 и H1 присутствуют**, что соответствует
  вашему требованию M1/M5/M15/M30/H1. Признаки старших ТФ строятся ресемплингом M1
  (`TF_MINUTES = [5, 15, 30, 60]`, `ai_predict_h1.py:15`). **VERIFIED.**
- **Горизонт:** ровно один — **60 баров M1** (`horizons: [60]`). Больше горизонтов в артефакте нет. **VERIFIED.**
- **Цель классификатора:** `target_direction ∈ {−1, +1}`.
- **Цель регрессора:** `target_return_bps` — доходность close→close через 60 баров, в bps.
- **Только закрытые свечи:** да. Инференс требует ≥ 2400 свечей M1, берёт хвост 7000,
  считает признаки, берёт последнюю строку без NaN. **VERIFIED** (`ai_predict_h1.py:222-266`).

## 4.3 Как получается BUY / SELL / WAIT

**VERIFIED**, `ai_predict_h1.py:264-290`:

```
probs      = direction_model.predict_proba(X)[0]
sign       = classes[argmax(probs)]          # −1 или +1
confidence = max(probs)
ret_bps    = return_model.predict(X)[0]
reg_sign   = +1 if ret_bps >= 0 else −1
strength   = |ret_bps| / target_scale_bps

if sign != reg_sign                → WAIT, reason = models_disagree
elif confidence < 0.60             → WAIT, reason = confidence_below_threshold
elif strength   < 0.25             → WAIT, reason = move_below_threshold
else                               → BUY (sign>0) / SELL (sign<0)
```

Пороги из артефакта (**VERIFIED**, декодированы):
`direction_confidence = 0.60`, `predicted_strength_ratio = 0.25`, `target_scale_bps = 8.779764175415039`.

**Ключевое:** **WAIT — это не класс модели, а правило поверх неё.** Модель всегда говорит
«вверх» или «вниз»; WAIT появляется, когда две модели спорят, или уверенность < 60 %,
или предсказанное движение < 0.25 × 8.78 bps ≈ **2.2 bps ≈ 0.09 $ при золоте 4000 $**.

## 4.4 Зона входа, подтверждение, инвалидация, TP/SL

**В артефакте и в `ai_predict_h1.py` их НЕТ.** Модель выдаёт:
`action`, `direction`, `confidence`, `predicted_return_bps`, `predicted_price_60m`,
`strength_ratio`, `agreement`, `reason`. **VERIFIED** — прочитан весь возвращаемый dict.

Зона входа / подтверждение / инвалидация / TP / SL формируются **выше**, в `index.js`
(порог сигнала 60/100, `trade_candidates`, риск-режимы `CAUTIOUS/MEDIUM/ACTIVE/AGGRESSIVE`).
Полный аудит этой логики в данной сессии **не проводился** — **NOT VERIFIED**.

## 4.5 Спред, комиссия, проскальзывание

**Не учитываются нигде в обучении и приёмке.** **VERIFIED:**
- В метке: `target_return_bps` — чистая close→close доходность, издержки не вычитаются.
- В приёмке (`_should_accept`, `weekend_train_h1.py:130-190`): критерии —
  `direction_accuracy`, `high_conf_accuracy`, `return_mae_bps`. **Ни одного критерия по PnL за вычетом издержек.**
- В артефакте есть `cost_bps_metadata: 1.0` — но это **только запись в метаданных**,
  на обучение и на решение не влияет.
- В переменных Railway есть `TRADING_AI_ROUND_TRIP_COST_RETURN` — но он относится к
  `trading_ai/`, который в рантайме мёртв (раздел 3.8).
- Существующий cost-aware контракт: `trading_ai/economic_labels.py` (230 строк) — **не подключён**.

**Следствие:** порог входа ≈ 2.2 bps при типичном спреде по золоту порядка 15–30 bps.
Модель может показывать хорошую accuracy и при этом быть убыточной после издержек.
Это **не измерено** — ни одного бэктеста с издержками в проекте не найдено.

## 4.6 Дисбаланс классов

`class_weight='balanced'` в классификаторе. **VERIFIED.**
Для метки «знак 60-барной доходности» дисбаланс небольшой по построению, так что
это скорее страховка, чем решение проблемы.

## 4.7 Разбиение train / validation / test

**VERIFIED**, `weekend_train_h1_safe.py:21-88` — `purged_chronological_split`:

| Параметр | Значение |
|---|---|
| train_fraction | 0.70 |
| min_train_rows | 5 000 |
| min_valid_rows | 1 500 |
| **purge_rows** | **60** (= длина горизонта) |
| порядок | строго хронологический, без перемешивания |

**Защита от утечки — реализована хорошо. Две независимые проверки:**
1. Внутри сплита: `if train_end_future_ts >= valid_start_ts: raise RuntimeError("Temporal leakage detected after purge")`
2. Повторно в тренере (`weekend_train_h1.py:238`): `if int(train_df["future_ts_60"].max()) >= int(valid_df["timestamp"].min()): raise`

То есть ни одна обучающая метка не может ссылаться на цену внутри валидации. Это правильно
и это **реальное инженерное достоинство проекта**.

**Чего НЕТ (VERIFIED):**
- **Нет отдельного test-набора.** Есть только train и valid. Слово «test» в сплите не встречается.
- **Нет финального hold-out.** Нет ни одного зафиксированного куска истории, отложенного навсегда.
- **Нет embargo** сверх purge=60 (переменная `TRADING_AI_EMBARGO_MINUTES` существует, но относится
  к мёртвому `trading_ai/`).

## 4.8 Walk-forward

**Два разных механизма, и это надо чётко разделить:**

1. **`trading_ai/walk_forward.py` (151 строка)** — настоящий расширяющийся walk-forward
   с `_fold_boundaries(n, folds, initial_train_fraction)`, переменные
   `TRADING_AI_WALK_FORWARD_FOLDS`, `TRADING_AI_EMBARGO_MINUTES`.
   **Тестируется только в CI.** В рантайме не вызывается. **VERIFIED.**

2. **`_evaluate_blocks` (`weekend_train_h1.py:105-120`)** — валидация режется на **3 блока**,
   и челленджер обязан быть не хуже чемпиона в ≥ 2 из 3 блоков, при худшем блоке ≥ −1.5 %
   и медианном ≥ −0.2 %. Это **не walk-forward**, а проверка устойчивости внутри одного
   валидационного окна. **VERIFIED.**

Запись `historical_validation_source: "V5 rolling walk-forward 2020-2026"` в артефакте
относится к прогону, который выполнялся **вне этого репозитория**. Код этого прогона
и его результаты в репозитории **не найдены** — **NOT VERIFIED**.

## 4.9 Out-of-sample и финальный hold-out

- Out-of-sample **в рамках одного обучения** — есть (валидационный хвост после purge). **VERIFIED.**
- Финальный hold-out — **НЕТ.** **VERIFIED.**
- Сама модель об этом честно предупреждает в метаданных:
  *«This final model has seen the whole historical period. It must be judged next on NEW future data,
  not re-tested on the same history.»* **VERIFIED.**

## 4.10 Проверки от утечки — полный список

**Реализовано (VERIFIED):**
1. Хронологический сплит без перемешивания.
2. Purge = 60 баров между train и valid.
3. Двойной assert на `max(train.future_ts_60) < min(valid.timestamp)`.
4. Фильтр `55 ≤ future_delta_min ≤ 70` — метка не перепрыгивает выходные и дыры.
5. `dump_reload_verify` — модель сохраняется, перечитывается, и предсказания на валидации
   обязаны совпасть побитово (`rtol=atol=1e-12`), иначе RuntimeError. Это защита от
   «модель в памяти хорошая, а сохранённая — другая».
6. В `trading_ai/labels.py` — причинный порог WAIT по индексу бара, а не по часам.

**Не реализовано:**
7. Нет embargo сверх purge.
8. Нет проверки на дублирование признаков между ТФ.
9. Нет point-in-time-контроля новостей/CFTC (они в модель и не входят).

## 4.11 Метрики и результаты

**Метрики, которые считаются (VERIFIED, `weekend_train_h1.py:76-95`):**
`direction_accuracy`, `high_conf_accuracy` (при confidence ≥ 0.60), `high_conf_coverage`,
`return_mae_bps`, `samples`, `high_conf_samples`.

**Критерии замены чемпиона (`_should_accept`, VERIFIED):**

| Условие | Порог (daily / weekend) |
|---|---|
| прирост direction_accuracy | ≥ **+0.003 / +0.005** |
| ИЛИ прирост high_conf_accuracy | ≥ +0.010 при просадке dir ≥ −0.006 / −0.010 |
| samples на валидации | ≥ 1 000 |
| high_conf_coverage | ≥ 3 % |
| return_mae_bps челленджера / чемпиона | ≤ 1.08 |
| блоков с приростом | ≥ 2 из 3 |
| худший блок | ≥ −0.015 |
| медианный блок | ≥ −0.002 |
| MAE в любом блоке | ≤ 1.15 × чемпион |

**ФАКТИЧЕСКИЕ ЧИСЛА РЕЗУЛЬТАТОВ — НЕ ПОЛУЧЕНЫ.**
Они лежат в `model_registry.metrics` и `training_current_data_runs.metrics` (JSONB) в Postgres.
Прямого SQL-доступа в этой сессии нет. **Ни одной цифры accuracy я не привожу, потому что
не видел её.** Чтобы получить:
```sql
SELECT version, created_at, metrics FROM model_registry WHERE model_key='H1' ORDER BY created_at DESC LIMIT 10;
SELECT run_key, tier, source_rows, trading_days, metrics FROM training_current_data_runs ORDER BY finished_at DESC LIMIT 20;
```

## 4.12 Насколько модели можно доверять — честная оценка

**Можно доверять (VERIFIED):**
- Защита от временной утечки — сделана на уровне выше среднего по индустрии (двойной assert + purge + фильтр разрывов).
- `dump_reload_verify` — редкая и правильная практика.
- Сравнение с чемпионом по блокам — защита от переобучения на одном режиме.
- Метаданные честные: артефакт сам предупреждает, что видел всю историю.

**Нельзя доверять (VERIFIED):**
- **Никакой оценки прибыльности не существует.** Accuracy ≠ деньги. Издержки не вычитаются нигде.
- Порог входа ≈ 2.2 bps несопоставим с реальным спредом по золоту. С высокой вероятностью
  большинство «сигналов» экономически бессмысленны. Это **гипотеза**, она **не измерена**.
- **Финального hold-out нет**, значит числа walk-forward 2020–2026 (которых мы даже не видели)
  нечем перепроверить.
- **Активная в проде модель обучена на ~11 днях данных** (раздел 5.4). Её обобщающая
  способность за пределами этих 11 дней ничем не подтверждена.
- Строка `V5 rolling walk-forward 2020-2026` — **утверждение без приложенных доказательств**.
  Код и результаты не найдены.

---

# 5. PIPELINE ОБУЧЕНИЯ — КАК ЕСТЬ

## 5.1 Схема фактического пути

```
xauusd_candles (PostgreSQL, timeframe='M1', source='live')
   │  exportCandles(limit) : ORDER BY candle_time DESC LIMIT N, затем .reverse()
   ▼
временный JSON-файл в os.tmpdir()
   │  execFile(python, weekend_train_h1.py --champion … --candles … --mode daily|weekend)
   ▼
[CLEANING]  to_numeric → dropna → sort_values(timestamp) → drop_duplicates → float64
   ▼
[FEATURE ENGINEERING]  add_m1_features + ресемплинг M5/M15/M30/M60 + hour/dow sin/cos = 111
   ▼
[LABELING]  shift(-60) → target_return_bps, target_direction=sign; фильтр 55≤Δt≤70 мин
   ▼
[SPLIT]  purged_chronological_split(train=0.70, purge=60) + двойной assert на утечку
   ▼
[TRAIN]  HistGradientBoostingClassifier + HistGradientBoostingRegressor (internal early stopping, validation_fraction=0.1)
   ▼
[VALIDATION]  _evaluate на валидационном хвосте + _evaluate_blocks (3 блока)
   ▼
[ACCEPT?]  _should_accept(champion, challenger) — 9 критериев, все по accuracy/MAE
   ▼
[SAVE+VERIFY]  dump_reload_verify — перечитать и сверить предсказания побитово
   ▼
[PROMOTE]  model_registry: UPDATE active=FALSE; INSERT новый active=TRUE (BYTEA)
   ▼
[SERVE]  model-registry.js кладёт BYTEA в /tmp/xauusd_ai_h1_active.joblib
   ▼
ai_predict_h1.py → BUY/SELL/WAIT → index.js → Telegram
```

## 5.2 Соответствие вашему эталонному pipeline

| Ваш этап | Есть? | Комментарий |
|---|---|---|
| DATA | **ЧАСТИЧНО** | живой поток M1 есть; 6,1 млн строк истории физически отсутствуют |
| CLEANING | **ЕСТЬ** | dropna, dedup, сортировка, приведение типов. **VERIFIED** |
| FEATURE ENGINEERING | **ЕСТЬ** | 111 признаков, одна и та же логика в train и в inference. **VERIFIED** |
| LABELING | **ЕСТЬ, но примитивно** | 2 класса, нулевая мёртвая зона, без издержек |
| SPLIT | **ЕСТЬ** | 70/30 хронологически + purge 60 |
| TRAIN | **ЕСТЬ** | sklearn HistGB ×2 |
| VALIDATION | **ЕСТЬ** | + разбивка на 3 блока |
| WALK-FORWARD | **НЕТ в рантайме** | код есть (`trading_ai/walk_forward.py`), вызывается только в CI |
| TEST | **НЕТ** | отдельного test-набора не существует |
| FINAL HOLDOUT | **НЕТ** | не существует |
| BACKTEST | **НЕТ** | ни одного бэктеста с издержками в проекте не найдено |
| PAPER / DEMO | **ЧАСТИЧНО** | `demo_trades`, `demo_worker_*`, `ai_global_trader_binance_paper_trades`, `*_shadow_*` таблицы есть; фактическое наполнение **NOT VERIFIED** |
| PRODUCTION | **ЕСТЬ (сигналы), торговля выключена** | REAL trading disabled по AGENTS.md |

## 5.3 Три параллельных обучающих пути — и это проблема

**VERIFIED** (прочитаны все три файла):

| Файл | Тренер | Гейт по объёму | Кого повышает |
|---|---|---|---|
| `weekend-upgrade.js` | `weekend_train_h1.py --mode daily\|weekend` | **ТОЛЬКО `candles.length >= 8000`** | повышает при `training.accepted` — **без проверки числа дней** |
| `training-current-data-lab-v2.js` | `weekend_train_h1.py --mode weekend` / `exploratory_train_h1.py` | `PROMOTION_MIN_ROWS = 15000`, `PROMOTION_MIN_DAYS = 10` | повышает только при `audit.rows ≥ 15000 && tradingDays ≥ 10` |
| `training-current-data-lab.js` (v1) | тот же | старая версия | остаётся в репо |

**Эти три файла пишут в ОДНУ таблицу `model_registry`.** Строгий гейт v2 обходится
слабым гейтом `weekend-upgrade.js`.

## 5.4 Что из этого следует — главная находка раздела

Активная модель — `school-v1-h1-daily-t00-20260917T210606Z`. **VERIFIED** (лог Railway).

Разбор имени по шаблону `weekend_train_h1.py:277`
(`f"school-v1-h1-{mode}-t{trial:02d}-{timestamp}"`): `mode = daily`, `trial = 0`,
время `2026-09-17T21:06:06Z`. **Единственный путь, порождающий `mode=daily`** —
`weekend-upgrade.js:368` (`const mode = kind === "DAILY" ? "daily" : "weekend"`),
потому что `training-current-data-lab-v2.js:263` жёстко передаёт `"--mode","weekend"`. **VERIFIED.**

Значит активная модель:
- обучена на `exportCandles(DAILY_LIMIT = 40 000)` — то есть на **всех имеющихся** M1-строках,
  а их по последнему замеру ≈ **13 849 (≈11 торговых дней)**;
- прошла через `promoteModel` (`weekend-upgrade.js:218`), где **нет проверки ни на 15 000 строк,
  ни на 10 дней** — только `if (!training.accepted) return false`;
- заменила собой полнопериодную модель на 1 545 615 примерах, которая теперь используется
  лишь как fallback, если в `model_registry` нет активной строки (`model-registry.js:34-37`).

**Иначе говоря: модель, обученная на 11 днях, вытеснила модель, обученную на 23 годах.**
Формально — потому что показала на ~4 000 строк валидации accuracy на 0.3 % выше.

---

# 6. ЧТО Я ДЕЛАЛ И ГДЕ ОСТАНОВИЛСЯ

## 6.1 Остановлено по вашему требованию

**Все исправления прекращены.** Ни одного изменения кода в этой сессии не сделано.
Единственный созданный файл — этот аудит.

## 6.2 Незавершённые процессы — состояние, а не продолжение

| Процесс | Состояние | Почему не трогаю |
|---|---|---|
| Школа книг (`trading-school-reader.js`) | **ПРОДОЛЖАЕТ РАБОТАТЬ** на сервере, читает `zerodha_ta`, интервал из `TRADING_SCHOOL_READ_INTERVAL_MS` | Остановка = изменение переменной Railway = изменение конфигурации. Ваше правило 3 (не менять архитектуру) и 2 (не переустанавливать). **Жду указания.** |
| `ops/backfill-xauusd-m1.js` | **НАПИСАН, НИ РАЗУ НЕ ЗАПУЩЕН** | Запуск = создание датасета + длинный процесс. Ваши правила 5 и 6. |
| `ai-global-trader` (Railway) | **CRASHED** с 2026-09-12 | Правило 2. |

## 6.3 Что было сделано до аудита (последние коммиты)

`90247fb` — починка двух застрявших книг; `577f888` — merge PR #234 (диагностика состояния);
`1c56f76` — обход новой книги + объяснение в логе, почему книга застряла. **VERIFIED** (`git log`).

Рабочее дерево **чистое**, незакоммиченных изменений нет (кроме этого файла). **VERIFIED** (`git status`).

## 6.4 Архитектурная цель, к которой я шёл (для полноты, не как предложение)

Устранял один повторяющийся дефект: **терминальное состояние без выхода + повтор без счётчика**.
Найдено и исправлено 7 экземпляров (школа ×3, autonomy, training-slot, gateway, PDF-ingest).
Все слиты в основную ветку. Это была работа по надёжности, **не по обучению**.

---

# 7. ТЕКУЩИЕ ОШИБКИ

## ERROR 1 — Gemini 429 RESOURCE_EXHAUSTED

- **Причина:** исчерпана квота Gemini API.
- **Где:** сервис `xauusd-ai-signal-bot`, движок новостей + школа. Лог:
  `{"statusCode":429,"status":"RESOURCE_EXHAUSTED","message":"You exceeded your current quota…"}`
- **Когда:** 09:14:52Z, 09:25:36Z, 09:36:37Z, 09:57:37Z, 10:19:39Z, 10:40:37Z (2026-09-21). **VERIFIED.**
- **Влияние:** Gemini был последним работающим советником Совета. Сейчас Совет без кворума.
  Автопауза растёт 5 → 10 → 20 мин. Новостной движок продолжает работать в деградированном режиме.
- **Безопасно ли чинить:** да — это вопрос биллинга/квоты, кода не касается.
- **Зависимости:** `GEMINI_API_KEY`, тариф Google AI Studio.

## ERROR 2 — Сервис `ai-global-trader` упал

- **Причина:** **UNKNOWN**. Логи деплоя `5f51d5f7` не сохранились (пустой ответ).
- **Где:** Railway, сервис `ad17d34e-dfe7-4bd4-8a32-f19e52c404f2`, деплой от 2026-09-12T15:02Z.
- **Влияние:** `replicas running=0, crashed=1`. Крипто/мульти-рынок ветка не работает.
  На XAU/USD-сигналы не влияет (они в другом сервисе).
- **Безопасно ли чинить:** сначала нужен redeploy ради свежих логов. Это изменение состояния — **жду указания.**
- **Зависимости:** неизвестны до получения логов.

## ERROR 3 — DeepSeek: 402 Insufficient Balance

- **Причина:** нулевой баланс аккаунта.
- **Где:** `ai-providers.js`, вызовы DeepSeek. **Влияние:** советник выбывает из Совета.
- **Безопасно ли чинить:** да, пополнение. Кода не касается.

## ERROR 4 — Grok: 403 permission-denied

- **Причина:** ключ создан, но не активирован / нет прав. Текст: `"Your newly cr…"`.
- **Где:** `XAI_API_KEY`. **Влияние:** советник выбывает.
- **Безопасно ли чинить:** да, в консоли xAI.

## ERROR 5 — ChatGPT: NOT_CONFIGURED

- **Причина:** **VERIFIED** — переменной `OPENAI_API_KEY` нет в списке переменных сервиса.
- **Влияние:** советник, указанный в `SHARED_COUNCIL_TOOLS.json` как один из трёх канонических, не работает.
- **Безопасно ли чинить:** да, добавить переменную.

## ERROR 6 — Ollama: TIMEOUT 120 000 ms

- **Причина:** `qwen2.5:3b` на CPU выдаёт ~7 tok/s; 8.2 с только на загрузку модели.
  Ответ Совета не укладывается в 120 с.
- **Где:** сервис `ollama`, переменные `OLLAMA_TIMEOUT_MS`, `OLLAMA_MAX_OUTPUT_TOKENS`.
- **Влияние:** локальный советник бесполезен для длинных ответов.
- **Безопасно ли чинить:** да — поднять таймаут или урезать вывод. Но это не решает скорость.

## ERROR 7 — Школа: `babypips_pipsology` STUCK HTTP 403

- **Причина:** сайт отдаёт 403 на серверный запрос. **Влияние:** источник не читается.
- **Статус:** переведён в `user_copy_required`, ретраи остановлены. Не вредит.

## ERROR 8 — Школа: `islr2` ERROR

- **Причина:** прямой PDF недоступен для скачивания. **Влияние:** источник не читается.
- **Статус:** переведён в `user_copy_required`. Не вредит.

## ERROR 9 — 17 книг в `WAITING_USER_COPY`

- **Причина:** нужны легальные копии от владельца (пиратские зеркала политикой запрещены —
  `library_manifest.json`: *«Pirate mirrors are never ingested»*).
- **Влияние:** самые ценные книги (Lopez de Prado AFML, Kaufman, Chan, Pardo, Murphy,
  Brooks, Elder, Bulkowski) не прочитаны.

## ERROR 10 — 0 понятых чанков у двух прочитанных книг

- **Где:** `sutton_barto_rl2` 0/539, `nist_statistics_handbook` 0/93. **VERIFIED.**
- **Причина:** скорее всего производная от ERROR 1 (Gemini не отвечает) — но **NOT VERIFIED**,
  прямой связи в логах не видел.

## ERROR 11 — Два гейта повышения модели противоречат друг другу (архитектурный дефект)

- **Причина:** `weekend-upgrade.js:218` повышает без проверки объёма; `training-current-data-lab-v2.js:217` — с проверкой. Пишут в одну таблицу.
- **Где:** `weekend-upgrade.js` vs `training-current-data-lab-v2.js`. **VERIFIED.**
- **Влияние:** **это уже сработало** — активная модель обучена на 11 днях (раздел 5.4).
- **Безопасно ли чинить:** да, изменение локальное. Но это изменение поведения обучения — **жду указания.**

## ERROR 12 — Заявленные 6,1 млн строк истории физически отсутствуют

- **Причина:** **UNKNOWN**. Манифест с SHA256 есть, zip-файлов нет нигде на диске. **VERIFIED.**
- **Влияние:** самое тяжёлое из всех. Без этих данных настоящее обучение невозможно.
- **Что нужно:** указать, где лежат файлы, либо разрешить бэкфилл через Dukascopy.

---

# 8. ЧТО БЫЛО СДЕЛАНО НЕПРАВИЛЬНО

Без оправданий.

1. **Школа была подана как «обучение ИИ». Это было неверно.** Вы сказали это первым, и вы правы.
   Школа платит Gemini за пересказ публичных учебников, кладёт пересказ в таблицы, которые
   читают только 4 файла самой школы, и не меняет ни одного веса модели. Это не обучение.

2. **Ошибка в отчёте по дате сбоя CI.** Я взял выборку из 5 прогонов и назвал 11 сентября.
   Вы потребовали весь период. Правильный ответ: последний зелёный 2026-09-02 10:50,
   первый красный 2026-09-09 17:02, всего 19 073 прогона.

3. **Неверно отнёс расход минут GitHub Actions.** Я обвинил 11 543 прогона цикла;
   `billable: {}` и `total_ms: 0` доказали, что они не выполнялись. Минуты сожгли ~7 500 реальных прогонов.

4. **Назвал CI блокером мержа.** `mergeable_state: "unstable"` — это не `"blocked"`.

5. **Назвал `SKIP_ALREADY_CLAIMED` дефектом.** Логи показали, что прогон H16 завершился нормально (11:00:51 → 11:08:34).

6. **Заявил о «ловушке run-row», теряющей платные ответы советников.** Неверно: `processCouncilTask` идёт по существующим строкам, новые советники просто не вызываются для старых задач.

7. **Сказал, что fpp3 «замер на 128/141».** Не замер — читатель идёт по книгам в порядке chunk-id.

8. **Сам внёс 8-й экземпляр того бага, который чинил:** добавил `islr2` с недоступным PDF,
   и он падал с Python-трейсбеком каждые 60 секунд, пока я не добавил `shouldRetryBookIngest`.

9. **Написал `ops/backfill-xauusd-m1.js` и ни разу его не проверил end-to-end.**
   Прокси песочницы отдаёт 403 на CONNECT к `datafeed.dukascopy.com`. Скрипт лежит непроверенным.

10. **Аргументировал деньгами там, где вы говорили образно.** Вы поправили, я это прекратил.

11. **Ни разу за всю предыдущую работу не открыл `xauusd_ai_final_h1_full_period.joblib`.**
    Полнопериодная модель на 1 545 615 примерах лежала в корне репозитория всё это время.
    Я чинил циклы школы вместо того, чтобы посмотреть, что уже обучено. Это самая дорогая
    ошибка в списке — она стоила недель работы не в ту сторону.

---

# 9. ЧТО НЕ ТРОГАТЬ

| Объект | Почему |
|---|---|
| `xauusd_ai_final_h1_full_period.joblib` | Единственный артефакт обучения на 23 годах. Воспроизвести нечем — исходных данных нет. **Не удалять, не перезаписывать.** |
| `trading_ai/history_manifest.json`, `history_quarantine.json`, `.sha256` | Единственное доказательство происхождения 6,1 млн строк. Без них данные, если найдутся, нечем верифицировать. |
| `purged_chronological_split` и оба assert'а на утечку | Единственная работающая защита от look-ahead. Любое ослабление обесценит все будущие метрики. |
| `dump_reload_verify` | Гарантирует, что в проде работает та же модель, что прошла валидацию. |
| Фильтр `55 ≤ future_delta_min ≤ 70` | Защита меток от выходных и дыр в данных. |
| `index.js:895` forward-only ingest | Пока не решено, как заливать историю, — не менять: любая правка может внести дубликаты или переписать живые свечи. |
| DEMO/fail-closed guards, REAL trading disabled | Прямое требование AGENTS.md. |
| `research_historical_news_v2_*` схема | CHECK-констрейнты и SHA256 — эталон качества данных в проекте. |
| `trading_ai/labels.py`, `economic_labels.py`, `walk_forward.py` | Мёртвый в рантайме, но это лучший код в проекте. Он понадобится. **Не удалять.** |
| Ветка `claude/ollama-local-advisor-r9jvfu` | Содержит 7 слитых исправлений надёжности. |

---

# 10. ЧТО НУЖНО ДЛЯ НАСТОЯЩЕГО ОБУЧЕНИЯ

**Ничего из перечисленного не установлено и не запущено. Это список, а не действие.**

## MUST HAVE (без этого обучения нет)

1. **Исторические данные M1.** Либо найти 25 zip-файлов HistData (SHA256 известны — проверка
   займёт минуту), либо разрешить бэкфилл через Dukascopy (`ops/backfill-xauusd-m1.js` написан).
   Без этого всё остальное бессмысленно.
2. **Место, куда эти данные положить.** `xauusd_candles` сейчас forward-only. Нужен либо
   отдельный путь загрузки с `source='histdata'`, либо отдельная таблица истории.
   Объём: 6,1 млн строк × ~100 байт ≈ 600 МБ + индексы. **Дисковую ёмкость Railway-Postgres нужно проверить — UNKNOWN.**
3. **Метки с издержками.** `economic_labels.py` уже написан. Подключить вместо
   `target_direction = sign(return)`.
4. **Финальный hold-out.** Отрезать последние N месяцев и никогда их не использовать в обучении.
5. **Единый гейт повышения.** Сейчас их два, слабый обходит сильный (ERROR 11).
6. **Бэктест с издержками.** Его в проекте нет вообще. Accuracy без PnL не решение.

## SHOULD HAVE

7. Walk-forward в рантайме (`trading_ai/walk_forward.py` уже есть, не вызывается).
8. Трёхклассовая метка BUY/WAIT/SELL с адаптивной мёртвой зоной (`trading_ai/labels.py` уже есть).
9. Embargo сверх purge.
10. Сохранение метрик каждого прогона в читаемом виде (сейчас JSONB в БД, наружу не выведены).
11. Рабочий советник Совета — хотя бы один (сейчас ноль).
12. Мониторинг дрейфа активной модели на форварде.

## LATER

13. Признаки из новостей / CFTC / макро (сейчас модель их не видит совсем).
14. Подключение знаний школы к признакам или к Совету (сейчас они никуда не идут).
15. Несколько горизонтов вместо одного 60-барного.
16. Binance-ветка (MOVE / LISTING / WHALE радары) — сейчас 2 файла-заготовки.
17. Калибровка вероятностей (Platt / isotonic) — сейчас берётся сырой `predict_proba`.

---

# 11. ФИНАЛЬНАЯ АРХИТЕКТУРА — НА БАЗЕ ТОГО, ЧТО ЕСТЬ

Ничего не выбрасывается. Помечено: **[ЕСТЬ]** / **[ЧАСТИЧНО]** / **[НЕТ]**.

```
┌─────────────────────────────────────────────────────────────────┐
│ USER (Telegram, русский язык)                          [ЕСТЬ]   │
│   index.js + node-telegram-bot-api, owner_only=true              │
└───────────────────────────┬─────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│ VIRUS AI CORE                                      [ЧАСТИЧНО]   │
│   virus-ai-chat-bootstrap.js — дверь владельца         [ЕСТЬ]   │
│   единый компактный контекст (462 симв.)               [ЕСТЬ]   │
│   единая память ядра                                    [НЕТ]   │
└───────────────────────────┬─────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│ ORCHESTRATOR                                       [ЧАСТИЧНО]   │
│   bootstrap-цепочка из 11 модулей                      [ЕСТЬ]   │
│   autonomy/roadmap-coordinator + предохранитель        [ЕСТЬ]   │
│   ai-council-gateway.js                        [ЕСТЬ, ВЫКЛЮЧЕН] │
│   настоящая маршрутизация задач по агентам               [НЕТ]  │
└───────────────────────────┬─────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│ SPECIALIZED AGENTS                                 [ЧАСТИЧНО]   │
│   gemini      [ЕСТЬ, 429]     deepseek  [ЕСТЬ, 402]             │
│   grok        [ЕСТЬ, 403]     chatgpt   [НЕ НАСТРОЕН]           │
│   local-qwen  [ЕСТЬ, TIMEOUT]                                   │
│   trading-school-reader.js — читает книги      [ЕСТЬ, ИЗОЛИРОВАН]│
│   news.js / cftc.js — сбор контекста                   [ЕСТЬ]   │
│   РАБОТАЮЩИХ СОВЕТНИКОВ СЕЙЧАС: 0                                │
└───────────────────────────┬─────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│ DATA LAYER                                         [ЧАСТИЧНО]   │
│   xauusd_candles M1 live, ~13.8k строк                 [ЕСТЬ]   │
│   6.1M строк истории (манифест есть, файлов нет)        [НЕТ]   │
│   history_manifest.json + quarantine + SHA256          [ЕСТЬ]   │
│   news 72 события 2003-2005                       [ЧАСТИЧНО]    │
│   CFTC (cftc.js подключён, объём неизвестен)      [ЧАСТИЧНО]    │
│   макро-ряды в БД                                       [НЕТ]   │
│   postgres_source.py — readonly-загрузчик              [ЕСТЬ]   │
│   ops/backfill-xauusd-m1.js               [ЕСТЬ, НЕ ЗАПУЩЕН]    │
└───────────────────────────┬─────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│ ML / TRAINING LAYER                                [ЧАСТИЧНО]   │
│   111 признаков M1/M5/M15/M30/H1                       [ЕСТЬ]   │
│   метка 60 баров, 2 класса, без издержек          [ЧАСТИЧНО]    │
│   purged split + двойной assert на утечку              [ЕСТЬ]   │
│   HistGB classifier + regressor                        [ЕСТЬ]   │
│   dump_reload_verify                                   [ЕСТЬ]   │
│   model_registry (BYTEA в Postgres)                    [ЕСТЬ]   │
│   walk-forward в рантайме                               [НЕТ]   │
│   test-набор / финальный hold-out                       [НЕТ]   │
│   бэктест с издержками                                  [НЕТ]   │
│   trading_ai/ (4308 стр., лучший код)      [ЕСТЬ, НЕ ПОДКЛЮЧЁН] │
└───────────────────────────┬─────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│ ANALYSIS / DECISION LAYER                          [ЧАСТИЧНО]   │
│   ai_predict_h1.py: 3 порога → BUY/SELL/WAIT           [ЕСТЬ]   │
│   порог сигнала 60/100 в index.js                      [ЕСТЬ]   │
│   graph-v6/v7, signal-ui-compact                       [ЕСТЬ]   │
│   зона входа / подтверждение / инвалидация        [ЧАСТИЧНО]    │
│   знания школы в решении                                [НЕТ]   │
└───────────────────────────┬─────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│ RISK MANAGER                                       [ЧАСТИЧНО]   │
│   режимы CAUTIOUS/MEDIUM/ACTIVE/AGGRESSIVE             [ЕСТЬ]   │
│   HIGH_IMPACT_NO_TRADE окно вокруг новостей            [ЕСТЬ]   │
│   контроль устаревания котировок (MAX_AGE_MS)          [ЕСТЬ]   │
│   отдельный сервис риск-менеджера                       [НЕТ]   │
│   лимит просадки / размер позиции от волатильности      [НЕТ]   │
└───────────────────────────┬─────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│ EXECUTION LAYER                                    [ЧАСТИЧНО]   │
│   demo_mt5_worker/ (Windows, trader_v9_hardened_v7)    [ЕСТЬ]   │
│   demo_worker_fence / ownership — защита от двойного   [ЕСТЬ]   │
│   ctrader-execution-demo (Railway)                [НЕ ПРОВЕРЕН] │
│   binance_xau/ (2 файла-заготовки)                      [НЕТ]   │
└───────────────────────────┬─────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│ MT5 DEMO [ЧАСТИЧНО]          │  Binance DEMO [НЕТ]              │
│ REAL TRADING DISABLED — по AGENTS.md, не ослаблять              │
└─────────────────────────────────────────────────────────────────┘
```

**Что в этой схеме надо достроить в первую очередь (по критичности):**
1. DATA LAYER — историю (без неё ML-слой не имеет смысла).
2. ML LAYER — метки с издержками, hold-out, бэктест.
3. ORCHESTRATOR — хотя бы один живой советник.
4. Подключить `trading_ai/` вместо того, чтобы держать его в CI.

---

# 12. ПЛАН ОБУЧЕНИЯ ТОРГОВОГО AI — 15 ЭТАПОВ

Не исполнять без вашей команды. Для каждого этапа указан критерий готовности.

| # | Этап | Критерий завершения |
|---|---|---|
| **1** | **Найти историю M1** | 25 zip-файлов найдены, SHA256 каждого совпал с `history_manifest.json`. ИЛИ принято решение о бэкфилле через Dukascopy. Критерий: `total_rows = 6 099 893` подтверждены. |
| **2** | **Решить, где хранить** | Замерена свободная ёмкость Railway-Postgres. Выбрано: отдельная таблица истории или `source='histdata'` в `xauusd_candles`. Критерий: план вмещается с запасом ×2. |
| **3** | **Загрузить историю** | Строки в БД. Критерий: `SELECT COUNT(*) FROM <table> WHERE timeframe='M1'` = ожидаемое; `MIN/MAX(candle_time)` совпадают с манифестом; 332 карантинных таймстампа отсутствуют. |
| **4** | **Аудит качества загруженного** | Критерий: 0 дубликатов по `(timeframe, candle_time)`; 0 строк с `high < low`; 0 цен ≤ 0; распределение разрывов объяснено выходными. |
| **5** | **Закрыть вопрос 2003–2009** | Модель обучена с 2003-05-05, манифест — с 2009-03-15. Критерий: источник данных 2003–2009 найден и задокументирован, ИЛИ период обучения официально сокращён до 2009+. |
| **6** | **Зафиксировать финальный hold-out** | Последние N месяцев отрезаны и записаны в конфиг как запретные. Критерий: тест падает, если обучающая выборка задевает hold-out. |
| **7** | **Перевести метки на cost-aware** | Подключить `economic_labels.py`. Критерий: метка учитывает BID/ASK, спред и комиссию; доля WAIT осмысленна (не 0 % и не 99 %). |
| **8** | **Единый гейт повышения** | `weekend-upgrade.js` и `training-current-data-lab-v2.js` используют один набор правил. Критерий: тест доказывает, что модель на 11 днях повышена быть не может. |
| **9** | **Базовый прогон обучения на полной истории** | Обучение на всех данных, кроме hold-out. Критерий: прогон завершается, метрики сохранены, `dump_reload_verify` зелёный. |
| **10** | **Настоящий walk-forward** | Подключить `trading_ai/walk_forward.py` в рантайм. Критерий: ≥ 6 фолдов, у каждого свои метрики, embargo соблюдён, отчёт сохранён. |
| **11** | **Бэктест с издержками** | Впервые в проекте. Критерий: получены net-PnL, max drawdown, Sharpe, число сделок, средняя сделка в bps — с вычтенным спредом и комиссией. |
| **12** | **Оценка на финальном hold-out — ОДИН РАЗ** | Критерий: модель прогоняется по hold-out ровно один раз, результат записан и неизменен. Если плохо — возврат к этапу 7, а не подгонка под hold-out. |
| **13** | **Forward / Shadow на живых данных** | Таблицы `*_shadow_*` уже есть. Критерий: ≥ 1 месяц предсказаний без сделок, расхождение между shadow и бэктестом объяснено. |
| **14** | **DEMO-торговля** | MT5 DEMO через `demo_mt5_worker`. Критерий: ≥ 100 сделок, реальное проскальзывание измерено и сопоставлено с допущением бэктеста. |
| **15** | **Champion promotion** | Только после 13 и 14. Критерий: net-PnL положителен на hold-out И на shadow И на DEMO. Три независимых подтверждения, иначе не повышать. |

**Критическое правило плана:** этапы 11, 12, 14 дают право говорить о прибыльности.
До них никакая accuracy не является доказательством. Сейчас проект находится **между 1 и 2**.

---

# 13. КАРТА ХРАНЕНИЯ

| Место | Что лежит | Проверено |
|---|---|---|
| **GitHub** `diyr1997/xauusd-ai-signal-bot` | Весь код: 248 файлов `.js`+`.py` (62 `.js` в корне), 44 теста, 29 workflow, 26 корневых `.md`, каталоги `ai_global_trader/`, `autonomy/`, `binance_xau/`, `db/`, `demo_mt5_worker/`, `docs/`, `ops/`, `research/`, `tests/`, `tools/`, `trading_ai/`, `trading_school/` | **VERIFIED** (`find`, `ls`, `wc`) |
| **GitHub — бинарь** | `xauusd_ai_final_h1_full_period.joblib`, 981 845 байт, добавлен коммитом `a267b83` | **VERIFIED** (`ls -la`, `git log`) |
| **GitHub — манифесты** | `trading_ai/history_manifest.json` (25 файлов, SHA256), `history_quarantine.json`, `history_quarantine.sha256` | **VERIFIED** |
| **Railway Postgres** `e3838235…` | 38 таблиц (раздел 3.1). Живые M1 ~13.8k строк, `model_registry.model_bytes` с активной моделью, школьные таблицы, Совет, DEMO | **ЧАСТИЧНО VERIFIED** — схема из кода, объёмы из логов; прямого SQL-доступа не было |
| **Railway — сервисы** | 17 сервисов в `virus-ai-clean-20260912` | **VERIFIED** (`list-services`, `environment-status`) |
| **Railway — другие проекты** | `virus-ai-core-llm`, `virus-ai-3d-office-web`, `virus-ai-agent-toolbox-20260910`, `virus-ai-v9-pr198-ci-20260909`, `radiant-energy` | **NOT VERIFIED** сегодня |
| **Railway volumes** | **UNKNOWN** — не проверялись. Нужен `list-volumes` по каждому сервису |
| **Cloud / Google Drive** | `tools/ai_toolbox/drive_candidates.json` — **19 кандидатов**. Что реально лежит на Drive — **UNKNOWN**, доступ не проверялся |
| **Локально (ПК владельца)** | 17 книг в `WAITING_USER_COPY`; предположительно 25 zip HistData; Windows-воркер `demo_mt5_worker` | **UNKNOWN** — агент не имеет доступа |
| **Контейнер сессии** | Клон репо. **sklearn НЕ установлен**, `.venv` отсутствует. Данных M1 нет | **VERIFIED** |
| **Временные файлы** | `/tmp/xauusd_ai_h1_active.joblib` (активная модель), `/tmp/current_data_candles_*.json`, `/tmp/*_candidate_*.joblib` — эфемерны, теряются при перезапуске | **VERIFIED** (код) |

**Главный вывод карты:** единственное надёжное хранилище — GitHub и Railway-Postgres.
**Исторические данные не хранятся нигде из проверяемых мест.**

---

# 14. API

## ACTIVE — работает прямо сейчас

| API | Где | Доказательство |
|---|---|---|
| **Telegram Bot API** | `TELEGRAM_BOT_TOKEN`, polling | сообщения доставляются, **VERIFIED** |
| **PostgreSQL** | `DATABASE_URL` | лог `M1 PostgreSQL: 7000` каждую минуту, **VERIFIED** |
| **Railway GraphQL** | внутренний | опрошен в этой сессии, **VERIFIED** |
| **Поток котировок M1** | MT5/cTrader → `xauusd_candles` | последняя свеча возрастом 32 с, **VERIFIED** |

## CONFIGURED — ключ есть, но сейчас не работает

| API | Переменная | Состояние |
|---|---|---|
| **Gemini** | `GEMINI_API_KEY`, `GEMINI_MODEL`, `GEMINI_NEWS_MODEL` | **429 RESOURCE_EXHAUSTED** — квота исчерпана |
| **DeepSeek** | `DEEPSEEK_API_KEY`, `DEEPSEEK_MODEL` | **402 Insufficient Balance** |
| **xAI / Grok** | `XAI_API_KEY`, `XAI_MODEL` | **403 permission-denied** |
| **Ollama (локальный)** | `OLLAMA_TIMEOUT_MS`, `OLLAMA_MAX_OUTPUT_TOKENS`, `LOCAL_ADVISOR_ENABLED` | **TIMEOUT 120 с**; `qwen2.5:3b` скачан |
| **cTrader** | `CTRADER_CLIENT_ID`, `CTRADER_CLIENT_SECRET` | 5 сервисов развёрнуто, работоспособность **NOT VERIFIED** |
| **Twelve Data** | `TWELVE_DATA_API_KEY` | ключ есть, использование **NOT VERIFIED** |
| **GitHub** | `GITHUB_REVIEW_TOKEN`, `GITHUB_COUNCIL_*` | транспорт Совета через ветку очереди |
| **MT5 Bridge** | `MT5_BRIDGE_SECRET` | мост к Windows-воркеру |
| **Claude Routine** | `CLAUDE_ROUTINE_TOKEN`, `CLAUDE_ROUTINE_URL`, `CLAUDE_ROUTINE_AUTOFIRE_ENABLED` | автозапуск задач |
| **Backup export** | `BACKUP_EXPORT_TOKEN` | `ops/railway_backup_export_server.py` |

## AVAILABLE BUT NOT CONFIGURED

| API | Что нужно | Зачем |
|---|---|---|
| **OpenAI / ChatGPT** | `OPENAI_API_KEY` **отсутствует** — **VERIFIED** | один из трёх канонических советников по `SHARED_COUNCIL_TOOLS.json` |
| **Perplexity** | пакет `@perplexity-ai/perplexity_ai@0.38.5` в зависимостях, переменной ключа нет | поиск/ресёрч |
| **Dukascopy** | `dukascopy-node@^1.45.0` установлен, `ops/backfill-xauusd-m1.js` написан | **единственный автоматический путь получить историю M1** |
| **Binance** | ключей нет | крипто-ветка, `ai_global_trader_binance_*` таблицы уже созданы |

## NOT NEEDED NOW

Google Cloud (нет footprint'а — по `AI_AGENT_TOOLBOX_STATUS.md`); Supabase (есть Postgres);
Notion / Gmail / Drive как рантайм-зависимости (Drive — только как возможный склад данных).

## UNKNOWN

| Вопрос | Как проверить |
|---|---|
| Значения всех переменных | Railway отдаёт OAuth-клиенту только имена. Нужен доступ владельца к консоли |
| Работают ли 5 `ctrader-*` сервисов | `get-logs` по каждому |
| Что в `virus-ai-intelligence` | `describe-service` + логи |
| Лимиты и тарифы Gemini/DeepSeek/xAI | консоли провайдеров |
| Содержимое Google Drive | доступ к Drive |

---

# 15. ИТОГОВАЯ ТАБЛИЦА

| COMPONENT | STATUS | VERIFIED? | LOCATION | NEXT ACTION |
|---|---|---|---|---|
| Telegram-бот | WORKING | ДА | `index.js`, Railway `f8710e22` | ничего |
| Поток M1 live | WORKING | ДА | `xauusd_candles` | ничего |
| PostgreSQL | WORKING | ДА | Railway `e3838235` | замерить размеры таблиц через SQL |
| Модель full-period (111 призн.) | EXISTS, NOT ACTIVE | ДА | `xauusd_ai_final_h1_full_period.joblib` | **не трогать**; решить, возвращать ли в чемпионы |
| Активная модель H1 | WORKING, ДАННЫХ МАЛО | ДА | `model_registry`, `school-v1-h1-daily-t00-20260917T210606Z` | получить её `metrics` из БД |
| Инференс `ai_predict_h1.py` | WORKING | ДА | корень | ничего |
| Purged split + anti-leak | WORKING | ДА | `weekend_train_h1_safe.py` | **не ослаблять** |
| `dump_reload_verify` | WORKING | ДА | `weekend_train_h1_safe.py` | **не трогать** |
| Гейт повышения | **BROKEN** (два конфликтующих) | ДА | `weekend-upgrade.js:218` vs `…lab-v2.js:217` | объединить — **после вашей команды** |
| История M1 6.1M строк | **MISSING** | ДА (отсутствие) | манифест есть, файлов нет | **найти или бэкфилл** |
| Манифест истории | EXISTS | ДА | `trading_ai/history_manifest.json` | **не трогать** |
| `ops/backfill-xauusd-m1.js` | WRITTEN, UNTESTED | ДА | `ops/` | e2e-проверка при разрешении |
| Метки (2 класса, без издержек) | WORKS, WRONG DESIGN | ДА | `weekend_train_h1.py:59-73` | заменить на `economic_labels.py` |
| `trading_ai/` (4308 стр.) | **DEAD IN RUNTIME** | ДА | `trading_ai/` | подключить walk_forward + labels |
| Walk-forward | NOT IN RUNTIME | ДА | `trading_ai/walk_forward.py` | подключить (этап 10) |
| Test-набор / hold-out | **DOES NOT EXIST** | ДА | — | создать (этап 6) |
| Бэктест с издержками | **DOES NOT EXIST** | ДА | — | создать (этап 11) |
| Совет (5 советников) | **0 РАБОТАЮТ** | ДА | `ai-providers.js` | квота Gemini / баланс DeepSeek / ключ Grok / `OPENAI_API_KEY` |
| Gemini | **429 QUOTA** | ДА | лог 10:40:37Z | биллинг |
| DeepSeek | 402 | ДА | диагностика Совета | пополнить |
| Grok | 403 | ДА | диагностика Совета | активировать ключ |
| ChatGPT | NOT CONFIGURED | ДА | переменных нет | добавить `OPENAI_API_KEY` |
| Ollama qwen2.5:3b | TIMEOUT | ДА | сервис `7e620a9a` | поднять таймаут / модель меньше |
| Школа книг | RUNNING, ИЗОЛИРОВАНА | ДА | `trading-school-*.js` ×4 | **решить: подключить или выключить** |
| `trading_school_book_memory` | НИКТО НЕ ЧИТАЕТ | ДА | Postgres | то же решение |
| Новости (72 события) | EXISTS, TINY | ДА | `research_historical_news_v2_*` | в модель не входят |
| CFTC | CONNECTED | ДА | `cftc.js`, `index.js:35` | объём замерить SQL |
| Макро-ряды | **НЕТ В БД** | ДА | — | позже |
| `ai-global-trader` | **CRASHED** | ДА | Railway `ad17d34e` | redeploy ради логов |
| `demo_mt5_worker` | CODE EXISTS | ДА (код) | `demo_mt5_worker/` | **NOT VERIFIED**, запущен ли |
| `binance_xau` | STUB (2 файла) | ДА | `binance_xau/` | позже |
| SkillSpector / Graphify | ACTIVE по ledger | НЕТ (сегодня) | внешние | перепроверить при необходимости |
| Остальные 22 инструмента реестра | НЕ РАБОТАЮТ В ПРОЕКТЕ | ДА | `SHARED_COUNCIL_TOOLS.json` | не ставить новые |
| 29 CI workflow | EXIST | ДА | `.github/workflows/` | бюджет Actions исчерпан — **NOT VERIFIED** сегодня |

## A. ЧТО РАБОТАЕТ

Telegram-бот; приём живых M1 (возраст 32 с); PostgreSQL; инференс модели H1;
защита от временной утечки (purge + двойной assert + фильтр разрывов);
`dump_reload_verify`; реестр моделей и подмена активной модели на лету;
режимы риска; окно запрета торговли вокруг новостей; школа продолжает читать
(`zerodha_ta`, `nist`); 29 CI-workflow; `research_historical_news_v2_*` схема
с SHA256-проверками; 7 слитых исправлений надёжности.

## B. ЧТО СЛОМАНО

1. Ноль работающих советников Совета (Gemini 429, DeepSeek 402, Grok 403, ChatGPT не настроен, Ollama timeout).
2. Сервис `ai-global-trader` упал 2026-09-12.
3. Два конфликтующих гейта повышения — слабый обошёл сильный, в проде модель на 11 днях.
4. 6,1 млн строк истории физически отсутствуют.
5. Школа читает книги в таблицы, которые никто не открывает.
6. `trading_ai/` (лучший код проекта, 4308 строк) не подключён к рантайму.
7. Нет test-набора, нет финального hold-out, нет бэктеста с издержками.
8. Издержки не учитываются нигде: порог входа ≈ 2.2 bps при спреде по золоту 15–30 bps.
9. Школьные книги: 17 источников ждут копий, 2 в ошибке, у 2 прочитанных 0 понятых чанков.

## C. ЧТО НЕИЗВЕСТНО

- Где физически лежат 25 zip-файлов HistData (6 099 893 строки).
- Откуда взялись данные 2003–2009 (модель обучена с 2003-05-05, манифест с 2009-03-15).
- Реальные метрики активной модели и модели full-period (лежат в `metrics JSONB`, SQL-доступа нет).
- Где код и результаты «V5 rolling walk-forward 2020-2026».
- Причина краха `ai-global-trader` (логи не сохранились).
- Свободная ёмкость Railway-Postgres и наличие volumes.
- Что лежит на Google Drive (19 кандидатов в `drive_candidates.json`).
- Запущен ли `demo_mt5_worker` на машине владельца.
- Текущее состояние бюджета GitHub Actions.
- Фактическое наполнение таблиц CFTC, DEMO, shadow.

## D. ЧТО НЕ МЕНЯТЬ

`xauusd_ai_final_h1_full_period.joblib`; `history_manifest.json` / `history_quarantine.*`;
`purged_chronological_split` и оба assert'а; `dump_reload_verify`;
фильтр `55 ≤ future_delta_min ≤ 70`; forward-only ingest в `index.js:895`
(пока не решён вопрос загрузки истории); DEMO/fail-closed guards и REAL trading disabled;
схему `research_historical_news_v2_*`; `trading_ai/labels.py`, `economic_labels.py`,
`walk_forward.py`; ветку `claude/ollama-local-advisor-r9jvfu`.

## E. ЧТО ПРОВЕРИТЬ СЛЕДУЮЩИМ

Только чтение, ничего не меняя:

1. `SELECT source, COUNT(*), MIN(candle_time), MAX(candle_time) FROM xauusd_candles WHERE timeframe='M1' GROUP BY source;` — точный объём и происхождение данных.
2. `SELECT version, created_at, active, source, metrics FROM model_registry WHERE model_key='H1' ORDER BY created_at DESC LIMIT 20;` — **реальные метрики всех моделей**.
3. `SELECT run_key, kind, status, tier, source_rows, trading_days, metrics FROM training_current_data_runs ORDER BY finished_at DESC LIMIT 30;` — история обучений.
4. `SELECT pg_size_pretty(pg_total_relation_size(c.oid)), c.relname FROM pg_class c ORDER BY pg_total_relation_size(c.oid) DESC LIMIT 20;` — размеры таблиц и запас места.
5. Найти 25 zip-файлов HistData; сверить SHA256 с манифестом.
6. Railway: `list-volumes` по каждому из 17 сервисов.
7. Redeploy `ai-global-trader` ради свежих логов краха.
8. Логи 5 `ctrader-*` сервисов и `virus-ai-intelligence`.
9. Проверить, действительно ли 0 понятых чанков — следствие квоты Gemini.
10. Состояние бюджета GitHub Actions.

## F. ЧТО ДЕЛАТЬ ПЕРВЫМ — ПОСЛЕ ВАШЕГО ПОДТВЕРЖДЕНИЯ

В этом порядке. Ни один пункт не начат.

1. **Найти историю M1.** Всё остальное от этого зависит. Либо файлы найдутся и
   сверятся по SHA256, либо запускаем `ops/backfill-xauusd-m1.js`.
2. **Достать реальные метрики из БД** (запросы 1–3 выше). Пока мы не видели ни одной
   цифры accuracy, любые суждения о качестве моделей — догадки.
3. **Решить судьбу школы:** подключить её знания к Совету/признакам — или выключить,
   чтобы не тратить квоту Gemini впустую.
4. **Починить одного советника** — дешевле всего добавить `OPENAI_API_KEY` или пополнить DeepSeek.
5. **Объединить гейты повышения**, чтобы модель на 11 днях больше не могла стать чемпионом.

---

## Оговорки аудита

- Прямого SQL-доступа к продакшн-Postgres не было. Все объёмы строк — из логов сервиса,
  а не из `COUNT(*)`. Там, где замер был сделан в прошлой сессии, это указано явно.
- Метаданные модели извлечены **без исполнения pickle** (zlib-распаковка + чтение строк),
  поэтому численные значения весов не проверялись — только структура, гиперпараметры,
  имена признаков и блок metadata.
- 10 из 17 сервисов Railway не опрашивались индивидуально; по ним есть только сводка
  `servicesWithIssues: 1`.
- Файлы `.md` вне корня (`docs/`, `research/`, `trading_school/`, `tools/`) прочитаны
  выборочно; полный разбор их содержимого не входил в объём.
- Логика зоны входа / TP / SL внутри `index.js` не аудировалась.

Аудит завершён. Исправления не начаты и не будут начаты без вашего указания.
