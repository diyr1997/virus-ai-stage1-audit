"use strict";

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { getHistoricalRates } = require("dukascopy-node");

const MANIFEST = path.join(__dirname, "preflight_2025_manifest.json");
const OUT_DIR = path.join(__dirname, "output", "historical_news_v2");
const HORIZONS = [1, 5, 15, 30, 60];

function stable(value) {
  if (Array.isArray(value)) return value.map(stable);
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.keys(value).sort().map((k) => [k, stable(value[k])]));
  }
  return value;
}
function stableJson(value) { return JSON.stringify(stable(value)); }
function sha256(value) { return crypto.createHash("sha256").update(stableJson(value)).digest("hex"); }
function assert(cond, message) { if (!cond) throw new Error(message); }

function easternParts(date) {
  const fmt = new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/New_York", year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23"
  });
  const p = Object.fromEntries(fmt.formatToParts(date).filter(x => x.type !== "literal").map(x => [x.type, x.value]));
  return `${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}:${p.second}`;
}

function validateManifest(manifest) {
  assert(manifest.research_only === true, "manifest must be research_only");
  assert(Array.isArray(manifest.events) && manifest.events.length === 10, "preflight must contain exactly 10 events");
  const allowed = new Set(["CPI", "EMPLOYMENT_SITUATION", "FOMC", "PCE"]);
  const ids = new Set();
  let tier12 = 0, est = 0, edt = 0;
  for (const e of manifest.events) {
    assert(!ids.has(e.id), `duplicate event id ${e.id}`); ids.add(e.id);
    assert(allowed.has(e.family), `scope violation ${e.family}`);
    const event = new Date(e.event_time_utc), pub = new Date(e.forecast_source_published_at_utc);
    assert(Number.isFinite(event.getTime()) && Number.isFinite(pub.getTime()), `bad timestamp ${e.id}`);
    assert(pub.getTime() < event.getTime(), `forecast source is not pre-release: ${e.id}`);
    assert(e.forecast !== null && e.actual !== null && e.previous !== null, `missing point-in-time fields ${e.id}`);
    assert(/^https:\/\//.test(e.forecast_source) && /^https:\/\//.test(e.official_source), `missing provenance URL ${e.id}`);
    assert(easternParts(event) === e.us_eastern_local, `America/New_York mismatch ${e.id}: got ${easternParts(event)}`);
    if (e.expected_utc_offset_minutes === -300) est++;
    if (e.expected_utc_offset_minutes === -240) edt++;
    if (e.forecast_tier <= 2) tier12++;
  }
  assert(tier12 >= 8, `need >=8 TIER1/2 forecasts; got ${tier12}`);
  assert(est > 0 && edt > 0, "preflight must cover both EST and EDT");
  return { event_count: manifest.events.length, tier12, est, edt };
}

async function fetchWindow(eventUtc) {
  const center = new Date(eventUtc);
  const from = new Date(center.getTime() - 5 * 60_000);
  const to = new Date(center.getTime() + 66 * 60_000);
  const rows = await getHistoricalRates({
    instrument: "xauusd", dates: { from, to }, timeframe: "m1", format: "json", priceType: "bid",
    batchSize: 1, pauseBetweenBatchesMs: 1200, retryCount: 5, pauseBetweenRetriesMs: 5000,
    retryOnEmpty: true, failAfterRetryCount: false,
  });
  return (Array.isArray(rows) ? rows : []).map(r => ({
    timestamp: Number(r.timestamp), open: Number(r.open), high: Number(r.high), low: Number(r.low), close: Number(r.close)
  })).filter(r => Number.isFinite(r.timestamp)).sort((a,b) => a.timestamp-b.timestamp);
}

function exactMinute(rows, t) { return rows.find(r => r.timestamp === t) || null; }
function analyze(event, rows) {
  const t0 = new Date(event.event_time_utc).getTime();
  const base = exactMinute(rows, t0);
  assert(base, `M1_GAP: missing exact event candle ${event.id}`);
  const reactions = {};
  for (const h of HORIZONS) {
    const target = exactMinute(rows, t0 + h * 60_000);
    assert(target, `M1_GAP: missing +${h} exact candle ${event.id}`);
    const pathRows = rows.filter(r => r.timestamp >= t0 && r.timestamp <= t0 + h * 60_000);
    assert(pathRows.length > 0, `M1_GAP: empty path ${event.id} +${h}`);
    const baseline = base.open;
    const change = target.close - baseline;
    const high = Math.max(...pathRows.map(r => r.high));
    const low = Math.min(...pathRows.map(r => r.low));
    reactions[`m${h}`] = {
      close: target.close,
      delta: Number(change.toFixed(6)),
      delta_bps: Number(((change / baseline) * 10000).toFixed(6)),
      mfe: Number((high - baseline).toFixed(6)),
      mae: Number((low - baseline).toFixed(6)),
    };
  }
  const d1 = reactions.m1.delta, d60 = reactions.m60.delta;
  return {
    id: event.id, family: event.family, metric: event.metric, event_time_utc: event.event_time_utc,
    forecast: event.forecast, previous: event.previous, actual: event.actual,
    forecast_tier: event.forecast_tier, forecast_source: event.forecast_source, official_source: event.official_source,
    baseline_open: base.open, reactions,
    reversal_1_to_60: d1 !== 0 && d60 !== 0 && Math.sign(d1) !== Math.sign(d60),
    m1_rows: rows.length,
  };
}

async function runOnce(manifest) {
  const results = [];
  for (const event of [...manifest.events].sort((a,b) => a.event_time_utc.localeCompare(b.event_time_utc))) {
    const rows = await fetchWindow(event.event_time_utc);
    assert(rows.length > 0, `RETRY_EXHAUSTED_OR_SOURCE_EMPTY ${event.id}`);
    results.push(analyze(event, rows));
  }
  return results;
}

async function main() {
  const manifest = JSON.parse(fs.readFileSync(MANIFEST, "utf8"));
  const validation = validateManifest(manifest);
  const results = await runOnce(manifest);
  const payload = {
    schema_version: 1,
    research_only: true,
    instrument: "XAUUSD",
    price_source: "Dukascopy xauusd M1 BID",
    baseline: "event-minute OPEN; no interpolation",
    horizons_minutes: HORIZONS,
    validation,
    manifest_sha256: sha256(manifest),
    results,
  };
  payload.result_sha256 = sha256(payload);
  fs.mkdirSync(OUT_DIR, { recursive: true });
  fs.writeFileSync(path.join(OUT_DIR, "preflight_2025.json"), JSON.stringify(payload, null, 2) + "\n");
  console.log(JSON.stringify({ validation, manifest_sha256: payload.manifest_sha256, result_sha256: payload.result_sha256, events: results.length }, null, 2));
}

main().catch(err => { console.error(err?.stack || err); process.exit(1); });
