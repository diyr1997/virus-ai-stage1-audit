# Global Gold Intelligence V3 — filtered master

Status: SHADOW / RESEARCH. This source universe consolidates the 2026-08-22 advisor research and independent verification. Production activation is forbidden until source transport, parser, historical replay and shadow gates pass.

## Canonical source policy
- One organization = one canonical source id, even if several pages/endpoints exist.
- Multiple endpoints (news/data/RSS/API/archive) belong to the same canonical source.
- PRIMARY official source wins over SECONDARY confirmations.
- Reuters/AP/Bloomberg/WGC may confirm or enrich, but never duplicate official impact.
- Final source strength is learned from historical replay, not reputation alone.
- Every source below must receive an explicit historical-audit state: REPLAYED, KEEP_SHADOW, NO_ARCHIVE, NO_EXACT_TIMESTAMP, TRANSPORT_UNAVAILABLE, or REJECT. No source is silently dropped.

## Deduplicated source universe

### United States / New York / Washington
Fed/FOMC; New York Fed; BLS; BEA; U.S. Treasury/FiscalData; OFAC; CFTC; CME/COMEX; U.S. Census; White House; USTR; FRED/St. Louis Fed; USGS gold/mineral statistics; EIA for oil-inflation transmission.

### Canada / Mexico
Bank of Canada; Statistics Canada; Finance Canada; CBSA where trade detail is useful; Banco de Mexico; INEGI; Mexico customs/tax trade source where replay shows value.

### Eurozone / UK / Switzerland
ECB; Eurostat; Bank of England; ONS; HMRC/UK Trade Info; LBMA; Swiss National Bank; Swiss Customs/BAZG; Swiss FSO; Bundesbank; Destatis; Banque de France; INSEE; Banca d'Italia; ISTAT; De Nederlandsche Bank; CBS Netherlands; Banco de Espana; INE Spain; National Bank of Poland; Statistics Poland; Czech National Bank; Hungarian National Bank; National Bank of Serbia.

### China / Hong Kong / Taiwan
PBOC; SAFE; Shanghai Gold Exchange; NBS China; GACC Customs; MOFCOM; Ministry of Finance China; State Council; China MFA; NDRC; HKMA; HKEX; Hong Kong Census & Statistics; Chinese Gold & Silver Exchange Society; Taiwan central bank; Taiwan Ministry of Finance; Taiwan Customs; TWSE.

### Japan / Korea
BOJ; Japan Ministry of Finance; METI; JPX/TOCOM/OSE; Bank of Korea; Statistics Korea; Korea Customs; KRX.

### South-East Asia
MAS; SGX; SingStat; Singapore Customs; Bank of Thailand; Thai Customs; Bank Indonesia; Statistics Indonesia; ICDX; Bank Negara Malaysia; Malaysia official statistics/customs where source-level replay adds unique value.

### India
RBI; India Ministry of Finance; Ministry of Commerce; CBIC/Customs; DGFT; MCX.

### Turkey / Russia / Eurasia
TCMB/EVDS; TurkStat; Borsa Istanbul; Bank of Russia; Russia Ministry of Finance; Rosstat; MOEX; Russia Customs where accessible; National Bank of Kazakhstan; Kazakhstan official statistics; Central Bank of Uzbekistan.

### Middle East / gold corridors
UAE Central Bank; DMCC; DGCX; Dubai Customs; Saudi Central Bank; Saudi official statistics; Saudi Ministry of Energy; Qatar Central Bank; Bank of Israel; Israel CBS; TASE; Iran central bank/customs where stable and official; OPEC.

### Africa / supply and official gold flows
SARB; Statistics South Africa; South Africa mining ministry; Bank of Ghana; Ghana Statistical Service; Ghana Minerals Commission; Ghana Gold Board (GoldBod); BCEAO; Mali mining authority; Bank of Tanzania; Tanzania NBS/mining ministry; Reserve Bank of Zimbabwe; ZimStat; Zimbabwe mining ministry. Lower-priority producer countries remain candidates until automation and replay justify them.

### Latin America
Banco Central do Brasil; IBGE; Brazil trade source/Siscomex; B3; Peru central bank; INEI Peru; Peru mining ministry; SUNAT; Chile central bank; INE Chile; Cochilco; Argentina central bank; INDEC.

### Australia
RBA; Australian Bureau of Statistics; Perth Mint; ASX; official mining/export statistics.

### Global institutions / reference layers
IMF; BIS; World Bank; OECD; WTO; UN Comtrade; LBMA; World Gold Council (SECONDARY/reference); EIA; OPEC; IEA; EU sanctions sources; UN Security Council.

## Financial hubs tracked separately from countries
New York/COMEX; London/LBMA; Zurich/Swiss refining; Shanghai/SGE; Hong Kong; Singapore; Dubai; Mumbai; Istanbul; Tokyo; plus Ghana→Dubai/India physical corridor as a supply-flow relationship.

## Historical replay cadence policy
Not every source is an M1 news source. Historical testing must match the source cadence:
- exact-timestamp central-bank/statistics releases: M1 reaction and lag profile;
- futures/positioning/open-interest/reserve/flow series: intraday/daily/weekly as published;
- monthly trade/reserve/physical-flow data: matching release and daily/weekly reaction;
- annual supply/mining structural data: slow-regime features only, never M1 causal labels;
- secondary newswires: timestamp/content corroboration and lead/lag diagnostics, never a duplicate canonical event.

## Market-source separation
Dukascopy XAUUSD spot, OctaFX spot, CME/COMEX gold futures, LBMA benchmarks, SGE, MCX, DGCX, JPX/TOCOM and other regional gold markets are independent evidence layers. Their OHLC values must never be automatically merged or substituted for each other. Agreement can increase confidence; disagreement is stored as evidence.

## Source lifecycle
CANDIDATE -> VERIFIED_TRANSPORT -> VERIFIED_PARSER -> REPLAYED -> PROMOTE | KEEP_SHADOW | REJECT

No source may skip REPLAYED before affecting XAU impact scoring unless it is only a confirmation/transport layer for an already canonical official event.
