"use strict";

const fs = require("fs");
const path = require("path");
const { getHistoricalRates } = require("dukascopy-node");
const { loadAndValidate, EXPECTED_DATASET } = require("./import_historical_news_v2_phase1");

const HORIZONS = [1, 5, 15, 30, 60];
const LAG_OFFSETS = [0, 1, 2, 3, 5, 10, 15, 30, 60];
const DEFAULT_THRESHOLD_USD = 0.10;
const EXPECTED_FULL_DAY_MINUTES = 1440;
const EARLIEST_USABLE_M1_UTC = "2003-05-05T00:00:00.000Z";
const EARLIEST_USABLE_M1_MS = Date.parse(EARLIEST_USABLE_M1_UTC);
const MINUTE = 60000;
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function validCandle(r) {
  if (!r) return false;
  const o = Number(r.open), h = Number(r.high), l = Number(r.low), c = Number(r.close);
  return [o,h,l,c].every(Number.isFinite) && h >= l && h >= o && h >= c && l <= o && l <= c;
}
function normalizeRows(rows) {
  return (Array.isArray(rows) ? rows : []).map((r) => ({ timestamp:Number(r.timestamp), open:Number(r.open), high:Number(r.high), low:Number(r.low), close:Number(r.close) })).filter((r) => Number.isFinite(r.timestamp)).sort((a,b) => a.timestamp-b.timestamp);
}
function sourceDiagnostics(rows) {
  const normalized = normalizeRows(rows);
  return {source_rows: normalized.length,source_coverage_ratio_vs_1440:Number((normalized.length/EXPECTED_FULL_DAY_MINUTES).toFixed(6)),source_first_timestamp_utc:normalized.length?new Date(normalized[0].timestamp).toISOString():null,source_last_timestamp_utc:normalized.length?new Date(normalized[normalized.length-1].timestamp).toISOString():null};
}
function canonicalEvent(event) {
  if (!String(event?.family || "").trim()) throw new Error("EVENT_FAMILY_REQUIRED");
  if (!String(event?.event_type || "").trim()) throw new Error("EVENT_TYPE_REQUIRED");
  if (!String(event?.official_source || "").trim()) throw new Error("OFFICIAL_SOURCE_REQUIRED");
  if (!String(event?.event_time_utc || "").trim()) throw new Error("EVENT_TIME_REQUIRED");
  return event;
}
function eventIdentity(event, eventMs = Date.parse(event?.event_time_utc)) {
  canonicalEvent(event);
  const iso=Number.isFinite(eventMs)?new Date(eventMs).toISOString():String(event.event_time_utc||"")||null;
  const d=Number.isFinite(eventMs)?new Date(eventMs):null;
  const releaseYear=Number(event.release_year||event.year||(d?d.getUTCFullYear():NaN));
  const releaseMonth=Number(event.release_month||(d?d.getUTCMonth()+1:NaN));
  return {ordinal:event.ordinal,family:event.family,event_type:event.event_type,release_year:Number.isFinite(releaseYear)?releaseYear:null,release_month:Number.isFinite(releaseMonth)?releaseMonth:null,release_datetime:iso,event_time_utc:iso,official_source:event.official_source};
}
function isPreBoundaryEvent(event) { const ms=Date.parse(event?.event_time_utc); return Number.isFinite(ms)&&ms<EARLIEST_USABLE_M1_MS; }
function excludedPreBoundary(event) { const eventMs=Date.parse(event.event_time_utc); return {...event,...eventIdentity(event,eventMs),status:"EXCLUDED_PRE_BOUNDARY",exclusion_reason:`release_datetime_before_${EARLIEST_USABLE_M1_UTC}`,quality_metric_eligible:false,source_contract:"dukascopy-node:xauusd:m1:bid",...sourceDiagnostics([]),horizons:{},reaction_lag_profile:{status:"NOT_EVALUATED_PRE_BOUNDARY"},reversal:{status:"NOT_EVALUATED_PRE_BOUNDARY"}}; }
function terminalError(event,status,error=null) { const eventMs=Date.parse(event.event_time_utc); return {...event,...eventIdentity(event,eventMs),status,quality_metric_eligible:true,...(error?{error:String(error).slice(0,500)}:{})}; }
function reversalState(window,baseline,threshold) {
  let initial=null,firstThresholdTs=null,oppositeThresholdSeen=false,crossBackTs=null;
  for(const c of window){const up=c.high-baseline>=threshold,down=baseline-c.low>=threshold;if(!initial){if(up&&down)return{state:"AMBIGUOUS",initial_direction:null,first_threshold_timestamp:new Date(c.timestamp).toISOString(),cross_back_timestamp:null,opposite_threshold_seen:true};if(up||down){initial=up?"UP":"DOWN";firstThresholdTs=c.timestamp;continue;}}else{if(initial==="UP"&&down)oppositeThresholdSeen=true;if(initial==="DOWN"&&up)oppositeThresholdSeen=true;const crossedBack=initial==="UP"?c.low<=baseline:c.high>=baseline;if(crossedBack){crossBackTs=c.timestamp;break;}}}
  if(!initial)return{state:"NO_THRESHOLD",initial_direction:null,first_threshold_timestamp:null,cross_back_timestamp:null,opposite_threshold_seen:false};
  return{state:crossBackTs?"REVERSAL":(oppositeThresholdSeen?"OPPOSITE_THRESHOLD_NO_CROSSBACK":"ONE_SIDED"),initial_direction:initial,first_threshold_timestamp:new Date(firstThresholdTs).toISOString(),cross_back_timestamp:crossBackTs?new Date(crossBackTs).toISOString():null,opposite_threshold_seen:oppositeThresholdSeen};
}
function reactionLagProfile(eventMs,byTs,baseline,lagOffsets=LAG_OFFSETS) {
  const points={},sampled=[];
  for(const lag of lagOffsets){
    const ts=eventMs+lag*MINUTE,c=byTs.get(ts),key=String(lag);
    if(!c){points[key]={status:"MISSING_M1",target_timestamp_utc:new Date(ts).toISOString()};continue}
    if(!validCandle(c)){points[key]={status:"INVALID_OHLC",target_timestamp_utc:new Date(ts).toISOString()};continue}
    const move=c.close-baseline;
    const point={status:"OK",delay_min:lag,target_timestamp_utc:new Date(ts).toISOString(),target_close:c.close,move_abs:move,move_pct:baseline?move/baseline*100:null,direction:move>0?"UP":move<0?"DOWN":"FLAT",m1_range_abs:c.high-c.low};
    points[key]=point;sampled.push(point);
  }
  const sampledPeak=sampled.length?sampled.reduce((best,p)=>Math.abs(p.move_abs)>Math.abs(best.move_abs)?p:best,sampled[0]):null;
  let observedPeak=null,missingOrInvalid=0;
  for(let lag=0;lag<=60;lag++){
    const ts=eventMs+lag*MINUTE,c=byTs.get(ts);
    if(!validCandle(c)){missingOrInvalid++;continue}
    const move=c.close-baseline;
    if(!observedPeak||Math.abs(move)>Math.abs(observedPeak.move_abs))observedPeak={delay_min:lag,target_timestamp_utc:new Date(ts).toISOString(),target_close:c.close,move_abs:move,direction:move>0?"UP":move<0?"DOWN":"FLAT"};
  }
  const pre=[];for(let t=eventMs-60*MINUTE;t<eventMs;t+=MINUTE){const c=byTs.get(t);if(validCandle(c))pre.push(c)}
  let firstBreak;
  if(pre.length!==60){
    firstBreak={status:"PRE_WINDOW_INCOMPLETE",observed_pre_m1:pre.length,expected_pre_m1:60,delay_min:null};
  }else{
    const preHigh=Math.max(...pre.map(c=>c.high)),preLow=Math.min(...pre.map(c=>c.low));let gapBefore=false,candidate=null;
    for(let lag=0;lag<=60;lag++){
      const ts=eventMs+lag*MINUTE,c=byTs.get(ts);
      if(!validCandle(c)){gapBefore=true;continue}
      if(c.close>preHigh||c.close<preLow){candidate={status:gapBefore?"UNDETERMINED_MISSING_M1":"OK",delay_min:lag,target_timestamp_utc:new Date(ts).toISOString(),target_close:c.close,direction:c.close>preHigh?"UP":"DOWN",pre_60m_high:preHigh,pre_60m_low:preLow};break}
    }
    firstBreak=candidate||{status:gapBefore?"UNDETERMINED_MISSING_M1":"NO_BREAK",delay_min:null,pre_60m_high:preHigh,pre_60m_low:preLow};
  }
  return{
    status:"OK",
    semantics:"Descriptive publication-to-market timing. No assumed internet/newswire delay and no causality claim.",
    sampled_lag_minutes:[...lagOffsets],
    points,
    sampled_peak_abs_close_move:sampledPeak?{delay_min:sampledPeak.delay_min,target_timestamp_utc:sampledPeak.target_timestamp_utc,move_abs:sampledPeak.move_abs,direction:sampledPeak.direction}:null,
    full_0_60m_peak:{status:missingOrInvalid?"PARTIAL_MISSING_OR_INVALID_M1":"OK",missing_or_invalid_minutes:missingOrInvalid,...(observedPeak||{delay_min:null,target_timestamp_utc:null,target_close:null,move_abs:null,direction:null})},
    first_pre_60m_range_break:firstBreak,
  };
}
function computeEventMetrics(event,rows,threshold=DEFAULT_THRESHOLD_USD) {
  canonicalEvent(event);
  const eventMs=Date.parse(event.event_time_utc),diagnostics=sourceDiagnostics(rows);
  if(!Number.isFinite(eventMs)||eventMs%MINUTE!==0)return{...event,...eventIdentity(event,eventMs),...diagnostics,status:"INVALID_EVENT_TIMESTAMP",quality_metric_eligible:true};
  if(eventMs<EARLIEST_USABLE_M1_MS)return excludedPreBoundary(event);
  const normalized=normalizeRows(rows),byTs=new Map(normalized.map(r=>[r.timestamp,r])),baselineTs=eventMs-MINUTE,baselineCandle=byTs.get(baselineTs);
  if(!validCandle(baselineCandle))return{...event,...eventIdentity(event,eventMs),...diagnostics,status:"MISSING_OR_INVALID_BASELINE_T_MINUS_1",quality_metric_eligible:true};
  const baseline=baselineCandle.close;
  const out={...event,...eventIdentity(event,eventMs),status:"OK",quality_metric_eligible:true,source_contract:"dukascopy-node:xauusd:m1:bid",...diagnostics,baseline_timestamp_utc:new Date(baselineTs).toISOString(),baseline_price:baseline,horizon_semantics:"+Nm = close of the Nth complete reaction minute; +1m uses close of candle t, +5m uses close of t+4m",reaction_lag_profile:reactionLagProfile(eventMs,byTs,baseline),horizons:{}};
  for(const h of HORIZONS){const targetMs=eventMs+(h-1)*MINUTE,window=[];let bad=null;for(let t=eventMs;t<=targetMs;t+=MINUTE){const c=byTs.get(t);if(!c){bad="MISSING_M1";break}if(!validCandle(c)){bad="INVALID_OHLC";break}window.push(c)}if(bad){out.horizons[String(h)]={status:bad};continue}const target=window[window.length-1];let maxHigh=window[0].high,minLow=window[0].low,mfeTs=window[0].timestamp,maeTs=window[0].timestamp;for(const c of window){if(c.high>maxHigh){maxHigh=c.high;mfeTs=c.timestamp}if(c.low<minLow){minLow=c.low;maeTs=c.timestamp}}const move=target.close-baseline;out.horizons[String(h)]={status:"OK",target_timestamp_utc:new Date(target.timestamp).toISOString(),target_close:target.close,move_abs:move,move_pct:baseline?move/baseline*100:null,direction:move>0?"UP":move<0?"DOWN":"FLAT",mfe_abs:maxHigh-baseline,mfe_timestamp_utc:new Date(mfeTs).toISOString(),mae_abs:minLow-baseline,mae_timestamp_utc:new Date(maeTs).toISOString(),range_abs:maxHigh-minLow};}
  const full=[];for(let t=eventMs;t<=eventMs+59*MINUTE;t+=MINUTE){const c=byTs.get(t);if(!validCandle(c)){out.reversal={status:c?"INVALID_OHLC":"MISSING_M1"};return out}full.push(c)}out.reversal={status:"OK",threshold_usd:threshold,...reversalState(full,baseline,threshold)};return out;
}
function dayBounds(eventMs){const from=new Date(Date.UTC(new Date(eventMs).getUTCFullYear(),new Date(eventMs).getUTCMonth(),new Date(eventMs).getUTCDate())-MINUTE);const to=new Date(from.getTime()+24*60*60*1000+2*MINUTE);return{from,to};}
async function fetchWindow(event){const eventMs=Date.parse(event.event_time_utc),{from,to}=dayBounds(eventMs);let last;for(let attempt=1;attempt<=5;attempt++){try{const rows=await getHistoricalRates({instrument:"xauusd",dates:{from,to},timeframe:"m1",format:"json",priceType:"bid",batchSize:1,pauseBetweenBatchesMs:2500,retryCount:3,pauseBetweenRetriesMs:5000,retryOnEmpty:false,failAfterRetryCount:false});const normalized=normalizeRows(rows);if(!normalized.length)throw new Error("SOURCE_EMPTY_DAY");return normalized}catch(e){last=e;if(attempt<5)await sleep(Math.min(60000,5000*Math.pow(2,attempt-1)))}}throw last;}
function hasMissingM1(r){return Object.values(r.horizons||{}).some(h=>h?.status==="MISSING_M1")||r.reversal?.status==="MISSING_M1";}
function hasInvalidOhlc(r){return Object.values(r.horizons||{}).some(h=>h?.status==="INVALID_OHLC")||r.reversal?.status==="INVALID_OHLC";}
function missingM1Documentation(results){return results.filter(r=>r.status!=="EXCLUDED_PRE_BOUNDARY"&&hasMissingM1(r)).map(r=>({ordinal:r.ordinal,family:r.family,release_year:r.release_year,release_datetime:r.release_datetime,status:r.status,missing_horizons:Object.entries(r.horizons||{}).filter(([,h])=>h?.status==="MISSING_M1").map(([h])=>Number(h)),reversal_status:r.reversal?.status||null,reason_code:"MISSING_M1_NO_INTERPOLATION"}));}
function median(values){const a=values.filter(Number.isFinite).sort((x,y)=>x-y);if(!a.length)return null;const mid=Math.floor(a.length/2);return a.length%2?a[mid]:(a[mid-1]+a[mid])/2;}
function summarize(results,threshold){
  const eligible=results.filter(r=>r.status!=="EXCLUDED_PRE_BOUNDARY"),excluded=results.filter(r=>r.status==="EXCLUDED_PRE_BOUNDARY"),valid60=eligible.filter(r=>r.horizons?.["60"]?.status==="OK"),reached=eligible.filter(r=>r.reversal?.status==="OK"&&r.reversal.state!=="NO_THRESHOLD"),byFamily={},sourceRows=eligible.map(r=>Number(r.source_rows)).filter(Number.isFinite),missingM1=eligible.filter(hasMissingM1).length,invalidOhlc=eligible.filter(hasInvalidOhlc).length;
  for(const r of eligible){
    const k=r.family;byFamily[k]||={events:0,valid60:0,threshold_reached:0,lag_profile_events:0,_sampled_peak_delay:[],_full_peak_delay:[],_pre_range_break_delay:[],pre_range_break_undetermined_missing_m1:0};const f=byFamily[k];f.events++;if(r.horizons?.["60"]?.status==="OK")f.valid60++;if(r.reversal?.status==="OK"&&r.reversal.state!=="NO_THRESHOLD")f.threshold_reached++;
    const p=r.reaction_lag_profile;if(p?.status==="OK"){f.lag_profile_events++;if(Number.isFinite(p.sampled_peak_abs_close_move?.delay_min))f._sampled_peak_delay.push(p.sampled_peak_abs_close_move.delay_min);if(Number.isFinite(p.full_0_60m_peak?.delay_min))f._full_peak_delay.push(p.full_0_60m_peak.delay_min);if(p.first_pre_60m_range_break?.status==="OK"&&Number.isFinite(p.first_pre_60m_range_break.delay_min))f._pre_range_break_delay.push(p.first_pre_60m_range_break.delay_min);if(p.first_pre_60m_range_break?.status==="UNDETERMINED_MISSING_M1")f.pre_range_break_undetermined_missing_m1++;}
  }
  for(const f of Object.values(byFamily)){f.median_sampled_peak_delay_min=median(f._sampled_peak_delay);f.median_full_0_60m_peak_delay_min=median(f._full_peak_delay);f.median_pre_60m_range_break_delay_min=median(f._pre_range_break_delay);delete f._sampled_peak_delay;delete f._full_peak_delay;delete f._pre_range_break_delay;}
  return{manifest_events:results.length,eligible_events:eligible.length,excluded_pre_boundary:excluded.length,earliest_usable_m1_utc:EARLIEST_USABLE_M1_UTC,valid_60m:valid60.length,validation_pass_rate:eligible.length?valid60.length/eligible.length:null,retrieval_errors:eligible.filter(r=>r.status==="RETRIEVAL_ERROR").length,missing_m1_events:missingM1,invalid_ohlc_events:invalidOhlc,source_rows_min:sourceRows.length?Math.min(...sourceRows):null,source_rows_max:sourceRows.length?Math.max(...sourceRows):null,threshold_usd:threshold,threshold_reached:reached.length,threshold_reach_rate:eligible.length?reached.length/eligible.length:null,threshold_gate:eligible.length&&(reached.length/eligible.length<0.2||reached.length/eligible.length>0.8)?"RECONSIDER":"ACCEPTABLE_RANGE",reaction_lag_minutes:LAG_OFFSETS,by_family:byFamily,missing_m1_documentation:missingM1Documentation(eligible)};
}
async function main(){const threshold=Number(process.env.REVERSAL_THRESHOLD_USD||DEFAULT_THRESHOLD_USD);const{events}=loadAndValidate();const selected=events.map((e,i)=>({...e,event_type:e.event_type||e.family,ordinal:i}));const results=[];for(let i=0;i<selected.length;i++){const e=selected[i];console.log(`PHASE1_REACTION ${i+1}/${selected.length} ${e.family} ${e.event_time_utc}`);if(isPreBoundaryEvent(e)){const excluded=excludedPreBoundary(e);console.log(`PHASE1_EXCLUDED ${i+1}/${selected.length} status=${excluded.status} boundary=${EARLIEST_USABLE_M1_UTC}`);results.push(excluded);continue}try{const rows=await fetchWindow(e),metrics=computeEventMetrics(e,rows,threshold);console.log(`PHASE1_SOURCE ${i+1}/${selected.length} rows=${metrics.source_rows} coverage=${metrics.source_coverage_ratio_vs_1440} status=${metrics.status} h60=${metrics.horizons?.["60"]?.status||"NA"}`);results.push(metrics)}catch(err){results.push(terminalError(e,"RETRIEVAL_ERROR",err?.message||err))}if(i<selected.length-1)await sleep(1500)}const payload={phase:"PHASE1_REACTION_METRICS_V2",research_only:true,dataset_sha256:EXPECTED_DATASET,generated_at_utc:new Date().toISOString(),threshold_provisional:true,horizons_minutes:HORIZONS,reaction_lag_minutes:LAG_OFFSETS,earliest_usable_m1_utc:EARLIEST_USABLE_M1_UTC,summary:summarize(results,threshold),events:results};const out=path.join(__dirname,"output","historical_news_v2","phase1_reaction_metrics_v2.json");fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,JSON.stringify(payload,null,2)+"\n");console.log(JSON.stringify(payload.summary,null,2));}
module.exports={HORIZONS,LAG_OFFSETS,DEFAULT_THRESHOLD_USD,EXPECTED_FULL_DAY_MINUTES,EARLIEST_USABLE_M1_UTC,validCandle,normalizeRows,sourceDiagnostics,canonicalEvent,eventIdentity,isPreBoundaryEvent,excludedPreBoundary,terminalError,reversalState,reactionLagProfile,computeEventMetrics,dayBounds,fetchWindow,hasMissingM1,hasInvalidOhlc,missingM1Documentation,median,summarize};
if(require.main===module)main().catch(e=>{console.error(e?.stack||e);process.exit(1)});
