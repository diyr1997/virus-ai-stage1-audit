"use strict";

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const OUT_DIR = path.join(__dirname, "output", "historical_news_v2", "official_archives");
const SOURCES = [
  { family: "CPI", landing: "https://www.bls.gov/bls/news-release/cpi.htm", slug: "cpi" },
  { family: "EMPLOYMENT_SITUATION", landing: "https://www.bls.gov/bls/news-release/empsit.htm", slug: "empsit" },
];
const YEARS = new Set([2003, 2004, 2005]);
const HEADER_PREFIX_CHARS = 2000;
const DATE_PROXIMITY_LINES = 5;

function sha256(text) {
  return crypto.createHash("sha256").update(String(text)).digest("hex");
}
function assert(cond, message) { if (!cond) throw new Error(message); }
async function fetchText(url) {
  const res = await fetch(url, { headers: { "user-agent": "xauusd-research-audit/2.0" } });
  if (!res.ok) throw new Error(`HTTP ${res.status} ${url}`);
  return res.text();
}
function absolute(base, href) { return new URL(href, base).toString(); }
function archiveLinks(html, source) {
  const out = [];
  const re = /href=["']([^"']+)["'][^>]*>([^<]*)</gi;
  let m;
  while ((m = re.exec(html))) {
    const href = m[1];
    if (!new RegExp(`/news\\.release/(?:history|archives)/${source.slug}_[^/]+\\.txt$`, "i").test(href)) continue;
    const date = href.match(/_(\d{8})\.txt$/i)?.[1];
    if (!date) continue;
    const year = Number(date.slice(4));
    if (!YEARS.has(year)) continue;
    out.push({ url: absolute(source.landing, href), archive_date_code: date, year });
  }
  return [...new Map(out.map(x => [x.url, x])).values()].sort((a,b)=>a.archive_date_code.localeCompare(b.archive_date_code));
}
function monthNum(name) {
  const m = {january:1,february:2,march:3,april:4,may:5,june:6,july:7,august:8,september:9,october:10,november:11,december:12};
  return m[String(name).toLowerCase()] || 0;
}
function parseReleaseTimestamp(raw) {
  const header = String(raw || "").replace(/\r/g, "").slice(0, HEADER_PREFIX_CHARS);
  const lines = header.split("\n");
  const timeRe = /\b(\d{1,2}):(\d{2})\s*(a\.?m\.?|p\.?m\.?)\s*,?\s*\((EST|EDT)\)/ig;
  const dateRe = /\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{1,2}),\s+(\d{4})\b/ig;
  const times = [];
  const dates = [];

  for (let lineIndex = 0; lineIndex < lines.length; lineIndex += 1) {
    let m;
    timeRe.lastIndex = 0;
    while ((m = timeRe.exec(lines[lineIndex]))) {
      times.push({ lineIndex, hour: Number(m[1]), minute: Number(m[2]), ap: m[3], zone: m[4].toUpperCase(), raw: m[0] });
    }
    dateRe.lastIndex = 0;
    while ((m = dateRe.exec(lines[lineIndex]))) {
      dates.push({ lineIndex, monthName: m[1], day: Number(m[2]), year: Number(m[3]), raw: m[0] });
    }
  }

  if (times.length !== 1) {
    throw new Error(`RELEASE_TIME_AMBIGUOUS count=${times.length}`);
  }
  const time = times[0];
  const nearbyDates = dates.filter(d => Math.abs(d.lineIndex - time.lineIndex) <= DATE_PROXIMITY_LINES);
  if (nearbyDates.length !== 1) {
    throw new Error(`RELEASE_DATE_AMBIGUOUS count=${nearbyDates.length}`);
  }
  const date = nearbyDates[0];

  assert(time.hour >= 1 && time.hour <= 12, `INVALID_HOUR ${time.hour}`);
  assert(time.minute >= 0 && time.minute <= 59, `INVALID_MINUTE ${time.minute}`);
  assert(time.zone === "EST" || time.zone === "EDT", `UNKNOWN_ZONE ${time.zone}`);
  const month = monthNum(date.monthName);
  assert(month >= 1 && month <= 12, `INVALID_MONTH ${date.monthName}`);
  assert(date.day >= 1 && date.day <= 31, `INVALID_DAY ${date.day}`);
  assert(date.year >= 1900 && date.year <= 2100, `INVALID_YEAR ${date.year}`);

  let hour = time.hour;
  const ap = time.ap.toLowerCase().replace(/\./g, "");
  if (ap === "pm" && hour !== 12) hour += 12;
  if (ap === "am" && hour === 12) hour = 0;
  const offsetMinutes = time.zone === "EST" ? -300 : -240;
  const utcMs = Date.UTC(date.year, month - 1, date.day, hour, time.minute) - offsetMinutes * 60000;
  const dt = new Date(utcMs);
  assert(dt.getUTCFullYear() >= 1900, "INVALID_RELEASE_TIMESTAMP");
  return {
    event_time_utc: dt.toISOString(),
    us_eastern_local: `${date.year}-${String(month).padStart(2,"0")}-${String(date.day).padStart(2,"0")}T${String(hour).padStart(2,"0")}:${String(time.minute).padStart(2,"0")}:00`,
    eastern_zone: time.zone,
    expected_utc_offset_minutes: offsetMinutes,
  };
}
function extractReleaseLabel(raw) {
  const m = raw.match(/(?:Consumer Price Index|THE EMPLOYMENT SITUATION)[^\n]*?(?:for|:|--)?\s*(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{4})/i);
  return m ? `${m[1]} ${m[2]}` : null;
}
async function collectSource(source) {
  const landingHtml = await fetchText(source.landing);
  const links = archiveLinks(landingHtml, source);
  assert(links.length >= 30, `${source.family}: expected >=30 TXT archives for 2003-2005, got ${links.length}`);
  const rows = [];
  for (const link of links) {
    const raw = await fetchText(link.url);
    const ts = parseReleaseTimestamp(raw);
    rows.push({
      family: source.family,
      year: link.year,
      archive_date_code: link.archive_date_code,
      release_label: extractReleaseLabel(raw),
      official_source: link.url,
      retrieval_timestamp_utc: new Date().toISOString(),
      raw_sha256: sha256(raw),
      raw_bytes: Buffer.byteLength(raw),
      ...ts,
    });
    await new Promise(r => setTimeout(r, 150));
  }
  return rows;
}
async function main() {
  const all = [];
  for (const source of SOURCES) all.push(...await collectSource(source));
  all.sort((a,b)=>a.event_time_utc.localeCompare(b.event_time_utc)||a.family.localeCompare(b.family));
  const byFamilyYear = {};
  for (const row of all) {
    const k = `${row.family}:${row.year}`;
    byFamilyYear[k] = (byFamilyYear[k] || 0) + 1;
  }
  for (const family of SOURCES.map(s=>s.family)) for (const year of YEARS) {
    assert((byFamilyYear[`${family}:${year}`] || 0) >= 10, `coverage too low ${family} ${year}`);
  }
  const payload = {
    schema_version: 1,
    research_only: true,
    point_in_time_policy: "official archived release text; no latest-database substitution",
    parser_policy: `first ${HEADER_PREFIX_CHARS} chars; exactly one time; exactly one date within ${DATE_PROXIMITY_LINES} lines; EST/EDT only; fail closed`,
    generated_at_utc: new Date().toISOString(),
    source_landing_pages: SOURCES.map(s=>s.landing),
    counts: byFamilyYear,
    events: all,
  };
  payload.dataset_sha256 = sha256(JSON.stringify(payload.events));
  fs.mkdirSync(OUT_DIR, { recursive: true });
  const out = path.join(OUT_DIR, "bls_2003_2005_release_index.json");
  fs.writeFileSync(out, JSON.stringify(payload, null, 2) + "\n");
  console.log(JSON.stringify({ events: all.length, counts: byFamilyYear, dataset_sha256: payload.dataset_sha256, out }, null, 2));
}

module.exports = { archiveLinks, parseReleaseTimestamp, extractReleaseLabel, collectSource, SOURCES, HEADER_PREFIX_CHARS, DATE_PROXIMITY_LINES };
if (require.main === module) main().catch(err => { console.error(err?.stack || err); process.exit(1); });
