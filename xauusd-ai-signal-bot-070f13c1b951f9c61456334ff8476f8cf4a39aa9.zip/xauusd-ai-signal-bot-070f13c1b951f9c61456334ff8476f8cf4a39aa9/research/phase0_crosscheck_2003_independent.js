"use strict";

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { getHistoricalRates } = require("dukascopy-node");

const SAMPLES = [
  { day: "2003-05-06", independent_usd_oz: 342.65 },
  { day: "2003-06-25", independent_usd_oz: 347.85 },
  { day: "2003-08-12", independent_usd_oz: 360.00 },
  { day: "2003-12-09", independent_usd_oz: 408.25 }
];
const SOURCE_URL = "https://thepuregoldcompany.co.uk/gold-price-usd/";
const TOLERANCE_PCT = 0.05;
function sha256(v){return crypto.createHash("sha256").update(JSON.stringify(v)).digest("hex");}

async function fetchDay(day){
  const from=new Date(`${day}T00:00:00Z`),to=new Date(from.getTime()+86400000);
  const rows=await getHistoricalRates({instrument:"xauusd",dates:{from,to},timeframe:"m1",format:"json",priceType:"bid",batchSize:1,pauseBetweenBatchesMs:1500,retryCount:5,pauseBetweenRetriesMs:5000,retryOnEmpty:true,failAfterRetryCount:false});
  return (Array.isArray(rows)?rows:[]).map(r=>({timestamp:Number(r.timestamp),close:Number(r.close)})).filter(r=>Number.isFinite(r.timestamp)&&Number.isFinite(r.close));
}

async function main(){
  const results=[];
  for(const sample of SAMPLES){
    const rows=await fetchDay(sample.day);
    if(!rows.length) throw new Error(`No Dukascopy M1 rows for ${sample.day}`);
    let best=null;
    for(const row of rows){
      const deviation_pct=Math.abs(row.close-sample.independent_usd_oz)/sample.independent_usd_oz*100;
      if(!best||deviation_pct<best.deviation_pct) best={timestamp_utc:new Date(row.timestamp).toISOString(),dukascopy_bid_close:row.close,deviation_pct};
    }
    results.push({...sample,nearest_same_day_m1:best,within_tolerance:best.deviation_pct<=TOLERANCE_PCT});
  }
  const payload={
    phase:"PHASE_0_INDEPENDENT_PRICE_LEVEL_CROSSCHECK",
    research_only:true,
    dukascopy_source:"dukascopy-node:xauusd:m1:bid",
    independent_source:SOURCE_URL,
    independent_source_description:"Published historical USD/oz gold daily price series; used only as an independent same-day price-level cross-check, not as an exact timestamp quote.",
    methodology:"For each independent daily historical gold quote, find the nearest Dukascopy XAUUSD M1 BID close on the same UTC date. This validates price scale/level without claiming timestamp equivalence. Acceptance requires nearest same-day deviation <= 0.05% for every sample.",
    tolerance_pct:TOLERANCE_PCT,
    all_within_tolerance:results.every(r=>r.within_tolerance),
    results
  };
  payload.result_sha256=sha256(payload);
  const out=path.join(__dirname,"output","historical_news_v2");fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,"phase0_crosscheck_2003_independent.json"),JSON.stringify(payload,null,2)+"\n");console.log(JSON.stringify(payload,null,2));
  if(!payload.all_within_tolerance) process.exitCode=2;
}
main().catch(err=>{console.error(err?.stack||err);process.exit(1);});
