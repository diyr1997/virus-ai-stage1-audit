"use strict";

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { getHistoricalRates } = require("dukascopy-node");

const MANIFEST = path.join(__dirname, "preflight_2025_manifest_v2.json");
const OUT_DIR = path.join(__dirname, "output", "historical_news_v2");
const HORIZONS = [1, 5, 15, 30, 60];

function stable(v) { if (Array.isArray(v)) return v.map(stable); if (v && typeof v === "object") return Object.fromEntries(Object.keys(v).sort().map(k => [k, stable(v[k])])); return v; }
function stableJson(v) { return JSON.stringify(stable(v)); }
function sha256(v) { return crypto.createHash("sha256").update(stableJson(v)).digest("hex"); }
function assert(c, m) { if (!c) throw new Error(m); }

function easternParts(date) {
  const fmt = new Intl.DateTimeFormat("en-CA", {timeZone:"America/New_York",year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit",hourCycle:"h23"});
  const p = Object.fromEntries(fmt.formatToParts(date).filter(x => x.type !== "literal").map(x => [x.type,x.value]));
  return `${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}:${p.second}`;
}

function buildPreReleaseFeatureSnapshot(e) {
  return { id:e.id, family:e.family, metric:e.metric, forecast:e.forecast, previous_pre_release:e.previous_pre_release, forecast_tier:e.forecast_tier };
}

function validateManifest(m) {
  assert(m.schema_version === 2, "PIT manifest schema_version must be 2");
  assert(m.research_only === true, "manifest must be research_only");
  assert(Array.isArray(m.events) && m.events.length === 10, "preflight requires exactly 10 events");
  const allowed = new Set(["CPI","EMPLOYMENT_SITUATION","FOMC","PCE"]); const ids = new Set(); let tier12=0, est=0, edt=0, revisions=0;
  for (const e of m.events) {
    assert(!ids.has(e.id), `duplicate ${e.id}`); ids.add(e.id);
    assert(allowed.has(e.family), `scope violation ${e.family}`);
    assert(Object.prototype.hasOwnProperty.call(e,"previous_pre_release"), `missing previous_pre_release ${e.id}`);
    assert(Object.prototype.hasOwnProperty.call(e,"previous_revised_at_release"), `missing previous_revised_at_release ${e.id}`);
    assert(typeof e.revision_flag === "boolean", `missing revision_flag ${e.id}`);
    const differs = e.previous_revised_at_release !== null && String(e.previous_revised_at_release) !== String(e.previous_pre_release);
    assert(e.revision_flag === differs, `revision consistency failure ${e.id}`);
    if (e.revision_flag) revisions++;
    const event = new Date(e.event_time_utc), pub = new Date(e.forecast_source_published_at_utc);
    assert(Number.isFinite(event.getTime()) && Number.isFinite(pub.getTime()) && pub < event, `forecast provenance timestamp failure ${e.id}`);
    assert(easternParts(event) === e.us_eastern_local, `DST/local mismatch ${e.id}`);
    assert(/^https:\/\//.test(e.forecast_source) && /^https:\/\//.test(e.official_source), `provenance URL failure ${e.id}`);
    const pre = buildPreReleaseFeatureSnapshot(e);
    assert(!Object.prototype.hasOwnProperty.call(pre,"previous_revised_at_release"), `LOOKAHEAD: revision leaked into pre-release snapshot ${e.id}`);
    if (e.forecast_tier <= 2) tier12++;
    if (e.expected_utc_offset_minutes === -300) est++;
    if (e.expected_utc_offset_minutes === -240) edt++;
  }
  assert(tier12 >= 8, `need >=8 Tier1/2; got ${tier12}`); assert(est>0 && edt>0, "need EST and EDT coverage");
  return {event_count:m.events.length,tier12,est,edt,revisions,lookahead_revision_leaks:0};
}

async function fetchWindow(eventUtc) {
  const center = new Date(eventUtc), from = new Date(center.getTime()-5*60000), to = new Date(center.getTime()+66*60000);
  const rows = await getHistoricalRates({instrument:"xauusd",dates:{from,to},timeframe:"m1",format:"json",priceType:"bid",batchSize:1,pauseBetweenBatchesMs:1200,retryCount:5,pauseBetweenRetriesMs:5000,retryOnEmpty:true,failAfterRetryCount:false});
  return (Array.isArray(rows)?rows:[]).map(r=>({timestamp:Number(r.timestamp),open:Number(r.open),high:Number(r.high),low:Number(r.low),close:Number(r.close)})).filter(r=>Number.isFinite(r.timestamp)).sort((a,b)=>a.timestamp-b.timestamp);
}
function exact(rows,t){return rows.find(r=>r.timestamp===t)||null;}
function analyze(e,rows){
  const t0=new Date(e.event_time_utc).getTime(), base=exact(rows,t0); assert(base,`M1_GAP baseline ${e.id}`); const reactions={};
  for(const h of HORIZONS){const target=exact(rows,t0+h*60000);assert(target,`M1_GAP +${h} ${e.id}`);const w=rows.filter(r=>r.timestamp>=t0&&r.timestamp<=t0+h*60000);assert(w.length===h+1,`M1_GAP window ${e.id} +${h} count=${w.length}`);const b=base.open,delta=target.close-b,hi=Math.max(...w.map(r=>r.high)),lo=Math.min(...w.map(r=>r.low));reactions[`m${h}`]={close:target.close,delta:Number(delta.toFixed(6)),delta_bps:Number(((delta/b)*10000).toFixed(6)),mfe:Number((hi-b).toFixed(6)),mae:Number((lo-b).toFixed(6))};}
  return {id:e.id,family:e.family,metric:e.metric,event_time_utc:e.event_time_utc,forecast:e.forecast,previous_pre_release:e.previous_pre_release,previous_revised_at_release:e.previous_revised_at_release,revision_flag:e.revision_flag,actual:e.actual,forecast_tier:e.forecast_tier,forecast_source:e.forecast_source,official_source:e.official_source,pre_release_feature_snapshot:buildPreReleaseFeatureSnapshot(e),baseline_open:base.open,reactions,reversal_1_to_60:reactions.m1.delta!==0&&reactions.m60.delta!==0&&Math.sign(reactions.m1.delta)!==Math.sign(reactions.m60.delta),m1_rows:rows.length};
}
async function main(){const m=JSON.parse(fs.readFileSync(MANIFEST,"utf8"));const validation=validateManifest(m);const results=[];for(const e of [...m.events].sort((a,b)=>a.event_time_utc.localeCompare(b.event_time_utc))){const rows=await fetchWindow(e.event_time_utc);assert(rows.length,`SOURCE_EMPTY ${e.id}`);results.push(analyze(e,rows));}const payload={schema_version:2,research_only:true,instrument:"XAUUSD",price_source:"Dukascopy xauusd M1 BID",baseline:"event-minute OPEN; exact candles only; no interpolation",horizons_minutes:HORIZONS,validation,manifest_sha256:sha256(m),results};payload.result_sha256=sha256(payload);fs.mkdirSync(OUT_DIR,{recursive:true});fs.writeFileSync(path.join(OUT_DIR,"preflight_2025_v2.json"),JSON.stringify(payload,null,2)+"\n");console.log(JSON.stringify({validation,manifest_sha256:payload.manifest_sha256,result_sha256:payload.result_sha256,events:results.length},null,2));}
main().catch(err=>{console.error(err?.stack||err);process.exit(1);});
