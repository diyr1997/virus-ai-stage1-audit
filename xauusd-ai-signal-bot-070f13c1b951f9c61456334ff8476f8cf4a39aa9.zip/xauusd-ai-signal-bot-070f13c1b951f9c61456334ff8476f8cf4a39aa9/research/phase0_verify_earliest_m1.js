"use strict";

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { getHistoricalRates } = require("dukascopy-node");

const START_DAY_UTC = process.env.PHASE0_START_DAY_UTC || "2003-05-05T00:00:00Z";

function sha256(text) {
  return crypto.createHash("sha256").update(String(text)).digest("hex");
}

async function main() {
  const from = new Date(START_DAY_UTC);
  if (!Number.isFinite(from.getTime())) throw new Error(`Invalid PHASE0_START_DAY_UTC: ${START_DAY_UTC}`);
  const to = new Date(from.getTime() + 24 * 60 * 60 * 1000);

  const rows = await getHistoricalRates({
    instrument: "xauusd",
    dates: { from, to },
    timeframe: "m1",
    format: "json",
    priceType: "bid",
    batchSize: 1,
    pauseBetweenBatchesMs: 2500,
    retryCount: 5,
    pauseBetweenRetriesMs: 10000,
    retryOnEmpty: true,
    failAfterRetryCount: false,
  });

  const normalized = (Array.isArray(rows) ? rows : [])
    .map((r) => ({
      timestamp: Number(r.timestamp),
      open: Number(r.open),
      high: Number(r.high),
      low: Number(r.low),
      close: Number(r.close),
    }))
    .filter((r) => Number.isFinite(r.timestamp))
    .sort((a, b) => a.timestamp - b.timestamp);

  const first = normalized[0] || null;
  const last = normalized[normalized.length - 1] || null;
  const payload = {
    phase: "PHASE_0_EARLIEST_M1_VERIFICATION",
    research_only: true,
    instrument: "xauusd",
    timeframe: "m1",
    price_type: "bid",
    requested_day_utc: from.toISOString(),
    rows: normalized.length,
    first_timestamp_utc: first ? new Date(first.timestamp).toISOString() : null,
    last_timestamp_utc: last ? new Date(last.timestamp).toISOString() : null,
    has_expected_boundary_or_later: Boolean(first && first.timestamp >= from.getTime()),
    source_contract: "dukascopy-node:xauusd:m1:bid",
    content_sha256: sha256(JSON.stringify(normalized)),
    terminal_status: normalized.length ? "VERIFIED_M1_PRESENT" : "SOURCE_EMPTY_CONFIRMED_OR_RETRY_EXHAUSTED",
  };

  const outDir = path.join(__dirname, "output", "historical_news_v2");
  fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(path.join(outDir, "phase0_earliest_m1.json"), JSON.stringify(payload, null, 2) + "\n", "utf8");
  console.log(JSON.stringify(payload, null, 2));

  if (!normalized.length) process.exitCode = 2;
}

main().catch((error) => {
  console.error(error?.stack || error);
  process.exit(1);
});
