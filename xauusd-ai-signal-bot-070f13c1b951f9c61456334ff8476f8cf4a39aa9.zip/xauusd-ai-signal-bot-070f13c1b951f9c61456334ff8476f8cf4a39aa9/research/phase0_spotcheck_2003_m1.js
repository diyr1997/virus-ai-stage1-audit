"use strict";

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { getHistoricalRates } = require("dukascopy-node");

const DAYS = ["2003-05-06", "2003-06-25", "2003-08-12", "2003-12-09"];
function sha256(v) { return crypto.createHash("sha256").update(JSON.stringify(v)).digest("hex"); }

async function fetchDay(day) {
  const from = new Date(`${day}T00:00:00Z`);
  const to = new Date(from.getTime() + 24 * 60 * 60 * 1000);
  const rows = await getHistoricalRates({
    instrument: "xauusd", dates: { from, to }, timeframe: "m1", format: "json", priceType: "bid",
    batchSize: 1, pauseBetweenBatchesMs: 1500, retryCount: 5, pauseBetweenRetriesMs: 5000,
    retryOnEmpty: true, failAfterRetryCount: false,
  });
  const clean = (Array.isArray(rows) ? rows : []).map(r => ({
    timestamp: Number(r.timestamp), open: Number(r.open), high: Number(r.high), low: Number(r.low), close: Number(r.close)
  })).filter(r => Number.isFinite(r.timestamp)).sort((a,b) => a.timestamp-b.timestamp);
  return {
    day,
    rows: clean.length,
    first_timestamp_utc: clean.length ? new Date(clean[0].timestamp).toISOString() : null,
    last_timestamp_utc: clean.length ? new Date(clean[clean.length-1].timestamp).toISOString() : null,
    content_sha256: sha256(clean),
    status: clean.length ? "VERIFIED_M1_PRESENT" : "SOURCE_EMPTY_CONFIRMED_OR_RETRY_EXHAUSTED"
  };
}

async function main() {
  const days = [];
  for (const day of DAYS) days.push(await fetchDay(day));
  const payload = {
    phase: "PHASE_0_2003_M1_SPOTCHECK",
    research_only: true,
    source_contract: "dukascopy-node:xauusd:m1:bid",
    requested_days: DAYS,
    all_present: days.every(d => d.rows > 0),
    days,
  };
  payload.result_sha256 = sha256(payload);
  const outDir = path.join(__dirname, "output", "historical_news_v2");
  fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(path.join(outDir, "phase0_spotcheck_2003.json"), JSON.stringify(payload, null, 2) + "\n");
  console.log(JSON.stringify(payload, null, 2));
  if (!payload.all_present) process.exitCode = 2;
}
main().catch(err => { console.error(err?.stack || err); process.exit(1); });
