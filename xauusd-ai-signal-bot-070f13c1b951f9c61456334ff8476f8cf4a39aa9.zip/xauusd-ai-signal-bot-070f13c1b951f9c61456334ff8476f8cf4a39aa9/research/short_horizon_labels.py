"""Causal research utilities for short-horizon XAU/USD replay.

Research-only. No production imports.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Sequence

import numpy as np
import pandas as pd

HORIZONS_MINUTES = (1, 3, 5, 10, 15, 30, 60)


@dataclass(frozen=True)
class BarrierSpec:
    horizon: int
    tp_atr: float = 1.0
    sl_atr: float = 1.0


def validate_m1(df: pd.DataFrame) -> dict:
    required = {"time", "open", "high", "low", "close"}
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(f"missing columns: {sorted(missing)}")
    x = df.copy()
    x["time"] = pd.to_datetime(x["time"], utc=True, errors="raise")
    ordered = bool(x["time"].is_monotonic_increasing)
    duplicate_times = int(x["time"].duplicated().sum())
    bad_ohlc = int(((x["high"] < x[["open", "close", "low"]].max(axis=1)) |
                    (x["low"] > x[["open", "close", "high"]].min(axis=1)) |
                    (x[["open", "high", "low", "close"]] <= 0).any(axis=1)).sum())
    dt = x["time"].sort_values().drop_duplicates().diff().dt.total_seconds().div(60)
    unexpected_gaps = int(((dt > 1) & (dt < 60 * 48)).sum())
    return {
        "rows": int(len(x)),
        "ordered": ordered,
        "duplicate_times": duplicate_times,
        "bad_ohlc": bad_ohlc,
        "gap_count_raw": unexpected_gaps,
        "first": x["time"].min(),
        "last": x["time"].max(),
    }


def causal_atr(df: pd.DataFrame, window: int = 14) -> pd.Series:
    """ATR known at each closed candle; no centered/future windows."""
    prev_close = df["close"].shift(1)
    tr = pd.concat([
        df["high"] - df["low"],
        (df["high"] - prev_close).abs(),
        (df["low"] - prev_close).abs(),
    ], axis=1).max(axis=1)
    return tr.rolling(window=window, min_periods=window).mean()


def forward_path_outcomes(
    df: pd.DataFrame,
    horizons: Sequence[int] = HORIZONS_MINUTES,
    atr_window: int = 14,
) -> pd.DataFrame:
    """Auxiliary outcomes. Future prices appear only in labels, never features."""
    x = df.reset_index(drop=True).copy()
    atr = causal_atr(x, atr_window)
    out = pd.DataFrame({"time": x["time"], "atr": atr})
    close = x["close"].to_numpy(dtype=float)
    high = x["high"].to_numpy(dtype=float)
    low = x["low"].to_numpy(dtype=float)
    n = len(x)
    for h in horizons:
        ret = np.full(n, np.nan)
        mfe = np.full(n, np.nan)
        mae = np.full(n, np.nan)
        for i in range(0, max(0, n - h)):
            entry = close[i]
            path_hi = high[i + 1:i + h + 1]
            path_lo = low[i + 1:i + h + 1]
            ret[i] = close[i + h] / entry - 1.0
            mfe[i] = np.max(path_hi - entry)
            mae[i] = np.min(path_lo - entry)
        scale = atr.to_numpy(dtype=float)
        out[f"ret_{h}m"] = ret
        out[f"mfe_atr_{h}m"] = mfe / scale
        out[f"mae_atr_{h}m"] = mae / scale
    return out


def triple_barrier_labels(
    df: pd.DataFrame,
    spec: BarrierSpec,
    atr_window: int = 14,
    spread: float | pd.Series = 0.0,
    slippage: float | pd.Series = 0.0,
) -> pd.DataFrame:
    """Symmetric research label from next-bar executable price approximation.

    label: BUY if upper barrier hits first, SELL if lower first, WAIT on timeout/tie.
    Costs shift the effective entry adversely for both sides.
    """
    x = df.reset_index(drop=True).copy()
    atr = causal_atr(x, atr_window).to_numpy(dtype=float)
    close = x["close"].to_numpy(dtype=float)
    high = x["high"].to_numpy(dtype=float)
    low = x["low"].to_numpy(dtype=float)
    spr = np.broadcast_to(np.asarray(spread, dtype=float), len(x))
    slip = np.broadcast_to(np.asarray(slippage, dtype=float), len(x))
    labels = np.full(len(x), "UNRESOLVED", dtype=object)
    hit_bar = np.full(len(x), -1, dtype=int)
    for i in range(len(x)):
        if not np.isfinite(atr[i]) or i + spec.horizon >= len(x):
            continue
        entry = close[i]
        cost = max(0.0, spr[i]) + max(0.0, slip[i])
        upper = entry + cost + spec.tp_atr * atr[i]
        lower = entry - cost - spec.sl_atr * atr[i]
        resolved = "WAIT"
        bar_idx = spec.horizon
        for j in range(1, spec.horizon + 1):
            up = high[i + j] >= upper
            dn = low[i + j] <= lower
            if up and dn:
                resolved, bar_idx = "WAIT", j
                break
            if up:
                resolved, bar_idx = "BUY", j
                break
            if dn:
                resolved, bar_idx = "SELL", j
                break
        labels[i] = resolved
        hit_bar[i] = bar_idx
    return pd.DataFrame({
        "time": x["time"],
        "label": labels,
        "bars_to_outcome": hit_bar,
        "horizon_minutes": spec.horizon,
        "tp_atr": spec.tp_atr,
        "sl_atr": spec.sl_atr,
    })


def label_intervals(times: Iterable[pd.Timestamp], horizons: Iterable[int]) -> pd.DataFrame:
    start = pd.to_datetime(pd.Series(list(times)), utc=True)
    h = pd.Series(list(horizons), dtype="int64")
    if len(start) != len(h):
        raise ValueError("times/horizons length mismatch")
    return pd.DataFrame({"start": start, "end": start + pd.to_timedelta(h, unit="m")})


def uniqueness_weights(intervals: pd.DataFrame) -> np.ndarray:
    """Average inverse concurrency over each label interval, minute resolution."""
    if intervals.empty:
        return np.array([], dtype=float)
    starts = pd.to_datetime(intervals["start"], utc=True)
    ends = pd.to_datetime(intervals["end"], utc=True)
    grid = pd.date_range(starts.min().floor("min"), ends.max().ceil("min"), freq="1min", tz="UTC")
    concurrency = np.zeros(len(grid), dtype=int)
    for s, e in zip(starts, ends):
        mask = (grid >= s) & (grid <= e)
        concurrency[mask] += 1
    weights = []
    for s, e in zip(starts, ends):
        mask = (grid >= s) & (grid <= e)
        c = concurrency[mask]
        weights.append(float(np.mean(1.0 / c[c > 0])))
    return np.asarray(weights)


def purged_train_mask(intervals: pd.DataFrame, test_start: pd.Timestamp, test_end: pd.Timestamp, embargo_minutes: int) -> np.ndarray:
    """Keep train labels whose future interval cannot touch test/embargo window."""
    starts = pd.to_datetime(intervals["start"], utc=True)
    ends = pd.to_datetime(intervals["end"], utc=True)
    ts = pd.Timestamp(test_start)
    te = pd.Timestamp(test_end)
    ts = ts.tz_localize("UTC") if ts.tzinfo is None else ts.tz_convert("UTC")
    te = te.tz_localize("UTC") if te.tzinfo is None else te.tz_convert("UTC")
    blocked_start = ts - pd.Timedelta(minutes=embargo_minutes)
    blocked_end = te + pd.Timedelta(minutes=embargo_minutes)
    overlap = (starts <= blocked_end) & (ends >= blocked_start)
    return (~overlap).to_numpy(dtype=bool)
