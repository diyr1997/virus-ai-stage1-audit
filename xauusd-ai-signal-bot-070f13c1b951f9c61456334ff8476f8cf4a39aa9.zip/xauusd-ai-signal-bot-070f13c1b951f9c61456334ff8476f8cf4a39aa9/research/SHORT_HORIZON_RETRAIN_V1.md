# XAU/USD Short-Horizon Retraining V1

Status: research-only, no production trading changes.

## Goal
Optimize for fast intraday opportunities, not 5-24 hour directional forecasts. Primary horizons are 1/3/5/10/15/30/60 minutes, with strongest research focus on 3-15 minutes. M30/H1 are context/regime only unless OOS evidence proves direct short-horizon value.

## Non-negotiable rules
- Source clock: closed M1 candles only.
- Higher TF features are built causally from already-closed M1 only.
- Predictions are immutable once emitted.
- Labels may use future path only after the prediction timestamp and never as features.
- Purge overlapping train/test label intervals; embargo by max tested horizon; use uniqueness weights for overlapping labels.
- Model fills use next available execution point + spread/slippage assumptions, never signal-close fantasy fills.
- BUY and SELL are reported separately.
- No model is promoted from research directly into DEMO/production.

## Phase 0
1. Data integrity: ordering, duplicates, gaps, bad OHLC, timestamp/timezone consistency.
2. Leakage audit: closed-MTF, rolling/scalers, swings/fractals, news first-print/revisions, macro as-of timestamps.
3. Current-model forensics by TF/side/strength/session/hour/year.
4. Label A/B/C: current direction vs triple-barrier vs directional primary + meta trade/no-trade.
5. Null baselines: always BUY/SELL, previous return, H1 slope/session rules, logistic baseline.

## Phase 1 minimal challenger
- One horizon at a time, first 5/10/15m family; 30/60m as context and validation. Do not force a single 60m-only target.
- Minimal causal features: log returns, range/body/wicks, realized vol, ATR normalization, session/time, spread/tick activity when available, causal MTF snapshots.
- Models compared on identical frozen folds: Logistic/linear baseline, HistGradientBoosting (available now), then CatBoost/LightGBM in dedicated research environment.
- Calibration: Isotonic vs sigmoid/Beta-style challenger on frozen OOS predictions.
- WAIT = economic abstention when calibrated EV/trust is insufficient, while multiclass WAIT remains an A/B candidate.

## Labels
Triple-barrier labels are calculated from entry after signal time, with volatility-scaled TP/SL and a vertical time barrier. Start symmetric. BUY/SELL asymmetry is an experiment, never a default assumption.

For every signal timestamp also preserve auxiliary outcomes for 1/3/5/10/15/30/60m: signed return, MFE, MAE, first barrier, and time-to-first-barrier.

## Trust
Use Bayesian shrinkage, not permanent hard-coded buckets. Candidate hierarchy:
horizon x side x confidence x regime x session x volatility. Small cells shrink toward parent/global reliability.

## Regime
Phase 1 uses deterministic causal tags (trend/range, volatility bucket, session, news-window). HMM/GMM/BOCPD are challengers and stay only if they improve frozen OOS expectancy/calibration.

## Model complexity gate
Do not add L/M/R ensembles, PatchTST/TFT, separate news-direction, impulse, reversal or volatility networks until a single-model pipeline beats null baselines after costs. Every later component requires an ablation win.

## Historical replay
Inference is minute-by-minute; retraining is scheduled, not per minute. Replay progresses chronologically from early history to present. Each prediction stores timestamp, feature/model version and decision, then is resolved only after its horizon matures. No historical prediction is rewritten after future data arrives.

## Promotion
Research -> shadow only after integrity gates, purged OOS improvement, calibrated probabilities, positive expectancy after costs and robustness by BUY/SELL/year/session. Shadow -> champion requires a separate live DEMO observation period and no regression in safety.
