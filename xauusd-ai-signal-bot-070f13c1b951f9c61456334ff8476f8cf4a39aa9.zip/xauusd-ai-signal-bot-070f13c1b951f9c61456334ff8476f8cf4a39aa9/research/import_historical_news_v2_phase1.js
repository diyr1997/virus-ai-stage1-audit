"use strict";
const fs=require("fs"),path=require("path"),crypto=require("crypto"),zlib=require("zlib");
const {Pool}=require("pg");
const EVIDENCE_B64=path.join(__dirname,"evidence","historical_news_v2","historical-news-v2-bls-2003-2005.zip.b64");
const EXPECTED_DATASET="1482ef648a3f291b3a7f136cafa846b2f0f0e8a7b9ac0f2a55c94d295f15f17d";
const EXPECTED_ZIP_SHA="c818a64268a5e9fd7fc107e48e655efab89e8615f082315ec46a041a75c66e6e";
const EXPECTED_JSON_SHA="834aa60d1fdcaefb157863902aa36476aa6e94afad29497b32332383f4d5d552";
const ARTIFACT_DIGEST=`sha256:${EXPECTED_ZIP_SHA}`;
const SCRIPT_VERSION="phase1-import-v2";
const DRY_RUN=process.argv.includes("--dry-run");
const sha=b=>crypto.createHash("sha256").update(b).digest("hex");
function fail(m){throw new Error(m)}
function extractSingleZipJson(zip){
  if(sha(zip)!==EXPECTED_ZIP_SHA) fail("ARTIFACT_ZIP_SHA_MISMATCH");
  let cd=-1; for(let i=zip.length-22;i>=0;i--){if(zip.readUInt32LE(i)===0x06054b50){cd=i;break}}
  if(cd<0) fail("ZIP_EOCD_NOT_FOUND");
  const entries=zip.readUInt16LE(cd+10), centralOffset=zip.readUInt32LE(cd+16); if(entries!==1) fail(`ZIP_EXPECTED_ONE_ENTRY ${entries}`);
  const p=centralOffset; if(zip.readUInt32LE(p)!==0x02014b50) fail("ZIP_CENTRAL_HEADER_MISSING");
  const method=zip.readUInt16LE(p+10), compSize=zip.readUInt32LE(p+20), uncompSize=zip.readUInt32LE(p+24);
  const nameLen=zip.readUInt16LE(p+28), extraLen=zip.readUInt16LE(p+30), commentLen=zip.readUInt16LE(p+32), localOffset=zip.readUInt32LE(p+42);
  if(extraLen<0||commentLen<0) fail("ZIP_BAD_CENTRAL_LENGTH");
  const name=zip.subarray(p+46,p+46+nameLen).toString("utf8"); if(name!=="bls_2003_2005_release_index.json") fail(`ZIP_BAD_ENTRY ${name}`);
  if(zip.readUInt32LE(localOffset)!==0x04034b50) fail("ZIP_LOCAL_HEADER_MISSING");
  const lName=zip.readUInt16LE(localOffset+26),lExtra=zip.readUInt16LE(localOffset+28),start=localOffset+30+lName+lExtra;
  const compressed=zip.subarray(start,start+compSize); let raw;
  if(method===8) raw=zlib.inflateRawSync(compressed); else if(method===0) raw=compressed; else fail(`ZIP_METHOD_UNSUPPORTED ${method}`);
  if(raw.length!==uncompSize) fail(`ZIP_SIZE_MISMATCH ${raw.length}!=${uncompSize}`);
  if(sha(raw)!==EXPECTED_JSON_SHA) fail("EVIDENCE_JSON_SHA_MISMATCH"); return raw.toString("utf8");
}
function validatePayload(raw){
 const p=JSON.parse(raw),e=p.events;if(!Array.isArray(e)||e.length!==72)fail("EXPECTED_72_EVENTS");
 if(p.dataset_sha256!==EXPECTED_DATASET||sha(Buffer.from(JSON.stringify(e)))!==EXPECTED_DATASET)fail("DATASET_SHA_MISMATCH");
 const counts=new Map(),keys=new Set(),srcs=new Set();
 for(const [i,x] of e.entries()){
  if(!["CPI","EMPLOYMENT_SITUATION"].includes(x.family))fail(`BAD_FAMILY ${i}`);if(![2003,2004,2005].includes(Number(x.year)))fail(`BAD_YEAR ${i}`);
  if(!/^https:\/\/www\.bls\.gov\/news\.release\/(?:history|archives)\/(?:cpi|empsit)_\d{8}\.txt$/i.test(x.official_source))fail(`BAD_SOURCE ${i}`);
  if(!/^[0-9a-f]{64}$/i.test(x.raw_sha256))fail(`BAD_RAW_SHA ${i}`);if(!/^\d{8}$/.test(x.archive_date_code))fail(`BAD_ARCHIVE_CODE ${i}`);
  if(!["EST","EDT"].includes(x.eastern_zone)||![-300,-240].includes(Number(x.expected_utc_offset_minutes)))fail(`BAD_ZONE ${i}`);
  const d=new Date(x.event_time_utc);if(!Number.isFinite(d.getTime()))fail(`BAD_TIME ${i}`);const dow=d.getUTCDay();if(dow===0||dow===6)fail(`WEEKEND_RELEASE ${i}`);
  const k=`${x.family}|${x.event_time_utc}`;if(keys.has(k))fail(`DUP_FAMILY_TIME ${i}`);keys.add(k);if(srcs.has(x.official_source))fail(`DUP_SOURCE ${i}`);srcs.add(x.official_source);
  const ck=`${x.family}:${x.year}`;counts.set(ck,(counts.get(ck)||0)+1);
 }
 for(const f of ["CPI","EMPLOYMENT_SITUATION"])for(const y of [2003,2004,2005])if(counts.get(`${f}:${y}`)!==12)fail(`BAD_GROUP_COUNT ${f}:${y}`);
 return {payload:p,events:e};
}
function loadAndValidate(){const b64=fs.readFileSync(EVIDENCE_B64,"utf8").replace(/\s+/g,"");const zip=Buffer.from(b64,"base64");const raw=extractSingleZipJson(zip);return {raw,...validatePayload(raw)}}
const schemaSql=`CREATE TABLE IF NOT EXISTS research_historical_news_v2_manifests(id BIGSERIAL PRIMARY KEY,dataset_sha256 TEXT NOT NULL CHECK(dataset_sha256 ~ '^[0-9a-f]{64}$'),artifact_digest TEXT NOT NULL,evidence_json_sha256 TEXT NOT NULL CHECK(evidence_json_sha256 ~ '^[0-9a-f]{64}$'),schema_version INTEGER NOT NULL,expected_count INTEGER NOT NULL CHECK(expected_count=72),source_families JSONB NOT NULL,import_script_version TEXT NOT NULL,imported_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),UNIQUE(dataset_sha256,artifact_digest));
CREATE TABLE IF NOT EXISTS research_historical_news_v2_events(manifest_id BIGINT NOT NULL REFERENCES research_historical_news_v2_manifests(id) ON DELETE RESTRICT,ordinal INTEGER NOT NULL CHECK(ordinal BETWEEN 0 AND 71),family TEXT NOT NULL CHECK(family IN ('CPI','EMPLOYMENT_SITUATION')),release_year SMALLINT NOT NULL CHECK(release_year BETWEEN 2003 AND 2005),event_time_utc TIMESTAMPTZ NOT NULL,us_eastern_local TEXT NOT NULL,eastern_zone TEXT NOT NULL CHECK(eastern_zone IN ('EST','EDT')),expected_utc_offset_minutes SMALLINT NOT NULL CHECK(expected_utc_offset_minutes IN (-300,-240)),release_label TEXT,official_source TEXT NOT NULL CHECK(official_source ~ '^https://www\\.bls\\.gov/news\\.release/(history|archives)/(cpi|empsit)_[0-9]{8}\\.txt$'),archive_date_code TEXT NOT NULL CHECK(archive_date_code ~ '^[0-9]{8}$'),raw_sha256 TEXT NOT NULL CHECK(raw_sha256 ~ '^[0-9a-f]{64}$'),raw_bytes INTEGER NOT NULL CHECK(raw_bytes>0),retrieval_timestamp_utc TIMESTAMPTZ NOT NULL,event_json_text TEXT NOT NULL,PRIMARY KEY(manifest_id,ordinal),UNIQUE(manifest_id,family,official_source,event_time_utc));`;
const insertEventSql=`INSERT INTO research_historical_news_v2_events(manifest_id,ordinal,family,release_year,event_time_utc,us_eastern_local,eastern_zone,expected_utc_offset_minutes,release_label,official_source,archive_date_code,raw_sha256,raw_bytes,retrieval_timestamp_utc,event_json_text) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)`;
const groupSql="SELECT family,EXTRACT(YEAR FROM event_time_utc)::int AS release_year,COUNT(*)::int n FROM research_historical_news_v2_events WHERE manifest_id=$1 GROUP BY 1,2 ORDER BY 1,2";
async function run(){const {payload,events}=loadAndValidate();console.log(JSON.stringify({ts:new Date().toISOString(),stage:"validated",dry_run:DRY_RUN,events:72,dataset_sha256:EXPECTED_DATASET,artifact_digest:ARTIFACT_DIGEST}));if(DRY_RUN)return;
 const url=String(process.env.DATABASE_URL||"").trim();if(!url)fail("DATABASE_URL_REQUIRED");const pool=new Pool({connectionString:url,max:1});const c=await pool.connect();
 try{await c.query("BEGIN");await c.query("SELECT pg_advisory_xact_lock($1)",[26082301]);await c.query(schemaSql);const existing=await c.query("SELECT * FROM research_historical_news_v2_manifests WHERE dataset_sha256=$1",[EXPECTED_DATASET]);let mid;
  if(existing.rows.length){const m=existing.rows[0];if(m.artifact_digest!==ARTIFACT_DIGEST||m.evidence_json_sha256!==EXPECTED_JSON_SHA||Number(m.expected_count)!==72)fail("EXISTING_MANIFEST_MISMATCH");mid=m.id;const n=await c.query("SELECT COUNT(*)::int n FROM research_historical_news_v2_events WHERE manifest_id=$1",[mid]);if(n.rows[0].n!==72)fail("PARTIAL_IMPORT_DETECTED");}
  else{const ins=await c.query(`INSERT INTO research_historical_news_v2_manifests(dataset_sha256,artifact_digest,evidence_json_sha256,schema_version,expected_count,source_families,import_script_version) VALUES($1,$2,$3,$4,72,$5::jsonb,$6) RETURNING id`,[EXPECTED_DATASET,ARTIFACT_DIGEST,EXPECTED_JSON_SHA,Number(payload.schema_version||1),JSON.stringify(["CPI","EMPLOYMENT_SITUATION"]),SCRIPT_VERSION]);mid=ins.rows[0].id;
   for(let i=0;i<events.length;i++){const x=events[i];await c.query(insertEventSql,[mid,i,x.family,x.year,x.event_time_utc,x.us_eastern_local,x.eastern_zone,x.expected_utc_offset_minutes,x.release_label,x.official_source,x.archive_date_code,x.raw_sha256,x.raw_bytes,x.retrieval_timestamp_utc,JSON.stringify(x)])}}
  const rows=await c.query("SELECT ordinal,event_json_text FROM research_historical_news_v2_events WHERE manifest_id=$1 ORDER BY ordinal",[mid]);if(rows.rows.length!==72)fail("POST_COUNT_MISMATCH");const dbHash=sha(Buffer.from(`[${rows.rows.map(r=>r.event_json_text).join(",")}]`));if(dbHash!==EXPECTED_DATASET)fail(`POST_DATASET_SHA_MISMATCH ${dbHash}`);
  const groups=await c.query(groupSql,[mid]);if(groups.rows.length!==6||groups.rows.some(r=>r.n!==12))fail("POST_GROUP_MISMATCH");await c.query("COMMIT");console.log(JSON.stringify({ts:new Date().toISOString(),stage:"import_verified",manifest_id:mid,events:72,dataset_sha256:dbHash,groups:groups.rows}));
 }catch(e){try{await c.query("ROLLBACK")}catch{}throw e}finally{c.release();await pool.end()}}
module.exports={extractSingleZipJson,validatePayload,loadAndValidate,run,EXPECTED_DATASET,EXPECTED_ZIP_SHA,EXPECTED_JSON_SHA,ARTIFACT_DIGEST,schemaSql,insertEventSql,groupSql};if(require.main===module)run().catch(e=>{console.error(e.stack||e);process.exit(1)});
