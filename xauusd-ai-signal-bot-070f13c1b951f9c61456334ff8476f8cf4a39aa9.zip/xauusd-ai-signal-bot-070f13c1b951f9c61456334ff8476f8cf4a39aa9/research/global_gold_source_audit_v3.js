"use strict";

const crypto = require("crypto");

// Machine-readable coverage contract for the complete 2026-08-22 source universe.
// Research only: this registry cannot activate production news weights or trading logic.
const SOURCE_GROUPS = Object.freeze({
  "US": [
    "Fed/FOMC","New York Fed","BLS","BEA","U.S. Treasury/FiscalData","OFAC","CFTC","CME/COMEX","U.S. Census","White House","USTR","FRED/St. Louis Fed","USGS gold/mineral statistics","EIA"
  ],
  "CANADA_MEXICO": [
    "Bank of Canada","Statistics Canada","Finance Canada","CBSA","Banco de Mexico","INEGI","Mexico customs/tax trade source"
  ],
  "EUROPE_UK_SWITZERLAND": [
    "ECB","Eurostat","Bank of England","ONS","HMRC/UK Trade Info","LBMA","Swiss National Bank","Swiss Customs/BAZG","Swiss FSO","Bundesbank","Destatis","Banque de France","INSEE","Banca d'Italia","ISTAT","De Nederlandsche Bank","CBS Netherlands","Banco de Espana","INE Spain","National Bank of Poland","Statistics Poland","Czech National Bank","Hungarian National Bank","National Bank of Serbia"
  ],
  "CHINA_HK_TAIWAN": [
    "PBOC","SAFE","Shanghai Gold Exchange","NBS China","GACC Customs","MOFCOM","Ministry of Finance China","State Council China","China MFA","NDRC","HKMA","HKEX","Hong Kong Census & Statistics","Chinese Gold & Silver Exchange Society","Taiwan central bank","Taiwan Ministry of Finance","Taiwan Customs","TWSE"
  ],
  "JAPAN_KOREA": [
    "BOJ","Japan Ministry of Finance","METI","JPX/TOCOM/OSE","Bank of Korea","Statistics Korea","Korea Customs","KRX"
  ],
  "SOUTH_EAST_ASIA": [
    "MAS","SGX","SingStat","Singapore Customs","Bank of Thailand","Thai Customs","Bank Indonesia","Statistics Indonesia","ICDX","Bank Negara Malaysia","Malaysia official statistics/customs"
  ],
  "INDIA": [
    "RBI","India Ministry of Finance","India Ministry of Commerce","CBIC/Customs","DGFT","MCX"
  ],
  "TURKEY_RUSSIA_EURASIA": [
    "TCMB/EVDS","TurkStat","Borsa Istanbul","Bank of Russia","Russia Ministry of Finance","Rosstat","MOEX","Russia Customs","National Bank of Kazakhstan","Kazakhstan official statistics","Central Bank of Uzbekistan"
  ],
  "MIDDLE_EAST": [
    "UAE Central Bank","DMCC","DGCX","Dubai Customs","Saudi Central Bank","Saudi official statistics","Saudi Ministry of Energy","Qatar Central Bank","Bank of Israel","Israel CBS","TASE","Iran central bank/customs","OPEC"
  ],
  "AFRICA": [
    "SARB","Statistics South Africa","South Africa mining ministry","Bank of Ghana","Ghana Statistical Service","Ghana Minerals Commission","Ghana Gold Board (GoldBod)","BCEAO","Mali mining authority","Bank of Tanzania","Tanzania NBS/mining ministry","Reserve Bank of Zimbabwe","ZimStat","Zimbabwe mining ministry"
  ],
  "LATIN_AMERICA": [
    "Banco Central do Brasil","IBGE","Brazil trade source/Siscomex","B3","Peru central bank","INEI Peru","Peru mining ministry","SUNAT","Chile central bank","INE Chile","Cochilco","Argentina central bank","INDEC"
  ],
  "AUSTRALIA": [
    "RBA","Australian Bureau of Statistics","Perth Mint","ASX","Australia official mining/export statistics"
  ],
  "GLOBAL": [
    "IMF","BIS","World Bank","OECD","WTO","UN Comtrade","LBMA","World Gold Council","EIA","OPEC","IEA","EU sanctions sources","UN Security Council"
  ],
  "SECONDARY_CONFIRMATION": [
    "Reuters","Bloomberg","Associated Press"
  ],
  "MARKET_VALIDATION": [
    "Dukascopy XAUUSD spot","OctaFX historical spot"
  ]
});

const CADENCE_RULES = Object.freeze({
  EVENT_EXACT: { replay_mode:"M1_LAG", horizons:"0/1/2/3/5/10/15/30/60m", purpose:"timestamped release reaction" },
  INTRADAY_MARKET: { replay_mode:"INDEPENDENT_MARKET_CROSSCHECK", horizons:"M1+", purpose:"market-price validation only" },
  DAILY: { replay_mode:"DAILY_CONTEXT", horizons:"intraday/daily", purpose:"daily market/macro context" },
  WEEKLY: { replay_mode:"WEEKLY_CONTEXT", horizons:"daily/weekly", purpose:"positioning/weekly context" },
  MONTHLY: { replay_mode:"MONTHLY_CONTEXT", horizons:"release-day/daily/weekly", purpose:"reserve/trade/physical-flow context" },
  STRUCTURAL: { replay_mode:"STRUCTURAL_ONLY", horizons:"monthly/quarterly/annual", purpose:"slow regime feature; never M1 causal label" },
  CONFIRMATION: { replay_mode:"LEAD_LAG_CONFIRMATION", horizons:"event timestamp comparison", purpose:"corroboration only; no duplicate event impact" },
  UNKNOWN: { replay_mode:"PENDING_CLASSIFICATION", horizons:null, purpose:"must be classified before training" }
});

function slug(value){
  return String(value||"").normalize("NFKD").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"");
}

const OVERRIDES = Object.freeze({
  "Fed/FOMC": {role:"PRIMARY",cadence:"EVENT_EXACT",historical_status:"REPLAYED",evidence:"official Fed archive; strict exact-minute FOMC replay exists"},
  "BLS": {role:"PRIMARY",cadence:"EVENT_EXACT",historical_status:"REPLAYED",evidence:"official CPI and Employment Situation archives; strict exact-minute replay exists"},
  "BEA": {role:"PRIMARY",cadence:"EVENT_EXACT",historical_status:"KEEP_SHADOW",evidence:"official historical archive verified; 2004 PCE market-baseline quality gaps remain explicit"},
  "CFTC": {role:"PRIMARY",cadence:"WEEKLY",historical_status:"REPLAYED",evidence:"official legacy COT historical files extend through old years; weekly positioning, not M1 news"},
  "ECB": {role:"PRIMARY",cadence:"EVENT_EXACT",historical_status:"KEEP_SHADOW",evidence:"official decision history exists; exact historical clock proof must be retained per event before M1 eligibility"},
  "Bank of England": {role:"PRIMARY",cadence:"EVENT_EXACT",historical_status:"KEEP_SHADOW",evidence:"official historical MPC archive/schedules exist; exact clock proof required per event"},
  "SAFE": {role:"PRIMARY",cadence:"MONTHLY",historical_status:"KEEP_SHADOW",evidence:"official historical reserve series exists; detailed monthly gold reserve component semantics change in 2015"},
  "USGS gold/mineral statistics": {role:"PRIMARY",cadence:"STRUCTURAL",historical_status:"KEEP_SHADOW",evidence:"official annual supply statistics; structural only"},
  "World Gold Council": {role:"SECONDARY",cadence:"MONTHLY",historical_status:"KEEP_SHADOW",evidence:"secondary/reference gold-demand and reserve layer"},
  "Reuters": {role:"SECONDARY",cadence:"CONFIRMATION",historical_status:"KEEP_SHADOW",evidence:"corroboration/lead-lag only; never duplicate primary official impact"},
  "Bloomberg": {role:"SECONDARY",cadence:"CONFIRMATION",historical_status:"KEEP_SHADOW",evidence:"corroboration/lead-lag only; never duplicate primary official impact"},
  "Associated Press": {role:"SECONDARY",cadence:"CONFIRMATION",historical_status:"KEEP_SHADOW",evidence:"corroboration only; never duplicate primary official impact"},
  "Dukascopy XAUUSD spot": {role:"MARKET_REFERENCE",cadence:"INTRADAY_MARKET",historical_status:"KEEP_SHADOW",evidence:"primary research market feed; known sparse/missing historical M1 minutes remain fail-closed"},
  "OctaFX historical spot": {role:"MARKET_REFERENCE",cadence:"INTRADAY_MARKET",historical_status:"KEEP_SHADOW",evidence:"independent spot cross-check only; never fills/substitutes Dukascopy OHLC"},
  "CME/COMEX": {role:"MARKET_REFERENCE",cadence:"INTRADAY_MARKET",historical_status:"PENDING_HISTORICAL_AUDIT",evidence:"futures market layer; keep separate from spot"},
  "LBMA": {role:"MARKET_REFERENCE",cadence:"DAILY",historical_status:"PENDING_HISTORICAL_AUDIT",evidence:"benchmark/reference layer; not interchangeable with spot M1"},
  "Shanghai Gold Exchange": {role:"MARKET_REFERENCE",cadence:"INTRADAY_MARKET",historical_status:"PENDING_HISTORICAL_AUDIT",evidence:"regional gold market layer; separate instrument/venue"},
  "MCX": {role:"MARKET_REFERENCE",cadence:"INTRADAY_MARKET",historical_status:"PENDING_HISTORICAL_AUDIT",evidence:"regional futures layer; separate instrument/venue"},
  "DGCX": {role:"MARKET_REFERENCE",cadence:"INTRADAY_MARKET",historical_status:"PENDING_HISTORICAL_AUDIT",evidence:"regional futures layer; separate instrument/venue"},
  "JPX/TOCOM/OSE": {role:"MARKET_REFERENCE",cadence:"INTRADAY_MARKET",historical_status:"PENDING_HISTORICAL_AUDIT",evidence:"regional futures layer; separate instrument/venue"}
});

function defaultRole(group){
  if(group==="SECONDARY_CONFIRMATION")return "SECONDARY";
  if(group==="MARKET_VALIDATION")return "MARKET_REFERENCE";
  return "PRIMARY";
}

function buildRegistry(){
  const byName=new Map();
  for(const [group,names] of Object.entries(SOURCE_GROUPS)){
    for(const name of names){
      const prior=byName.get(name);
      if(prior){prior.regions.push(group);continue;}
      const override=OVERRIDES[name]||{};
      const cadence=override.cadence||"UNKNOWN";
      byName.set(name,{
        source_id:slug(name),
        name,
        regions:[group],
        role:override.role||defaultRole(group),
        cadence,
        replay_mode:CADENCE_RULES[cadence].replay_mode,
        historical_status:override.historical_status||"PENDING_HISTORICAL_AUDIT",
        evidence:override.evidence||"not yet individually replayed; retained explicitly for audit",
        training_eligible:false,
        production_eligible:false
      });
    }
  }
  const sources=[...byName.values()].sort((a,b)=>a.source_id.localeCompare(b.source_id));
  const payload={
    schema:"GLOBAL_GOLD_SOURCE_AUDIT_V3",
    research_only:true,
    generated_policy:"deterministic_registry_no_runtime_network",
    source_count:sources.length,
    status_counts:sources.reduce((m,s)=>(m[s.historical_status]=(m[s.historical_status]||0)+1,m),{}),
    cadence_counts:sources.reduce((m,s)=>(m[s.cadence]=(m[s.cadence]||0)+1,m),{}),
    sources
  };
  payload.registry_sha256=crypto.createHash("sha256").update(JSON.stringify(payload.sources)).digest("hex");
  return payload;
}

function trainingEligible(source, pointInTimeEvidence=false){
  if(!source||source.production_eligible)return false;
  if(!pointInTimeEvidence)return false;
  return source.historical_status==="REPLAYED" && source.cadence!=="UNKNOWN";
}

if(require.main===module) process.stdout.write(JSON.stringify(buildRegistry(),null,2)+"\n");
module.exports={SOURCE_GROUPS,CADENCE_RULES,OVERRIDES,slug,buildRegistry,trainingEligible};
