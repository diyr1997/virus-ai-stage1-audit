"use strict";

const fs = require("fs");
const path = require("path");

async function probe(url, headers = {}) {
  const started = Date.now();
  try {
    const res = await fetch(url, { headers, redirect: "follow" });
    const text = await res.text();
    let json = null;
    try { json = JSON.parse(text); } catch {}
    return {
      url: url.replace(/([?&](?:c|k|s|t)=)[^&]+/gi, "$1REDACTED"),
      status: res.status,
      ok: res.ok,
      content_type: res.headers.get("content-type"),
      elapsed_ms: Date.now() - started,
      body_preview: text.slice(0, 1200),
      json_count: Array.isArray(json) ? json.length : null,
      json_sample: Array.isArray(json) ? json.slice(0, 2) : json,
    };
  } catch (error) {
    return { url, status: 0, ok: false, elapsed_ms: Date.now() - started, error: String(error?.message || error) };
  }
}

async function main() {
  const teKey = process.env.TRADING_ECONOMICS_API_KEY || "guest:guest";
  const te = await probe(`https://api.tradingeconomics.com/calendar/country/united%20states/2003-01-01/2003-12-31?c=${encodeURIComponent(teKey)}`);
  const fx = await probe("https://calendar.fxstreet.com/eventdate/?view=range&start=20030101&end=20030131&countrycode=US&f=json");
  const payload = {
    research_only: true,
    probed_at_utc: new Date().toISOString(),
    trading_economics: te,
    fxstreet: fx,
    interpretation: {
      te_guest_historical_available: Boolean(te.ok && (te.json_count === null || te.json_count > 0)),
      fxstreet_unauthenticated_available: Boolean(fx.ok),
    },
  };
  const out = path.join(__dirname, "output", "historical_news_v2");
  fs.mkdirSync(out, { recursive: true });
  fs.writeFileSync(path.join(out, "calendar_provider_probe_2003_2005.json"), JSON.stringify(payload, null, 2) + "\n");
  console.log(JSON.stringify(payload, null, 2));
}

main().catch((error) => { console.error(error?.stack || error); process.exit(1); });
