"use strict";

const fs=require("fs");
const path=require("path");
const crypto=require("crypto");
const {fetchWindow,computeEventMetrics,terminalError}=require("./phase1_reaction_metrics_v2");

const FED_RELEASE_TIME_EVIDENCE="https://www.federalreserve.gov/boarddocs/speeches/2004/20040505/default.htm";
const BEA_2004_CALENDAR_EVIDENCE="https://www.bea.gov/news/2003/personal-income-november-2003";
const FORECAST_STATUS="NO_VERIFIED_CONTEMPORANEOUS_CONSENSUS_YET";
const DST_2004_START_DATE="2004-04-04";
const DST_2004_END_DATE="2004-10-31";

function easternOffsetMinutes2004(date){
  if(!/^2004-\d{2}-\d{2}$/.test(date)) throw new Error(`EASTERN_2004_DATE_REQUIRED ${date}`);
  return date>=DST_2004_START_DATE&&date<DST_2004_END_DATE?-240:-300;
}
function easternLocalToUtc2004(date,time){
  const offset=easternOffsetMinutes2004(date);
  const [hh,mm,ss="00"]=String(time).split(":");
  const localMs=Date.parse(`${date}T${hh}:${mm}:${ss}.000Z`);
  if(!Number.isFinite(localMs)) throw new Error(`INVALID_LOCAL_TIME ${date} ${time}`);
  return {utc:new Date(localMs-offset*60000).toISOString(),offset};
}
function fomc(dateCompact,actual,previous){
  const date=`2004-${dateCompact.slice(4,6)}-${dateCompact.slice(6)}`;
  const {utc,offset}=easternLocalToUtc2004(date,"14:15:00");
  return {id:`${date}_FOMC`,family:"FOMC",event_type:"FOMC_STATEMENT",metric:"target_federal_funds_rate_pct",event_time_utc:utc,us_eastern_local:`${date}T14:15:00`,expected_utc_offset_minutes:offset,official_source:`https://www.federalreserve.gov/boarddocs/press/monetary/2004/${dateCompact}/default.htm`,timestamp_source:FED_RELEASE_TIME_EVIDENCE,timestamp_basis:"Federal Reserve official 2004 description: regular-meeting news release about 2:15 p.m. ET",actual,previous_pre_release:previous,forecast:null,forecast_status:FORECAST_STATUS};
}
function pce(id,date,slug){
  const {utc,offset}=easternLocalToUtc2004(date,"08:30:00");
  return {id,family:"PCE",event_type:"PERSONAL_INCOME_AND_OUTLAYS",metric:"pce_price_index",event_time_utc:utc,us_eastern_local:`${date}T08:30:00`,expected_utc_offset_minutes:offset,official_source:`https://www.bea.gov/news/2004/${slug}`,timestamp_source:BEA_2004_CALENDAR_EVIDENCE,timestamp_basis:"BEA historical release calendar plus release-page 8:30 A.M. EST/EDT embargo",actual:null,previous_pre_release:null,forecast:null,forecast_status:FORECAST_STATUS,value_parse_status:"PILOT_SOURCE_AND_M1_AVAILABILITY_ONLY"};
}

const FOMC_EVENTS=[
  fomc("20040128",1.00,1.00),fomc("20040316",1.00,1.00),fomc("20040504",1.00,1.00),fomc("20040630",1.25,1.00),
  fomc("20040810",1.50,1.25),fomc("20040921",1.75,1.50),fomc("20041110",2.00,1.75),fomc("20041214",2.25,2.00),
];
const PCE_EVENTS=[
  pce("2004-02-02_PCE_DEC2003","2004-02-02","personal-income-and-outlays-december-2003"),
  pce("2004-03-01_PCE_JAN2004","2004-03-01","personal-income-and-outlays-january-2004"),
  pce("2004-03-26_PCE_FEB2004","2004-03-26","personal-income-and-outlays-february-2004"),
  pce("2004-04-30_PCE_MAR2004","2004-04-30","personal-income-and-outlays-march-2004"),
  pce("2004-05-28_PCE_APR2004","2004-05-28","personal-income-april-2004"),
  pce("2004-06-28_PCE_MAY2004","2004-06-28","personal-income-may-2004"),
  pce("2004-08-03_PCE_JUN2004","2004-08-03","personal-income-june-2004"),
  pce("2004-08-30_PCE_JUL2004","2004-08-30","personal-income-july-2004"),
  pce("2004-09-30_PCE_AUG2004","2004-09-30","personal-income-august-2004"),
  pce("2004-11-01_PCE_SEP2004","2004-11-01","personal-income-september-2004"),
  pce("2004-12-01_PCE_OCT2004","2004-12-01","personal-income-october-2004-0"),
  pce("2004-12-23_PCE_NOV2004","2004-12-23","personal-income-november-2004"),
];
const PILOT_EVENTS=[...FOMC_EVENTS,...PCE_EVENTS].sort((a,b)=>a.event_time_utc.localeCompare(b.event_time_utc));

function sha256(v){return crypto.createHash("sha256").update(String(v)).digest("hex")}
function pilotSummary(results){
  const retrieval=results.filter(x=>x.status==="RETRIEVAL_ERROR").length;
  const missing=results.filter(x=>Object.values(x.horizons||{}).some(h=>h?.status==="MISSING_M1")||x.reversal?.status==="MISSING_M1").length;
  const invalid=results.filter(x=>Object.values(x.horizons||{}).some(h=>h?.status==="INVALID_OHLC")||x.reversal?.status==="INVALID_OHLC").length;
  const baselineUnavailable=results.filter(x=>x.status==="MISSING_OR_INVALID_BASELINE_T_MINUS_1");
  const unusableReaction=results.filter(x=>x.status!=="OK"&&x.status!=="RETRIEVAL_ERROR"&&x.status!=="EXCLUDED_PRE_BOUNDARY");
  const unusableStatuses=[...new Set(unusableReaction.map(x=>x.status||"MISSING_STATUS"))].sort();
  const n=results.length;
  return {events:n,retrieval_errors:retrieval,retrieval_error_rate:n?retrieval/n:null,missing_m1_events:missing,missing_m1_rate:n?missing/n:null,invalid_ohlc_events:invalid,baseline_unavailable_events:baselineUnavailable.length,unusable_reaction_events:unusableReaction.length,unusable_reaction_statuses:unusableStatuses,quality_gate:n===20&&retrieval/n<=0.05&&missing/n<=0.10&&invalid===0&&baselineUnavailable.length===0&&unusableReaction.length===0?"PASS":"FAIL",required_events:20,required_retrieval_error_rate_max:0.05,required_missing_m1_rate_max:0.10,required_invalid_ohlc_events_max:0,required_baseline_unavailable_events_max:0,required_unusable_reaction_events_max:0,pilot_semantics:"workflow/data-availability validation only; not statistical reaction inference"};
}
async function main(){
  if(PILOT_EVENTS.length!==20) throw new Error(`PILOT_EXPECTED_20_EVENTS got=${PILOT_EVENTS.length}`);
  const results=[];
  for(let i=0;i<PILOT_EVENTS.length;i++){
    const e={...PILOT_EVENTS[i],ordinal:i};
    console.log(`FOMC_PCE_PILOT ${i+1}/${PILOT_EVENTS.length} ${e.family} ${e.event_time_utc}`);
    try{const rows=await fetchWindow(e);results.push(computeEventMetrics(e,rows));}
    catch(err){results.push(terminalError(e,"RETRIEVAL_ERROR",err?.message||err));}
  }
  const summary=pilotSummary(results);
  const payload={schema_version:3,research_only:true,pilot_only:true,point_in_time_policy:"official Fed/BEA release pages only for event/timestamp/action provenance; forecast remains null until a contemporaneous pre-release source is verified",no_interpolation:true,generated_at_utc:new Date().toISOString(),manifest_sha256:sha256(JSON.stringify(PILOT_EVENTS)),summary,events:results};
  const out=path.join(__dirname,"output","historical_news_v2","fomc_pce_pilot_2004.json");fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,JSON.stringify(payload,null,2)+"\n");console.log(JSON.stringify(summary,null,2));if(summary.quality_gate!=="PASS")process.exitCode=2;
}
module.exports={PILOT_EVENTS,FOMC_EVENTS,PCE_EVENTS,FED_RELEASE_TIME_EVIDENCE,BEA_2004_CALENDAR_EVIDENCE,FORECAST_STATUS,DST_2004_START_DATE,DST_2004_END_DATE,easternOffsetMinutes2004,easternLocalToUtc2004,pilotSummary};
if(require.main===module)main().catch(e=>{console.error(e?.stack||e);process.exit(1)});
