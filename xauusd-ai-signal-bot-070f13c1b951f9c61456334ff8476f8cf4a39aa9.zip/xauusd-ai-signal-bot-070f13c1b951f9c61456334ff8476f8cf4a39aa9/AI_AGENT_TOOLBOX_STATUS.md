# AI Agent Toolbox — status ledger

Last updated: 2026-09-11, by Claude Code.

## 2026-09-15 update (pass 3) — remaining skill packs, parity tests, final review

Detail: `AI_TOOLBOX_FINAL_AUDIT_2026-09-15.md` → "Pass 3 results".

- **Strix — BLOCKED, genuine, NOT overridden.** Fresh payload-only scan (commit
  `84f4108`): 9 HIGH, all in the installable payload, all one real pattern —
  the skills instruct the agent to run `curl -sSL https://strix.ai/install | bash`
  (`AGENTS.md:30` and four SKILL.md locations). Unblocking needs a digest-pinned
  release artifact instead of `curl | bash`.
- **Matt Pocock Skills — REJECTED as a duplicate, and the old "blocked by
  scanner" framing was WRONG.** 7 of 9 HIGHs are false positives, two with
  inverted meaning (`git reset --hard` flagged inside a `DANGEROUS_PATTERNS`
  array of a hook that *blocks* it). Real reason not to install: its
  Wayfinder/handoff concepts are now native in `CONTEXT.md`/`PROJECT_STATE.md`.
- **Anthropic Skills — REJECTED as a duplicate, also mis-flagged.** All 9
  "Prompt Injection" HIGHs match only the **UTF-8 BOM** in standard ECMA OOXML
  `.xsd` files; the lone YARA hit fires on docs containing `tools=`. Decisive:
  `ListSkills` shows `docx`, `pptx`, `xlsx`, `pdf`, `skill-creator` are **already
  enabled in this session**.
- **Google Skills — BLOCKED, and the scan itself did not complete.** 819 issues
  but `coverage_percent=0.0`, `is_complete=false`, 781 files only partially
  inspected, 8 `obfuscated_instruction_text` exceptions — so it is neither a
  clean result nor a definitive block. One genuine CRITICAL: a credential →
  network taint (`os.environ.get` → `urllib.request.urlopen`) in
  `skills/cloud/iam-helper-for-troubleshooting/scripts/troubleshooting_error_id.py:149`.
  Stronger reason to skip it: **the project has no Google Cloud footprint** (it
  runs on Railway + PostgreSQL), and the findings concentrate in
  `skills/cloud/*`, `skills/ads/*`, `plugins/cloud/*`. Cherry-pick and scan
  individual skills alone if any are still wanted.
- **purgedcv — downgraded ACTIVE → READY by a real parity test.** Native
  expanding-window walk-forward leaks **0**; purgedcv leaks **0**; but the native
  purge-only rule transplanted into a k-fold layout leaks **60 backward
  violations**. So it duplicates the current design and becomes necessary only if
  the project moves to k-fold/CPCV. Test committed:
  `tools/research_env/parity_purgedcv_vs_native.py`.
- **orderflow-metrics — formula parity PASS, stays WATCH.** No native OFI exists
  *by design* (`sampled_quotes.py` refuses OFI/CVD/L2 and a test asserts feature
  names never claim them), so parity ran against the hand-implemented canonical
  Cont-Kukanov-Stoikov formula: 8/8 fixtures, 5000 randomized trials, cumulative
  and `depth_imbalance` all exact. Correct arithmetic is not an edge and does not
  license relabelling sampled L1 as order flow.
- **Ponytail — stays READY.** No native `/plugin` flow exists in this session
  (`ListPlugins` empty **and** `SearchPlugins` finds nothing). Activation is two
  user commands: `/plugin marketplace add DietrichGebert/ponytail`, then
  `/plugin install ponytail@ponytail`, then verify with `/plugin`.
- **OmniRoute — explicitly NOT a completion blocker.** Stays `NEEDS_CONFIG`;
  nothing else in the toolbox depends on it.
- **Final diff/security review:** the PR is **100% additive** (4,412 insertions,
  0 deletions). The only executable content is three `tools/research_env/`
  scripts with no subprocess/eval/network/file-write/credential access. Secret
  scan clean. All three scripts re-run green.

## 2026-09-15 update (pass 2) — fresh security gate + functional verification

**The 2026-09-10 Railway audit is superseded for every tool named here.** Full
detail and evidence: `AI_TOOLBOX_FINAL_AUDIT_2026-09-15.md`.

Correction to pass 1: `git clone` of arbitrary public GitHub repos **does** work
in this environment (only the HTTP API is scoped), so pass 2 cloned, installed
and ran the real tools instead of reasoning about them.

- **NVIDIA SkillSpector 2.11.2** (commit `03e8f56b`) — freshly installed and run
  as the gate; now `ACTIVE`. Static-only: its semantic analyzers are skipped
  without an API key. **Method correction:** scan the *installable payload*, not
  the whole repo — whole-repo scans flag benchmarks/tests/docs that are never
  installed.
- **Graphify 0.9.61** — `ACTIVE`. Indexed this repo for real: **3841 nodes,
  9160 edges, 345 files**; dependency query found the decision core
  (`trading_ai/economic_labels.py:166`), impact query returned the 12 modules
  affected by `validate_candles()`. 4 payload HIGHs reviewed → all false
  positives (`rm -f` scoped to its own cache; "without warning" matched inside a
  sentence telling the agent *to* warn).
- **Ponytail 4.10.0** — `READY`. Payload scan clean (0 issues); its full-repo
  CRITICAL is 100% benchmarks/tests/docs. Its rule *"Never simplify away: input
  validation at trust boundaries..."* was tested against a real trap
  (`_validated_closes` is the only NaN guard, since NaN comparisons pass
  `validate_candles` silently) and correctly protects it. Only remaining step is
  the user running the two `/plugin` commands.
- **Andrej Karpathy Skills** — `WATCH`, security-clean but a third overlapping
  rule source next to `AGENTS.md` + Ponytail. Deliberately not installed.
- **Headroom (`headroom-ai` 0.37.0 — PyPI `headroom` is an unrelated squat)** —
  `ISOLATED_TEST`. Real benchmark: 96.3% reduction on identifier-heavy output
  (lossy), **65.6% reduction with 0 of 5961 numbers lost** on structured numeric
  evidence. Never place it in front of audit logs/evidence without a lossless check.
- **OmniRoute 3.8.50** — `NEEDS_CONFIG`, and this **downgrades** the old claim:
  doctor 0 failures and `health=healthy`, but `compression status` → HTTP 503
  ("MCP server is disabled") and **no completion was ever obtained**. The
  2026-09-10 "compression=PASS" is not reproducible by default. New security
  finding: `serve` binds `0.0.0.0` with no API-key requirement on `/v1/*`.
- **Optuna / ruptures / purgedcv** — `ACTIVE`, now reproducible from pinned
  `tools/research_env/requirements.txt`, verified green from a clean venv by
  `tools/research_env/verify_research_env.py`. Research-only.
- **QM** — `ISOLATED_TEST`. Railway read access works; service live, deployment
  SUCCESS, and `variableNames: []` confirms **zero secrets injected**. But no
  `QM_TOOLBOX_READY` marker in retained logs, so boot is still unverified.
- **Scout and Valet exist** — both confirmed by direct clone (MIT). The earlier
  `EXISTENCE_UNCONFIRMED` was a search-indexing gap.
- **Fynance** — `REJECTED`. No such repo found; purgedcv already provides its
  listed capabilities (CPCV, deflated/probabilistic Sharpe, PBO).
- **`CONTEXT.md` and `PROJECT_STATE.md` were created** (ported and corrected).
  They currently exist **only on the PR branch
  `claude/toolbox-master-completion-2026-09-15` (PR #225)** — they are **not on
  `main`** until that PR is merged, so `AGENTS.md`'s reference to them is still
  dangling on `main`. The toolbox branch was reconciled file-by-file — **never
  merge it**, it would delete large amounts of current work.
- **Google Drive**: master doc could not be edited in place (connector supports
  title/parent only, not body). A companion doc
  `1LSG3Fphtt3DLrbHEWBIUi6bg9ImbGxFq0GXRMj1Kt7k` was created in the same folder
  and read back to confirm.

Final distribution across all 72: ACTIVE 8, ISOLATED_TEST 8, WATCH 6, BLOCKED 6,
NOT_USEFUL 4, REJECTED 2, READY 1, NEEDS_CONFIG 1, BROKEN 1, NOT_APPLICABLE 1,
NEEDS_KEY 1, NOT_INSTALLED 33 (each with an explicit "no capability gap today"
justification — heavy tools are not installed for inventory completeness).

## 2026-09-15 update (pass 1) — master completion audit

A full re-audit (`AI_TOOLBOX_FINAL_AUDIT_2026-09-15.md`,
`AI_TOOLBOX_MASTER_INVENTORY_2026-09-15.json`,
`AI_TOOLBOX_ADOPTION_MATRIX_2026-09-15.json`, same commit) expanded this
ledger's scope from the 23 items below (24 incl. QM) plus the 19 Google Drive
donor candidates (43 total baseline) to **72 unique candidates**, after also
reading `tools/quant_toolbox/manifest.json`, `tools/ml_challenger/manifest.json`,
`tools/news_toolbox/manifest.json` (all on the unmerged
`ai/integrate-agent-toolbox-2026-09-10` branch, not previously cross-referenced
here) and several unmerged shadow-model research branches. Headline changes
since 2026-09-11:

- Optuna, ruptures, purgedcv **re-verified with real deterministic tests in
  this session** (fresh isolated venv, no project deps) — all PASS. purgedcv's
  constructor API has changed upstream since it was last checked; the corrected
  signature is documented in the new audit.
- `orderflow-metrics`'s upstream is now resolved: `github.com/twowaymind/orderflow-metrics`
  (MIT, PyPI `orderflow-metrics==0.29.0`). Previously unresolved.
- `ruflo` confirmed dead (control-plane probe failed rc=128; its own audit
  script was already removed from this repo on 2026-09-11) — stays
  `BROKEN`/`REJECTED`.
- `Fynance` remains unresolved — independent WebSearch this session found no
  matching repository. Not invented; still blocked.
- Existence of ~20 of the smaller/less-known repos in this ledger (Ponytail,
  Graphify, OmniRoute, Andrej Karpathy Skills, QM, Strix, SkillSpector,
  DeepSeek Harness, headroom, claude-mem, hermes-agent, Agent-Reach, OpenCLI,
  Kronos, etc.) was independently re-confirmed via WebSearch this session
  (direct GitHub fetch is blocked for this session outside the project repo's
  own scope, by design). All confirmed real except two that could not be
  independently confirmed: `pedrobraiti/market-research-mcp` (Scout) and
  `pedrobraiti/agentic-trading-mcp` (Valet) — marked `EXISTENCE_UNCONFIRMED`,
  not rejected outright, pending a re-check of the exact URL.
- New candidates found and not previously tracked anywhere in this project:
  Microsoft Qlib, Microsoft RD-Agent, QuantConnect LEAN, vectorbt, tsfresh,
  River, NeuralForecast, OpenBB, FinGPT, FinBERT, FinRobot, FinRL, CCXT,
  Hummingbot, PyTorch Forecasting (DeepAR/DeepVAR), Crawl4AI, news-please,
  Trafilatura, Newspaper4k, Firecrawl, RSSHub, Perplexity MCP, Chronos-2,
  Moirai-2.0/uni2ts (CC-BY-NC-4.0 — production use excluded), FinCast
  (hardware-blocked), TimesFM-2.5, `spotware/OpenApiPy`, and
  `stefan-jansen/machine-learning-for-trading` (already in active use as
  Trading School reading material, not a new install).
- Everything else below (Tier 1-4) is carried forward **unverified this
  session** — it still cites the 2026-09-10 Railway audit as its evidence,
  exactly as before. This update does not silently upgrade any status; see
  the new audit file for exactly what was and was not re-tested.
- `CONTEXT.md` and `PROJECT_STATE.md`, referenced by `AGENTS.md` and
  `tools/ai_toolbox/TOOLBOX_TOPOLOGY.md` as the durable memory files, **do not
  exist on `main`**. Recorded as a gap, not fixed in this pass.

This file is the single place where Claude, ChatGPT, and any other project AI can check
what is actually installed/working versus what only exists as a starred GitHub repo.
**A repository being starred or cloned is not evidence that a tool is active.** Every
status below is grounded in one of two verifiable sources, both cited per tool:

- **Railway audit** — a real, executed install/test run in the isolated
  `virus-ai-agent-toolbox-20260910` Railway project, service
  `priority-ponytail-omniroute-architect`, branch
  `ai/integrate-agent-toolbox-2026-09-10`, commit `825dae8`, deployment
  `3d4ed44b-4257-4db4-8f1b-bd7b02853ff9` (SUCCESS, 2026-09-10). Full status table
  emitted by the run itself as `AI TOOLBOX STATUS`. This branch is **not merged to
  `main`** — none of its effects exist in production or in this Claude Code session
  until reviewed and merged.
- **Claude Code session** — verified directly in this session (MCP connection live,
  command actually run here, etc).

Anything not covered by either source is marked `NOT_INSTALLED` / `UNTESTED`. Nothing
in this file is invented.

## Status legend

- `READY` — installed, configured, passed its test, safe to use as designed.
- `ACTIVE` — currently in use in this project's actual workflow (not just installed).
- `NEEDS_CONFIG` — installed but missing configuration/credentials to do anything useful.
- `NEEDS_KEY` — requires a paid/API key we have not provisioned.
- `BLOCKED` — installed but held back by our own security gate (SkillSpector) or a
  failed functional test. Not silently bypassed, per project policy.
- `BROKEN` — attempted and failed.
- `NOT_INSTALLED` — no verified install anywhere.
- `NOT_USEFUL` — works, but has no real application to this project.
- `REJECTED` — evaluated and intentionally not activated.

## Priority order (usefulness for our actual workflow, not popularity)

1. **Ponytail** — reduce unnecessary work/code before generation
2. **Graphify** — search/query repo structure instead of reading everything
3. **context7** (MCP, already live) — current library docs instead of guessing from training data
4. **OmniRoute** — cheap/free-tier model routing + context compression (partially proven — see below)
5. **AI System Architect** (component of Awesome LLM Apps) — plan before generating code
6. **Andrej Karpathy Skills** — coding-discipline guardrail (assumptions, simplicity, surgical changes)
7. **DeepSeek Harness** — execution-orchestrator candidate (isolated, not promoted)
8. **Matt Pocock Wayfinder/handoff pattern** — multi-session continuity (reimplemented natively, not via the upstream skill pack)
9. **Built-in Claude Code `code-review` / `security-review` skills** — already available, no install needed
10. **NVIDIA SkillSpector** — our security gate for every other skill/MCP payload
11. **Google Skills** — selective specialist catalog (blocked, see below)
12. **Anthropic Skills** — reference patterns (blocked, see below)
13. **Strix** — authorized app-security testing (blocked, see below)
14. **Humanizer** — prose polish only, low relevance to this project
15. **AirLLM** — large-model inference on constrained hardware, no matching use case here
16. Everything below: **not evaluated yet**, lowest priority for a trading-safety project — `ruflo`, `hermes-agent`, `Agent-Reach`, `OpenCLI`, `playwright-cli`, `headroom`, `claude-mem`, `public-apis`, `supabase` (MCP, unused so far)

## Full inventory (23 GitHub items)

### Tier 1 — verified working today

| # | Tool | Repo | Purpose | How Claude Code should use it | Installed | Configured | Working | API key? | Paid? | Via subscription? | Cuts tokens? | How | Free-tier/limits created? | Real limits | Security risk |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | Ponytail | `DietrichGebert/ponytail` | Pre-generation guardrail: write only what the task needs | Run its decision ladder mentally/via skill before writing code; matches what I already try to do by default | Cloned+skill-installed in Railway audit only (SkillSpector PASS); **not installed in this Claude Code session** | NOT_CONFIGURED here | Claude Code native install exists (`/plugin marketplace add DietrichGebert/ponytail` then `/plugin install ponytail@ponytail`) but requires the user to run it — not a tool available to me | No | No | Yes (npm/plugin, free) | Claims 54% less code / 20% lower cost in its own benchmark (unverified by us independently) | fewer generated tokens/lines | No | Self-reported benchmark, not measured on this project | Low — passed static scan |
| 2 | Graphify | `Graphify-Labs/graphify` | Local code/doc knowledge graph | Query dependency/impact paths instead of reading the whole repo before a change | Railway audit: cloned, pip-installed, CLI ran | CONFIGURED (code-only mode, no semantic-model key) | **WORKING** — produced a real graph of this exact repo: 2944 nodes, 7294 edges, 223 source files | Optional (semantic mode needs one; code-only mode doesn't) | No (code-only) | N/A | Yes | avoids reading full files for impact analysis | No | Code-only mode loses semantic/NL search | Low |
| 3 | context7 | `upstash/context7` | Current library/API docs for LLMs | Already an MCP server in this session (`mcp__Context7__*`) — use before answering framework/API questions | **Installed (MCP)** | CONFIGURED | **WORKING**, used earlier this session | No (proxied) | Free tier exists upstream | Yes, via this session's MCP | Indirectly — avoids wrong/outdated answers needing correction | avoids re-work | Has its own upstream rate limits (unverified exact numbers) | Unknown to us | Low |
| 4 | OmniRoute | `diegosouzapw/OmniRoute` | Multi-provider AI gateway: routing/fallback/compression/MCP/A2A | Route only non-critical helper calls to cheap/free models; never architecture/trading/safety/security decisions | Railway audit: cloned, npm-installed | CONFIGURED: `compression.enabled=true`, `defaultMode=stacked` — **confirmed by its own doctor/health check**, not just claimed | **PARTIALLY WORKING** — see dedicated section below | Depends on provider(s) routed | Provider-dependent | Not directly — it's a routing layer, not part of Claude's own subscription | Yes, if it works | prompt/context compression + cheaper models for non-critical calls | Provider-specific, see below | See below | Medium — a routing layer between us and third-party model providers; never gets our real API keys per policy |
| 5 | Andrej Karpathy Skills | `multica-ai/andrej-karpathy-skills` | Coding discipline: assumptions, simplicity, surgical changes | Background discipline, same spirit as this project's own `AGENTS.md` rules | Railway audit: cloned, skill-installed | CONFIGURED | **WORKING** (SkillSpector PASS, install PASS) | No | No | Yes (skill pack) | Marginal | encourages smaller diffs | No | Static scan only, not exhaustive | Low |
| 6 | NVIDIA SkillSpector | `NVIDIA/SkillSpector` | Static security scanner for agent skills/MCP payloads | Run before trusting any new external skill; already gated the run below | Railway audit: installed, ran as bootstrap gate | CONFIGURED | **WORKING** — this is the tool that produced every PASS/FAIL/BLOCKED verdict below | No | No | Yes | No — it's a gate, not a compressor | N/A | N/A | Static analysis only; flagged 4 of 13 packs (including Anthropic's own official skills repo) — treat as signal, not proof, but we don't override it without review | Low (it's the safety tool itself) |

### Tier 2 — blocked by our own security gate (not bypassed)

| # | Tool | Repo | Why blocked | What would unblock it |
|---|---|---|---|---|
| 7 | Strix | `usestrix/strix` | SkillSpector static scan **FAILED**; agent-skill activation BLOCKED | Manual review of the specific static findings (log was inside the now-gone ephemeral Railway container — not recoverable; would need a fresh scan) |
| 8 | Google Skills | `google/skills` | SkillSpector static scan **FAILED** on the full pack; BLOCKED | Cherry-pick only the specific architecture/reliability skills we need instead of the whole catalog, then re-scan just those |
| 9 | Anthropic Skills | `anthropics/skills` | SkillSpector static scan **FAILED**; BLOCKED | Re-scan; this is plausibly a false positive on official Anthropic content, but per project policy we do not silently override a failed gate — needs an actual look at the findings first |
| 10 | Matt Pocock Skills | `mattpocock/skills` | SkillSpector static scan **FAILED** on the full pack; BLOCKED | The *concepts* (Wayfinder, handoff) are already reimplemented natively in `AGENTS.md`/`CONTEXT.md`/`PROJECT_STATE.md` without needing the upstream skill activated |

### Tier 3 — installed/tested but not promoted

| # | Tool | Repo | Status | Note |
|---|---|---|---|---|
| 11 | DeepSeek Harness | `deepseek-ai/deepseek-harness` | INSTALLED / CONFIGURED / smoke-tested only | Upstream is explicitly "developer preview"; kept as an isolated execution-orchestrator **candidate**, not promoted to any real role. No production secrets given to it. |
| 12 | AI System Architect (part of `Shubhamsaboo/awesome-llm-apps`) | same repo | INSTALLED, compiles, UI smoke PASS | **BROKEN for actual use**: the self-audit run that tried to use it for a real architecture review timed out (`TOOLBOX_SELF_AUDIT_ROUTE_UNAVAILABLE`, reason `TimeoutError`) and ended `BLOCKED — no_working_schema_valid_architect_route`. It has never successfully produced a real project review. Needs its own DeepSeek+Anthropic credentials to run standalone, or a working OmniRoute route (currently not reliable, see below). |
| 13 | AirLLM | `lyogavin/airllm` | INSTALLED (import smoke only) | `NOT_USEFUL` here — it's for running huge models on tiny local GPUs; we don't have that hardware need on Railway/this environment. |
| 14 | Humanizer | `blader/humanizer` | INSTALLED / WORKING (smoke) | `NOT_USEFUL` for this project specifically — a trading-signal bot's Telegram output should stay precise/numeric, not "humanized." Keep away from any machine-readable trading text per its own stated role. |

### Tier 4 — never installed, never tested (9 of the 23)

| # | Tool | Repo | Notes |
|---|---|---|---|
| 15 | ruflo | `ruvnet/ruflo` | Separately probed as `ruflo-main-project-audit` / `ruflo-control-plane-audit` Railway services — the control-plane probe **FAILED** (`rc=128`, target-source unreachable). Not working. |
| 16 | hermes-agent | `NousResearch/hermes-agent` | Never touched. `NOT_INSTALLED`. |
| 17 | Agent-Reach | `Panniantong/Agent-Reach` | Never touched. `NOT_INSTALLED`. |
| 18 | OpenCLI | `jackwener/OpenCLI` | Never touched. `NOT_INSTALLED`. |
| 19 | playwright-cli | `microsoft/playwright-cli` | Never touched. Note: this Claude Code environment already ships Chromium+Playwright directly (unrelated to this specific repo). `NOT_INSTALLED`. |
| 20 | headroom | `headroomlabs-ai/headroom` | Claims to compress tool output/logs before they reach the model — could genuinely reduce tokens, but never evaluated. `NOT_INSTALLED`, worth a look later. |
| 21 | claude-mem | `thedotmack/claude-mem` | Cross-session memory tool — overlaps with our own `PROJECT_STATE.md` approach, which is already GitHub-native and durable. `NOT_INSTALLED`, `REJECTED` for now (redundant with what we already have). |
| 22 | public-apis | `public-apis/public-apis` | Reference list, not a tool. `NOT_APPLICABLE`. |
| 23 | supabase | `supabase/supabase` | An MCP server for it is connected in this session but the project's actual database is Railway PostgreSQL, not Supabase — `NOT_USEFUL` for this project unless that changes. |

## OmniRoute — detailed, skeptical verification

You specifically asked not to trust the "~1.47 billion free-tier tokens" marketing claim. We didn't.

**Confirmed real:**
- `OMNIROUTE_SELF_AUDIT doctor_rc=0`, `health=PASS` — the gateway itself runs and its own doctor check passes.
- `OMNIROUTE_SELF_AUDIT compression=PASS stacked=true` — compression is genuinely enabled with `defaultMode=stacked`, exactly as you described from the earlier standalone Railway deployment. This is a real, checked config, not a claim.

**Not confirmed / failed when actually used:**
- The one real attempt to route an actual task (the System Architect's architecture review) through OmniRoute's free/no-credential model catalog **timed out**:
  `TOOLBOX_SELF_AUDIT_ROUTE_UNAVAILABLE {"model": "unc/Lorbus/Qwen3.6-27B-int4-AutoRound", "batches": [], "reason": "TimeoutError"}`, ending in `TOOLBOX_SELF_AUDIT_STATUS {"status": "BLOCKED", "reason": "no_working_schema_valid_architect_route"}`.
- In other words: **the only concrete free-tier model we tried through OmniRoute did not actually deliver a usable response.** Whatever budget the provider claims (1.47B tokens or otherwise) was not demonstrated as *usable* quota — a marketing number and an actually-reachable, non-timing-out endpoint are two different things, and only the endpoint matters.
- The prior integration notes are explicit about this same skepticism: *"Do not assume an `auto` combo is free or that a catalog budget is accessible quota."* — this was already correctly flagged before you asked.

**Verdict:** OmniRoute's compression feature is real and verified. Its free-tier routing claim is **not verified as usable** — one real test failed. Treat it as `NEEDS_CONFIG` / unreliable until a full end-to-end call through it actually returns a real completion, and re-test before relying on it for anything.

## AI System Architect — detailed status

This is **not a separate GitHub repository** — it's a component ("AI System Architect Advisor") inside `Shubhamsaboo/awesome-llm-apps` (the 18th item in your starred list). It installs and compiles, but:

- It needs its own DeepSeek + Anthropic API credentials to run standalone (we have neither provisioned for it — using this session's own Claude Code access does not satisfy that, they're separate credential paths).
- The one attempt to bridge it through OmniRoute instead of paying for those credentials **failed** (see above).
- **It has never successfully produced one real project review.** Status: `BROKEN` for actual use, `READY` only for its own UI/compile smoke test.

## What I actually did in this session (not just found)

- Confirmed `context7` and `supabase` MCP connections are live and already usable here.
- Verified Ponytail's real Claude Code native install path (`/plugin marketplace add DietrichGebert/ponytail`, then `/plugin install ponytail@ponytail`) — this requires the user (or a permission I don't have) to run, since adding a third-party plugin marketplace is not something I can do through any tool available to me. Not installed by me; documented instead of faked.
- Did not attempt to re-run the full 13-tool Railway install pipeline here — it already produced real, evidenced results on `ai/integrate-agent-toolbox-2026-09-10`; repeating it in this session would be redundant and would burn time/tokens without new information. This file cites that evidence directly instead.
- Did not touch any production credentials, Telegram tokens, Railway secrets, or database credentials. REAL trading remains OFF everywhere referenced above.

## Recommended next step

The toolbox integration branch (`ai/integrate-agent-toolbox-2026-09-10`) is real, tested, and currently isolated from `main`. Its actual value (Graphify structural search, Ponytail discipline, OmniRoute compression) only compounds once merged and used routinely — right now it is inert evidence sitting on an unmerged branch and a Railway service that isn't part of the live workflow. Suggest: review that branch's diff, decide what to cherry-pick into `main` (starting with `tools/ai_toolbox/manifest.json`, `TOOLBOX_TOPOLOGY.md`, `AGENTS.md`, `CONTEXT.md` — pure documentation/config, zero runtime risk), and leave the blocked/unverified pieces (System Architect via OmniRoute, DeepSeek Harness promotion) isolated until they actually pass a real test.
