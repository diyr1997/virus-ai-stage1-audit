"use strict";

const { AsyncLocalStorage } = require("async_hooks");
const TelegramBot = require("node-telegram-bot-api");
const { Pool } = require("pg");

const OWNER_CHAT_ID = Number(process.env.TELEGRAM_OWNER_CHAT_ID || 0);
const accessContext = new AsyncLocalStorage();

function numericChatId(value) {
  const n = Number(value || 0);
  return Number.isFinite(n) ? n : 0;
}

function isOwner(chatId) {
  return Boolean(
    OWNER_CHAT_ID &&
      numericChatId(chatId) === OWNER_CHAT_ID
  );
}

function extractChatId(payload) {
  return numericChatId(
    payload?.message?.chat?.id ??
      payload?.chat?.id ??
      payload?.from?.id ??
      0
  );
}

function publicKeyboard() {
  return {
    inline_keyboard: [
      [
        { text: "M1", callback_data: "signal_M1" },
        { text: "M5", callback_data: "signal_M5" },
        { text: "M15", callback_data: "signal_M15" },
      ],
      [
        { text: "M30", callback_data: "signal_M30" },
        { text: "H1", callback_data: "signal_H1" },
      ],
    ],
  };
}

function publicWelcomeText() {
  return [
    "📊 XAU/USD AI Signals",
    "",
    "Выбери таймфрейм:",
    "M1 / M5 / M15 / M30 / H1",
    "",
    "Доступ: сигнал + график.",
  ].join("\n");
}

function publicOnlyText() {
  return "🔒 В общем доступе доступны только сигналы M1 / M5 / M15 / M30 / H1.";
}

function sanitizePublicText(value) {
  let text = String(value ?? "");

  if (text.startsWith("🤖 XAU/USD AI Signal Bot")) {
    return publicWelcomeText();
  }

  if (text.startsWith("🤖 Главное меню")) {
    return publicWelcomeText();
  }

  text = text.replace(
    "🌙 XAU/USD сейчас закрыт. Новости, CFTC и статистика доступны.",
    "🌙 XAU/USD сейчас закрыт. Сигналы временно недоступны."
  );

  text = text.replace(
    /\n📦 Верхний лимит лота по силе:\n[^\n]+\n\(реальный объём DEMO-бот[^\n]*\)/g,
    ""
  );

  text = text.replace(/\s*•\s*DEMO risk-control/g, "");

  return text;
}

function sanitizePublicOptions(options) {
  const next = { ...(options || {}) };
  next.reply_markup = publicKeyboard();

  if (typeof next.caption === "string") {
    next.caption = sanitizePublicText(next.caption);
  }

  return next;
}

const originalOnText = TelegramBot.prototype.onText;
TelegramBot.prototype.onText = function patchedOnText(regexp, callback) {
  return originalOnText.call(
    this,
    regexp,
    async (message, match) => {
      const chatId = extractChatId(message);
      const owner = isOwner(chatId);
      const text = String(message?.text || "").trim();

      if (
        !owner &&
        text.startsWith("/") &&
        !/^\/(?:start|signal)(?:@\w+)?(?:\s+(?:M1|M5|M15|M30|H1))?$/i.test(
          text
        )
      ) {
        await this.sendMessage(chatId, publicOnlyText(), {
          reply_markup: publicKeyboard(),
        });
        return;
      }

      return accessContext.run(
        { chatId, owner },
        () => callback.call(this, message, match)
      );
    }
  );
};

const originalOn = TelegramBot.prototype.on;
TelegramBot.prototype.on = function patchedOn(event, callback) {
  if (event !== "callback_query") {
    return originalOn.call(this, event, callback);
  }

  return originalOn.call(this, event, async (query) => {
    const chatId = extractChatId(query);
    const owner = isOwner(chatId);
    const data = String(query?.data || "");

    const publicAllowed =
      data === "main_menu" ||
      data === "signal_menu" ||
      /^signal_(M1|M5|M15|M30|H1)$/.test(data);

    if (!owner && !publicAllowed) {
      await this
        .answerCallbackQuery(query.id, {
          text: "Доступны только сигналы",
          show_alert: true,
        })
        .catch(() => {});
      await this
        .sendMessage(chatId, publicOnlyText(), {
          reply_markup: publicKeyboard(),
        })
        .catch(() => {});
      return;
    }

    return accessContext.run(
      { chatId, owner },
      () => callback.call(this, query)
    );
  });
};

const originalSendMessage = TelegramBot.prototype.sendMessage;
TelegramBot.prototype.sendMessage = function patchedSendMessage(
  chatId,
  text,
  options
) {
  if (isOwner(chatId)) {
    return originalSendMessage.call(this, chatId, text, options);
  }

  return originalSendMessage.call(
    this,
    chatId,
    sanitizePublicText(text),
    sanitizePublicOptions(options)
  );
};

const originalSendPhoto = TelegramBot.prototype.sendPhoto;
TelegramBot.prototype.sendPhoto = function patchedSendPhoto(
  chatId,
  photo,
  options,
  fileOptions
) {
  if (isOwner(chatId)) {
    return originalSendPhoto.call(
      this,
      chatId,
      photo,
      options,
      fileOptions
    );
  }

  return originalSendPhoto.call(
    this,
    chatId,
    photo,
    sanitizePublicOptions(options),
    fileOptions
  );
};

const originalSetMyCommands = TelegramBot.prototype.setMyCommands;
TelegramBot.prototype.setMyCommands = function patchedSetMyCommands(
  commands,
  options
) {
  const all = Array.isArray(commands) ? commands : [];
  const publicCommands = all.filter((item) =>
    ["start", "signal"].includes(String(item?.command || ""))
  );

  const publicResult = originalSetMyCommands.call(
    this,
    publicCommands,
    options
  );

  if (!OWNER_CHAT_ID) {
    return publicResult;
  }

  return Promise.resolve(publicResult).then(() =>
    originalSetMyCommands.call(this, all, {
      scope: {
        type: "chat",
        chat_id: OWNER_CHAT_ID,
      },
    })
  );
};

const originalPoolQuery = Pool.prototype.query;
Pool.prototype.query = function patchedPoolQuery(...args) {
  const store = accessContext.getStore();
  const sql =
    typeof args[0] === "string"
      ? args[0]
      : String(args[0]?.text || "");

  if (
    store &&
    store.owner === false &&
    /\bINSERT\s+INTO\s+analysis_runs\b/i.test(sql)
  ) {
    return Promise.resolve({
      command: "INSERT",
      rowCount: 0,
      oid: 0,
      rows: [],
      fields: [],
    });
  }

  return originalPoolQuery.apply(this, args);
};

if (!OWNER_CHAT_ID) {
  console.warn(
    "⚠️ PUBLIC ACCESS: TELEGRAM_OWNER_CHAT_ID is missing. Fail-closed public UI is active."
  );
} else {
  console.log(
    "✅ Telegram ACL: owner=ADMIN, everyone else=SIGNAL_VIEW_ONLY"
  );
}
