# XAU/USD Trading Intelligence Core V1

Status: **living synthesis / shadow research only**

This is a second knowledge layer. Original books and source-specific memories remain separate and untouched. This file is not a copy of any book and does not replace the source library.

## Purpose

Combine repeated ideas from the Trading School into one normalized vocabulary, preserve disagreements and conditions, and turn only the strongest shared ideas into measurable XAU/USD hypotheses.

The core must never treat repetition as proof. A concept is useful only after causal feature engineering and out-of-sample validation on XAU/USD.

## Normalized vocabulary

- **Trend regime** — persistent directional structure with directional efficiency and higher-timeframe support.
- **Range regime** — low directional efficiency / two-sided price discovery where trend-continuation assumptions are weaker.
- **Impulse** — directional expansion with strong candle body, follow-through and efficient path.
- **Pullback** — lower-timeframe counter-move inside a still-aligned higher-timeframe trend.
- **Reversal** — structural change that invalidates the prior trend context; not every counter-move is a reversal.
- **Breakout** — price leaving a recent structure/range; quality depends on follow-through, efficiency and context.
- **MTF alignment** — agreement of directional evidence across M5/M15/M30/H1.
- **Higher-TF context** — M15/M30/H1 directional state used to interpret M1/M5 movement.
- **Conflict** — lower timeframe moving against higher-timeframe context; can mean pullback, transition or reversal and therefore needs conditions.
- **Risk validation** — no trading idea is accepted only because it looks good in-sample; it must survive OOS/block/walk-forward checks.

## Consensus hypotheses for V1 shadow testing

These are project-specific paraphrased hypotheses, not quotations from authors.

1. **Impulse consensus**: a strong body is more useful when it is accompanied by short-term follow-through, path efficiency and a trend-like regime.
2. **MTF trend consensus**: higher-timeframe alignment should matter more when the market is trending and there is little lower-vs-higher conflict.
3. **Pullback-in-trend context**: a lower-timeframe counter-move should be interpreted differently when higher timeframes remain aligned.
4. **Contextual breakout**: location near/outside a recent range should matter more when directional efficiency and trend context agree.
5. **Conflict penalty**: disagreement between M1 and higher timeframes is not a directional signal by itself; it is a state variable that should reduce confidence unless a reversal framework is separately confirmed.

## Safety rules

- Original source memories remain separate.
- Source provenance stays in metadata even when the main terminology is normalized.
- No long copyrighted passages are copied into this core.
- Incomplete/partial books cannot be marked as fully synthesized.
- A unified idea is not promoted into the active model automatically.
- Every feature is tested first in SHADOW mode on real XAU/USD history.
- Promotion remains disabled for the first V1 core experiments.

## First quantitative experiment

V1 tests conditional/composite features rather than simply adding all raw book-derived features. This is deliberate: prior ablation tests showed that the raw Trading School V1 features, individually and in broad groups, degraded direction accuracy. The unified-core experiment tests whether *conditional combinations* are more useful than raw concepts in isolation.

Planned features:

- `core_impulse_consensus`
- `core_mtf_trend_consensus`
- `core_pullback_in_trend`
- `core_contextual_breakout`
- `core_conflict_penalty`

Test policy: same real M1 history, held-out validation, three validation blocks, no active-model change, no promotion.
