#!/usr/bin/env python3
from __future__ import annotations

import argparse
import io
import json
import logging
import urllib.request
from pathlib import Path

logging.getLogger("pypdf").setLevel(logging.CRITICAL)


def download(url: str) -> bytes:
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": "XAUUSD-Trading-School/1.0 (+private educational ingestion)",
            "Accept": "application/pdf,*/*;q=0.8",
        },
    )
    with urllib.request.urlopen(req, timeout=90) as response:
        return response.read()


def extract_with_pymupdf(data: bytes, limit: int, out: Path) -> dict:
    import fitz

    doc = fitz.open(stream=data, filetype="pdf")
    total = len(doc)
    limit = min(limit or total, total)
    extracted = 0
    failed = 0
    with out.open("w", encoding="utf-8") as f:
        for idx in range(limit):
            try:
                text = doc[idx].get_text("text") or ""
            except BaseException as exc:
                text = ""
                error = f"{type(exc).__name__}: {exc}"
                failed += 1
            else:
                error = None
                if text.strip():
                    extracted += 1
            f.write(json.dumps({"page": idx + 1, "text": text, "error": error}, ensure_ascii=False) + "\n")
    doc.close()
    return {
        "engine": "pymupdf",
        "pages_total": total,
        "pages_written": limit,
        "pages_with_text": extracted,
        "pages_failed": failed,
    }


def extract_with_pypdf(data: bytes, limit: int, out: Path) -> dict:
    from pypdf import PdfReader

    reader = PdfReader(io.BytesIO(data), strict=False)
    total = len(reader.pages)
    limit = min(limit or total, total)
    extracted = 0
    failed = 0
    with out.open("w", encoding="utf-8") as f:
        for idx in range(limit):
            try:
                text = reader.pages[idx].extract_text() or ""
            except BaseException as exc:
                text = ""
                error = f"{type(exc).__name__}: {exc}"
                failed += 1
            else:
                error = None
                if text.strip():
                    extracted += 1
            f.write(json.dumps({"page": idx + 1, "text": text, "error": error}, ensure_ascii=False) + "\n")
    return {
        "engine": "pypdf",
        "pages_total": total,
        "pages_written": limit,
        "pages_with_text": extracted,
        "pages_failed": failed,
    }


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--url", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--max-pages", type=int, default=0)
    args = p.parse_args()

    data = download(args.url)
    out = Path(args.output)
    limit = max(0, int(args.max_pages or 0))

    errors = []
    try:
        meta = extract_with_pymupdf(data, limit, out)
    except BaseException as exc:
        errors.append(f"pymupdf:{type(exc).__name__}:{exc}")
        meta = extract_with_pypdf(data, limit, out)

    meta.update({"ok": True, "bytes": len(data), "output": str(out), "fallback_errors": errors})
    print(json.dumps(meta, ensure_ascii=False))


if __name__ == "__main__":
    main()
