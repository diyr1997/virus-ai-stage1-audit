#!/usr/bin/env python3
"""Trading School Regime Router V1.

Purpose:
- Classify causal market context from already-computed Trading School features.
- Evaluate the CURRENT active H1 champion separately inside each regime.
- Test simple route hypotheses without changing or promoting any live model.

This file never opens trades and never writes a model.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from ai_predict_h1 import add_all_features, load_bundle

REGIME_ORDER = [
    "REVERSAL_ATTEMPT",
    "PULLBACK_IN_TREND",
    "IMPULSE",
    "TREND",
    "RANGE",
    "CONFLICT",
    "MIXED",
]


def _sign(value: float) -> int:
    if not np.isfinite(value) or value == 0:
        return 0
    return 1 if value > 0 else -1


def classify_regime(row: pd.Series) -> str:
    """Causal deterministic state classifier; uses current/past features only."""
    body = float(row.get("school_body_to_range", 0.0) or 0.0)
    follow = float(row.get("school_followthrough_3", 0.0) or 0.0)
    eff10 = float(row.get("school_efficiency_10", 0.0) or 0.0)
    trend = float(row.get("school_trend_regime", 0.0) or 0.0)
    range_score = float(row.get("school_range_regime", 0.0) or 0.0)
    higher = float(row.get("school_higher_tf_alignment", 0.0) or 0.0)
    mtf = float(row.get("school_mtf_alignment", 0.0) or 0.0)
    disagreement = float(row.get("school_m1_vs_higher_disagreement", 0.0) or 0.0)
    pullback = float(row.get("school_pullback_score", 0.0) or 0.0)

    # Strong lower-TF move against an established higher-TF trend.
    if (
        trend >= 0.55
        and abs(higher) >= 0.45
        and disagreement >= 0.50
        and abs(follow) >= 0.55
        and eff10 >= 0.40
        and _sign(follow) != 0
        and _sign(higher) != 0
        and _sign(follow) != _sign(higher)
    ):
        return "REVERSAL_ATTEMPT"

    # Counter-move exists, but path efficiency is weak enough to look like pullback noise.
    if trend >= 0.52 and abs(higher) >= 0.40 and pullback >= 0.12 and disagreement >= 0.28:
        return "PULLBACK_IN_TREND"

    # Local expansion/follow-through. This may be trend continuation or fresh impulse.
    if body >= 0.55 and abs(follow) >= 0.55 and eff10 >= 0.42:
        return "IMPULSE"

    if trend >= 0.60 and abs(higher) >= 0.42 and disagreement < 0.30:
        return "TREND"

    if range_score >= 0.58 and eff10 <= 0.42 and abs(mtf) <= 0.55:
        return "RANGE"

    if disagreement >= 0.30 or abs(mtf) < 0.20:
        return "CONFLICT"

    return "MIXED"


def routed_direction(row: pd.Series, regime: str) -> int:
    """A shadow-only routing hypothesis; 0 means abstain."""
    higher = float(row.get("school_higher_tf_alignment", 0.0) or 0.0)
    follow = float(row.get("school_followthrough_3", 0.0) or 0.0)

    if regime in ("TREND", "PULLBACK_IN_TREND"):
        return _sign(higher)
    if regime in ("IMPULSE", "REVERSAL_ATTEMPT"):
        return _sign(follow)
    return 0


def build_labeled_frame(raw: pd.DataFrame, features: list[str]) -> pd.DataFrame:
    x = add_all_features(raw.copy())
    x["future_close_60"] = x["close"].shift(-60)
    x["future_ts_60"] = x["timestamp"].shift(-60)
    x["future_delta_min"] = (x["future_ts_60"] - x["timestamp"]) / 60_000.0
    x["target_return_bps"] = (x["future_close_60"] / x["close"] - 1.0) * 10_000.0
    x["target_direction"] = np.where(x["target_return_bps"] >= 0.0, 1, -1)

    needed = list(features) + [
        "school_body_to_range",
        "school_followthrough_3",
        "school_efficiency_10",
        "school_trend_regime",
        "school_range_regime",
        "school_higher_tf_alignment",
        "school_mtf_alignment",
        "school_m1_vs_higher_disagreement",
        "school_pullback_score",
        "target_return_bps",
        "target_direction",
        "future_delta_min",
    ]
    x = x.replace([np.inf, -np.inf], np.nan).dropna(subset=needed)
    x = x[(x["future_delta_min"] >= 55.0) & (x["future_delta_min"] <= 70.0)].copy()
    if len(x) < 3500:
        raise RuntimeError(f"Need >=3500 usable labeled rows, got {len(x)}")
    return x


def _metrics(frame: pd.DataFrame) -> dict:
    n = int(len(frame))
    if n == 0:
        return {
            "samples": 0,
            "direction_accuracy": None,
            "return_mae_bps": None,
            "signal_coverage": 0.0,
            "signal_direction_accuracy": None,
            "route_coverage": 0.0,
            "route_direction_accuracy": None,
        }

    direction_accuracy = float((frame["champion_direction"] == frame["target_direction"]).mean())
    mae = float(np.mean(np.abs(frame["champion_return_bps"] - frame["target_return_bps"])))

    sig = frame[frame["champion_emit"]]
    route = frame[frame["route_direction"] != 0]
    return {
        "samples": n,
        "direction_accuracy": direction_accuracy,
        "return_mae_bps": mae,
        "signal_coverage": float(len(sig) / n),
        "signal_direction_accuracy": (
            float((sig["champion_direction"] == sig["target_direction"]).mean()) if len(sig) else None
        ),
        "route_coverage": float(len(route) / n),
        "route_direction_accuracy": (
            float((route["route_direction"] == route["target_direction"]).mean()) if len(route) else None
        ),
    }


def evaluate(model_path: str, candles_path: str) -> dict:
    bundle = load_bundle(model_path)
    features = list(bundle.get("features", []))
    if not features:
        raise RuntimeError("Champion bundle has no feature list")

    raw_rows = json.loads(Path(candles_path).read_text(encoding="utf-8"))
    raw = pd.DataFrame(raw_rows)
    required = ["timestamp", "open", "high", "low", "close"]
    for col in required:
        raw[col] = pd.to_numeric(raw[col], errors="coerce")
    raw = raw.dropna(subset=required).sort_values("timestamp").drop_duplicates("timestamp").reset_index(drop=True)
    if len(raw) < 5000:
        raise RuntimeError(f"Need >=5000 M1 candles, got {len(raw)}")

    data = build_labeled_frame(raw, features)

    valid_rows = max(1000, int(len(data) * 0.30))
    valid_rows = min(valid_rows, len(data) - 2500)
    if valid_rows < 1000:
        raise RuntimeError("Cannot reserve >=1000 validation rows")
    valid = data.iloc[-valid_rows:].copy()

    X = valid[features].to_numpy(dtype=np.float32)
    clf = bundle["direction_models"][60]
    reg = bundle["return_models"][60]
    probs = clf.predict_proba(X)
    classes = np.asarray(clf.classes_)
    best = np.argmax(probs, axis=1)
    pred_dir = classes[best].astype(int)
    confidence = probs[np.arange(len(probs)), best]
    pred_ret = reg.predict(X).astype(float)

    thr = bundle["thresholds"][60]
    conf_thr = float(thr["direction_confidence"])
    strength_thr = float(thr["predicted_strength_ratio"])
    target_scale = max(float(thr["target_scale_bps"]), 1e-9)
    reg_sign = np.where(pred_ret >= 0.0, 1, -1)
    agreement = pred_dir == reg_sign
    strength_ratio = np.abs(pred_ret) / target_scale
    emit = agreement & (confidence >= conf_thr) & (strength_ratio >= strength_thr)

    valid["champion_direction"] = pred_dir
    valid["champion_confidence"] = confidence
    valid["champion_return_bps"] = pred_ret
    valid["champion_emit"] = emit
    valid["regime"] = valid.apply(classify_regime, axis=1)
    valid["route_direction"] = [routed_direction(row, regime) for (_, row), regime in zip(valid.iterrows(), valid["regime"])]

    overall = _metrics(valid)
    by_regime = {}
    for regime in REGIME_ORDER:
        sub = valid[valid["regime"] == regime]
        m = _metrics(sub)
        m["share"] = float(len(sub) / len(valid)) if len(valid) else 0.0
        by_regime[regime] = m

    blocks = []
    indices = np.array_split(np.arange(len(valid)), 3)
    for i, idx in enumerate(indices, start=1):
        block = valid.iloc[idx]
        row = {"block": i, "samples": int(len(block)), "regimes": {}}
        for regime in REGIME_ORDER:
            row["regimes"][regime] = _metrics(block[block["regime"] == regime])
        blocks.append(row)

    # Rank regimes by how much the simple route hypothesis improves/worsens over
    # champion direction accuracy inside the exact same rows. This is discovery
    # only; no route is activated by this script.
    ranked_routes = []
    for regime, m in by_regime.items():
        if not m["samples"] or m["route_direction_accuracy"] is None:
            continue
        ranked_routes.append(
            {
                "regime": regime,
                "samples": m["samples"],
                "share": m["share"],
                "champion_direction_accuracy": m["direction_accuracy"],
                "route_direction_accuracy": m["route_direction_accuracy"],
                "route_gain": float(m["route_direction_accuracy"] - m["direction_accuracy"]),
                "route_coverage": m["route_coverage"],
            }
        )
    ranked_routes.sort(key=lambda r: r["route_gain"], reverse=True)

    return {
        "ok": True,
        "version": "REGIME_ROUTER_V1",
        "shadow_only": True,
        "promoted": False,
        "active_model_changed": False,
        "model_version": bundle.get("version"),
        "source_rows": int(len(raw)),
        "usable_rows": int(len(data)),
        "validation_rows": int(len(valid)),
        "overall": overall,
        "by_regime": by_regime,
        "blocks": blocks,
        "ranked_route_hypotheses": ranked_routes,
        "thresholds": {
            "direction_confidence": conf_thr,
            "predicted_strength_ratio": strength_thr,
            "target_scale_bps": target_scale,
        },
        "note": "Context audit only. Router and route hypotheses are NOT connected to live BUY/SELL or DEMO execution.",
    }


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--model", required=True)
    p.add_argument("--candles", required=True)
    args = p.parse_args()
    try:
        print(json.dumps(evaluate(args.model, args.candles), ensure_ascii=False, allow_nan=False))
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False))
        raise SystemExit(2)


if __name__ == "__main__":
    main()
