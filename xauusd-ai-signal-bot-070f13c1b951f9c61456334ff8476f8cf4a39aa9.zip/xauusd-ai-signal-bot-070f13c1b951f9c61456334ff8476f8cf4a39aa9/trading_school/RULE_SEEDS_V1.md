# Trading School V1 — Rule Seeds

Updated: 2026-08-20

These are **project interpretations**, not copied book text. They are hypotheses for testing only. They must not directly change live/DEMO decisions until validated on XAU/USD history.

## Price action / short-term structure (M1/M5)

- Do not treat a single indicator as a complete entry decision.
- Distinguish trend continuation from range/mean-reversion regimes before using momentum rules.
- A breakout should be evaluated for follow-through, volatility expansion and failure/rejection behavior.
- If a position already exists, additional entries require evidence of continued movement in the same direction; do not average down solely because the original signal is still active.
- Support/resistance should be evaluated as zones confirmed by repeated price interaction rather than as one exact price.

## Multi-timeframe structure (M5/M15/M30/H1)

- Separate short-term pullback from higher-timeframe trend reversal.
- A lower-timeframe counter-move should not automatically override the higher-timeframe regime.
- Track agreement/disagreement between M1/M5/M15/M30/H1 as explicit features rather than merging all timeframes into one signal.
- Require stronger confirmation for trades that oppose the dominant higher-timeframe structure.

## Trading systems / regime logic

- Every discretionary concept must be rewritten as explicit, measurable conditions.
- Momentum and mean-reversion rules should not be applied in the same market regime without a regime classifier.
- Strategy performance should be measured separately by volatility/trend/range regime.
- Entry, exit, sizing and cancellation rules must be tested as a complete system, not only as isolated indicators.

## Risk and position management

- Position sizing must account for account equity, stop distance, free margin and current portfolio exposure.
- Additional positions should require positive/healthy scenario state, not merely available margin.
- Track equity curve and drawdown, not only win rate.
- Test risk rules separately across all DEMO risk modes.

## Forecasting / ML validation

- Separate training, validation and final out-of-sample periods.
- Examine residuals and forecast errors rather than only directional accuracy.
- Compare point forecasts with uncertainty/prediction bands when practical.
- Avoid selecting a model after repeatedly testing many variants on the same holdout period.
- Champion/challenger promotion requires stability across several non-overlapping time blocks and market regimes.
- New features that appear predictive in-sample must be checked for leakage, non-stationarity and causal weakness.

## Gold/futures market context

- Treat futures/COMEX structure as market context, not as a direct BUY/SELL command.
- Spread, liquidity, session boundaries and maintenance windows can invalidate an otherwise good short-term setup.
- Around abnormal liquidity or planned market breaks, new entries should be paused rather than forced from stale prices.

## Acceptance metrics for every rule seed

At minimum compare:
- win rate;
- profit factor;
- expectancy;
- max drawdown;
- false-entry rate;
- trade count;
- average adverse excursion;
- average favorable excursion;
- stability by timeframe;
- stability by market regime;
- out-of-sample degradation.

A rule is rejected if the apparent improvement disappears outside the training period or materially worsens drawdown/robustness.
