#!/usr/bin/env python3
"""One-shot Trading School V1 bootstrap trainer.

Uses the currently available recent M1 history when the normal auto-trainer has
not yet accumulated its 8k safety minimum. It is deliberately stricter about
promotion and requires at least 1,000 out-of-sample rows. Normal daily/weekend
training keeps its original 8k+ requirement.
"""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor

from ai_predict_h1 import add_all_features, load_bundle
from trading_school.features_v1 import SCHOOL_FEATURES
from weekend_train_h1 import (
    _clean_input,
    _evaluate_blocks,
    _evaluate_frame,
    _should_accept,
)


def build_dataset(df: pd.DataFrame, features: list[str]) -> pd.DataFrame:
    if len(df) < 5_000:
        raise RuntimeError(f"Need >=5000 M1 candles for bootstrap, got {len(df)}")

    x = add_all_features(df.copy())
    x["future_close_60"] = x["close"].shift(-60)
    x["future_ts_60"] = x["timestamp"].shift(-60)
    x["future_delta_min"] = (x["future_ts_60"] - x["timestamp"]) / 60_000.0
    x["target_return_bps"] = (x["future_close_60"] / x["close"] - 1.0) * 10_000.0
    x["target_direction"] = np.where(x["target_return_bps"] >= 0.0, 1, -1)

    required = list(features) + ["target_return_bps", "target_direction", "future_delta_min"]
    x = x.replace([np.inf, -np.inf], np.nan).dropna(subset=required)
    x = x[(x["future_delta_min"] >= 55.0) & (x["future_delta_min"] <= 70.0)].copy()
    if len(x) < 3_500:
        raise RuntimeError(f"Need >=3500 usable labeled rows, got {len(x)}")
    return x


def train(champion_path: str, candles_path: str, output_path: str) -> dict:
    champion = load_bundle(champion_path)
    champion_features = list(champion.get("features", []))
    if not champion_features:
        raise RuntimeError("Champion bundle has no feature list")

    challenger_features = champion_features + [
        f for f in SCHOOL_FEATURES if f not in champion_features
    ]

    raw = _clean_input(candles_path)
    data = build_dataset(raw, challenger_features)

    # Keep at least 1,000 untouched rows for out-of-sample validation.
    valid_rows = max(1_000, int(len(data) * 0.30))
    valid_rows = min(valid_rows, len(data) - 2_500)
    if valid_rows < 1_000:
        raise RuntimeError("Cannot reserve >=1000 validation rows")
    split = len(data) - valid_rows
    train_df = data.iloc[:split]
    valid_df = data.iloc[split:]

    X_train = train_df[challenger_features].to_numpy(dtype=np.float32)
    y_train_dir = train_df["target_direction"].to_numpy(dtype=np.int8)
    y_train_ret = train_df["target_return_bps"].to_numpy(dtype=np.float32)

    # Conservative profile for this one-shot bootstrap.
    profile = {
        "name": "trading_school_bootstrap_conservative",
        "learning_rate": 0.035,
        "max_iter": 150,
        "max_leaf_nodes": 15,
        "min_samples_leaf": 55,
        "l2_regularization": 3.0,
    }

    clf = HistGradientBoostingClassifier(
        learning_rate=profile["learning_rate"],
        max_iter=profile["max_iter"],
        max_leaf_nodes=profile["max_leaf_nodes"],
        min_samples_leaf=profile["min_samples_leaf"],
        l2_regularization=profile["l2_regularization"],
        random_state=142,
    )
    reg = HistGradientBoostingRegressor(
        learning_rate=profile["learning_rate"],
        max_iter=profile["max_iter"],
        max_leaf_nodes=profile["max_leaf_nodes"],
        min_samples_leaf=profile["min_samples_leaf"],
        l2_regularization=profile["l2_regularization"],
        loss="absolute_error",
        random_state=142,
    )
    clf.fit(X_train, y_train_dir)
    reg.fit(X_train, y_train_ret)

    challenger = dict(champion)
    challenger["direction_models"] = dict(champion["direction_models"])
    challenger["return_models"] = dict(champion["return_models"])
    challenger["direction_models"][60] = clf
    challenger["return_models"][60] = reg
    challenger["features"] = challenger_features

    now = datetime.now(timezone.utc)
    version = f"school-v1-bootstrap-{now.strftime('%Y%m%dT%H%M%SZ')}"
    challenger["version"] = version

    champion_metrics = _evaluate_frame(champion, valid_df, champion_features)
    challenger_metrics = _evaluate_frame(challenger, valid_df, challenger_features)
    champion_blocks = _evaluate_blocks(champion, valid_df, champion_features, blocks=3)
    challenger_blocks = _evaluate_blocks(challenger, valid_df, challenger_features, blocks=3)

    # Use weekend thresholds (stricter than daily) even though this is a one-shot run.
    accepted, reasons = _should_accept(
        champion_metrics,
        challenger_metrics,
        champion_blocks,
        challenger_blocks,
        "weekend",
    )

    # Extra bootstrap safety: no validation block may lose more than 0.5 percentage
    # point of direction accuracy, and at least two must improve.
    block_gains = []
    if len(champion_blocks) == len(challenger_blocks) and champion_blocks:
        block_gains = [
            float(n["direction_accuracy"]) - float(c["direction_accuracy"])
            for c, n in zip(champion_blocks, challenger_blocks)
        ]
        if min(block_gains) < -0.005:
            accepted = False
            reasons.append(f"bootstrap_worst_block={min(block_gains):+.4f}")
        if sum(g > 0 for g in block_gains) < 2:
            accepted = False
            reasons.append("bootstrap_needs_2_positive_blocks")

    metadata = dict(champion.get("metadata", {}))
    metadata["trading_school_v1"] = {
        "enabled": True,
        "bootstrap": True,
        "trained_at": now.isoformat(),
        "free_sources": "trading_school/FREE_SOURCES_V1.md",
        "rule_seeds": "trading_school/RULE_SEEDS_V1.md",
        "features": [f for f in challenger_features if f.startswith("school_")],
        "source_rows": int(len(raw)),
        "usable_rows": int(len(data)),
        "train_rows": int(len(train_df)),
        "validation_rows": int(len(valid_df)),
        "accepted": bool(accepted),
        "reject_reasons": reasons,
        "champion_metrics": champion_metrics,
        "challenger_metrics": challenger_metrics,
        "block_gains": block_gains,
    }
    challenger["metadata"] = metadata

    joblib.dump(challenger, output_path, compress=3)
    return {
        "ok": True,
        "version": version,
        "accepted": bool(accepted),
        "reject_reasons": reasons,
        "source_rows": int(len(raw)),
        "usable_rows": int(len(data)),
        "train_rows": int(len(train_df)),
        "validation_rows": int(len(valid_df)),
        "champion_feature_count": len(champion_features),
        "challenger_feature_count": len(challenger_features),
        "school_features_added": [f for f in challenger_features if f not in champion_features],
        "champion_metrics": champion_metrics,
        "challenger_metrics": challenger_metrics,
        "champion_blocks": champion_blocks,
        "challenger_blocks": challenger_blocks,
        "block_gains": block_gains,
        "profile": profile,
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--champion", required=True)
    p.add_argument("--candles", required=True)
    p.add_argument("--output", required=True)
    args = p.parse_args()
    try:
        result = train(args.champion, args.candles, args.output)
        print(json.dumps(result, ensure_ascii=False, allow_nan=False))
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, allow_nan=False))
        raise SystemExit(2)


if __name__ == "__main__":
    main()
