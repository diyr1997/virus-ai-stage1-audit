# Trading School — Legal Book Access Map V1

Updated: 2026-08-20

Purpose: keep one legal source map for the books and educational material used by the XAU/USD Trading School. A title appearing here does **not** mean the full copyrighted book has been copied into the project. Full text is ingested only when it is openly licensed/free from the rights holder, or when the user provides a lawful personal copy for private analysis. Library/DRM books and publisher samples are registered as access routes only.

## Already open/free and eligible for direct ingestion

1. Zerodha Varsity — Technical Analysis — free open web.
2. Zerodha Varsity — Trading Systems — free open web.
3. Zerodha Varsity — Risk Management and Trading Psychology — free open web.
4. Hyndman & Athanasopoulos — Forecasting: Principles and Practice, 3rd ed. — free online textbook.
5. CME Group — A Trader's Guide to Futures — official free PDF.
6. MetaQuotes — MQL5 Programming for Traders — official free PDF.
7. QuantInsti — A Rough and Ready Guide to Algorithmic Trading, 2026 — free publisher PDF delivered by email; requires the user's downloaded copy.
8. Bailey/Borwein/López de Prado/Zhu — backtest-overfitting research — free official research access where offered.
9. López de Prado & Zoonekynd — Causality and Factor Investing (2025) — free official research access.
10. Stefan Jansen — Machine Learning for Algorithmic Trading companion repository — public GitHub, MIT-licensed software/documentation. The project may ingest the repository README/chapter README material and use the code as an open companion source. Official repo: https://github.com/stefan-jansen/machine-learning-for-trading

## Paid books — keep registered, use legal full copy when available

### Brian Shannon — Technical Analysis Using Multiple Timeframes
- Role: multi-timeframe market structure, trend alignment, entries/exits, risk.
- Official ebook: https://play.google.com/store/books/details/Brian_Shannon_Technical_Analysis_Using_Multiple_Ti?id=K2juEQAAQBAJ
- Open Library catalog: https://openlibrary.org/books/OL27090914M/Technical_analysis_using_multiple_timeframes
- Full 2008 physical pagination is xii + 184 pages; Google Play ebook currently shows 196 pages.
- User-provided 150-page scan is marked PARTIAL and must not be treated as the complete book.

### Al Brooks — Trading Price Action Trends
- Role: M1/M5 price action, trend bars, breakouts, channels, continuation.
- Library route: https://www.overdrive.com/media/703341/trading-price-action-trends
- Publisher page/sample: https://www.wiley-vch.de/en/areas-interest/finance-economics-law/trading-price-action-trends-978-1-118-06651-5

### Al Brooks — Trading Price Action Reversals
- Role: reversal vs pullback, failed breakouts, intraday reversal structure.
- Library route: https://www.overdrive.com/media/717717/trading-price-action-reversals
- Publisher page/sample: https://www.wiley-vch.de/en/areas-interest/finance-economics-law/finance-investments-13fi/trading-13fi4/trading-price-action-reversals-978-1-118-06661-4

### Adam Grimes — The Art & Science of Technical Analysis
- Role: market structure, price action, trend/range transitions, statistically validated setups, risk.
- Library route: https://www.overdrive.com/media/965798/the-art-science-of-technical-analysis
- Publisher page/sample: https://www.wiley-vch.de/en/areas-interest/finance-economics-law/finance-investments-13fi/trading-13fi4/the-art-science-of-technical-analysis-978-1-118-11512-1

### John J. Murphy — Technical Analysis of the Financial Markets
- Role: broad technical-analysis reference, indicators, intermarket context, futures.
- Library route: https://www.overdrive.com/media/1258456/technical-analysis-of-the-financial-markets

### Ernest P. Chan — Quantitative Trading, Revised 2nd Edition (2026)
- Role: quantitative research, changing regimes, ML, backtesting, business/process discipline.
- Library route (2026 edition): https://nlb.overdrive.com/media/12924666
- Official ebook: https://play.google.com/store/books/details/Quantitative_Trading_How_to_Build_Your_Own_Algorit?id=_tzEEQAAQBAJ

### Ernest P. Chan — Algorithmic Trading
- Role: mean reversion, momentum, intraday momentum, backtesting, risk.
- Library route: https://www.overdrive.com/media/1485734/algorithmic-trading
- Publisher page/sample: https://www.wiley-vch.de/en?isbn=9781118460146&option=com_eshop&title=Algorithmic+Trading&view=product

### Marcos López de Prado — Advances in Financial Machine Learning
- Role: financial ML, labeling/validation discipline, backtest false positives, feature research.
- Library route: https://www.overdrive.com/media/3578564/advances-in-financial-machine-learning
- Publisher page/sample: https://www.wiley-vch.de/en/areas-interest/finance-economics-law/finance-investments-13fi/finance-investments-special-topics-13fiz/advances-in-financial-machine-learning-978-1-119-48208-6

### Perry J. Kaufman — Trading Systems and Methods, 6th Edition
- Role: systematic methods, indicators, algorithms, multiple timeframes, adaptive techniques, risk.
- Publisher page: https://www.wiley-vch.de/en/areas-interest/finance-economics-law/finance-investments-13fi/trading-13fi4/trading-systems-and-methods-978-1-119-60535-5
- O'Reilly catalog/subscription route: https://www.oreilly.com/library/view/trading-systems-and/9781119605355/

### Stefan Jansen — Machine Learning for Algorithmic Trading, 2nd Edition
- Role: practical ML workflow, feature engineering, model validation, backtesting, alternative data.
- Full book remains copyrighted.
- Open MIT companion repository is directly usable: https://github.com/stefan-jansen/machine-learning-for-trading

### Robert Pardo — The Evaluation and Optimization of Trading Strategies, 2nd Edition
- Role: walk-forward testing, optimization, robustness, avoiding overfit.
- Library route: https://www.overdrive.com/media/166709/the-evaluation-and-optimization-of-trading-strategies

### Thomas N. Bulkowski — Encyclopedia of Chart Patterns, 3rd Edition
- Role: pattern statistics, failures, stop behavior, higher-timeframe pattern research.
- Library route: https://www.overdrive.com/media/5708469/encyclopedia-of-chart-patterns
- Do not scrape the author's website for AI training; use the book only from lawful access.

### Alexander Elder — The New Trading for a Living
- Role: risk, trade management, discipline, system process, record keeping.
- Library route: https://www.overdrive.com/media/1984204/the-new-trading-for-a-living

## Optional extension books worth keeping on the radar

- Al Brooks — Trading Price Action Trading Ranges (completes the Trends/Ranges/Reversals trilogy).
- Brian Shannon — Maximum Trading Gains with Anchored VWAP (2023), useful for objective price/time/volume context and entry/exit research.

## Project policy

1. Full copyrighted books are never scraped from pirate mirrors or committed to GitHub.
2. Publisher samples, public descriptions and tables of contents may be used only as samples/catalog context, not treated as the full book.
3. Library/OverDrive links are access routes; DRM/borrowed content is not automatically copied out of the library system.
4. Openly licensed material may be ingested according to its license. Preserve required attribution/license notices.
5. A lawful user-provided full ebook/PDF may be analyzed privately; store derived project knowledge rather than redistributing the book.
6. Every extracted trading idea must become a measurable hypothesis and pass XAU/USD out-of-sample/shadow testing before it can influence DEMO behavior.
