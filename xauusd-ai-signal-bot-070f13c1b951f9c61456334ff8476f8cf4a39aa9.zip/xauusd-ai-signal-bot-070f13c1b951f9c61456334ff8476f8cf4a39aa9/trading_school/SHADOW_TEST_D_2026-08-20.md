# Trading School — Shadow Test D

Date: 2026-08-20
Mode: SAFE SHADOW ONLY

This was a one-off challenger training/evaluation using real XAU/USD M1 candles from PostgreSQL. The active model was not changed and no model was promoted.

## Run

- Real M1 candles: 7000
- Out-of-sample validation rows: 1806
- Champion features: 111
- Challenger features: 123
- Added Trading School features: 12
- Training/evaluation elapsed time: 2.56 seconds
- Challenger version: `school-v1-bootstrap-20260820T111920Z`
- Accepted by metrics: NO
- Promoted: NO
- Active model changed: NO

## Champion metrics

- Direction accuracy: 0.4695459579 (46.95%)
- High-confidence accuracy: 0.2363636364 (23.64%)
- High-confidence coverage: 0.0304540421 (3.05%)
- Return MAE: 23.4794229932 bps
- Validation samples: 1806
- High-confidence samples: 55

## Challenger metrics

- Direction accuracy: 0.4435215947 (44.35%)
- High-confidence accuracy: 0.4295958279 (42.96%)
- High-confidence coverage: 0.8493909192 (84.94%)
- Return MAE: 29.1441717294 bps
- Validation samples: 1806
- High-confidence samples: 1534

## Why it was rejected

- Return MAE degraded by ratio 1.2413.
- Overall direction accuracy gain was -0.0260 (about -2.60 percentage points).
- Only 1 of 3 validation blocks improved.
- Worst block direction gain was -0.1130.
- Median block direction gain was -0.0133.
- Block 2 return MAE ratio was 1.3981.
- Bootstrap safety checks also failed: worst block -0.1130 and fewer than 2 positive blocks.

## Interpretation

The current 12 Trading School numerical features should NOT be promoted together. The result is useful as a baseline: future experiments should test smaller groups separately (price action/impulse, multi-timeframe alignment, trend-range regime, pullback/reversal) and later incorporate rules derived from fully understood books. This shadow test gives the system experience without changing production behavior.
