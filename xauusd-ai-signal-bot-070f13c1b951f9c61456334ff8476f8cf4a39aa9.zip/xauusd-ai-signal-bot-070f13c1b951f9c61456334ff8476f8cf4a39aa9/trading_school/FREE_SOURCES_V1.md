# Trading School V1 — Legal Free Sources

Updated: 2026-08-20

Status: **research library only**. These sources do not directly change BUY/SELL/WAIT and do not modify MT5 execution. Any rule extracted from them must be translated into measurable features and validated on XAU/USD history before DEMO influence.

## F1 — QuantInsti: A Rough and Ready Guide to Algorithmic Trading — 2026 Edition

- Official source: https://www.quantinsti.com/algo-trading-ebook
- Access: FREE, PDF delivered by the publisher by email.
- Edition: revised and expanded 2026.
- Project use: algorithmic-trading map, AI/ML/LLMs, market data, momentum, mean reversion, execution, position sizing, strategy decay.
- Intended layer: Analytical Bot #1 / Quant School.
- Copyright handling: do not mirror the full PDF in GitHub; use the official publisher copy and store only project-specific derived rules/notes.

## F2 — Zerodha Varsity: Technical Analysis

- Official source: https://zerodha.com/varsity/modules/
- Access: FREE and open online; Zerodha states no signup/paywall/ads for Varsity.
- Current module: Technical Analysis.
- Project use: candles, timeframes, support/resistance, moving averages, RSI, MACD, Bollinger Bands, patterns, Dow Theory, risk/reward and trading checklist.
- Intended layer: Analytical Bot #1 / Price Action + Technical Analysis School.

## F3 — Zerodha Varsity: Trading Systems

- Official source: https://zerodha.com/varsity/modules/
- Access: FREE and open online.
- Project use: components of systematic trading, turning discretionary ideas into explicit rules and testable systems.
- Intended layer: Analytical Bot #1 / System School.

## F4 — Zerodha Varsity: Risk Management and Trading Psychology

- Official source: https://zerodha.com/varsity/module/risk-management/page/2/
- Access: FREE and open online; module includes downloadable PDF.
- Project use: position sizing, equity curve, expected returns, VaR, Kelly criterion, active-trader sizing, risk and common trading biases.
- Intended layer: Bot #1 validation/risk research; Bot #2 may only receive separately validated implementation rules.

## F5 — Forecasting: Principles and Practice, 3rd edition — Hyndman & Athanasopoulos

- Official source: https://otexts.com/fpp3/
- Access: FREE online textbook.
- Edition: 3rd edition (2021); online edition is maintained and updated.
- Project use: time-series exploration, features, model evaluation, residual diagnostics, prediction intervals, forecasting workflow.
- Intended layer: Analytical Bot #1 / Forecasting + ML validation.
- Important: not a trading signal book; it is used to improve statistical discipline.

## F6 — CME Group: A Trader's Guide to Futures

- Official landing page: https://www.cmegroup.com/education/brochures-and-handbooks/a-traders-guide-to-futures
- Official PDF: https://www.cmegroup.com/content/dam/cmegroup/education/files/a-traders-guide-to-futures.pdf
- Access: FREE.
- Project use: futures mechanics, participant types, trade flow, margin/execution context. Relevant to gold because COMEX/CME futures are an important part of the gold market ecosystem.
- Intended layer: Bot #1 / Gold Market Structure School.

## F7 — MetaQuotes: MQL5 Programming for Traders

- Official PDF: https://www.mql5.com/files/book/mql5book.pdf
- Access: FREE official PDF.
- Project use: MT5/MQL5 engineering, orders, positions, debugging, reliability.
- Intended layer: Bot #2 engineering only. It is **not** a source of BUY/SELL direction.

## F8 — Bailey, Borwein, López de Prado, Zhu: Backtest Overfitting

- Official SSRN page: https://papers.ssrn.com/sol3/papers.cfm?abstract_id=2308659
- Access: FREE to read/download from SSRN where offered.
- Project use: detect and reduce backtest overfitting; prevent selecting a model just because it looks excellent after many trials.
- Intended layer: night/weekend champion-challenger validation.
- Copyright handling: keep the source link and project notes; do not redistribute the paper unless its license explicitly permits it.

## F9 — López de Prado & Zoonekynd: Causality and Factor Investing — 2025

- Official SSRN page: https://papers.ssrn.com/sol3/papers.cfm?abstract_id=5277078
- Access: FREE to read from SSRN.
- Year: 2025.
- Project use: distinguish statistically attractive factors from causally weak/misspecified ones; useful when evaluating new AI features.
- Intended layer: Bot #1 / ML research and weekend validation.

## F10 — Stefan Jansen: Machine Learning for Algorithmic Trading — open companion repository

- Official source: https://github.com/stefan-jansen/machine-learning-for-trading
- Access: public GitHub companion repository.
- License: MIT for the repository software/documentation (license preserved in source).
- Content: root/chapter README material plus more than 150 practical notebooks/code examples supporting the book's ML-for-trading workflow.
- Project use: financial feature engineering, learning-task design, model validation, backtesting, portfolio evaluation, alternative data and practical ML workflows.
- Intended layer: Analytical Bot #1 / ML School + weekend research.
- Copyright handling: the commercial book text is not mirrored; only the openly licensed companion repository is ingested.

---

## Loading policy

1. Do not pirate or mirror copyrighted books.
2. Register official free sources here.
3. Extract only concise project-specific concepts/rules from copyrighted sources; openly licensed material may be stored according to its license.
4. Convert every concept into measurable XAU/USD features.
5. Backtest separately on M1, M5, M15, M30 and H1 where relevant.
6. Use out-of-sample and walk-forward validation.
7. Promote only robust improvements to DEMO challenger models.
8. Production/MT5 execution remains unchanged until a separate validation decision.
