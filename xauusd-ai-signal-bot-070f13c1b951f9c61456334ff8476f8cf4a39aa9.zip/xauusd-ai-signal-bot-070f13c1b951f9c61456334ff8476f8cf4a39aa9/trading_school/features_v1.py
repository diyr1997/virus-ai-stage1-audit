"""Trading School V1 feature engineering.

This module contains project-specific, measurable interpretations of legal/open
trading education sources. It does not copy book text and it does not issue
BUY/SELL commands. All features are causal: they only use current/past bars.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

SCHOOL_FEATURES = [
    "school_body_to_range",
    "school_close_location",
    "school_efficiency_10",
    "school_efficiency_30",
    "school_followthrough_3",
    "school_breakout_position_20",
    "school_mtf_alignment",
    "school_higher_tf_alignment",
    "school_m1_vs_higher_disagreement",
    "school_pullback_score",
    "school_trend_regime",
    "school_range_regime",
]

CORE_FEATURES = [
    "core_impulse_consensus",
    "core_mtf_trend_consensus",
    "core_pullback_in_trend",
    "core_contextual_breakout",
    "core_conflict_penalty",
]


def _safe_div(a: pd.Series, b: pd.Series) -> pd.Series:
    return a / b.replace(0, np.nan)


def _sign(series: pd.Series) -> pd.Series:
    values = np.sign(pd.to_numeric(series, errors="coerce"))
    return pd.Series(values, index=series.index, dtype="float64")


def add_trading_school_features(df: pd.DataFrame) -> pd.DataFrame:
    """Add compact price-action, regime and multi-timeframe features.

    Expected input is the frame after add_m1_features() and
    add_multitimeframe_features(). Missing optional MTF columns are treated as
    neutral so the function stays backward-compatible.
    """
    out = df
    close = pd.to_numeric(out["close"], errors="coerce")
    open_ = pd.to_numeric(out["open"], errors="coerce")
    high = pd.to_numeric(out["high"], errors="coerce")
    low = pd.to_numeric(out["low"], errors="coerce")

    candle_range = (high - low).abs()
    body = close - open_
    out["school_body_to_range"] = _safe_div(body.abs(), candle_range).clip(0, 2)
    out["school_close_location"] = _safe_div(close - low, candle_range).clip(0, 1)

    ret1 = close.pct_change(1)
    for n in (10, 30):
        net = (close - close.shift(n)).abs()
        path = close.diff().abs().rolling(n, min_periods=n).sum()
        out[f"school_efficiency_{n}"] = _safe_div(net, path).clip(0, 1)

    direction = _sign(close.diff())
    out["school_followthrough_3"] = (
        direction.rolling(3, min_periods=3).sum() / 3.0
    ).clip(-1, 1)

    rolling_high = high.shift(1).rolling(20, min_periods=20).max()
    rolling_low = low.shift(1).rolling(20, min_periods=20).min()
    channel = (rolling_high - rolling_low).abs()
    out["school_breakout_position_20"] = (
        _safe_div(close - rolling_low, channel).clip(-1, 2) - 0.5
    ) * 2.0

    tf_signals = []
    higher_signals = []
    for tf in (5, 15, 30, 60):
        ema_col = f"m{tf}_ema5_20_spread"
        ret_col = f"m{tf}_ret1"
        if ema_col in out.columns and ret_col in out.columns:
            signal = (_sign(out[ema_col]) + _sign(out[ret_col])) / 2.0
        elif ema_col in out.columns:
            signal = _sign(out[ema_col])
        elif ret_col in out.columns:
            signal = _sign(out[ret_col])
        else:
            signal = pd.Series(0.0, index=out.index)
        tf_signals.append(signal)
        if tf in (15, 30, 60):
            higher_signals.append(signal)

    mtf = sum(tf_signals) / max(len(tf_signals), 1)
    higher = sum(higher_signals) / max(len(higher_signals), 1)
    out["school_mtf_alignment"] = mtf.clip(-1, 1)
    out["school_higher_tf_alignment"] = higher.clip(-1, 1)

    short = _sign(out["m1_ret5"] if "m1_ret5" in out.columns else ret1)
    higher_sign = _sign(higher)
    disagreement = (short * higher_sign < 0).astype(float) * higher.abs()
    out["school_m1_vs_higher_disagreement"] = disagreement.clip(0, 1)

    # Pullback: a lower-TF counter-move while higher TFs are still aligned.
    out["school_pullback_score"] = (
        disagreement * higher.abs() * (1.0 - out["school_efficiency_10"].fillna(0.0))
    ).clip(0, 1)

    efficiency = (
        0.6 * out["school_efficiency_30"].fillna(0.0)
        + 0.4 * out["school_efficiency_10"].fillna(0.0)
    )
    trend = (0.55 * higher.abs() + 0.45 * efficiency).clip(0, 1)
    out["school_trend_regime"] = trend
    out["school_range_regime"] = (1.0 - trend).clip(0, 1)

    return out


def add_unified_core_features(df: pd.DataFrame) -> pd.DataFrame:
    """Add conditional consensus features for the unified Trading Intelligence Core.

    These features intentionally combine context rather than expose another set
    of raw book concepts. They are causal and shadow-testable.
    """
    out = df
    body = out["school_body_to_range"].fillna(0.0).clip(0, 2)
    follow = out["school_followthrough_3"].fillna(0.0).clip(-1, 1)
    eff10 = out["school_efficiency_10"].fillna(0.0).clip(0, 1)
    trend = out["school_trend_regime"].fillna(0.0).clip(0, 1)
    higher = out["school_higher_tf_alignment"].fillna(0.0).clip(-1, 1)
    disagreement = out["school_m1_vs_higher_disagreement"].fillna(0.0).clip(0, 1)
    pullback = out["school_pullback_score"].fillna(0.0).clip(0, 1)
    breakout = out["school_breakout_position_20"].fillna(0.0).clip(-2, 2)

    # Strong current body + persistent direction + efficient path + trend context.
    out["core_impulse_consensus"] = (
        np.sign(follow) * body.clip(0, 1) * follow.abs() * eff10 * (0.35 + 0.65 * trend)
    ).clip(-1, 1)

    # Higher-TF direction matters most in a trend and when M1 is not fighting it.
    out["core_mtf_trend_consensus"] = (
        higher * trend * (1.0 - disagreement)
    ).clip(-1, 1)

    # A pullback is directional only through its still-intact higher-TF context.
    out["core_pullback_in_trend"] = (
        higher * pullback * trend
    ).clip(-1, 1)

    # Breakout location is weighted by efficiency, trend context and HTF agreement.
    out["core_contextual_breakout"] = (
        breakout.clip(-1, 1) * eff10 * (0.25 + 0.75 * trend) * (0.5 + 0.5 * higher.abs())
    ).clip(-1, 1)

    # State variable: larger values mean more lower-vs-higher conflict in a trend.
    out["core_conflict_penalty"] = (disagreement * trend).clip(0, 1)
    return out
