# AUTHORITATIVE BOOK EXPANSION V3 — 2026-08-20

Purpose: expand the Trading School with highly authoritative, technically useful books that complement the existing price-action/MTF/quant library. This file registers titles and roles only. Copyrighted full books are NOT copied into GitHub. Full-book synthesis waits for a lawful user copy or licensed access.

## Selection rule
A book is included only when it fills a concrete gap for the XAU/USD project: market microstructure/execution, falsifiable technical-analysis testing, systematic research architecture, modern AI/ML validation, futures trend regimes, or intraday trading costs. Popularity alone is not enough.

## New high-priority books

### A1 — David Aronson — Evidence-Based Technical Analysis (2006/2007)
Role: scientific-method layer for every technical rule. Strongly relevant to the project's current problem where plausible book-derived features can look convincing but fail OOS.
Use for: hypothesis testing, data-mining bias, statistical inference, objective rule evaluation, false discoveries.
Legal digital route: Wiley Online Books / OverDrive ebook.
Status: USER_COPY_REQUIRED for full-text reading.
Priority: CRITICAL.

### A2 — Larry Harris — Trading and Exchanges: Market Microstructure for Practitioners (2002)
Role: market mechanics and execution reality.
Use for: bid/ask spread, liquidity, order types, order-driven markets, transaction costs, volatility, market structure, execution assumptions.
Why it matters to XAU/USD: frequent M1/M5 trading is highly sensitive to spread, liquidity and execution costs; backtests must not assume mid-price fills.
Legal digital route: Oxford Academic / OverDrive ebook.
Status: USER_COPY_REQUIRED for full-text reading.
Priority: CRITICAL.

### A3 — Álvaro Cartea, Sebastian Jaimungal, José Penalva — Algorithmic and High-Frequency Trading (2015)
Role: modern electronic-market / algorithmic execution framework.
Use for: limit order book, adverse selection, intraday volume/volatility/spread patterns, optimal execution, market making, trading algorithms.
Legal digital route: Cambridge University Press ebook; official front matter/excerpt exists.
Status: USER_COPY_REQUIRED for full-text reading.
Priority: HIGH.

### A4 — Jean-Philippe Bouchaud, Julius Bonart, Jonathan Donier, Martin Gould — Trades, Quotes and Prices: Financial Markets Under the Microscope (2018)
Role: empirical microstructure and price-impact layer.
Use for: order flow, spread, liquidity, price impact, adverse selection, micro/meso market dynamics, optimal execution.
Why it matters: helps distinguish a genuine impulse from short-lived microstructure noise and improves realistic execution/slippage hypotheses.
Legal digital route: Cambridge University Press.
Status: USER_COPY_REQUIRED for full-text reading.
Priority: HIGH.

### A5 — Charles-Albert Lehalle, Sophie Laruelle — Market Microstructure in Practice, 2nd Edition (2018)
Role: practical electronic trading and market-fragmentation / execution layer.
Use for: intraday price impact, optimal trading, liquidity, electronic-market behavior, quantitative microstructure indicators.
Legal digital route: World Scientific / licensed ebook vendors.
Status: USER_COPY_REQUIRED for full-text reading.
Priority: HIGH.

### A6 — Rishi K. Narang — Inside the Black Box: A Simple Guide to Systematic Investing, 3rd Edition (2024)
Role: current systematic-trading architecture.
Use for: alpha models, signal mixing, data, transaction-cost models, risk, research process, ML/alternative-data developments, execution.
Why this edition: substantially newer than the 2013 edition and explicitly updated for machine learning, signal mixing, data extraction and execution.
Legal digital route: Wiley / OverDrive EPUB.
Status: USER_COPY_REQUIRED for full-text reading.
Priority: HIGH.

### A7 — Ernest P. Chan — Machine Trading (2017)
Role: bridge between existing Chan books and intraday/ML implementation.
Use for: time-series analysis, AI techniques, intraday trading, market microstructure, systematic research workflow.
Legal digital route: Wiley ebook/library where available.
Status: USER_COPY_REQUIRED for full-text reading.
Priority: HIGH.

### A8 — Andreas F. Clenow — Following the Trend, 2nd Edition (2023)
Role: systematic futures trend/counter-trend regime research.
Use for: trend persistence, counter-trend pullbacks, futures data, volatility-based stops, robustness, practical execution and backtesting cautions.
Caution: mostly longer-horizon diversified futures; do NOT transplant parameters directly to M1/M5. Use only concepts/hypotheses and retest on XAU/USD.
Legal digital route: Wiley Online Books / O'Reilly subscription.
Status: USER_COPY_REQUIRED for full-text reading.
Priority: MEDIUM-HIGH.

### A9 — Irene Aldridge, Marco Avellaneda — Big Data Science in Finance (2021)
Role: rigorous data-science layer for finance.
Use for: feature construction, large financial data, quantitative methods, validation discipline and modern data workflows.
Legal digital route: Wiley ebook.
Status: USER_COPY_REQUIRED for full-text reading.
Priority: MEDIUM-HIGH.

### A10 — Hamlet Jesse Medina Ruiz, Ernest P. Chan — Generative AI for Trading and Asset Management (2025)
Role: modern AI/LLM research layer.
Use for: where generative AI can help research/synthesis and where it should NOT be trusted as a direct signal generator; design of AI-assisted research workflows.
Caution: AI advice never overrides numeric OOS acceptance.
Legal digital route: Wiley ebook.
Status: USER_COPY_REQUIRED for full-text reading.
Priority: MEDIUM-HIGH.

### A11 — Jiri Pik, Ernest P. Chan, Jared Broad, Philip Sun, Vivek Singh — Hands-On AI Trading with Python, QuantConnect, and AWS (2025)
Role: modern implementation/backtest/execution realism.
Use for: spread-aware fills, broker constraints, ML workflow, cloud research engineering, live-vs-backtest differences.
Legal digital route: Wiley ebook.
Status: USER_COPY_REQUIRED for full-text reading.
Priority: MEDIUM-HIGH.

### A12 — Andrew Green — Deep Learning in Quantitative Finance (2026)
Role: newest deep-learning reference in quantitative finance.
Use for: neural-network foundations, training, regularisation and application design.
Caution: not automatically suitable for M1 direction; only adopt architectures that beat simpler baselines under leakage-safe OOS tests.
Legal digital route: Wiley Online Books / ebook.
Status: USER_COPY_REQUIRED for full-text reading.
Priority: RESEARCH.

## Why these complement the existing library
The existing library is strongest in price action, MTF context, classic TA, trading systems, risk, and financial ML. The main gaps are:
1. realistic market microstructure / execution costs;
2. a strict scientific falsification layer for TA hypotheses;
3. newer systematic-trading architecture and AI research practices;
4. explicit spread/slippage/order-flow thinking for M1/M5.

## Required experiment design — do NOT blindly merge books
When lawful source material becomes available, every book contributes through three separate tracks:

TRACK 1 — INDIVIDUAL BOOK
- Distill one book independently.
- Normalize its terminology but retain source provenance.
- Build only causal/measurable hypotheses.
- Run leakage check -> OOS -> chronological blocks -> shadow.
- Record which market regimes and TFs help/hurt.

TRACK 2 — AUTHOR/DOMAIN GROUP
- Combine only compatible books within one domain, e.g. microstructure, price action, validation, AI/ML.
- Resolve duplicated concepts and explicitly flag contradictions.
- Test the domain group independently against champion.

TRACK 3 — UNIFIED TRADING INTELLIGENCE
- Merge only ideas that survived individual/domain tests OR are needed as context/router hypotheses.
- Do not average contradictory rules into one vague score.
- Use a regime/router layer when a concept only works under certain market states.
- Compare Unified vs best individual book vs champion.

## Acceptance rule
No book, author, AI advisor, or unified synthesis can directly change DEMO execution or active models. Promotion requires objective improvement on held-out data plus chronological robustness, realistic transaction-cost assumptions, and shadow/DEMO verification.

## DeepSeek role
DeepSeek must independently propose its own authoritative list without being told to agree with this file. Its output will be compared with this shortlist:
- overlap = stronger candidate for acquisition/review;
- unique DeepSeek proposal = verify publisher/edition/current relevance first;
- disagreement = keep both hypotheses and test, not vote by AI majority.

## Immediate priority if only a few books are acquired
1. Evidence-Based Technical Analysis — Aronson
2. Trading and Exchanges — Harris
3. Inside the Black Box, 3rd ed — Narang
4. Algorithmic and High-Frequency Trading — Cartea/Jaimungal/Penalva
5. Trades, Quotes and Prices — Bouchaud et al.
6. Machine Trading — Chan
7. Market Microstructure in Practice, 2nd ed — Lehalle/Laruelle

This order is chosen for the current XAU/USD M1/M5 system, not as a universal ranking of trading books.