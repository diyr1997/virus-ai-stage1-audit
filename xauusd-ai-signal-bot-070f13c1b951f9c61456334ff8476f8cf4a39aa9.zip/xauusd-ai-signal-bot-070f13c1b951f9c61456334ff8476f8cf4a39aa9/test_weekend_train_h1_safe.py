from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

from weekend_train_h1_safe import (
    dump_reload_verify,
    purged_chronological_split,
)


class FakeDirectionModel:
    def predict(self, X):
        return np.where(X[:, 0] >= 0.0, 1, -1)

    def predict_proba(self, X):
        p = np.clip(0.5 + X[:, 0] * 0.01, 0.01, 0.99)
        return np.column_stack([1.0 - p, p])


class FakeReturnModel:
    def predict(self, X):
        return X[:, 0] * 2.5 + X[:, 1] * 0.1


class WeekendTrainerSafetyTests(unittest.TestCase):
    def synthetic(self, rows=9000):
        ts = np.arange(rows, dtype=np.int64) * 60_000
        frame = pd.DataFrame(
            {
                "timestamp": ts,
                "future_ts_60": ts + 60 * 60_000,
                "f0": np.linspace(-2.0, 2.0, rows),
                "f1": np.linspace(1.0, 3.0, rows),
            }
        )
        return frame

    def test_purged_split_has_strict_label_boundary(self):
        split = purged_chronological_split(self.synthetic(), purge_rows=60)
        self.assertGreaterEqual(len(split.train_df), 5000)
        self.assertGreaterEqual(len(split.valid_df), 1500)
        self.assertEqual(split.purge_rows, 60)
        self.assertLess(split.train_end_future_ts, split.valid_start_ts)
        self.assertLess(
            int(split.train_df["future_ts_60"].max()),
            int(split.valid_df["timestamp"].min()),
        )

    def test_without_purge_boundary_would_leak(self):
        data = self.synthetic()
        raw_split = int(len(data) * 0.70)
        train = data.iloc[:raw_split]
        valid = data.iloc[raw_split:]
        self.assertGreaterEqual(
            int(train["future_ts_60"].max()),
            int(valid["timestamp"].min()),
        )

    def test_purge_rejects_insufficient_data(self):
        with self.assertRaises(RuntimeError):
            purged_chronological_split(self.synthetic(6500), purge_rows=60)

    def test_dump_reload_predictions_are_identical(self):
        frame = self.synthetic(1800).iloc[:500].copy()
        bundle = {
            "direction_models": {60: FakeDirectionModel()},
            "return_models": {60: FakeReturnModel()},
        }
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "challenger.joblib"
            result = dump_reload_verify(bundle, output, frame, ["f0", "f1"])
            self.assertTrue(result["reload_verified"])
            self.assertTrue(output.exists())


if __name__ == "__main__":
    unittest.main()
