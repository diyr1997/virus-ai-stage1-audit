"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const source = fs.readFileSync(
  path.join(__dirname, "index.js"),
  "utf8"
);

const start = source.indexOf("function buildTradePlan");
const end = source.indexOf(
  "// POSTGRES — SAVE ANALYSIS / CANDIDATE",
  start
);

assert(start >= 0 && end > start, "trade plan section not found");

const context = vm.createContext({
  strengthLotCap: () => 0.06,
});

vm.runInContext(source.slice(start, end), context);

const sell = vm.runInContext(
  `buildTradePlan(
    {
      price: 4364.41,
      atr: 4,
      direction: "SELL",
      action: "SELL",
      strength: 89,
      momentum: 0,
      trend: 0
    },
    "M5",
    { fresh: true, bid: 4364.83, ask: 4365.11 },
    []
  )`,
  context
);

assert(Math.abs(sell.confirmation - 4364.11) < 1e-9);
assert(Math.abs(sell.sl - 4367.71) < 1e-9);
assert.strictEqual(sell.invalidation, sell.sl);

assert(source.includes("только закрытая свеча ${timeframe}"));
assert(source.includes("сменился на противоположное направление/WAIT"));
assert(source.includes('"CLOSED_TF_OR_DIRECTION_CHANGE"'));

console.log("scenario cancellation tests: OK");
