# AI Council Task — Full Repository Audit

Run family: `REPO_AUDIT_FULL_2026_08_20_R1`

## Goal
Audit the entire XAU/USD project repository, not only recently changed files. Every available advisor receives the same repository manifest and the same source-code bundle for a given audit chunk, reviews it independently, then performs peer review of the other advisors' findings.

## Coverage
Review all relevant text/source/config files in the deployed repository, including:
- cloud Telegram analytics and autopilot code;
- AI/ML inference and training code;
- AI Council/provider/bootstrap code;
- news/CFTC modules;
- graph/forecast modules;
- Trading School source readers, trainers and manifests;
- `demo_mt5_worker` worker/trader/risk/launcher/tests;
- Railway/package/requirements/GitHub Actions configuration;
- project documentation/roadmaps when they affect behavior or contradict code.

Large files must be split into line-numbered chunks. A file is not considered reviewed merely because its name appeared in a manifest.

## Security / access boundary
The advisors receive sanitized READ-ONLY source text. Never expose `.env`, real `config_private.bat`, API keys, database URLs, Telegram tokens, MT5 secrets, credentials, binary files, caches or user data. Advisors propose patches; they do not receive direct write credentials and do not silently modify production.

## What every advisor must look for
1. Syntax/runtime errors and broken imports/exports.
2. Logic bugs, race conditions, duplicated polling/timers and duplicate execution paths.
3. Inconsistent assumptions between files, especially symbol/timeframe/timezone/freshness logic.
4. Any path that could open duplicate positions, reset symbol-level entry state, self-hedge BUY+SELL or bypass DEMO-only protection.
5. Candidate lifecycle bugs: OPEN/WAIT/EXPIRE/CANCEL/BLOCK, stale confirmation, duplicate candidates and cooldown conflicts.
6. Risk-manager mistakes: balance/equity/margin/free-margin/SL-risk/lot caps/add limits.
7. News-source freshness, deduplication, preview-vs-release classification, rate-limit/backoff and signal contamination.
8. Graph generation latency, duplicate/missing images, forecast invariants and misleading assumptions.
9. AI Council/provider problems: quota/backoff, duplicate paid calls, locking, context leakage, source verification and catch-up correctness.
10. Trading School/model leakage, look-ahead bias, train/test contamination, non-chronological validation, overfit promotion or false `UNDERSTOOD` state.
11. Error handling/restart behavior on Railway and Windows worker.
12. Secrets/privacy/security issues and unsafe logging.
13. Dead code, obsolete modules, duplicated implementations and configuration drift.
14. Missing deterministic tests and observability.
15. Simpler safer architecture where current design is unnecessarily complex.

## Required output per audit chunk
- files_and_lines_reviewed
- critical_findings
- high_findings
- medium_findings
- low_findings
- suspected_false_positives
- cross_file_inconsistencies
- security_or_secret_risks
- trading_safety_risks
- reliability_and_concurrency_risks
- exact_patch_proposals
- tests_required_before_fix
- what_must_not_change
- confidence

For every finding, identify exact file and line/range when possible, explain the failure mode, and distinguish CONFIRMED from SUSPECTED. Do not invent errors merely to produce findings.

## Peer-review rule
After independent review, inspect the other advisors' findings. Confirm or reject each material issue, look for missed interactions between files, and propose the smallest safe fix. Majority vote is not enough: use code evidence, deterministic tests and DEMO safety.

## Final repository synthesis
After chunk reviews exist, produce one cross-repository report that deduplicates findings, ranks fixes by severity/dependency, identifies architecture-level root causes, and defines a staged repair/test/rollback plan. No trading-rule change is activated merely because the council recommends it.
