# First Gemini Project Review

## Task

Review the entire XAU/USD project as a technical advisor. Do not change code or trading settings. Produce an independent audit and improvement roadmap.

## Review questions

1. What is the real current architecture of Bot 1, Bot 2, PostgreSQL, Railway and the Windows MT5 worker?
2. What has already been implemented and what is only planned?
3. Which recent changes may be incomplete, fragile or inconsistent?
4. What important problems may have been missed?
5. Which parts of the news engine can create stale, duplicated, delayed or misleading information for M1/M5?
6. Which parts of signal generation, confirmation, cancellation, SL/TP and result checking need validation?
7. Does Bot 2 correctly protect balance, equity, free margin, open positions and DEMO-only safety?
8. What data, logging, tests and backtests are missing?
9. What should be improved first, second and third?
10. Which suggestions are unsafe or should not be implemented?

## Required output

Return:

- project_understanding
- implemented_now
- incomplete_or_planned
- suspected_problems
- news_improvements
- signal_improvements
- demo_risk_improvements
- data_and_testing_gaps
- prioritized_roadmap
- quick_safe_wins
- changes_to_avoid
- exact_files_to_review
- test_plan
- confidence_and_unknowns

Every proposal must include expected benefit, risk, required files, validation method and rollback plan.

The review is advisory only. Never expose secrets, change production, change MT5 execution, or recommend real-account trading.
