"use strict";

const crypto = require("crypto");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { promisify } = require("util");
const { execFile } = require("child_process");
const { Pool } = require("pg");
const {
  classifyTrainingTier,
  auditCandles,
  dataFingerprint,
  shouldRunNewDataExperiment,
} = require("./training-data-policy");

const execFileAsync = promisify(execFile);
const TZ = process.env.CURRENT_DATA_LAB_TIMEZONE || "Asia/Tashkent";
const DATABASE_URL = String(
  process.env.DATABASE_URL || process.env.DATABASE_PUBLIC_URL || ""
).trim();
const BOT_TOKEN = String(process.env.TELEGRAM_BOT_TOKEN || "").trim();
const PYTHON = process.env.PYTHON_BIN || path.join(__dirname, ".venv", "bin", "python");
const EXPLORATORY_TRAINER = path.join(__dirname, "exploratory_train_h1.py");
const CHALLENGER_TRAINER = path.join(__dirname, "weekend_train_h1.py");
const BUILTIN_MODEL = path.join(__dirname, "xauusd_ai_final_h1_full_period.joblib");
const ACTIVE_MODEL_TMP = path.join(os.tmpdir(), "xauusd_ai_h1_active.joblib");
const ENABLED = !/^(0|false|no|disabled)$/i.test(
  String(process.env.CURRENT_DATA_LAB_ENABLED || "1")
);
const CHECK_MS = Math.max(30_000, Number(process.env.CURRENT_DATA_LAB_CHECK_MS || 60_000));
const START_HOUR = Math.max(3, Math.min(10, Number(process.env.CURRENT_DATA_LAB_START_HOUR || 5)));
const SLOT_HOURS = Math.max(2, Math.min(6, Number(process.env.CURRENT_DATA_LAB_SLOT_HOURS || 4)));
const LAST_HEAVY_HOUR = Math.max(18, Math.min(22, Number(process.env.CURRENT_DATA_LAB_LAST_HOUR || 20)));
const NEW_DATA_STEP = Math.max(250, Number(process.env.CURRENT_DATA_LAB_NEW_DATA_STEP || 1000));
const PROMOTION_MIN_ROWS = Math.max(8000, Number(process.env.CURRENT_DATA_LAB_PROMOTION_MIN_ROWS || 15000));
const PROMOTION_MIN_DAYS = Math.max(5, Number(process.env.CURRENT_DATA_LAB_PROMOTION_MIN_DAYS || 10));

const pool = DATABASE_URL
  ? new Pool({ connectionString: DATABASE_URL, max: 2, idleTimeoutMillis: 30_000 })
  : null;
let running = false;

function localParts(now = new Date()) {
  const fmt = new Intl.DateTimeFormat("en-CA", {
    timeZone: TZ,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    weekday: "short",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  });
  const parts = Object.fromEntries(
    fmt.formatToParts(now)
      .filter((p) => p.type !== "literal")
      .map((p) => [p.type, p.value])
  );
  return {
    date: `${parts.year}-${parts.month}-${parts.day}`,
    weekday: parts.weekday,
    hour: Number(parts.hour),
    minute: Number(parts.minute),
  };
}

function weekendSlot(local) {
  if (!["Sat", "Sun"].includes(local.weekday)) return null;
  const dayStart = local.weekday === "Sat" ? START_HOUR : 0;
  if (local.hour < dayStart || local.hour > LAST_HEAVY_HOUR) return null;
  const slotIndex = Math.floor((local.hour - dayStart) / SLOT_HOURS);
  const slotHour = dayStart + slotIndex * SLOT_HOURS;
  if (slotHour > LAST_HEAVY_HOUR) return null;
  const saturdaySlots = Math.floor((LAST_HEAVY_HOUR - START_HOUR) / SLOT_HOURS) + 1;
  const sundaySlots = Math.floor(LAST_HEAVY_HOUR / SLOT_HOURS) + 1;
  const trial = local.weekday === "Sat" ? slotIndex : saturdaySlots + slotIndex;
  const final = local.weekday === "Sun" && slotIndex === sundaySlots - 1;
  return { slotIndex, slotHour, trial, final };
}

async function ensureSchema() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS training_current_data_runs (
      run_key TEXT PRIMARY KEY,
      kind TEXT NOT NULL,
      status TEXT NOT NULL,
      tier TEXT,
      source_rows INTEGER,
      trading_days INTEGER,
      data_hash TEXT,
      started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      finished_at TIMESTAMPTZ,
      metrics JSONB NOT NULL DEFAULT '{}'::jsonb,
      report JSONB NOT NULL DEFAULT '{}'::jsonb,
      error TEXT
    )
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS model_registry (
      id BIGSERIAL PRIMARY KEY,
      model_key VARCHAR(40) NOT NULL,
      version VARCHAR(120) NOT NULL UNIQUE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      active BOOLEAN NOT NULL DEFAULT FALSE,
      source VARCHAR(40) NOT NULL DEFAULT 'AUTO_TRAINING',
      metrics JSONB NOT NULL DEFAULT '{}'::jsonb,
      model_bytes BYTEA NOT NULL,
      payload JSONB NOT NULL DEFAULT '{}'::jsonb
    )
  `);
  await pool.query(`
    CREATE INDEX IF NOT EXISTS idx_model_registry_active
    ON model_registry(model_key, active, created_at DESC)
  `);
}

async function claimRun(runKey, kind) {
  const result = await pool.query(
    `INSERT INTO training_current_data_runs(run_key,kind,status)
     VALUES($1,$2,'RUNNING') ON CONFLICT(run_key) DO NOTHING RETURNING run_key`,
    [runKey, kind]
  );
  return result.rowCount === 1;
}

async function finishRun(runKey, status, fields = {}) {
  await pool.query(
    `UPDATE training_current_data_runs
     SET status=$2, tier=$3, source_rows=$4, trading_days=$5, data_hash=$6,
         finished_at=NOW(), metrics=$7::jsonb, report=$8::jsonb, error=$9
     WHERE run_key=$1`,
    [
      runKey,
      status,
      fields.tier || null,
      fields.sourceRows ?? null,
      fields.tradingDays ?? null,
      fields.dataHash || null,
      JSON.stringify(fields.metrics || {}),
      JSON.stringify(fields.report || {}),
      fields.error || null,
    ]
  );
}

async function currentM1Count() {
  const result = await pool.query(
    `SELECT COUNT(*)::int AS rows FROM xauusd_candles WHERE timeframe='M1'`
  );
  return Number(result.rows[0]?.rows || 0);
}

async function exportAllCandles() {
  const result = await pool.query(`
    SELECT (EXTRACT(EPOCH FROM candle_time)*1000)::bigint AS timestamp,
           open::float8, high::float8, low::float8, close::float8, volume::float8
    FROM xauusd_candles
    WHERE timeframe='M1'
    ORDER BY candle_time ASC
  `);
  return result.rows.map((row) => ({ ...row, timestamp: Number(row.timestamp) }));
}

async function materializeChampion() {
  const result = await pool.query(
    `SELECT version, model_bytes FROM model_registry
     WHERE model_key='H1' AND active=TRUE ORDER BY created_at DESC LIMIT 1`
  );
  if (result.rows[0]?.model_bytes) {
    fs.writeFileSync(ACTIVE_MODEL_TMP, result.rows[0].model_bytes);
    return { path: ACTIVE_MODEL_TMP, version: result.rows[0].version, source: "registry" };
  }
  return { path: BUILTIN_MODEL, version: "builtin", source: "repository" };
}

async function promoteModel(training, candidatePath, dataHash) {
  if (!training?.accepted || !training?.promotion_eligible) return false;
  const bytes = fs.readFileSync(candidatePath);
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query(`UPDATE model_registry SET active=FALSE WHERE model_key='H1' AND active=TRUE`);
    await client.query(
      `INSERT INTO model_registry(model_key,version,active,source,metrics,model_bytes,payload)
       VALUES('H1',$1,TRUE,'CURRENT_DATA_LAB',$2::jsonb,$3,$4::jsonb)`,
      [
        training.version,
        JSON.stringify(training),
        bytes,
        JSON.stringify({ promoted_at: new Date().toISOString(), data_hash: dataHash }),
      ]
    );
    await client.query("COMMIT");
    fs.writeFileSync(ACTIVE_MODEL_TMP, bytes);
    return true;
  } catch (error) {
    await client.query("ROLLBACK").catch(() => {});
    throw error;
  } finally {
    client.release();
  }
}

function parseLastJsonLine(stdout) {
  const line = String(stdout || "").trim().split(/\r?\n/).filter(Boolean).pop();
  return JSON.parse(line || "{}");
}

async function runTraining(candles, tier, trial, audit, dataHash) {
  const champion = await materializeChampion();
  const stamp = Date.now();
  const candlesPath = path.join(os.tmpdir(), `current_data_candles_${stamp}.json`);
  const candidatePath = path.join(os.tmpdir(), `current_data_candidate_${stamp}.joblib`);
  fs.writeFileSync(candlesPath, JSON.stringify(candles), "utf8");

  try {
    if (!tier.canTrain) {
      return {
        ok: true,
        experiment_tier: tier.tier,
        promotion_eligible: false,
        promoted: false,
        source_rows: audit.rows,
        trading_days: audit.tradingDays,
        reason: tier.reason,
      };
    }

    if (!tier.canPromote) {
      const { stdout, stderr } = await execFileAsync(
        PYTHON,
        [EXPLORATORY_TRAINER, "--champion", champion.path, "--candles", candlesPath, "--trial", String(trial)],
        { timeout: 15 * 60_000, maxBuffer: 4 * 1024 * 1024 }
      );
      if (stderr?.trim()) console.log("🧪 CURRENT DATA exploratory stderr:", stderr.trim().slice(0, 1200));
      const training = parseLastJsonLine(stdout);
      if (!training.ok) throw new Error(training.error || "exploratory training failed");
      training.experiment_tier = tier.tier;
      training.promotion_eligible = false;
      training.promoted = false;
      training.promotion_block_reason = tier.reason;
      training.data_hash = dataHash;
      training.champion_source = champion.source;
      return training;
    }

    const { stdout, stderr } = await execFileAsync(
      PYTHON,
      [
        CHALLENGER_TRAINER,
        "--champion", champion.path,
        "--candles", candlesPath,
        "--output", candidatePath,
        "--mode", "weekend",
        "--trial", String(trial),
      ],
      { timeout: 30 * 60_000, maxBuffer: 4 * 1024 * 1024 }
    );
    if (stderr?.trim()) console.log("🧠 CURRENT DATA challenger stderr:", stderr.trim().slice(0, 1200));
    const training = parseLastJsonLine(stdout);
    if (!training.ok) throw new Error(training.error || "challenger training failed");
    training.experiment_tier = tier.tier;
    training.promotion_eligible = true;
    training.data_hash = dataHash;
    training.champion_source = champion.source;
    training.promoted = await promoteModel(training, candidatePath, dataHash);
    return training;
  } finally {
    fs.unlink(candlesPath, () => {});
    fs.unlink(candidatePath, () => {});
  }
}

async function ownerChatId() {
  const env = Number(process.env.TELEGRAM_OWNER_CHAT_ID || 0);
  if (env) return env;
  const result = await pool.query(`SELECT value FROM bot_settings WHERE key='owner_chat_id' LIMIT 1`);
  return Number(result.rows[0]?.value || 0);
}

async function notify(text) {
  const chatId = await ownerChatId().catch(() => 0);
  if (!BOT_TOKEN || !chatId) return;
  await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, text: String(text).slice(0, 3900) }),
  }).catch(() => {});
}

async function lastSuccessfulRows() {
  const result = await pool.query(`
    SELECT source_rows FROM training_current_data_runs
    WHERE status='SUCCESS' AND source_rows IS NOT NULL
    ORDER BY finished_at DESC NULLS LAST LIMIT 1
  `);
  return Number(result.rows[0]?.source_rows || 0);
}

async function executeRun(kind, runKey, options = {}) {
  if (!(await claimRun(runKey, kind))) return false;
  console.log(`🧪 CURRENT DATA LAB START | ${runKey}`);

  try {
    const candles = await exportAllCandles();
    const audit = auditCandles(candles);
    const tier = classifyTrainingTier(
      { rows: audit.rows, tradingDays: audit.tradingDays },
      { promotionMinRows: PROMOTION_MIN_ROWS, promotionMinTradingDays: PROMOTION_MIN_DAYS }
    );
    const fingerprint = dataFingerprint(candles);

    if (!audit.qualityPass) {
      await finishRun(runKey, "FAILED", {
        tier: tier.tier,
        sourceRows: audit.rows,
        tradingDays: audit.tradingDays,
        dataHash: fingerprint,
        metrics: { audit },
        error: `data_quality_failed_duplicates=${audit.duplicates}_invalid=${audit.invalid}`,
      });
      console.warn(`⚠️ CURRENT DATA LAB quality gate blocked | rows=${audit.rows}`);
      return false;
    }

    const training = await runTraining(candles, tier, Number(options.trial || 0), audit, fingerprint);
    const report = {
      audit,
      training,
      owner_policy: "use all currently available verified M1 data; never idle only because promotion data is insufficient",
      promotion_gate: `>=${PROMOTION_MIN_ROWS} rows and >=${PROMOTION_MIN_DAYS} trading days plus existing OOS acceptance`,
    };
    await finishRun(runKey, "SUCCESS", {
      tier: tier.tier,
      sourceRows: audit.rows,
      tradingDays: audit.tradingDays,
      dataHash: fingerprint,
      metrics: {
        direction_accuracy_gain: training.direction_accuracy_gain ?? null,
        challenger_metrics: training.challenger_metrics || {},
        champion_metrics: training.champion_metrics || {},
      },
      report,
    });

    console.log(
      `🧪 CURRENT DATA LAB DONE | ${runKey} | tier=${tier.tier} | rows=${audit.rows} | days=${audit.tradingDays} | promoted=${Boolean(training.promoted)}`
    );

    if (kind === "DAILY" || options.final || training.promoted || options.notifyExploratory) {
      await notify(
        `🧪 ОБУЧЕНИЕ НА ТЕКУЩИХ ДАННЫХ\n` +
        `M1: ${audit.rows} • дней: ${audit.tradingDays}\n` +
        `Режим: ${tier.tier}\n` +
        `Эксперимент: ${training?.profile?.name || "data audit"}\n` +
        `${training.promoted ? `✅ Champion заменён: ${training.version}` : "🛡 Champion не менялся"}\n` +
        `Все доступные данные этого запуска использованы; результат сохранён.`
      );
    }
    return true;
  } catch (error) {
    await finishRun(runKey, "FAILED", { error: String(error?.message || error) }).catch(() => {});
    console.error(`❌ CURRENT DATA LAB | ${runKey}:`, error);
    if (options.final || kind === "DAILY") {
      await notify(`❌ CURRENT DATA LAB FAILED\n${String(error?.message || error).slice(0, 1200)}\nChampion не менялся.`);
    }
    return false;
  }
}

async function schedulerTick() {
  if (!ENABLED || !pool || running) return;
  const local = localParts();
  let kind = null;
  let runKey = null;
  let options = {};

  if (["Mon", "Tue", "Wed", "Thu", "Fri"].includes(local.weekday) && local.hour === 2 && local.minute >= 5) {
    kind = "DAILY";
    runKey = `${local.date}:CURRENT_DATA_DAILY`;
  } else {
    const slot = weekendSlot(local);
    if (slot) {
      kind = local.weekday === "Sat" ? "WEEKEND_SAT" : "WEEKEND_SUN";
      runKey = `${local.date}:CURRENT_DATA:${kind}:H${String(slot.slotHour).padStart(2, "0")}`;
      options = {
        trial: slot.trial,
        final: slot.final,
        notifyExploratory: local.weekday === "Sat" && slot.slotIndex === 0,
      };
    }
  }

  if (!kind && ["Sat", "Sun"].includes(local.weekday)) {
    const [currentRows, previousRows] = await Promise.all([currentM1Count(), lastSuccessfulRows()]);
    if (shouldRunNewDataExperiment({ currentRows, lastRows: previousRows, step: NEW_DATA_STEP })) {
      const bucket = Math.floor(currentRows / NEW_DATA_STEP);
      kind = "NEW_DATA";
      runKey = `${local.date}:CURRENT_DATA:NEW:${bucket}`;
      options = { trial: bucket, notifyExploratory: false };
    }
  }

  if (!kind) return;
  running = true;
  try {
    await executeRun(kind, runKey, options);
  } finally {
    running = false;
  }
}

async function start() {
  if (!ENABLED) {
    console.log("🧪 CURRENT DATA LAB: disabled");
    return;
  }
  if (!pool) {
    console.warn("⚠️ CURRENT DATA LAB: PostgreSQL unavailable");
    return;
  }
  await ensureSchema();
  console.log(
    `✅ CURRENT DATA LAB V1: all verified M1; exploratory >=1000; promotion >=${PROMOTION_MIN_ROWS} rows + ${PROMOTION_MIN_DAYS} days; daily 02:05 ${TZ}; Weekend ${START_HOUR}:00 -> Sun ${LAST_HEAVY_HOUR}:00 every ${SLOT_HOURS}h`
  );
  setTimeout(() => schedulerTick().catch((e) => console.error("CURRENT DATA LAB tick:", e)), 20_000);
  setInterval(() => schedulerTick().catch((e) => console.error("CURRENT DATA LAB tick:", e)), CHECK_MS).unref();
}

if (!/^(1|true|yes)$/i.test(String(process.env.CURRENT_DATA_LAB_DISABLE_AUTOSTART || "0"))) {
  start().catch((error) => console.error("❌ CURRENT DATA LAB INIT:", error));
}

module.exports = {
  localParts,
  weekendSlot,
  currentM1Count,
  executeRun,
  schedulerTick,
  start,
};
