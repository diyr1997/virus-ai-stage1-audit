"use strict";

const fs = require("fs");
const path = require("path");
const { Pool } = require("pg");
const {
  buildMasterContextSnapshot,
  enqueueCouncilTask,
  ensureCouncilSchema,
} = require("./ai-council-persistent");

const ROOT = __dirname;
const RUN_PREFIX = "REPO_AUDIT_FULL_2026_08_20_R1";
const SYNTHESIS_ID = `${RUN_PREFIX}_SYNTHESIS`;
const MAX_BUNDLE_CHARS = Math.max(
  20_000,
  Number(process.env.AI_COUNCIL_REPO_AUDIT_BUNDLE_CHARS || 65_000)
);
const MAX_FILE_CHUNK_CHARS = Math.max(
  10_000,
  Number(process.env.AI_COUNCIL_REPO_AUDIT_FILE_CHUNK_CHARS || 30_000)
);

const ALLOWED_EXTENSIONS = new Set([
  ".js",
  ".cjs",
  ".mjs",
  ".py",
  ".json",
  ".md",
  ".txt",
  ".yml",
  ".yaml",
  ".toml",
  ".ini",
  ".cfg",
  ".bat",
  ".ps1",
  ".sh",
]);

const EXCLUDED_DIRS = new Set([
  ".git",
  "node_modules",
  ".venv",
  "venv",
  "__pycache__",
  ".pytest_cache",
  ".mypy_cache",
  ".ruff_cache",
  "dist",
  "build",
  "coverage",
]);

function normalizeRelative(full) {
  return path.relative(ROOT, full).split(path.sep).join("/");
}

function isSensitivePath(relative) {
  const rel = String(relative || "").toLowerCase();
  const base = path.basename(rel);

  if (base === ".env" || base.startsWith(".env.")) return true;
  if (base === "config_private.bat" || base === "config_private.ps1") return true;
  if (/\.(pem|p12|pfx|key|crt)$/i.test(base)) return true;
  if (/^(id_rsa|id_ed25519|credentials\.json|secrets?\.json)$/i.test(base)) return true;
  if (/secret|private[_-]?key|api[_-]?key[_-]?dump|token[_-]?dump/i.test(base)) {
    return !/example|template|setup|readme/i.test(base);
  }
  return false;
}

function isAllowedFile(relative) {
  if (isSensitivePath(relative)) return false;
  const base = path.basename(relative);
  if (base === "Dockerfile" || base === ".gitignore") return true;
  const ext = path.extname(base).toLowerCase();
  return ALLOWED_EXTENSIONS.has(ext);
}

function walk(dir = ROOT, out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.isDirectory() && EXCLUDED_DIRS.has(entry.name)) continue;
    const full = path.join(dir, entry.name);
    const relative = normalizeRelative(full);

    if (entry.isDirectory()) {
      walk(full, out);
      continue;
    }
    if (!entry.isFile() || !isAllowedFile(relative)) continue;
    out.push(full);
  }
  return out;
}

function readTextSafe(full) {
  const buffer = fs.readFileSync(full);
  if (buffer.includes(0)) return null;
  return buffer.toString("utf8");
}

function domainFor(relative) {
  const rel = relative.toLowerCase();
  if (rel.startsWith("demo_mt5_worker/")) return "demo_worker";
  if (rel.startsWith("trading_school/") || rel.includes("trading-school")) {
    return "trading_school";
  }
  if (/news|cftc|gdelt|fed|bls|ecb|boj|boe/.test(rel)) return "news";
  if (/graph|forecast|chart/.test(rel)) return "graph_forecast";
  if (/ai-council|ai-providers|grok|deepseek|gemini|claude/.test(rel)) {
    return "ai_council";
  }
  if (/ai_predict|ai_h1|model|train|feature|backtest/.test(rel)) return "model_ml";
  if (
    rel.startsWith(".github/") ||
    /railpack|package\.json|requirements|dockerfile|\.ya?ml$|\.toml$|\.bat$|\.ps1$/.test(rel)
  ) {
    return "deploy_config";
  }
  if (/\.md$|\.txt$/.test(rel)) return "docs_specs";
  return "cloud_core";
}

function splitFile(relative, text) {
  const lines = String(text || "").split(/\r?\n/);
  const chunks = [];
  let start = 1;
  let current = [];
  let chars = 0;

  function flush() {
    if (!current.length) return;
    const end = start + current.length - 1;
    const numbered = current
      .map((line, index) => `${start + index}: ${line}`)
      .join("\n");
    chunks.push({
      relative,
      domain: domainFor(relative),
      startLine: start,
      endLine: end,
      text: `===== FILE ${relative} L${start}-L${end} =====\n${numbered}`,
    });
    start = end + 1;
    current = [];
    chars = 0;
  }

  for (const line of lines) {
    const next = String(line).length + 12;
    if (current.length && chars + next > MAX_FILE_CHUNK_CHARS) flush();
    current.push(line);
    chars += next;
  }
  flush();
  return chunks;
}

function buildRepositorySnapshot() {
  const files = [];
  const chunks = [];

  for (const full of walk()) {
    const relative = normalizeRelative(full);
    let text;
    try {
      text = readTextSafe(full);
    } catch (error) {
      files.push({ relative, error: error.message, included: false });
      continue;
    }
    if (text === null) {
      files.push({ relative, binary: true, included: false });
      continue;
    }

    const fileChunks = splitFile(relative, text);
    files.push({
      relative,
      included: true,
      chars: text.length,
      lines: text.split(/\r?\n/).length,
      domain: domainFor(relative),
      chunks: fileChunks.length,
    });
    chunks.push(...fileChunks);
  }

  return { files, chunks };
}

function buildBundles(chunks) {
  const byDomain = new Map();
  for (const chunk of chunks) {
    if (!byDomain.has(chunk.domain)) byDomain.set(chunk.domain, []);
    byDomain.get(chunk.domain).push(chunk);
  }

  const bundles = [];
  for (const [domain, domainChunks] of byDomain.entries()) {
    let current = [];
    let chars = 0;
    let part = 1;

    const flush = () => {
      if (!current.length) return;
      bundles.push({ domain, part, chunks: current });
      part += 1;
      current = [];
      chars = 0;
    };

    for (const chunk of domainChunks) {
      const size = chunk.text.length + 200;
      if (current.length && chars + size > MAX_BUNDLE_CHARS) flush();
      current.push(chunk);
      chars += size;
    }
    flush();
  }

  return bundles;
}

function compactManifest(files) {
  return files
    .map((file) => {
      if (!file.included) {
        return `${file.relative} | EXCLUDED_FROM_TEXT | ${file.binary ? "binary" : file.error || "sensitive/unsupported"}`;
      }
      return `${file.relative} | ${file.domain} | ${file.lines} lines | ${file.chars} chars | ${file.chunks} chunk(s)`;
    })
    .join("\n");
}

function bundleTaskText(baseTask, bundle, index, total) {
  const coverage = bundle.chunks
    .map((chunk) => `${chunk.relative}: L${chunk.startLine}-L${chunk.endLine}`)
    .join("\n");

  return [
    baseTask,
    "",
    `## Current audit bundle ${index + 1}/${total}`,
    `Domain: ${bundle.domain}`,
    "Exact source coverage in this bundle:",
    coverage,
    "",
    "Review every supplied line. Cross-reference against the shared roadmap/project context. Do not assume another bundle will catch a local bug.",
  ].join("\n");
}

async function seedRepoAuditTasks() {
  if (/^(0|false|no|disabled)$/i.test(
    String(process.env.AI_COUNCIL_REPO_AUDIT_ENABLED || "1")
  )) {
    return [];
  }

  await ensureCouncilSchema();
  const baseTask = fs.readFileSync(
    path.join(ROOT, "AI_COUNCIL_REPO_AUDIT_TASK.md"),
    "utf8"
  );
  const baseContext = buildMasterContextSnapshot();
  const snapshot = buildRepositorySnapshot();
  const manifest = compactManifest(snapshot.files);
  const bundles = buildBundles(snapshot.chunks);
  const ids = [];

  for (let index = 0; index < bundles.length; index += 1) {
    const bundle = bundles[index];
    const taskId = `${RUN_PREFIX}_${String(index + 1).padStart(2, "0")}_${bundle.domain}`;
    const sourceText = bundle.chunks.map((chunk) => chunk.text).join("\n\n");
    const contextSnapshot = [
      baseContext,
      "",
      "===== FULL REPOSITORY MANIFEST =====",
      manifest,
      "",
      "===== READ-ONLY SOURCE BUNDLE =====",
      sourceText,
    ].join("\n");

    await enqueueCouncilTask({
      taskId,
      taskType: "repo_code_audit",
      task: bundleTaskText(baseTask, bundle, index, bundles.length),
      contextSnapshot,
    });
    ids.push(taskId);
  }

  return ids;
}

async function maybeSeedRepoAuditSynthesis(taskIds) {
  if (!Array.isArray(taskIds) || !taskIds.length) return false;
  const databaseUrl = String(process.env.DATABASE_URL || "").trim();
  if (!databaseUrl) return false;

  const db = new Pool({ connectionString: databaseUrl });
  try {
    const { rows } = await db.query(
      `SELECT id, final_plan, revision, status
       FROM ai_council_tasks
       WHERE id = ANY($1::text[])
       ORDER BY id`,
      [taskIds]
    );

    if (rows.length !== taskIds.length || rows.some((row) => !row.final_plan)) {
      return false;
    }

    const findings = rows
      .map(
        (row) =>
          `===== ${row.id} | revision=${row.revision} | status=${row.status} =====\n${row.final_plan}`
      )
      .join("\n\n");

    const task = [
      fs.readFileSync(path.join(ROOT, "AI_COUNCIL_REPO_AUDIT_TASK.md"), "utf8"),
      "",
      "## FINAL CROSS-REPOSITORY SYNTHESIS",
      "All audit bundles below already have provisional council syntheses. Reconcile them across the entire repository.",
      "Deduplicate repeated findings. Identify root causes spanning multiple files. Rank fixes CRITICAL/HIGH/MEDIUM/LOW and specify dependencies, exact tests and rollback.",
      "Do not automatically apply patches; produce the joint repair plan first.",
    ].join("\n");

    await enqueueCouncilTask({
      taskId: SYNTHESIS_ID,
      taskType: "repo_audit_synthesis",
      task,
      contextSnapshot: `${buildMasterContextSnapshot()}\n\n===== BUNDLE COUNCIL FINDINGS =====\n${findings}`,
    });
    return true;
  } finally {
    await db.end();
  }
}

async function seedAndAdvanceRepoAudit() {
  const taskIds = await seedRepoAuditTasks();
  await maybeSeedRepoAuditSynthesis(taskIds);
  return taskIds;
}

module.exports = {
  RUN_PREFIX,
  SYNTHESIS_ID,
  buildRepositorySnapshot,
  buildBundles,
  seedRepoAuditTasks,
  maybeSeedRepoAuditSynthesis,
  seedAndAdvanceRepoAudit,
};
