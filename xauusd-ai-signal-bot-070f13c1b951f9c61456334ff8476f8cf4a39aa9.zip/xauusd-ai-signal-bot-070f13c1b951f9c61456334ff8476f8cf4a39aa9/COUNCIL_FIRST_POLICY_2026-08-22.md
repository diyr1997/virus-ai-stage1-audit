# COUNCIL_FIRST Project Policy — 2026-08-22

Owner mandate: every material XAU/USD project mutation must be reviewed by the available AI Council before implementation starts, and the resulting draft/diff must receive a second Council implementation review before merge/deploy.

This document records the policy only. Enforcement code is implemented separately and must fail closed for mutations while keeping read-only status paths alive.

## Material mutations covered
- code/file changes
- configuration/environment changes
- DB schema/data migrations that alter behavior
- trading/entry/exit/risk logic
- news logic/sources/weights
- model/training/promotion logic
- graph/forecast behavior
- Telegram command behavior that mutates project state
- local worker packaging/startup behavior

Read-only status/diagnostic questions may bypass implementation authorization.

## Required Council flow
RECEIVED -> COUNCIL_PENDING -> PROVISIONAL_REVIEW or REVIEWED -> AUTHORIZED_FOR_DRAFT -> DRAFT_REVIEW_PENDING -> AUTHORIZED_FOR_MERGE

Failure states: BLOCKED / FAILED.

Configured-but-unavailable advisors remain recorded as pending/retry and must catch up later. Never claim unavailable advisors participated.

## ChatGPT bridge limitation
Railway cannot intercept messages sent inside the ChatGPT application by itself. For ChatGPT-originated project change requests, the assistant must explicitly enqueue the request into the same Council intake before modifying the repository/project.

## Non-negotiable safety
- Automatic execution stays DEMO only.
- REAL trading remains blocked.
- Bot #1 Railway analytics state and Bot #2 local MT5 worker state remain isolated.
- No simultaneous bot BUY+SELL basket.
- Model/strategy/news changes require measured validation, not AI opinion alone.
