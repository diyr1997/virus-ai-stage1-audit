# AI Toolbox — master completion audit, 2026-09-15

Branch: `claude/toolbox-master-completion-2026-09-15` (from `main`). PR #225.
Author: Claude Code.

Three passes:

- **Pass 1** — built the master inventory (43 → **72** unique candidates) from
  `main`, the unmerged `ai/integrate-agent-toolbox-2026-09-10` branch, the
  quant/ml/news toolbox manifests, unmerged shadow-model branches, and the
  Google Drive master inventory.
- **Pass 2** — closed the mandatory gaps: a **fresh security gate**, real
  functional verification of the Claude-side development tools, a reproducible
  research environment, the two missing durable-memory files, and the toolbox
  branch reconciliation.
- **Pass 3** — fresh payload-only scans of the four remaining skill packs, two
  real parity tests (purgedcv vs the native validation stack, orderflow-metrics
  vs the canonical OFI formula), a definitive check of the Ponytail plugin path,
  and the final diff/security review. See **Pass 3 results** below.

Machine-readable data: `AI_TOOLBOX_MASTER_INVENTORY_2026-09-15.json` (per-tool
record, all 72) and `AI_TOOLBOX_ADOPTION_MATRIX_2026-09-15.json` (decision view).

## Correction to pass 1: GitHub access

Pass 1 concluded that only `WebSearch` could verify external repos, because
`curl`/`WebFetch` to other GitHub repos return 403. **That was wrong in an
important way**: `git clone` of arbitrary public repos *does* work here (the
proxy allows git transport while scoping the HTTP API). Pass 2 therefore
cloned, installed and executed the real tools instead of reasoning about them.

This also resolved both `EXISTENCE_UNCONFIRMED` entries: **Scout**
(`pedrobraiti/market-research-mcp`, HEAD `070c908`, MIT) and **Valet**
(`pedrobraiti/agentic-trading-mcp`, HEAD `caafaeb`, MIT) are both real. Their
earlier "unconfirmed" status was a search-indexing gap, not a missing repo.

## Phase 2 — fresh security gate (supersedes the 2026-09-10 Railway audit)

**NVIDIA SkillSpector 2.11.2**, cloned at commit
`03e8f56bdb9ddb85d7db09ca592f97dd0f545c41`, installed in an isolated Python 3.13
venv (it requires `>=3.12,<3.15`; the default interpreter here is 3.11), and
actually executed. Five scans were run.

**Stated limitation:** its LLM/semantic analyzers are skipped because no API key
is provisioned (`Skipping analyzer semantic_*: required API key is missing`), so
every finding below is a **static pattern match**, not semantic analysis.

### Method correction that changed the outcome

Scanning a **whole repository** produces heavy false positives, because benchmark
suites, tests, READMEs and `.env.example` files get scanned even though they are
never installed. The correct target is the **installable payload only**
(`skills/`, `hooks/`, `commands/`, plugin manifest).

| Target | Full-repo verdict | Payload-only verdict |
|---|---|---|
| Ponytail | CRITICAL / `DO_NOT_INSTALL`, 105 issues (35 HIGH) | **score 0, LOW, 0 issues** |
| Graphify | (not completed — slow) | score 88, CRITICAL, 4 HIGH → all false positives |
| Andrej Karpathy Skills | — | **score 0, LOW, `SAFE`, 0 issues** |
| Headroom | — | **score 0, LOW, `SAFE`, 0 issues** |

### Documented false-positive overrides

Project policy permits overriding a scanner finding only with a written manual
review of that specific finding. Two overrides were made:

**Ponytail** — all 35 HIGH findings are in `benchmarks/` (22), `tests/` (7),
`README.md` (2), `.env.example`, `.gitignore`, `__init__.py`, `docs/`. **Zero**
in the installable payload. Individually reviewed:
- *"Privilege Escalation / Credential Access"* in `.env.example` — the file
  contains the placeholder `ANTHROPIC_API_KEY=sk-ant-...` as a template.
- *"Agent Snooping"* in `README.md:327` — the README's **uninstall instructions**
  documenting which files Ponytail writes.
- *"System Prompt Leakage"* in `__init__.py:190` — the literal line `return prompt`
  in a hook handler returning an unmodified prompt.
- *"Data Exfiltration / Env Variable Harvesting"* — `{**os.environ, "PORT": str(port)}`
  passing env to a benchmark test server subprocess.
- *"Tool Misuse"* — the string `DELETE /todos/:id` inside a **benchmark prompt**
  describing a Todo REST API exercise.
- *"Anti-Refusal"* — the phrase *"without judgment"* in a results file whose
  sentence argues **for** keeping guards: *"'Write less' without judgment cuts
  the guard; ponytail's rule, never simplify away input validation at trust
  boundaries, keeps it."*

**Graphify** — 4 HIGH in the payload, all reviewed:
- 3× *"Tool Misuse"* on `rm -f` — every one scoped strictly to Graphify's **own**
  `graphify-out/.graphify_*` cache files. No wildcards outside its output
  directory, no user paths.
- 1× *"Anti-Refusal"* matched `without warning` inside the line
  *"Never run HTML viz on a graph with more than 5,000 nodes without warning the
  user"* — a safety instruction whose meaning the scanner inverted.

## Phase 3 — Claude development tools, real functional results

### Graphify → ACTIVE

`pip install graphifyy` (0.9.61) in an isolated venv, then a real deterministic
code-only index of **this repository**:

- **3841 nodes, 9160 edges, 345 code files** AST-extracted.
- **Dependency query** — "How is the BUY/SELL/WAIT decision made?" correctly
  surfaced `trading_ai/economic_labels.py:166` (*"Choose BUY/SELL/WAIT after
  comparing both actions with invariant WAIT=0"*) — the actual decision core.
- **Impact query** — `graphify affected "validate_candles()"` correctly returned
  its 12 dependent modules including `load_m1_candles()`,
  `aggregate_closed_candles()`, `compute_indicator_universe_at()`.
- **god-nodes** — `Candle` (161 edges) as the top architectural hub.

`graphify-out/` is git-ignored: it is a 4.2 MB derived artifact, rebuilt with
`graphify update .`

### Ponytail → READY (one user action from ACTIVE)

Security-clean on the payload. The remaining question was whether its
"write less" discipline is **dangerous** for a trading-safety project. Tested
against a real trap in this repo:

`trading_ai/kaufman.py::_validated_closes()` validates all four OHLC values but
returns only `close` — exactly the "redundancy" a naive minimizer would strip.
Stripping it would be a real regression: `validate_candles()` checks only OHLC
*relationships*, and **NaN comparisons are always `False` in Python**, so a NaN
`high` passes `validate_candles()` silently. The four-value `isfinite`/type loop
in `_validated_closes` is the **only** NaN guard on that path.

Ponytail's `SKILL.md` carries an explicit rule that forbids exactly this cut:

> *"Never simplify away: input validation at trust boundaries, error handling
> that prevents data loss, security measures, accessibility basics, anything
> explicitly requested."*

plus *"The ladder shortens the solution, never the reading... Laziness that skips
comprehension to ship a small diff is the dangerous kind."*

**Verdict: PASS** — it protects the guard rather than removing it.

**Not marked ACTIVE** because the Claude Code plugin is not loaded: `ListPlugins`
returns empty, and `/plugin marketplace add DietrichGebert/ponytail` +
`/plugin install ponytail@ponytail` are user-run slash commands that no
session-level tool can invoke. That single user action is all that remains.

### Andrej Karpathy Skills → WATCH (deliberately not installed)

Security-clean (`SAFE`, score 0). Its four principles are already covered by
`AGENTS.md` and Ponytail. Installing it would add a **third overlapping rule
source with no new capability**, which the no-duplicates rule forbids. Adopt
only on explicit request.

### Headroom → ISOLATED_TEST, conditional adopt

The PyPI package `headroom` is an **unrelated squat**; the real one is
`headroom-ai` (0.37.0). Real benchmark, using headroom's own token accounting
(tiktoken's BPE download is proxy-blocked) plus an independent numeric-fidelity
check:

| Content | Before → After | Reduction | Numbers lost |
|---|---|---|---|
| Identifier-heavy tool output (`graphify manifest.json`) | 20,818 → 768 | **96.3%** | 1,465 of 1,583 |
| Large structured numeric backtest evidence (1,200 rows) | 32,904 → 11,318 | **65.6%** | **0 of 5,961** |
| `user`-role message | unchanged | 0% | 0 |

It **routes by content type**: structured numeric data went to `router:mixed:0.34`
(lossless for every numeric value), identifier-heavy prose to
`router:smart_crusher:0.04`. It refuses to compress `user` messages by design.

**Conditional adopt** for bulk tool output. Per project rule it must **not** sit
in front of raw backtest evidence, security findings or immutable audit logs
without a per-artifact lossless check first.

### OmniRoute → NEEDS_CONFIG (this *downgrades* a previous claim)

Installed for real (npm `omniroute@3.8.50`, MIT, 1164 packages, ~2.4 GB).

- `doctor` — 5 ok, 44 warnings (all "other CLI not installed"), **0 failures**.
- `serve` — starts in 5.5s; `health` reports **`healthy`**, version 3.8.50.
- `compression status` — **HTTP 503, "MCP server is disabled."**
- `compression preview` — returned empty.
- `/v1/models` — `{"error":"Authentication required"}`; `keys list` — *"No keys configured."*
- **No real completion was obtained.**

So the 2026-09-10 result *"compression=PASS stacked=true"* is **not reproducible
in a fresh default install** and must stop being quoted as verified. Free-tier
routing remains unproven, exactly as before. No provider credentials were added,
per policy.

**New security finding:** `omniroute serve` binds **`0.0.0.0` with no API-key
requirement on the inference plane** by default — the tool itself warns that any
device that can route to the host can spend your provider credits. It must never
run with real provider keys on a non-loopback interface.

## Phase 4 — reproducible research environment

Optuna, ruptures and purgedcv were moved out of the throwaway `/tmp` venv into
`tools/research_env/`:

- `requirements.txt` — fully pinned (`optuna==5.0.0`, `ruptures==1.1.10`,
  `purgedcv==0.1.6`, plus the exact resolved scientific stack).
- `verify_research_env.py` — committed known-answer tests; **exits non-zero on
  failure** so it can gate CI. Import success alone is not treated as a pass.

Re-verified from a **clean venv built only from the committed
`requirements.txt`**, exit 0:

| Library | Test | Result |
|---|---|---|
| Optuna 5.0.0 | TPE minimize `(x-2)^2`, seed 42, 50 trials | PASS — `best_x=2.0047707` |
| ruptures 1.1.10 | PELT on synthetic 4-segment signal | PASS — recovered `[100,200,300,400]` exactly |
| purgedcv 0.1.6 | `PurgedKFold(purge_horizon=3h, embargo_fraction=0.01)`, 500 rows | PASS — **0 leakage violations**, 5 folds |

**API change worth recording:** purgedcv's constructor now requires
`prediction_times` / `evaluation_times` / `purge_horizon` / `embargo_fraction`.
The older `purge=` / `embargo=` kwargs raise `TypeError`.

These stay **research-only** and must never be imported by production trading,
execution, risk or signal-emitting paths.

## Phase 5 — durable memory files created

`CONTEXT.md` and `PROJECT_STATE.md` did not exist on `main`, despite `AGENTS.md`
treating them as canonical. Both were ported from the toolbox branch and
**corrected to verified state** — notably the toolbox role map, which that branch
wrote optimistically (it assumed a working AI System Architect and verified
OmniRoute compression; neither holds).

**They exist only on the PR branch `claude/toolbox-master-completion-2026-09-15`
(PR #225), not on `main`.** Until that PR is merged, `AGENTS.md` on `main` still
points at two files that are not there. Closing that gap requires merging this
PR — it is not closed by this audit alone.

## Phase 6 — toolbox branch reconciliation (no merge)

`ai/integrate-agent-toolbox-2026-09-10` **must not be merged.** It was cut from a
much older `main`; merging would **delete** large amounts of current work —
`ai-council-claude-bridge.js` (541 lines), `ai-council-gateway.js`, many
`ai_global_trader/` modules, `VIRUS_AI_CONTINUOUS_LEARNING_AND_ABSORPTION.md`
(416 lines), and `AI_AGENT_TOOLBOX_STATUS.md` itself.

Ported **file by file** instead: `tools/ai_toolbox/manifest.json`,
`drive_candidates.json`, `RUNTIME_POLICY.md`, `TOOLBOX_TOPOLOGY.md`,
`ARCHITECT_ORDER.md`, and the `quant_toolbox` / `ml_challenger` / `news_toolbox`
manifests. The two documents carrying now-contradicted claims
(`TOOLBOX_TOPOLOGY.md`, `ARCHITECT_ORDER.md`) received correction headers rather
than being copied as-is.

`bootstrap.sh` was **reviewed but deliberately not executed**: no secrets, no
`curl | bash`, no sudo, and its single `rm -rf` is scoped to the clone target
directory before a fresh clone. Running the whole pipeline was unnecessary —
the tools that matter were tested individually and more rigorously.

## Phase 7 — QM

Railway read access **does** work (an earlier note said permissions blocked it).
Service `qm-agent-harness` in project `virus-ai-agent-toolbox-20260910` is
`state=live`, latest deployment `5d96988f` **SUCCESS** (2026-09-11).

**Safety boundary confirmed:** `variableNames: []` — the service has **zero**
environment variables, so no MT5, Telegram, broker or production-database
secrets were ever injected.

But the `QM_TOOLBOX_READY` marker does **not** appear in retained deploy logs
(only `Starting Container`), so QM's own runtime boot is still not observable,
and no bounded task has been run. Deployment SUCCESS is not proof QM booted.
Status stays **ISOLATED_TEST**, not ACTIVE.

## Phase 8 — Google Drive

The master inventory document **could not be edited in place**: the Drive
connector available here exposes `update_file` for **title and parent folder
only** — it cannot modify a Google Doc's body. This is a connector limitation,
not a permissions problem (the account is the document owner).

A companion document was therefore **created in the same Drive folder** and its
content was read back to confirm it landed:

> **VIRUS AI — TOOLBOX SYNC 2026-09-15 (verified statuses, apply to master inventory)**
> `1LSG3Fphtt3DLrbHEWBIUi6bg9ImbGxFq0GXRMj1Kt7k`

It carries every verified status change, the counter note (46 *project modules*
vs 72 *external tool candidates* — different countable things), the new
candidates, and the safety state. The master document still needs a manual merge
or a Docs-capable connector.

## Fynance — rejected rather than left pending

No repository matching the name and description could be found across two
independent search attempts. Its listed ideas are already covered: purgedcv
(adopted) ships `CombinatorialPurgedCV`, `deflated_sharpe_ratio`,
`probabilistic_sharpe_ratio` and `probability_of_backtest_overfitting`.
Recommendation: drop the name or supply an exact upstream URL.

## Heavy candidates deliberately not installed

33 candidates remain `NOT_INSTALLED` **by decision**. Each now carries an
explicit justification in the inventory: no demonstrated capability gap today,
plus heavy dependencies. Qlib, RD-Agent, FinRL, NautilusTrader, LEAN, Chronos,
TimesFM and similar are **not** installed for the sake of the count — they get
installed when a concrete gap is identified, not before.

## Final status distribution (all 72 classified)

| Status | Count |
|---|---|
| NOT_INSTALLED | 33 |
| ACTIVE | 8 |
| ISOLATED_TEST | 8 |
| WATCH | 6 |
| BLOCKED | 6 |
| NOT_USEFUL | 4 |
| REJECTED | 2 |
| READY | 1 |
| NEEDS_CONFIG | 1 |
| BROKEN | 1 |
| NOT_APPLICABLE | 1 |
| NEEDS_KEY | 1 |

Every status is from the approved legend.

**ACTIVE (8):** Graphify, Context7, Claude built-in code-review/security-review,
NVIDIA SkillSpector, Optuna, ruptures, purgedcv, stefan-jansen ML4T companion.
**READY (1):** Ponytail.

## Pass 3 results

### Fresh payload-only scans of the four remaining skill packs

All cloned at pinned commits and scanned with the same payload-only method.
**The verdicts split cleanly into one genuine block and three mis-flagged packs**
— which is exactly why per-finding review is mandatory rather than reading the
headline score.

| Pack | Commit | Score / verdict | Review outcome |
|---|---|---|---|
| Strix | `84f4108` | 77, HIGH, `DO_NOT_INSTALL` | **GENUINE — stays BLOCKED** |
| Matt Pocock Skills | `3cca18b` | 100, CRITICAL, `DO_NOT_INSTALL` | 7/9 false positives → REJECTED as duplicate |
| Anthropic Skills | `34040c9` | 100, CRITICAL, `DO_NOT_INSTALL` | mis-flagged on docs → REJECTED as duplicate |
| Google Skills | `5a14f11` | 100, CRITICAL — **scan incomplete** | 1 genuine CRITICAL; BLOCKED + not applicable |

**Strix — the one genuine finding, NOT overridden.** All 9 HIGHs are in the
installable payload (not benchmarks), and they are one real pattern repeated:
the skills instruct the agent to run `curl -sSL https://strix.ai/install | bash`
— in `AGENTS.md:30`, `skills/ci-security-scanning-with-strix/SKILL.md` (lines 44,
91, 128), `skills/managed-pentesting-with-strix/SKILL.md:16` and
`skills/penetration-testing-with-strix/SKILL.md:46`. That is third-party remote
code execution inside an agent-loaded skill, on a repo that also handles trading
credentials. Unblocking requires pinning a verified release artifact by digest
instead of `curl | bash`.

**Matt Pocock — the scanner was wrong, but the pack is still a duplicate.** 7 of
9 HIGHs are false positives, two of them with inverted meaning: `git reset --hard`
and `git push` are flagged as "Tool Misuse" while sitting inside a
`DANGEROUS_PATTERNS` array in a hook that **blocks** those very commands.
"Anti-Refusal" matched *"without warning"* (a beta README) and *"always answer"*
(prose about questionnaires). The 2 real-but-declared capabilities are the
git-guardrails skill writing to `~/.claude/settings.json` (it asks for scope
first) and a scaffolding wizard reading `.env` defaults. **This corrects the
earlier "BLOCKED by scanner" framing.** The actual reason not to install is that
its Wayfinder/handoff concepts are now implemented natively in `CONTEXT.md` and
`PROJECT_STATE.md` in this very PR.

**Anthropic Skills — mis-flagged on its own documentation.** Two findings prove
it outright: all 9 *"Prompt Injection / Hidden Instructions"* HIGHs match nothing
but the **UTF-8 BOM (`﻿`)** at the start of standard ECMA OOXML `.xsd`
schema files shipped with the docx/pptx skills, and the single *"YARA Match"*
(an MCP tool-poisoning rule) fires on a model-migration document that merely
contains `tools=` and `"description":`. 22 of 47 HIGHs sit in
`skills/claude-api` — Claude API *documentation*, which naturally contains
"access token", curl examples and CLI samples, including one flagged line whose
own text says the token is *"Never echoed"*. One genuine pattern worth noting:
`anthropic-cli.md` documents a `curl ... | sudo` install for Anthropic's own
pinned CLI release. **Decisive reason not to install:** `ListSkills` confirms
`docx`, `pptx`, `xlsx`, `pdf` and `skill-creator` are **already enabled in this
session** — cloning the repo would re-add identical skills a second time.

**Google Skills — the scan did not complete, and that itself is the finding.**
819 issues (1 CRITICAL, 159 HIGH, 630 MEDIUM) across 781 components, but
`coverage_percent = 0.0`, `is_complete = false`, `fully_inspected_files = 0`,
`partially_inspected_files = 781`, with 8 ledger exceptions of reason code
`obfuscated_instruction_text`. **This is neither a clean bill of health nor a
definitive block — it is an incomplete scan, and must not be reported as
either.**

The single CRITICAL is specific and genuine, not a text match:
`skills/cloud/iam-helper-for-troubleshooting/scripts/troubleshooting_error_id.py:149`
shows a tainted data flow — `req`, derived from `os.environ.get`
(credential/environment), reaching `urllib.request.urlopen` (network output) at
confidence 0.9. Plausibly legitimate for a GCP IAM helper calling a Google API,
but it is a real credential→network flow in executable code. By contrast, the 91
"Privilege Escalation" HIGHs sample as documentation — `secrets.json` inside
OAuth client-setup instructions.

Blocked on two independent grounds, and **the second is the stronger one**: this
project has **no Google Cloud footprint at all** — it runs on Railway with
PostgreSQL. The HIGH findings concentrate in `skills/cloud/*` (GCS bucket
architecture, GKE, IAM, Genkit), `skills/ads/*` and `plugins/cloud/*`, none of
which the project can use. If the originally-wanted architecture / reliability /
performance / cost skills are still desired, cherry-pick those directories and
scan each **alone** — a small target completes fully, as it did for Ponytail,
Graphify, Karpathy and Headroom.

### Parity test 1 — purgedcv vs the native validation stack

`tools/research_env/parity_purgedcv_vs_native.py` (committed, exit 0) imports the
**actual** `trading_ai.pipeline.chronological_split` and reproduces the
`walk_forward` boundary rule, then counts leakage in **both** directions with one
shared validator-agnostic rule — forward (what a purge prevents) and backward
(what an embargo prevents).

| Validator | Folds | Violations |
|---|---|---|
| native `chronological_split` | 1 split | **0** |
| native expanding-window walk-forward | 5 | **0** |
| purgedcv `PurgedKFold` | 5 (4 with train *after* test) | **0** |
| native purge-only rule transplanted into k-fold | 5 | **60, all backward** |

**Verdict: purgedcv is a DUPLICATE for the project's current design.** The
expanding-window layout keeps train strictly before test, so a left-side purge is
structurally sufficient. purgedcv becomes **required** the moment train samples
exist after a test fold (k-fold / CPCV), where the current purge-only rule leaked
60 backward violations. It is therefore **downgraded ACTIVE → READY**: pinned and
verified, ready for the day that design change happens, but not wired in before
then. Its deflated/probabilistic Sharpe and PBO helpers remain independently
useful.

### Parity test 2 — orderflow-metrics vs the canonical OFI formula

**There is deliberately no native OFI to compare against.**
`trading_ai/sampled_quotes.py` documents *"no aggressor inference, OFI/CVD, or
L2"*, and `test_names_do_not_claim_order_flow_or_realized_volatility` actively
asserts no feature name may contain `ofi`/`cvd`/`footprint`/`aggressor`/
`order_flow`. That is the correct call: the project has sampled L1 quotes, not
true L2 or trade data. So parity was run against the **canonical Cont-Kukanov-
Stoikov formula, hand-implemented** in
`tools/research_env/parity_orderflow_metrics.py` (committed, exit 0):

- 8 hand-checked book-event fixtures (bid up/down, ask up/down, resize at
  unchanged prices, spread widen/narrow, zero sizes) — **all match**
- 5,000 randomized differential trials — **0 OFI mismatches**
- 5,000 randomized `depth_imbalance` trials — **0 mismatches**
- cumulative `ofi()` over a 59-step sequence — **exact match** (−60.0 vs −60.0)
- `ofi_series` length is n−1 as documented

**Verdict: formula PASS, status stays WATCH.** Correct arithmetic is not a
trading edge, and real OFI needs L1/L2 depth we do not have for XAUUSD. Adopting
it must **not** be read as permission to relabel sampled-L1 features as order
flow — the existing naming test forbids exactly that and should stay. Revisit at
the Binance stage. Packaging note: installed as `orderflow-metrics==0.29.0` but
the module reports `__version__ = 0.15.0`.

### Ponytail — plugin path definitively unavailable

Confirmed with two independent tools: `ListPlugins` returns empty **and**
`SearchPlugins` finds nothing for ponytail (it is a third-party GitHub
marketplace plugin, not in the org catalog). There is no native `/plugin` flow
reachable from this session, so Ponytail **stays READY by evidence, not by
omission**. Exact user steps to activate, run inside Claude Code:

1. `/plugin marketplace add DietrichGebert/ponytail`
2. `/plugin install ponytail@ponytail`
3. verify with `/plugin` that `ponytail` is listed

Optional intensity `/ponytail lite|full|ultra` (default `full`); disable with
"stop ponytail". Only after step 3 may its status become ACTIVE.

### OmniRoute — explicitly not a completion blocker

Per instruction, OmniRoute is **not** treated as a blocker for toolbox
completion. It stays `NEEDS_CONFIG`: install/doctor/serve/health pass, but
compression is unverified in a fresh default install and no completion was
obtained safely. It is a nice-to-have routing/compression layer, not a dependency
of any other tool, and nothing else in the toolbox waits on it.

### Final diff / security review of PR #225

- **The diff is 100% additive: 4,412 insertions, 0 deletions, 18 files.** No
  production trading, execution, risk, Telegram or database code is modified.
- The **only** executable content added is three scripts under
  `tools/research_env/`. Reviewed line by line: **no** `subprocess`, `os.system`,
  `eval`, `exec`, `__import__`, `pickle`, network calls, file writes, or
  credential access in any of them. They read synthetic data, call pure
  functions, print JSON and set an exit code.
- `parity_purgedcv_vs_native.py` does `sys.path.insert(0, ".")` to import the
  real `trading_ai.pipeline` — read-only use of one pure function
  (`chronological_split`) on synthetic samples; it never touches project data.
- Secret scan across the staged diff for `sk-ant-*`, `ghp_*`, private keys,
  `postgres://user:pass@`, AWS keys and Telegram bot tokens: **no matches.** The
  only credential-shaped strings are quoted findings inside the audit prose (e.g.
  describing Ponytail's `.env.example` placeholder).
- All three committed scripts re-run green (exit 0) after every edit.
- `graphify-out/` is git-ignored, so the 4.2 MB derived graph is not committed.

## REAL trading

Untouched. No MT5, Telegram, broker, Railway production or PostgreSQL
credentials were read, requested or given to any tool. Every functional test ran
in a throwaway venv or an isolated container with no project dependencies and no
secrets. No trading logic was modified.
