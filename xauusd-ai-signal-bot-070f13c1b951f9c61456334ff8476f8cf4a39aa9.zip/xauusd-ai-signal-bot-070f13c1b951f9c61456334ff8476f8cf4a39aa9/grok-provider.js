"use strict";

/**
 * Grok/xAI advisor adapter for the XAU/USD AI Council.
 * Advisory only: this module has no trading or production-write capabilities.
 */

async function postJson(url, headers, body, timeoutMs = 240_000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json", ...headers },
      body: JSON.stringify(body),
      signal: controller.signal,
    });

    const raw = await response.text();
    let data;
    try {
      data = JSON.parse(raw);
    } catch {
      data = { raw };
    }

    if (!response.ok) {
      throw new Error(
        `xAI API ${response.status}: ${String(
          data?.error?.message || raw || "Unknown xAI API error"
        ).slice(0, 1000)}`
      );
    }

    return data;
  } finally {
    clearTimeout(timer);
  }
}

function getXaiConfig() {
  const key = String(process.env.XAI_API_KEY || "").trim();
  if (!key) throw new Error("XAI_API_KEY is not configured");

  return {
    key,
    model: String(process.env.XAI_MODEL || "grok-4.5").trim(),
    reasoningEffort: String(
      process.env.XAI_REASONING_EFFORT || "medium"
    ).trim(),
    maxTokens: Math.max(
      500,
      Number(process.env.XAI_MAX_OUTPUT_TOKENS || 6000)
    ),
    timeoutMs: Math.max(
      20_000,
      Number(process.env.XAI_TIMEOUT_MS || 240_000)
    ),
  };
}

async function callGrok(prompt) {
  const { key, model, reasoningEffort, maxTokens, timeoutMs } = getXaiConfig();

  const data = await postJson(
    "https://api.x.ai/v1/chat/completions",
    {
      authorization: `Bearer ${key}`,
      "x-grok-conv-id": "xauusd-ai-council",
    },
    {
      model,
      messages: [{ role: "user", content: String(prompt || "") }],
      reasoning_effort: reasoningEffort,
      max_completion_tokens: maxTokens,
    },
    timeoutMs
  );

  return String(data?.choices?.[0]?.message?.content || "").trim();
}

function extractResponsesText(data) {
  if (typeof data?.output_text === "string" && data.output_text.trim()) {
    return data.output_text.trim();
  }

  const chunks = [];
  for (const item of Array.isArray(data?.output) ? data.output : []) {
    for (const part of Array.isArray(item?.content) ? item.content : []) {
      if (typeof part?.text === "string" && part.text.trim()) {
        chunks.push(part.text.trim());
      }
    }
  }
  return chunks.join("\n").trim();
}

function extractResponseSources(data) {
  const urls = new Set();
  const sources = [];

  function addSource(url, title = "") {
    const clean = String(url || "").trim();
    if (!clean || urls.has(clean)) return;
    urls.add(clean);
    sources.push({ url: clean, title: String(title || "").trim() });
  }

  for (const citation of Array.isArray(data?.citations) ? data.citations : []) {
    if (typeof citation === "string") addSource(citation);
    else addSource(citation?.url || citation?.uri, citation?.title);
  }

  for (const item of Array.isArray(data?.output) ? data.output : []) {
    const actionSources = item?.action?.sources;
    if (Array.isArray(actionSources)) {
      for (const source of actionSources) {
        addSource(source?.url || source?.uri, source?.title);
      }
    }

    for (const part of Array.isArray(item?.content) ? item.content : []) {
      for (const annotation of Array.isArray(part?.annotations)
        ? part.annotations
        : []) {
        addSource(
          annotation?.url || annotation?.url_citation?.url,
          annotation?.title || annotation?.url_citation?.title
        );
      }
    }
  }

  return sources;
}

async function callGrokResearch(prompt) {
  const { key, model, maxTokens, timeoutMs } = getXaiConfig();

  const data = await postJson(
    "https://api.x.ai/v1/responses",
    { authorization: `Bearer ${key}` },
    {
      model,
      input: [{ role: "user", content: String(prompt || "") }],
      tools: [{ type: "web_search" }],
      include: ["web_search_call.action.sources"],
      max_output_tokens: maxTokens,
    },
    timeoutMs
  );

  return {
    text: extractResponsesText(data),
    sources: extractResponseSources(data),
    model,
    grounded: true,
  };
}

module.exports = {
  callGrok,
  callGrokResearch,
  extractResponsesText,
  extractResponseSources,
};
