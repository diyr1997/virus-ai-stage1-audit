# AUDIT-001 — Inventory of task execution, verification, Council, bridge and repo-audit

**Status:** EXECUTED, awaiting independent verification. Not COMPLETE.
**Date:** 2026-09-21
**Scope:** DEVELOPMENT PROTOCOL V2 §26. Read-only. No code changed, nothing installed, nothing deleted.
**Branch:** `claude/ollama-local-advisor-r9jvfu` @ `b33ef6e`

Every claim below carries the command or file that produced it. Anything I could not
establish is marked UNVERIFIED rather than assumed.

---

## Headline: the protocol's core failure is present and countable today

```
git ls-tree -r origin/ai-council-queue --name-only | grep -c '^\.ai-council-queue/claude-tasks/'    ->  65
git ls-tree -r origin/ai-council-queue --name-only | grep -c '^\.ai-council-queue/claude-results/'  ->  28
```

**65 Claude tasks queued, 28 answered. 37 have no result file at all.**

This is not a hypothetical. It is the exact condition §5 forbids being reported as
"all tasks complete", and it exists in the repository right now. The general queue
`.ai-council-queue/tasks/` holds a further **341** files; how many of those are
answered is UNVERIFIED (their result convention differs and I did not enumerate it).

---

## 1. What already exists

| # | Mechanism | File / location | Maps to protocol |
|---|---|---|---|
| 1 | Council task queue, two phases + synthesis | `ai-council-persistent.js`, tables `ai_council_tasks`, `ai_council_runs` | §1, §14, §15 |
| 2 | Intake state machine with explicit transition table | `council-first-intake.js` | §1, §2, §4 |
| 3 | Approval gate `MERGE_DECISION: APPROVE\|BLOCK` | `council-first-intake.js:182-191` | §4 |
| 4 | Roadmap task registry, persisted outside any AI's memory | `.ai-council-queue/autonomy/roadmap-state-v3.json` | §6 |
| 5 | Executor + independent result verification | `autonomy/claude-executor.js`, `roadmap-coordinator.js` | §4 |
| 6 | Repository-wide scan seeded as Council tasks | `ai-council-repo-audit.js` | §7 partial |
| 7 | GitHub file bridge to a Claude worker | `ai-council-claude-bridge.js`, table `ai_council_claude_bridge` | §23 |
| 8 | Harness-enforced permission allow/deny list | `.claude/settings.json` on branch `ai-council-queue` | §24 |
| 9 | Lease + stale reaping on training runs | `training-current-data-lab-v2.js`, table `training_current_data_runs` | §6 |
| 10 | Atomic champion swap with evidence | `model_registry`, `weekend-upgrade.js` | §3 |

---

## 2. Where it is

Verified by `grep -rln "require.*<module>"` excluding `node_modules` and `tests/`:

```
ai-council-persistent     <- virus-ai-chat-bootstrap.js, roadmap-coordinator.js,
                             ai-council-dynamic.js, council-first-intake.js,
                             ai-council-gateway.js, ai-council-repo-audit.js,
                             ai-council-catchup-bootstrap.js
ai-council-claude-bridge  <- autonomy/claude-executor.js, ai-council-dynamic.js,
                             ai-council-persistent.js
ai-council-repo-audit     <- ai-council-catchup-bootstrap.js
claude-executor           <- autonomy/roadmap-coordinator.js
council-first-intake      <- (nothing)
```

The production start command, from `package.json`:

```
today-signal-audit · telegram-autosignal-dedup · news-xau · graph-v6 ·
signal-ui-compact · trading-school · deepseek-first-review ·
telegram-public-access · telegram-public-signal-cache · direction-status ·
virus-ai-chat  ->  index.js
```

`grep -n 'require("./ai-council|require("./autonomy|require("./council' index.js`
returns **nothing**. So `index.js` itself loads none of them.

---

## 3. What actually runs

**LIVE in production.** `ai-council-persistent.js`, reached through
`virus-ai-chat-bootstrap.js`, which is in the start command. Confirmed by the
deploy log at 2026-09-21T09:14:32Z:

```
🧠 VIRUS AI CHAT: enabled | mode=council | provider=coordinator | owner_only=true
```

**LIVE.** `training_current_data_runs` lease and reaper — log every minute:

```
🧪 CURRENT DATA LAB V2: Reaped 0 stale RUNNING rows
```

**LIVE.** `model_registry` active-model resolution:

```
🧠 MODEL REGISTRY: active H1 school-v1-h1-daily-t00-20260917T210606Z
```

**ENFORCED, but only on one branch.** `.claude/settings.json` exists on
`origin/ai-council-queue` and **not on `main`** (`git ls-tree -r origin/ai-council-queue
--name-only | grep '^\.claude/'` returns it; the working tree on my branch has
`find .claude -type f | wc -l` = **0**). Its deny list is real and specific:

```
deny: Write(.ai-council-queue/claude-tasks/**), git checkout main,
      git push * main*, git push --force*, git reset --hard*,
      git clean*, rm *, curl *, wget *, mt5*
allow: Read, Glob, Grep, Write(.ai-council-queue/claude-results/**),
       git status/diff/log/rev-parse/branch, fetch+checkout+push on ai-council-queue only
```

---

## 4. What exists only nominally

**`council-first-intake.js` — the best-designed component in the project, and nothing loads it.**
It defines 9 states and an explicit `ALLOWED_TRANSITIONS` table:

```
RECEIVED · COUNCIL_PENDING · PROVISIONAL_REVIEW · REVIEWED ·
AUTHORIZED_FOR_DRAFT · DRAFT_REVIEW_PENDING · AUTHORIZED_FOR_MERGE ·
BLOCKED · FAILED
```

plus `council_intake_requests` with a `CHECK (status IN (...))` constraint and a
separate `council_intake_audit` table. The grep for requires returns nothing. It is
also absent from the start command. Its env var `COUNCIL_FIRST_AUTH_SECRET` does not
appear in the Railway variable listing for the bot service.

**`ai-council-repo-audit.js` — a one-shot audit, not the cyclic Guardian of §8.**

```
ai-council-repo-audit.js:13  const RUN_PREFIX = "REPO_AUDIT_FULL_2026_08_20_R1";
```

The prefix is hard-coded and dated, `R1` meaning round one. Re-running requires
editing the constant. It keeps no per-file state, no cycle counter and no findings
store. It is loaded only by `ai-council-catchup-bootstrap.js`, which is not in the
start command.

**`autonomy/roadmap-coordinator.js` + `claude-executor.js` — the verification layer §4 asks for, not running.**
It already contains the right idea, at `roadmap-coordinator.js:151`:

> *"Review the VERIFIED GitHub diff and executor test evidence in the frozen context.
> Do not trust the executor summary when it conflicts with the actual diff."*

and carries `verifyExecutorResult`, `mergeVerifiedBranch`, and evidence fields
`base_sha` / `head_sha` / `branch`. Nothing in the runtime loads it. The only place it
is exercised is `.github/workflows/autonomy-coordinator-tests.yml`.

**`railpack.json` runs `node --check` on all of these at build time.** That is a syntax
check, not execution. Passing it proves the files parse, nothing more.

**Routines: two of three disabled, the third unscheduled.**

| Routine | Enabled | Schedule | Last run |
|---|---|---|---|
| AI Council queue watcher | **false** | `19 * * * *` | — |
| VIRUS AI Council — Claude | true | **none (fire-only)** | 2026-09-13T11:01, SUCCEEDED |
| AI Council Claude Bridge Worker | **false** | `32 * * * *` | 2026-09-12T21:32, SUCCEEDED |

Nothing has driven the queue for **8 days**, which is consistent with the 37
unanswered tasks. The phrase `NO_PENDING_TASKS` in §5 of the protocol appears verbatim
inside the "VIRUS AI Council — Claude" routine prompt, so the protocol is describing a
contract this system already states and does not currently keep.

---

## 5. What is missing

| Protocol requirement | Status | Evidence |
|---|---|---|
| `UNVERIFIED` state | **absent everywhere** | `grep -rhoE "'UNVERIFIED'" --include=*.js` → 0 hits |
| Findings store | **absent** | grep for `CREATE TABLE`/`INSERT INTO` + `findings` → 0 hits |
| Per-file Guardian state (path, last checked commit, timestamp, finding status) | **absent** | no table, no file |
| Cycle counter (`CYCLE-001 COMPLETE`) | **absent** | `RUN_PREFIX` is a fixed string |
| Coverage report (§21) | **absent** | no producer of FILES CHECKED / UNCHECKED |
| Cross-check of code against a COMPLETE task (§10) | **absent** | no mechanism reads task status and re-tests the claim |
| Terminal `COMPLETE` after merge | **absent** | intake's highest state is `AUTHORIZED_FOR_MERGE`; nothing records the merge landed and held |
| Budget / hard spend limit (§19) | **absent** | no cost estimator, no limiter |
| `EXECUTED` / `VERIFYING` / `CLAIMED` states | mostly absent | `CLAIMED` appears once; `EXECUTED`, `VERIFYING` zero |

---

## 6. What is duplicated

**Four different task-state vocabularies**, none matching the protocol's:

```
intake      RECEIVED · COUNCIL_PENDING · PROVISIONAL_REVIEW · REVIEWED ·
            AUTHORIZED_FOR_DRAFT · DRAFT_REVIEW_PENDING · AUTHORIZED_FOR_MERGE ·
            BLOCKED · FAILED
roadmap     WAITING · IN_PROGRESS · REVIEW · DONE · BLOCKED
council run PENDING · SUCCESS · FAILED  (+ task: WAITING_ADVISORS · COMPLETE)
training    PENDING · RUNNING · SUCCESS · FAILED · STALE
```

Raw counts across all JS, `node_modules` excluded:
`PENDING` 27, `SUCCESS` 12, `RUNNING` 12, `FAILED` 10, `COMPLETED` 6, `COMPLETE` 4,
`STALE` 3, `SKIPPED` 2, `CLAIMED` 1, `BLOCKED` 1.

**Two roadmap state files** on the queue branch: `roadmap-state.json` and
`roadmap-state-v3.json`. Which is authoritative is UNVERIFIED; the coordinator's
`AUTONOMY_STATE_PATH` defaults to the **unversioned** `roadmap-state.json`, while the
richer v3 file is the one holding 33 items.

**Two training labs**: `training-current-data-lab.js` and `training-current-data-lab-v2.js`,
both defining `model_registry` and both able to promote.

---

## 7. What conflicts

1. **Restrictions live on one branch only.** `.claude/settings.json` is on
   `ai-council-queue`. Work done on `main` or on a `claude/*` branch runs without it.
2. **Roadmap registry says 0.6 is IN_PROGRESS since before 2026-09-19**, yet nothing
   is running to advance it. Statuses: `DONE` 5, `IN_PROGRESS` 1, `WAITING` 27 of 33.
   An `IN_PROGRESS` item with no running executor is precisely the stale state §6 says
   must fall back to PENDING/UNVERIFIED.
3. **The protocol's vocabulary matches none of the four in use**, so adopting it
   verbatim would create a fifth.

---

## 8. What can be reused

Ranked by how much of the protocol each already satisfies:

1. **`council-first-intake.js`** — §1, §2 and §4 are largely built here. It needs a
   loader and a terminal `COMPLETE`, not a rewrite.
2. **`ai-council-persistent.js`** — §14 and §15 (independent → peer review →
   synthesis, with a revision counter) are already correct and already live.
3. **`autonomy/roadmap-coordinator.js`** — §4's "verify against the diff, not the
   summary" is written and tested; it needs to be run.
4. **`.claude/settings.json`** — §24's guardrails exist; they need to apply on every
   branch, not one.
5. **`training-data-policy.js`** — the fail-closed gate pattern (`promotionDecision`)
   is a working model for how a verifier should refuse on missing evidence.
6. **`ai-council-repo-audit.js`** — its file-splitting and bundling is reusable as the
   scanning half of a Guardian; the state half does not exist.

---

## 9. What must be created

Only what nothing above covers:

1. A **findings store** with the fields §8 lists, and a `related_task` link for §10.
2. A **per-file cursor** so a Guardian can resume a cycle instead of restarting.
3. A **task ↔ code cross-check** that re-tests a COMPLETE claim and can reopen it.
4. A **coverage report** producer (§21).
5. An **`UNVERIFIED` state** and the rule that it never auto-promotes.
6. A **terminal `COMPLETE`** recorded only after independent verification.
7. A **budget controller** with a hard stop (§19).

---

## 10. Evidence index

| Claim | How to reproduce |
|---|---|
| 65 tasks / 28 results | `git ls-tree -r origin/ai-council-queue --name-only \| grep -c '^\.ai-council-queue/claude-tasks/'` and the same for `claude-results/` |
| 341 general tasks | same, `^\.ai-council-queue/tasks/` |
| `.claude` absent on working branch | `find .claude -type f \| wc -l` → 0 |
| `.claude/settings.json` present on queue branch | `git show origin/ai-council-queue:.claude/settings.json` |
| intake is an orphan | `grep -rn "council-first-intake" --include=*.js . \| grep -v node_modules \| grep -v tests/` → empty |
| intake states | `sed -n '16,62p' council-first-intake.js` |
| repo audit is one-shot | `sed -n '13p' ai-council-repo-audit.js` |
| coordinator not in runtime | `grep -n 'require("./autonomy' index.js` → empty; `package.json:scripts.start` |
| railpack only syntax-checks | `railpack.json`, `node --check ...` |
| routine states | `list_triggers` (Claude Code Remote) |
| roadmap statuses | `git show origin/ai-council-queue:.ai-council-queue/autonomy/roadmap-state-v3.json` |
| no findings table | `grep -rn "findings" --include=*.js . \| grep -i "create table\|insert into"` → empty |
| no UNVERIFIED | `grep -rhoE "'UNVERIFIED'" --include=*.js .` → empty |
| live services | Railway deploy logs, service `f8710e22-3082-4839-8ec3-d25f260d1c9b` |

---

## Blocker carried forward, not lost

The previous task — loading the 6,099,893-row canonical M1 bundle — is **BLOCKED**,
not complete. The archive on Google Drive is not shared with "Anyone with the link"
(`get_file_permissions` on `1KNxCqerh0U_ZFCDpKRmAG_SF4yndvCkU` returns the owner only),
this sandbox has no route to `drive.google.com`, and the Drive tool available to me can
only grant access to a named email address, so I cannot open it myself. Recorded here
so it is not silently dropped while this audit proceeds.

---

## Stopping here

Per §26: AUDIT-001 is EXECUTED with evidence. It is **not** COMPLETE until independently
verified. I am not starting AUDIT-002 and I am not implementing anything from the
protocol until this report is checked.
