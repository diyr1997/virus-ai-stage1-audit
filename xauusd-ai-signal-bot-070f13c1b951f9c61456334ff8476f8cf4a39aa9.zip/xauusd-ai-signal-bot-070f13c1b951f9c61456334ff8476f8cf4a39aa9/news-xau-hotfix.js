"use strict";

// XAU/USD NEWS RELEVANCE HOTFIX V15
// Loaded before index.js from package.json.
// It wraps ./news.js without touching MT5/DEMO trading code.

const Module = require("module");
const path = require("path");

const originalLoad = Module._load;
const PATCHED = Symbol.for("xauusd.news.relevance.v15");
let announced = false;

function clamp100(value) {
  return Math.max(0, Math.min(100, Math.round(Number(value) || 0)));
}

function textOf(item) {
  return `${item?.originalTitle || item?.title || ""} ${item?.description || ""}`
    .replace(/\s+/g, " ")
    .trim();
}

function hasXauBridge(text) {
  return /\bgold\b|bullion|xauusd|treasury yields?|bond yields?|\bdxy\b|u\.s\. dollar|us dollar|greenback|federal reserve|\bfomc\b|inflation|\bcpi\b|\bpce\b|nonfarm|payrolls|risk[- ]off|safe haven|geopolit|war|missile|airstrike|sanctions|hormuz|red sea|banking crisis|financial crisis/i.test(text);
}

function isChartOrToolPage(text) {
  return /(?:gold|xauusd|gold futures).{0,35}(?:live |interactive )?chart\b|\b(?:live |interactive )?chart.{0,35}(?:gold|xauusd|gold futures)/i.test(text);
}

function isCbdcNoise(text) {
  return /digital yuan|electronic yuan|e[- ]?yuan|e[- ]?cny|\bcbdc\b|central bank digital currency/i.test(text) &&
    !/\bgold\b|bullion|xauusd|gold reserves?|treasury yields?|\bdxy\b|federal reserve|\bfomc\b|risk[- ]off|banking crisis|financial crisis/i.test(text);
}

function isPureFxForecast(text) {
  const fxPair = /\b(?:gbp|eur|jpy|aud|nzd|cad|chf)\s*\/\s*(?:usd|eur|jpy|gbp)|\busd\s*\/\s*(?:jpy|chf|cad)\b/i.test(text);
  const forecast = /forecast|outlook|expected|expects|seen above|seen below|target|resistance|support|further gains?|further rise|further fall|price prediction/i.test(text);
  return fxPair && forecast && !hasXauBridge(text.replace(/\busd\b/gi, ""));
}

function isWeakRegionalBackground(item, text) {
  const region = String(item?.region || "").toUpperCase();
  const weakRegion = ["UK", "EUROPE", "JAPAN", "CHINA"].includes(region);
  if (!weakRegion) return false;
  if (String(item?.eventKind || "").toUpperCase() !== "BACKGROUND") return false;

  return !/\bgold\b|bullion|xauusd|treasury yields?|bond yields?|\bdxy\b|u\.s\. dollar|us dollar|greenback|federal reserve|\bfomc\b|risk[- ]off|safe haven|geopolit|war|missile|sanctions|banking crisis|financial crisis|gold reserves?/i.test(text);
}

function isEscalation(text) {
  const conflict = /iran|israel|gaza|yemen|red sea|hormuz|uae|saudi|qatar|war|military|missile|airstrike|attack|invasion/i.test(text);
  const escalation = /missile|airstrike|attack|invasion|escalat|intensif|retaliat|sanctions?|suspend(?:s|ed|ing)? trade|halts? trade|blocks? trade|closes? strait|shipping disruption/i.test(text);
  const deescalation = /ceasefire|truce|peace deal|de[- ]?escalat|talks resume|agreement reached/i.test(text);
  return conflict && escalation && !deescalation;
}

function isDeescalation(text) {
  return /ceasefire|truce|peace deal|de[- ]?escalat|agreement reached/i.test(text);
}

function goldMacroReaction(text) {
  const gold = /\bgold\b|bullion|xauusd/i.test(text);
  if (!gold) return null;

  const bullish =
    /dollar.{0,40}(?:fall|drop|weaken|slip|declin|lower)|(?:weaker|soft(?:er)?) dollar|yields?.{0,40}(?:fall|drop|ease|slip|declin|lower)/i.test(text);
  const bearish =
    /dollar.{0,40}(?:rise|jump|strengthen|climb|surge|higher)|(?:stronger|firm(?:er)?) dollar|yields?.{0,40}(?:rise|jump|climb|surge|higher)/i.test(text);

  if (bullish && !bearish) return "UP";
  if (bearish && !bullish) return "DOWN";
  return null;
}

function refineItem(item) {
  if (!item || typeof item !== "object") return null;

  const text = textOf(item);
  if (!text) return null;

  if (isChartOrToolPage(text)) return null;
  if (isCbdcNoise(text)) return null;
  if (isPureFxForecast(text)) return null;
  if (isWeakRegionalBackground(item, text)) return null;

  const out = { ...item };
  let impact = clamp100(out.impact);
  let direction = String(out.goldDirection || "UNKNOWN").toUpperCase();
  let reason = String(out.relevanceReason || "");

  const reaction = goldMacroReaction(text);
  if (reaction) {
    direction = reaction;
    impact = Math.max(impact, 72);
    reason = reaction === "UP"
      ? "Золото + слабый доллар/снижение доходностей"
      : "Золото + сильный доллар/рост доходностей";
  }

  if (isEscalation(text)) {
    direction = "UP";
    impact = Math.max(impact, 76);
    reason = "Геополитическая эскалация / спрос на защитные активы";
  } else if (isDeescalation(text)) {
    direction = "DOWN";
    impact = Math.max(impact, 65);
    reason = "Снижение геополитического риска";
  }

  const region = String(out.region || "").toUpperCase();
  const regionalOnly = ["UK", "EUROPE", "JAPAN", "CHINA"].includes(region) &&
    !/\bgold\b|bullion|xauusd|treasury yields?|bond yields?|\bdxy\b|federal reserve|\bfomc\b|geopolit|war|missile|sanctions|gold reserves?/i.test(text);
  if (regionalOnly) impact = Math.min(impact, 35);

  if (String(out.eventKind || "").toUpperCase() === "PREVIEW") {
    impact = Math.min(impact, 52);
  }

  out.impact = clamp100(impact);
  out.relevanceScore = out.impact;
  out.level = out.impact >= 90 ? "EXTREME" : out.impact >= 75 ? "HIGH" : out.impact >= 55 ? "MEDIUM" : "LOW";
  out.goldDirection = direction;
  out.relevanceReason = reason ? `${reason} • XAU-фильтр V15` : "XAU-релевантность • XAU-фильтр V15";
  out.xauRelevanceVersion = "V15";

  return out;
}

function refineSnapshot(items) {
  return (Array.isArray(items) ? items : [])
    .map(refineItem)
    .filter(Boolean);
}

function wrapNewsExports(exportsObject) {
  if (!exportsObject || typeof exportsObject !== "object") return exportsObject;
  if (exportsObject[PATCHED]) return exportsObject;
  if (typeof exportsObject.getGoldNewsSnapshot !== "function") return exportsObject;

  const originalSnapshot = exportsObject.getGoldNewsSnapshot.bind(exportsObject);
  const wrapped = {
    ...exportsObject,
    async getGoldNewsSnapshot(...args) {
      return refineSnapshot(await originalSnapshot(...args));
    },
  };

  Object.defineProperty(wrapped, PATCHED, {
    value: true,
    enumerable: false,
  });

  if (!announced) {
    announced = true;
    console.log("✅ XAU NEWS FILTER V15: ON");
  }

  return wrapped;
}

Module._load = function patchedLoad(request, parent, isMain) {
  const loaded = originalLoad.apply(this, arguments);

  try {
    const resolved = Module._resolveFilename(request, parent, isMain);
    if (path.basename(String(resolved)).toLowerCase() === "news.js") {
      return wrapNewsExports(loaded);
    }
  } catch {
    // Keep Node's normal module-loading behavior on resolver edge cases.
  }

  return loaded;
};

module.exports = {
  refineItem,
  refineSnapshot,
};
