# AI Council Task — Review the Council Itself

Run ID: `AI_COUNCIL_ARCHITECTURE_SELF_REVIEW_2026_08_20_R1`

## Goal
Independently review the new persistent all-advisor workflow before it is trusted. The council must critique its own coordination architecture.

## Proposed architecture to review
- PostgreSQL tables persist canonical tasks and per-advisor/per-phase run state.
- Advisors currently expected: Gemini, DeepSeek, Claude, Grok.
- Same frozen project context and same task for everyone.
- Phase 1: independent response.
- Phase 2: peer review of successful independent responses.
- If an advisor is missing, rate-limited or fails, its slot remains PENDING and the rest continue.
- A periodic catch-up loop retries incomplete tasks.
- A synthesis can be provisional while advisors are missing.
- When a late advisor succeeds, synthesis is run again as a new revision.
- Research tasks should use grounded web search where the provider supports it (Gemini Google Search and Grok web_search); providers without grounded browsing must label URLs/legal availability UNVERIFIED.
- No council result directly changes MT5 trading or production rules.
- Pre-implementation design review and post-draft implementation review are mandatory for serious changes.

## Files currently proposed
- `ai-council.js` — advisor roles/basic council foundation.
- `ai-providers.js` — Gemini/DeepSeek/Claude provider adapters.
- `grok-provider.js` — Grok normal + grounded web-research adapter.
- `ai-council-persistent.js` — PostgreSQL queue, per-advisor state, independent/peer phases, synthesis and catch-up processing.
- `ai-council-catchup-bootstrap.js` — recurring processor and initial task seeding.
- `AI_COUNCIL_PROJECT_CONTEXT.md` — mandatory common rules/context.
- `AI_COUNCIL_ROADMAP_2026-08-20.md` — recent changes + near-term plans.
- `AI_COUNCIL_BOOK_REFRESH_TASK.md` — first full-council research task.
- `railpack.json` — syntax checks + preload of catch-up bootstrap.

## Questions every advisor must answer
1. Is this file/module separation sound? What should be merged, split or renamed?
2. What concurrency/race conditions exist if a catch-up pass overlaps or Railway runs more than one replica?
3. How should PostgreSQL task claiming/locking work to avoid duplicate paid API calls?
4. How should rate-limit/backoff/retry timing be persisted per provider instead of hammering a failing API?
5. How do we guarantee a late advisor performs a genuinely independent first pass before seeing peers?
6. How should we decide whether a late objection is material enough to require another synthesis/review cycle?
7. Should coordinator synthesis be produced by one provider, several providers, or deterministic aggregation + final coordinator? Explain cost/quality tradeoffs.
8. How should web sources/citations be normalized and verified across Gemini/Grok/other future providers?
9. What security/privacy issues exist when large project snapshots are sent to external AI providers? What must be redacted or excluded?
10. How should context size be controlled so the system does not repeatedly send unnecessary large books/code and waste tokens?
11. What observability is required: task status, provider status, attempts, cost/token usage, last error, last successful review, revision history?
12. What deterministic tests should be required before merge/deploy?
13. What happens when an advisor is unconfigured for weeks? Should a task ever become FINAL_WITH_MISSING_ADVISOR versus permanently WAITING?
14. How should future advisors (for example Kimi) catch up on old tasks without re-running every obsolete task?
15. Identify any simpler architecture that satisfies the user's rule with less complexity/cost.

## Required output
- architecture_verdict
- critical_bugs_or_risks
- recommended_file_structure
- database_and_locking_design
- retry_and_backoff_design
- context_and_cost_controls
- security_controls
- deterministic_test_plan
- what_to_change_before_merge
- what_can_wait
- confidence

## Safety
Review only. Do not trade, change production rules, expose secrets or claim an advisor participated without a logged response.
