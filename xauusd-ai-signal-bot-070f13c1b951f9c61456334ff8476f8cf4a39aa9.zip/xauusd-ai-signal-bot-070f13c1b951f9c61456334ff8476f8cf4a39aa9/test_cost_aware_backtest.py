"""Tests for the net-of-cost evaluation.

The point of the module is to stop a model that predicts direction well from
being promoted while losing money. So the load-bearing test is the one where
direction is perfect and the answer is still negative.
"""

from __future__ import annotations

import unittest

import numpy as np
import pandas as pd

from cost_aware_backtest import (
    DEFAULT_COSTS,
    TradingCosts,
    emit_decisions,
    net_verdict,
    simulate,
)

MINUTE_MS = 60_000


def frame(moves, *, entry=4000.0, spacing_minutes=120):
    """One decision row per move, spaced far enough apart not to overlap."""
    rows = []
    for i, move in enumerate(moves):
        ts = i * spacing_minutes * MINUTE_MS
        rows.append(
            {
                "timestamp": ts,
                "close": entry,
                "future_close_60": entry + move,
                "future_ts_60": ts + 60 * MINUTE_MS,
            }
        )
    return pd.DataFrame(rows)


def all_long(df):
    return np.ones(len(df), dtype=bool), np.ones(len(df), dtype=int)


class CostModelTest(unittest.TestCase):
    def test_round_trip_cost_is_the_sum_of_its_parts(self):
        costs = TradingCosts(
            spread_usd=0.30, slippage_usd_per_side=0.05, commission_usd_per_oz=0.06
        )
        self.assertAlmostEqual(costs.round_trip_usd, 0.46, places=12)


class SimulationTest(unittest.TestCase):
    def test_perfect_direction_still_loses_to_friction(self):
        # Every call is right, every move is +$0.20, friction is $0.46 a round
        # trip. Accuracy is 100%. The account bleeds $0.26 a trade. This is the
        # whole reason the module exists.
        df = frame([0.20] * 10)
        emit, direction = all_long(df)

        result = simulate(df, emit, direction, costs=DEFAULT_COSTS)

        self.assertEqual(result["trades"], 10)
        self.assertEqual(result["win_rate"], 0.0)
        self.assertGreater(result["gross_usd_per_oz"], 0.0)
        self.assertAlmostEqual(result["net_usd_per_oz"], -2.6, places=9)
        self.assertLess(result["net_bps_per_trade"], 0.0)
        self.assertGreater(result["gross_bps_per_trade"], 0.0)

    def test_an_edge_wider_than_friction_survives(self):
        df = frame([1.50] * 10)
        emit, direction = all_long(df)

        result = simulate(df, emit, direction)

        self.assertEqual(result["trades"], 10)
        self.assertEqual(result["win_rate"], 1.0)
        self.assertAlmostEqual(result["net_usd_per_oz"], 10.4, places=9)
        # (1.50 - 0.46) / 4000 * 10000 = 2.6 bps
        self.assertAlmostEqual(result["net_bps_per_trade"], 2.6, places=9)

    def test_short_trades_earn_when_price_falls(self):
        df = frame([-1.50] * 5)
        result = simulate(
            df, np.ones(len(df), dtype=bool), np.full(len(df), -1, dtype=int)
        )
        self.assertEqual(result["trades"], 5)
        self.assertAlmostEqual(result["net_usd_per_oz"], 5.2, places=9)

    def test_only_one_position_is_held_at_a_time(self):
        # Signals every 10 minutes at t=0..120 while each trade runs for 60. A
        # simulator that ignored the open position would book thirteen
        # overlapping trades on capital it does not have. Entries land at
        # t=0, 60 and 120; every signal in between is skipped.
        df = frame([1.50] * 13, spacing_minutes=10)
        emit, direction = all_long(df)

        result = simulate(df, emit, direction)

        self.assertEqual(result["signal_rows"], 13)
        self.assertEqual(result["trades"], 3)

    def test_drawdown_is_measured_from_the_peak_not_from_the_start(self):
        # Net per trade after $0.46 friction: +1.04, +1.04, -0.66, -0.66.
        # Equity runs 1.04 -> 2.08 -> 1.42 -> 0.76, so the account ends above
        # where it started and a drawdown-from-start would report nothing.
        # Measured from the 2.08 peak the real dip is -1.32.
        df = frame([1.50, 1.50, -0.20, -0.20])
        emit, direction = all_long(df)

        result = simulate(df, emit, direction)

        self.assertAlmostEqual(result["net_usd_per_oz"], 0.76, places=9)
        self.assertGreater(result["net_usd_per_oz"], 0.0)
        self.assertAlmostEqual(result["max_drawdown_usd_per_oz"], -1.32, places=9)

    def test_rows_without_a_signal_are_not_traded(self):
        df = frame([1.50] * 4)
        emit = np.array([True, False, False, True])
        result = simulate(df, emit, np.ones(len(df), dtype=int))
        self.assertEqual(result["trades"], 2)
        self.assertEqual(result["signal_rows"], 2)

    def test_no_signals_returns_zeros_and_never_divides_by_zero(self):
        df = frame([1.50] * 4)
        result = simulate(
            df, np.zeros(len(df), dtype=bool), np.ones(len(df), dtype=int)
        )
        self.assertEqual(result["trades"], 0)
        self.assertEqual(result["net_usd_per_oz"], 0.0)
        self.assertIsNone(result["net_bps_per_trade"])
        self.assertIsNone(result["profit_factor"])

    def test_missing_columns_are_refused_rather_than_guessed(self):
        df = frame([1.50] * 3).drop(columns=["future_close_60"])
        with self.assertRaises(RuntimeError):
            simulate(df, *all_long(df))


class EmitRuleTest(unittest.TestCase):
    def test_emit_matches_the_production_rule(self):
        thresholds = {
            "direction_confidence": 0.60,
            "predicted_strength_ratio": 0.25,
            "target_scale_bps": 8.7798,
        }
        classes = np.array([-1, 1])
        probs = np.array(
            [
                [0.10, 0.90],  # confident up, regressor agrees, big move -> trade
                [0.45, 0.55],  # confidence below 0.60 -> wait
                [0.10, 0.90],  # regressor disagrees -> wait
                [0.10, 0.90],  # move below 0.25 * 8.78 bps -> wait
            ]
        )
        predicted = np.array([5.0, 5.0, -5.0, 1.0])

        emit, sign = emit_decisions(probs, classes, predicted, thresholds)

        self.assertEqual(list(emit), [True, False, False, False])
        self.assertEqual(list(sign), [1, 1, 1, 1])


class VerdictTest(unittest.TestCase):
    def test_refuses_a_challenger_that_loses_money(self):
        ok, reasons = net_verdict(
            {"net_bps_per_trade": 0.5, "trades": 100},
            {"net_bps_per_trade": -0.2, "trades": 100},
        )
        self.assertFalse(ok)
        self.assertTrue(any("net_edge_not_positive" in r for r in reasons))

    def test_refuses_a_profitable_challenger_worse_than_the_champion(self):
        ok, reasons = net_verdict(
            {"net_bps_per_trade": 1.2, "trades": 100},
            {"net_bps_per_trade": 0.4, "trades": 100},
        )
        self.assertFalse(ok)
        self.assertTrue(any("net_edge_below_champion" in r for r in reasons))

    def test_refuses_when_there_are_too_few_trades_to_judge(self):
        ok, reasons = net_verdict(
            {"net_bps_per_trade": 0.1, "trades": 100},
            {"net_bps_per_trade": 9.9, "trades": 3},
        )
        self.assertFalse(ok)
        self.assertTrue(any("net_trades_below" in r for r in reasons))

    def test_accepts_a_clear_improvement(self):
        ok, reasons = net_verdict(
            {"net_bps_per_trade": 0.4, "trades": 100},
            {"net_bps_per_trade": 1.1, "trades": 120},
        )
        self.assertTrue(ok)
        self.assertEqual(reasons, [])

    def test_a_champion_that_never_trades_does_not_block_a_profitable_one(self):
        # The live champion emitted nothing at all across a whole validation
        # window, so there is no champion edge to compare against. A profitable
        # challenger must still be able to replace it.
        silent_champion = {"trades": 0, "net_bps_per_trade": None}
        ok, reasons = net_verdict(
            silent_champion, {"net_bps_per_trade": 1.1, "trades": 120}
        )
        self.assertTrue(ok)
        self.assertEqual(reasons, [])

    def test_is_fail_closed_on_missing_numbers(self):
        self.assertFalse(net_verdict({}, {})[0])
        self.assertFalse(net_verdict({}, {"trades": 100})[0])
        self.assertFalse(
            net_verdict({}, {"trades": 100, "net_bps_per_trade": None})[0]
        )


if __name__ == "__main__":
    unittest.main()
