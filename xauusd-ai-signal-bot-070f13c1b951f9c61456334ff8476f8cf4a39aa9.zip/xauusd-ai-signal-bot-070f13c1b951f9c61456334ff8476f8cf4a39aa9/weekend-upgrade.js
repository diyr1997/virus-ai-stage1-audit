"use strict";

const fs = require("fs");
const os = require("os");
const path = require("path");
const { promisify } = require("util");
const { execFile } = require("child_process");
const { Pool } = require("pg");
const { buildAdvisorPrompt } = require("./ai-council");
const { callProvider, callGeminiGrounded } = require("./ai-providers");

const execFileAsync = promisify(execFile);
const TZ = process.env.WEEKEND_UPGRADE_TIMEZONE || "Asia/Tashkent";
const DATABASE_URL = String(
  process.env.DATABASE_URL || process.env.DATABASE_PUBLIC_URL || ""
).trim();
const BOT_TOKEN = String(process.env.TELEGRAM_BOT_TOKEN || "").trim();
const PYTHON = process.env.PYTHON_BIN || path.join(__dirname, ".venv", "bin", "python");
const {
  classifyTrainingTier,
  auditCandles,
  promotionDecision,
} = require("./training-data-policy");

const TRAINER = path.join(__dirname, "weekend_train_h1.py");
const BUILTIN_MODEL = path.join(__dirname, "xauusd_ai_final_h1_full_period.joblib");
const ACTIVE_MODEL_TMP = path.join(os.tmpdir(), "xauusd_ai_h1_active.joblib");
const ENABLED = String(process.env.AUTO_TRAINING_ENABLED || "1") !== "0";
const CHECK_MS = Math.max(30_000, Number(process.env.AUTO_TRAINING_CHECK_MS || 60_000));
const DAILY_LIMIT = Math.max(8_000, Number(process.env.AUTO_TRAINING_DAILY_M1 || 40_000));
const WEEKEND_LIMIT = Math.max(12_000, Number(process.env.AUTO_TRAINING_WEEKEND_M1 || 120_000));

// Weekend Lab: not an endless loop over the same model. Every slot is a
// distinct experiment. Saturday begins after the market is safely closed;
// Sunday stops heavy work early enough to leave a large buffer before Monday.
const WEEKEND_START_HOUR = Math.max(
  3,
  Math.min(10, Number(process.env.WEEKEND_LAB_START_HOUR || 5))
);
const WEEKEND_SLOT_HOURS = Math.max(
  2,
  Math.min(6, Number(process.env.WEEKEND_LAB_SLOT_HOURS || 4))
);
const WEEKEND_LAST_HEAVY_HOUR = Math.max(
  18,
  Math.min(22, Number(process.env.WEEKEND_LAST_HEAVY_HOUR || 20))
);
const WEEKEND_COUNCIL_EVERY_SLOTS = Math.max(
  1,
  Math.min(8, Number(process.env.WEEKEND_COUNCIL_EVERY_SLOTS || 2))
);

const pool = DATABASE_URL
  ? new Pool({ connectionString: DATABASE_URL, max: 2, idleTimeoutMillis: 30_000 })
  : null;

let running = false;

function localParts(now = new Date()) {
  const fmt = new Intl.DateTimeFormat("en-CA", {
    timeZone: TZ,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    weekday: "short",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  });
  const parts = Object.fromEntries(
    fmt.formatToParts(now)
      .filter((p) => p.type !== "literal")
      .map((p) => [p.type, p.value])
  );
  return {
    date: `${parts.year}-${parts.month}-${parts.day}`,
    weekday: parts.weekday,
    hour: Number(parts.hour),
    minute: Number(parts.minute),
  };
}

function weekendSlot(local) {
  if (!["Sat", "Sun"].includes(local.weekday)) return null;

  const dayStart = local.weekday === "Sat" ? WEEKEND_START_HOUR : 0;
  if (local.hour < dayStart || local.hour > WEEKEND_LAST_HEAVY_HOUR) return null;

  const slotIndex = Math.floor((local.hour - dayStart) / WEEKEND_SLOT_HOURS);
  const slotHour = dayStart + slotIndex * WEEKEND_SLOT_HOURS;
  if (slotHour > WEEKEND_LAST_HEAVY_HOUR) return null;

  const saturdaySlots =
    Math.floor((WEEKEND_LAST_HEAVY_HOUR - WEEKEND_START_HOUR) / WEEKEND_SLOT_HOURS) + 1;
  const sundaySlots = Math.floor(WEEKEND_LAST_HEAVY_HOUR / WEEKEND_SLOT_HOURS) + 1;
  const trial = local.weekday === "Sat" ? slotIndex : saturdaySlots + slotIndex;
  const final = local.weekday === "Sun" && slotIndex === sundaySlots - 1;
  const runCouncil = final || trial % WEEKEND_COUNCIL_EVERY_SLOTS === 0;

  return { slotIndex, slotHour, trial, final, runCouncil };
}

async function ensureSchema() {
  if (!pool) return;
  await pool.query(`
    CREATE TABLE IF NOT EXISTS weekend_upgrade_runs (
      run_key VARCHAR(80) PRIMARY KEY,
      kind VARCHAR(24) NOT NULL,
      status VARCHAR(24) NOT NULL,
      started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      finished_at TIMESTAMPTZ,
      metrics JSONB NOT NULL DEFAULT '{}'::jsonb,
      report JSONB NOT NULL DEFAULT '{}'::jsonb,
      error TEXT
    )
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS model_registry (
      id BIGSERIAL PRIMARY KEY,
      model_key VARCHAR(40) NOT NULL,
      version VARCHAR(120) NOT NULL UNIQUE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      active BOOLEAN NOT NULL DEFAULT FALSE,
      source VARCHAR(40) NOT NULL DEFAULT 'AUTO_TRAINING',
      metrics JSONB NOT NULL DEFAULT '{}'::jsonb,
      model_bytes BYTEA NOT NULL,
      payload JSONB NOT NULL DEFAULT '{}'::jsonb
    )
  `);
  await pool.query(`
    CREATE INDEX IF NOT EXISTS idx_model_registry_active
    ON model_registry(model_key, active, created_at DESC)
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS weekend_improvement_proposals (
      id BIGSERIAL PRIMARY KEY,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      run_key VARCHAR(80) NOT NULL,
      source VARCHAR(40) NOT NULL DEFAULT 'AI_COUNCIL',
      status VARCHAR(24) NOT NULL DEFAULT 'PROPOSED',
      proposal TEXT NOT NULL,
      payload JSONB NOT NULL DEFAULT '{}'::jsonb
    )
  `);
}

async function claimRun(runKey, kind) {
  const result = await pool.query(
    `INSERT INTO weekend_upgrade_runs(run_key, kind, status)
     VALUES($1,$2,'RUNNING') ON CONFLICT(run_key) DO NOTHING RETURNING run_key`,
    [runKey, kind]
  );
  return result.rowCount === 1;
}

async function finishRun(runKey, status, metrics = {}, report = {}, error = null) {
  await pool.query(
    `UPDATE weekend_upgrade_runs
     SET status=$2, finished_at=NOW(), metrics=$3::jsonb, report=$4::jsonb, error=$5
     WHERE run_key=$1`,
    [runKey, status, JSON.stringify(metrics), JSON.stringify(report), error]
  );
}

async function gatherWeeklyMetrics() {
  const [analysis, trades, state] = await Promise.all([
    pool.query(`
      SELECT ar.timeframe,
             COUNT(*)::int AS analyses,
             COUNT(*) FILTER (WHERE ar.action IN ('BUY','SELL'))::int AS signals,
             COUNT(r.id)::int AS checked,
             COUNT(*) FILTER (WHERE r.success IS TRUE)::int AS correct,
             COUNT(*) FILTER (WHERE r.success IS FALSE)::int AS wrong
      FROM analysis_runs ar
      LEFT JOIN analysis_results r ON r.analysis_id=ar.id
      WHERE ar.analyzed_at >= NOW() - INTERVAL '7 days'
      GROUP BY ar.timeframe ORDER BY ar.timeframe
    `),
    pool.query(`
      SELECT COUNT(*) FILTER (WHERE status='CLOSED')::int AS closed,
             COUNT(*) FILTER (WHERE status='OPEN')::int AS open,
             COUNT(*) FILTER (WHERE status='CLOSED' AND profit > 0)::int AS wins,
             COUNT(*) FILTER (WHERE status='CLOSED' AND profit < 0)::int AS losses,
             COALESCE(SUM(profit) FILTER (WHERE status='CLOSED'),0)::float8 AS profit,
             COALESCE(AVG(slippage) FILTER (WHERE status='CLOSED'),0)::float8 AS avg_slippage
      FROM demo_trades WHERE created_at >= NOW() - INTERVAL '7 days'
    `),
    pool.query(`SELECT key, value, updated_at FROM demo_worker_state
                WHERE key IN ('heartbeat','last_error','market_state')`),
  ]);

  return {
    generated_at: new Date().toISOString(),
    analysis_by_timeframe: analysis.rows,
    demo: trades.rows[0] || {},
    worker_state: state.rows,
  };
}

async function exportCandles(limit) {
  const result = await pool.query(
    `SELECT (EXTRACT(EPOCH FROM candle_time)*1000)::bigint AS timestamp,
            open::float8, high::float8, low::float8, close::float8, volume::float8
     FROM xauusd_candles
     WHERE timeframe='M1'
     ORDER BY candle_time DESC LIMIT $1`,
    [limit]
  );
  return result.rows.reverse();
}

async function materializeChampion() {
  const result = await pool.query(
    `SELECT version, model_bytes FROM model_registry
     WHERE model_key='H1' AND active=TRUE ORDER BY created_at DESC LIMIT 1`
  );
  if (result.rows[0]?.model_bytes) {
    fs.writeFileSync(ACTIVE_MODEL_TMP, result.rows[0].model_bytes);
    return { path: ACTIVE_MODEL_TMP, version: result.rows[0].version, source: "registry" };
  }
  return { path: BUILTIN_MODEL, version: "builtin", source: "repository" };
}

async function promoteModel(training, candidatePath) {
  const decision = promotionDecision({
    accepted: training?.accepted,
    tier: training?.data_tier,
    audit: training?.data_audit,
  });
  if (!decision.promote) {
    training.promotion_block_reason = decision.reason;
    console.log(`🛡 AUTO UPGRADE promotion blocked | ${decision.reason}`);
    return false;
  }
  const bytes = fs.readFileSync(candidatePath);
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query(`UPDATE model_registry SET active=FALSE WHERE model_key='H1' AND active=TRUE`);
    await client.query(
      `INSERT INTO model_registry(model_key,version,active,source,metrics,model_bytes,payload)
       VALUES('H1',$1,TRUE,'AUTO_TRAINING',$2::jsonb,$3,$4::jsonb)`,
      [training.version, JSON.stringify(training), bytes,
       JSON.stringify({ promoted_at: new Date().toISOString() })]
    );
    await client.query("COMMIT");
    fs.writeFileSync(ACTIVE_MODEL_TMP, bytes);
    return true;
  } catch (e) {
    await client.query("ROLLBACK").catch(() => {});
    throw e;
  } finally {
    client.release();
  }
}

async function trainModel(mode, trial = 0) {
  const limit = mode === "weekend" ? WEEKEND_LIMIT : DAILY_LIMIT;
  const candles = await exportCandles(limit);
  if (candles.length < 8_000) {
    return {
      ok: false,
      skipped: true,
      reason: `not_enough_M1_${candles.length}`,
      source_rows: candles.length,
    };
  }

  // Audit and classify the exact rows the trainer is about to learn from, with
  // the same shared policy the current-data lab uses. Without this the daily
  // slot promoted a challenger trained on whatever happened to be in the table.
  const audit = auditCandles(candles);
  const tier = classifyTrainingTier({
    rows: audit.rows,
    tradingDays: audit.tradingDays,
  });
  if (!tier.canTrain) {
    return {
      ok: false,
      skipped: true,
      reason: tier.reason,
      source_rows: audit.rows,
      trading_days: audit.tradingDays,
      data_audit: audit,
      data_tier: tier,
    };
  }

  const champion = await materializeChampion();
  const stamp = Date.now();
  const candlesPath = path.join(os.tmpdir(), `weekend_train_candles_${stamp}.json`);
  const candidatePath = path.join(os.tmpdir(), `weekend_candidate_${stamp}.joblib`);
  fs.writeFileSync(candlesPath, JSON.stringify(candles), "utf8");

  try {
    const { stdout, stderr } = await execFileAsync(
      PYTHON,
      [
        TRAINER,
        "--champion", champion.path,
        "--candles", candlesPath,
        "--output", candidatePath,
        "--mode", mode,
        "--trial", String(trial),
      ],
      {
        timeout: mode === "weekend" ? 30 * 60_000 : 12 * 60_000,
        maxBuffer: 4 * 1024 * 1024,
      }
    );
    if (stderr?.trim()) {
      console.log("🧠 AUTO TRAIN stderr:", stderr.trim().slice(0, 1200));
    }
    const line = String(stdout || "").trim().split(/\r?\n/).filter(Boolean).pop();
    const training = JSON.parse(line || "{}");
    if (!training.ok) throw new Error(training.error || "training failed");
    training.champion_source = champion.source;
    training.data_audit = audit;
    training.data_tier = tier;
    training.source_rows = audit.rows;
    training.trading_days = audit.tradingDays;
    training.promotion_eligible = tier.canPromote;
    training.promoted = await promoteModel(training, candidatePath);
    return training;
  } finally {
    fs.unlink(candlesPath, () => {});
    fs.unlink(candidatePath, () => {});
  }
}

async function safeAdvisor(provider, prompt) {
  try {
    const text = await callProvider(provider, prompt);
    return { provider, ok: true, text: String(text || "").slice(0, 30000) };
  } catch (error) {
    return {
      provider,
      ok: false,
      error: String(error?.message || error).slice(0, 1000),
    };
  }
}

async function runWeekendCouncil(metrics, training) {
  let google = null;
  try {
    google = await callGeminiGrounded(
      `XAU/USD weekly engineering review. Today is ${new Date().toISOString()}.
Use Google Search to identify CURRENT primary/high-quality macro sources and current information streams that matter for gold: Federal Reserve/FOMC, BLS inflation/jobs, US Treasury/yields, CFTC, major central banks and reliable economic calendars. Do not give a trade call. Recommend how our news ingestion, freshness scoring, duplicate filtering and event-impact logic can improve. Clearly separate verified current sources from engineering suggestions.`
    );
  } catch (error) {
    google = { error: String(error?.message || error) };
  }

  const task = `Safe self-improvement review for the XAU/USD two-bot project.
WEEK METRICS:\n${JSON.stringify(metrics, null, 2)}
AUTO-TRAIN RESULT:\n${JSON.stringify(training, null, 2)}
GEMINI+GOOGLE CURRENT-SOURCE REVIEW:\n${JSON.stringify(google, null, 2)}
Find concrete measurable improvements to signal quality, forecast graph, news freshness, data quality, testing, DEMO reliability and risk controls. Separate: (1) model/data experiments that may be automated safely; (2) code/risk changes that must remain proposals until tested. No production writes.`;

  const first = [];
  for (const provider of ["gemini", "deepseek", "claude"]) {
    first.push(await safeAdvisor(provider, buildAdvisorPrompt({ task, advisor: provider })));
  }
  const available = first.filter((x) => x.ok);
  const coordinator = await safeAdvisor(
    "coordinator",
    buildAdvisorPrompt({ task, advisor: "coordinator", previousResponses: available })
  );
  return { google_grounded_review: google, advisors: first, coordinator };
}

async function saveCouncilProposal(runKey, council) {
  const text = String(council?.coordinator?.text || "").trim();
  if (!text) return;
  await pool.query(
    `INSERT INTO weekend_improvement_proposals(run_key, source, status, proposal, payload)
     VALUES($1,'AI_COUNCIL','PROPOSED',$2,$3::jsonb)`,
    [runKey, text, JSON.stringify({ council })]
  );
}

async function ownerChatId() {
  const env = Number(process.env.TELEGRAM_OWNER_CHAT_ID || 0);
  if (env) return env;
  const r = await pool.query(
    `SELECT value FROM bot_settings WHERE key='owner_chat_id' LIMIT 1`
  );
  return Number(r.rows[0]?.value || 0);
}

async function notify(text) {
  const chatId = await ownerChatId().catch(() => 0);
  if (!BOT_TOKEN || !chatId) return;
  await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, text: String(text).slice(0, 3900) }),
  }).catch(() => {});
}

async function executeRun(kind, runKey, options = {}) {
  if (!(await claimRun(runKey, kind))) return;
  console.log(`🧠 AUTO UPGRADE START | ${runKey}`);

  try {
    const metrics = await gatherWeeklyMetrics();
    const mode = kind === "DAILY" ? "daily" : "weekend";
    const trial = Number(options.trial || 0);
    const training = await trainModel(mode, trial);

    let council = null;
    if (kind !== "DAILY" && options.runCouncil) {
      council = await runWeekendCouncil(metrics, training);
      await saveCouncilProposal(runKey, council).catch((error) => {
        console.warn("WEEKEND proposal save:", error.message);
      });
    }

    const report = {
      training,
      council,
      trial,
      final: Boolean(options.final),
      safety: "AI advisors cannot write trading production code",
    };
    await finishRun(runKey, "SUCCESS", metrics, report, null);

    const status = training?.promoted
      ? `✅ новая H1 модель активирована: ${training.version}`
      : training?.accepted
      ? "⚠️ challenger прошёл тест, но не был активирован"
      : `🛡 старая модель оставлена${training?.reason ? ` (${training.reason})` : ""}`;

    // Avoid Telegram spam during the weekend lab. Report only real promotion,
    // final Sunday result, or the single daily run.
    if (kind === "DAILY" || training?.promoted || options.final) {
      await notify(
        `${kind === "DAILY" ? "🧠 НОЧНОЕ ОБУЧЕНИЕ" : "🧪 WEEKEND LAB"}\n${status}\n` +
        `Эксперимент: ${training?.profile?.name || trial}\n` +
        `M1 данных: ${training?.source_rows ?? "?"}\n` +
        `${council ? "Gemini/Google и AI Council завершили аудит. " : ""}` +
        `Результат сохранён в PostgreSQL.`
      );
    }

    console.log(
      `🧠 AUTO UPGRADE DONE | ${runKey} | trial=${trial} | promoted=${Boolean(training?.promoted)}`
    );
  } catch (error) {
    await finishRun(
      runKey,
      "FAILED",
      {},
      {},
      String(error?.message || error)
    ).catch(() => {});
    if (options.final || kind === "DAILY") {
      await notify(
        `❌ AUTO UPGRADE FAILED\n${String(error?.message || error).slice(0, 1200)}\nРабочая модель не заменена.`
      );
    }
    console.error("❌ AUTO UPGRADE:", error);
  }
}

async function schedulerTick() {
  if (!ENABLED || !pool || running) return;
  const local = localParts();
  let kind = null;
  let runKey = null;
  let options = {};

  if (
    ["Mon", "Tue", "Wed", "Thu", "Fri"].includes(local.weekday) &&
    local.hour === 2 &&
    local.minute >= 5
  ) {
    kind = "DAILY";
    runKey = `${local.date}:DAILY`;
  } else {
    const slot = weekendSlot(local);
    if (slot) {
      kind = local.weekday === "Sat" ? "WEEKEND_SAT" : "WEEKEND_SUN";
      runKey = `${local.date}:${kind}:H${String(slot.slotHour).padStart(2, "0")}`;
      options = {
        trial: slot.trial,
        final: slot.final,
        runCouncil: slot.runCouncil,
      };
    }
  }

  if (!kind) return;
  running = true;
  try {
    await executeRun(kind, runKey, options);
  } finally {
    running = false;
  }
}

async function start() {
  if (!ENABLED) {
    console.log("🧠 AUTO TRAINING: disabled by AUTO_TRAINING_ENABLED=0");
    return;
  }
  if (!pool) {
    console.warn("⚠️ AUTO TRAINING: PostgreSQL unavailable");
    return;
  }

  await ensureSchema();
  console.log(
    `✅ AUTO TRAINING V7.3: daily 02:05 ${TZ}; Weekend Lab Sat ${WEEKEND_START_HOUR}:00 -> Sun ${WEEKEND_LAST_HEAVY_HOUR}:00 every ${WEEKEND_SLOT_HOURS}h; varied challengers + periodic Gemini/Google + AI Council`
  );

  setTimeout(
    () => schedulerTick().catch((e) => console.error("AUTO UPGRADE tick:", e)),
    20_000
  );
  setInterval(
    () => schedulerTick().catch((e) => console.error("AUTO UPGRADE tick:", e)),
    CHECK_MS
  ).unref();
}

start().catch((error) => console.error("❌ AUTO TRAINING INIT:", error));

module.exports = {
  localParts,
  weekendSlot,
  schedulerTick,
  executeRun,
};
