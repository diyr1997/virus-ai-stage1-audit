"use strict";

/**
 * Trading School core-book priority helper.
 *
 * 1) Expands every Zerodha html_collection module from its index into all
 *    chapter URLs in source order (TA, Trading Systems, Risk).
 * 2) Defers engineering/context PDFs from Gemini semantic reading so scarce AI
 *    quota is spent first on the analytical books the user asked to learn.
 *    Their full source text remains stored in PostgreSQL and can be resumed
 *    later without downloading again.
 * 3) Repairs/retries an empty FPP3 online-book seed instead of falsely treating
 *    a zero-text failed page as a fully ingested book.
 * 4) Logs compact progress for every source.
 */

const fs = require("fs");
const path = require("path");
const { Pool } = require("pg");

const DATABASE_URL = String(
  process.env.DATABASE_URL || process.env.DATABASE_PUBLIC_URL || ""
).trim();
const MANIFEST_PATH = path.join(__dirname, "trading_school", "library_manifest.json");
const RUN_MS = Math.max(5 * 60_000, Number(process.env.TRADING_SCHOOL_PRIORITY_REFRESH_MS || 30 * 60_000));

const pool = DATABASE_URL
  ? new Pool({ connectionString: DATABASE_URL, max: 1, idleTimeoutMillis: 30_000 })
  : null;

function manifest() {
  return JSON.parse(fs.readFileSync(MANIFEST_PATH, "utf8"));
}

function normalizeUrl(raw, base) {
  try {
    const u = new URL(raw, base);
    u.hash = "";
    if (!["http:", "https:"].includes(u.protocol)) return null;
    return u.toString();
  } catch {
    return null;
  }
}

function linksInOrder(html, base) {
  const out = [];
  const seen = new Set();
  const rx = /<a\b[^>]*?href\s*=\s*["']([^"']+)["'][^>]*>/gi;
  let match;
  while ((match = rx.exec(String(html || "")))) {
    const url = normalizeUrl(match[1], base);
    if (!url || seen.has(url)) continue;
    seen.add(url);
    out.push(url);
  }
  return out;
}

async function fetchHtml(url) {
  const response = await fetch(url, {
    headers: {
      "user-agent": "XAUUSD-Trading-School/2.1 (private educational reader)",
      accept: "text/html,application/xhtml+xml",
    },
    redirect: "follow",
    signal: AbortSignal.timeout(60_000),
  });
  if (!response.ok) throw new Error(`HTTP ${response.status} ${url}`);
  return response.text();
}

async function expandZerodha(source) {
  const html = await fetchHtml(source.entry_url);
  const hostSet = new Set((source.allowed_hosts || []).map((x) => String(x).toLowerCase()));
  const chapters = linksInOrder(html, source.entry_url).filter((raw) => {
    try {
      const u = new URL(raw);
      if (hostSet.size && !hostSet.has(u.hostname.toLowerCase())) return false;
      return u.pathname.startsWith(source.path_prefix || "/varsity/chapter/");
    } catch {
      return false;
    }
  });

  let seq = 2;
  for (const url of chapters.slice(0, Math.max(0, Number(source.max_pages || 60) - 1))) {
    await pool.query(
      `INSERT INTO trading_school_pages(book_key,seq,url,status)
       VALUES($1,$2,$3,'PENDING')
       ON CONFLICT(book_key,url) DO UPDATE SET
         seq=LEAST(trading_school_pages.seq, EXCLUDED.seq),
         updated_at=NOW()`,
      [source.key, seq++, url]
    );
  }

  await pool.query(
    `UPDATE trading_school_books SET discovered_pages=(
       SELECT COUNT(*) FROM trading_school_pages WHERE book_key=$1
     ), updated_at=NOW() WHERE book_key=$1`,
    [source.key]
  );
  console.log(`📚 BOOK MAP ${source.key}: ${chapters.length} chapter links found`);
}

async function repairEmptyFpp3() {
  const stats = await pool.query(
    `SELECT b.status,b.total_chars,
            COUNT(p.id)::int AS pages,
            COUNT(p.id) FILTER(WHERE p.status='INGESTED')::int AS ingested,
            COUNT(p.id) FILTER(WHERE p.status='ERROR')::int AS errors
     FROM trading_school_books b
     LEFT JOIN trading_school_pages p ON p.book_key=b.book_key
     WHERE b.book_key='fpp3'
     GROUP BY b.status,b.total_chars`
  );
  const row = stats.rows[0];
  if (!row) return;

  const chars = Number(row.total_chars || 0);
  const ingested = Number(row.ingested || 0);
  const errors = Number(row.errors || 0);

  if (chars > 0 && ingested > 0) return;

  // Retry at most once per priority cycle (normally every 30 minutes). The
  // Full Reader will pick the PENDING page on its next reading tick.
  if (errors > 0) {
    await pool.query(
      `UPDATE trading_school_pages
       SET status='PENDING',error=NULL,updated_at=NOW()
       WHERE book_key='fpp3' AND status='ERROR'`
    );
  }
  await pool.query(
    `UPDATE trading_school_books
     SET status='QUEUED',last_error=NULL,updated_at=NOW()
     WHERE book_key='fpp3'`
  );
  console.log(`📚 FPP3 REPAIR | zero-text source reset for retry | prior_errors=${errors}`);
}

async function deferNonCoreAi() {
  // These sources are already downloaded in full. Keep them in private storage,
  // but do not let a 2,047-page engineering manual consume the first AI quota
  // needed for price action / systems / risk / forecasting understanding.
  await pool.query(
    `UPDATE trading_school_chunks
     SET ai_status='DEFERRED', updated_at=NOW()
     WHERE book_key IN ('mql5_book','cme_futures_guide')
       AND ai_status IN ('PENDING','RETRY')`
  );
}

async function logProgress() {
  const result = await pool.query(
    `SELECT b.book_key,b.status,b.discovered_pages,b.ingested_pages,b.summarized_chunks,b.total_chars,b.last_error,
            (SELECT p.error FROM trading_school_pages p
              WHERE p.book_key=b.book_key AND p.error IS NOT NULL
              ORDER BY p.updated_at DESC LIMIT 1) AS page_error,
            COUNT(c.id)::int AS chunks,
            COUNT(c.id) FILTER(WHERE c.ai_status='DONE')::int AS understood,
            COUNT(c.id) FILTER(WHERE c.ai_status='DEFERRED')::int AS deferred
     FROM trading_school_books b
     LEFT JOIN trading_school_chunks c ON c.book_key=b.book_key
     GROUP BY b.book_key,b.status,b.discovered_pages,b.ingested_pages,b.summarized_chunks,b.total_chars
     ORDER BY CASE b.book_key
       WHEN 'zerodha_ta' THEN 1
       WHEN 'zerodha_trading_systems' THEN 2
       WHEN 'zerodha_risk' THEN 3
       WHEN 'fpp3' THEN 4
       WHEN 'cme_futures_guide' THEN 5
       WHEN 'mql5_book' THEN 6
       WHEN 'quantinsti_2026' THEN 7
       ELSE 99 END, b.book_key`
  );
  for (const row of result.rows) {
    // A book with pages discovered but none read is stuck, and the reason was
    // only ever written to the database. Without it "pages=0/1" is a dead end
    // for whoever is reading the logs.
    const stuck =
      Number(row.discovered_pages || 0) > 0 && Number(row.ingested_pages || 0) === 0;
    const why = stuck
      ? String(row.page_error || row.last_error || "no error recorded").split("\n")[0].slice(0, 160)
      : "";
    console.log(
      `📚 SCHOOL STATUS ${row.book_key} | pages=${row.ingested_pages}/${row.discovered_pages} | chunks=${row.understood}/${row.chunks} understood | deferred=${row.deferred} | chars=${row.total_chars} | ${row.status}` +
        (why ? ` | STUCK: ${why}` : "")
    );
  }
}

async function run() {
  if (!pool) return;
  try {
    const m = manifest();
    for (const source of m.sources || []) {
      if (source.type !== "html_collection" || !source.entry_url) continue;
      if (!String(source.entry_url).includes("zerodha.com/varsity/module/")) continue;
      await expandZerodha(source);
    }
    await repairEmptyFpp3();
    await deferNonCoreAi();
    await logProgress();
  } catch (error) {
    console.warn(`📚 SCHOOL PRIORITY: ${String(error?.message || error).slice(0, 1000)}`);
  }
}

setTimeout(run, 25_000).unref();
setInterval(run, RUN_MS).unref();

module.exports = { run, expandZerodha, repairEmptyFpp3 };
