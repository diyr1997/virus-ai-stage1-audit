# XAU/USD AI Council Project Context

Updated: 2026-09-20

## Purpose

This project builds a controlled XAU/USD analysis and DEMO trading system. It is not financial advice and must not trade a real account.

## Components

- Bot 1: Telegram analytical bot. It collects market data and news, analyzes M1/M5/M15/M30/H1, creates BUY/SELL/WAIT analysis, charts, entry conditions, cancellation levels, SL/TP and statistics.
- Bot 2: Windows MT5 DEMO worker. It receives DEMO candidates, checks live MT5 data, applies risk controls, and manages DEMO trades only.
- PostgreSQL: persistent storage for candles, analyses, news-derived pressure, candidates, DEMO trades, worker state, errors, results and AI Council task state.
- Railway: cloud service for Bot 1 and PostgreSQL. The MT5 DEMO worker remains on the user's Windows computer.

## Core trading rules

- Analyze closed candles only.
- Keep M1, M5, M15, M30 and H1 separate.
- Below strength 60/100: WAIT; do not create a new DEMO candidate.
- Existing positions must not be closed only because signal strength falls.
- Bot 2 must check balance, equity, margin, free margin, open positions, SL risk and total volume before opening or adding positions.
- Real accounts are blocked. Never remove this safety boundary.
- Any strategy change must be tested on historical data and DEMO before activation.

## VIRUS AI ONE-BRAIN / ABSORPTION RULE

The long-term runtime target is ONE native VIRUS AI brain, not an internal voting committee of ChatGPT/Claude/Gemini/DeepSeek/Grok/Kimi/Perplexity or named forecasting models.

External advisors and lawful public/open-source AI systems are teachers, donors and research inputs. VIRUS may absorb useful open capabilities such as algorithms, architecture ideas, SDK/tool-use patterns, memory/retrieval, planning, evals, model components, research code, compatible weights, news understanding, time-series methods, microstructure methods, safety/observability and other skills after verification and testing.

The final trading contract remains:

`VIRUS AI -> BUY / SELL / WAIT + forecast + uncertainty + reasons -> Risk -> Safety -> Execution`

Do not expose or rely on runtime majority voting such as `GPT=BUY, Gemini=SELL, Claude=WAIT`. Correlated donor methods are not independent evidence.

Detailed learning/discovery architecture is stored in `VIRUS_AI_CONTINUOUS_LEARNING_AND_ABSORPTION.md` and must be consulted for new AI skills, GitHub candidates, news-AI improvements and self-improvement design.

AI Council findings must first become measurable candidates/hypotheses. They may teach, review and help create challenger generations, but they do not become direct runtime trading votes.

## NEWS INTELLIGENCE RULE

News is part of the VIRUS intelligence layer, not an external voting bot.

- Preserve point-in-time provenance: source, event id, publication/event/first-seen/as-of times.
- Canonicalize one underlying event so repeated articles do not multiply confidence.
- Use AI to understand event type, entities, actual/forecast/previous when available, gold/USD/rates/risk relevance, novelty, uncertainty and likely horizon.
- Fuse news representation with market regime, volatility, session, liquidity and later order-flow context.
- Learn/test time decay and event impact across M1/M5/M15/M30/H1 instead of treating an AI opinion as a rule.
- High-impact scheduled events may produce a safety embargo/no-trade state.
- News Intelligence produces structured evidence to the single VIRUS brain; it does not send BUY/SELL orders itself.

## CONTINUOUS SKILL / CAPABILITY DISCOVERY RULE

The project should maintain a research queue for meaningful new or updated lawful public capabilities from GitHub, official SDKs/APIs, research code and primary-source releases.

For each candidate record exact source, version/commit, code license, weights license where relevant, maintenance, dependencies, security, overlap, XAU/USD and future Binance relevance, legal/API restrictions, proposed absorption mode, deterministic test plan and status `WATCH | ISOLATED_TEST | ADOPTED | REJECTED`.

Discovery is not adoption. A candidate must pass verification, anti-leakage/OOS testing, redundancy/ablation, cost-aware evaluation where trading is affected, safety checks and shadow/DEMO validation before promotion.

## Mandatory AI Council operating rule

For every serious project task — strategy, code, books, news, models, graphs, entries/exits, risk, diagnostics or architecture — the work belongs to the whole available AI Council, not to one advisor alone.

1. Every configured/available advisor receives the same structured task and the same frozen project-context snapshot.
2. Each advisor first works independently so that early answers do not anchor the others.
3. Then every available advisor receives the other advisors' responses and performs peer review: challenge mistakes, unsupported assumptions, contradictions, missing alternatives, weak sources and unsafe changes.
4. The coordinator reconciles the evidence and disagreements. The result is not decided by majority vote; verifiability, testability, robustness and DEMO safety take priority.
5. ChatGPT is the user's coordinator/communication link and final explainer, not the only source of ideas and not an excuse to skip other advisors.
6. If one advisor is unavailable because of missing credentials, quota, API failure or deployment problems, the task does NOT disappear. That advisor remains PENDING in PostgreSQL.
7. When the advisor becomes available again, it automatically receives the same frozen task/context plus the already-completed responses, performs its missed independent/peer-review work, and records its objections or improvements.
8. If a late advisor adds a material objection or new evidence, the council must synthesize the task again as a new revision.
9. Never claim that an advisor participated unless a successful response is actually logged.
10. Future advisors added to the council follow the same workflow.

Important distinction: the mandatory Council workflow is a DEVELOPMENT/RESEARCH/AUDIT workflow. It must not become the runtime trading decision mechanism.

## Mandatory design + implementation review

For any serious file/code/architecture change, council participation begins BEFORE implementation, not after it.

### Before files are created or materially changed
All available advisors must be asked to review the intended design, including:
- which files/modules should exist;
- responsibilities and boundaries of each module;
- what existing code should be reused instead of duplicated;
- database/schema implications;
- failure modes, quota/API/offline behavior and concurrency risks;
- security/secrets boundaries;
- rollback strategy;
- deterministic tests and acceptance criteria;
- what should deliberately NOT be changed.

### After a draft branch/diff exists
The concrete implementation/diff must be given back to the council for implementation review before merge/deploy. Advisors should look for bugs, duplicated logic, hidden coupling, unsafe fallbacks, missing tests and simpler alternatives. Material objections require another revision/review cycle.

This rule also applies to AI Council code itself: the council must review the mechanisms used to coordinate the council.

## AI council roles

- ChatGPT: coordinator and user-facing link. Decomposes goals, compares proposals, exposes disagreements, defines acceptance tests, helps discover new lawful capabilities and returns the combined development/research synthesis to the user.
- Gemini: current sources, grounded web research, news design, economic-event context, new official/open releases and independent project ideas.
- DeepSeek: algorithms, calculations, code proposals, backtesting, mathematical critique, implementation ideas and risk-management ideas.
- Claude: code review, architecture, edge cases, reliability, security audit and open-source/tooling evaluation when configured.
- Grok/xAI: independent challenger, grounded web research when appropriate, coding/agentic architecture, long-context synthesis, contradiction hunting and falsification of proposed ideas.
- Kimi/Perplexity/future advisors: research/verification roles when configured and actually available.
- local-qwen: local Ollama advisor running on the private Railway `ollama` service (no external API, no API key, no per-token cost). Cheap always-available second opinion: sanity checks, obvious contradictions, missing edge cases and short verification questions. A small quantized model, so it is never treated as a research or source-verification advisor.

The local advisor is OFF by default and is controlled by Railway variables only:
`LOCAL_ADVISOR_ENABLED` (default `false`), `OLLAMA_BASE_URL` (default `http://ollama.railway.internal:11434`), `OLLAMA_MODEL` (default `qwen2.5:3b`), `OLLAMA_TIMEOUT_MS` (default `120000`), `OLLAMA_MAX_OUTPUT_TOKENS` (default `512`). It also honours `AI_COUNCIL_DISABLED_ADVISORS` exactly like every other member. When Ollama is unreachable or slow, the call times out, the reason is logged and `local-qwen` is reported as unavailable; the Council quorum is computed from the advisors that did answer.

AI advisors propose knowledge/capabilities and help create/test VIRUS challengers; they do not independently trade or silently change production code.

## Shared near-term roadmap every advisor must know and critique

1. Persistent all-advisor workflow: same task/context, independent round, peer review, PostgreSQL PENDING state, automatic catch-up, re-synthesis after meaningful late feedback.
2. Build the VIRUS continuous learning/absorption pipeline: discover, verify, understand, adapt, test, self-evaluate, promote/reject and monitor lawful new AI/tool/research capabilities.
3. Upgrade News Intelligence into a point-in-time AI-linked evidence layer with canonical events, structured understanding, learned decay/horizon and regime interaction.
4. Maintain a GitHub/research capability registry for new skills/models/tools/updates and test only meaningful nonredundant candidates.
5. Rebuild the book/library map from scratch with a strict preference for high-quality legally free/open/official sources. Re-check old items instead of trusting the manifest.
6. Install and verify final V8 home DEMO worker package; confirm DEMO guard, heartbeat, GOLD# freshness and closed M1 freshness.
7. Observe Impulse Entry Guard V3: one initial basket entry, profitable/progress-gated ADD, no duplicate timeframe slot, no simultaneous BUY+SELL.
8. Continue V4 reversal research: profitable old basket -> close -> verify flat -> only then consider opposite entry. Losing old basket must not be hedged. Compare close-and-flip against exit-and-wait before enabling anything.
9. Improve candidate diagnostics: exact OPEN / WAIT / EXPIRE / CANCEL / BLOCK reasons and stale-confirmation detection.
10. Evaluate official BEA PCE/GDP, selected Treasury and stable PBoC sources; use WGC/LBMA for gold-market-structure context where lawful/stable. No source may affect confidence before validation.
11. Continue Graph Scenario V6 latency/dedup/missing-image monitoring; graphic forecasts are visualization, not evidence.
12. Continue daily/weekend challenger model workflow; champion replacement only after objective chronological/OOS acceptance checks.
13. Kimi remains a possible later advisor subject to API/cost value; any future advisor must join the same workflow and catch up on prior pending tasks.

A fuller roadmap is stored in `AI_COUNCIL_ROADMAP_2026-08-20.md` and should be consulted for major design tasks.

## Standard workflow

1. Receive a user goal.
2. Create one canonical council task with constraints, acceptance criteria and a frozen context snapshot.
3. Run pre-implementation design review across all available advisors.
4. Persist one independent + one peer-review slot per advisor in PostgreSQL.
5. Run all currently available advisors independently.
6. Keep unavailable advisors PENDING rather than failing the whole task.
7. Run peer review across successful independent responses.
8. Produce a provisional synthesis if some advisors are still pending; mark it provisional.
9. Automatically retry pending advisors on the catch-up interval.
10. Re-synthesize when late advisor responses materially expand the evidence set.
11. Only after the council result is clear: prepare code/research changes on a separate Git branch.
12. Send the draft branch/diff back to the council for implementation review.
13. Resolve material objections, then run syntax checks, deterministic tests, historical/OOS/chronological validation and DEMO/shadow validation as appropriate.
14. Review logs and only then deploy/promote.
15. Record result, evidence and rollback plan.

## Research / books rule

- The council should search independently when the provider supports browsing.
- Providers without native web search may propose candidates from their knowledge, but must label legal availability and URLs as UNVERIFIED until another grounded verification step confirms them.
- Prefer official, author, publisher, university, exchange, regulator, standards-body and explicitly open-license sources.
- Pirate mirrors and suspicious copyrighted PDF hosts are forbidden.
- Existing library entries must be re-checked; being in the manifest is not proof of quality or legal availability.
- A book idea never becomes a trading rule merely because multiple AIs like it. Convert it to a measurable hypothesis and test it first.
- The user-supplied Brian Shannon scan is partial and must remain marked PARTIAL until a complete lawful copy is available.

## Current priority

Build and use the persistent all-advisor development/research workflow while transitioning knowledge into ONE VIRUS AI through the continuous learning/absorption pipeline. Prioritize News Intelligence, capability discovery and safe challenger testing. Council opinions must not directly influence BUY/SELL decisions or MT5 execution until proposed trading changes are measured against historical and DEMO results.

## Security

Never place API keys, Telegram tokens, database URLs, MT5 bridge secrets or account credentials in this file, prompts, logs or Git commits. Use Railway variables and redact secrets.

## Required advisor response format

Return JSON or clearly labeled sections:

- summary
- findings
- proposed_changes
- rejected_or_doubtful_ideas
- evidence_and_sources
- risks
- tests
- disagreements
- confidence
