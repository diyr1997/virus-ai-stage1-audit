"use strict";

/**
 * AI COUNCIL FOUNDATION
 * Safe-by-default: advisory only, no trading actions and no production writes.
 */

const fs = require("fs");
const path = require("path");
const { callGrok } = require("./grok-provider");

const CONTEXT_PATH = path.join(__dirname, "AI_COUNCIL_PROJECT_CONTEXT.md");

// ChatGPT is both an autonomous API advisor and the preferred synthesis
// coordinator when OPENAI_API_KEY is configured. All members remain inside
// this one canonical Council; unavailable members never impersonate a quorum.
const COORDINATOR_MEMBER = "chatgpt";
const ALL_ADVISORS = ["chatgpt", "gemini", "deepseek", "claude", "grok", "kimi", "perplexity", "local-qwen"];
const ALL_COUNCIL_MEMBERS = [...new Set([COORDINATOR_MEMBER, ...ALL_ADVISORS])];

function parseDisabledAdvisors(raw = process.env.AI_COUNCIL_DISABLED_ADVISORS || "") {
  const allowed = new Set(ALL_ADVISORS);
  return [...new Set(
    String(raw || "")
      .split(/[,;\s]+/)
      .map((value) => value.trim().toLowerCase())
      .filter((value) => allowed.has(value))
  )];
}

const DISABLED_ADVISORS = parseDisabledAdvisors();
const DISABLED_ADVISOR_SET = new Set(DISABLED_ADVISORS);
const ADVISORS = ALL_ADVISORS.filter((advisor) => !DISABLED_ADVISOR_SET.has(advisor));

function advisorDisabled(advisor) {
  return DISABLED_ADVISOR_SET.has(String(advisor || "").trim().toLowerCase());
}

function loadProjectContext() {
  try {
    return fs.readFileSync(CONTEXT_PATH, "utf8");
  } catch {
    return "Project context is unavailable. Ask the coordinator for the current project constraints.";
  }
}

const ROLES = {
  chatgpt: "Primary autonomous Council coordinator and independent reviewer. Preserve the user's intent, reason independently, reconcile disagreements, define tests, and remain fail-closed on unsupported claims or unsafe actions.",
  gemini: "Focus on current sources, news design, economic events and independent product ideas.",
  deepseek: "Focus on algorithms, calculations, code proposals, backtesting and risk management.",
  claude: "Focus on code review, architecture, edge cases, reliability and security.",
  grok: "Act as an independent challenger. Focus on coding and agentic architecture, long-context synthesis, contradictions between advisors, missing assumptions, alternative hypotheses and ways to falsify proposed trading ideas before implementation.",
  kimi: "Focus on long-context review, research synthesis, alternative implementations, consistency checks and missing assumptions.",
  perplexity: "Focus on fresh-source research, current macro/news discovery, source citations, contradictory-source detection, and independent verification of time-sensitive claims. Never convert research into a direct trade command.",
  "local-qwen": "Local Ollama advisor (small quantized model, no external API). Focus on cheap always-available second opinions: sanity checks, obvious contradictions, missing edge cases and short verification questions. Keep answers short, never claim access to fresh sources or executed tools.",
  coordinator: "Reconcile proposals, identify disagreements, define tests and produce one safe implementation plan.",
};

function buildAdvisorPrompt({ task, advisor, previousResponses = [] }) {
  const role = ROLES[advisor] || ROLES.coordinator;
  const peerReview = previousResponses.length
    ? `\n\nOther advisors' proposals to review:\n${JSON.stringify(previousResponses, null, 2)}`
    : "";

  return `You are part of the XAU/USD AI Council.\n\nPROJECT CONTEXT:\n${loadProjectContext()}\n\nYOUR ROLE:\n${role}\n\nTASK:\n${task}${peerReview}\n\nReturn clearly labeled sections: summary, proposed_changes, affected_files, expected_benefit, risks, tests, rollback, questions_or_unknowns. Do not trade, expose secrets, or silently modify production.`;
}

function normalizeResponse(provider, text) {
  return {
    provider,
    received_at: new Date().toISOString(),
    response: String(text || "").trim(),
  };
}

async function callAdvisor(callProvider, advisor, prompt) {
  if (advisor === "grok") return callGrok(prompt);
  return callProvider(advisor, prompt);
}

/**
 * Provider adapters are injected by the caller when configured. Grok uses its
 * dedicated xAI adapter. Credentials remain in Railway variables and are never
 * written to GitHub or logs.
 */
async function runCouncil({ task, callProvider }) {
  if (!task || typeof callProvider !== "function") {
    throw new Error("task and callProvider are required");
  }

  const firstRound = [];
  for (const advisor of ADVISORS) {
    const text = await callAdvisor(
      callProvider,
      advisor,
      buildAdvisorPrompt({ task, advisor })
    );
    firstRound.push(normalizeResponse(advisor, text));
  }

  const review = [];
  for (const advisor of ADVISORS) {
    const text = await callAdvisor(
      callProvider,
      advisor,
      buildAdvisorPrompt({
        task,
        advisor,
        previousResponses: firstRound,
      })
    );
    review.push(normalizeResponse(advisor, text));
  }

  const coordinatorPrompt = buildAdvisorPrompt({
    task,
    advisor: "coordinator",
    previousResponses: [...firstRound, ...review],
  });

  const coordinator = ADVISORS.includes(COORDINATOR_MEMBER)
    ? COORDINATOR_MEMBER
    : ADVISORS[0];
  if (!coordinator) {
    throw new Error("No active AI Council advisors");
  }
  const finalPlan = await callProvider(coordinator, coordinatorPrompt);

  return {
    task,
    coordinator_member: COORDINATOR_MEMBER,
    council_members: ALL_COUNCIL_MEMBERS,
    advisors: ADVISORS,
    disabled_advisors: DISABLED_ADVISORS,
    first_round: firstRound,
    review_round: review,
    final_plan: normalizeResponse(coordinator, finalPlan),
    advisory_only: true,
    production_changed: false,
  };
}

module.exports = {
  COORDINATOR_MEMBER,
  ALL_COUNCIL_MEMBERS,
  ALL_ADVISORS,
  ADVISORS,
  DISABLED_ADVISORS,
  advisorDisabled,
  parseDisabledAdvisors,
  ROLES,
  loadProjectContext,
  buildAdvisorPrompt,
  runCouncil,
};