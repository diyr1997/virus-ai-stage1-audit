# XAU/USD AI Council — Shared Roadmap

Updated: 2026-08-20

Purpose: every advisor must see not only the current task but also what the project recently changed, what is intentionally not live yet, and what is planned next. This roadmap is context, not permission to modify production.

## Recently changed / prepared

### AI Council
- Grok/xAI provider was added to the council code and is intended to participate as an independent challenger.
- Railway variables include the xAI API key/model, but the cloud deployment containing the newest council code must be verified before claiming Grok is live.
- DeepSeek previously completed an independent book-discovery run; its results are evidence/input, not a final curriculum.
- Gemini remains useful for grounded/current research but may hit quota/rate limits.
- Persistent all-advisor task/catch-up workflow is being prepared so unavailable advisors do not silently disappear from a decision.

### DEMO worker / entries
- Impulse Entry Guard V3 is prepared for the home-worker package.
- One first entry per global XAU/GOLD basket; later same-direction positions are ADDs, not fresh initial slots.
- ADD requires profitable basket + favorable price progress.
- New timeframe/candidate must not reset symbol-level entry logic.
- Simultaneous bot BUY and SELL is blocked.
- Direction is rechecked immediately before order_send().
- These local-worker changes still require installation/verification on the home laptop before they can be considered active.

### Research / Trading School
- Existing book/source manifest mixes truly free/open material with paid/user-copy-only books.
- A fresh whole-council literature refresh is required with a stricter rule: prioritize high-quality legally free/open/official sources and explicitly classify paid/user-copy-only sources.
- Existing School features and regime ideas are not promoted merely for looking stronger; failed chronological/OOS tests remain rejected.

## Near-term roadmap — all advisors should critique this

1. **Persistent all-advisor workflow**
   - Same task + same frozen context for all configured advisors.
   - Independent round, then peer-review round.
   - Missing/quota-failed providers remain PENDING in PostgreSQL.
   - Automatic catch-up after provider recovery.
   - Re-synthesis when a late advisor adds material evidence or objections.
   - Before major implementation: council design review.
   - After draft code/diff: council implementation review before merge/deploy.

2. **Book/library rebuild from scratch**
   - Independently search legal/free/open books, official manuals, university notes/courses and research collections.
   - Cover gold market structure, microstructure/execution, TA, intraday momentum/reversal/regimes, algo/systematic research, statistics/time-series, financial ML, risk and MT5 engineering.
   - Re-check every existing library item: KEEP / DOWNGRADE / REPLACE / WAITING_USER_COPY / REJECT.
   - Convert useful concepts to measurable XAU/USD hypotheses instead of copying rules.
   - Preserve Brian Shannon current scan as PARTIAL until complete lawful copy is available.

3. **Worker V8 home installation and DEMO verification**
   - Install final consolidated worker package on the home laptop.
   - Verify DEMO-only guard, heartbeat, GOLD# quote freshness and closed M1 freshness.
   - Observe V3: one initial entry, profitable progress-gated ADD, no duplicate TF slot, no hedge.

4. **Reversal / close-and-flip research (V4 candidate)**
   - Desired behavior: if a genuine opposite M1/M5 impulse appears and current basket is profitable, close old side, verify flat, then consider opposite entry.
   - If old basket is losing, do not open the opposite side; leave risk management to current SL/TP.
   - Do not enable until reversal detection is robust across chronological blocks and DEMO/shadow evidence.
   - Council should actively challenge whether close-and-flip is better than simply exit-and-wait.

5. **Candidate diagnostics and confirmation**
   - Log exact reason for OPEN / WAIT / EXPIRE / CANCEL / BLOCK.
   - Improve detection of stale confirmation context.
   - Re-evaluate confirmation and invalidation rules without weakening safety merely to create more trades.

6. **News engine improvements**
   - Evaluate official BEA PCE/GDP sources.
   - Evaluate carefully selected U.S. Treasury sources.
   - Evaluate stable PBoC official reserve/policy sources.
   - Use WGC/LBMA as gold-market-structure context where lawful and technically stable.
   - Every source must pass freshness, relevance, duplicate/corroboration, preview-vs-release and no-trade-window tests before affecting signal confidence.

7. **Graph Scenario V6 monitoring**
   - Continue latency, deduplication and missing-image monitoring.
   - Forecast graphic remains visualization, never evidence by itself.

8. **Model/training workflow**
   - Continue daily short learning and deeper weekend challenger training when infrastructure is ready.
   - Challenger may replace champion only after objective chronological/OOS acceptance checks.
   - No AI opinion alone can promote a model.

9. **Future AI additions**
   - Kimi remains a candidate for later, subject to cost/API value evaluation.
   - Any new advisor must join the same independent -> peer review -> catch-up workflow, not become a privileged decision maker.

## Mandatory design-review rule

Before creating or materially changing project architecture/files for a serious task, the council should be asked:
- what files/modules should exist;
- what responsibilities belong in each file;
- what existing code should be reused instead of duplicated;
- failure modes and rollback;
- how to test the implementation;
- what should deliberately NOT be changed.

After a draft branch/diff exists, the council should review the concrete implementation before merge/deploy. Material objections require another revision/review cycle.

## Non-negotiable constraints
- DEMO only for automatic trading.
- No self-hedging BUY+SELL for the bot.
- No copyrighted commercial book text committed to GitHub.
- No strategy/model/news-source promotion without measured validation.
- Never pretend an unavailable advisor participated.
- Never mix cloud Bot #1 state with local MT5 Bot #2 state.
