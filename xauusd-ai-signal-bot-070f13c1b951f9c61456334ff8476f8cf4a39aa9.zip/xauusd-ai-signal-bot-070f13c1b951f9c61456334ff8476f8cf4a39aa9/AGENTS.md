# VIRUS AI — mandatory agent operating contract

This file is the common task-execution contract for every AI Council member and every engineering/research agent working on this repository.

Before planning, reviewing, editing, testing, or claiming completion, read in this order:

1. `AI_COUNCIL_PROJECT_CONTEXT.md` — canonical project/safety context.
2. `AI_AGENT_TOOLBOX_STATUS.md` — evidence-based status of existing GitHub tools; cloned/starred is not the same as active.
3. `tools/ai_toolbox/SHARED_COUNCIL_TOOLS.json` — one shared Council tool registry, including Google Drive discovery candidates.
4. The exact files/evidence relevant to the assigned task.

## Mandatory task procedure

For every non-trivial task:

1. State the exact goal, constraints, and what would count as success.
2. Reuse existing project code/tools before proposing new dependencies or duplicate modules.
3. Apply the Ponytail/minimal-change discipline: make the smallest correct change that preserves validation, security, error handling, observability and rollback.
4. Separate VERIFIED facts, measured results, hypotheses, opinions and unavailable evidence.
5. Explain why each material change/tool is needed and what simpler alternatives were rejected.
6. Define executable checks/tests before claiming completion; run them when the execution environment permits.
7. Never claim that a tool, advisor, test, deployment, dataset or runtime is working unless current evidence proves it.
8. Record blockers explicitly instead of fabricating a PASS.
9. For code/architecture changes, perform Council design review first and Council review of the concrete diff/evidence before promotion.
10. Return enough provenance that another Council member can reproduce or challenge the result.

## Shared-tool rule

- ChatGPT, DeepSeek and Claude use ONE shared GitHub-derived tool registry. Do not create provider-specific tool catalogs, independent Councils, or separate truth stores.
- Visibility in the shared registry means a tool is known to the Council; it does NOT mean the provider API natively owns or can directly invoke that tool.
- Actual execution of external tools must happen through the authorized shared project runtime / isolated toolbox executor with least privilege. Advisors may request a tool by canonical registry name; they must not pretend they executed it if no execution evidence was returned.
- `AI_AGENT_TOOLBOX_STATUS.md` is authoritative for current install/test status until newer evidence replaces it.

## Mandatory external-tool gate

NVIDIA SkillSpector is the mandatory security preflight for new external AI skills/MCP payloads.

For every new GitHub/Drive candidate:

`DISCOVER -> RESOLVE EXACT UPSTREAM/VERSION -> LICENSE CHECK -> SKILLSPECTOR/SECURITY CHECK (when skill/MCP payload exists) -> ISOLATED INSTALL -> SMOKE/PARITY TEST -> COUNCIL REVIEW -> ADOPT / WATCH / REJECT`

- A failed security gate is not silently bypassed.
- A missing exact upstream, license, credential, hardware requirement or runtime dependency is an explicit blocker.
- Third-party tools execute only in isolated development/audit environments until separately promoted after evidence-based review.
- Never inject production broker/MT5/Telegram/database secrets into third-party tools by default.

## Non-negotiable safety rules

- REAL trading remains disabled. Do not weaken or remove DEMO/fail-closed guards.
- Unknown state, stale data, missing costs, missing ownership/fencing, leakage risk or failed verification means WAIT / NO TRADE where trading safety is involved.
- Never invent backtest metrics, runtime status, test results, URLs, licensing facts, data availability or profitability.
- Preserve point-in-time/as-of integrity and Research -> Challenger -> Validation -> DEMO/Shadow -> Champion separation.
- Never expose secrets in prompts, logs, reports or commits.
- Make surgical changes; do not refactor unrelated code.

## Council relationship

The AI Council is a development/research/audit system, not the live trading decision engine. External advisors and external tools provide evidence, critiques and implementation assistance to the single VIRUS AI project; they do not become separate live-trading brains or independent BUY/SELL voters.
