"use strict";

// ======================================================
// XAU/USD GLOBAL NEWS ENGINE V14
// CLEAN V4 compatible
//
// Цель:
// - быстрые новости для M1/M5/M15/M30/H1;
// - США + Китай + Япония + Европа + UK;
// - Ближний Восток + Африка + Латинская Америка + Азия;
// - физическое золото / резервы центробанков / доллар / yields;
// - системная крипта только при реальной связи с XAU/USD;
// - CFTC здесь НЕ смешивается: CFTC остаётся отдельно в cftc.js.
// ======================================================

// Core news snapshot is a 5-minute safety/fallback cycle. Fast, push-capable
// sources are handled by fast-news-watcher-v2.js; this engine must not hammer
// RSS/search/translation endpoints on every analysis tick.
const CACHE_MS = Math.max(
  5 * 60_000,
  Number(process.env.NEWS_CACHE_MS || 5 * 60_000)
);

const TRANSLATE_LIMIT = Math.max(
  0,
  Math.min(12, Number(process.env.NEWS_TRANSLATE_LIMIT || 8))
);
const TRANSLATE_GAP_MS = Math.max(
  250,
  Number(process.env.NEWS_TRANSLATE_GAP_MS || 750)
);
const TRANSLATE_BACKOFF_MS = Math.max(
  5 * 60_000,
  Number(process.env.NEWS_TRANSLATE_BACKOFF_MS || 6 * 60 * 60_000)
);

const ENABLE_GDELT =
  String(process.env.ENABLE_GDELT_NEWS || "true").toLowerCase() !== "false";

const CANONICAL_TIMEZONE = "UTC";
const USER_TIMEZONE =
  process.env.USER_TIMEZONE || "Asia/Tashkent";
const NEWS_FUTURE_TOLERANCE_MS = Math.max(
  30_000,
  Number(process.env.NEWS_FUTURE_TOLERANCE_MS || 2 * 60_000)
);

const GDELT_URL = "https://api.gdeltproject.org/api/v2/doc/doc";

function envMilliseconds(name, fallback, minimum) {
  const parsed = Number(process.env[name]);
  return Number.isFinite(parsed) ? Math.max(minimum, parsed) : fallback;
}

const GDELT_CACHE_MS = envMilliseconds(
  "GDELT_CACHE_MS",
  30 * 60_000,
  10 * 60_000
);
const GDELT_GAP_MS = envMilliseconds(
  "GDELT_GAP_MS",
  8_000,
  6_000
);
const GDELT_FAILURE_BACKOFF_MS = envMilliseconds(
  "GDELT_FAILURE_BACKOFF_MS",
  30 * 60_000,
  5 * 60_000
);
const GDELT_RATE_LIMIT_BACKOFF_MS = envMilliseconds(
  "GDELT_RATE_LIMIT_BACKOFF_MS",
  60 * 60_000,
  15 * 60_000
);

const OFFICIAL_SOURCES = [
  {
    name: "Federal Reserve — Monetary Policy",
    url: "https://www.federalreserve.gov/feeds/press_monetary.xml",
    region: "USA",
    baseImpact: 88,
    official: true,
  },
  {
    name: "Federal Reserve — Speeches & Testimony",
    url: "https://www.federalreserve.gov/feeds/speeches_and_testimony.xml",
    region: "USA",
    baseImpact: 72,
    official: true,
  },
  {
    name: "BLS — CPI",
    url: "https://www.bls.gov/feed/cpi.rss",
    region: "USA",
    baseImpact: 94,
    official: true,
  },
  {
    name: "BLS — Employment / NFP",
    url: "https://www.bls.gov/feed/empsit.rss",
    region: "USA",
    baseImpact: 96,
    official: true,
  },
  {
    name: "BLS — JOLTS",
    url: "https://www.bls.gov/feed/jolts.rss",
    region: "USA",
    baseImpact: 78,
    official: true,
  },
  {
    name: "European Central Bank",
    url: "https://www.ecb.europa.eu/rss/press.html",
    region: "EUROPE",
    baseImpact: 72,
    official: true,
  },
  {
    name: "Bank of England — News",
    url: "https://www.bankofengland.co.uk/rss/news",
    region: "UK",
    baseImpact: 68,
    official: true,
  },
  {
    name: "Bank of England — Speeches",
    url: "https://www.bankofengland.co.uk/rss/speeches",
    region: "UK",
    baseImpact: 62,
    official: true,
  },
  {
    name: "Bank of Japan",
    url: "https://www.boj.or.jp/en/rss/whatsnew.xml",
    region: "JAPAN",
    baseImpact: 70,
    official: true,
  },
];

const GOOGLE_NEWS_QUERIES = [
  {
    name: "gold_market",
    region: "GLOBAL",
    q: '"gold price" OR bullion OR XAUUSD OR "spot gold" OR "gold futures" OR "gold demand" OR "gold supply"',
  },
  {
    name: "usa_macro",
    region: "USA",
    q: '"Federal Reserve" OR FOMC OR "consumer price index" OR CPI OR "nonfarm payrolls" OR NFP OR PCE OR "Treasury yields" OR DXY',
  },
  {
    name: "china",
    region: "CHINA",
    q: 'PBOC OR "People\'s Bank of China" OR yuan OR renminbi OR "China gold reserves" OR "China central bank gold" OR "China economy"',
  },
  {
    name: "japan",
    region: "JAPAN",
    q: '"Bank of Japan" OR BOJ OR yen OR "Japan inflation" OR "Japan interest rates" OR "Japan monetary policy"',
  },
  {
    name: "europe",
    region: "EUROPE",
    q: '"European Central Bank" OR ECB OR "euro area inflation" OR "eurozone inflation" OR "ECB rates"',
  },
  {
    name: "uk",
    region: "UK",
    q: '"Bank of England" OR BOE OR "UK inflation" OR "UK interest rates" OR sterling',
  },
  {
    name: "middle_east",
    region: "MIDDLE_EAST",
    q: '(Iran OR Israel OR Gaza OR Yemen OR "Red Sea" OR Saudi OR "Strait of Hormuz") (sanctions OR missile OR attack OR ceasefire OR oil OR "risk off" OR gold)',
  },
  {
    name: "africa",
    region: "AFRICA",
    q: '("South Africa" OR Ghana OR Mali OR "Burkina Faso" OR Sudan) ("gold mine" OR "gold production" OR "gold exports" OR sanctions OR "political crisis")',
  },
  {
    name: "latam",
    region: "LATAM",
    q: '(Brazil OR Mexico OR Argentina OR Peru OR Chile) ("central bank" OR "gold reserves" OR currency OR inflation OR "interest rates" OR crisis)',
  },
  {
    name: "asia_gold",
    region: "ASIA",
    q: '(India OR RBI OR "Reserve Bank of India" OR Singapore OR Korea) ("gold demand" OR "gold imports" OR "gold reserves" OR currency OR "interest rates")',
  },
  {
    name: "central_bank_gold",
    region: "GLOBAL",
    q: '"central bank gold" OR "central banks buy gold" OR "official gold reserves" OR "gold reserve purchases"',
  },
  {
    name: "geopolitics",
    region: "GLOBAL",
    q: '(sanctions OR tariffs OR "trade war" OR geopolitical OR "banking crisis" OR "financial crisis" OR ceasefire) (gold OR dollar OR yields OR oil)',
  },
  {
    name: "systemic_crypto",
    region: "GLOBAL",
    q: '(Tether OR USDT OR Bitcoin OR crypto) (gold OR reserves OR liquidity OR "banking stress" OR "risk off" OR "Treasury yields" OR "Federal Reserve")',
  },
];

const GDELT_QUERIES = [
  {
    name: "gold",
    query: '("gold price" OR bullion OR XAUUSD OR "gold futures")',
  },
  {
    name: "macro_asia",
    query: '(PBOC OR "Bank of Japan" OR yuan OR yen OR "central bank gold")',
  },
  {
    name: "geopolitics",
    query: '(sanctions OR ceasefire OR tariffs OR "banking crisis" OR "missile attack") AND (gold OR dollar OR oil)',
  },
];

// ------------------------------------------------------
// KEYWORDS / FILTERS
// ------------------------------------------------------

const TERMS = {
  gold: [
    "gold price",
    "spot gold",
    "gold futures",
    "bullion",
    "xauusd",
    "precious metals",
    "gold market",
    "gold demand",
    "gold supply",
    "gold rally",
    "gold selloff",
  ],

  fed: [
    "federal reserve",
    "fomc",
    "fed chair",
    "fed governor",
    "powell",
  ],

  cpi: [
    "consumer price index",
    "consumer prices",
    "u.s. cpi",
    "us cpi",
    "core cpi",
    "headline cpi",
  ],

  nfp: [
    "nonfarm payroll",
    "non-farm payroll",
    "employment situation",
    "jobs report",
    "payrolls",
  ],

  pce: [
    "personal consumption expenditures",
    "pce inflation",
    "pce price index",
    "core pce",
  ],

  labor: [
    "jolts",
    "job openings",
    "jobless claims",
    "unemployment",
    "labor market",
    "labour market",
  ],

  rates: [
    "interest rate",
    "rate cut",
    "rate cuts",
    "rate hike",
    "rate hikes",
    "monetary policy",
    "policy rate",
    "dovish",
    "hawkish",
  ],

  yields: [
    "treasury yield",
    "treasury yields",
    "10-year treasury",
    "2-year treasury",
    "bond yield",
    "bond yields",
  ],

  usd: [
    "dollar index",
    " dxy ",
    "u.s. dollar",
    "us dollar",
    "greenback",
    "dollar weakens",
    "dollar strengthens",
    "weaker dollar",
    "stronger dollar",
  ],

  china: [
    "china",
    "pboc",
    "people's bank of china",
    "people s bank of china",
    "yuan",
    "renminbi",
    "beijing",
  ],

  japan: [
    "japan",
    "bank of japan",
    " boj ",
    "yen",
    "tokyo",
  ],

  europe: [
    "european central bank",
    " ecb ",
    "eurozone",
    "euro area",
  ],

  uk: [
    "bank of england",
    " boe ",
    "united kingdom",
    "britain",
    "sterling",
  ],

  reserves: [
    "gold reserves",
    "official gold reserves",
    "central bank gold",
    "central bank buying",
    "central banks buy gold",
    "gold purchases",
    "gold reserve purchases",
    "gold etf inflows",
    "gold etf outflows",
  ],

  geo: [
    "sanctions",
    "missile attack",
    "military attack",
    "airstrike",
    "war escalation",
    "ceasefire",
    "peace deal",
    "trade war",
    "tariff",
    "tariffs",
    "geopolitical",
    "banking crisis",
    "financial crisis",
    "sovereign default",
    "invasion",
    "red sea",
    "strait of hormuz",
  ],

  mining: [
    "mine closure",
    "mine shutdown",
    "production halt",
    "production cut",
    "gold output",
    "gold production",
    "gold export",
    "gold exports",
    "supply disruption",
    "export ban",
    "mine strike",
    "refinery shutdown",
  ],

  crypto: [
    "bitcoin",
    "btc",
    "ethereum",
    "crypto",
    "cryptocurrency",
    "stablecoin",
    "tether",
    "usdt",
    "usdc",
  ],
};

const CRYPTO_BRIDGE = [
  "gold",
  "gold reserves",
  "federal reserve",
  "interest rate",
  "treasury yields",
  "liquidity",
  "liquidity crunch",
  "banking stress",
  "banking crisis",
  "financial stability",
  "risk-off",
  "risk off",
  "systemic risk",
  "market contagion",
  "liquidations",
  "market crash",
  "market selloff",
];

const CRYPTO_NOISE = [
  "presale",
  "pre-sale",
  "memecoin",
  "meme coin",
  "airdrop",
  "token listing",
  "new token",
  "token launch",
  "ico",
  "staking rewards",
  "yield farming",
  "price prediction",
  "100x",
  "1000x",
  "altcoin gem",
  "moonshot",
];

const HARD_NOISE = [
  /gold medal|won gold|wins gold|olympic gold|championship|swimming|football|boxing|wrestling|cycling|horse racing/i,
  /record label|gold records|single|album|artist|singer|rapper|song|music video|concert/i,
  /collectible coin|replica coin|coin design|buy now|shop now/i,
  /retirement savings|pension savings|credit card|mortgage rate|personal finance/i,
  /communist party of india|cpi\(m\)|\bcpi\b.*assembly/i,
];

const RETAIL_NOISE = [
  /gold rate today|today gold rate|gold price today in|price of gold today in/i,
  /\b18\s?k\b|\b22\s?k\b|\b24\s?k\b|18[- ]?karat|22[- ]?karat|24[- ]?karat/i,
  /per tola|per gram|per 10 grams?|jewel+l?ery|making charges|hallmark gold/i,
  /gold rate.*(delhi|mumbai|chennai|bengaluru|bangalore|hyderabad|kolkata|lahore|karachi)/i,
];

const TECHNICAL_NOISE = [
  /tradingview|linkedin|oanda:xauusd|breakoutalerts?/i,
  /technical analysis|technical outlook|trading setup|support and resistance|support level|resistance level/i,
  /price target|gold price forecast|gold forecast|price prediction|chart pattern|stop loss|take profit/i,
];

const OPINION_NOISE = [
  /opinion|commentary|editorial|column:/i,
  /analyst says|strategist says|economist explains|what investors should know/i,
  /why .* could|why .* may|what it means for|here'?s why/i,
];

const HISTORY_NOISE = [
  /over the past \d+ years?|in the last \d+ years?|over \d+ years?|for \d+ years?/i,
  /historical performance|history shows|decades? of/i,
];

const PREVIEW_PATTERNS = [
  /ahead of|preview|what to expect|markets await|investors await|awaiting/i,
  /scheduled|will be released|set to be released|coming week|expected later/i,
];

const RECAP_PATTERNS = [
  /last week|earlier this week|week in review|weekly recap/i,
  /after (the )?.{0,35}(report|data|release|cpi|nonfarm|payroll|pce)/i,
  /following (the )?.{0,35}(report|data|release|cpi|nonfarm|payroll|pce)/i,
];

const LIVE_PATTERNS = [
  /breaking|just released|unexpectedly|announces?|imposes?|orders?/i,
  /beats? expectations|misses? expectations|comes? in above|comes? in below/i,
  /cuts? rates?|raises? rates?|sanctions?.*announced|tariffs?.*announced/i,
  /ceasefire.*agreed|ceasefire.*reached|banking crisis|market crash|market selloff/i,
];

const translationCache = new Map();
const loggedNewsErrors = new WeakSet();
const officialFeedState = new Map();
let translationNextAttemptAt = 0;
let snapshotCache = [];
let snapshotUpdatedAt = 0;

let gdeltCache = [];
let gdeltUpdatedAt = 0;
let gdeltUpdating = false;
let lastGdeltAt = 0;
let gdeltNextAttemptAt = 0;

// ------------------------------------------------------
// BASIC HELPERS
// ------------------------------------------------------

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function normalizeSpaces(value = "") {
  return String(value).replace(/\s+/g, " ").trim();
}

function decodeEntities(value = "") {
  return String(value)
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">");
}

function stripHtml(value = "") {
  return normalizeSpaces(
    decodeEntities(value).replace(/<[^>]*>/g, " ")
  );
}

function extractTag(block, tag) {
  const match = block.match(
    new RegExp(`<${tag}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${tag}>`, "i")
  );

  return match ? stripHtml(match[1]) : "";
}

function extractLink(block) {
  const direct = extractTag(block, "link");
  if (direct) return direct;

  const match = block.match(/<link[^>]+href=["']([^"']+)["'][^>]*>/i);
  return match ? decodeEntities(match[1]).trim() : "";
}

function parseDate(value) {
  const t = Date.parse(value || "");
  return Number.isFinite(t) ? t : 0;
}

function parseGdeltDate(value) {
  if (!value) return 0;

  if (typeof value === "number") {
    return value < 10_000_000_000 ? value * 1000 : value;
  }

  const text = String(value).trim();
  const compact = text.match(
    /^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})Z?$/
  );

  if (compact) {
    return Date.parse(
      `${compact[1]}-${compact[2]}-${compact[3]}T${compact[4]}:${compact[5]}:${compact[6]}Z`
    );
  }

  return parseDate(text);
}

function containsAny(text, words) {
  return words.some((word) => text.includes(word));
}

function matchesAny(text, patterns) {
  return patterns.some((pattern) => pattern.test(text));
}

function clamp100(value) {
  return Math.max(0, Math.min(100, Math.round(Number(value) || 0)));
}

function looksRussian(text = "") {
  const value = String(text || "");
  const cyr = (value.match(/[А-Яа-яЁё]/g) || []).length;
  const lat = (value.match(/[A-Za-z]/g) || []).length;
  return cyr > 0 && cyr >= lat;
}

// ------------------------------------------------------
// SOURCE / REGION / TOPIC
// ------------------------------------------------------

function sourceQuality(source = "", url = "", official = false) {
  if (official) return 1.0;

  const value = `${source} ${url}`.toLowerCase();

  if (
    /reuters|associated press|apnews|bloomberg|financial times|ft\.com|wall street journal|wsj|cnbc/.test(
      value
    )
  ) {
    return 0.95;
  }

  if (
    /kitco|fxstreet|investing\.com|marketwatch|yahoo finance|barron|fortune|business insider|economist/.test(
      value
    )
  ) {
    return 0.82;
  }

  if (
    /forexlive|investinglive|businessline|gold eagle|kalkine|aol|goodreturns/.test(
      value
    )
  ) {
    return 0.60;
  }

  if (/tradingview|linkedin|openpr|futubull|moomoo/.test(value)) {
    return 0.25;
  }

  return 0.58;
}

function detectRegion(text = "", preset = "") {
  if (preset && preset !== "GLOBAL") return preset;

  const lower = text.toLowerCase();

  if (/china|pboc|beijing|yuan|renminbi/.test(lower)) return "CHINA";
  if (/bank of japan|japan|tokyo|yen/.test(lower)) return "JAPAN";
  if (/ecb|eurozone|euro area|european central bank/.test(lower))
    return "EUROPE";
  if (/bank of england|britain|british|united kingdom|sterling/.test(lower))
    return "UK";
  if (
    /iran|israel|gaza|saudi|uae|qatar|yemen|red sea|middle east|hormuz/.test(
      lower
    )
  )
    return "MIDDLE_EAST";
  if (
    /south africa|ghana|mali|burkina|sudan|africa|african gold/.test(lower)
  )
    return "AFRICA";
  if (/brazil|argentina|mexico|peru|chile|latin america/.test(lower))
    return "LATAM";
  if (/india|reserve bank of india|\brbi\b|singapore|south korea|korea/.test(lower))
    return "ASIA";
  if (
    /federal reserve|fomc|treasury yield|united states|u\.s\.|\busa\b|dollar index/.test(
      lower
    )
  )
    return "USA";

  return preset || "GLOBAL";
}

function detectTopics(text = "") {
  const lower = ` ${text.toLowerCase()} `;

  const crypto = containsAny(lower, TERMS.crypto);

  const cpi =
    !/communist party of india|assembly|cpi\(m\)/i.test(lower) &&
    (containsAny(lower, TERMS.cpi) ||
      (/\bcpi\b/i.test(lower) &&
        /inflation|consumer prices|federal reserve|\bfed\b|bls|u\.s\.|united states/i.test(
          lower
        )));

  const topics = {
    gold: containsAny(lower, TERMS.gold),
    fed: containsAny(lower, TERMS.fed),
    cpi,
    nfp: containsAny(lower, TERMS.nfp),
    pce: containsAny(lower, TERMS.pce),
    labor: containsAny(lower, TERMS.labor),
    rates: containsAny(lower, TERMS.rates),
    yields: containsAny(lower, TERMS.yields),
    usd: containsAny(lower, TERMS.usd),
    china: containsAny(lower, TERMS.china),
    japan: containsAny(lower, TERMS.japan),
    europe: containsAny(lower, TERMS.europe),
    uk: containsAny(lower, TERMS.uk),
    reserves: containsAny(lower, TERMS.reserves),
    geo: containsAny(lower, TERMS.geo),
    mining: containsAny(lower, TERMS.mining),
    crypto,
    cryptoSystemic: crypto && containsAny(lower, CRYPTO_BRIDGE),
  };

  topics.centralBank =
    topics.fed ||
    topics.china ||
    topics.japan ||
    topics.europe ||
    topics.uk;

  topics.macro =
    topics.fed ||
    topics.cpi ||
    topics.nfp ||
    topics.pce ||
    topics.labor ||
    topics.rates ||
    topics.yields ||
    topics.usd ||
    topics.centralBank;

  return topics;
}

function relevanceReason(topics, region) {
  if (topics.cpi) return "Инфляция США / CPI";
  if (topics.nfp) return "Рынок труда США / NFP";
  if (topics.pce) return "Инфляция США / PCE";
  if (topics.labor) return "Рынок труда / занятость";
  if (topics.fed && topics.rates) return "ФРС / процентные ставки";
  if (topics.fed) return "ФРС / денежная политика";
  if (topics.yields) return "Доходности облигаций";
  if (topics.usd) return "Доллар США";
  if (topics.reserves) return "Покупки / резервы золота";
  if (topics.china) return "Китай / PBOC / юань";
  if (topics.japan) return "Япония / BOJ / иена";
  if (topics.europe) return "ЕЦБ / экономика еврозоны";
  if (topics.uk) return "Bank of England / фунт";
  if (topics.geo) return "Геополитический риск";
  if (topics.mining) return "Добыча / поставки золота";
  if (topics.cryptoSystemic)
    return "Системная крипта / ликвидность / финансовый риск";
  if (topics.gold) return "Мировой рынок золота";
  if (region === "AFRICA") return "Африка / золотодобыча / политический риск";
  if (region === "LATAM") return "Латинская Америка / валюты / центробанки";
  if (region === "MIDDLE_EAST") return "Ближний Восток / геополитический риск";
  return "Макроэкономический фон для XAU/USD";
}

// ------------------------------------------------------
// DIRECTION / IMPACT / CLASSIFICATION
// ------------------------------------------------------

function detectGoldDirection(text, topics) {
  if (
    /(gold|bullion).{0,55}(rose|rises|rise|gained|gains|jumped|surged|climbed|rebounded)/i.test(
      text
    )
  )
    return "UP";

  if (
    /(gold|bullion).{0,55}(fell|falls|fall|dropped|drops|slipped|plunged|declined)/i.test(
      text
    )
  )
    return "DOWN";

  if (
    /yields?.{0,35}(fall|drop|slip|ease|decline)/i.test(text) ||
    /dollar.{0,35}(fall|drop|weaken|slip|decline)/i.test(text)
  )
    return "UP";

  if (
    /yields?.{0,35}(rise|jump|climb|surge)/i.test(text) ||
    /dollar.{0,35}(rise|jump|strengthen|climb|surge)/i.test(text)
  )
    return "DOWN";

  if (
    /(war|attack|airstrike|missile|invasion).{0,45}(escalat|intensif|expand)/i.test(
      text
    )
  )
    return "UP";

  if (/(ceasefire|peace deal|truce).{0,40}(agree|signed|reached|holds)/i.test(text))
    return "DOWN";

  if (
    /central bank.{0,55}(buy|buys|bought|purchase|purchases|adds).{0,30}gold/i.test(
      text
    )
  )
    return "UP";

  if (
    /(rate cut|cuts rates|dovish)/i.test(text) &&
    (topics.fed || topics.rates || topics.centralBank)
  )
    return "UP";

  if (
    /(rate hike|raises rates|hawkish)/i.test(text) &&
    (topics.fed || topics.rates || topics.centralBank)
  )
    return "DOWN";

  if (
    /(yuan|renminbi).{0,35}(weakens|falls|drops|depreciates)/i.test(text) &&
    topics.china
  )
    return "UP";

  if (
    /(yuan|renminbi).{0,35}(strengthens|rises|gains)/i.test(text) &&
    topics.china
  )
    return "DOWN";

  return "UNKNOWN";
}

function calculateBaseImpact(topics, base = 42) {
  let value = Number(base) || 42;

  if (topics.cpi || topics.nfp) value = Math.max(value, 90);
  else if (topics.pce) value = Math.max(value, 86);
  else if (topics.fed && topics.rates) value = Math.max(value, 88);
  else if (topics.fed) value = Math.max(value, 78);
  else if (topics.yields || topics.usd) value = Math.max(value, 75);
  else if (topics.reserves) value = Math.max(value, 80);
  else if (topics.geo) value = Math.max(value, 78);
  else if (topics.china && topics.rates) value = Math.max(value, 76);
  else if (topics.japan && topics.rates) value = Math.max(value, 72);
  else if (topics.centralBank || topics.rates) value = Math.max(value, 70);
  else if (topics.gold) value = Math.max(value, 64);
  else if (topics.mining) value = Math.max(value, 64);
  else if (topics.cryptoSystemic) value = Math.max(value, 58);

  return value;
}

function impactLevel(value) {
  if (value >= 90) return "EXTREME";
  if (value >= 75) return "HIGH";
  if (value >= 55) return "MEDIUM";
  return "LOW";
}

function classifyEvent(text, quality, topics, official) {
  const lower = text.toLowerCase();

  // CFTC не смешиваем с оперативной лентой.
  if (
    /\bcftc\b|commitments of traders|managed money|net long|net short|futures positioning/i.test(
      text
    )
  )
    return null;

  if (
    matchesAny(text, HARD_NOISE) ||
    matchesAny(text, RETAIL_NOISE) ||
    matchesAny(text, TECHNICAL_NOISE) ||
    matchesAny(text, HISTORY_NOISE)
  )
    return null;

  if (
    topics.crypto &&
    ((!topics.cryptoSystemic &&
      !topics.gold &&
      !topics.macro &&
      !topics.geo &&
      !topics.reserves) ||
      (containsAny(lower, CRYPTO_NOISE) &&
        !topics.cryptoSystemic &&
        !topics.gold &&
        !topics.macro &&
        !topics.geo))
  )
    return null;

  if (matchesAny(text, RECAP_PATTERNS)) return null;
  if (matchesAny(text, OPINION_NOISE)) return null;

  if (official && (topics.macro || topics.reserves || topics.gold))
    return "OFFICIAL_RELEASE";

  if (matchesAny(text, PREVIEW_PATTERNS))
    return quality >= 0.82 || official ? "PREVIEW" : null;

  if (
    topics.cryptoSystemic &&
    (topics.gold ||
      topics.reserves ||
      topics.macro ||
      topics.geo ||
      /banking stress|banking crisis|liquidity crunch|systemic risk/i.test(text))
  )
    return "SYSTEMIC_CRYPTO";

  if (matchesAny(text, LIVE_PATTERNS)) return "REAL_EVENT";

  if (
    topics.gold &&
    /(gold|bullion).{0,55}(rise|rose|gain|jump|surge|fall|fell|drop|slip|plunge|rebound|steady|flat)/i.test(
      text
    )
  )
    return "MARKET_REACTION";

  if (
    quality >= 0.90 &&
    (topics.macro ||
      topics.geo ||
      topics.reserves ||
      topics.mining ||
      topics.china ||
      topics.japan)
  )
    return "REAL_EVENT";

  if (
    quality >= 0.72 &&
    (topics.gold ||
      topics.macro ||
      topics.geo ||
      topics.reserves ||
      topics.mining ||
      topics.china ||
      topics.japan)
  )
    return "BACKGROUND";

  return null;
}

function buildItem(raw) {
  const title = stripHtml(raw.title || "");
  const description = stripHtml(raw.description || "");

  if (!title) return null;

  const text = normalizeSpaces(`${title} ${description}`);
  const quality = sourceQuality(raw.source, raw.url, Boolean(raw.official));
  const topics = detectTopics(text);
  const region = detectRegion(text, raw.region || "");

  const eventKind = classifyEvent(
    text,
    quality,
    topics,
    Boolean(raw.official)
  );

  if (!eventKind) return null;

  let impact =
    calculateBaseImpact(topics, raw.baseImpact) +
    Math.round((quality - 0.6) * 20);

  if (eventKind === "OFFICIAL_RELEASE") impact += 5;
  if (eventKind === "REAL_EVENT") impact += 4;
  if (eventKind === "MARKET_REACTION") impact += 2;
  if (eventKind === "SYSTEMIC_CRYPTO") impact += 2;

  if (eventKind === "PREVIEW") impact = Math.min(impact, 52);
  if (eventKind === "BACKGROUND") impact = Math.min(impact, 58);

  impact = clamp100(impact);

  return {
    title,
    originalTitle: title,
    description,
    url: raw.url || "",
    source: raw.source || "Unknown",
    region,
    timestamp: Number(raw.timestamp) || 0,
    impact,
    level: impactLevel(impact),
    goldDirection: detectGoldDirection(text, topics),
    tradeRelevant: true,
    relevanceScore: impact,
    relevanceReason:
      relevanceReason(topics, region) +
      (eventKind === "PREVIEW"
        ? " • анонс, не свежий релиз"
        : eventKind === "BACKGROUND"
        ? " • общий фон"
        : eventKind === "SYSTEMIC_CRYPTO"
        ? " • только системная связь"
        : ""),
    eventKind,
    sourceQuality: quality,
    corroborationCount: 1,
    corroboratingSources: [raw.source || "Unknown"],
    cryptoSystemic: Boolean(topics.cryptoSystemic),
  };
}

// ------------------------------------------------------
// RSS / HTTP
// ------------------------------------------------------

function parseFeed(xml, sourceConfig) {
  const blocks = [
    ...(xml.match(/<item\b[\s\S]*?<\/item>/gi) || []),
    ...(xml.match(/<entry\b[\s\S]*?<\/entry>/gi) || []),
  ];

  return blocks
    .map((block) =>
      buildItem({
        title: extractTag(block, "title"),
        description:
          extractTag(block, "description") ||
          extractTag(block, "summary") ||
          extractTag(block, "content"),
        url: extractLink(block),
        source: extractTag(block, "source") || sourceConfig.name,
        region: sourceConfig.region || "",
        timestamp: parseDate(
          extractTag(block, "pubDate") ||
            extractTag(block, "published") ||
            extractTag(block, "updated") ||
            extractTag(block, "dc:date")
        ),
        baseImpact: sourceConfig.baseImpact,
        official: Boolean(sourceConfig.official),
      })
    )
    .filter(Boolean);
}

async function fetchText(
  url,
  label,
  { retries = 1, timeoutMs = 10_000 } = {}
) {
  let lastError = null;

  for (let attempt = 1; attempt <= retries; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    try {
      const response = await fetch(url, {
        signal: controller.signal,
        headers: {
          "User-Agent": "Mozilla/5.0 XAUUSD-AI-Signal/14.0",
          Accept:
            "application/json, application/rss+xml, application/xml, text/xml, text/plain, */*",
        },
      });

      const text = await response.text();
      clearTimeout(timer);

      if (!response.ok) {
        const error = new Error(
          `HTTP ${response.status}: ${text.slice(0, 120)}`
        );
        error.status = response.status;
        throw error;
      }

      if (!text.trim()) throw new Error("empty response");
      return text;
    } catch (error) {
      clearTimeout(timer);
      lastError = error;

      console.warn(
        `⚠️ NEWS ${label}: ${
          error.name === "AbortError" ? "timeout" : error.message
        }`
      );
      if (error && typeof error === "object") {
        loggedNewsErrors.add(error);
      }

      if (error.status === 429) break;
      if (attempt < retries) await sleep(700 * attempt);
    }
  }

  throw lastError || new Error(`${label}: fetch failed`);
}

async function fetchOfficial(source) {
  const state = officialFeedState.get(source.url) || {};
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 10_000);
    const headers = {
      "User-Agent": "VIRUS-AI-XAUUSD-News/14.1 (research RSS reader)",
      Accept: "application/rss+xml, application/xml, text/xml, */*",
    };
    if (state.etag) headers["If-None-Match"] = state.etag;
    if (state.lastModified) headers["If-Modified-Since"] = state.lastModified;

    let response;
    try {
      response = await fetch(source.url, { signal: controller.signal, headers });
    } finally {
      clearTimeout(timer);
    }

    if (response.status === 304) {
      console.log(`📰 ${source.name}: 304 NOT MODIFIED`);
      return state.items || [];
    }

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const xml = await response.text();
    if (!xml.trim()) throw new Error("empty response");

    const items = parseFeed(xml, source);
    officialFeedState.set(source.url, {
      etag: response.headers.get("etag") || state.etag || null,
      lastModified: response.headers.get("last-modified") || state.lastModified || null,
      items,
      updatedAt: Date.now(),
    });

    console.log(`📰 ${source.name}: ${items.length}`);
    return items;
  } catch (error) {
    // Keep the last valid feed during a transient outage instead of turning a
    // temporary source failure into an empty-news state.
    if (state.items?.length) {
      console.warn(`⚠️ NEWS ${source.name}: ${error.message}; using cached feed`);
      return state.items;
    }
    console.warn(`⚠️ NEWS ${source.name}: ${error.message}`);
    return [];
  }
}

function googleNewsUrl(query) {
  return (
    "https://news.google.com/rss/search?" +
    new URLSearchParams({
      q: `${query} when:1d`,
      hl: "en-US",
      gl: "US",
      ceid: "US:en",
    }).toString()
  );
}

async function fetchGoogle(group, index) {
  try {
    const xml = await fetchText(
      googleNewsUrl(group.q),
      `Google ${group.name}`,
      {
        retries: 1,
        timeoutMs: 10_000,
      }
    );

    const items = parseFeed(xml, {
      name: `Google News — ${group.name}`,
      region: group.region || "",
      baseImpact: 44,
      official: false,
    });

    console.log(`🌐 Google ${group.name}: ${items.length}`);
    return items;
  } catch {
    return [];
  }
}

// ------------------------------------------------------
// GDELT (background, non-blocking)
// ------------------------------------------------------

async function waitForGdeltSlot() {
  const wait = Math.max(0, GDELT_GAP_MS - (Date.now() - lastGdeltAt));
  if (wait) await sleep(wait);
  lastGdeltAt = Date.now();
}

async function fetchGdelt(group) {
  await waitForGdeltSlot();

  const url =
    GDELT_URL +
    "?" +
    new URLSearchParams({
      query: group.query,
      mode: "artlist",
      maxrecords: "50",
      timespan: "24h",
      sort: "datedesc",
      format: "json",
    }).toString();

  const raw = await fetchText(url, `GDELT ${group.name}`, {
    retries: 1,
    timeoutMs: 15_000,
  });

  const data = JSON.parse(raw);
  const articles = Array.isArray(data?.articles) ? data.articles : [];

  return articles
    .map((article) =>
      buildItem({
        title: article.title,
        description: article.description || article.context || "",
        url: article.url || "",
        source: article.domain || article.source || "GDELT",
        region: "",
        timestamp: parseGdeltDate(
          article.seendate ||
            article.date ||
            article.datetime ||
            article.published
        ),
        baseImpact: 42,
        official: false,
      })
    )
    .filter(Boolean);
}

async function refreshGdeltCache() {
  if (!ENABLE_GDELT || gdeltUpdating) return;

  const now = Date.now();

  if (now < gdeltNextAttemptAt) return;
  if (gdeltUpdatedAt && now - gdeltUpdatedAt < GDELT_CACHE_MS) return;

  gdeltUpdating = true;

  try {
    const all = [];
    let successfulGroups = 0;
    let rateLimited = false;

    for (const group of GDELT_QUERIES) {
      try {
        const items = await fetchGdelt(group);
        successfulGroups += 1;
        all.push(...items);
      } catch (error) {
        const alreadyLogged =
          error &&
          typeof error === "object" &&
          loggedNewsErrors.has(error);

        if (!alreadyLogged) {
          console.warn(`⚠️ GDELT ${group.name}: ${error.message}`);
        }

        if (Number(error?.status) === 429) {
          rateLimited = true;
          break;
        }
      }
    }

    const finishedAt = Date.now();

    if (successfulGroups > 0) {
      if (all.length) {
        gdeltCache = deduplicate(all).slice(0, 100);
      }

      gdeltUpdatedAt = finishedAt;
      gdeltNextAttemptAt =
        finishedAt +
        (rateLimited ? GDELT_RATE_LIMIT_BACKOFF_MS : GDELT_CACHE_MS);

      console.log(
        `✅ GDELT cache: ${gdeltCache.length} | ` +
          `источников ${successfulGroups}/${GDELT_QUERIES.length}`
      );
    } else {
      const backoff = rateLimited
        ? GDELT_RATE_LIMIT_BACKOFF_MS
        : GDELT_FAILURE_BACKOFF_MS;

      gdeltNextAttemptAt = finishedAt + backoff;

      console.warn(
        `⏸️ GDELT: повтор через ${Math.round(backoff / 60_000)} мин` +
          (rateLimited ? " после HTTP 429" : " после ошибки сети")
      );
    }
  } finally {
    gdeltUpdating = false;
  }
}

// ------------------------------------------------------
// DEDUPE / CORROBORATION
// ------------------------------------------------------

function tokenSet(value) {
  return new Set(
    stripHtml(value)
      .toLowerCase()
      .replace(/[^a-z0-9а-яё\s]/gi, " ")
      .split(/\s+/)
      .filter((token) => token.length > 2)
  );
}

function similarity(a, b) {
  if (!a.size || !b.size) return 0;

  let intersection = 0;
  for (const token of a) {
    if (b.has(token)) intersection++;
  }

  const union = new Set([...a, ...b]).size;
  return union ? intersection / union : 0;
}

function isDuplicate(a, b) {
  if (
    a.timestamp &&
    b.timestamp &&
    Math.abs(a.timestamp - b.timestamp) > 8 * 60 * 60_000
  ) {
    return false;
  }

  return (
    similarity(
      tokenSet(a.originalTitle || a.title),
      tokenSet(b.originalTitle || b.title)
    ) >= 0.58
  );
}

function mergeItems(a, b) {
  const sources = new Set([
    ...(a.corroboratingSources || [a.source]),
    ...(b.corroboratingSources || [b.source]),
  ]);

  const best =
    b.sourceQuality * 100 + b.impact > a.sourceQuality * 100 + a.impact
      ? b
      : a;

  const directions = [a.goldDirection, b.goldDirection].filter(
    (x) => x && x !== "UNKNOWN"
  );

  let goldDirection = best.goldDirection;

  if (directions.includes("UP") && !directions.includes("DOWN"))
    goldDirection = "UP";

  if (directions.includes("DOWN") && !directions.includes("UP"))
    goldDirection = "DOWN";

  return {
    ...best,
    timestamp: Math.max(a.timestamp || 0, b.timestamp || 0),
    goldDirection,
    corroborationCount: sources.size,
    corroboratingSources: [...sources],
    impact: clamp100(
      Math.max(a.impact, b.impact) + Math.min(8, (sources.size - 1) * 3)
    ),
  };
}

function deduplicate(items) {
  const sorted = [...(items || [])]
    .filter(Boolean)
    .sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));

  const result = [];

  for (const item of sorted) {
    const index = result.findIndex((existing) => isDuplicate(existing, item));

    if (index < 0) {
      result.push(item);
    } else {
      result[index] = mergeItems(result[index], item);
    }
  }

  return result;
}

// ------------------------------------------------------
// TRANSLATION
// ------------------------------------------------------

async function translateTitle(title) {
  const clean = stripHtml(title || "");

  if (!clean || looksRussian(clean)) return clean;
  if (translationCache.has(clean)) return translationCache.get(clean);

  const wait = Math.max(0, translationNextAttemptAt - Date.now());
  if (wait) await sleep(wait);

  try {
    const url =
      "https://translate.googleapis.com/translate_a/single?" +
      new URLSearchParams({
        client: "gtx",
        sl: "auto",
        tl: "ru",
        dt: "t",
        q: clean.slice(0, 450),
      }).toString();

    const data = JSON.parse(
      await fetchText(url, "translate", {
        retries: 1,
        timeoutMs: 6_000,
      })
    );

    const translated = Array.isArray(data?.[0])
      ? data[0]
          .map((part) => (Array.isArray(part) ? part[0] || "" : ""))
          .join("")
          .trim()
      : "";

    const result = translated || clean;
    translationCache.set(clean, result);
    translationNextAttemptAt = Date.now() + TRANSLATE_GAP_MS;
    return result;
  } catch (error) {
    // Google Translate's anonymous endpoint can return HTTP 429. Do not retry
    // immediately for every headline; keep English as a safe fallback.
    if (Number(error?.status) === 429) {
      translationNextAttemptAt = Date.now() + TRANSLATE_BACKOFF_MS;
      console.warn(
        `⏸️ NEWS translate: HTTP 429; translation paused for ${Math.round(TRANSLATE_BACKOFF_MS / 60_000)} min`
      );
    }
    translationCache.set(clean, clean);
    return clean;
  }
}

async function translateTop(items, limit = TRANSLATE_LIMIT) {
  const output = items.map((item) => ({ ...item }));
  const max = Math.min(limit, output.length);
  let cursor = 0;

  async function worker() {
    while (true) {
      const index = cursor++;
      if (index >= max) return;

      const originalTitle =
        output[index].originalTitle || output[index].title || "";

      output[index].title = await translateTitle(originalTitle);
    }
  }

  if (max > 0) {
    // Serialize translation requests. Parallel anonymous requests were causing
    // repeated 429s and did not improve the news pipeline materially.
    await worker();
  }

  return output;
}

// ------------------------------------------------------
// PUBLIC API
// ------------------------------------------------------

function isOutputEligible(item) {
  if (!item || !item.tradeRelevant || !item.timestamp) return false;

  const age = Date.now() - item.timestamp;

  // Все источники приводятся к epoch/UTC. События, которые выглядят
  // заметно "из будущего", не участвуют в торговом новостном давлении.
  if (age < -NEWS_FUTURE_TOLERANCE_MS) return false;
  if (age > 48 * 60 * 60_000) return false;

  if (item.eventKind === "OFFICIAL_RELEASE") return true;
  if (item.corroborationCount >= 2 && item.impact >= 50) return true;

  if (
    ["REAL_EVENT", "MARKET_REACTION", "SYSTEMIC_CRYPTO"].includes(
      item.eventKind
    )
  ) {
    return item.sourceQuality >= 0.70 || item.impact >= 70;
  }

  if (item.eventKind === "PREVIEW") return item.sourceQuality >= 0.82;
  if (item.eventKind === "BACKGROUND")
    return item.sourceQuality >= 0.82 || item.impact >= 65;

  return false;
}

async function getGoldNewsSnapshot(options = {}) {
  const force = Boolean(options?.force);

  if (
    !force &&
    snapshotCache.length &&
    Date.now() - snapshotUpdatedAt < CACHE_MS
  ) {
    return snapshotCache.map((item) => ({ ...item }));
  }

  const [officialGroups, googleGroups] = await Promise.all([
    Promise.all(OFFICIAL_SOURCES.map(fetchOfficial)),
    Promise.all(GOOGLE_NEWS_QUERIES.map(fetchGoogle)),
  ]);

  // GDELT не задерживает ответ Telegram.
  refreshGdeltCache().catch((error) =>
    console.warn(`⚠️ GDELT background: ${error.message}`)
  );

  let combined = deduplicate([
    ...officialGroups.flat(),
    ...googleGroups.flat(),
    ...gdeltCache,
  ])
    .filter(isOutputEligible)
    .slice(0, 220);

  combined = await translateTop(combined);

  snapshotCache = combined;
  snapshotUpdatedAt = Date.now();

  const byRegion = {};
  for (const item of combined) {
    byRegion[item.region] = (byRegion[item.region] || 0) + 1;
  }

  console.log(
    `✅ NEWS V14: ${combined.length} | ${Object.entries(byRegion)
      .map(([region, count]) => `${region}:${count}`)
      .join(" ")}`
  );

  return combined.map((item) => ({ ...item }));
}

function getRecentNews(items, hours = 24) {
  const cutoff = Date.now() - Number(hours || 24) * 60 * 60_000;

  const futureCutoff =
    Date.now() + NEWS_FUTURE_TOLERANCE_MS;

  return [...(items || [])]
    .filter(
      (item) =>
        item?.tradeRelevant &&
        item.timestamp &&
        item.timestamp >= cutoff &&
        item.timestamp <= futureCutoff
    )
    .sort((a, b) => b.timestamp - a.timestamp);
}

function getImportantNews(items, minImpact = 55, hours = 24) {
  return getRecentNews(items, hours).filter(
    (item) => Number(item.impact || 0) >= Number(minImpact || 55)
  );
}

function calculateNewsPressure(items, hours = 6) {
  const recent = getImportantNews(items, 55, hours)
    .filter((item) => item.eventKind !== "PREVIEW")
    .slice(0, 40);

  if (!recent.length) {
    return {
      direction: "NEUTRAL",
      score: 0,
      strength: 0,
      strongestImpact: 0,
      count: 0,
    };
  }

  let score = 0;
  let totalWeight = 0;

  for (const item of recent) {
    const ageHours = Math.max(
      0,
      (Date.now() - item.timestamp) / 3_600_000
    );

    const freshness = Math.max(0.12, 1 - ageHours / Math.max(1, hours));
    const corroboration = Math.min(
      1.18,
      1 + Math.max(0, item.corroborationCount - 1) * 0.04
    );

    const weight =
      freshness *
      (Number(item.impact || 0) / 100) *
      corroboration;

    totalWeight += weight;

    if (item.goldDirection === "UP") score += weight;
    if (item.goldDirection === "DOWN") score -= weight;
  }

  const normalized =
    totalWeight > 0 ? (score / totalWeight) * 100 : 0;

  return {
    direction:
      normalized >= 12
        ? "UP"
        : normalized <= -12
        ? "DOWN"
        : "NEUTRAL",

    score: Number(score.toFixed(3)),

    strength: Math.min(100, Math.round(Math.abs(normalized))),

    strongestImpact: Math.max(
      ...recent.map((item) => Number(item.impact || 0))
    ),

    count: recent.length,
  };
}

function formatGoldNewsMessage(items, limit = 10) {
  const recent = getRecentNews(items, 24).slice(0, Number(limit || 10));
  const pressure = calculateNewsPressure(items, 6);

  let text = "🌍 XAU/USD — МИРОВОЙ НОВОСТНОЙ РАДАР V14\n\n";

  if (!recent.length) {
    text += "Свежих полезных новостей за 24 часа пока нет.\n\n";
  }

  recent.forEach((item, index) => {
    const icon =
      item.goldDirection === "UP"
        ? "🟢⬆️"
        : item.goldDirection === "DOWN"
        ? "🔴⬇️"
        : "⚪↔️";

    const time = item.timestamp
      ? new Date(item.timestamp).toLocaleString("ru-RU", {
          timeZone: USER_TIMEZONE,
          day: "2-digit",
          month: "2-digit",
          hour: "2-digit",
          minute: "2-digit",
        })
      : "—";

    text += `${index + 1}. ${item.title}\n`;
    text += `Источник: ${item.source}\n`;
    text += `Регион: ${item.region}\n`;
    text += `Тип: ${item.eventKind}\n`;
    text += `Влияние: ${item.impact}/100 • ${item.level}\n`;
    text += `Почему важно: ${item.relevanceReason}\n`;
    text += `Золото: ${icon}\n`;
    text += `Время: ${time}\n`;

    if (item.corroborationCount > 1) {
      text += `Подтверждено источниками: ${item.corroborationCount}\n`;
    }

    if (item.cryptoSystemic) {
      text += "₿ Крипто-фактор: только системная связь\n";
    }

    text += "\n";
  });

  text +=
    pressure.direction === "UP"
      ? "🟢 ОБЩИЙ ФОН: ЗА РОСТ ЗОЛОТА\n"
      : pressure.direction === "DOWN"
      ? "🔴 ОБЩИЙ ФОН: ЗА СНИЖЕНИЕ ЗОЛОТА\n"
      : "⚪ ОБЩИЙ ФОН: НЕЙТРАЛЬНО / НЕЯСНО\n";

  text += `💪 Сила: ${pressure.strength}/100\n`;
  text += `🚨 Самая сильная: ${pressure.strongestImpact}/100\n`;
  text += `📰 Учтено: ${pressure.count}`;

  return text;
}

module.exports = {
  OFFICIAL_SOURCES,
  GOOGLE_NEWS_QUERIES,
  GDELT_QUERIES,
  getGoldNewsSnapshot,
  getRecentNews,
  getImportantNews,
  calculateNewsPressure,
  formatGoldNewsMessage,
  CANONICAL_TIMEZONE,
  USER_TIMEZONE,
};
