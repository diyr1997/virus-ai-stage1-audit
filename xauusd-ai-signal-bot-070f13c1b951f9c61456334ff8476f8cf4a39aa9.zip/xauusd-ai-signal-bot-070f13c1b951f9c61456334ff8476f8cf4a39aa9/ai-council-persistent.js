"use strict";

const fs = require("fs");
const path = require("path");
const { Pool } = require("pg");
const { ADVISORS, ROLES } = require("./ai-council");
const {
  callProvider,
  callOpenAI,
  callGeminiGrounded,
  callDeepSeek,
  callClaude,
} = require("./ai-providers");
const { callGrok, callGrokResearch } = require("./grok-provider");
const { claudeBridgeActive } = require("./ai-council-claude-bridge");
const { LOCAL_ADVISOR_ID, localAdvisorEnabled } = require("./local-advisor");

const DATABASE_URL = String(process.env.DATABASE_URL || "").trim();
const pool = DATABASE_URL ? new Pool({ connectionString: DATABASE_URL }) : null;

const CONTEXT_FILES = [
  "AGENTS.md",
  "AI_AGENT_TOOLBOX_STATUS.md",
  path.join("tools", "ai_toolbox", "SHARED_COUNCIL_TOOLS.json"),
  "AI_COUNCIL_PROJECT_CONTEXT.md",
  "AI_COUNCIL_ROADMAP_2026-08-20.md",
  "PROJECT_LEDGER_2026-08-20.md",
  "TRADING_SCHOOL_BOOK_LIBRARY.md",
  path.join("trading_school", "library_manifest.json"),
];

const PROVIDER_KEYS = {
  chatgpt: "OPENAI_API_KEY",
  gemini: "GEMINI_API_KEY",
  deepseek: "DEEPSEEK_API_KEY",
  claude: "ANTHROPIC_API_KEY",
  grok: "XAI_API_KEY",
  perplexity: "PERPLEXITY_API_KEY",
};

function requirePool() {
  if (!pool) throw new Error("DATABASE_URL is not configured");
  return pool;
}

function advisorConfigured(advisor) {
  const key = PROVIDER_KEYS[advisor];
  if (key && String(process.env[key] || "").trim()) return true;
  if (advisor === "claude" && claudeBridgeActive()) return true;
  // The local Ollama advisor has no API key: it is gated by an explicit
  // opt-in flag and stays NOT_CONFIGURED (never a quorum blocker) by default.
  if (advisor === LOCAL_ADVISOR_ID && localAdvisorEnabled()) return true;
  return false;
}

function buildMasterContextSnapshot() {
  const chunks = [];
  for (const relative of CONTEXT_FILES) {
    const full = path.join(__dirname, relative);
    try {
      chunks.push(`\n\n===== ${relative} =====\n${fs.readFileSync(full, "utf8")}`);
    } catch (error) {
      chunks.push(`\n\n===== ${relative} =====\nUNAVAILABLE: ${error.message}`);
    }
  }
  return chunks.join("").trim();
}

async function ensureCouncilSchema() {
  const db = requirePool();
  await db.query(`
    CREATE TABLE IF NOT EXISTS ai_council_tasks (
      id TEXT PRIMARY KEY,
      task_type TEXT NOT NULL,
      task TEXT NOT NULL,
      context_snapshot TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'PENDING',
      revision INTEGER NOT NULL DEFAULT 0,
      final_plan TEXT,
      last_coordinator TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await db.query(`
    CREATE TABLE IF NOT EXISTS ai_council_runs (
      task_id TEXT NOT NULL REFERENCES ai_council_tasks(id) ON DELETE CASCADE,
      advisor TEXT NOT NULL,
      phase TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'PENDING',
      response TEXT,
      error TEXT,
      attempts INTEGER NOT NULL DEFAULT 0,
      completed_at TIMESTAMPTZ,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      PRIMARY KEY (task_id, advisor, phase)
    )
  `);

  await db.query(
    "CREATE INDEX IF NOT EXISTS ai_council_tasks_status_idx ON ai_council_tasks(status, updated_at)"
  );
}

async function enqueueCouncilTask({
  taskId,
  taskType = "general",
  task,
  contextSnapshot = buildMasterContextSnapshot(),
}) {
  if (!taskId || !task) throw new Error("taskId and task are required");
  const db = requirePool();
  await ensureCouncilSchema();

  await db.query(
    `INSERT INTO ai_council_tasks(id, task_type, task, context_snapshot, status)
     VALUES ($1, $2, $3, $4, 'PENDING')
     ON CONFLICT (id) DO NOTHING`,
    [taskId, taskType, task, contextSnapshot]
  );

  for (const advisor of ADVISORS) {
    for (const phase of ["independent", "peer_review"]) {
      await db.query(
        `INSERT INTO ai_council_runs(task_id, advisor, phase, status)
         VALUES ($1, $2, $3, 'PENDING')
         ON CONFLICT (task_id, advisor, phase) DO NOTHING`,
        [taskId, advisor, phase]
      );
    }
  }

  return taskId;
}

function groundedToText(result) {
  if (!result || typeof result === "string") return String(result || "").trim();
  if (result.rateLimited) {
    const error = new Error(`Provider rate limited until ${result.retryAt || "later"}`);
    error.code = "RATE_LIMITED";
    throw error;
  }

  const text = String(result.text || "").trim();
  if (!text) throw new Error("Provider returned empty research response");
  const sources = Array.isArray(result.sources) ? result.sources : [];
  if (!sources.length) return text;

  return `${text}\n\nVERIFIABLE SOURCES:\n${sources
    .map((s, index) => `${index + 1}. ${s.title || "Source"} — ${s.url}`)
    .join("\n")}`;
}

async function callAdvisorForTask(advisor, taskType, prompt) {
  const research = /research|book|source|news/i.test(String(taskType || ""));

  if (advisor === "grok") {
    return groundedToText(research ? await callGrokResearch(prompt) : await callGrok(prompt));
  }
  if (advisor === "gemini" && research) {
    return groundedToText(await callGeminiGrounded(prompt));
  }
  if (advisor === "chatgpt") return String(await callOpenAI(prompt)).trim();
  if (advisor === "deepseek") return String(await callDeepSeek(prompt)).trim();
  if (advisor === "claude") return String(await callClaude(prompt)).trim();
  return String(await callProvider(advisor, prompt)).trim();
}

function buildPrompt({ task, taskType, contextSnapshot, advisor, peerResponses = [] }) {
  const role = ROLES[advisor] || "Independent reviewer";
  const peer = peerResponses.length
    ? `\n\nOTHER ADVISORS' RESPONSES TO CRITIQUE:\n${JSON.stringify(peerResponses, null, 2)}`
    : "";

  return [
    "You are one member of the XAU/USD AI Council.",
    "Every advisor receives the same task and the same frozen project context.",
    "AGENTS.md inside the frozen context is the mandatory task-execution contract. The shared tool registry is common to every advisor; never pretend a listed tool was executed without returned execution evidence.",
    "First think independently. Do not wait for or imitate another advisor's answer.",
    "In peer-review phase, actively look for mistakes, contradictions, missing evidence and better alternatives.",
    "Do not trade, expose secrets, or silently change production.",
    "When a claim depends on a source, distinguish VERIFIED from UNVERIFIED. Do not invent URLs or book availability.",
    `TASK TYPE: ${taskType}`,
    `YOUR ROLE: ${role}`,
    "",
    "FROZEN PROJECT CONTEXT:",
    contextSnapshot,
    "",
    "TASK:",
    task,
    peer,
    "",
    "Return: summary, findings, proposed_changes, rejected_or_doubtful_ideas, evidence_and_sources, risks, tests, disagreements, confidence.",
  ].join("\n");
}

async function getTask(taskId) {
  const { rows } = await requirePool().query(
    "SELECT * FROM ai_council_tasks WHERE id=$1",
    [taskId]
  );
  return rows[0] || null;
}

async function getRuns(taskId) {
  const { rows } = await requirePool().query(
    "SELECT * FROM ai_council_runs WHERE task_id=$1 ORDER BY advisor, phase",
    [taskId]
  );
  return rows;
}

async function saveRunSuccess(taskId, advisor, phase, response) {
  await requirePool().query(
    `UPDATE ai_council_runs
     SET status='SUCCESS', response=$4, error=NULL, attempts=attempts+1,
         completed_at=NOW(), updated_at=NOW()
     WHERE task_id=$1 AND advisor=$2 AND phase=$3`,
    [taskId, advisor, phase, response]
  );
}

async function saveRunPending(taskId, advisor, phase, error) {
  await requirePool().query(
    `UPDATE ai_council_runs
     SET status='PENDING', error=$4, attempts=attempts+1, updated_at=NOW()
     WHERE task_id=$1 AND advisor=$2 AND phase=$3`,
    [taskId, advisor, phase, String(error?.message || error || "Unknown error").slice(0, 1600)]
  );
}

async function attemptAdvisorPhase(task, advisor, phase, peerResponses = []) {
  if (!advisorConfigured(advisor)) {
    await saveRunPending(task.id, advisor, phase, new Error("NOT_CONFIGURED"));
    return false;
  }

  try {
    const prompt = buildPrompt({
      task: task.task,
      taskType: task.task_type,
      contextSnapshot: task.context_snapshot,
      advisor,
      peerResponses,
    });
    const response = await callAdvisorForTask(advisor, task.task_type, prompt);
    if (!response) throw new Error("Empty advisor response");
    await saveRunSuccess(task.id, advisor, phase, response);
    return true;
  } catch (error) {
    await saveRunPending(task.id, advisor, phase, error);
    return false;
  }
}

async function runPhaseInParallel(task, phase, runs, peerResponses = []) {
  const jobs = ADVISORS.map(async (advisor) => {
    const existing = runs.find(
      (run) => run.advisor === advisor && run.phase === phase
    );
    if (existing?.status === "SUCCESS") return false;

    if (phase === "peer_review") {
      const independent = runs.find(
        (run) =>
          run.advisor === advisor &&
          run.phase === "independent" &&
          run.status === "SUCCESS"
      );
      if (!independent) return false;
    }

    return attemptAdvisorPhase(task, advisor, phase, peerResponses);
  });

  const settled = await Promise.allSettled(jobs);
  return settled.some(
    (result) => result.status === "fulfilled" && result.value === true
  );
}

async function synthesizeTask(task, successfulResponses) {
  if (!successfulResponses.length) return false;

  const synthesisPrompt = [
    "You are the coordinator for the XAU/USD AI Council.",
    "Reconcile the advisor responses below. Do not decide by majority vote. Prefer verifiable evidence, testability, robustness and DEMO safety.",
    "Explicitly list disagreements. Mark any conclusion that still needs a missing advisor's catch-up review as provisional.",
    "If a late advisor adds a material objection later, the council will run this synthesis again as a new revision.",
    "",
    `TASK: ${task.task}`,
    "",
    "ADVISOR RESPONSES:",
    JSON.stringify(successfulResponses, null, 2),
    "",
    "Return: consensus, strongest_disagreements, approved_for_testing, rejected, needs_more_evidence, exact_next_tests, provisional_items, final_recommendation.",
  ].join("\n");

  const order = ["chatgpt", "deepseek", "claude", "gemini", "grok"];
  for (const coordinator of order) {
    if (!advisorConfigured(coordinator)) continue;
    try {
      const text = await callAdvisorForTask(coordinator, "synthesis", synthesisPrompt);
      if (!text) continue;
      await requirePool().query(
        `UPDATE ai_council_tasks
         SET final_plan=$2, last_coordinator=$3, revision=revision+1,
             updated_at=NOW()
         WHERE id=$1`,
        [task.id, text, coordinator]
      );
      return true;
    } catch (error) {
      console.warn(`AI COUNCIL coordinator ${coordinator} unavailable: ${error.message}`);
    }
  }
  return false;
}

async function processCouncilTask(taskId) {
  const task = await getTask(taskId);
  if (!task) throw new Error(`Unknown council task: ${taskId}`);

  let runs = await getRuns(taskId);
  let progress = await runPhaseInParallel(task, "independent", runs);

  runs = await getRuns(taskId);
  const independent = runs
    .filter((run) => run.phase === "independent" && run.status === "SUCCESS")
    .map((run) => ({ advisor: run.advisor, response: run.response }));

  const peerProgress = await runPhaseInParallel(
    task,
    "peer_review",
    runs,
    independent
  );
  progress = progress || peerProgress;

  runs = await getRuns(taskId);
  const completed = runs
    .filter((run) => run.status === "SUCCESS")
    .map((run) => ({
      advisor: run.advisor,
      phase: run.phase,
      response: run.response,
    }));

  const allComplete = ADVISORS.every((advisor) =>
    ["independent", "peer_review"].every((phase) =>
      runs.some(
        (run) =>
          run.advisor === advisor &&
          run.phase === phase &&
          run.status === "SUCCESS"
      )
    )
  );

  if (progress || !task.final_plan) {
    await synthesizeTask(task, completed);
  }

  await requirePool().query(
    `UPDATE ai_council_tasks
     SET status=$2, updated_at=NOW()
     WHERE id=$1`,
    [taskId, allComplete ? "COMPLETE" : "WAITING_ADVISORS"]
  );

  return {
    taskId,
    status: allComplete ? "COMPLETE" : "WAITING_ADVISORS",
    completedRuns: completed.length,
    totalRuns: ADVISORS.length * 2,
  };
}

async function processPendingCouncilTasks(limit = 10) {
  await ensureCouncilSchema();
  const { rows } = await requirePool().query(
    `SELECT id FROM ai_council_tasks
     WHERE status <> 'COMPLETE'
     ORDER BY updated_at ASC
     LIMIT $1`,
    [Math.max(1, Math.min(50, Number(limit) || 10))]
  );

  const results = [];
  for (const row of rows) {
    try {
      results.push(await processCouncilTask(row.id));
    } catch (error) {
      console.warn(`AI COUNCIL task ${row.id} failed: ${error.message}`);
    }
  }
  return results;
}

module.exports = {
  ADVISORS,
  advisorConfigured,
  buildMasterContextSnapshot,
  ensureCouncilSchema,
  enqueueCouncilTask,
  processCouncilTask,
  processPendingCouncilTasks,
};