"use strict";

/**
 * Trading School — Open Companion Ingestor V1.1
 *
 * Safely imports only openly licensed material. Current source:
 * Stefan Jansen's public MIT-licensed Machine Learning for Algorithmic Trading
 * companion repository. We ingest root/chapter README files (not the commercial
 * book text) into the same private PostgreSQL Trading School tables so the
 * existing AI reader can summarize them and generate testable hypotheses.
 *
 * This module NEVER changes BUY/SELL logic, never promotes a model, and never
 * touches MT5 execution.
 */

const crypto = require("crypto");
const { Pool } = require("pg");

const DATABASE_URL = String(
  process.env.DATABASE_URL || process.env.DATABASE_PUBLIC_URL || ""
).trim();
const ENABLED = String(process.env.TRADING_SCHOOL_OPEN_COMPANIONS_ENABLED || "1") !== "0";
const RUN_DELAY_MS = Math.max(20_000, Number(process.env.TRADING_SCHOOL_OPEN_COMPANIONS_DELAY_MS || 45_000));
const CHUNK_CHARS = 12_000;

const SOURCE = {
  key: "stefan_jansen_ml4t_companion",
  title: "Stefan Jansen — Machine Learning for Algorithmic Trading open companion repository",
  treeUrl: "https://api.github.com/repos/stefan-jansen/machine-learning-for-trading/git/trees/main?recursive=1",
  rawBase: "https://raw.githubusercontent.com/stefan-jansen/machine-learning-for-trading/main/",
  landing: "https://github.com/stefan-jansen/machine-learning-for-trading",
  license: "MIT",
  role: "ml_feature_engineering_validation_backtesting_workflow",
};

const pool = DATABASE_URL
  ? new Pool({ connectionString: DATABASE_URL, max: 1, idleTimeoutMillis: 30_000 })
  : null;

function sha256(text) {
  return crypto.createHash("sha256").update(String(text || ""), "utf8").digest("hex");
}

function splitText(text, maxChars = CHUNK_CHARS) {
  const paragraphs = String(text || "").replace(/\r/g, "").split(/\n{2,}/).map((x) => x.trim()).filter(Boolean);
  const chunks = [];
  let current = "";
  for (const p of paragraphs) {
    if (current && current.length + p.length + 2 > maxChars) {
      chunks.push(current);
      current = "";
    }
    if (p.length > maxChars) {
      if (current) chunks.push(current), (current = "");
      for (let i = 0; i < p.length; i += maxChars) chunks.push(p.slice(i, i + maxChars));
    } else {
      current += (current ? "\n\n" : "") + p;
    }
  }
  if (current) chunks.push(current);
  return chunks;
}

async function fetchText(url, accept = "text/plain,*/*;q=0.5") {
  const r = await fetch(url, {
    headers: {
      "user-agent": "XAUUSD-Trading-School/2.1 (open-license educational reader)",
      accept,
    },
    redirect: "follow",
    signal: AbortSignal.timeout(60_000),
  });
  if (!r.ok) throw new Error(`HTTP ${r.status} ${url}`);
  return await r.text();
}

async function ensureSchema() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS trading_school_books (
      book_key VARCHAR(80) PRIMARY KEY,
      title TEXT NOT NULL,
      source_type VARCHAR(40) NOT NULL,
      source_url TEXT,
      access_mode VARCHAR(60),
      role TEXT,
      status VARCHAR(32) NOT NULL DEFAULT 'NEW',
      discovered_pages INT NOT NULL DEFAULT 0,
      ingested_pages INT NOT NULL DEFAULT 0,
      summarized_chunks INT NOT NULL DEFAULT 0,
      total_chars BIGINT NOT NULL DEFAULT 0,
      last_error TEXT,
      meta JSONB NOT NULL DEFAULT '{}'::jsonb,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS trading_school_pages (
      id BIGSERIAL PRIMARY KEY,
      book_key VARCHAR(80) NOT NULL REFERENCES trading_school_books(book_key) ON DELETE CASCADE,
      seq BIGINT NOT NULL,
      url TEXT NOT NULL,
      title TEXT,
      status VARCHAR(24) NOT NULL DEFAULT 'PENDING',
      char_count INT NOT NULL DEFAULT 0,
      error TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE(book_key, url)
    );

    CREATE TABLE IF NOT EXISTS trading_school_chunks (
      id BIGSERIAL PRIMARY KEY,
      book_key VARCHAR(80) NOT NULL REFERENCES trading_school_books(book_key) ON DELETE CASCADE,
      page_id BIGINT REFERENCES trading_school_pages(id) ON DELETE CASCADE,
      chunk_no INT NOT NULL,
      locator TEXT,
      source_url TEXT,
      content_hash CHAR(64) NOT NULL,
      content TEXT NOT NULL,
      ai_status VARCHAR(24) NOT NULL DEFAULT 'PENDING',
      summary TEXT,
      concepts JSONB NOT NULL DEFAULT '{}'::jsonb,
      ai_error TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE(book_key, content_hash)
    );
  `);
}

function selectReadmes(tree) {
  return (tree || [])
    .filter((x) => x && x.type === "blob" && typeof x.path === "string")
    .map((x) => x.path)
    .filter((p) => p === "README.md" || /^\d{2}_[^/]+\/README\.md$/i.test(p))
    .sort((a, b) => {
      if (a === "README.md") return -1;
      if (b === "README.md") return 1;
      return a.localeCompare(b);
    })
    .slice(0, 80);
}

async function upsertBook() {
  const meta = {
    license: SOURCE.license,
    license_url: "https://github.com/stefan-jansen/machine-learning-for-trading/blob/main/LICENSE",
    source_repo: SOURCE.landing,
    ingest_scope: "root_and_chapter_README_only",
    commercial_book_text_copied: false,
  };
  await pool.query(
    `INSERT INTO trading_school_books(book_key,title,source_type,source_url,access_mode,role,status,meta)
     VALUES($1,$2,'github_mit_readmes',$3,'open_mit_licensed_companion',$4,'QUEUED',$5::jsonb)
     ON CONFLICT(book_key) DO UPDATE SET
       title=EXCLUDED.title, source_type=EXCLUDED.source_type, source_url=EXCLUDED.source_url,
       access_mode=EXCLUDED.access_mode, role=EXCLUDED.role,
       meta=trading_school_books.meta || EXCLUDED.meta, updated_at=NOW()`,
    [SOURCE.key, SOURCE.title, SOURCE.landing, SOURCE.role, JSON.stringify(meta)]
  );
}

async function cachedSnapshot() {
  const pages = await pool.query(
    `SELECT COUNT(*)::int AS n, COALESCE(SUM(char_count),0)::bigint AS chars
     FROM trading_school_pages WHERE book_key=$1 AND status='INGESTED'`,
    [SOURCE.key]
  );
  const chunks = await pool.query(
    `SELECT COUNT(*)::int AS n FROM trading_school_chunks WHERE book_key=$1`,
    [SOURCE.key]
  );
  return {
    pages: Number(pages.rows[0]?.n || 0),
    chars: Number(pages.rows[0]?.chars || 0),
    chunks: Number(chunks.rows[0]?.n || 0),
  };
}

async function keepExistingIfCompleteEnough() {
  const snap = await cachedSnapshot();
  // We already successfully captured 28 README pages / 44 chunks. Once a useful
  // copy is safely stored, do not hammer GitHub on every redeploy just to refresh
  // an unchanged companion repository. This also protects us from API 403/429.
  if (snap.pages >= 20 && snap.chunks >= 20 && snap.chars >= 100_000) {
    await pool.query(
      `UPDATE trading_school_books
       SET status='INGESTED',discovered_pages=$2,ingested_pages=$2,total_chars=$3,last_error=NULL,updated_at=NOW(),
           meta=meta || $4::jsonb
       WHERE book_key=$1`,
      [SOURCE.key, snap.pages, snap.chars, JSON.stringify({ cached_open_companion: true, total_chunks: snap.chunks })]
    );
    console.log(
      `📚 OPEN COMPANION CACHED | source=stefan_jansen_ml4t | readmes=${snap.pages} | ` +
      `chunks=${snap.chunks} | chars=${snap.chars} | refresh_skipped=true`
    );
    return true;
  }
  return false;
}

async function ingestOne(path, seq) {
  const rawUrl = SOURCE.rawBase + path;
  const text = (await fetchText(rawUrl)).trim();
  if (text.length < 50) return { chars: 0, chunks: 0 };

  const page = await pool.query(
    `INSERT INTO trading_school_pages(book_key,seq,url,title,status,char_count,error)
     VALUES($1,$2,$3,$4,'INGESTED',$5,NULL)
     ON CONFLICT(book_key,url) DO UPDATE SET
       seq=EXCLUDED.seq,title=EXCLUDED.title,status='INGESTED',char_count=EXCLUDED.char_count,error=NULL,updated_at=NOW()
     RETURNING id`,
    [SOURCE.key, seq, rawUrl, path, text.length]
  );
  const pageId = page.rows[0].id;
  const chunks = splitText(text);
  for (let i = 0; i < chunks.length; i++) {
    const c = chunks[i];
    await pool.query(
      `INSERT INTO trading_school_chunks(book_key,page_id,chunk_no,locator,source_url,content_hash,content,ai_status)
       VALUES($1,$2,$3,$4,$5,$6,$7,'PENDING')
       ON CONFLICT(book_key,content_hash) DO NOTHING`,
      [SOURCE.key, pageId, i + 1, `${path} / part ${i + 1}`, rawUrl, sha256(c), c]
    );
  }
  return { chars: text.length, chunks: chunks.length };
}

async function run() {
  if (!ENABLED) return;
  if (!pool) {
    console.warn("📚 OPEN COMPANIONS: PostgreSQL unavailable; skipped");
    return;
  }
  await ensureSchema();
  await upsertBook();

  try {
    if (await keepExistingIfCompleteEnough()) return;

    const treeText = await fetchText(SOURCE.treeUrl, "application/vnd.github+json,application/json;q=0.9,*/*;q=0.5");
    const treeJson = JSON.parse(treeText);
    const paths = selectReadmes(treeJson.tree);
    if (!paths.length) throw new Error("No eligible README files discovered");

    for (let i = 0; i < paths.length; i++) {
      await ingestOne(paths[i], i + 1);
    }

    const snap = await cachedSnapshot();
    await pool.query(
      `UPDATE trading_school_books
       SET status='INGESTED',discovered_pages=$2,ingested_pages=$2,total_chars=$3,last_error=NULL,updated_at=NOW(),
           meta=meta || $4::jsonb
       WHERE book_key=$1`,
      [SOURCE.key, snap.pages, snap.chars, JSON.stringify({ discovered_readmes: paths.length, total_chunks: snap.chunks })]
    );

    console.log(
      `📚 OPEN COMPANION INGESTED | source=stefan_jansen_ml4t | license=MIT | ` +
      `readmes=${snap.pages} | chunks=${snap.chunks} | chars=${snap.chars} | commercial_book_text=false`
    );
  } catch (error) {
    // If a refresh fails but we have a usable cached copy, keep the book usable
    // instead of downgrading it to ERROR.
    const snap = await cachedSnapshot().catch(() => ({ pages: 0, chunks: 0, chars: 0 }));
    if (snap.pages >= 20 && snap.chunks >= 20 && snap.chars >= 100_000) {
      await pool.query(
        `UPDATE trading_school_books SET status='INGESTED',last_error=$2,updated_at=NOW() WHERE book_key=$1`,
        [SOURCE.key, `refresh skipped after cached copy: ${String(error?.message || error)}`]
      ).catch(() => {});
      console.warn(`📚 OPEN COMPANION REFRESH SKIPPED | cached copy kept | ${String(error?.message || error)}`);
      return;
    }

    await pool.query(
      `UPDATE trading_school_books SET status='ERROR',last_error=$2,updated_at=NOW() WHERE book_key=$1`,
      [SOURCE.key, String(error?.message || error)]
    ).catch(() => {});
    console.error("❌ OPEN COMPANION INGEST:", error);
  }
}

console.log(`📚 TRADING SCHOOL OPEN COMPANIONS V1.1: armed; starts in ${Math.round(RUN_DELAY_MS / 1000)} sec`);
setTimeout(() => run().catch((e) => console.error("❌ OPEN COMPANIONS bootstrap:", e)), RUN_DELAY_MS).unref();
