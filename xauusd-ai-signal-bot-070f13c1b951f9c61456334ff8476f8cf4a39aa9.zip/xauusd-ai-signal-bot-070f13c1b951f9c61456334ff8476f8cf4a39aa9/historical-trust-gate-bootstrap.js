"use strict";

/*
  Historical trust gate for DEMO trade-candidate creation.

  This is deliberately narrow: it does NOT rewrite BUY/SELL analyses and it
  does NOT change the global strength threshold. It only prevents automatic
  trade candidates for classes that were persistently far below random on
  both the 7-day and 30-day production audit.

  Evidence captured 2026-08-24:
    M15 SELL 60-69:  7d 21.92% (n=73), 30d 27.55% (n=98)
    M15 SELL 80-89:  7d 30.58% (n=121),30d 32.03% (n=128)
    M30 SELL 60-69:  7d  8.33% (n=36), 30d  8.33% (n=36)
    M30 SELL 80-89:  7d 17.07% (n=82), 30d 14.29% (n=98)

  Strong classes (for example M15 SELL 90-100) are intentionally untouched.
  Fast-entry is therefore preserved unless a candidate falls into one of the
  statistically toxic buckets below. Safety/trust gates remain allowed to
  veto a fast entry.
*/

const { Pool } = require("pg");

const PATCHED = Symbol.for("xauusd.historical.trust.gate.v1");
const ENABLED = !/^(0|false|off)$/i.test(
  String(process.env.HISTORICAL_TRUST_GATE_ENABLED ?? "1")
);

const BLOCKED = Object.freeze({
  "M15|SELL|60-69": Object.freeze({ acc7d: 21.92, n7d: 73, acc30d: 27.55, n30d: 98 }),
  "M15|SELL|80-89": Object.freeze({ acc7d: 30.58, n7d: 121, acc30d: 32.03, n30d: 128 }),
  "M30|SELL|60-69": Object.freeze({ acc7d: 8.33, n7d: 36, acc30d: 8.33, n30d: 36 }),
  "M30|SELL|80-89": Object.freeze({ acc7d: 17.07, n7d: 82, acc30d: 14.29, n30d: 98 }),
});

function strengthBucket(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return "UNKNOWN";
  if (n < 70) return "60-69";
  if (n < 80) return "70-79";
  if (n < 90) return "80-89";
  return "90-100";
}

function assessCandidateTrust(values) {
  if (!Array.isArray(values) || values.length < 5) {
    return { allow: true, reason: "UNMAPPED_VALUES" };
  }

  const timeframe = String(values[2] || "").toUpperCase();
  const side = String(values[3] || "").toUpperCase();
  const strength = Number(values[4]);
  const bucket = strengthBucket(strength);
  const key = `${timeframe}|${side}|${bucket}`;
  const evidence = BLOCKED[key] || null;

  if (!evidence) {
    return { allow: true, key, timeframe, side, strength, bucket };
  }

  return {
    allow: false,
    key,
    timeframe,
    side,
    strength,
    bucket,
    evidence,
    reason: "HISTORICAL_TRUST_BELOW_35PCT_7D_30D",
  };
}

if (ENABLED && !Pool.prototype[PATCHED]) {
  const originalQuery = Pool.prototype.query;

  Pool.prototype.query = async function historicalTrustQuery(text, values, ...rest) {
    const sql = typeof text === "string" ? text : String(text?.text || "");
    if (!/INSERT\s+INTO\s+trade_candidates/i.test(sql)) {
      return originalQuery.call(this, text, values, ...rest);
    }

    const trust = assessCandidateTrust(values);
    if (!trust.allow) {
      console.warn(
        `⛔ CANDIDATE BLOCKED | HISTORICAL_TRUST | ${trust.key} | ` +
        `strength=${trust.strength} | ` +
        `acc7d=${trust.evidence.acc7d}% n7d=${trust.evidence.n7d} | ` +
        `acc30d=${trust.evidence.acc30d}% n30d=${trust.evidence.n30d}`
      );
      return { rows: [], rowCount: 0, command: "INSERT" };
    }

    return originalQuery.call(this, text, values, ...rest);
  };

  Object.defineProperty(Pool.prototype, PATCHED, { value: true, enumerable: false });
  console.log(
    "✅ HISTORICAL TRUST GATE V1: toxic M15/M30 SELL buckets blocked for DEMO candidates"
  );
} else if (!ENABLED) {
  console.warn("ℹ️ HISTORICAL TRUST GATE V1: disabled by environment");
}

module.exports = {
  assessCandidateTrust,
  strengthBucket,
  BLOCKED,
  ENABLED,
};
