# AI COUNCIL — NEXT TASKS (2026-08-20)

These are advisory/shadow tasks only. No advisor is allowed to change live/demo execution or promote a model directly.

## Task A — News-source audit for XAU/USD
Ask every available advisor independently to review the current news architecture and return:
- missing primary sources that materially affect XAU/USD;
- source freshness and timestamp risks;
- duplicate/corroboration logic;
- PREVIEW vs REAL_RELEASE distinction;
- suggested impact decay by M1/M5/M15/M30/H1;
- high-impact no-trade windows;
- false-positive/noise examples;
- a deterministic test plan before any source can influence signal strength.

Priority source candidates for verification:
- U.S. BEA Personal Income & Outlays / PCE and GDP;
- U.S. Treasury press/auction/rate/TIC data where a direct XAU bridge exists;
- PBoC official reserve/monetary-policy material;
- World Gold Council central-bank/ETF/demand data;
- LBMA market data/context where automated use is permitted.

## Task B — Code review / patch proposal
Give advisors a compact architecture map plus relevant source files and recent failure logs. Each advisor should return:
1. bug/risk finding;
2. minimal patch idea;
3. tests that would prove the patch;
4. rollback condition;
5. whether the change affects analytics only, DEMO execution, risk, or model training.

Do NOT automatically merge AI-generated code. Coordinator may convert an agreed proposal into a candidate patch only after deterministic syntax/unit/shadow tests.

## Task C — Brian Shannon partial-book review
Source status: user supplied a scanned copy of *Technical Analysis Using Multiple Timeframes* (2008), but the available PDF ends at printed page 136 and does not contain Chapters 15–18. Mark every result PARTIAL.

Do not commit or redistribute the raw copyrighted scan. The ChatGPT-side reader may create original private chapter notes/hypotheses from the user-provided copy. Advisors receive only those distilled notes unless a temporary provider upload is explicitly implemented without storing the source in GitHub.

Ask each available advisor independently to produce:
- market-structure principles;
- multi-timeframe hierarchy and trend-alignment ideas;
- pullback vs reversal distinctions;
- support/resistance and trend-stage concepts;
- news/price-reaction lessons from the available chapters;
- exceptions/failure modes;
- direct mappings to M1/M5/M15/M30/H1 XAU/USD;
- measurable causal features/rules;
- hypotheses that can be falsified by OOS/chronological tests.

Do not claim Chapters 15–18 were reviewed until a complete copy is supplied.

## Task D — Independent synthesis
Coordinator compares advisor responses and labels every proposal:
- AGREEMENT: supported independently by >=2 advisors;
- DISAGREEMENT: advisors conflict, needs test;
- SOURCE_DERIVED: directly supported by available source notes;
- INFERENCE: advisor extrapolation, must not be presented as book content;
- TESTABLE_NOW: can be evaluated on existing XAU/USD data;
- NEEDS_DATA: cannot be tested yet.

The only path from AI idea to production is:
proposal -> deterministic implementation -> leakage check -> OOS -> chronological blocks -> shadow/demo -> objective acceptance -> optional promotion.

## Provider reality on 2026-08-20
- Gemini: configured, but may be temporarily quota/rate-limited.
- DeepSeek: provider code exists; DEEPSEEK_API_KEY is not currently configured in Railway.
- Claude: provider code exists; ANTHROPIC_API_KEY is not currently configured in Railway.

Never report a provider as having reviewed a task unless a successful provider response is actually stored/logged.
