"use strict";

const TelegramBot = require("node-telegram-bot-api");
const { Pool } = require("pg");
const { callProvider } = require("./ai-providers");
const { enqueueCouncilTask } = require("./ai-council-persistent");
const {
  processCouncilTask: processCouncilTaskDynamic,
  getCouncilSnapshot,
  configuredAdvisorList,
} = require("./ai-council-dynamic");

const ENABLED = /^(1|true|yes|on)$/i.test(String(process.env.VIRUS_AI_CHAT_ENABLED || "0"));
const OWNER_CHAT_ID = String(process.env.TELEGRAM_OWNER_CHAT_ID || "").trim();
const DATABASE_URL = String(process.env.DATABASE_URL || process.env.DATABASE_PUBLIC_URL || "").trim();
const MAX_HISTORY = Math.max(2, Math.min(12, Number(process.env.VIRUS_AI_CHAT_HISTORY || 6)));
const MAX_INPUT = Math.max(500, Math.min(8000, Number(process.env.VIRUS_AI_CHAT_MAX_INPUT || 4000)));
const PROVIDER = String(process.env.VIRUS_AI_CHAT_PROVIDER || "coordinator").trim().toLowerCase();
// "single" keeps the original one-model behaviour. "council" puts the question
// to the whole Council and returns one agreed answer, which is what the owner
// asked for: everyone at one table, one reply back.
const MODE = /^council$/i.test(String(process.env.VIRUS_AI_CHAT_MODE || "single").trim())
  ? "council"
  : "single";
// A full Council round is two passes per advisor plus synthesis. Past this the
// owner gets the single-model answer instead of silence.
const COUNCIL_TIMEOUT_MS = Math.max(
  60_000,
  Math.min(900_000, Number(process.env.VIRUS_AI_CHAT_COUNCIL_TIMEOUT_MS || 300_000))
);

const pool = DATABASE_URL ? new Pool({ connectionString: DATABASE_URL, max: 2, idleTimeoutMillis: 15000 }) : null;
const historyByChat = new Map();
const inFlight = new Set();

function ownerAllowed(chatId) {
  if (!OWNER_CHAT_ID) return false;
  return String(chatId) === OWNER_CHAT_ID;
}

function cleanText(value) {
  return String(value || "").replace(/\u0000/g, "").trim().slice(0, MAX_INPUT);
}

function shouldHandle(message) {
  if (!ENABLED || !message || !message.chat) return false;
  if (!ownerAllowed(message.chat.id)) return false;
  const text = cleanText(message.text);
  if (!text || text.startsWith("/")) return false;
  if (message.via_bot || message.forward_origin) return false;
  return true;
}

async function queryOne(sql) {
  if (!pool) return null;
  try {
    const { rows } = await pool.query(sql);
    return rows[0] || null;
  } catch {
    return null;
  }
}

async function runtimeSnapshot() {
  const [m1, candidate, trade, worker] = await Promise.all([
    queryOne(`SELECT candle_time, close, source FROM xauusd_candles WHERE timeframe='M1' ORDER BY candle_time DESC LIMIT 1`),
    queryOne(`SELECT id, created_at, expires_at, symbol, timeframe, side, strength, status FROM trade_candidates ORDER BY created_at DESC LIMIT 1`),
    queryOne(`SELECT id, created_at, opened_at, closed_at, symbol, timeframe, side, lot, entry_price, exit_price, profit, status, close_reason FROM demo_trades ORDER BY created_at DESC LIMIT 1`),
    queryOne(`SELECT key, value, updated_at FROM demo_worker_state ORDER BY updated_at DESC LIMIT 1`),
  ]);
  return { m1, candidate, trade, worker, captured_at: new Date().toISOString() };
}

function historyFor(chatId) {
  const key = String(chatId);
  const items = historyByChat.get(key) || [];
  return items.slice(-MAX_HISTORY);
}

function pushHistory(chatId, role, text) {
  const key = String(chatId);
  const items = historyByChat.get(key) || [];
  items.push({ role, text: String(text || "").slice(0, 6000) });
  historyByChat.set(key, items.slice(-(MAX_HISTORY * 2)));
}

function buildPrompt(userText, history, snapshot) {
  return [
    "You are VIRUS AI, the owner's conversational interface for a cloud-first trading research and DEMO execution project.",
    "Reply in Russian unless the owner explicitly asks for another language.",
    "Be concise, practical, and factual. Never invent live market data, trades, balances, connectivity, or completed actions.",
    "If runtime evidence is missing or stale, explicitly say that it cannot be confirmed.",
    "Current policy: REAL trading is disabled. Discuss and operate only within research, shadow, paper, or DEMO contexts unless production policy is explicitly changed later by the owner through a separate guarded process.",
    "The current launch plan is: primary DEMO stream focuses on gold; a secondary DEMO stream may later select another market autonomously. Target starting DEMO balance for testing is 100 units in the account currency.",
    "Do not claim that broker account balance can be changed through the trading API unless runtime/broker evidence explicitly confirms it.",
    "When asked why a trade was or was not taken, use only the supplied runtime snapshot and say what is missing.",
    "",
    "RUNTIME SNAPSHOT (may contain nulls; treat null as unavailable):",
    JSON.stringify(snapshot),
    "",
    "RECENT CHAT:",
    JSON.stringify(history),
    "",
    "OWNER MESSAGE:",
    userText,
  ].join("\n");
}

function buildCouncilTaskId(chatId, now = Date.now()) {
  const safeChat = String(chatId).replace(/[^0-9A-Za-z_-]+/g, "_");
  return `CHAT_${safeChat}_${Number(now) || Date.now()}`.toUpperCase();
}

// Deliberately NOT buildMasterContextSnapshot(): that is ~94k characters of
// frozen project files, sent once per advisor per phase. A chat question needs
// the live runtime state and a short brief, nothing more.
function buildCompactContext(snapshot, invited = []) {
  return [
    "VIRUS AI project. REAL trading is disabled; research, shadow and DEMO only.",
    "Answer the owner's question from the runtime snapshot below. Never invent",
    "market data, balances, trades or completed actions. Say plainly when",
    "something cannot be confirmed from the snapshot.",
    "",
    // Asked for by the Council itself: without this it could not answer who was
    // sitting with it, and correctly refused to guess. This is who was INVITED;
    // who actually answered is appended to the reply afterwards, because it is
    // only known once every advisor has finished.
    `COUNCIL SEATS INVITED TO THIS TASK: ${invited.join(", ") || "unknown"}`,
    "Do not claim which of them answered - you cannot see that from here.",
    "",
    "RUNTIME SNAPSHOT (null means unavailable):",
    JSON.stringify(snapshot),
  ].join("\n");
}

// The Council's final_plan is long and written for engineers. The owner asked
// for the short version in plain Russian, so it gets one compression pass.
function buildDigestPrompt(question, finalPlan, readyAdvisors = []) {
  return [
    "Ниже — совместный вердикт совета ИИ по вопросу владельца.",
    "Перескажи его владельцу простым русским языком, коротко.",
    "Правила: не больше 12 строк; без технического жаргона без необходимости;",
    "сначала прямой ответ на вопрос, потом что это значит, потом что дальше.",
    "Не добавляй ничего, чего нет в вердикте. Не выдумывай числа.",
    "Если в вердикте чего-то не хватает — так и скажи одной строкой.",
    "",
    `СОВЕТНИКИ ЗА СТОЛОМ: ${readyAdvisors.join(", ") || "неизвестно"}`,
    "",
    "ВОПРОС ВЛАДЕЛЬЦА:",
    String(question || ""),
    "",
    "ВЕРДИКТ СОВЕТА:",
    String(finalPlan || ""),
  ].join("\n");
}

// Who answered, and for everyone who did not, the one-line reason. Without
// this the reply says only who was at the table, so a Council that quietly
// shrank to one advisor looks the same as one that was always meant to be one.
function seatingLine(result) {
  const ready = result?.readyAdvisors || [];
  const missing = (result?.unavailableAdvisors || [])
    .map((entry) => {
      const reason = String(entry?.error || "").split("\n")[0].trim().slice(0, 80);
      return reason ? `${entry.advisor} (${reason})` : String(entry?.advisor || "");
    })
    .filter(Boolean);

  const lines = [`— за столом: ${ready.join(", ") || "никого"}`];
  if (missing.length) lines.push(`— не ответили: ${missing.join("; ")}`);
  return lines.join("\n");
}

function withTimeout(promise, ms, label) {
  let timer = null;
  const guard = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(`${label}_TIMEOUT`)), ms);
  });
  return Promise.race([promise, guard]).finally(() => clearTimeout(timer));
}

// Returns { text, readyAdvisors } on success, or null when the Council could
// not produce a verdict. Never throws: the caller falls back to one model.
async function councilAnswer(userText, snapshot) {
  const taskId = buildCouncilTaskId(snapshot?.chatId ?? "owner");
  let invited = [];
  try {
    invited = configuredAdvisorList();
  } catch {
    invited = [];
  }
  try {
    await enqueueCouncilTask({
      taskId,
      taskType: "owner_question",
      task: String(userText || ""),
      contextSnapshot: buildCompactContext(snapshot, invited),
    });
    await withTimeout(processCouncilTaskDynamic(taskId), COUNCIL_TIMEOUT_MS, "COUNCIL");
    const result = await getCouncilSnapshot(taskId);
    const finalPlan = String(result?.task?.final_plan || "").trim();
    if (!finalPlan) return null;
    const digest = String(
      (await callProvider(PROVIDER, buildDigestPrompt(userText, finalPlan, result?.readyAdvisors))) || ""
    ).trim();
    return {
      text: digest || finalPlan,
      seating: seatingLine(result),
    };
  } catch (error) {
    console.warn(`VIRUS_AI_CHAT council fallback: ${String(error?.message || error).slice(0, 300)}`);
    return null;
  }
}

async function reply(bot, message) {
  const chatId = message.chat.id;
  const key = String(chatId);
  if (inFlight.has(key)) {
    await bot.sendMessage(chatId, "⏳ Я уже обрабатываю предыдущее сообщение.");
    return;
  }
  inFlight.add(key);
  const startedAt = Date.now();
  try {
    await bot.sendChatAction(chatId, "typing").catch(() => {});
    const text = cleanText(message.text);
    const snapshot = await runtimeSnapshot();
    const history = historyFor(chatId);
    let answer = "";
    let seated = null;

    if (MODE === "council") {
      await bot
        .sendMessage(chatId, "🧠 Спрашиваю совет. Это занимает несколько минут.")
        .catch(() => {});
      const verdict = await councilAnswer(text, { ...snapshot, chatId });
      if (verdict) {
        answer = verdict.text;
        seated = verdict.seating;
      }
    }

    if (!answer) {
      const prompt = buildPrompt(text, history, snapshot);
      answer = String((await callProvider(PROVIDER, prompt)) || "").trim();
      // Say so rather than passing one model's answer off as the Council's.
      if (MODE === "council" && answer) {
        answer = `⚠️ Совет не дал общий вердикт, отвечает одна модель.\n\n${answer}`;
      }
    } else if (seated) {
      answer = `${answer}\n\n${seated}`;
    }

    if (!answer) throw new Error("EMPTY_AI_RESPONSE");
    pushHistory(chatId, "user", text);
    pushHistory(chatId, "assistant", answer);
    const chunks = answer.match(/[\s\S]{1,3900}/g) || [answer];
    for (const chunk of chunks) await bot.sendMessage(chatId, chunk);
    // The success path used to log nothing at all, so "the door never fired"
    // and "the door answered fine" looked identical from outside. That cost
    // three rounds of guesswork before it was noticed.
    console.log(
      `🧠 VIRUS_AI_CHAT replied | mode=${MODE} | council=${seated ? "yes" : "no"} | ` +
        `chars=${answer.length} | ms=${Date.now() - startedAt}`
    );
  } catch (error) {
    console.error(`VIRUS_AI_CHAT error: ${error?.stack || error}`);
    await bot.sendMessage(chatId, "⚠️ VIRUS AI сейчас не смог сформировать ответ. Торговые действия не выполнялись.").catch(() => {});
  } finally {
    inFlight.delete(key);
  }
}

if (ENABLED) {
  const originalEmit = TelegramBot.prototype.emit;
  TelegramBot.prototype.emit = function patchedEmit(eventName, ...args) {
    const result = originalEmit.call(this, eventName, ...args);
    if (eventName === "message") {
      const message = args[0];
      if (shouldHandle(message)) {
        setImmediate(() => reply(this, message));
      }
    }
    return result;
  };
  // mode is the thing an operator cannot otherwise tell from the outside:
  // whether a question goes to the whole Council or to one model.
  console.log(
    `🧠 VIRUS AI CHAT: enabled | mode=${MODE} | provider=${PROVIDER} | owner_only=true` +
      (MODE === "council" ? ` | council_timeout=${Math.round(COUNCIL_TIMEOUT_MS / 1000)}s` : "")
  );
} else {
  console.log("🧠 VIRUS AI CHAT: disabled");
}

module.exports = {
  buildPrompt,
  runtimeSnapshot,
  shouldHandle,
  buildCouncilTaskId,
  buildCompactContext,
  buildDigestPrompt,
  seatingLine,
};
