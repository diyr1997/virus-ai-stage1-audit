from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

from .price_training import Candle
from .price_training_v3 import FeatureState


@dataclass(frozen=True)
class HorizonForecast:
    horizon_min: int
    action: str
    probability_up: float
    confidence: float
    predicted_bps: float
    predicted_price: float
    enabled: bool
    confidence_threshold: float
    min_predicted_magnitude_bps: float
    require_sign_agreement: bool
    calibration_edge_bps: float | None

    def as_dict(self) -> dict[str, object]:
        return {
            "horizon_min": self.horizon_min,
            "action": self.action,
            "probability_up": self.probability_up,
            "confidence": self.confidence,
            "predicted_bps": self.predicted_bps,
            "predicted_price": self.predicted_price,
            "enabled": self.enabled,
            "confidence_threshold": self.confidence_threshold,
            "min_predicted_magnitude_bps": self.min_predicted_magnitude_bps,
            "require_sign_agreement": self.require_sign_agreement,
            "calibration_edge_bps": self.calibration_edge_bps,
        }


class RegimeSelectivePredictor:
    def __init__(self, artifact: dict[str, Any]) -> None:
        self.artifact = artifact
        self.model_version = str(artifact.get("model_version") or "")
        self.market = str(artifact.get("market") or "XAUUSD").upper()
        self.feature_names = tuple(str(v) for v in artifact.get("feature_names", []))
        self.models = dict(artifact.get("models") or {})
        self.horizons = tuple(int(v) for v in artifact.get("horizons_minutes", []))
        if not self.model_version:
            raise ValueError("model artifact has no model_version")
        if self.market != "XAUUSD":
            raise ValueError(f"unexpected market in artifact: {self.market}")
        if not self.horizons or not self.models:
            raise ValueError("model artifact has no horizons/models")
        self.state = FeatureState()
        self.last_timestamp_ms: int | None = None

    @staticmethod
    def _logistic(score: float) -> float:
        score = min(max(score, -30.0), 30.0)
        return 1.0 / (1.0 + math.exp(-score))

    @staticmethod
    def _dot(weights: list[float], features: tuple[float, ...]) -> float:
        if len(weights) != len(features):
            raise ValueError(f"feature/weight size mismatch: {len(features)} != {len(weights)}")
        return sum(weight * value for weight, value in zip(weights, features))

    def ingest(self, candle: Candle, *, emit: bool = True) -> dict[str, object] | None:
        if self.last_timestamp_ms is not None and candle.timestamp_ms <= self.last_timestamp_ms:
            raise ValueError("candles must arrive strictly in chronological order")
        features = self.state.features_and_advance(candle)
        self.last_timestamp_ms = candle.timestamp_ms
        if not emit:
            return None
        if self.feature_names and len(features) != len(self.feature_names):
            raise ValueError(f"runtime feature count mismatch: {len(features)} != {len(self.feature_names)}")

        forecasts: list[HorizonForecast] = []
        for horizon in self.horizons:
            raw = dict(self.models.get(str(horizon)) or {})
            direction_weights = [float(v) for v in raw.get("direction_weights", [])]
            return_weights = [float(v) for v in raw.get("return_weights", [])]
            if not direction_weights or not return_weights:
                raise ValueError(f"missing weights for horizon {horizon}")

            probability_up = self._logistic(self._dot(direction_weights, features))
            confidence = max(probability_up, 1.0 - probability_up)
            return_scale = float(raw.get("return_scale_bps", 20.0))
            predicted_scaled = min(max(self._dot(return_weights, features), -10.0), 10.0)
            predicted_bps = predicted_scaled * return_scale
            predicted_price = candle.close * (1.0 + predicted_bps / 10_000.0)

            signal_filter = dict(raw.get("signal_filter") or {})
            enabled = bool(signal_filter.get("enabled", True))
            confidence_threshold = float(signal_filter.get("confidence_threshold") or 0.5)
            min_magnitude = float(signal_filter.get("min_predicted_magnitude_bps") or 0.0)
            require_sign_agreement = bool(signal_filter.get("require_sign_agreement", False))
            calibration_edge_raw = signal_filter.get("avg_directional_edge_bps")
            calibration_edge = None if calibration_edge_raw is None else float(calibration_edge_raw)
            predicted_up = probability_up >= 0.5
            sign_agrees = predicted_bps != 0.0 and ((predicted_bps > 0.0) == predicted_up)

            if (
                not enabled
                or confidence < confidence_threshold
                or abs(predicted_bps) < min_magnitude
                or (require_sign_agreement and not sign_agrees)
            ):
                action = "WAIT"
            else:
                action = "BUY" if predicted_up else "SELL"

            forecasts.append(
                HorizonForecast(
                    horizon_min=horizon,
                    action=action,
                    probability_up=probability_up,
                    confidence=confidence,
                    predicted_bps=predicted_bps,
                    predicted_price=predicted_price,
                    enabled=enabled,
                    confidence_threshold=confidence_threshold,
                    min_predicted_magnitude_bps=min_magnitude,
                    require_sign_agreement=require_sign_agreement,
                    calibration_edge_bps=calibration_edge,
                )
            )

        actionable = [item for item in forecasts if item.action != "WAIT"]
        if actionable:
            primary = max(
                actionable,
                key=lambda item: (
                    (item.confidence - 0.5)
                    * max(abs(item.predicted_bps), 0.01)
                    * max(item.calibration_edge_bps or 0.01, 0.01)
                ),
            )
        else:
            primary = min(forecasts, key=lambda item: item.horizon_min)

        signal_id = f"{self.model_version}:{candle.timestamp_ms}:{primary.horizon_min}:{primary.action}"
        return {
            "signal_id": signal_id,
            "market": self.market,
            "action": primary.action,
            "confidence": primary.confidence,
            "horizon_min": primary.horizon_min,
            "entry_price": candle.close,
            "exit_price": primary.predicted_price,
            "stop_loss": None,
            "take_profit": None,
            "model_version": self.model_version,
            "timestamp_ms": candle.timestamp_ms,
            "forecast_path": [item.as_dict() for item in forecasts],
        }
