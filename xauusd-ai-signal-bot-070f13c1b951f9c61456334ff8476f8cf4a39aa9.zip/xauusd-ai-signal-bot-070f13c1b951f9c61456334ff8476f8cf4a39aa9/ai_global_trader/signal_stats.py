from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any

try:
    import psycopg
except Exception:  # pragma: no cover
    psycopg = None


@dataclass(frozen=True)
class SignalWindowStats:
    hours: int
    total: int
    correct: int
    wrong: int
    pending: int

    @property
    def accuracy_pct(self) -> float | None:
        resolved = self.correct + self.wrong
        return None if resolved <= 0 else self.correct * 100.0 / resolved


@dataclass(frozen=True)
class TradeWindowStats:
    hours: int
    signals: int
    linked_signals_opened: int
    positions_opened: int
    closed: int
    profit: int
    loss: int
    breakeven: int
    open_now: int
    failed: int
    skipped: int
    net_pnl: float

    @property
    def signal_to_open_pct(self) -> float | None:
        return None if self.signals <= 0 else self.linked_signals_opened * 100.0 / self.signals


def _database_url() -> str:
    return os.getenv("DATABASE_URL", "").strip()


def _connect():
    if psycopg is None:
        raise RuntimeError("psycopg is not installed")
    url = _database_url()
    if not url:
        raise RuntimeError("DATABASE_URL is not configured")
    return psycopg.connect(url, autocommit=True)


def ensure_schema() -> None:
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS ai_global_trader_signal_events (
                id BIGSERIAL PRIMARY KEY,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                market TEXT NOT NULL,
                direction TEXT NOT NULL,
                horizon_minutes INTEGER,
                reference_price DOUBLE PRECISION,
                status TEXT NOT NULL DEFAULT 'PENDING',
                resolved_at TIMESTAMPTZ,
                correct BOOLEAN,
                move_points DOUBLE PRECISION,
                metadata JSONB NOT NULL DEFAULT '{}'::jsonb
            )
            """
        )
        cur.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_ai_global_trader_signal_events_market_created
            ON ai_global_trader_signal_events (market, created_at DESC)
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS ai_global_trader_trade_events (
                id BIGSERIAL PRIMARY KEY,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                market TEXT NOT NULL,
                signal_event_id BIGINT,
                external_signal_id TEXT,
                mt5_ticket BIGINT,
                status TEXT NOT NULL,
                opened_at TIMESTAMPTZ,
                closed_at TIMESTAMPTZ,
                volume DOUBLE PRECISION,
                entry_price DOUBLE PRECISION,
                exit_price DOUBLE PRECISION,
                pnl DOUBLE PRECISION,
                failure_reason TEXT,
                metadata JSONB NOT NULL DEFAULT '{}'::jsonb
            )
            """
        )
        cur.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_ai_global_trader_trade_events_market_created
            ON ai_global_trader_trade_events (market, created_at DESC)
            """
        )
        cur.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_ai_global_trader_trade_events_signal
            ON ai_global_trader_trade_events (signal_event_id)
            """
        )


def record_signal(*, market: str, direction: str, horizon_minutes: int | None = None,
                  reference_price: float | None = None, metadata: dict[str, Any] | None = None) -> int:
    ensure_schema()
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """INSERT INTO ai_global_trader_signal_events
               (market, direction, horizon_minutes, reference_price, metadata)
               VALUES (%s,%s,%s,%s,%s::jsonb) RETURNING id""",
            (market.upper(), direction.upper(), horizon_minutes, reference_price,
             json.dumps(metadata or {}, ensure_ascii=False)),
        )
        row = cur.fetchone()
        if not row:
            raise RuntimeError("failed to create signal event")
        return int(row[0])


def resolve_signal(*, signal_id: int, correct: bool, move_points: float | None = None) -> None:
    ensure_schema()
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """UPDATE ai_global_trader_signal_events
               SET status='RESOLVED', resolved_at=NOW(), correct=%s, move_points=%s
               WHERE id=%s""",
            (correct, move_points, signal_id),
        )


def record_trade_open(*, market: str, signal_event_id: int | None, external_signal_id: str | None,
                      mt5_ticket: int, volume: float, entry_price: float,
                      metadata: dict[str, Any] | None = None) -> int:
    ensure_schema()
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """INSERT INTO ai_global_trader_trade_events
               (market, signal_event_id, external_signal_id, mt5_ticket, status, opened_at,
                volume, entry_price, metadata)
               VALUES (%s,%s,%s,%s,'OPEN',NOW(),%s,%s,%s::jsonb) RETURNING id""",
            (market.upper(), signal_event_id, external_signal_id, mt5_ticket, volume, entry_price,
             json.dumps(metadata or {}, ensure_ascii=False)),
        )
        row = cur.fetchone()
        if not row:
            raise RuntimeError("failed to create trade event")
        return int(row[0])


def resolve_trade(*, trade_event_id: int, pnl: float, exit_price: float | None = None) -> None:
    ensure_schema()
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """UPDATE ai_global_trader_trade_events
               SET status='CLOSED', closed_at=NOW(), pnl=%s, exit_price=%s
               WHERE id=%s""",
            (pnl, exit_price, trade_event_id),
        )


def record_trade_failure(*, market: str, signal_event_id: int | None, external_signal_id: str | None,
                         reason: str, skipped: bool = False,
                         metadata: dict[str, Any] | None = None) -> int:
    ensure_schema()
    status = "SKIPPED" if skipped else "FAILED"
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """INSERT INTO ai_global_trader_trade_events
               (market, signal_event_id, external_signal_id, status, failure_reason, metadata)
               VALUES (%s,%s,%s,%s,%s,%s::jsonb) RETURNING id""",
            (market.upper(), signal_event_id, external_signal_id, status, reason,
             json.dumps(metadata or {}, ensure_ascii=False)),
        )
        row = cur.fetchone()
        if not row:
            raise RuntimeError("failed to create trade failure event")
        return int(row[0])


def stats_for_hours(hours: int, *, market: str = "XAUUSD") -> SignalWindowStats:
    if hours <= 0:
        raise ValueError("hours must be positive")
    ensure_schema()
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """SELECT COUNT(*)::bigint,
                      COUNT(*) FILTER (WHERE correct IS TRUE)::bigint,
                      COUNT(*) FILTER (WHERE correct IS FALSE)::bigint,
                      COUNT(*) FILTER (WHERE correct IS NULL)::bigint
               FROM ai_global_trader_signal_events
               WHERE market=%s AND created_at >= NOW()-(%s*INTERVAL '1 hour')""",
            (market.upper(), hours),
        )
        row = cur.fetchone() or (0, 0, 0, 0)
    return SignalWindowStats(hours, *(int(v or 0) for v in row))


def trade_stats_for_hours(hours: int, *, market: str = "XAUUSD") -> TradeWindowStats:
    if hours <= 0:
        raise ValueError("hours must be positive")
    ensure_schema()
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """WITH s AS (
                   SELECT COUNT(*)::bigint AS signals
                   FROM ai_global_trader_signal_events
                   WHERE market=%s AND created_at >= NOW()-(%s*INTERVAL '1 hour')
               ), t AS (
                   SELECT
                     COUNT(DISTINCT signal_event_id) FILTER (WHERE status IN ('OPEN','CLOSED'))::bigint AS linked_opened,
                     COUNT(*) FILTER (WHERE status IN ('OPEN','CLOSED'))::bigint AS positions_opened,
                     COUNT(*) FILTER (WHERE status='CLOSED')::bigint AS closed,
                     COUNT(*) FILTER (WHERE status='CLOSED' AND pnl > 0)::bigint AS profit,
                     COUNT(*) FILTER (WHERE status='CLOSED' AND pnl < 0)::bigint AS loss,
                     COUNT(*) FILTER (WHERE status='CLOSED' AND COALESCE(pnl,0)=0)::bigint AS breakeven,
                     COUNT(*) FILTER (WHERE status='OPEN')::bigint AS open_now,
                     COUNT(*) FILTER (WHERE status='FAILED')::bigint AS failed,
                     COUNT(*) FILTER (WHERE status='SKIPPED')::bigint AS skipped,
                     COALESCE(SUM(pnl) FILTER (WHERE status='CLOSED'),0)::double precision AS net_pnl
                   FROM ai_global_trader_trade_events
                   WHERE market=%s AND created_at >= NOW()-(%s*INTERVAL '1 hour')
               )
               SELECT s.signals,t.linked_opened,t.positions_opened,t.closed,t.profit,t.loss,t.breakeven,
                      t.open_now,t.failed,t.skipped,t.net_pnl FROM s CROSS JOIN t""",
            (market.upper(), hours, market.upper(), hours),
        )
        row = cur.fetchone() or (0,) * 11
    return TradeWindowStats(
        hours=hours,
        signals=int(row[0] or 0),
        linked_signals_opened=int(row[1] or 0),
        positions_opened=int(row[2] or 0),
        closed=int(row[3] or 0),
        profit=int(row[4] or 0),
        loss=int(row[5] or 0),
        breakeven=int(row[6] or 0),
        open_now=int(row[7] or 0),
        failed=int(row[8] or 0),
        skipped=int(row[9] or 0),
        net_pnl=float(row[10] or 0.0),
    )


def stats_windows(*, market: str = "XAUUSD", windows: tuple[int, ...] = (1, 6, 24, 168)) -> list[SignalWindowStats]:
    return [stats_for_hours(hours, market=market) for hours in windows]


def trade_stats_windows(*, market: str = "XAUUSD", windows: tuple[int, ...] = (1, 6, 24, 168)) -> list[TradeWindowStats]:
    return [trade_stats_for_hours(hours, market=market) for hours in windows]
