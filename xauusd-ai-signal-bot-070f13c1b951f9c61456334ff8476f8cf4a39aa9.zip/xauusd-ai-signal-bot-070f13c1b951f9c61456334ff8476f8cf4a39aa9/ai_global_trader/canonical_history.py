from __future__ import annotations

import hashlib
import io
import json
import re
import struct
import tempfile
import zipfile
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Callable

PACKAGE_DIR = Path(__file__).resolve().parent
META_DIR = PACKAGE_DIR / "data"
MANIFEST_PATH = META_DIR / "history_manifest.json"
QUARANTINE_PATH = META_DIR / "history_quarantine.json"
QUARANTINE_SHA_PATH = META_DIR / "history_quarantine.sha256"

Progress = Callable[..., None]

# (utc_epoch_ms, struct.pack("!5d", open, high, low, close, volume)).
# The packed form is the same fingerprint the duplicate check compares, so a
# consumer cannot receive values that differ from the ones just verified.
RowSink = Callable[[int, bytes], None]


@dataclass(frozen=True)
class FileScan:
    filename: str
    raw_rows: int
    canonical_rows: int
    identical_duplicates: int
    quarantined_timestamps: int
    first_utc: str | None
    last_utc: str | None


def _load_metadata() -> tuple[dict, dict]:
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    quarantine_bytes = QUARANTINE_PATH.read_bytes()
    expected_sha = QUARANTINE_SHA_PATH.read_text(encoding="ascii").strip().lower()
    actual_sha = hashlib.sha256(quarantine_bytes).hexdigest()
    if actual_sha != expected_sha:
        raise RuntimeError(
            f"quarantine metadata SHA mismatch: expected {expected_sha}, got {actual_sha}"
        )
    return manifest, json.loads(quarantine_bytes.decode("utf-8"))


def _parse_timestamp(value: str, second_field: str | None = None) -> tuple[int, int]:
    digits = re.sub(r"\D", "", value)
    fields_used = 1
    if len(digits) == 8 and second_field is not None:
        time_digits = re.sub(r"\D", "", second_field)
        if len(time_digits) in {4, 6}:
            digits += time_digits
            fields_used = 2
    if len(digits) == 14:
        local_est = datetime.strptime(digits, "%Y%m%d%H%M%S")
    elif len(digits) == 12:
        local_est = datetime.strptime(digits, "%Y%m%d%H%M")
    else:
        raise ValueError(f"unsupported HistData timestamp: {value!r}")
    # HistData textual timestamps are fixed EST UTC-05:00, with no DST.
    utc_dt = (local_est + timedelta(hours=5)).replace(tzinfo=timezone.utc)
    return int(utc_dt.timestamp() * 1000), fields_used


def _parse_row(line: str) -> tuple[int, bytes]:
    delimiter = ";" if ";" in line else "," if "," in line else None
    if delimiter is None:
        raise ValueError("unsupported HistData delimiter")
    parts = [part.strip() for part in line.split(delimiter)]
    if not parts:
        raise ValueError("empty row")
    if parts[0].lower() in {"timestamp", "date", "datetime"}:
        raise ValueError("header")

    if parts[0].upper() == "XAUUSD" and len(parts) >= 6:
        ts, used = _parse_timestamp(parts[1], parts[2] if len(parts) > 2 else None)
        values = parts[1 + used :]
    else:
        ts, used = _parse_timestamp(parts[0], parts[1] if len(parts) > 1 else None)
        values = parts[used:]

    if len(values) < 4:
        raise ValueError("OHLC columns missing")
    try:
        o, h, l, c = (float(values[i]) for i in range(4))
        v = float(values[4]) if len(values) > 4 and values[4] else 0.0
    except (ValueError, IndexError) as exc:
        raise ValueError("invalid OHLCV values") from exc
    # Compact deterministic fingerprint matching numeric OHLCV equality.
    return ts, struct.pack("!5d", o, h, l, c, v)


def _iso(epoch_ms: int | None) -> str | None:
    if epoch_ms is None:
        return None
    return datetime.fromtimestamp(epoch_ms / 1000, tz=timezone.utc).isoformat()


def _materialize_inner(outer: zipfile.ZipFile, name: str) -> tuple[Path, str]:
    digest = hashlib.sha256()
    tmp = tempfile.NamedTemporaryFile(prefix="agt-xau-", suffix=".zip", delete=False)
    path = Path(tmp.name)
    try:
        with outer.open(name, "r") as source, tmp:
            for chunk in iter(lambda: source.read(1024 * 1024), b""):
                digest.update(chunk)
                tmp.write(chunk)
        return path, digest.hexdigest()
    except Exception:
        path.unlink(missing_ok=True)
        raise


def _select_candle_member(inner: zipfile.ZipFile, archive_name: str) -> zipfile.ZipInfo:
    files = [info for info in inner.infolist() if not info.is_dir()]
    csv_members = [info for info in files if info.filename.lower().endswith(".csv")]
    if len(csv_members) == 1:
        return csv_members[0]
    if len(csv_members) > 1:
        raise RuntimeError(f"multiple CSV data members in {archive_name}: {len(csv_members)}")
    for info in files:
        if not info.filename.lower().endswith(".txt"):
            continue
        with inner.open(info, "r") as raw:
            head = raw.read(4096).decode("utf-8-sig", errors="replace")
        if "Status Report" not in head and "Gap of " not in head and "HistData.com (c)" not in head:
            return info
    raise RuntimeError(f"no candle CSV/TXT member in {archive_name}")


def _scan_inner(
    path: Path,
    spec: dict,
    quarantine_ms: set[int],
    sink: RowSink | None = None,
) -> FileScan:
    # ``sink`` receives every row this function counts as canonical, in
    # timestamp order, as (utc_ms, packed_ohlcv). It exists so a loader can
    # write the same rows the verification just validated, instead of
    # reimplementing the dedup and quarantine rules and drifting from them.
    # HistData contains a few repeated blocks that are not strictly ordered.
    # Keep only one compact OHLCV fingerprint per timestamp for this file,
    # then evaluate timestamps in sorted order. Memory stays bounded to one
    # annual/monthly archive rather than the full 6.1M-row history.
    groups: dict[int, list[object]] = {}
    raw_rows = 0

    with zipfile.ZipFile(path, "r") as inner:
        member = _select_candle_member(inner, spec["file"])
        with inner.open(member, "r") as raw:
            text = io.TextIOWrapper(raw, encoding="utf-8-sig", errors="replace", newline="")
            for line_number, raw_line in enumerate(text, start=1):
                line = raw_line.strip()
                if not line:
                    continue
                try:
                    ts, fingerprint = _parse_row(line)
                except ValueError as exc:
                    if str(exc) == "header":
                        continue
                    raise RuntimeError(
                        f"cannot parse {spec['file']} line {line_number}: {exc}"
                    ) from exc
                raw_rows += 1
                group = groups.get(ts)
                if group is None:
                    groups[ts] = [fingerprint, 1, False]
                else:
                    group[1] = int(group[1]) + 1
                    if fingerprint != group[0]:
                        group[2] = True

    canonical_rows = 0
    identical_duplicates = 0
    quarantined_seen: set[int] = set()
    first_canonical: int | None = None
    last_canonical: int | None = None

    for ts in sorted(groups):
        fingerprint, count_obj, conflicting_obj = groups[ts]
        count = int(count_obj)
        conflicting = bool(conflicting_obj)
        if conflicting:
            if ts not in quarantine_ms:
                raise RuntimeError(
                    f"unexpected conflicting rows in {spec['file']} at UTC ms {ts}"
                )
            quarantined_seen.add(ts)
            continue
        canonical_rows += 1
        identical_duplicates += count - 1
        if first_canonical is None:
            first_canonical = ts
        last_canonical = ts
        if sink is not None:
            sink(ts, fingerprint)

    result = FileScan(
        filename=spec["file"],
        raw_rows=raw_rows,
        canonical_rows=canonical_rows,
        identical_duplicates=identical_duplicates,
        quarantined_timestamps=len(quarantined_seen),
        first_utc=_iso(first_canonical),
        last_utc=_iso(last_canonical),
    )
    expected = {
        "raw_rows": spec["raw_rows"],
        "canonical_rows": spec["canonical_rows"],
        "identical_duplicates": spec["identical_duplicate_rows"],
        "quarantined_timestamps": spec["conflict_timestamp_count"],
        "first_utc": spec["first_utc"],
        "last_utc": spec["last_utc"],
    }
    actual = {
        "raw_rows": result.raw_rows,
        "canonical_rows": result.canonical_rows,
        "identical_duplicates": result.identical_duplicates,
        "quarantined_timestamps": result.quarantined_timestamps,
        "first_utc": result.first_utc,
        "last_utc": result.last_utc,
    }
    for key, expected_value in expected.items():
        if actual[key] != expected_value:
            raise RuntimeError(
                f"canonical validation failed for {spec['file']} {key}: expected {expected_value!r}, got {actual[key]!r}"
            )
    missing = quarantine_ms - quarantined_seen
    if missing:
        raise RuntimeError(f"quarantine timestamps missing from {spec['file']}: {len(missing)}")
    return result


def scan_canonical_history(
    bundle_path: Path,
    progress: Progress | None = None,
    sink: RowSink | None = None,
) -> dict[str, object]:
    """Verify the bundle against the manifest, optionally emitting its rows.

    Without ``sink`` this is a pure audit. With one, the same pass hands every
    canonical row to the caller. Either way the function still raises on the
    first mismatch, so a loader that streams rows into a database is writing
    data that has already cleared the per-file SHA256, the per-file counters
    and the global totals.
    """
    manifest, quarantine = _load_metadata()
    specs = manifest["files"]
    expected_names = [item["file"] for item in specs]
    quarantine_by_file = {
        name: {int(value) for value in values}
        for name, values in quarantine.get("files", {}).items()
    }
    total_raw = total_canonical = total_duplicates = total_quarantined = 0
    first_utc: str | None = None
    last_utc: str | None = None

    with zipfile.ZipFile(bundle_path, "r") as outer:
        names = [info.filename for info in outer.infolist() if not info.is_dir()]
        if set(names) != set(expected_names) or len(names) != len(expected_names):
            raise RuntimeError("outer canonical bundle members do not match manifest")

        for index, spec in enumerate(specs, start=1):
            inner_path, actual_sha = _materialize_inner(outer, spec["file"])
            try:
                if actual_sha != spec["sha256"]:
                    raise RuntimeError(
                        f"inner ZIP SHA mismatch for {spec['file']}: expected {spec['sha256']}, got {actual_sha}"
                    )
                result = _scan_inner(
                    inner_path,
                    spec,
                    quarantine_by_file.get(spec["file"], set()),
                    sink=sink,
                )
            finally:
                inner_path.unlink(missing_ok=True)

            total_raw += result.raw_rows
            total_canonical += result.canonical_rows
            total_duplicates += result.identical_duplicates
            total_quarantined += result.quarantined_timestamps
            if first_utc is None:
                first_utc = result.first_utc
            last_utc = result.last_utc
            if progress is not None:
                progress(
                    "canonical_file_verified",
                    file=spec["file"],
                    file_index=index,
                    total_files=len(specs),
                    raw_rows=result.raw_rows,
                    canonical_rows=result.canonical_rows,
                )

    actual_totals = {
        "total_raw_rows": total_raw,
        "total_rows": total_canonical,
        "identical_duplicate_rows_removed": total_duplicates,
        "quarantined_conflicting_timestamps": total_quarantined,
        "first_utc": first_utc,
        "last_utc": last_utc,
    }
    expected_totals = {
        "total_raw_rows": manifest["total_raw_rows"],
        "total_rows": manifest["total_rows"],
        "identical_duplicate_rows_removed": manifest["identical_duplicate_rows_removed"],
        "quarantined_conflicting_timestamps": manifest["quarantined_conflicting_timestamps"],
        "first_utc": manifest["first_utc"],
        "last_utc": manifest["last_utc"],
    }
    for key, expected_value in expected_totals.items():
        if actual_totals[key] != expected_value:
            raise RuntimeError(
                f"global canonical validation failed for {key}: expected {expected_value!r}, got {actual_totals[key]!r}"
            )

    return {
        "files": len(specs),
        "raw_rows": total_raw,
        "canonical_rows": total_canonical,
        "identical_duplicates_removed": total_duplicates,
        "quarantined_timestamps": total_quarantined,
        "first_utc": first_utc,
        "last_utc": last_utc,
        "legacy_logic_loaded": False,
    }
