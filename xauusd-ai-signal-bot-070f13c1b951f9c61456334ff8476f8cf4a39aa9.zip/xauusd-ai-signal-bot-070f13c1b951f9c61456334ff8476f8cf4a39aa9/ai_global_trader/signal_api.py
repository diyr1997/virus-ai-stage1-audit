from __future__ import annotations

import hmac
import json
import os
import threading
from dataclasses import dataclass, field
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable

from .live_inference import RegimeSelectivePredictor
from .model_store import load_model_artifact, promoted_model_artifact
from .price_training import Candle
from .signal_stats import record_signal


@dataclass
class SignalAPIState:
    predictor: RegimeSelectivePredictor | None = None
    latest_signal: dict[str, object] | None = None
    lock: threading.RLock = field(default_factory=threading.RLock)


STATE = SignalAPIState()


def _enabled() -> bool:
    return os.getenv("AI_GLOBAL_TRADER_SIGNAL_API_ENABLED", "false").strip().lower() in {"1", "true", "yes", "on"}


def _worker_token() -> str:
    return os.getenv("AI_GLOBAL_TRADER_WORKER_TOKEN", "").strip()


def _load_live_artifact() -> dict[str, object] | None:
    explicit = os.getenv("AI_GLOBAL_TRADER_LIVE_MODEL_VERSION", "").strip()
    if explicit:
        return load_model_artifact(explicit)
    return promoted_model_artifact(os.getenv("AI_GLOBAL_TRADER_MARKET", "XAUUSD"))


def _ensure_predictor() -> RegimeSelectivePredictor:
    with STATE.lock:
        if STATE.predictor is not None:
            return STATE.predictor
        artifact = _load_live_artifact()
        if artifact is None:
            raise RuntimeError("no approved live model is configured")
        STATE.predictor = RegimeSelectivePredictor(artifact)
        return STATE.predictor


def _candle(raw: dict[str, Any]) -> Candle:
    return Candle(
        timestamp_ms=int(raw["timestamp_ms"]),
        open=float(raw["open"]),
        high=float(raw["high"]),
        low=float(raw["low"]),
        close=float(raw["close"]),
        volume=float(raw.get("volume") or 0.0),
    )


def _is_authorized(header: str | None) -> bool:
    expected = _worker_token()
    if not expected:
        return False
    supplied = (header or "").strip()
    prefix = "Bearer "
    if not supplied.startswith(prefix):
        return False
    return hmac.compare_digest(supplied[len(prefix) :], expected)


def _record_actionable(signal: dict[str, object]) -> None:
    action = str(signal.get("action") or "WAIT").upper()
    if action not in {"BUY", "SELL"}:
        return
    try:
        db_id = record_signal(
            market=str(signal.get("market") or "XAUUSD"),
            direction=action,
            horizon_minutes=int(signal.get("horizon_min") or 0) or None,
            reference_price=float(signal.get("entry_price")) if signal.get("entry_price") is not None else None,
            metadata={
                "external_signal_id": signal.get("signal_id"),
                "confidence": signal.get("confidence"),
                "model_version": signal.get("model_version"),
                "forecast_path": signal.get("forecast_path"),
            },
        )
        signal["stats_signal_id"] = db_id
    except Exception:
        # Signal delivery must not fail because optional statistics storage is unavailable.
        pass


class Handler(BaseHTTPRequestHandler):
    server_version = "AI-Global-Trader-Signal-API/1.0"

    def log_message(self, _format: str, *_args: object) -> None:
        return

    def _send(self, status: int, payload: dict[str, object]) -> None:
        body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _json_body(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0 or length > 2_000_000:
            raise ValueError("invalid request body size")
        raw = self.rfile.read(length)
        payload = json.loads(raw.decode("utf-8"))
        if not isinstance(payload, dict):
            raise ValueError("JSON object required")
        return payload

    def _require_auth(self) -> bool:
        if _is_authorized(self.headers.get("Authorization")):
            return True
        self._send(HTTPStatus.UNAUTHORIZED, {"error": "unauthorized"})
        return False

    def do_GET(self) -> None:  # noqa: N802
        if self.path == "/health":
            self._send(HTTPStatus.OK, {"ok": True, "system": "AI Global Trader"})
            return
        if self.path == "/api/v1/signals/latest":
            if not self._require_auth():
                return
            with STATE.lock:
                signal = STATE.latest_signal
            self._send(HTTPStatus.OK, {"signal": signal})
            return
        self._send(HTTPStatus.NOT_FOUND, {"error": "not_found"})

    def do_POST(self) -> None:  # noqa: N802
        if not self._require_auth():
            return
        try:
            payload = self._json_body()
            predictor = _ensure_predictor()

            if self.path == "/api/v1/market/warmup":
                raw_candles = payload.get("candles")
                if not isinstance(raw_candles, list) or not raw_candles:
                    raise ValueError("candles array required")
                if len(raw_candles) > 500:
                    raise ValueError("too many warmup candles")
                with STATE.lock:
                    for item in raw_candles:
                        if not isinstance(item, dict):
                            raise ValueError("invalid candle")
                        predictor.ingest(_candle(item), emit=False)
                self._send(HTTPStatus.OK, {"ok": True, "warmup_candles": len(raw_candles), "model_version": predictor.model_version})
                return

            if self.path == "/api/v1/market/candle":
                item = payload.get("candle")
                if not isinstance(item, dict):
                    raise ValueError("candle object required")
                with STATE.lock:
                    signal = predictor.ingest(_candle(item), emit=True)
                    if signal is None:
                        raise RuntimeError("predictor returned no signal")
                    _record_actionable(signal)
                    STATE.latest_signal = signal
                self._send(HTTPStatus.OK, {"signal": signal})
                return

            self._send(HTTPStatus.NOT_FOUND, {"error": "not_found"})
        except ValueError as exc:
            self._send(HTTPStatus.BAD_REQUEST, {"error": "bad_request", "message": str(exc)})
        except Exception as exc:
            self._send(HTTPStatus.SERVICE_UNAVAILABLE, {"error": type(exc).__name__, "message": str(exc)})


def start_signal_api(log: Callable[..., None]) -> bool:
    if not _enabled():
        log("signal_api_disabled")
        return False
    if not _worker_token():
        log("signal_api_waiting_for_worker_token")
        return False

    port = int(os.getenv("PORT", "8080"))
    server = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    thread = threading.Thread(target=server.serve_forever, name="ai-global-trader-signal-api", daemon=True)
    thread.start()
    log("signal_api_started", port=port)
    return True
