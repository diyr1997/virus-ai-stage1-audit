from __future__ import annotations

import json
import os
import threading
import time
from decimal import Decimal
from typing import Any, Callable

from .binance_demo import BinanceFuturesDemoClient

POLL_SECONDS = max(5, int(os.getenv("AI_GLOBAL_TRADER_BINANCE_DEMO_POLL_SECONDS", "10")))
SYMBOL = os.getenv("AI_GLOBAL_TRADER_BINANCE_DEMO_SYMBOL", "XAUUSDT").strip().upper() or "XAUUSDT"
MAX_SIGNAL_AGE_SECONDS = max(30, int(os.getenv("AI_GLOBAL_TRADER_BINANCE_DEMO_MAX_SIGNAL_AGE_SECONDS", "180")))
TARGET_NOTIONAL_USDT = Decimal(os.getenv("AI_GLOBAL_TRADER_BINANCE_DEMO_TARGET_NOTIONAL_USDT", "10"))


def _enabled() -> bool:
    return os.getenv("AI_GLOBAL_TRADER_BINANCE_DEMO_ENABLED", "false").strip().lower() in {"1", "true", "yes", "on"}


def _connect():
    import psycopg

    url = os.environ.get("DATABASE_URL", "").strip()
    if not url:
        raise RuntimeError("DATABASE_URL is not configured")
    return psycopg.connect(url)


def _ensure_schema() -> None:
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS ai_global_trader_binance_demo_orders (
                id BIGSERIAL PRIMARY KEY,
                prediction_id BIGINT NOT NULL,
                symbol TEXT NOT NULL,
                action TEXT NOT NULL,
                confidence DOUBLE PRECISION NOT NULL,
                signal_time TIMESTAMPTZ NOT NULL,
                horizon_minutes INTEGER NOT NULL,
                quantity TEXT,
                status TEXT NOT NULL DEFAULT 'CLAIMED',
                entry_order_id TEXT,
                entry_avg_price DOUBLE PRECISION,
                opened_at TIMESTAMPTZ,
                target_close_at TIMESTAMPTZ,
                exit_order_id TEXT,
                exit_avg_price DOUBLE PRECISION,
                closed_at TIMESTAMPTZ,
                error TEXT,
                entry_response JSONB,
                exit_response JSONB,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                UNIQUE (prediction_id, symbol)
            )
            """
        )
        cur.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_ai_gt_binance_demo_status
            ON ai_global_trader_binance_demo_orders (symbol, status, target_close_at)
            """
        )
        conn.commit()


def _active_position(client: BinanceFuturesDemoClient) -> dict[str, Any] | None:
    rows = client.positions(SYMBOL)
    for row in rows:
        try:
            amount = Decimal(str(row.get("positionAmt", "0")))
        except Exception:
            continue
        if amount != 0:
            result = dict(row)
            result["_amount"] = amount
            return result
    return None


def _due_open_order():
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """
            SELECT id, action, quantity
            FROM ai_global_trader_binance_demo_orders
            WHERE symbol = %s
              AND status = 'OPEN'
              AND target_close_at <= NOW()
            ORDER BY target_close_at ASC
            LIMIT 1
            """,
            (SYMBOL,),
        )
        return cur.fetchone()


def _close_due(client: BinanceFuturesDemoClient, log: Callable[..., None]) -> bool:
    row = _due_open_order()
    if row is None:
        return False
    record_id, action, quantity = row
    position = _active_position(client)
    if position is None:
        with _connect() as conn, conn.cursor() as cur:
            cur.execute(
                """
                UPDATE ai_global_trader_binance_demo_orders
                SET status='CLOSED_NO_POSITION', closed_at=NOW(), updated_at=NOW()
                WHERE id=%s
                """,
                (record_id,),
            )
            conn.commit()
        log("binance_demo_position_missing_at_exit", record_id=record_id, symbol=SYMBOL)
        return True

    amount = Decimal(position["_amount"])
    exit_side = "SELL" if amount > 0 else "BUY"
    close_qty = format(abs(amount), "f").rstrip("0").rstrip(".") or str(quantity)
    response = client.market_order(symbol=SYMBOL, side=exit_side, quantity=close_qty, reduce_only=True)
    avg_price = float(response.get("avgPrice") or 0.0) or None
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """
            UPDATE ai_global_trader_binance_demo_orders
            SET status='CLOSED', exit_order_id=%s, exit_avg_price=%s,
                exit_response=%s::jsonb, closed_at=NOW(), updated_at=NOW()
            WHERE id=%s
            """,
            (str(response.get("orderId") or ""), avg_price, json.dumps(response, ensure_ascii=False), record_id),
        )
        conn.commit()
    log(
        "binance_demo_exit_filled",
        record_id=record_id,
        symbol=SYMBOL,
        side=exit_side,
        quantity=close_qty,
        avg_price=avg_price,
        real_money=False,
    )
    return True


def _latest_fresh_signal():
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """
            SELECT p.id, p.candle_time, p.action, p.confidence, p.horizon_minutes, p.entry_price, p.target_time
            FROM ai_global_trader_shadow_predictions p
            LEFT JOIN ai_global_trader_binance_demo_orders d
              ON d.prediction_id = p.id AND d.symbol = %s
            WHERE p.action IN ('BUY','SELL')
              AND p.target_time > NOW()
              AND p.candle_time >= NOW() - (%s * INTERVAL '1 second')
              AND d.id IS NULL
            ORDER BY p.candle_time DESC, p.id DESC
            LIMIT 1
            """,
            (SYMBOL, MAX_SIGNAL_AGE_SECONDS),
        )
        return cur.fetchone()


def _claim_signal(row) -> int | None:
    prediction_id, candle_time, action, confidence, horizon, _entry_price, target_time = row
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO ai_global_trader_binance_demo_orders (
                prediction_id, symbol, action, confidence, signal_time,
                horizon_minutes, target_close_at, status
            ) VALUES (%s,%s,%s,%s,%s,%s,%s,'CLAIMED')
            ON CONFLICT (prediction_id, symbol) DO NOTHING
            RETURNING id
            """,
            (prediction_id, SYMBOL, action, confidence, candle_time, horizon, target_time),
        )
        claimed = cur.fetchone()
        conn.commit()
    return None if claimed is None else int(claimed[0])


def _open_for_signal(client: BinanceFuturesDemoClient, log: Callable[..., None]) -> bool:
    if _active_position(client) is not None:
        return False
    row = _latest_fresh_signal()
    if row is None:
        return False
    record_id = _claim_signal(row)
    if record_id is None:
        return False
    prediction_id, candle_time, action, confidence, horizon, entry_price, target_time = row
    try:
        quantity = client.minimum_market_quantity(SYMBOL, target_notional_usdt=TARGET_NOTIONAL_USDT)
        response = client.market_order(symbol=SYMBOL, side=str(action), quantity=quantity)
        avg_price = float(response.get("avgPrice") or 0.0) or None
        with _connect() as conn, conn.cursor() as cur:
            cur.execute(
                """
                UPDATE ai_global_trader_binance_demo_orders
                SET quantity=%s, status='OPEN', entry_order_id=%s,
                    entry_avg_price=%s, entry_response=%s::jsonb,
                    opened_at=NOW(), updated_at=NOW()
                WHERE id=%s
                """,
                (quantity, str(response.get("orderId") or ""), avg_price, json.dumps(response, ensure_ascii=False), record_id),
            )
            conn.commit()
        log(
            "binance_demo_entry_filled",
            record_id=record_id,
            prediction_id=prediction_id,
            symbol=SYMBOL,
            action=action,
            confidence=float(confidence),
            signal_time=candle_time.isoformat(),
            horizon_minutes=int(horizon),
            source_xau_entry_price=float(entry_price),
            demo_avg_price=avg_price,
            quantity=quantity,
            target_close_at=target_time.isoformat() if target_time else None,
            transfer_test=True,
            real_money=False,
        )
        return True
    except Exception as exc:
        with _connect() as conn, conn.cursor() as cur:
            cur.execute(
                """
                UPDATE ai_global_trader_binance_demo_orders
                SET status='ERROR', error=%s, updated_at=NOW()
                WHERE id=%s
                """,
                (f"{type(exc).__name__}: {exc}", record_id),
            )
            conn.commit()
        raise


def _loop(log: Callable[..., None]) -> None:
    try:
        _ensure_schema()
        client = BinanceFuturesDemoClient()
        rules = client.symbol_rules(SYMBOL)
        balance = client.balance()
        usdt = next((row for row in balance if str(row.get("asset")) == "USDT"), {}) if isinstance(balance, list) else {}
        log(
            "binance_demo_executor_started",
            symbol=SYMBOL,
            base_url=client.config.base_url,
            orders_enabled=client.config.allow_orders,
            symbol_status=rules.get("status"),
            min_qty=str(rules.get("min_qty")),
            step_size=str(rules.get("step_size")),
            available_usdt=usdt.get("availableBalance"),
            real_money=False,
        )
        last_error: str | None = None
        while True:
            try:
                if client.config.allow_orders:
                    _close_due(client, log)
                    _open_for_signal(client, log)
                last_error = None
            except Exception as exc:
                message = f"{type(exc).__name__}: {exc}"
                if message != last_error:
                    log("binance_demo_executor_error", symbol=SYMBOL, error=type(exc).__name__, message=str(exc), real_money=False)
                    last_error = message
            time.sleep(POLL_SECONDS)
    except Exception as exc:
        log("binance_demo_executor_failed", symbol=SYMBOL, error=type(exc).__name__, message=str(exc), real_money=False)


def start_binance_demo_executor(log: Callable[..., None]) -> bool:
    if not _enabled():
        log("binance_demo_executor_disabled", symbol=SYMBOL)
        return False
    thread = threading.Thread(target=_loop, args=(log,), name="ai-global-binance-demo", daemon=True)
    thread.start()
    log("binance_demo_executor_thread_started", symbol=SYMBOL, real_money=False)
    return True
