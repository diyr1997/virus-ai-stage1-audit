# AI Global Trader

Clean runtime namespace for the new AI system. The runtime is intentionally isolated from the legacy `trading_ai` package. Initial market module: XAU/USD.
