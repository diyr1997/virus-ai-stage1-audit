from __future__ import annotations

import json
import os
import threading
import time
from datetime import datetime, timezone
from typing import Callable

from .live_inference import RegimeSelectivePredictor
from .model_store import load_model_artifact
from .price_training import Candle, MINUTE_MS

POLICY_VERSION = "xauusd-policy-v6-v4-robust"
SOURCE_MODEL_VERSION = "xauusd-price-v4-robust-selector"
POLL_SECONDS = 15
MAX_SIGNAL_CANDLE_AGE_SECONDS = 150
WARMUP_CANDLES = 180


def _enabled() -> bool:
    return os.getenv("AI_GLOBAL_TRADER_SHADOW_V6_ENABLED", "false").strip().lower() in {"1", "true", "yes", "on"}


def _connect():
    import psycopg

    url = os.environ.get("DATABASE_URL", "").strip()
    if not url:
        raise RuntimeError("DATABASE_URL is not configured")
    return psycopg.connect(url)


def _ensure_schema() -> None:
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS ai_global_trader_shadow_sessions (
                policy_version TEXT PRIMARY KEY,
                source_model_version TEXT NOT NULL,
                started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                execution_enabled BOOLEAN NOT NULL DEFAULT FALSE,
                notes JSONB NOT NULL DEFAULT '{}'::jsonb
            )
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS ai_global_trader_shadow_predictions (
                id BIGSERIAL PRIMARY KEY,
                policy_version TEXT NOT NULL,
                source_model_version TEXT NOT NULL,
                candle_time TIMESTAMPTZ NOT NULL,
                action TEXT NOT NULL,
                confidence DOUBLE PRECISION NOT NULL,
                horizon_minutes INTEGER NOT NULL,
                entry_price DOUBLE PRECISION NOT NULL,
                predicted_price DOUBLE PRECISION,
                target_time TIMESTAMPTZ,
                actual_price DOUBLE PRECISION,
                move_bps DOUBLE PRECISION,
                directional_edge_bps DOUBLE PRECISION,
                correct BOOLEAN,
                status TEXT NOT NULL,
                resolved_at TIMESTAMPTZ,
                metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                UNIQUE (policy_version, candle_time)
            )
            """
        )
        cur.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_ai_gt_shadow_pending
            ON ai_global_trader_shadow_predictions (policy_version, status, target_time)
            """
        )
        cur.execute(
            """
            INSERT INTO ai_global_trader_shadow_sessions (
                policy_version, source_model_version, execution_enabled, notes
            ) VALUES (%s, %s, FALSE, %s::jsonb)
            ON CONFLICT (policy_version) DO NOTHING
            """,
            (
                POLICY_VERSION,
                SOURCE_MODEL_VERSION,
                json.dumps(
                    {
                        "future_only": True,
                        "real_execution": False,
                        "demo_execution": False,
                        "purpose": "parallel_future_only_ab_test_of_v4_robust_selector",
                    },
                    ensure_ascii=False,
                ),
            ),
        )
        conn.commit()


def _row_to_candle(row) -> Candle:
    dt = row[0]
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    else:
        dt = dt.astimezone(timezone.utc)
    return Candle(
        timestamp_ms=int(dt.timestamp() * 1000),
        open=float(row[1]),
        high=float(row[2]),
        low=float(row[3]),
        close=float(row[4]),
        volume=float(row[5] or 0.0),
    )


def _latest_closed_candle():
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """
            SELECT candle_time, open, high, low, close, volume, source
            FROM xauusd_candles
            WHERE timeframe = 'M1'
              AND candle_time <= NOW() - INTERVAL '1 minute'
            ORDER BY
                candle_time DESC,
                CASE WHEN UPPER(COALESCE(source, '')) LIKE 'MT5%%' THEN 0 ELSE 1 END,
                COALESCE(source, '')
            LIMIT 1
            """
        )
        return cur.fetchone()


def _warmup_rows(before_or_at) -> list:
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """
            SELECT candle_time, open, high, low, close, volume, source
            FROM (
                SELECT DISTINCT ON (candle_time)
                    candle_time, open, high, low, close, volume, source
                FROM xauusd_candles
                WHERE timeframe = 'M1' AND candle_time <= %s
                ORDER BY
                    candle_time DESC,
                    CASE WHEN UPPER(COALESCE(source, '')) LIKE 'MT5%%' THEN 0 ELSE 1 END,
                    COALESCE(source, '')
                LIMIT %s
            ) q
            ORDER BY candle_time ASC
            """,
            (before_or_at, WARMUP_CANDLES),
        )
        return cur.fetchall()


def _insert_prediction(signal: dict[str, object], candle: Candle) -> bool:
    action = str(signal.get("action") or "WAIT").upper()
    horizon = int(signal.get("horizon_min") or 3)
    candle_time = datetime.fromtimestamp(candle.timestamp_ms / 1000.0, tz=timezone.utc)
    target_time = None if action == "WAIT" else datetime.fromtimestamp(
        (candle.timestamp_ms + horizon * MINUTE_MS) / 1000.0,
        tz=timezone.utc,
    )
    status = "WAIT" if action == "WAIT" else "PENDING"
    metadata = {
        "signal_id": signal.get("signal_id"),
        "forecast_path": signal.get("forecast_path"),
        "future_only": True,
        "execution_enabled": False,
        "ab_test": "v4_robust_vs_v5_consensus",
    }
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO ai_global_trader_shadow_predictions (
                policy_version, source_model_version, candle_time, action,
                confidence, horizon_minutes, entry_price, predicted_price,
                target_time, status, metadata
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s::jsonb)
            ON CONFLICT (policy_version, candle_time) DO NOTHING
            RETURNING id
            """,
            (
                POLICY_VERSION,
                SOURCE_MODEL_VERSION,
                candle_time,
                action,
                float(signal.get("confidence") or 0.5),
                horizon,
                float(signal.get("entry_price") or candle.close),
                None if signal.get("exit_price") is None else float(signal.get("exit_price")),
                target_time,
                status,
                json.dumps(metadata, ensure_ascii=False),
            ),
        )
        inserted = cur.fetchone() is not None
        conn.commit()
    return inserted


def _resolve_pending() -> int:
    resolved = 0
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """
            SELECT id, target_time, action, entry_price
            FROM ai_global_trader_shadow_predictions
            WHERE policy_version = %s
              AND status = 'PENDING'
              AND target_time <= NOW() - INTERVAL '1 minute'
            ORDER BY target_time ASC
            LIMIT 500
            """,
            (POLICY_VERSION,),
        )
        for prediction_id, target_time, action, entry_price in cur.fetchall():
            cur.execute(
                """
                SELECT close
                FROM xauusd_candles
                WHERE timeframe = 'M1' AND candle_time = %s
                ORDER BY CASE WHEN UPPER(COALESCE(source, '')) LIKE 'MT5%%' THEN 0 ELSE 1 END
                LIMIT 1
                """,
                (target_time,),
            )
            row = cur.fetchone()
            if row is None:
                continue
            actual_price = float(row[0])
            entry = float(entry_price)
            move_bps = (actual_price / entry - 1.0) * 10_000.0
            edge_bps = move_bps if str(action).upper() == "BUY" else -move_bps
            cur.execute(
                """
                UPDATE ai_global_trader_shadow_predictions
                SET actual_price=%s, move_bps=%s, directional_edge_bps=%s,
                    correct=%s, status='RESOLVED', resolved_at=NOW()
                WHERE id=%s
                """,
                (actual_price, move_bps, edge_bps, edge_bps > 0.0, prediction_id),
            )
            resolved += 1
        conn.commit()
    return resolved


def _summary() -> dict[str, object]:
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """
            SELECT
                COUNT(*) FILTER (WHERE action IN ('BUY','SELL')),
                COUNT(*) FILTER (WHERE status='RESOLVED'),
                COUNT(*) FILTER (WHERE correct IS TRUE),
                COUNT(*) FILTER (WHERE correct IS FALSE),
                COUNT(*) FILTER (WHERE action='WAIT'),
                AVG(directional_edge_bps) FILTER (WHERE status='RESOLVED')
            FROM ai_global_trader_shadow_predictions
            WHERE policy_version=%s
            """,
            (POLICY_VERSION,),
        )
        row = cur.fetchone() or (0, 0, 0, 0, 0, None)
    resolved = int(row[1] or 0)
    correct = int(row[2] or 0)
    return {
        "actionable": int(row[0] or 0),
        "resolved": resolved,
        "correct": correct,
        "wrong": int(row[3] or 0),
        "wait": int(row[4] or 0),
        "accuracy": None if resolved == 0 else correct / resolved,
        "avg_directional_edge_bps": None if row[5] is None else float(row[5]),
    }


def _loop(log: Callable[..., None]) -> None:
    try:
        _ensure_schema()
        source = load_model_artifact(SOURCE_MODEL_VERSION)
        if source is None:
            raise RuntimeError(f"source model not found: {SOURCE_MODEL_VERSION}")
        predictor = RegimeSelectivePredictor(source)
        latest = _latest_closed_candle()
        if latest is None:
            raise RuntimeError("no closed XAUUSD M1 candle available")
        warmup = _warmup_rows(latest[0])
        for row in warmup:
            predictor.ingest(_row_to_candle(row), emit=False)
        last_ms = _row_to_candle(latest).timestamp_ms
        log(
            "shadow_v6_started",
            policy_version=POLICY_VERSION,
            source_model_version=SOURCE_MODEL_VERSION,
            warmup_candles=len(warmup),
            execution_enabled=False,
            future_only=True,
        )

        next_summary = time.monotonic() + 300.0
        while True:
            try:
                row = _latest_closed_candle()
                if row is not None:
                    candle = _row_to_candle(row)
                    if candle.timestamp_ms > last_ms:
                        age_seconds = max(0.0, time.time() - candle.timestamp_ms / 1000.0 - 60.0)
                        if candle.timestamp_ms - last_ms > MINUTE_MS:
                            source = load_model_artifact(SOURCE_MODEL_VERSION)
                            if source is None:
                                raise RuntimeError("source model disappeared")
                            predictor = RegimeSelectivePredictor(source)
                            warmup = _warmup_rows(row[0])
                            for warm_row in warmup[:-1]:
                                predictor.ingest(_row_to_candle(warm_row), emit=False)
                        if age_seconds <= MAX_SIGNAL_CANDLE_AGE_SECONDS:
                            signal = predictor.ingest(candle, emit=True)
                            if signal is not None and _insert_prediction(signal, candle):
                                log(
                                    "shadow_v6_prediction",
                                    candle_time=datetime.fromtimestamp(candle.timestamp_ms / 1000.0, tz=timezone.utc).isoformat(),
                                    action=signal.get("action"),
                                    confidence=signal.get("confidence"),
                                    horizon_min=signal.get("horizon_min"),
                                    policy_version=POLICY_VERSION,
                                    execution_enabled=False,
                                )
                        else:
                            predictor.ingest(candle, emit=False)
                        last_ms = candle.timestamp_ms
                resolved = _resolve_pending()
                if resolved:
                    log("shadow_v6_resolved", count=resolved, policy_version=POLICY_VERSION)
                if time.monotonic() >= next_summary:
                    log("shadow_v6_summary", policy_version=POLICY_VERSION, **_summary())
                    next_summary = time.monotonic() + 300.0
            except Exception as exc:
                log("shadow_v6_loop_error", error=type(exc).__name__, message=str(exc))
            time.sleep(POLL_SECONDS)
    except Exception as exc:
        log("shadow_v6_failed", error=type(exc).__name__, message=str(exc))


def start_shadow_monitor_v6(log: Callable[..., None]) -> bool:
    if not _enabled():
        log("shadow_v6_disabled")
        return False
    thread = threading.Thread(target=_loop, args=(log,), name="ai-global-trader-shadow-v6", daemon=True)
    thread.start()
    log("shadow_v6_thread_started", policy_version=POLICY_VERSION)
    return True
