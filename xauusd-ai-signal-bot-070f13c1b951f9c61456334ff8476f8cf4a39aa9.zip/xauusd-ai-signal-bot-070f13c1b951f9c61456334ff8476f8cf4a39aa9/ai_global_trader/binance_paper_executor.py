from __future__ import annotations

import json
import os
import threading
import time
import urllib.parse
import urllib.request
from decimal import Decimal
from typing import Any, Callable

POLL_SECONDS = max(3, int(os.getenv("AI_GLOBAL_TRADER_BINANCE_PAPER_POLL_SECONDS", "5")))
SYMBOL = os.getenv("AI_GLOBAL_TRADER_BINANCE_PAPER_SYMBOL", "XAUUSDT").strip().upper() or "XAUUSDT"
BASE_URL = os.getenv("AI_GLOBAL_TRADER_BINANCE_MARKET_BASE_URL", "https://fapi.binance.com").rstrip("/")
MAX_SIGNAL_AGE_SECONDS = max(30, int(os.getenv("AI_GLOBAL_TRADER_BINANCE_PAPER_MAX_SIGNAL_AGE_SECONDS", "180")))
TARGET_NOTIONAL_USDT = Decimal(os.getenv("AI_GLOBAL_TRADER_BINANCE_PAPER_TARGET_NOTIONAL_USDT", "100"))
REQUEST_TIMEOUT = max(3, int(os.getenv("AI_GLOBAL_TRADER_BINANCE_PAPER_HTTP_TIMEOUT", "10")))


def _enabled() -> bool:
    return os.getenv("AI_GLOBAL_TRADER_BINANCE_PAPER_ENABLED", "false").strip().lower() in {"1", "true", "yes", "on"}


def _connect():
    import psycopg

    url = os.environ.get("DATABASE_URL", "").strip()
    if not url:
        raise RuntimeError("DATABASE_URL is not configured")
    return psycopg.connect(url)


def _get(path: str, **params: object) -> Any:
    query = urllib.parse.urlencode({k: v for k, v in params.items() if v is not None})
    url = f"{BASE_URL}{path}"
    if query:
        url += "?" + query
    req = urllib.request.Request(url, headers={"User-Agent": "AI-Global-Trader/xau-paper-v1"})
    with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as response:
        return json.loads(response.read().decode("utf-8"))


def _quote() -> tuple[float, float]:
    row = _get("/fapi/v1/ticker/bookTicker", symbol=SYMBOL)
    bid = float(row.get("bidPrice") or 0.0)
    ask = float(row.get("askPrice") or 0.0)
    if bid <= 0 or ask <= 0 or ask < bid:
        raise RuntimeError(f"invalid {SYMBOL} quote bid={bid} ask={ask}")
    return bid, ask


def _ensure_schema() -> None:
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS ai_global_trader_binance_paper_trades (
                id BIGSERIAL PRIMARY KEY,
                prediction_id BIGINT NOT NULL,
                symbol TEXT NOT NULL,
                action TEXT NOT NULL,
                confidence DOUBLE PRECISION NOT NULL,
                signal_time TIMESTAMPTZ NOT NULL,
                horizon_minutes INTEGER NOT NULL,
                source_xau_entry_price DOUBLE PRECISION,
                notional_usdt DOUBLE PRECISION NOT NULL,
                entry_bid DOUBLE PRECISION NOT NULL,
                entry_ask DOUBLE PRECISION NOT NULL,
                entry_price DOUBLE PRECISION NOT NULL,
                entry_spread_bps DOUBLE PRECISION NOT NULL,
                opened_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                target_close_at TIMESTAMPTZ NOT NULL,
                exit_bid DOUBLE PRECISION,
                exit_ask DOUBLE PRECISION,
                exit_price DOUBLE PRECISION,
                exit_spread_bps DOUBLE PRECISION,
                pnl_bps DOUBLE PRECISION,
                pnl_usdt DOUBLE PRECISION,
                closed_at TIMESTAMPTZ,
                status TEXT NOT NULL DEFAULT 'OPEN',
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                UNIQUE (prediction_id, symbol)
            )
            """
        )
        cur.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_ai_gt_binance_paper_status
            ON ai_global_trader_binance_paper_trades (symbol, status, target_close_at)
            """
        )
        conn.commit()


def _open_trade_row():
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """
            SELECT id, action, entry_price, notional_usdt
            FROM ai_global_trader_binance_paper_trades
            WHERE symbol=%s AND status='OPEN'
            ORDER BY opened_at ASC
            LIMIT 1
            """,
            (SYMBOL,),
        )
        return cur.fetchone()


def _due_trade_row():
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """
            SELECT id, action, entry_price, notional_usdt
            FROM ai_global_trader_binance_paper_trades
            WHERE symbol=%s AND status='OPEN' AND target_close_at <= NOW()
            ORDER BY target_close_at ASC
            LIMIT 1
            """,
            (SYMBOL,),
        )
        return cur.fetchone()


def _latest_fresh_signal():
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """
            SELECT p.id, p.candle_time, p.action, p.confidence,
                   p.horizon_minutes, p.entry_price, p.target_time
            FROM ai_global_trader_shadow_predictions p
            LEFT JOIN ai_global_trader_binance_paper_trades t
              ON t.prediction_id=p.id AND t.symbol=%s
            WHERE p.action IN ('BUY','SELL')
              AND p.target_time > NOW()
              AND p.candle_time >= NOW() - (%s * INTERVAL '1 second')
              AND t.id IS NULL
            ORDER BY p.candle_time DESC, p.id DESC
            LIMIT 1
            """,
            (SYMBOL, MAX_SIGNAL_AGE_SECONDS),
        )
        return cur.fetchone()


def _spread_bps(bid: float, ask: float) -> float:
    mid = (bid + ask) / 2.0
    return ((ask - bid) / mid) * 10000.0 if mid > 0 else 0.0


def _close_due(log: Callable[..., None]) -> bool:
    row = _due_trade_row()
    if row is None:
        return False
    record_id, action, entry_price, notional = row
    bid, ask = _quote()
    exit_price = bid if action == "BUY" else ask
    if action == "BUY":
        pnl_bps = (exit_price / float(entry_price) - 1.0) * 10000.0
    else:
        pnl_bps = (float(entry_price) / exit_price - 1.0) * 10000.0
    pnl_usdt = float(notional) * pnl_bps / 10000.0
    spread_bps = _spread_bps(bid, ask)
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """
            UPDATE ai_global_trader_binance_paper_trades
            SET exit_bid=%s, exit_ask=%s, exit_price=%s, exit_spread_bps=%s,
                pnl_bps=%s, pnl_usdt=%s, closed_at=NOW(), status='CLOSED', updated_at=NOW()
            WHERE id=%s
            """,
            (bid, ask, exit_price, spread_bps, pnl_bps, pnl_usdt, record_id),
        )
        conn.commit()
    log(
        "binance_xau_paper_closed",
        record_id=int(record_id),
        symbol=SYMBOL,
        action=action,
        exit_price=exit_price,
        spread_bps=round(spread_bps, 6),
        pnl_bps=round(pnl_bps, 6),
        pnl_usdt=round(pnl_usdt, 6),
        real_money=False,
        authenticated_api=False,
    )
    return True


def _open_for_signal(log: Callable[..., None]) -> bool:
    if _open_trade_row() is not None:
        return False
    row = _latest_fresh_signal()
    if row is None:
        return False
    prediction_id, candle_time, action, confidence, horizon, source_entry, target_time = row
    bid, ask = _quote()
    entry_price = ask if action == "BUY" else bid
    spread_bps = _spread_bps(bid, ask)
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO ai_global_trader_binance_paper_trades (
                prediction_id, symbol, action, confidence, signal_time, horizon_minutes,
                source_xau_entry_price, notional_usdt, entry_bid, entry_ask,
                entry_price, entry_spread_bps, target_close_at, status
            ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,'OPEN')
            ON CONFLICT (prediction_id, symbol) DO NOTHING
            RETURNING id
            """,
            (
                prediction_id, SYMBOL, action, confidence, candle_time, horizon,
                source_entry, float(TARGET_NOTIONAL_USDT), bid, ask,
                entry_price, spread_bps, target_time,
            ),
        )
        claimed = cur.fetchone()
        conn.commit()
    if claimed is None:
        return False
    record_id = int(claimed[0])
    log(
        "binance_xau_paper_opened",
        record_id=record_id,
        prediction_id=int(prediction_id),
        symbol=SYMBOL,
        action=action,
        confidence=float(confidence),
        signal_time=candle_time.isoformat(),
        horizon_minutes=int(horizon),
        source_xau_entry_price=float(source_entry),
        paper_entry_price=entry_price,
        bid=bid,
        ask=ask,
        spread_bps=round(spread_bps, 6),
        notional_usdt=float(TARGET_NOTIONAL_USDT),
        target_close_at=target_time.isoformat(),
        transfer_test=True,
        real_money=False,
        authenticated_api=False,
    )
    return True


def _loop(log: Callable[..., None]) -> None:
    try:
        _ensure_schema()
        bid, ask = _quote()
        log(
            "binance_xau_paper_started",
            symbol=SYMBOL,
            base_url=BASE_URL,
            bid=bid,
            ask=ask,
            spread_bps=round(_spread_bps(bid, ask), 6),
            target_notional_usdt=float(TARGET_NOTIONAL_USDT),
            real_money=False,
            authenticated_api=False,
        )
        last_error: str | None = None
        while True:
            try:
                _close_due(log)
                _open_for_signal(log)
                last_error = None
            except Exception as exc:
                message = f"{type(exc).__name__}: {exc}"
                if message != last_error:
                    log("binance_xau_paper_error", symbol=SYMBOL, error=type(exc).__name__, message=str(exc), real_money=False)
                    last_error = message
            time.sleep(POLL_SECONDS)
    except Exception as exc:
        log("binance_xau_paper_failed", symbol=SYMBOL, error=type(exc).__name__, message=str(exc), real_money=False)


def start_binance_paper_executor(log: Callable[..., None]) -> bool:
    if not _enabled():
        log("binance_xau_paper_disabled", symbol=SYMBOL)
        return False
    thread = threading.Thread(target=_loop, args=(log,), name="ai-global-binance-xau-paper", daemon=True)
    thread.start()
    log("binance_xau_paper_thread_started", symbol=SYMBOL, real_money=False, authenticated_api=False)
    return True
