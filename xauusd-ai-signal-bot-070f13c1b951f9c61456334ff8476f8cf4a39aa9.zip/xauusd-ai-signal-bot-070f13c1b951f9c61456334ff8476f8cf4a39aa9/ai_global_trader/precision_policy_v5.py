from __future__ import annotations

from collections import Counter
from typing import Any

from .live_inference import RegimeSelectivePredictor
from .price_training import Candle

POLICY_VERSION = "xauusd-policy-v5-precision-consensus"
SOURCE_MODEL_VERSION = "xauusd-price-v3-regime-selective"
ALLOWED_HORIZONS = (3, 5, 10)
MIN_DIRECTION_VOTES = 2


class PrecisionConsensusPredictor:
    """Conservative policy layer for shadow testing only.

    The allowed horizons are the V3 horizons that independently cleared the
    predeclared offline accuracy/edge gate. This policy is not promoted and
    must earn approval on future shadow data collected after the policy freeze.
    """

    def __init__(self, source_artifact: dict[str, Any]) -> None:
        source_version = str(source_artifact.get("model_version") or "")
        if source_version != SOURCE_MODEL_VERSION:
            raise ValueError(
                f"v5 requires source model {SOURCE_MODEL_VERSION}, got {source_version or 'unknown'}"
            )
        self.base = RegimeSelectivePredictor(source_artifact)
        self.model_version = POLICY_VERSION
        self.source_model_version = source_version
        self.market = self.base.market

    def ingest(self, candle: Candle, *, emit: bool = True) -> dict[str, object] | None:
        base_signal = self.base.ingest(candle, emit=emit)
        if base_signal is None:
            return None

        raw_path = [
            dict(item)
            for item in list(base_signal.get("forecast_path") or [])
            if int(item.get("horizon_min") or 0) in ALLOWED_HORIZONS
        ]
        actionable = [
            item for item in raw_path
            if str(item.get("action") or "WAIT").upper() in {"BUY", "SELL"}
        ]
        votes = Counter(str(item.get("action") or "WAIT").upper() for item in actionable)
        direction = None
        if votes:
            candidate, count = votes.most_common(1)[0]
            if count >= MIN_DIRECTION_VOTES:
                direction = candidate

        agreeing = [] if direction is None else [
            item for item in actionable
            if str(item.get("action") or "").upper() == direction
        ]
        if not agreeing:
            return {
                "signal_id": f"{POLICY_VERSION}:{candle.timestamp_ms}:WAIT",
                "market": self.market,
                "action": "WAIT",
                "confidence": max(
                    [float(item.get("confidence") or 0.5) for item in raw_path] or [0.5]
                ),
                "horizon_min": 3,
                "entry_price": candle.close,
                "exit_price": None,
                "stop_loss": None,
                "take_profit": None,
                "model_version": POLICY_VERSION,
                "source_model_version": self.source_model_version,
                "timestamp_ms": candle.timestamp_ms,
                "forecast_path": raw_path,
                "policy": {
                    "allowed_horizons": list(ALLOWED_HORIZONS),
                    "min_direction_votes": MIN_DIRECTION_VOTES,
                    "votes": dict(votes),
                },
            }

        primary = max(
            agreeing,
            key=lambda item: (
                max(float(item.get("confidence") or 0.5) - 0.5, 0.0)
                * max(abs(float(item.get("predicted_bps") or 0.0)), 0.01)
            ),
        )
        mean_confidence = sum(float(item.get("confidence") or 0.5) for item in agreeing) / len(agreeing)
        horizon = int(primary.get("horizon_min") or 3)
        return {
            "signal_id": f"{POLICY_VERSION}:{candle.timestamp_ms}:{horizon}:{direction}",
            "market": self.market,
            "action": direction,
            "confidence": mean_confidence,
            "horizon_min": horizon,
            "entry_price": candle.close,
            "exit_price": float(primary.get("predicted_price") or candle.close),
            "stop_loss": None,
            "take_profit": None,
            "model_version": POLICY_VERSION,
            "source_model_version": self.source_model_version,
            "timestamp_ms": candle.timestamp_ms,
            "forecast_path": raw_path,
            "policy": {
                "allowed_horizons": list(ALLOWED_HORIZONS),
                "min_direction_votes": MIN_DIRECTION_VOTES,
                "votes": dict(votes),
            },
        }
