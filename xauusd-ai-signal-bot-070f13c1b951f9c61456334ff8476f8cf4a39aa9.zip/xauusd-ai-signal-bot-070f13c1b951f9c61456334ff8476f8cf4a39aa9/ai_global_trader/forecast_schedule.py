from __future__ import annotations

import os
from dataclasses import dataclass

# Full forecast horizon contract for AI Global Trader.
# These are model targets, not just chart labels.
DEFAULT_FORECAST_MINUTES = (1, 3, 5, 10, 15, 30, 60)


@dataclass(frozen=True)
class ForecastPoint:
    minute: int


def forecast_minutes() -> tuple[int, ...]:
    raw = os.getenv("AI_GLOBAL_TRADER_FORECAST_MINUTES", "").strip()
    if not raw:
        return DEFAULT_FORECAST_MINUTES

    points: list[int] = []
    for item in raw.split(","):
        item = item.strip()
        if not item:
            continue
        minute = int(item)
        if minute <= 0:
            raise ValueError("forecast minute must be positive")
        points.append(minute)

    unique = tuple(sorted(set(points)))
    if not unique:
        return DEFAULT_FORECAST_MINUTES
    return unique


def forecast_points() -> tuple[ForecastPoint, ...]:
    return tuple(ForecastPoint(minute=value) for value in forecast_minutes())
