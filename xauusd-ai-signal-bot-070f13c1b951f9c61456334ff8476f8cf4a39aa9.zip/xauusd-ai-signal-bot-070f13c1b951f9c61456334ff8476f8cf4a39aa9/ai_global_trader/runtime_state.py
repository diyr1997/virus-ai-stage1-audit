from __future__ import annotations

import threading
from typing import Any

_lock = threading.Lock()
_state: dict[str, Any] = {
    "phase": "BOOTSTRAP",
    "training_progress_pct": 0.0,
    "training_file": None,
    "training_complete": False,
}


def update_state(**fields: Any) -> None:
    with _lock:
        _state.update(fields)


def snapshot_state() -> dict[str, Any]:
    with _lock:
        return dict(_state)
