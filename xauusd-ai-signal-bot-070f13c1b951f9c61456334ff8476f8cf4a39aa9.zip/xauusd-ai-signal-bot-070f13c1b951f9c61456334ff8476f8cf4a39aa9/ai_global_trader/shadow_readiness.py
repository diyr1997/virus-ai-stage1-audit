from __future__ import annotations

import os
import threading
import time
from datetime import datetime, timezone
from typing import Callable

from .model_store import load_model_artifact
from .runtime_state import update_state
from .shadow_monitor import SOURCE_MODEL_VERSION as V5_SOURCE_MODEL_VERSION
from .shadow_monitor_v6 import SOURCE_MODEL_VERSION as V6_SOURCE_MODEL_VERSION

POLL_SECONDS = 60
MAX_READY_M1_AGE_SECONDS = 180


def _env_true(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _connect():
    import psycopg

    url = os.environ.get("DATABASE_URL", "").strip()
    if not url:
        raise RuntimeError("DATABASE_URL is not configured")
    return psycopg.connect(url)


def _latest_m1() -> tuple[datetime | None, float | None]:
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """
            SELECT MAX(candle_time)
            FROM xauusd_candles
            WHERE timeframe = 'M1'
            """
        )
        row = cur.fetchone()
    if not row or row[0] is None:
        return None, None
    candle_time = row[0]
    if candle_time.tzinfo is None:
        candle_time = candle_time.replace(tzinfo=timezone.utc)
    else:
        candle_time = candle_time.astimezone(timezone.utc)
    age = max(0.0, (datetime.now(timezone.utc) - candle_time).total_seconds())
    return candle_time, age


def _execution_enabled() -> bool:
    return any(
        (
            _env_true("AI_GLOBAL_TRADER_BINANCE_DEMO_ENABLED"),
            _env_true("AI_GLOBAL_TRADER_BINANCE_PAPER_ENABLED"),
            _env_true("BINANCE_ALLOW_TESTNET_ORDERS"),
        )
    )


def _model_state() -> tuple[bool, bool]:
    v5 = load_model_artifact(V5_SOURCE_MODEL_VERSION) is not None
    v6 = load_model_artifact(V6_SOURCE_MODEL_VERSION) is not None
    return v5, v6


def _weekend_closed(now_utc: datetime) -> bool:
    """Conservative weekend hint only; freshness remains the actual readiness gate.

    Gold/FX broker reopen minutes can vary. The hint never makes the system READY; it only
    distinguishes a normal weekend gap from a stale feed. Sunday 21:00 UTC onward is treated
    as expected-open territory so a missing first M1 becomes visible as a data issue instead
    of being hidden behind the weekend label.
    """
    weekday = now_utc.weekday()  # Monday=0
    if weekday == 5:  # Saturday
        return True
    if weekday == 6 and now_utc.hour < 21:  # Sunday before expected reopen window
        return True
    if weekday == 4 and now_utc.hour >= 22:  # late Friday after common close window
        return True
    return False


def readiness_snapshot() -> dict[str, object]:
    now_utc = datetime.now(timezone.utc)
    candle_time, age = _latest_m1()
    execution = _execution_enabled()
    v5_loaded, v6_loaded = _model_state()
    weekend_closed = _weekend_closed(now_utc)

    if execution:
        status = "SAFETY_BLOCKED"
        reason = "execution_path_enabled"
    elif not v5_loaded or not v6_loaded:
        status = "MODEL_MISSING"
        missing = []
        if not v5_loaded:
            missing.append(V5_SOURCE_MODEL_VERSION)
        if not v6_loaded:
            missing.append(V6_SOURCE_MODEL_VERSION)
        reason = "missing:" + ",".join(missing)
    elif candle_time is None or age is None:
        status = "MARKET_CLOSED_WEEKEND" if weekend_closed else "WAITING_FOR_FRESH_M1"
        reason = "weekend_closed_no_fresh_m1" if weekend_closed else "no_m1_in_database"
    elif age > MAX_READY_M1_AGE_SECONDS:
        if weekend_closed:
            status = "MARKET_CLOSED_WEEKEND"
            reason = "weekend_closed_wait_for_first_fresh_m1"
        else:
            status = "WAITING_FOR_FRESH_M1"
            reason = "data_stale_while_market_expected_open_or_daily_pause"
    else:
        status = "READY_FOR_SHADOW"
        reason = "fresh_m1_models_loaded_execution_off"

    return {
        "status": status,
        "reason": reason,
        "market_weekend_closed_hint": weekend_closed,
        "now_utc": now_utc.isoformat(),
        "latest_m1_utc": None if candle_time is None else candle_time.isoformat(),
        "latest_m1_age_seconds": age,
        "max_ready_m1_age_seconds": MAX_READY_M1_AGE_SECONDS,
        "v5_source_model": V5_SOURCE_MODEL_VERSION,
        "v5_model_loaded": v5_loaded,
        "v6_source_model": V6_SOURCE_MODEL_VERSION,
        "v6_model_loaded": v6_loaded,
        "execution_enabled": execution,
        "future_only": True,
    }


def _loop(log: Callable[..., None]) -> None:
    last_key: tuple[object, ...] | None = None
    while True:
        try:
            snapshot = readiness_snapshot()
            update_state(shadow_readiness=snapshot)
            key = (
                snapshot["status"],
                snapshot["reason"],
                snapshot["v5_model_loaded"],
                snapshot["v6_model_loaded"],
                snapshot["execution_enabled"],
            )
            if key != last_key:
                log("shadow_readiness", **snapshot)
                last_key = key
        except Exception as exc:
            failure = {
                "status": "READINESS_ERROR",
                "reason": f"{type(exc).__name__}: {exc}",
                "execution_enabled": False,
                "future_only": True,
            }
            update_state(shadow_readiness=failure)
            key = (failure["status"], failure["reason"])
            if key != last_key:
                log("shadow_readiness_error", **failure)
                last_key = key
        time.sleep(POLL_SECONDS)


def start_shadow_readiness(log: Callable[..., None]) -> bool:
    thread = threading.Thread(
        target=_loop,
        args=(log,),
        name="ai-global-trader-shadow-readiness",
        daemon=True,
    )
    thread.start()
    log("shadow_readiness_thread_started", execution_enabled=False)
    return True
