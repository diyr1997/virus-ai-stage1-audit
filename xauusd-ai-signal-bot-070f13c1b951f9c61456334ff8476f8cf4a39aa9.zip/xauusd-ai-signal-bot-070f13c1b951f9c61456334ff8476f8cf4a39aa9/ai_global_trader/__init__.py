"""AI Global Trader clean runtime package.

This package is intentionally isolated from the legacy trading_ai code.
"""
