from __future__ import annotations

import hashlib
import json
import os
import time
import urllib.request
import zipfile
from pathlib import Path

from .canonical_history import scan_canonical_history
from .full_horizon_training import MODEL_VERSION as BASELINE_MODEL_VERSION, train_full_horizon_baseline
from .model_store import latest_model_summary, save_model_artifact
from .price_selector_v4 import MODEL_VERSION as V4_MODEL_VERSION, build_robust_selector_v4
from .price_training_v3 import MODEL_VERSION as V3_MODEL_VERSION, train_regime_selective_v3
from .promotion_gate import evaluate_offline_candidate
from .runtime_state import update_state
from .shadow_monitor import start_shadow_monitor
from .shadow_monitor_v6 import start_shadow_monitor_v6
from .signal_api import start_signal_api
from .telegram_bot import start_telegram_bot

DATA_DIR = Path(os.getenv("AI_GLOBAL_TRADER_DATA_DIR", "/app/data"))
BUNDLE_PATH = DATA_DIR / "XAUUSD_M1_CANONICAL_2009_2026_08.zip"
MODEL_DIR = DATA_DIR / "models"


def log(event: str, **fields: object) -> None:
    payload = {"event": event, **fields}
    print("AI_GLOBAL_TRADER " + json.dumps(payload, ensure_ascii=False, sort_keys=True), flush=True)


def _env_true(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _training_generation() -> str:
    return os.getenv("AI_GLOBAL_TRADER_TRAINING_GENERATION", "V2").strip().upper() or "V2"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def download_history() -> None:
    url = os.environ["TRADING_AI_REMOTE_HISTORY_URL"]
    expected_sha = os.environ["TRADING_AI_REMOTE_HISTORY_SHA256"].strip().lower()
    token = os.environ.get("TRADING_AI_REMOTE_HISTORY_BEARER_TOKEN", "").strip()

    DATA_DIR.mkdir(parents=True, exist_ok=True)
    tmp = BUNDLE_PATH.with_suffix(".zip.part")
    if tmp.exists():
        tmp.unlink()

    headers = {"User-Agent": "AI-Global-Trader/1.0"}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    log("history_download_started", destination=str(BUNDLE_PATH), url=url)
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=120) as response, tmp.open("wb") as out:
        while True:
            chunk = response.read(1024 * 1024)
            if not chunk:
                break
            out.write(chunk)

    actual_sha = sha256_file(tmp)
    if actual_sha != expected_sha:
        tmp.unlink(missing_ok=True)
        raise RuntimeError(f"history SHA256 mismatch: expected {expected_sha}, got {actual_sha}")

    with zipfile.ZipFile(tmp, "r") as zf:
        bad = zf.testzip()
        names = zf.namelist()
        if bad:
            raise RuntimeError(f"corrupt member in canonical bundle: {bad}")
        if len(names) != 25:
            raise RuntimeError(f"unexpected canonical bundle member count: {len(names)}")
        if not all(name.endswith(".zip") and "XAUUSD" in name for name in names):
            raise RuntimeError("unexpected file in canonical XAU/USD bundle")

    tmp.replace(BUNDLE_PATH)
    log(
        "history_verified",
        bytes=BUNDLE_PATH.stat().st_size,
        sha256=actual_sha,
        members=25,
        market=os.getenv("AI_GLOBAL_TRADER_MARKET", "XAUUSD"),
    )


def _training_progress(event: str, **fields: object) -> None:
    log(event, **fields)
    if event == "price_training_started":
        update_state(
            phase="TRAINING",
            training_progress_pct=0.0,
            training_file=None,
            training_complete=False,
            model_version=fields.get("model_version"),
            horizons_minutes=fields.get("horizons"),
        )
    elif event == "training_file_complete":
        update_state(
            phase="TRAINING",
            training_progress_pct=float(fields.get("progress_pct", 0.0)),
            training_file=fields.get("file"),
            training_complete=False,
        )
    elif event in {"v3_selection_calibrated", "v4_selection_calibrated"}:
        update_state(calibration_selection=fields.get("selection"))
    elif event == "price_training_complete":
        update_state(
            phase="TRAINING_COMPLETE",
            training_progress_pct=100.0,
            training_file=None,
            training_complete=True,
            model_version=fields.get("model_version"),
            horizons_minutes=fields.get("horizons_minutes"),
            holdout_metrics=fields.get("holdout_metrics"),
            selective_holdout_metrics=fields.get("selective_holdout_metrics"),
            calibration_selection=fields.get("calibration_selection"),
        )


def _run_training() -> dict[str, object]:
    generation = _training_generation()
    if generation == "V4":
        log("training_generation_selected", generation="V4", model_version=V4_MODEL_VERSION)
        return build_robust_selector_v4(BUNDLE_PATH, MODEL_DIR, progress=_training_progress)
    if generation == "V3":
        log("training_generation_selected", generation="V3", model_version=V3_MODEL_VERSION)
        return train_regime_selective_v3(BUNDLE_PATH, MODEL_DIR, progress=_training_progress)
    if generation == "V2":
        log("training_generation_selected", generation="V2", model_version=BASELINE_MODEL_VERSION)
        return train_full_horizon_baseline(BUNDLE_PATH, MODEL_DIR, progress=_training_progress)
    raise RuntimeError(f"unsupported AI_GLOBAL_TRADER_TRAINING_GENERATION={generation}")


def main() -> int:
    update_state(phase="BOOTSTRAP", training_progress_pct=0.0, training_complete=False)
    log(
        "runtime_started",
        system="AI Global Trader",
        mode=os.getenv("AI_GLOBAL_TRADER_MODE", "bootstrap"),
        market=os.getenv("AI_GLOBAL_TRADER_MARKET", "XAUUSD"),
        legacy_logic_loaded=False,
        training_generation=_training_generation(),
    )
    download_history()

    telegram_enabled = start_telegram_bot(log)
    signal_api_enabled = start_signal_api(log)
    update_state(phase="DATA_VALIDATION", telegram_enabled=telegram_enabled, signal_api_enabled=signal_api_enabled)

    log("canonical_scan_started", legacy_logic_loaded=False)
    scan = scan_canonical_history(BUNDLE_PATH)
    log("canonical_scan_verified", **scan)

    auto_train = _env_true("AI_GLOBAL_TRADER_AUTO_TRAIN", default=True)
    baseline_complete = _env_true("AI_GLOBAL_TRADER_BASELINE_COMPLETE", default=False)

    training_complete = False
    training_summary: dict[str, object] | None = None
    if not auto_train and baseline_complete:
        market = os.getenv("AI_GLOBAL_TRADER_MARKET", "XAUUSD")
        stored = None
        try:
            stored = latest_model_summary(market)
        except Exception as exc:
            log("model_store_read_failed", error=type(exc).__name__, message=str(exc))
        training_complete = stored is not None
        training_summary = stored or {"model_version": BASELINE_MODEL_VERSION}
        update_state(
            phase="TRAINING_COMPLETE" if training_complete else "TRAINING_PENDING",
            canonical_history_ready=True,
            training_progress_pct=100.0 if training_complete else 0.0,
            training_complete=training_complete,
            model_version=(stored or {}).get("model_version", BASELINE_MODEL_VERSION),
            horizons_minutes=(stored or {}).get("horizons_minutes"),
            holdout_metrics=(stored or {}).get("holdout_metrics"),
            selective_holdout_metrics=(stored or {}).get("selective_holdout_metrics"),
            calibration_selection=(stored or {}).get("calibration_selection"),
            model_artifact_loaded=stored is not None,
        )
        log(
            "price_training_skipped_existing_baseline",
            model_version=(stored or {}).get("model_version", BASELINE_MODEL_VERSION),
            reason="existing_model_loaded",
            model_artifact_loaded=stored is not None,
        )
    else:
        update_state(phase="TRAINING", canonical_history_ready=True)
        try:
            training_summary = _run_training()
            artifact_path = Path(str(training_summary["artifact_path"]))
            save_model_artifact(artifact_path)
            artifact = json.loads(artifact_path.read_text(encoding="utf-8"))
            gate_report = evaluate_offline_candidate(artifact).as_dict()
            log("offline_promotion_gate", **gate_report)
            update_state(offline_promotion_gate=gate_report)
            log(
                "model_artifact_persisted",
                model_version=training_summary.get("model_version"),
                storage="postgres",
            )
            training_complete = True
            update_state(model_artifact_loaded=True)
        except Exception as exc:
            log("price_training_failed", error=type(exc).__name__, message=str(exc))
            update_state(
                phase="TRAINING_FAILED",
                training_complete=False,
                training_error=f"{type(exc).__name__}: {exc}",
            )

    shadow_v5_enabled = start_shadow_monitor(log)
    shadow_v6_enabled = start_shadow_monitor_v6(log)
    update_state(shadow_v5_enabled=shadow_v5_enabled, shadow_v6_enabled=shadow_v6_enabled)

    log(
        "bootstrap_ready",
        legacy_logic_loaded=False,
        canonical_history_ready=True,
        telegram_enabled=telegram_enabled,
        signal_api_enabled=signal_api_enabled,
        shadow_v5_enabled=shadow_v5_enabled,
        shadow_v6_enabled=shadow_v6_enabled,
        training_complete=training_complete,
        model_version=(training_summary or {}).get("model_version"),
    )

    while True:
        time.sleep(300)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        log("bootstrap_failed", error=type(exc).__name__, message=str(exc))
        raise
