from __future__ import annotations

import json
import os
import threading
import time
from typing import Callable

POLL_SECONDS = 300
UNRESOLVABLE_AFTER_HOURS = 6


def _enabled() -> bool:
    return os.getenv("AI_GLOBAL_TRADER_SHADOW_MAINTENANCE_ENABLED", "true").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


def _connect():
    import psycopg

    url = os.environ.get("DATABASE_URL", "").strip()
    if not url:
        raise RuntimeError("DATABASE_URL is not configured")
    return psycopg.connect(url)


def _expire_unresolvable_targets() -> dict[str, int]:
    """Exclude shadow predictions whose exact wall-clock target candle never existed.

    This is intentionally conservative. A prediction is untouched for six hours after
    target_time. Only then, if there is still no exact XAUUSD M1 candle at target_time,
    it is marked UNRESOLVABLE_TARGET_GAP. It is not carried to the next market session
    and is not counted as correct/incorrect or included in directional edge.
    """
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """
            WITH doomed AS (
                SELECT p.id
                FROM ai_global_trader_shadow_predictions p
                WHERE p.status = 'PENDING'
                  AND p.target_time IS NOT NULL
                  AND p.target_time <= NOW() - (%s * INTERVAL '1 hour')
                  AND NOT EXISTS (
                      SELECT 1
                      FROM xauusd_candles c
                      WHERE c.timeframe = 'M1'
                        AND c.candle_time = p.target_time
                  )
                FOR UPDATE SKIP LOCKED
            )
            UPDATE ai_global_trader_shadow_predictions p
            SET status = 'UNRESOLVABLE_TARGET_GAP',
                resolved_at = NOW(),
                correct = NULL,
                actual_price = NULL,
                move_bps = NULL,
                directional_edge_bps = NULL,
                metadata = COALESCE(p.metadata, '{}'::jsonb) || %s::jsonb
            FROM doomed d
            WHERE p.id = d.id
            RETURNING p.policy_version
            """,
            (
                UNRESOLVABLE_AFTER_HOURS,
                json.dumps(
                    {
                        "resolution_reason": "exact_target_m1_missing_after_grace",
                        "score_excluded": True,
                        "target_carry_forward": False,
                        "grace_hours": UNRESOLVABLE_AFTER_HOURS,
                    },
                    ensure_ascii=False,
                ),
            ),
        )
        rows = cur.fetchall()
        conn.commit()

    counts: dict[str, int] = {}
    for (policy_version,) in rows:
        key = str(policy_version)
        counts[key] = counts.get(key, 0) + 1
    return counts


def _loop(log: Callable[..., None]) -> None:
    log(
        "shadow_maintenance_started",
        execution_enabled=False,
        score_excluded_status="UNRESOLVABLE_TARGET_GAP",
        grace_hours=UNRESOLVABLE_AFTER_HOURS,
    )
    while True:
        try:
            counts = _expire_unresolvable_targets()
            if counts:
                log(
                    "shadow_unresolvable_targets_expired",
                    by_policy=counts,
                    total=sum(counts.values()),
                    execution_enabled=False,
                )
        except Exception as exc:
            # The table may not exist during very early bootstrap. Retry later instead of
            # making the main runtime fail.
            log("shadow_maintenance_error", error=type(exc).__name__, message=str(exc))
        time.sleep(POLL_SECONDS)


def start_shadow_maintenance(log: Callable[..., None]) -> bool:
    if not _enabled():
        log("shadow_maintenance_disabled")
        return False
    thread = threading.Thread(
        target=_loop,
        args=(log,),
        name="ai-global-trader-shadow-maintenance",
        daemon=True,
    )
    thread.start()
    log("shadow_maintenance_thread_started", execution_enabled=False)
    return True
