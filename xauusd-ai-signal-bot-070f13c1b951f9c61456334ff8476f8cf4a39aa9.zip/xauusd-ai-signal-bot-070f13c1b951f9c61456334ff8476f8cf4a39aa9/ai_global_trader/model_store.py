from __future__ import annotations

import json
import os
from pathlib import Path


def _connect():
    import psycopg

    url = os.environ.get("DATABASE_URL", "").strip()
    if not url:
        raise RuntimeError("DATABASE_URL is not configured")
    return psycopg.connect(url)


def ensure_schema() -> None:
    with _connect() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS ai_global_trader_models (
                    model_version TEXT PRIMARY KEY,
                    market TEXT NOT NULL,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    horizons_minutes INTEGER[] NOT NULL,
                    holdout_metrics JSONB NOT NULL,
                    artifact_json JSONB NOT NULL,
                    is_promoted BOOLEAN NOT NULL DEFAULT FALSE
                )
                """
            )
        conn.commit()


def save_model_artifact(path: Path) -> None:
    artifact = json.loads(path.read_text(encoding="utf-8"))
    model_version = str(artifact["model_version"])
    market = str(artifact.get("market", "XAUUSD"))
    horizons = [int(v) for v in artifact.get("horizons_minutes", [])]
    holdout_metrics = artifact.get("holdout_metrics", {})

    ensure_schema()
    with _connect() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO ai_global_trader_models (
                    model_version, market, horizons_minutes, holdout_metrics, artifact_json
                ) VALUES (%s, %s, %s, %s::jsonb, %s::jsonb)
                ON CONFLICT (model_version) DO UPDATE SET
                    market = EXCLUDED.market,
                    horizons_minutes = EXCLUDED.horizons_minutes,
                    holdout_metrics = EXCLUDED.holdout_metrics,
                    artifact_json = EXCLUDED.artifact_json,
                    created_at = NOW()
                """,
                (
                    model_version,
                    market,
                    horizons,
                    json.dumps(holdout_metrics, ensure_ascii=False),
                    json.dumps(artifact, ensure_ascii=False),
                ),
            )
        conn.commit()


def latest_model_summary(market: str = "XAUUSD") -> dict[str, object] | None:
    ensure_schema()
    with _connect() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT model_version, horizons_minutes, holdout_metrics, artifact_json, is_promoted, created_at
                FROM ai_global_trader_models
                WHERE market = %s
                ORDER BY created_at DESC
                LIMIT 1
                """,
                (market,),
            )
            row = cur.fetchone()
    if row is None:
        return None
    artifact = dict(row[3] or {})
    return {
        "model_version": row[0],
        "horizons_minutes": list(row[1] or []),
        "holdout_metrics": row[2] or {},
        "selective_holdout_metrics": artifact.get("selective_holdout_metrics") or {},
        "calibration_selection": artifact.get("calibration_selection") or {},
        "source_model_version": artifact.get("source_model_version"),
        "purpose": artifact.get("purpose"),
        "is_promoted": bool(row[4]),
        "created_at": row[5].isoformat() if row[5] else None,
    }


def load_model_artifact(model_version: str) -> dict[str, object] | None:
    ensure_schema()
    with _connect() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT artifact_json FROM ai_global_trader_models WHERE model_version = %s",
                (model_version,),
            )
            row = cur.fetchone()
    if row is None:
        return None
    return dict(row[0] or {})


def latest_model_artifact(market: str = "XAUUSD") -> dict[str, object] | None:
    ensure_schema()
    with _connect() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT artifact_json
                FROM ai_global_trader_models
                WHERE market = %s
                ORDER BY created_at DESC
                LIMIT 1
                """,
                (market,),
            )
            row = cur.fetchone()
    if row is None:
        return None
    return dict(row[0] or {})


def promoted_model_artifact(market: str = "XAUUSD") -> dict[str, object] | None:
    ensure_schema()
    with _connect() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT artifact_json
                FROM ai_global_trader_models
                WHERE market = %s AND is_promoted IS TRUE
                ORDER BY created_at DESC
                LIMIT 1
                """,
                (market,),
            )
            row = cur.fetchone()
    if row is None:
        return None
    return dict(row[0] or {})


def promote_model(model_version: str, *, market: str = "XAUUSD") -> None:
    """Promote exactly one model. Call only after independent evaluation approves it."""
    ensure_schema()
    with _connect() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT 1 FROM ai_global_trader_models WHERE model_version = %s AND market = %s",
                (model_version, market),
            )
            if cur.fetchone() is None:
                raise RuntimeError(f"model not found: {model_version}")
            cur.execute(
                "UPDATE ai_global_trader_models SET is_promoted = FALSE WHERE market = %s",
                (market,),
            )
            cur.execute(
                "UPDATE ai_global_trader_models SET is_promoted = TRUE WHERE model_version = %s AND market = %s",
                (model_version, market),
            )
        conn.commit()
