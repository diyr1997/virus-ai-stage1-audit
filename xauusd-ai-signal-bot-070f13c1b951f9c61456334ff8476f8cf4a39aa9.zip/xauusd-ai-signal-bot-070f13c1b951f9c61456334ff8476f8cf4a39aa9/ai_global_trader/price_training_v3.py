from __future__ import annotations

import json
import math
import os
import tempfile
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

from .forecast_schedule import forecast_minutes
from .price_training import (
    MINUTE_MS,
    AdaGradLogistic,
    AdaGradRegressor,
    Candle,
    Metrics,
    _clip,
    iter_canonical_candles,
)

Progress = Callable[..., None]
MODEL_VERSION = "xauusd-price-v3-regime-selective"
CALIBRATION_START_UTC = datetime(2024, 1, 1, tzinfo=timezone.utc)
HOLDOUT_START_UTC = datetime(2025, 1, 1, tzinfo=timezone.utc)
CALIBRATION_START_MS = int(CALIBRATION_START_UTC.timestamp() * 1000)
HOLDOUT_START_MS = int(HOLDOUT_START_UTC.timestamp() * 1000)
LOOKBACK_MINUTES = (1, 2, 3, 5, 8, 13, 15, 21, 30, 34, 55, 60, 89)
EWMA_SPANS = (5, 15, 30, 60)
CONFIDENCE_GRID = (0.50, 0.51, 0.52, 0.53, 0.54, 0.55, 0.56, 0.58, 0.60)
MAGNITUDE_GRID_BPS = (0.0, 0.5, 1.0, 2.0)
MIN_CALIBRATION_SIGNALS = 5000
MIN_CALIBRATION_COVERAGE = 0.02


@dataclass(frozen=True)
class PendingExample:
    horizon_min: int
    features: tuple[float, ...]
    base_close: float
    phase: str


@dataclass
class SignalMetrics:
    evaluated: int = 0
    signals: int = 0
    correct: int = 0
    directional_edge_bps_sum: float = 0.0
    abs_move_bps_sum: float = 0.0

    def add(self, probability_up: float, predicted_bps: float, actual_bps: float, *, conf: float, min_magnitude_bps: float) -> None:
        if actual_bps == 0.0:
            return
        self.evaluated += 1
        confidence = max(probability_up, 1.0 - probability_up)
        if confidence < conf or abs(predicted_bps) < min_magnitude_bps:
            return
        predicted_up = probability_up >= 0.5
        actual_up = actual_bps > 0.0
        self.signals += 1
        self.correct += int(predicted_up == actual_up)
        self.directional_edge_bps_sum += actual_bps if predicted_up else -actual_bps
        self.abs_move_bps_sum += abs(actual_bps)

    def summary(self) -> dict[str, float | int | None]:
        accuracy = None if self.signals == 0 else self.correct / self.signals
        coverage = None if self.evaluated == 0 else self.signals / self.evaluated
        return {
            "evaluated": self.evaluated,
            "signals": self.signals,
            "correct": self.correct,
            "wrong": self.signals - self.correct,
            "direction_accuracy": accuracy,
            "coverage": coverage,
            "avg_directional_edge_bps": None if self.signals == 0 else self.directional_edge_bps_sum / self.signals,
            "avg_abs_move_bps": None if self.signals == 0 else self.abs_move_bps_sum / self.signals,
        }


@dataclass
class CalibrationCell:
    total: int = 0
    signals: int = 0
    correct: int = 0

    def add(self, probability_up: float, predicted_bps: float, actual_bps: float, *, conf: float, min_magnitude_bps: float) -> None:
        if actual_bps == 0.0:
            return
        self.total += 1
        confidence = max(probability_up, 1.0 - probability_up)
        if confidence < conf or abs(predicted_bps) < min_magnitude_bps:
            return
        self.signals += 1
        self.correct += int((probability_up >= 0.5) == (actual_bps > 0.0))

    @property
    def accuracy(self) -> float | None:
        return None if self.signals == 0 else self.correct / self.signals

    @property
    def coverage(self) -> float:
        return 0.0 if self.total == 0 else self.signals / self.total

    @property
    def wilson_lower(self) -> float:
        if self.signals <= 0:
            return 0.0
        n = float(self.signals)
        p = self.correct / n
        z = 1.96
        denominator = 1.0 + z * z / n
        centre = p + z * z / (2.0 * n)
        spread = z * math.sqrt((p * (1.0 - p) + z * z / (4.0 * n)) / n)
        return (centre - spread) / denominator


class CalibrationGrid:
    def __init__(self) -> None:
        self.cells = {
            (conf, magnitude): CalibrationCell()
            for conf in CONFIDENCE_GRID
            for magnitude in MAGNITUDE_GRID_BPS
        }

    def add(self, probability_up: float, predicted_bps: float, actual_bps: float) -> None:
        for (conf, magnitude), cell in self.cells.items():
            cell.add(
                probability_up,
                predicted_bps,
                actual_bps,
                conf=conf,
                min_magnitude_bps=magnitude,
            )

    def choose(self) -> dict[str, float | int | None]:
        eligible: list[tuple[float, float, float, float, CalibrationCell]] = []
        for (conf, magnitude), cell in self.cells.items():
            if cell.signals < MIN_CALIBRATION_SIGNALS or cell.coverage < MIN_CALIBRATION_COVERAGE:
                continue
            eligible.append((cell.wilson_lower, cell.coverage, conf, magnitude, cell))

        if not eligible:
            conf, magnitude = 0.50, 0.0
            cell = self.cells[(conf, magnitude)]
        else:
            eligible.sort(key=lambda item: (item[0], item[1]), reverse=True)
            _lower, _coverage, conf, magnitude, cell = eligible[0]

        return {
            "confidence_threshold": conf,
            "min_predicted_magnitude_bps": magnitude,
            "signals": cell.signals,
            "total": cell.total,
            "coverage": cell.coverage,
            "direction_accuracy": cell.accuracy,
            "wilson_lower_95": cell.wilson_lower,
        }


@dataclass
class FeatureState:
    recent: dict[int, Candle] = field(default_factory=dict)
    order: deque[int] = field(default_factory=deque)
    ewma_ret: dict[int, float] = field(default_factory=lambda: {span: 0.0 for span in EWMA_SPANS})
    ewma_abs: dict[int, float] = field(default_factory=lambda: {span: 0.0 for span in EWMA_SPANS})
    ewma_sq: dict[int, float] = field(default_factory=lambda: {span: 0.0 for span in EWMA_SPANS})
    ewma_range: dict[int, float] = field(default_factory=lambda: {span: 0.0 for span in EWMA_SPANS})
    initialized: bool = False

    def _reset_ewma(self) -> None:
        for span in EWMA_SPANS:
            self.ewma_ret[span] = 0.0
            self.ewma_abs[span] = 0.0
            self.ewma_sq[span] = 0.0
            self.ewma_range[span] = 0.0
        self.initialized = False

    def features_and_advance(self, candle: Candle) -> tuple[float, ...]:
        previous = self.recent.get(candle.timestamp_ms - MINUTE_MS)
        if previous is None:
            self._reset_ewma()
            one_minute_bps = 0.0
            has_previous = 0.0
        else:
            one_minute_bps = (candle.close / previous.close - 1.0) * 10_000.0 if previous.close > 0 else 0.0
            has_previous = 1.0

        denom = candle.close if candle.close else 1.0
        body_bps = (candle.close - candle.open) / denom * 10_000.0
        range_bps = (candle.high - candle.low) / denom * 10_000.0
        candle_range = max(candle.high - candle.low, 1e-12)
        upper_wick = candle.high - max(candle.open, candle.close)
        lower_wick = min(candle.open, candle.close) - candle.low
        close_position = 2.0 * (candle.close - candle.low) / candle_range - 1.0

        ret_scaled = _clip(one_minute_bps / 20.0)
        range_scaled = _clip(range_bps / 20.0)
        for span in EWMA_SPANS:
            alpha = 2.0 / (span + 1.0)
            if not self.initialized:
                self.ewma_ret[span] = ret_scaled
                self.ewma_abs[span] = abs(ret_scaled)
                self.ewma_sq[span] = ret_scaled * ret_scaled
                self.ewma_range[span] = range_scaled
            else:
                self.ewma_ret[span] = alpha * ret_scaled + (1.0 - alpha) * self.ewma_ret[span]
                self.ewma_abs[span] = alpha * abs(ret_scaled) + (1.0 - alpha) * self.ewma_abs[span]
                self.ewma_sq[span] = alpha * ret_scaled * ret_scaled + (1.0 - alpha) * self.ewma_sq[span]
                self.ewma_range[span] = alpha * range_scaled + (1.0 - alpha) * self.ewma_range[span]
        self.initialized = True

        values: list[float] = [1.0, has_previous]
        exact_returns: dict[int, float] = {}
        for minute in LOOKBACK_MINUTES:
            past = self.recent.get(candle.timestamp_ms - minute * MINUTE_MS)
            if past is None or past.close <= 0:
                values.extend((0.0, 0.0, 0.0, 0.0))
                exact_returns[minute] = 0.0
            else:
                ret_bps = (candle.close / past.close - 1.0) * 10_000.0
                scaled = _clip(ret_bps / 40.0)
                values.extend((scaled, abs(scaled), scaled * scaled, 1.0))
                exact_returns[minute] = scaled

        body_scaled = _clip(body_bps / 20.0)
        values.extend(
            (
                body_scaled,
                range_scaled,
                _clip(close_position, 1.0),
                _clip(upper_wick / candle_range, 1.0),
                _clip(lower_wick / candle_range, 1.0),
                body_scaled * range_scaled,
            )
        )

        ewma_vol: dict[int, float] = {}
        for span in EWMA_SPANS:
            variance = max(self.ewma_sq[span] - self.ewma_ret[span] ** 2, 0.0)
            volatility = math.sqrt(variance)
            ewma_vol[span] = volatility
            values.extend(
                (
                    _clip(self.ewma_ret[span]),
                    _clip(self.ewma_abs[span]),
                    _clip(volatility),
                    _clip(self.ewma_range[span]),
                )
            )

        alignment_terms = []
        for minute in (1, 3, 5, 15, 30, 60):
            value = exact_returns.get(minute, 0.0)
            if value > 0:
                alignment_terms.append(1.0)
            elif value < 0:
                alignment_terms.append(-1.0)
        alignment = sum(alignment_terms) / len(alignment_terms) if alignment_terms else 0.0
        ret3 = exact_returns.get(3, 0.0)
        ret5 = exact_returns.get(5, 0.0)
        ret15 = exact_returns.get(15, 0.0)
        ret30 = exact_returns.get(30, 0.0)
        ret60 = exact_returns.get(60, 0.0)
        values.extend(
            (
                alignment,
                _clip(ret3 - ret15),
                _clip(ret5 - ret30),
                _clip(ret15 - ret60),
                _clip(ret5 * ewma_vol[15]),
                _clip(ret15 * ewma_vol[30]),
                _clip(alignment * ewma_vol[15]),
                _clip(close_position * ret5),
                _clip(body_scaled * ewma_vol[5]),
            )
        )

        dt = datetime.fromtimestamp(candle.timestamp_ms / 1000, tz=timezone.utc)
        minute_of_day = dt.hour * 60 + dt.minute
        hour_angle = 2.0 * math.pi * minute_of_day / 1440.0
        dow_angle = 2.0 * math.pi * dt.weekday() / 7.0
        values.extend((math.sin(hour_angle), math.cos(hour_angle), math.sin(dow_angle), math.cos(dow_angle)))

        while self.order and self.order[0] < candle.timestamp_ms - 95 * MINUTE_MS:
            old = self.order.popleft()
            self.recent.pop(old, None)
        self.recent[candle.timestamp_ms] = candle
        self.order.append(candle.timestamp_ms)
        return tuple(values)


def _feature_names() -> tuple[str, ...]:
    names = ["bias", "has_previous_minute"]
    for minute in LOOKBACK_MINUTES:
        names.extend((f"ret_{minute}m", f"abs_ret_{minute}m", f"sq_ret_{minute}m", f"has_{minute}m"))
    names.extend(("body_bps", "range_bps", "close_position", "upper_wick_ratio", "lower_wick_ratio", "body_x_range"))
    for span in EWMA_SPANS:
        names.extend((f"ewma_ret_{span}", f"ewma_abs_{span}", f"ewma_vol_{span}", f"ewma_range_{span}"))
    names.extend(
        (
            "momentum_alignment",
            "accel_3_15",
            "accel_5_30",
            "accel_15_60",
            "ret5_x_vol15",
            "ret15_x_vol30",
            "alignment_x_vol15",
            "closepos_x_ret5",
            "body_x_vol5",
            "hour_sin",
            "hour_cos",
            "dow_sin",
            "dow_cos",
        )
    )
    return tuple(names)


def _phase(origin_ms: int) -> str:
    if origin_ms < CALIBRATION_START_MS:
        return "TRAIN"
    if origin_ms < HOLDOUT_START_MS:
        return "CALIBRATION"
    return "HOLDOUT"


def _target_stays_in_phase(target_ms: int, phase: str) -> bool:
    if phase == "TRAIN":
        return target_ms < CALIBRATION_START_MS
    if phase == "CALIBRATION":
        return target_ms < HOLDOUT_START_MS
    return True


def train_regime_selective_v3(bundle_path: Path, output_dir: Path, progress: Progress | None = None) -> dict[str, object]:
    horizons = tuple(forecast_minutes())
    feature_names = _feature_names()
    classifiers = {h: AdaGradLogistic(len(feature_names), learning_rate=0.06, l2=2e-5) for h in horizons}
    regressors = {h: AdaGradRegressor(len(feature_names), learning_rate=0.02, l2=2e-5) for h in horizons}
    train_metrics = {h: Metrics() for h in horizons}
    calibration_metrics = {h: Metrics() for h in horizons}
    holdout_metrics = {h: Metrics() for h in horizons}
    calibration_grids = {h: CalibrationGrid() for h in horizons}
    selective_holdout = {h: SignalMetrics() for h in horizons}
    selection: dict[int, dict[str, float | int | None]] = {}
    pending: dict[int, list[PendingExample]] = {}
    state = FeatureState()
    candles_seen = 0
    scheduled = 0

    if progress is not None:
        progress(
            "price_training_started",
            model_version=MODEL_VERSION,
            horizons=list(horizons),
            calibration_start_utc=CALIBRATION_START_UTC.isoformat(),
            holdout_start_utc=HOLDOUT_START_UTC.isoformat(),
            feature_count=len(feature_names),
            selection="calibration_wilson_grid",
        )

    def finalize_selection() -> None:
        if selection:
            return
        for horizon in horizons:
            selection[horizon] = calibration_grids[horizon].choose()
        if progress is not None:
            progress(
                "v3_selection_calibrated",
                model_version=MODEL_VERSION,
                selection={str(k): v for k, v in selection.items()},
            )

    for candle in iter_canonical_candles(bundle_path, progress=progress):
        candles_seen += 1
        stale_targets = [target for target in pending if target < candle.timestamp_ms]
        for target in stale_targets:
            pending.pop(target, None)

        due = pending.pop(candle.timestamp_ms, [])
        for example in due:
            actual_bps = (candle.close / example.base_close - 1.0) * 10_000.0
            if actual_bps == 0.0:
                continue
            classifier = classifiers[example.horizon_min]
            regressor = regressors[example.horizon_min]
            p = classifier.predict(example.features)
            pred_bps = regressor.predict_scaled(example.features) * 20.0

            if example.phase == "TRAIN":
                train_metrics[example.horizon_min].add(p, pred_bps, actual_bps)
                classifier.update(example.features, 1 if actual_bps > 0 else 0)
                regressor.update(example.features, _clip(actual_bps / 20.0, 10.0))
            elif example.phase == "CALIBRATION":
                calibration_metrics[example.horizon_min].add(p, pred_bps, actual_bps)
                calibration_grids[example.horizon_min].add(p, pred_bps, actual_bps)
            else:
                finalize_selection()
                holdout_metrics[example.horizon_min].add(p, pred_bps, actual_bps)
                selected = selection[example.horizon_min]
                selective_holdout[example.horizon_min].add(
                    p,
                    pred_bps,
                    actual_bps,
                    conf=float(selected["confidence_threshold"] or 0.5),
                    min_magnitude_bps=float(selected["min_predicted_magnitude_bps"] or 0.0),
                )

        x = state.features_and_advance(candle)
        phase = _phase(candle.timestamp_ms)
        if phase == "HOLDOUT":
            finalize_selection()
        for horizon in horizons:
            target_ms = candle.timestamp_ms + horizon * MINUTE_MS
            if not _target_stays_in_phase(target_ms, phase):
                continue
            pending.setdefault(target_ms, []).append(PendingExample(horizon, x, candle.close, phase))
            scheduled += 1

    finalize_selection()
    artifact = {
        "system": "AI Global Trader",
        "market": os.getenv("AI_GLOBAL_TRADER_MARKET", "XAUUSD"),
        "model_version": MODEL_VERSION,
        "model_type": "price_only_regime_features_online_adagrad_selective",
        "purpose": "research_candidate_not_promoted",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "calibration_start_utc": CALIBRATION_START_UTC.isoformat(),
        "holdout_start_utc": HOLDOUT_START_UTC.isoformat(),
        "horizons_minutes": list(horizons),
        "feature_names": list(feature_names),
        "candles_seen": candles_seen,
        "examples_scheduled": scheduled,
        "selection_method": {
            "name": "calibration_wilson_grid",
            "confidence_grid": list(CONFIDENCE_GRID),
            "magnitude_grid_bps": list(MAGNITUDE_GRID_BPS),
            "minimum_calibration_signals": MIN_CALIBRATION_SIGNALS,
            "minimum_calibration_coverage": MIN_CALIBRATION_COVERAGE,
        },
        "calibration_selection": {str(h): selection[h] for h in horizons},
        "train_metrics": {str(h): train_metrics[h].summary() for h in horizons},
        "calibration_metrics": {str(h): calibration_metrics[h].summary() for h in horizons},
        "holdout_metrics": {str(h): holdout_metrics[h].summary() for h in horizons},
        "selective_holdout_metrics": {str(h): selective_holdout[h].summary() for h in horizons},
        "models": {
            str(h): {
                "direction_weights": classifiers[h].weights,
                "return_weights": regressors[h].weights,
                "return_scale_bps": 20.0,
                "signal_filter": selection[h],
            }
            for h in horizons
        },
    }

    output_dir.mkdir(parents=True, exist_ok=True)
    artifact_path = output_dir / f"{MODEL_VERSION}.json"
    tmp = tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False, dir=output_dir, prefix="model-v3-", suffix=".tmp")
    tmp_path = Path(tmp.name)
    try:
        with tmp:
            json.dump(artifact, tmp, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            tmp.flush()
        tmp_path.replace(artifact_path)
    finally:
        tmp_path.unlink(missing_ok=True)

    summary = {
        "model_version": MODEL_VERSION,
        "artifact_path": str(artifact_path),
        "candles_seen": candles_seen,
        "calibration_start_utc": CALIBRATION_START_UTC.isoformat(),
        "holdout_start_utc": HOLDOUT_START_UTC.isoformat(),
        "horizons_minutes": list(horizons),
        "calibration_selection": artifact["calibration_selection"],
        "holdout_metrics": artifact["holdout_metrics"],
        "selective_holdout_metrics": artifact["selective_holdout_metrics"],
        "train_metrics": artifact["train_metrics"],
    }
    if progress is not None:
        progress("price_training_complete", **summary)
    return summary
