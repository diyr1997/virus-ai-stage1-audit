from __future__ import annotations

import json
import os
import threading
import time
import urllib.parse
import urllib.request
from typing import Callable

from .forecast_schedule import forecast_minutes
from .runtime_state import snapshot_state
from .signal_stats import stats_windows, trade_stats_windows

TOKEN_ENV = "AI_GLOBAL_TRADER_TELEGRAM_BOT_TOKEN"


def _api(token: str, method: str, payload: dict[str, object] | None = None, timeout: int = 35) -> dict:
    url = f"https://api.telegram.org/bot{token}/{method}"
    data = None
    headers = {"User-Agent": "AI-Global-Trader/1.0"}
    if payload is not None:
        data = urllib.parse.urlencode({k: str(v) for k, v in payload.items()}).encode("utf-8")
        headers["Content-Type"] = "application/x-www-form-urlencoded"
    req = urllib.request.Request(url, data=data, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as response:
        result = json.loads(response.read().decode("utf-8"))
    if not result.get("ok"):
        raise RuntimeError(f"Telegram API error in {method}: {result.get('description', 'unknown error')}")
    return result


def _register_commands(token: str, log: Callable[..., None]) -> None:
    commands = [
        {"command": "start", "description": "Главное меню AI Global Trader"},
        {"command": "status", "description": "Текущий статус системы"},
        {"command": "stats", "description": "Сигналы и DEMO-сделки 1ч / 6ч / 24ч / 7д"},
        {"command": "help", "description": "Что делает каждая команда"},
    ]
    _api(token, "setMyCommands", {"commands": json.dumps(commands, ensure_ascii=False)}, timeout=20)
    _api(token, "setChatMenuButton", {"menu_button": json.dumps({"type": "commands"})}, timeout=20)
    log("telegram_commands_registered", commands=[item["command"] for item in commands])


def _phase_label(phase: str) -> str:
    labels = {
        "BOOTSTRAP": "запуск",
        "DATA_VALIDATION": "проверка данных",
        "TRAINING": "обучение",
        "TRAINING_COMPLETE": "обучение завершено",
        "TRAINING_FAILED": "ошибка обучения",
    }
    return labels.get(phase, phase.lower())


def _start_text() -> str:
    return (
        "🤖 AI Global Trader\n"
        "Главное меню нового AI.\n\n"
        "Сейчас активен рынок XAU/USD.\n"
        "Используй /status для текущего состояния системы.\n"
        "Используй /stats для статистики сигналов и DEMO-сделок.\n"
        "Используй /help, чтобы посмотреть назначение команд."
    )


def _status_text() -> str:
    market = os.getenv("AI_GLOBAL_TRADER_MARKET", "XAUUSD")
    mode = os.getenv("AI_GLOBAL_TRADER_MODE", "TRAINING")
    timer = " / ".join(f"{minute}м" for minute in forecast_minutes())
    state = snapshot_state()
    phase = str(state.get("phase", "BOOTSTRAP"))
    progress = float(state.get("training_progress_pct", 0.0) or 0.0)
    current_file = state.get("training_file")

    lines = [
        "📊 Статус AI Global Trader",
        f"Рынок: {market}",
        f"Режим: {mode}",
        f"Этап: {_phase_label(phase)}",
    ]
    if phase == "TRAINING":
        lines.append(f"Прогресс обучения: {progress:.2f}%")
        if current_file:
            lines.append(f"Сейчас: {current_file}")
    elif phase == "TRAINING_COMPLETE":
        lines.append("Прогресс обучения: 100%")
    elif phase == "TRAINING_FAILED":
        lines.append("Обучение остановлено из-за ошибки")

    lines.extend((
        "История XAU/USD: проверена",
        f"Таймер прогноза: {timer}",
        "Старая торговая логика: не загружена",
        "Торговля реальными деньгами: выключена",
    ))
    return "\n".join(lines)


def _stats_text() -> str:
    market = os.getenv("AI_GLOBAL_TRADER_MARKET", "XAUUSD")
    labels = {1: "1 час", 6: "6 часов", 24: "24 часа", 168: "7 дней"}
    try:
        signal_windows = stats_windows(market=market, windows=(1, 6, 24, 168))
        trade_windows = trade_stats_windows(market=market, windows=(1, 6, 24, 168))
    except Exception as exc:
        return "📈 Статистика\nХранилище статистики пока недоступно.\nПричина: " + type(exc).__name__

    lines = [f"📈 AI Global Trader — статистика {market}"]
    for sig, tr in zip(signal_windows, trade_windows):
        label = labels.get(sig.hours, f"{sig.hours} ч")
        accuracy = "—" if sig.accuracy_pct is None else f"{sig.accuracy_pct:.1f}%"
        conversion = "—" if tr.signal_to_open_pct is None else f"{tr.signal_to_open_pct:.1f}%"
        lines.extend((
            "",
            f"🕒 {label}",
            f"📡 Сигналов: {sig.total} | ✅ {sig.correct} | ❌ {sig.wrong} | ⏳ {sig.pending}",
            f"🎯 Точность сигналов: {accuracy}",
            f"🔗 Сигнал → открытие: {tr.linked_signals_opened}/{tr.signals} ({conversion})",
            f"💼 Открыто позиций: {tr.positions_opened} | сейчас открыто: {tr.open_now}",
            f"💰 Закрыто: {tr.closed} | ➕ {tr.profit} | ➖ {tr.loss} | ⚪ {tr.breakeven}",
            f"⚠️ Сбои открытия: {tr.failed} | пропущено защитой: {tr.skipped}",
            f"💵 Итог P/L DEMO: {tr.net_pnl:+.2f}",
        ))
    if all(item.total == 0 for item in signal_windows):
        lines.extend(("", "Live-сигналы нового AI ещё не запускались — статистика начнёт заполняться автоматически."))
    return "\n".join(lines)


def _help_text() -> str:
    return (
        "🧭 Команды AI Global Trader\n\n"
        "/start — открыть главное меню\n"
        "/status — текущий статус AI, обучение и горизонты прогноза\n"
        "/stats — сигналы + связка с DEMO: открытия, плюс/минус, сбои, P/L за 1ч, 6ч, 24ч и 7 дней\n"
        "/help — показать это объяснение"
    )


def _send(token: str, chat_id: int, text: str) -> None:
    _api(token, "sendMessage", {"chat_id": chat_id, "text": text}, timeout=20)


def _poll_loop(token: str, log: Callable[..., None]) -> None:
    offset = 0
    try:
        me = _api(token, "getMe", timeout=20).get("result", {})
        _register_commands(token, log)
        log("telegram_connected", username=me.get("username"), bot_id=me.get("id"))
    except Exception as exc:
        log("telegram_connect_failed", error=type(exc).__name__, message=str(exc))
        return

    while True:
        try:
            response = _api(token, "getUpdates", {"offset": offset, "timeout": 25, "allowed_updates": json.dumps(["message"])}, timeout=35)
            for update in response.get("result", []):
                update_id = int(update.get("update_id", 0))
                offset = max(offset, update_id + 1)
                message = update.get("message") or {}
                chat = message.get("chat") or {}
                chat_id = chat.get("id")
                text = str(message.get("text") or "").strip()
                if chat_id is None or not text:
                    continue
                command = text.split()[0].split("@")[0].lower()
                log("telegram_command", command=command)
                if command == "/start":
                    _send(token, int(chat_id), _start_text())
                elif command == "/status":
                    _send(token, int(chat_id), _status_text())
                elif command == "/stats":
                    _send(token, int(chat_id), _stats_text())
                elif command == "/help":
                    _send(token, int(chat_id), _help_text())
        except Exception as exc:
            log("telegram_poll_error", error=type(exc).__name__, message=str(exc))
            time.sleep(5)


def start_telegram_bot(log: Callable[..., None]) -> bool:
    token = os.getenv(TOKEN_ENV, "").strip()
    if not token:
        log("telegram_waiting_for_token", variable=TOKEN_ENV)
        return False
    thread = threading.Thread(target=_poll_loop, args=(token, log), name="ai-global-trader-telegram", daemon=True)
    thread.start()
    log("telegram_thread_started")
    return True
