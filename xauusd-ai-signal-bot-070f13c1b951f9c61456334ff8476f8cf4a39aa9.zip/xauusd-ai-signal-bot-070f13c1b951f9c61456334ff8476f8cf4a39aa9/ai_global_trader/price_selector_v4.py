from __future__ import annotations

import copy
import json
import math
import os
import tempfile
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Callable

from .forecast_schedule import forecast_minutes
from .model_store import load_model_artifact
from .price_training import MINUTE_MS, Metrics, iter_canonical_candles
from .price_training_v3 import (
    CALIBRATION_START_MS,
    CALIBRATION_START_UTC,
    HOLDOUT_START_MS,
    HOLDOUT_START_UTC,
    FeatureState,
    _target_stays_in_phase,
)

Progress = Callable[..., None]
MODEL_VERSION = "xauusd-price-v4-robust-selector"
SOURCE_MODEL_VERSION = "xauusd-price-v3-regime-selective"

CONFIDENCE_GRID = (0.50, 0.51, 0.52, 0.53, 0.54, 0.55, 0.56, 0.58, 0.60, 0.62, 0.65)
MAGNITUDE_GRID_BPS = (0.0, 0.5, 1.0, 2.0, 3.0, 5.0)
SIGN_AGREEMENT_GRID = (True, False)
MIN_CALIBRATION_SIGNALS = 4000
MIN_CALIBRATION_COVERAGE = 0.01
MIN_WILSON_LOWER = 0.515
MIN_AVG_EDGE_BPS = 0.05
MIN_POSITIVE_MONTH_FRACTION = 0.58
MIN_VALID_MONTHS = 8
MIN_SIGNALS_PER_MONTH = 50
MIN_WORST_MONTH_EDGE_BPS = -0.50
WARMUP_START_MS = int((CALIBRATION_START_UTC - timedelta(hours=3)).timestamp() * 1000)


@dataclass(frozen=True)
class PendingExample:
    horizon_min: int
    features: tuple[float, ...]
    base_close: float
    phase: str
    origin_month: str


@dataclass
class RobustSignalMetrics:
    evaluated: int = 0
    signals: int = 0
    correct: int = 0
    directional_edge_bps_sum: float = 0.0
    abs_move_bps_sum: float = 0.0

    def add(
        self,
        probability_up: float,
        predicted_bps: float,
        actual_bps: float,
        selected: dict[str, object],
    ) -> None:
        if actual_bps == 0.0:
            return
        self.evaluated += 1
        if not bool(selected.get("enabled", False)):
            return
        confidence = max(probability_up, 1.0 - probability_up)
        if confidence < float(selected.get("confidence_threshold") or 0.5):
            return
        if abs(predicted_bps) < float(selected.get("min_predicted_magnitude_bps") or 0.0):
            return
        predicted_up = probability_up >= 0.5
        if bool(selected.get("require_sign_agreement", False)):
            if predicted_bps == 0.0 or ((predicted_bps > 0.0) != predicted_up):
                return
        actual_up = actual_bps > 0.0
        self.signals += 1
        self.correct += int(predicted_up == actual_up)
        self.directional_edge_bps_sum += actual_bps if predicted_up else -actual_bps
        self.abs_move_bps_sum += abs(actual_bps)

    def summary(self) -> dict[str, float | int | None]:
        return {
            "evaluated": self.evaluated,
            "signals": self.signals,
            "correct": self.correct,
            "wrong": self.signals - self.correct,
            "direction_accuracy": None if self.signals == 0 else self.correct / self.signals,
            "coverage": None if self.evaluated == 0 else self.signals / self.evaluated,
            "avg_directional_edge_bps": None if self.signals == 0 else self.directional_edge_bps_sum / self.signals,
            "avg_abs_move_bps": None if self.signals == 0 else self.abs_move_bps_sum / self.signals,
        }


@dataclass
class MonthlyBucket:
    signals: int = 0
    edge_sum: float = 0.0


@dataclass
class RobustCalibrationCell:
    total: int = 0
    signals: int = 0
    correct: int = 0
    edge_sum: float = 0.0
    abs_move_sum: float = 0.0
    monthly: dict[str, MonthlyBucket] = field(default_factory=lambda: defaultdict(MonthlyBucket))

    def add(
        self,
        probability_up: float,
        predicted_bps: float,
        actual_bps: float,
        *,
        origin_month: str,
        conf: float,
        min_magnitude_bps: float,
        require_sign_agreement: bool,
    ) -> None:
        if actual_bps == 0.0:
            return
        self.total += 1
        confidence = max(probability_up, 1.0 - probability_up)
        if confidence < conf or abs(predicted_bps) < min_magnitude_bps:
            return
        predicted_up = probability_up >= 0.5
        if require_sign_agreement:
            if predicted_bps == 0.0 or ((predicted_bps > 0.0) != predicted_up):
                return
        directional_edge = actual_bps if predicted_up else -actual_bps
        self.signals += 1
        self.correct += int(predicted_up == (actual_bps > 0.0))
        self.edge_sum += directional_edge
        self.abs_move_sum += abs(actual_bps)
        bucket = self.monthly[origin_month]
        bucket.signals += 1
        bucket.edge_sum += directional_edge

    @property
    def accuracy(self) -> float | None:
        return None if self.signals == 0 else self.correct / self.signals

    @property
    def coverage(self) -> float:
        return 0.0 if self.total == 0 else self.signals / self.total

    @property
    def avg_edge_bps(self) -> float:
        return 0.0 if self.signals == 0 else self.edge_sum / self.signals

    @property
    def wilson_lower(self) -> float:
        if self.signals <= 0:
            return 0.0
        n = float(self.signals)
        p = self.correct / n
        z = 1.96
        denominator = 1.0 + z * z / n
        centre = p + z * z / (2.0 * n)
        spread = z * math.sqrt((p * (1.0 - p) + z * z / (4.0 * n)) / n)
        return (centre - spread) / denominator

    def monthly_summary(self) -> tuple[int, float, float | None]:
        edges = [
            bucket.edge_sum / bucket.signals
            for bucket in self.monthly.values()
            if bucket.signals >= MIN_SIGNALS_PER_MONTH
        ]
        if not edges:
            return 0, 0.0, None
        positive_fraction = sum(edge > 0.0 for edge in edges) / len(edges)
        return len(edges), positive_fraction, min(edges)


class RobustCalibrationGrid:
    def __init__(self) -> None:
        self.cells = {
            (conf, magnitude, agreement): RobustCalibrationCell()
            for conf in CONFIDENCE_GRID
            for magnitude in MAGNITUDE_GRID_BPS
            for agreement in SIGN_AGREEMENT_GRID
        }

    def add(
        self,
        probability_up: float,
        predicted_bps: float,
        actual_bps: float,
        *,
        origin_month: str,
    ) -> None:
        for (conf, magnitude, agreement), cell in self.cells.items():
            cell.add(
                probability_up,
                predicted_bps,
                actual_bps,
                origin_month=origin_month,
                conf=conf,
                min_magnitude_bps=magnitude,
                require_sign_agreement=agreement,
            )

    def choose(self) -> dict[str, object]:
        eligible: list[tuple[float, float, float, float, float, bool, RobustCalibrationCell, int, float, float | None]] = []
        fallback: list[tuple[float, float, float, float, bool, RobustCalibrationCell, int, float, float | None]] = []
        for (conf, magnitude, agreement), cell in self.cells.items():
            valid_months, positive_fraction, worst_month_edge = cell.monthly_summary()
            fallback.append(
                (
                    cell.wilson_lower,
                    cell.avg_edge_bps,
                    cell.coverage,
                    conf,
                    agreement,
                    cell,
                    valid_months,
                    positive_fraction,
                    worst_month_edge,
                )
            )
            if cell.signals < MIN_CALIBRATION_SIGNALS or cell.coverage < MIN_CALIBRATION_COVERAGE:
                continue
            if cell.wilson_lower < MIN_WILSON_LOWER or cell.avg_edge_bps < MIN_AVG_EDGE_BPS:
                continue
            if valid_months < MIN_VALID_MONTHS or positive_fraction < MIN_POSITIVE_MONTH_FRACTION:
                continue
            if worst_month_edge is None or worst_month_edge < MIN_WORST_MONTH_EDGE_BPS:
                continue
            score = (
                cell.wilson_lower
                + 0.015 * math.tanh(cell.avg_edge_bps / 2.0)
                + 0.005 * positive_fraction
                + 0.002 * min(cell.coverage / 0.10, 1.0)
            )
            eligible.append(
                (
                    score,
                    cell.wilson_lower,
                    cell.avg_edge_bps,
                    cell.coverage,
                    conf,
                    agreement,
                    cell,
                    valid_months,
                    positive_fraction,
                    worst_month_edge,
                )
            )

        enabled = bool(eligible)
        if enabled:
            eligible.sort(key=lambda item: (item[0], item[1], item[2], item[3]), reverse=True)
            _score, _wl, _edge, _coverage, conf, agreement, cell, valid_months, positive_fraction, worst_month_edge = eligible[0]
            magnitude = next(
                mag
                for (c, mag, a), candidate in self.cells.items()
                if candidate is cell and c == conf and a == agreement
            )
        else:
            fallback.sort(key=lambda item: (item[0], item[1], item[2]), reverse=True)
            _wl, _edge, _coverage, conf, agreement, cell, valid_months, positive_fraction, worst_month_edge = fallback[0]
            magnitude = next(
                mag
                for (c, mag, a), candidate in self.cells.items()
                if candidate is cell and c == conf and a == agreement
            )

        return {
            "enabled": enabled,
            "confidence_threshold": conf,
            "min_predicted_magnitude_bps": magnitude,
            "require_sign_agreement": agreement,
            "signals": cell.signals,
            "total": cell.total,
            "coverage": cell.coverage,
            "direction_accuracy": cell.accuracy,
            "wilson_lower_95": cell.wilson_lower,
            "avg_directional_edge_bps": cell.avg_edge_bps,
            "valid_months": valid_months,
            "positive_month_fraction": positive_fraction,
            "worst_month_edge_bps": worst_month_edge,
            "disabled_reason": None if enabled else "no_calibration_cell_passed_robustness_gate",
        }


def _logistic(score: float) -> float:
    score = min(max(score, -30.0), 30.0)
    return 1.0 / (1.0 + math.exp(-score))


def _dot(weights: list[float], features: tuple[float, ...]) -> float:
    if len(weights) != len(features):
        raise ValueError(f"feature/weight size mismatch: {len(weights)} != {len(features)}")
    return sum(weight * value for weight, value in zip(weights, features))


def _predict(source: dict[str, object], horizon: int, features: tuple[float, ...]) -> tuple[float, float]:
    models = dict(source.get("models") or {})
    raw = dict(models.get(str(horizon)) or {})
    direction_weights = [float(v) for v in raw.get("direction_weights", [])]
    return_weights = [float(v) for v in raw.get("return_weights", [])]
    if not direction_weights or not return_weights:
        raise ValueError(f"source artifact missing weights for horizon {horizon}")
    probability_up = _logistic(_dot(direction_weights, features))
    return_scale = float(raw.get("return_scale_bps") or 20.0)
    predicted_scaled = min(max(_dot(return_weights, features), -10.0), 10.0)
    return probability_up, predicted_scaled * return_scale


def _phase(timestamp_ms: int) -> str:
    if timestamp_ms < CALIBRATION_START_MS:
        return "WARMUP"
    if timestamp_ms < HOLDOUT_START_MS:
        return "CALIBRATION"
    return "HOLDOUT"


def build_robust_selector_v4(bundle_path: Path, output_dir: Path, progress: Progress | None = None) -> dict[str, object]:
    source = load_model_artifact(SOURCE_MODEL_VERSION)
    if source is None:
        raise RuntimeError(f"source model is not stored: {SOURCE_MODEL_VERSION}")
    horizons = tuple(int(v) for v in (source.get("horizons_minutes") or forecast_minutes()))
    feature_names = tuple(str(v) for v in source.get("feature_names", []))
    if not feature_names:
        raise RuntimeError("source model has no feature_names")

    grids = {h: RobustCalibrationGrid() for h in horizons}
    holdout_metrics = {h: Metrics() for h in horizons}
    selective_holdout = {h: RobustSignalMetrics() for h in horizons}
    selection: dict[int, dict[str, object]] = {}
    pending: dict[int, list[PendingExample]] = {}
    state = FeatureState()
    candles_seen = 0
    evaluated_candles = 0

    if progress is not None:
        progress(
            "price_training_started",
            model_version=MODEL_VERSION,
            source_model_version=SOURCE_MODEL_VERSION,
            horizons=list(horizons),
            calibration_start_utc=CALIBRATION_START_UTC.isoformat(),
            holdout_start_utc=HOLDOUT_START_UTC.isoformat(),
            feature_count=len(feature_names),
            selection="robust_monthly_edge_grid",
        )

    def finalize_selection() -> None:
        if selection:
            return
        for horizon in horizons:
            selection[horizon] = grids[horizon].choose()
        if progress is not None:
            progress(
                "v4_selection_calibrated",
                model_version=MODEL_VERSION,
                source_model_version=SOURCE_MODEL_VERSION,
                selection={str(k): v for k, v in selection.items()},
            )

    for candle in iter_canonical_candles(bundle_path, progress=progress):
        candles_seen += 1
        if candle.timestamp_ms < WARMUP_START_MS:
            continue
        evaluated_candles += 1

        stale_targets = [target for target in pending if target < candle.timestamp_ms]
        for target in stale_targets:
            pending.pop(target, None)

        due = pending.pop(candle.timestamp_ms, [])
        for example in due:
            actual_bps = (candle.close / example.base_close - 1.0) * 10_000.0
            if actual_bps == 0.0:
                continue
            p, pred_bps = _predict(source, example.horizon_min, example.features)
            if example.phase == "CALIBRATION":
                grids[example.horizon_min].add(
                    p,
                    pred_bps,
                    actual_bps,
                    origin_month=example.origin_month,
                )
            elif example.phase == "HOLDOUT":
                finalize_selection()
                holdout_metrics[example.horizon_min].add(p, pred_bps, actual_bps)
                selective_holdout[example.horizon_min].add(
                    p,
                    pred_bps,
                    actual_bps,
                    selection[example.horizon_min],
                )

        features = state.features_and_advance(candle)
        phase = _phase(candle.timestamp_ms)
        if phase == "HOLDOUT":
            finalize_selection()
        if phase == "WARMUP":
            continue
        origin_month = datetime.fromtimestamp(candle.timestamp_ms / 1000, tz=timezone.utc).strftime("%Y-%m")
        for horizon in horizons:
            target_ms = candle.timestamp_ms + horizon * MINUTE_MS
            if not _target_stays_in_phase(target_ms, phase):
                continue
            pending.setdefault(target_ms, []).append(
                PendingExample(horizon, features, candle.close, phase, origin_month)
            )

    finalize_selection()

    artifact = copy.deepcopy(source)
    artifact.update(
        {
            "system": "AI Global Trader",
            "market": os.getenv("AI_GLOBAL_TRADER_MARKET", "XAUUSD"),
            "model_version": MODEL_VERSION,
            "source_model_version": SOURCE_MODEL_VERSION,
            "model_type": "v3_weights_with_robust_monthly_edge_selector",
            "purpose": "research_candidate_not_promoted",
            "created_at_utc": datetime.now(timezone.utc).isoformat(),
            "calibration_start_utc": CALIBRATION_START_UTC.isoformat(),
            "holdout_start_utc": HOLDOUT_START_UTC.isoformat(),
            "candles_seen": candles_seen,
            "evaluated_candles": evaluated_candles,
            "selection_method": {
                "name": "robust_monthly_edge_grid",
                "confidence_grid": list(CONFIDENCE_GRID),
                "magnitude_grid_bps": list(MAGNITUDE_GRID_BPS),
                "sign_agreement_grid": list(SIGN_AGREEMENT_GRID),
                "minimum_calibration_signals": MIN_CALIBRATION_SIGNALS,
                "minimum_calibration_coverage": MIN_CALIBRATION_COVERAGE,
                "minimum_wilson_lower_95": MIN_WILSON_LOWER,
                "minimum_avg_directional_edge_bps": MIN_AVG_EDGE_BPS,
                "minimum_positive_month_fraction": MIN_POSITIVE_MONTH_FRACTION,
                "minimum_valid_months": MIN_VALID_MONTHS,
                "minimum_signals_per_month": MIN_SIGNALS_PER_MONTH,
                "minimum_worst_month_edge_bps": MIN_WORST_MONTH_EDGE_BPS,
            },
            "calibration_selection": {str(h): selection[h] for h in horizons},
            "holdout_metrics": {str(h): holdout_metrics[h].summary() for h in horizons},
            "selective_holdout_metrics": {str(h): selective_holdout[h].summary() for h in horizons},
        }
    )
    models = dict(artifact.get("models") or {})
    for horizon in horizons:
        raw = dict(models.get(str(horizon)) or {})
        raw["signal_filter"] = selection[horizon]
        models[str(horizon)] = raw
    artifact["models"] = models

    output_dir.mkdir(parents=True, exist_ok=True)
    artifact_path = output_dir / f"{MODEL_VERSION}.json"
    tmp = tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False, dir=output_dir, prefix="model-v4-", suffix=".tmp")
    tmp_path = Path(tmp.name)
    try:
        with tmp:
            json.dump(artifact, tmp, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            tmp.flush()
        tmp_path.replace(artifact_path)
    finally:
        tmp_path.unlink(missing_ok=True)

    summary = {
        "model_version": MODEL_VERSION,
        "source_model_version": SOURCE_MODEL_VERSION,
        "artifact_path": str(artifact_path),
        "candles_seen": candles_seen,
        "evaluated_candles": evaluated_candles,
        "calibration_start_utc": CALIBRATION_START_UTC.isoformat(),
        "holdout_start_utc": HOLDOUT_START_UTC.isoformat(),
        "horizons_minutes": list(horizons),
        "calibration_selection": artifact["calibration_selection"],
        "holdout_metrics": artifact["holdout_metrics"],
        "selective_holdout_metrics": artifact["selective_holdout_metrics"],
    }
    if progress is not None:
        progress("price_training_complete", **summary)
    return summary
