from __future__ import annotations

import json
import os
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

from .live_inference import RegimeSelectivePredictor
from .model_store import load_model_artifact
from .price_training import Candle, MINUTE_MS

FORWARD_CUTOFF_UTC = datetime(2026, 8, 14, 21, 58, tzinfo=timezone.utc)
WARMUP_MINUTES = 120
DEFAULT_MODEL_VERSIONS = (
    "xauusd-price-v3-regime-selective",
    "xauusd-price-v4-robust-selector",
)


def _connect():
    import psycopg

    url = os.environ.get("DATABASE_URL", "").strip()
    if not url:
        raise RuntimeError("DATABASE_URL is not configured")
    return psycopg.connect(url)


@dataclass
class ForwardMetric:
    evaluated: int = 0
    signals: int = 0
    correct: int = 0
    directional_edge_bps_sum: float = 0.0
    abs_move_bps_sum: float = 0.0

    def add(self, action: str, actual_bps: float) -> None:
        if action not in {"BUY", "SELL"} or actual_bps == 0.0:
            return
        self.evaluated += 1
        self.signals += 1
        predicted_up = action == "BUY"
        actual_up = actual_bps > 0.0
        self.correct += int(predicted_up == actual_up)
        self.directional_edge_bps_sum += actual_bps if predicted_up else -actual_bps
        self.abs_move_bps_sum += abs(actual_bps)

    def summary(self) -> dict[str, float | int | None]:
        wrong = self.signals - self.correct
        return {
            "evaluated": self.evaluated,
            "signals": self.signals,
            "correct": self.correct,
            "wrong": wrong,
            "direction_accuracy": None if self.signals == 0 else self.correct / self.signals,
            "avg_directional_edge_bps": None if self.signals == 0 else self.directional_edge_bps_sum / self.signals,
            "avg_abs_move_bps": None if self.signals == 0 else self.abs_move_bps_sum / self.signals,
        }


def _fetch_live_candles() -> tuple[list[Candle], dict[str, object]]:
    warmup_start = FORWARD_CUTOFF_UTC - timedelta(minutes=WARMUP_MINUTES)
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """
            SELECT DISTINCT ON (candle_time)
                candle_time, open, high, low, close, volume, source
            FROM xauusd_candles
            WHERE timeframe = 'M1'
              AND candle_time >= %s
              AND candle_time <= NOW() - INTERVAL '1 minute'
            ORDER BY
                candle_time,
                CASE WHEN UPPER(COALESCE(source, '')) LIKE 'MT5%%' THEN 0 ELSE 1 END,
                COALESCE(source, '')
            """,
            (warmup_start,),
        )
        rows = cur.fetchall()

    candles: list[Candle] = []
    sources: Counter[str] = Counter()
    invalid_rows = 0
    post_cutoff_rows = 0
    gap_segments = 0
    previous_ms: int | None = None
    first_post: datetime | None = None
    last_post: datetime | None = None

    for row in rows:
        dt = row[0]
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        else:
            dt = dt.astimezone(timezone.utc)
        o, h, l, c = (float(row[1]), float(row[2]), float(row[3]), float(row[4]))
        volume = float(row[5] or 0.0)
        source = str(row[6] or "UNKNOWN")
        if min(o, h, l, c) <= 0 or h < l or h < max(o, c) or l > min(o, c):
            invalid_rows += 1
            continue
        timestamp_ms = int(dt.timestamp() * 1000)
        if previous_ms is not None and timestamp_ms - previous_ms > MINUTE_MS:
            gap_segments += 1
        previous_ms = timestamp_ms
        candles.append(Candle(timestamp_ms=timestamp_ms, open=o, high=h, low=l, close=c, volume=volume))
        sources[source] += 1
        if dt >= FORWARD_CUTOFF_UTC:
            post_cutoff_rows += 1
            first_post = first_post or dt
            last_post = dt

    meta = {
        "cutoff_utc": FORWARD_CUTOFF_UTC.isoformat(),
        "warmup_start_utc": warmup_start.isoformat(),
        "rows_total_with_warmup": len(candles),
        "rows_after_cutoff": post_cutoff_rows,
        "first_after_cutoff_utc": None if first_post is None else first_post.isoformat(),
        "last_after_cutoff_utc": None if last_post is None else last_post.isoformat(),
        "invalid_rows_skipped": invalid_rows,
        "gap_segments": gap_segments,
        "source_counts": dict(sources),
    }
    return candles, meta


def _evaluate_model(model_version: str, candles: list[Candle]) -> dict[str, object]:
    artifact = load_model_artifact(model_version)
    if artifact is None:
        return {"model_version": model_version, "available": False, "reason": "artifact_not_found"}

    predictor = RegimeSelectivePredictor(artifact)
    close_by_time = {item.timestamp_ms: item.close for item in candles}
    per_horizon = {int(h): ForwardMetric() for h in artifact.get("horizons_minutes", [])}
    primary = ForwardMetric()
    primary_by_horizon: Counter[int] = Counter()
    emitted = 0
    actionable_primary = 0

    for candle in candles:
        if candle.timestamp_ms < int(FORWARD_CUTOFF_UTC.timestamp() * 1000):
            predictor.ingest(candle, emit=False)
            continue
        signal = predictor.ingest(candle, emit=True)
        if signal is None:
            continue
        emitted += 1
        forecast_path = list(signal.get("forecast_path") or [])
        for raw in forecast_path:
            horizon = int(raw.get("horizon_min") or 0)
            action = str(raw.get("action") or "WAIT").upper()
            target_close = close_by_time.get(candle.timestamp_ms + horizon * MINUTE_MS)
            if target_close is None or horizon not in per_horizon:
                continue
            actual_bps = (target_close / candle.close - 1.0) * 10_000.0
            per_horizon[horizon].add(action, actual_bps)

        primary_action = str(signal.get("action") or "WAIT").upper()
        primary_horizon = int(signal.get("horizon_min") or 0)
        if primary_action in {"BUY", "SELL"}:
            actionable_primary += 1
            primary_by_horizon[primary_horizon] += 1
            target_close = close_by_time.get(candle.timestamp_ms + primary_horizon * MINUTE_MS)
            if target_close is not None:
                actual_bps = (target_close / candle.close - 1.0) * 10_000.0
                primary.add(primary_action, actual_bps)

    return {
        "model_version": model_version,
        "available": True,
        "emitted_minutes": emitted,
        "actionable_primary_minutes": actionable_primary,
        "primary_horizon_counts": {str(k): v for k, v in sorted(primary_by_horizon.items())},
        "primary_metrics": primary.summary(),
        "per_horizon": {str(h): per_horizon[h].summary() for h in sorted(per_horizon)},
    }


def _ensure_store_schema() -> None:
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS ai_global_trader_forward_evaluations (
                id BIGSERIAL PRIMARY KEY,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                cutoff_utc TIMESTAMPTZ NOT NULL,
                data_last_utc TIMESTAMPTZ,
                report_json JSONB NOT NULL
            )
            """
        )
        conn.commit()


def _persist(report: dict[str, object]) -> None:
    _ensure_store_schema()
    data = dict(report.get("data") or {})
    last_raw = data.get("last_after_cutoff_utc")
    last_dt = None if not last_raw else datetime.fromisoformat(str(last_raw))
    with _connect() as conn, conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO ai_global_trader_forward_evaluations (cutoff_utc, data_last_utc, report_json)
            VALUES (%s, %s, %s::jsonb)
            """,
            (FORWARD_CUTOFF_UTC, last_dt, json.dumps(report, ensure_ascii=False)),
        )
        conn.commit()


def run_forward_evaluation(model_versions: tuple[str, ...] | None = None) -> dict[str, object]:
    versions = model_versions or tuple(
        value.strip()
        for value in os.getenv("AI_GLOBAL_TRADER_FORWARD_MODELS", ",".join(DEFAULT_MODEL_VERSIONS)).split(",")
        if value.strip()
    )
    candles, data_meta = _fetch_live_candles()
    if int(data_meta.get("rows_after_cutoff") or 0) < 120:
        raise RuntimeError(
            f"not enough fresh M1 rows after cutoff: {data_meta.get('rows_after_cutoff')}"
        )
    results = [_evaluate_model(version, candles) for version in versions]
    report = {
        "evaluation_kind": "fresh_forward_readonly_market_data",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "data": data_meta,
        "models": results,
        "execution_enabled": False,
        "canonical_history_mutated": False,
    }
    _persist(report)
    return report


def main() -> int:
    report = run_forward_evaluation()
    print("AI_GLOBAL_TRADER_FORWARD " + json.dumps(report, ensure_ascii=False, sort_keys=True), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
