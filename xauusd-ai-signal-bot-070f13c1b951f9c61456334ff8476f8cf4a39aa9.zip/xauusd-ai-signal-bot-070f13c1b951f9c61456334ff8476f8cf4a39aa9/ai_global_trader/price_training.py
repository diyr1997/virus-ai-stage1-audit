from __future__ import annotations

import io
import json
import math
import os
import re
import tempfile
import zipfile
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Iterator

from .canonical_history import _load_metadata, _materialize_inner, _parse_timestamp, _select_candle_member
from .forecast_schedule import forecast_minutes

Progress = Callable[..., None]
MINUTE_MS = 60_000
LOOKBACK_MINUTES = (1, 3, 5, 8, 13, 21, 34)
HOLDOUT_START_UTC = datetime(2025, 1, 1, tzinfo=timezone.utc)
HOLDOUT_START_MS = int(HOLDOUT_START_UTC.timestamp() * 1000)
MODEL_VERSION = "xauusd-price-baseline-v1"


@dataclass(frozen=True)
class Candle:
    timestamp_ms: int
    open: float
    high: float
    low: float
    close: float
    volume: float


@dataclass
class Metrics:
    count: int = 0
    correct: int = 0
    log_loss_sum: float = 0.0
    abs_error_bps_sum: float = 0.0
    zero_baseline_abs_bps_sum: float = 0.0

    def add(self, probability_up: float, predicted_bps: float, actual_bps: float) -> None:
        if actual_bps == 0.0:
            return
        y = 1 if actual_bps > 0 else 0
        p = min(max(probability_up, 1e-8), 1.0 - 1e-8)
        predicted = 1 if p >= 0.5 else 0
        self.count += 1
        self.correct += int(predicted == y)
        self.log_loss_sum += -(y * math.log(p) + (1 - y) * math.log(1.0 - p))
        self.abs_error_bps_sum += abs(predicted_bps - actual_bps)
        self.zero_baseline_abs_bps_sum += abs(actual_bps)

    def summary(self) -> dict[str, float | int | None]:
        if self.count == 0:
            return {
                "samples": 0,
                "direction_accuracy": None,
                "log_loss": None,
                "mae_bps": None,
                "zero_baseline_mae_bps": None,
            }
        return {
            "samples": self.count,
            "direction_accuracy": self.correct / self.count,
            "log_loss": self.log_loss_sum / self.count,
            "mae_bps": self.abs_error_bps_sum / self.count,
            "zero_baseline_mae_bps": self.zero_baseline_abs_bps_sum / self.count,
        }


@dataclass
class AdaGradLogistic:
    size: int
    learning_rate: float = 0.08
    l2: float = 1e-5
    weights: list[float] = field(init=False)
    accum: list[float] = field(init=False)

    def __post_init__(self) -> None:
        self.weights = [0.0] * self.size
        self.accum = [1e-6] * self.size

    def predict(self, x: tuple[float, ...]) -> float:
        score = sum(w * value for w, value in zip(self.weights, x))
        score = min(max(score, -30.0), 30.0)
        return 1.0 / (1.0 + math.exp(-score))

    def update(self, x: tuple[float, ...], y: int) -> float:
        p = self.predict(x)
        error = p - y
        for i, value in enumerate(x):
            reg = 0.0 if i == 0 else self.l2 * self.weights[i]
            grad = error * value + reg
            self.accum[i] += grad * grad
            self.weights[i] -= self.learning_rate * grad / math.sqrt(self.accum[i])
        return p


@dataclass
class AdaGradRegressor:
    size: int
    learning_rate: float = 0.03
    l2: float = 1e-5
    weights: list[float] = field(init=False)
    accum: list[float] = field(init=False)

    def __post_init__(self) -> None:
        self.weights = [0.0] * self.size
        self.accum = [1e-6] * self.size

    def predict_scaled(self, x: tuple[float, ...]) -> float:
        return max(min(sum(w * value for w, value in zip(self.weights, x)), 10.0), -10.0)

    def update(self, x: tuple[float, ...], target_scaled: float) -> float:
        prediction = self.predict_scaled(x)
        error = max(min(prediction - target_scaled, 5.0), -5.0)
        for i, value in enumerate(x):
            reg = 0.0 if i == 0 else self.l2 * self.weights[i]
            grad = error * value + reg
            self.accum[i] += grad * grad
            self.weights[i] -= self.learning_rate * grad / math.sqrt(self.accum[i])
        return prediction


@dataclass(frozen=True)
class PendingExample:
    horizon_min: int
    features: tuple[float, ...]
    base_close: float
    origin_ms: int
    is_train: bool


def _parse_candle_row(line: str) -> Candle:
    delimiter = ";" if ";" in line else "," if "," in line else None
    if delimiter is None:
        raise ValueError("unsupported delimiter")
    parts = [part.strip() for part in line.split(delimiter)]
    if not parts:
        raise ValueError("empty row")
    if parts[0].lower() in {"timestamp", "date", "datetime"}:
        raise ValueError("header")

    if parts[0].upper() == "XAUUSD" and len(parts) >= 6:
        ts, used = _parse_timestamp(parts[1], parts[2] if len(parts) > 2 else None)
        values = parts[1 + used :]
    else:
        ts, used = _parse_timestamp(parts[0], parts[1] if len(parts) > 1 else None)
        values = parts[used:]

    if len(values) < 4:
        raise ValueError("OHLC missing")
    o, h, l, c = (float(values[i]) for i in range(4))
    v = float(values[4]) if len(values) > 4 and values[4] else 0.0
    if not (l <= min(o, c) <= max(o, c) <= h):
        raise ValueError("invalid OHLC ordering")
    return Candle(ts, o, h, l, c, v)


def _canonical_file_candles(path: Path, archive_name: str, quarantine_ms: set[int]) -> list[Candle]:
    groups: dict[int, list[object]] = {}
    with zipfile.ZipFile(path, "r") as inner:
        member = _select_candle_member(inner, archive_name)
        with inner.open(member, "r") as raw:
            text = io.TextIOWrapper(raw, encoding="utf-8-sig", errors="replace", newline="")
            for line_no, raw_line in enumerate(text, start=1):
                line = raw_line.strip()
                if not line:
                    continue
                try:
                    candle = _parse_candle_row(line)
                except ValueError as exc:
                    if str(exc) == "header":
                        continue
                    raise RuntimeError(f"training parse failed {archive_name}:{line_no}: {exc}") from exc
                fingerprint = (candle.open, candle.high, candle.low, candle.close, candle.volume)
                group = groups.get(candle.timestamp_ms)
                if group is None:
                    groups[candle.timestamp_ms] = [candle, fingerprint, False]
                elif fingerprint != group[1]:
                    group[2] = True

    rows: list[Candle] = []
    for ts in sorted(groups):
        candle, _fingerprint, conflicting = groups[ts]
        if conflicting:
            if ts not in quarantine_ms:
                raise RuntimeError(f"unexpected training conflict in {archive_name} at {ts}")
            continue
        if ts in quarantine_ms:
            # Quarantine policy removes all variants at explicitly listed timestamps.
            continue
        rows.append(candle)  # type: ignore[arg-type]
    return rows


def iter_canonical_candles(bundle_path: Path, progress: Progress | None = None) -> Iterator[Candle]:
    manifest, quarantine = _load_metadata()
    quarantine_by_file = {
        name: {int(value) for value in values}
        for name, values in quarantine.get("files", {}).items()
    }
    processed = 0
    total = int(manifest["total_rows"])

    with zipfile.ZipFile(bundle_path, "r") as outer:
        for index, spec in enumerate(manifest["files"], start=1):
            inner_path, actual_sha = _materialize_inner(outer, spec["file"])
            try:
                if actual_sha != spec["sha256"]:
                    raise RuntimeError(f"training inner ZIP SHA mismatch: {spec['file']}")
                rows = _canonical_file_candles(
                    inner_path,
                    spec["file"],
                    quarantine_by_file.get(spec["file"], set()),
                )
            finally:
                inner_path.unlink(missing_ok=True)

            if len(rows) != int(spec["canonical_rows"]):
                raise RuntimeError(
                    f"training canonical count mismatch {spec['file']}: expected {spec['canonical_rows']}, got {len(rows)}"
                )
            for candle in rows:
                yield candle
            processed += len(rows)
            if progress is not None:
                progress(
                    "training_file_complete",
                    file=spec["file"],
                    file_index=index,
                    total_files=len(manifest["files"]),
                    canonical_rows_processed=processed,
                    total_canonical_rows=total,
                    progress_pct=round(100.0 * processed / total, 2),
                )


def _clip(value: float, limit: float = 5.0) -> float:
    return max(min(value, limit), -limit)


def _feature_names() -> tuple[str, ...]:
    names = ["bias"]
    for minute in LOOKBACK_MINUTES:
        names.extend((f"ret_{minute}m", f"has_{minute}m"))
    names.extend(("body_bps", "range_bps", "close_position", "hour_sin", "hour_cos", "dow_sin", "dow_cos"))
    return tuple(names)


def _features(candle: Candle, recent: dict[int, Candle]) -> tuple[float, ...]:
    values: list[float] = [1.0]
    for minute in LOOKBACK_MINUTES:
        past = recent.get(candle.timestamp_ms - minute * MINUTE_MS)
        if past is None or past.close <= 0:
            values.extend((0.0, 0.0))
        else:
            ret_bps = (candle.close / past.close - 1.0) * 10_000.0
            values.extend((_clip(ret_bps / 20.0), 1.0))

    denom = candle.close if candle.close else 1.0
    body_bps = (candle.close - candle.open) / denom * 10_000.0
    range_bps = (candle.high - candle.low) / denom * 10_000.0
    if candle.high > candle.low:
        close_position = 2.0 * (candle.close - candle.low) / (candle.high - candle.low) - 1.0
    else:
        close_position = 0.0

    dt = datetime.fromtimestamp(candle.timestamp_ms / 1000, tz=timezone.utc)
    minute_of_day = dt.hour * 60 + dt.minute
    hour_angle = 2.0 * math.pi * minute_of_day / 1440.0
    dow_angle = 2.0 * math.pi * dt.weekday() / 7.0
    values.extend(
        (
            _clip(body_bps / 20.0),
            _clip(range_bps / 20.0),
            _clip(close_position, 1.0),
            math.sin(hour_angle),
            math.cos(hour_angle),
            math.sin(dow_angle),
            math.cos(dow_angle),
        )
    )
    return tuple(values)


def train_price_baseline(bundle_path: Path, output_dir: Path, progress: Progress | None = None) -> dict[str, object]:
    horizons = tuple(forecast_minutes())
    feature_names = _feature_names()
    classifiers = {h: AdaGradLogistic(len(feature_names)) for h in horizons}
    regressors = {h: AdaGradRegressor(len(feature_names)) for h in horizons}
    train_metrics = {h: Metrics() for h in horizons}
    holdout_metrics = {h: Metrics() for h in horizons}
    pending: dict[int, list[PendingExample]] = {}
    recent: dict[int, Candle] = {}
    recent_order: deque[int] = deque()
    candles_seen = 0
    scheduled = 0

    if progress is not None:
        progress(
            "price_training_started",
            model_version=MODEL_VERSION,
            horizons=list(horizons),
            holdout_start_utc=HOLDOUT_START_UTC.isoformat(),
            feature_count=len(feature_names),
        )

    for candle in iter_canonical_candles(bundle_path, progress=progress):
        candles_seen += 1

        # Any exact-target examples skipped by a market/data gap are discarded.
        stale_targets = [target for target in pending if target < candle.timestamp_ms]
        for target in stale_targets:
            pending.pop(target, None)

        due = pending.pop(candle.timestamp_ms, [])
        for example in due:
            actual_bps = (candle.close / example.base_close - 1.0) * 10_000.0
            if actual_bps == 0.0:
                continue
            classifier = classifiers[example.horizon_min]
            regressor = regressors[example.horizon_min]
            if example.is_train:
                p = classifier.predict(example.features)
                pred_bps = regressor.predict_scaled(example.features) * 20.0
                train_metrics[example.horizon_min].add(p, pred_bps, actual_bps)
                classifier.update(example.features, 1 if actual_bps > 0 else 0)
                target_scaled = _clip(actual_bps / 20.0, 10.0)
                regressor.update(example.features, target_scaled)
            else:
                p = classifier.predict(example.features)
                pred_bps = regressor.predict_scaled(example.features) * 20.0
                holdout_metrics[example.horizon_min].add(p, pred_bps, actual_bps)

        while recent_order and recent_order[0] < candle.timestamp_ms - 40 * MINUTE_MS:
            old = recent_order.popleft()
            recent.pop(old, None)

        x = _features(candle, recent)
        is_train = candle.timestamp_ms < HOLDOUT_START_MS
        for horizon in horizons:
            target_ms = candle.timestamp_ms + horizon * MINUTE_MS
            pending.setdefault(target_ms, []).append(
                PendingExample(horizon, x, candle.close, candle.timestamp_ms, is_train)
            )
            scheduled += 1

        recent[candle.timestamp_ms] = candle
        recent_order.append(candle.timestamp_ms)

    artifact = {
        "system": "AI Global Trader",
        "market": os.getenv("AI_GLOBAL_TRADER_MARKET", "XAUUSD"),
        "model_version": MODEL_VERSION,
        "model_type": "price_only_online_adagrad_baseline",
        "purpose": "research_baseline_not_promoted",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "holdout_start_utc": HOLDOUT_START_UTC.isoformat(),
        "horizons_minutes": list(horizons),
        "feature_names": list(feature_names),
        "candles_seen": candles_seen,
        "examples_scheduled": scheduled,
        "train_metrics": {str(h): train_metrics[h].summary() for h in horizons},
        "holdout_metrics": {str(h): holdout_metrics[h].summary() for h in horizons},
        "models": {
            str(h): {
                "direction_weights": classifiers[h].weights,
                "return_weights": regressors[h].weights,
                "return_scale_bps": 20.0,
            }
            for h in horizons
        },
    }

    output_dir.mkdir(parents=True, exist_ok=True)
    artifact_path = output_dir / f"{MODEL_VERSION}.json"
    tmp = tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False, dir=output_dir, prefix="model-", suffix=".tmp")
    tmp_path = Path(tmp.name)
    try:
        with tmp:
            json.dump(artifact, tmp, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            tmp.flush()
        tmp_path.replace(artifact_path)
    finally:
        tmp_path.unlink(missing_ok=True)

    summary = {
        "model_version": MODEL_VERSION,
        "artifact_path": str(artifact_path),
        "candles_seen": candles_seen,
        "holdout_start_utc": HOLDOUT_START_UTC.isoformat(),
        "horizons_minutes": list(horizons),
        "holdout_metrics": artifact["holdout_metrics"],
        "train_metrics": artifact["train_metrics"],
    }
    if progress is not None:
        progress("price_training_complete", **summary)
    return summary
