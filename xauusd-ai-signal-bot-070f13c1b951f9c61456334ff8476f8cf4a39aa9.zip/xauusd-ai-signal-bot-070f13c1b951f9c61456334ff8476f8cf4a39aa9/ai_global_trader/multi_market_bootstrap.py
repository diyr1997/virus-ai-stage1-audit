from __future__ import annotations

from .binance_demo_executor import start_binance_demo_executor
from .binance_paper_executor import start_binance_paper_executor
from .bootstrap import log, main as xau_main
from .crypto_market_experience import start_crypto_experience_collector
from .shadow_maintenance import start_shadow_maintenance
from .shadow_readiness import start_shadow_readiness


def main() -> int:
    crypto_enabled = start_crypto_experience_collector(log)
    binance_demo_enabled = start_binance_demo_executor(log)
    binance_paper_enabled = start_binance_paper_executor(log)
    shadow_maintenance_enabled = start_shadow_maintenance(log)
    shadow_readiness_enabled = start_shadow_readiness(log)
    log(
        "multi_market_bootstrap_ready",
        primary_market="XAUUSD",
        crypto_market="BTCUSDT",
        crypto_experience_enabled=crypto_enabled,
        binance_demo_market="XAUUSDT",
        binance_demo_enabled=binance_demo_enabled,
        binance_paper_market="XAUUSDT",
        binance_paper_enabled=binance_paper_enabled,
        shadow_maintenance_enabled=shadow_maintenance_enabled,
        shadow_readiness_enabled=shadow_readiness_enabled,
        shared_system="AI Global Trader",
        model_weights_shared=False,
        execution_enabled=binance_demo_enabled or binance_paper_enabled,
        real_money=False,
    )
    return xau_main()


if __name__ == "__main__":
    raise SystemExit(main())
