from __future__ import annotations

import json
import os
import threading
import time
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from typing import Any

MARKET = os.getenv("AI_GLOBAL_TRADER_CRYPTO_MARKET", "BTCUSDT").strip().upper() or "BTCUSDT"
BASE_URL = os.getenv("AI_GLOBAL_TRADER_BINANCE_MARKET_BASE_URL", "https://fapi.binance.com").rstrip("/")
POLL_SECONDS = max(10, int(os.getenv("AI_GLOBAL_TRADER_CRYPTO_POLL_SECONDS", "20")))
REQUEST_TIMEOUT = max(3, int(os.getenv("AI_GLOBAL_TRADER_CRYPTO_HTTP_TIMEOUT", "10")))


def _enabled() -> bool:
    return os.getenv("AI_GLOBAL_TRADER_CRYPTO_ENABLED", "false").strip().lower() in {"1", "true", "yes", "on"}


def _connect():
    import psycopg

    url = os.environ.get("DATABASE_URL", "").strip()
    if not url:
        raise RuntimeError("DATABASE_URL is not configured")
    return psycopg.connect(url)


def _get(path: str, **params: object) -> Any:
    query = urllib.parse.urlencode({k: v for k, v in params.items() if v is not None})
    url = f"{BASE_URL}{path}"
    if query:
        url += "?" + query
    req = urllib.request.Request(url, headers={"User-Agent": "AI-Global-Trader/crypto-experience-v1"})
    with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as response:
        return json.loads(response.read().decode("utf-8"))


def _ensure_schema() -> None:
    with _connect() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS ai_global_market_experience (
                    market TEXT NOT NULL,
                    candle_open_time TIMESTAMPTZ NOT NULL,
                    candle_close_time TIMESTAMPTZ NOT NULL,
                    observed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    close_price DOUBLE PRECISION NOT NULL,
                    features JSONB NOT NULL,
                    future_close_5m DOUBLE PRECISION,
                    future_return_5m_bps DOUBLE PRECISION,
                    future_close_15m DOUBLE PRECISION,
                    future_return_15m_bps DOUBLE PRECISION,
                    evaluated_5m_at TIMESTAMPTZ,
                    evaluated_15m_at TIMESTAMPTZ,
                    source TEXT NOT NULL DEFAULT 'binance_usds_futures_public',
                    PRIMARY KEY (market, candle_open_time)
                )
                """
            )
            cur.execute(
                """
                CREATE INDEX IF NOT EXISTS ai_global_market_experience_market_time_idx
                ON ai_global_market_experience (market, candle_open_time DESC)
                """
            )
        conn.commit()


def _f(x: object, default: float = 0.0) -> float:
    try:
        return float(x)
    except (TypeError, ValueError):
        return default


def _closed_klines() -> list[list[object]]:
    rows = _get("/fapi/v1/klines", symbol=MARKET, interval="1m", limit=32)
    now_ms = int(time.time() * 1000)
    return [row for row in rows if int(row[6]) < now_ms]


def _order_book_features() -> dict[str, float]:
    book = _get("/fapi/v1/depth", symbol=MARKET, limit=20)
    bids = [(_f(p), _f(q)) for p, q in book.get("bids", [])]
    asks = [(_f(p), _f(q)) for p, q in book.get("asks", [])]
    best_bid = bids[0][0] if bids else 0.0
    best_ask = asks[0][0] if asks else 0.0
    bid_qty_20 = sum(q for _, q in bids)
    ask_qty_20 = sum(q for _, q in asks)
    denom = bid_qty_20 + ask_qty_20
    imbalance = (bid_qty_20 - ask_qty_20) / denom if denom > 0 else 0.0
    mid = (best_bid + best_ask) / 2.0 if best_bid > 0 and best_ask > 0 else 0.0
    spread = best_ask - best_bid if best_bid > 0 and best_ask > 0 else 0.0
    spread_bps = spread / mid * 10000.0 if mid > 0 else 0.0
    return {
        "best_bid": best_bid,
        "best_ask": best_ask,
        "spread": spread,
        "spread_bps": spread_bps,
        "bid_qty_20": bid_qty_20,
        "ask_qty_20": ask_qty_20,
        "depth_imbalance_20": imbalance,
    }


def _derivatives_features() -> dict[str, float]:
    premium = _get("/fapi/v1/premiumIndex", symbol=MARKET)
    oi = _get("/fapi/v1/openInterest", symbol=MARKET)
    mark = _f(premium.get("markPrice"))
    index = _f(premium.get("indexPrice"))
    basis_bps = (mark - index) / index * 10000.0 if index > 0 else 0.0
    return {
        "mark_price": mark,
        "index_price": index,
        "basis_bps": basis_bps,
        "last_funding_rate": _f(premium.get("lastFundingRate")),
        "open_interest": _f(oi.get("openInterest")),
    }


def _taker_features() -> dict[str, float]:
    try:
        rows = _get("/futures/data/takerlongshortRatio", symbol=MARKET, period="5m", limit=1)
        row = rows[-1] if isinstance(rows, list) and rows else {}
        buy = _f(row.get("buyVol"))
        sell = _f(row.get("sellVol"))
        total = buy + sell
        pressure = (buy - sell) / total if total > 0 else 0.0
        return {
            "taker_buy_vol_5m": buy,
            "taker_sell_vol_5m": sell,
            "taker_buy_sell_ratio_5m": _f(row.get("buySellRatio")),
            "taker_pressure_5m": pressure,
        }
    except Exception:
        return {
            "taker_buy_vol_5m": 0.0,
            "taker_sell_vol_5m": 0.0,
            "taker_buy_sell_ratio_5m": 0.0,
            "taker_pressure_5m": 0.0,
        }


def _candle_features(rows: list[list[object]]) -> tuple[datetime, datetime, float, dict[str, float]]:
    row = rows[-1]
    open_ms = int(row[0])
    close_ms = int(row[6])
    close = _f(row[4])
    closes = [_f(r[4]) for r in rows]
    volumes = [_f(r[5]) for r in rows]
    quote_volumes = [_f(r[7]) for r in rows]
    trades = [_f(r[8]) for r in rows]
    taker_buy_quote = [_f(r[10]) for r in rows]

    def ret_bps(n: int) -> float:
        if len(closes) <= n or closes[-1 - n] <= 0:
            return 0.0
        return (closes[-1] / closes[-1 - n] - 1.0) * 10000.0

    quote = quote_volumes[-1] if quote_volumes else 0.0
    buy_q = taker_buy_quote[-1] if taker_buy_quote else 0.0
    sell_q = max(0.0, quote - buy_q)
    qdenom = buy_q + sell_q
    candle_taker_pressure = (buy_q - sell_q) / qdenom if qdenom > 0 else 0.0

    features = {
        "open": _f(row[1]),
        "high": _f(row[2]),
        "low": _f(row[3]),
        "close": close,
        "volume": volumes[-1] if volumes else 0.0,
        "quote_volume": quote,
        "trade_count": trades[-1] if trades else 0.0,
        "taker_buy_quote": buy_q,
        "candle_taker_pressure": candle_taker_pressure,
        "return_1m_bps": ret_bps(1),
        "return_5m_bps": ret_bps(5),
        "return_15m_bps": ret_bps(15),
    }
    return (
        datetime.fromtimestamp(open_ms / 1000.0, tz=timezone.utc),
        datetime.fromtimestamp(close_ms / 1000.0, tz=timezone.utc),
        close,
        features,
    )


def _upsert_snapshot(open_time: datetime, close_time: datetime, close: float, features: dict[str, float]) -> bool:
    payload = json.dumps(features, ensure_ascii=False, sort_keys=True)
    with _connect() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO ai_global_market_experience (
                    market, candle_open_time, candle_close_time, close_price, features
                ) VALUES (%s, %s, %s, %s, %s::jsonb)
                ON CONFLICT (market, candle_open_time) DO NOTHING
                """,
                (MARKET, open_time, close_time, close, payload),
            )
            inserted = cur.rowcount > 0
        conn.commit()
    return inserted


def _label_matured(current_open_time: datetime, current_close: float) -> tuple[int, int]:
    labeled5 = 0
    labeled15 = 0
    with _connect() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE ai_global_market_experience
                SET future_close_5m = %s,
                    future_return_5m_bps = (%s / close_price - 1.0) * 10000.0,
                    evaluated_5m_at = NOW()
                WHERE market = %s
                  AND candle_open_time = %s - INTERVAL '5 minutes'
                  AND future_close_5m IS NULL
                """,
                (current_close, current_close, MARKET, current_open_time),
            )
            labeled5 = max(0, cur.rowcount)
            cur.execute(
                """
                UPDATE ai_global_market_experience
                SET future_close_15m = %s,
                    future_return_15m_bps = (%s / close_price - 1.0) * 10000.0,
                    evaluated_15m_at = NOW()
                WHERE market = %s
                  AND candle_open_time = %s - INTERVAL '15 minutes'
                  AND future_close_15m IS NULL
                """,
                (current_close, current_close, MARKET, current_open_time),
            )
            labeled15 = max(0, cur.rowcount)
        conn.commit()
    return labeled5, labeled15


def collect_once(log) -> None:
    rows = _closed_klines()
    if len(rows) < 16:
        raise RuntimeError(f"insufficient closed Binance M1 rows: {len(rows)}")
    open_time, close_time, close, features = _candle_features(rows)
    features.update(_order_book_features())
    features.update(_derivatives_features())
    features.update(_taker_features())
    inserted = _upsert_snapshot(open_time, close_time, close, features)
    labeled5, labeled15 = _label_matured(open_time, close)
    if inserted or labeled5 or labeled15:
        log(
            "crypto_experience_updated",
            market=MARKET,
            candle_open_time=open_time.isoformat(),
            close=close,
            inserted=inserted,
            labeled_5m=labeled5,
            labeled_15m=labeled15,
            spread_bps=round(features.get("spread_bps", 0.0), 6),
            depth_imbalance_20=round(features.get("depth_imbalance_20", 0.0), 6),
            taker_pressure_5m=round(features.get("taker_pressure_5m", 0.0), 6),
            open_interest=features.get("open_interest", 0.0),
            funding_rate=features.get("last_funding_rate", 0.0),
        )


def _loop(log) -> None:
    _ensure_schema()
    log("crypto_experience_collector_started", market=MARKET, base_url=BASE_URL, poll_seconds=POLL_SECONDS)
    last_error: str | None = None
    while True:
        try:
            collect_once(log)
            last_error = None
        except Exception as exc:
            message = f"{type(exc).__name__}: {exc}"
            if message != last_error:
                log("crypto_experience_collector_error", market=MARKET, error=type(exc).__name__, message=str(exc))
                last_error = message
        time.sleep(POLL_SECONDS)


def start_crypto_experience_collector(log) -> bool:
    if not _enabled():
        log("crypto_experience_collector_disabled", market=MARKET)
        return False
    thread = threading.Thread(target=_loop, args=(log,), name=f"crypto-experience-{MARKET.lower()}", daemon=True)
    thread.start()
    return True
