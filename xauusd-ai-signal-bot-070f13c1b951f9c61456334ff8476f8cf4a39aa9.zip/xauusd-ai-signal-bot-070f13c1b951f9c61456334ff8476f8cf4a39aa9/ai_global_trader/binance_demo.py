from __future__ import annotations

import hashlib
import hmac
import json
import math
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from decimal import Decimal, ROUND_UP
from typing import Any


@dataclass(frozen=True)
class DemoConfig:
    api_key: str
    api_secret: str
    base_url: str
    allow_orders: bool

    @classmethod
    def from_env(cls) -> "DemoConfig":
        api_key = os.getenv("BINANCE_TESTNET_API_KEY", "").strip()
        api_secret = os.getenv("BINANCE_TESTNET_API_SECRET", "").strip()
        base_url = os.getenv("BINANCE_TESTNET_BASE_URL", "https://demo-fapi.binance.com").strip().rstrip("/")
        allow_orders = os.getenv("BINANCE_ALLOW_TESTNET_ORDERS", "0").strip() == "1"
        if not api_key or not api_secret:
            raise RuntimeError("missing Binance DEMO/Testnet API credentials")
        host = (urllib.parse.urlparse(base_url).hostname or "").lower()
        if not host or not ("demo" in host or "testnet" in host):
            raise RuntimeError(f"refusing non-demo Binance host: {host}")
        if host in {"fapi.binance.com", "api.binance.com", "www.binance.com"}:
            raise RuntimeError(f"refusing production Binance host: {host}")
        return cls(api_key=api_key, api_secret=api_secret, base_url=base_url, allow_orders=allow_orders)


class BinanceFuturesDemoClient:
    """Minimal USD(S)-M Futures DEMO client with a hard production-host guard."""

    def __init__(self, config: DemoConfig | None = None) -> None:
        self.config = config or DemoConfig.from_env()

    def _query(self, params: dict[str, Any] | None, *, signed: bool) -> str:
        payload = dict(params or {})
        if signed:
            payload.setdefault("timestamp", int(time.time() * 1000))
            payload.setdefault("recvWindow", 5000)
        query = urllib.parse.urlencode(payload, doseq=True)
        if signed:
            sig = hmac.new(
                self.config.api_secret.encode("utf-8"),
                query.encode("utf-8"),
                hashlib.sha256,
            ).hexdigest()
            query = f"{query}&signature={sig}"
        return query

    def _request(self, method: str, path: str, *, params: dict[str, Any] | None = None, signed: bool = True) -> Any:
        query = self._query(params, signed=signed)
        url = f"{self.config.base_url}{path}"
        data = None
        if method.upper() == "GET":
            if query:
                url += "?" + query
        else:
            data = query.encode("utf-8")
        headers = {"User-Agent": "AI-Global-Trader-Binance-Demo/1.0"}
        if signed:
            headers["X-MBX-APIKEY"] = self.config.api_key
        if data is not None:
            headers["Content-Type"] = "application/x-www-form-urlencoded"
        req = urllib.request.Request(url, data=data, method=method.upper(), headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=15) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")[:1000]
            raise RuntimeError(f"Binance DEMO HTTP {exc.code}: {body}") from exc

    def exchange_info(self) -> Any:
        return self._request("GET", "/fapi/v1/exchangeInfo", signed=False)

    def ticker_price(self, symbol: str) -> float:
        payload = self._request("GET", "/fapi/v1/ticker/price", params={"symbol": symbol}, signed=False)
        return float(payload["price"])

    def account(self) -> Any:
        return self._request("GET", "/fapi/v2/account")

    def balance(self) -> Any:
        return self._request("GET", "/fapi/v2/balance")

    def positions(self, symbol: str) -> list[dict[str, Any]]:
        payload = self._request("GET", "/fapi/v2/positionRisk", params={"symbol": symbol})
        if isinstance(payload, list):
            return [dict(row) for row in payload]
        return [dict(payload)]

    def symbol_rules(self, symbol: str) -> dict[str, Any]:
        info = self.exchange_info()
        row = next((s for s in info.get("symbols", []) if str(s.get("symbol")) == symbol), None)
        if row is None:
            raise RuntimeError(f"{symbol} is not available in Binance DEMO exchangeInfo")
        filters = {str(f.get("filterType")): f for f in row.get("filters", [])}
        lot = filters.get("MARKET_LOT_SIZE") or filters.get("LOT_SIZE") or {}
        notional = filters.get("MIN_NOTIONAL") or filters.get("NOTIONAL") or {}
        return {
            "status": row.get("status"),
            "quantity_precision": int(row.get("quantityPrecision", 8)),
            "min_qty": Decimal(str(lot.get("minQty", "0"))),
            "step_size": Decimal(str(lot.get("stepSize", "0"))),
            "max_qty": Decimal(str(lot.get("maxQty", "0"))),
            "min_notional": Decimal(str(notional.get("notional") or notional.get("minNotional") or "5")),
        }

    def minimum_market_quantity(self, symbol: str, *, target_notional_usdt: Decimal = Decimal("10")) -> str:
        rules = self.symbol_rules(symbol)
        if str(rules.get("status") or "") not in {"TRADING", "PENDING_TRADING"}:
            raise RuntimeError(f"{symbol} DEMO status is {rules.get('status')}")
        price = Decimal(str(self.ticker_price(symbol)))
        if price <= 0:
            raise RuntimeError(f"invalid DEMO price for {symbol}")
        min_notional = max(Decimal("5"), Decimal(rules["min_notional"]), target_notional_usdt)
        min_qty = Decimal(rules["min_qty"])
        step = Decimal(rules["step_size"])
        if step <= 0:
            raise RuntimeError(f"invalid DEMO step size for {symbol}")
        needed = max(min_qty, min_notional / price)
        steps = (needed / step).to_integral_value(rounding=ROUND_UP)
        qty = steps * step
        max_qty = Decimal(rules["max_qty"])
        if max_qty > 0 and qty > max_qty:
            raise RuntimeError(f"calculated quantity exceeds maxQty for {symbol}")
        precision = int(rules["quantity_precision"])
        text = f"{qty:.{precision}f}".rstrip("0").rstrip(".")
        return text or "0"

    def market_order(self, *, symbol: str, side: str, quantity: str, reduce_only: bool = False) -> Any:
        if not self.config.allow_orders:
            raise RuntimeError("DEMO order placement disabled; set BINANCE_ALLOW_TESTNET_ORDERS=1")
        params: dict[str, Any] = {
            "symbol": symbol,
            "side": side.upper(),
            "type": "MARKET",
            "quantity": quantity,
            "newOrderRespType": "RESULT",
        }
        if reduce_only:
            params["reduceOnly"] = "true"
        return self._request("POST", "/fapi/v1/order", params=params)
