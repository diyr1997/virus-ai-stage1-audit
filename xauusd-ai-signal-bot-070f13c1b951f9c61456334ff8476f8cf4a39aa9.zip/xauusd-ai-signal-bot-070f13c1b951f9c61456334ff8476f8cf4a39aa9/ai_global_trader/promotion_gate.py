from __future__ import annotations

from dataclasses import dataclass
from typing import Any

CORE_HORIZONS = (1, 3, 5, 10, 15)
MIN_ENABLED_CORE_HORIZONS = 3
MIN_SELECTIVE_ACCURACY = 0.535
MIN_DIRECTIONAL_EDGE_BPS = 0.05
MIN_HOLDOUT_SIGNALS_PER_HORIZON = 10_000
MIN_COMBINED_HOLDOUT_SIGNALS = 40_000
MIN_WEIGHTED_ACCURACY = 0.54


@dataclass(frozen=True)
class OfflineGateReport:
    passed: bool
    model_version: str
    enabled_horizons: tuple[int, ...]
    combined_signals: int
    weighted_accuracy: float | None
    reasons: tuple[str, ...]

    def as_dict(self) -> dict[str, object]:
        return {
            "passed": self.passed,
            "model_version": self.model_version,
            "enabled_horizons": list(self.enabled_horizons),
            "combined_signals": self.combined_signals,
            "weighted_accuracy": self.weighted_accuracy,
            "reasons": list(self.reasons),
            "requires_live_shadow_before_promotion": True,
        }


def evaluate_offline_candidate(artifact: dict[str, Any]) -> OfflineGateReport:
    model_version = str(artifact.get("model_version") or "unknown")
    models = dict(artifact.get("models") or {})
    selective = dict(artifact.get("selective_holdout_metrics") or {})
    enabled: list[int] = []
    reasons: list[str] = []
    combined_signals = 0
    combined_correct = 0

    for raw_horizon, raw_model in models.items():
        try:
            horizon = int(raw_horizon)
        except Exception:
            continue
        model = dict(raw_model or {})
        signal_filter = dict(model.get("signal_filter") or {})
        if not bool(signal_filter.get("enabled", True)):
            continue
        enabled.append(horizon)
        metrics = dict(selective.get(str(horizon)) or {})
        signals = int(metrics.get("signals") or 0)
        correct = int(metrics.get("correct") or 0)
        accuracy_raw = metrics.get("direction_accuracy")
        edge_raw = metrics.get("avg_directional_edge_bps")
        accuracy = None if accuracy_raw is None else float(accuracy_raw)
        edge = None if edge_raw is None else float(edge_raw)
        combined_signals += signals
        combined_correct += correct

        if signals < MIN_HOLDOUT_SIGNALS_PER_HORIZON:
            reasons.append(f"{horizon}m: holdout signals {signals} < {MIN_HOLDOUT_SIGNALS_PER_HORIZON}")
        if accuracy is None or accuracy < MIN_SELECTIVE_ACCURACY:
            reasons.append(f"{horizon}m: selective accuracy {accuracy} < {MIN_SELECTIVE_ACCURACY}")
        if edge is None or edge < MIN_DIRECTIONAL_EDGE_BPS:
            reasons.append(f"{horizon}m: directional edge {edge} < {MIN_DIRECTIONAL_EDGE_BPS} bps")

    enabled_core = [h for h in enabled if h in CORE_HORIZONS]
    if len(enabled_core) < MIN_ENABLED_CORE_HORIZONS:
        reasons.append(
            f"enabled core horizons {len(enabled_core)} < {MIN_ENABLED_CORE_HORIZONS}"
        )
    if combined_signals < MIN_COMBINED_HOLDOUT_SIGNALS:
        reasons.append(
            f"combined holdout signals {combined_signals} < {MIN_COMBINED_HOLDOUT_SIGNALS}"
        )

    weighted_accuracy = None if combined_signals == 0 else combined_correct / combined_signals
    if weighted_accuracy is None or weighted_accuracy < MIN_WEIGHTED_ACCURACY:
        reasons.append(
            f"weighted selective accuracy {weighted_accuracy} < {MIN_WEIGHTED_ACCURACY}"
        )

    return OfflineGateReport(
        passed=not reasons,
        model_version=model_version,
        enabled_horizons=tuple(sorted(enabled)),
        combined_signals=combined_signals,
        weighted_accuracy=weighted_accuracy,
        reasons=tuple(reasons),
    )
