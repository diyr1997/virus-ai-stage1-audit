from __future__ import annotations

from pathlib import Path
from typing import Callable

from . import price_training

MODEL_VERSION = "xauusd-price-baseline-v2-full-horizons"


def train_full_horizon_baseline(
    bundle_path: Path,
    output_dir: Path,
    progress: Callable[..., None] | None = None,
) -> dict[str, object]:
    # Keep v1 historical result immutable; v2 uses the restored full forecast horizon contract.
    price_training.MODEL_VERSION = MODEL_VERSION
    return price_training.train_price_baseline(bundle_path, output_dir, progress=progress)
