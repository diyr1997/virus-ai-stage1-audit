"use strict";

/**
 * Trading School Full Reader V2
 *
 * Goal: read legal/free sources sequentially from start to finish, keep the
 * source text privately in PostgreSQL, then build structured AI notes before
 * any idea is allowed into trading experiments.
 *
 * This module NEVER opens trades and NEVER edits production trading rules.
 */

const fs = require("fs");
const os = require("os");
const path = require("path");
const crypto = require("crypto");
const { promisify } = require("util");
const { execFile } = require("child_process");
const { Pool } = require("pg");
const { callGemini } = require("./ai-providers");

const execFileAsync = promisify(execFile);
const DATABASE_URL = String(
  process.env.DATABASE_URL || process.env.DATABASE_PUBLIC_URL || ""
).trim();
const PYTHON = process.env.PYTHON_BIN || path.join(__dirname, ".venv", "bin", "python");
const MANIFEST_PATH = path.join(__dirname, "trading_school", "library_manifest.json");
const PDF_READER = path.join(__dirname, "trading_school", "pdf_to_jsonl.py");
const ENABLED = String(process.env.TRADING_SCHOOL_READER_ENABLED || "1") !== "0";
const AI_ENABLED = !/^(0|false|no|disabled)$/i.test(
  String(process.env.TRADING_SCHOOL_AI_ENABLED || "1")
);
const PAGE_BATCH = Math.max(1, Math.min(20, Number(process.env.TRADING_SCHOOL_PAGE_BATCH || 6)));
const READ_INTERVAL_MS = Math.max(60_000, Number(process.env.TRADING_SCHOOL_READ_INTERVAL_MS || 5 * 60_000));
const AI_INTERVAL_MS = Math.max(5 * 60_000, Number(process.env.TRADING_SCHOOL_AI_INTERVAL_MS || 20 * 60_000));
const CHUNK_CHARS = Math.max(6000, Math.min(24000, Number(process.env.TRADING_SCHOOL_CHUNK_CHARS || 14000)));
const MAX_CHUNK_AI_ATTEMPTS = Math.max(
  1,
  Number(process.env.TRADING_SCHOOL_MAX_CHUNK_AI_ATTEMPTS || 5)
);
// A PDF whose URL 404s, redirects to an HTML landing page or refuses this
// client will fail identically on every reading tick. Without a bound that is
// one failed download per minute, forever, per bad source.
const MAX_BOOK_INGEST_ATTEMPTS = Math.max(
  1,
  Number(process.env.TRADING_SCHOOL_MAX_BOOK_INGEST_ATTEMPTS || 5)
);

const pool = DATABASE_URL
  ? new Pool({ connectionString: DATABASE_URL, max: 2, idleTimeoutMillis: 30_000 })
  : null;

let reading = false;
let aiReading = false;

function manifest() {
  return JSON.parse(fs.readFileSync(MANIFEST_PATH, "utf8"));
}

function hash(text) {
  return crypto.createHash("sha256").update(String(text || ""), "utf8").digest("hex");
}

function decodeEntities(text) {
  const named = {
    amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " ",
    ndash: "–", mdash: "—", hellip: "…", rsquo: "’", lsquo: "‘",
    rdquo: "”", ldquo: "“", copy: "©", reg: "®",
  };
  return String(text || "").replace(/&(#x?[0-9a-f]+|[a-z][a-z0-9]+);/gi, (m, code) => {
    if (code[0] === "#") {
      const hex = code[1]?.toLowerCase() === "x";
      const n = parseInt(code.slice(hex ? 2 : 1), hex ? 16 : 10);
      return Number.isFinite(n) ? String.fromCodePoint(n) : " ";
    }
    return named[code.toLowerCase()] ?? " ";
  });
}

function stripHtml(html) {
  return decodeEntities(
    String(html || "")
      .replace(/<script\b[\s\S]*?<\/script>/gi, " ")
      .replace(/<style\b[\s\S]*?<\/style>/gi, " ")
      .replace(/<svg\b[\s\S]*?<\/svg>/gi, " ")
      .replace(/<noscript\b[\s\S]*?<\/noscript>/gi, " ")
      .replace(/<nav\b[\s\S]*?<\/nav>/gi, " ")
      .replace(/<footer\b[\s\S]*?<\/footer>/gi, " ")
      .replace(/<br\s*\/?>/gi, "\n")
      .replace(/<\/(p|div|section|article|h[1-6]|li|tr)>/gi, "\n")
      .replace(/<[^>]+>/g, " ")
  )
    .replace(/\r/g, "")
    .replace(/[ \t]+/g, " ")
    .replace(/\n[ \t]+/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function pageTitle(html, fallback = "") {
  const m = String(html || "").match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  return stripHtml(m?.[1] || fallback).slice(0, 500);
}

function cleanUrl(raw, base) {
  try {
    const u = new URL(raw, base);
    u.hash = "";
    if (!["http:", "https:"].includes(u.protocol)) return null;
    if (/\.(css|js|png|jpe?g|gif|svg|webp|ico|zip|epub|mp4|mp3|woff2?|ttf)$/i.test(u.pathname)) return null;
    return u.toString();
  } catch {
    return null;
  }
}

function linksFromHtml(html, base) {
  const out = new Set();
  const rx = /<a\b[^>]*?href\s*=\s*["']([^"']+)["'][^>]*>/gi;
  let m;
  while ((m = rx.exec(String(html || "")))) {
    const u = cleanUrl(m[1], base);
    if (u) out.add(u);
  }
  return [...out];
}

function splitText(text, maxChars = CHUNK_CHARS) {
  const paragraphs = String(text || "").split(/\n{2,}/).map((x) => x.trim()).filter(Boolean);
  const chunks = [];
  let current = "";
  for (const p of paragraphs) {
    if (current && current.length + p.length + 2 > maxChars) {
      chunks.push(current);
      current = "";
    }
    if (p.length > maxChars) {
      if (current) chunks.push(current), (current = "");
      for (let i = 0; i < p.length; i += maxChars) chunks.push(p.slice(i, i + maxChars));
    } else {
      current += (current ? "\n\n" : "") + p;
    }
  }
  if (current) chunks.push(current);
  return chunks;
}

async function fetchText(url) {
  const response = await fetch(url, {
    headers: {
      "user-agent": "XAUUSD-Trading-School/2.0 (private educational reader)",
      accept: "text/html,application/xhtml+xml,text/plain;q=0.9,*/*;q=0.5",
    },
    redirect: "follow",
    signal: AbortSignal.timeout(60_000),
  });
  if (!response.ok) throw new Error(`HTTP ${response.status} ${url}`);
  return await response.text();
}

async function ensureSchema() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS trading_school_books (
      book_key VARCHAR(80) PRIMARY KEY,
      title TEXT NOT NULL,
      source_type VARCHAR(40) NOT NULL,
      source_url TEXT,
      access_mode VARCHAR(60),
      role TEXT,
      status VARCHAR(32) NOT NULL DEFAULT 'NEW',
      discovered_pages INT NOT NULL DEFAULT 0,
      ingested_pages INT NOT NULL DEFAULT 0,
      summarized_chunks INT NOT NULL DEFAULT 0,
      total_chars BIGINT NOT NULL DEFAULT 0,
      last_error TEXT,
      meta JSONB NOT NULL DEFAULT '{}'::jsonb,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS trading_school_pages (
      id BIGSERIAL PRIMARY KEY,
      book_key VARCHAR(80) NOT NULL REFERENCES trading_school_books(book_key) ON DELETE CASCADE,
      seq BIGINT NOT NULL,
      url TEXT NOT NULL,
      title TEXT,
      status VARCHAR(24) NOT NULL DEFAULT 'PENDING',
      char_count INT NOT NULL DEFAULT 0,
      error TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE(book_key, url)
    );

    CREATE INDEX IF NOT EXISTS idx_trading_school_pages_pending
      ON trading_school_pages(book_key, status, seq);

    CREATE TABLE IF NOT EXISTS trading_school_chunks (
      id BIGSERIAL PRIMARY KEY,
      book_key VARCHAR(80) NOT NULL REFERENCES trading_school_books(book_key) ON DELETE CASCADE,
      page_id BIGINT REFERENCES trading_school_pages(id) ON DELETE CASCADE,
      chunk_no INT NOT NULL,
      locator TEXT,
      source_url TEXT,
      content_hash CHAR(64) NOT NULL,
      content TEXT NOT NULL,
      ai_status VARCHAR(24) NOT NULL DEFAULT 'PENDING',
      summary TEXT,
      concepts JSONB NOT NULL DEFAULT '{}'::jsonb,
      ai_error TEXT,
      ai_attempts INT NOT NULL DEFAULT 0,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE(book_key, content_hash)
    );

    ALTER TABLE trading_school_chunks
      ADD COLUMN IF NOT EXISTS ai_attempts INT NOT NULL DEFAULT 0;

    ALTER TABLE trading_school_books
      ADD COLUMN IF NOT EXISTS ingest_attempts INT NOT NULL DEFAULT 0;

    CREATE INDEX IF NOT EXISTS idx_trading_school_chunks_ai
      ON trading_school_chunks(ai_status, ai_attempts, id);

    CREATE TABLE IF NOT EXISTS trading_school_book_memory (
      book_key VARCHAR(80) PRIMARY KEY REFERENCES trading_school_books(book_key) ON DELETE CASCADE,
      synthesis TEXT NOT NULL DEFAULT '',
      principles JSONB NOT NULL DEFAULT '[]'::jsonb,
      exceptions JSONB NOT NULL DEFAULT '[]'::jsonb,
      timeframe_map JSONB NOT NULL DEFAULT '{}'::jsonb,
      experiment_seeds JSONB NOT NULL DEFAULT '[]'::jsonb,
      source_chunks INT NOT NULL DEFAULT 0,
      complete BOOLEAN NOT NULL DEFAULT FALSE,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
}

async function seedManifest() {
  const m = manifest();
  for (const s of m.sources || []) {
    const sourceUrl = s.entry_url || s.url || s.landing_url || null;
    const status = s.type === "user_copy_required" ? "WAITING_USER_COPY" : "QUEUED";
    await pool.query(
      `INSERT INTO trading_school_books(book_key,title,source_type,source_url,access_mode,role,status,meta)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8::jsonb)
       ON CONFLICT(book_key) DO UPDATE SET
         title=EXCLUDED.title, source_type=EXCLUDED.source_type, source_url=EXCLUDED.source_url,
         access_mode=EXCLUDED.access_mode, role=EXCLUDED.role,
         meta=trading_school_books.meta || EXCLUDED.meta, updated_at=NOW()`,
      [s.key, s.title, s.type, sourceUrl, s.access, s.role, status, JSON.stringify(s)]
    );
    if (s.entry_url && s.type.startsWith("html")) {
      await pool.query(
        `INSERT INTO trading_school_pages(book_key,seq,url,status)
         VALUES($1,1,$2,'PENDING') ON CONFLICT(book_key,url) DO NOTHING`,
        [s.key, s.entry_url]
      );
    }
  }
}

function allowedLink(source, candidate) {
  try {
    const u = new URL(candidate);
    const hosts = new Set((source.allowed_hosts || []).map((x) => String(x).toLowerCase()));
    if (hosts.size && !hosts.has(u.hostname.toLowerCase())) return false;
    if (source.path_prefix && !u.pathname.startsWith(source.path_prefix)) return false;
    if (u.pathname.includes("/comments/") || /\/tag\//i.test(u.pathname)) return false;
    return true;
  } catch {
    return false;
  }
}

async function addDiscoveredLinks(source, bookKey, links, recursive) {
  if (!recursive && links.length === 0) return;
  const maxPages = Number(source.max_pages || 200);
  const count = await pool.query(`SELECT COUNT(*)::int AS n FROM trading_school_pages WHERE book_key=$1`, [bookKey]);
  let n = Number(count.rows[0]?.n || 0);
  for (const link of links) {
    if (n >= maxPages) break;
    if (!allowedLink(source, link)) continue;
    const inserted = await pool.query(
      `INSERT INTO trading_school_pages(book_key,seq,url,status)
       VALUES($1::varchar(80),(SELECT COALESCE(MAX(seq),0)+1 FROM trading_school_pages WHERE book_key=$1::varchar(80)),$2,'PENDING')
       ON CONFLICT(book_key,url) DO NOTHING RETURNING id`,
      [bookKey, link]
    );
    if (inserted.rowCount) n += 1;
  }
}

// Declared per source, with the historical behaviour of the two original books
// as the fallback so their crawls are byte-for-byte unchanged.
function linkDiscoveryMode(source) {
  const declared = String(source?.link_discovery || "").trim().toLowerCase();
  if (declared === "recursive" || declared === "entry_only" || declared === "none") return declared;
  if (source?.key === "fpp3") return "recursive";
  return "entry_only";
}

async function ingestHtmlPage(source, page) {
  const html = await fetchText(page.url);
  const title = pageTitle(html, page.url);
  const text = stripHtml(html);
  if (text.length < 300) throw new Error(`Page text too short (${text.length})`);

  const chunks = splitText(text);
  for (let i = 0; i < chunks.length; i++) {
    const content = chunks[i];
    await pool.query(
      `INSERT INTO trading_school_chunks(book_key,page_id,chunk_no,locator,source_url,content_hash,content)
       VALUES($1,$2,$3,$4,$5,$6,$7)
       ON CONFLICT(book_key,content_hash) DO NOTHING`,
      [page.book_key, page.id, i + 1, `${title} / part ${i + 1}`, page.url, hash(content), content]
    );
  }

  // Link discovery used to be hard-coded to two book keys, so any source added
  // to the manifest later read its entry page and stopped there - it was never
  // allowed to look for chapters. It is now declared by the source itself.
  //   "entry_only" (default) follow links found on the entry page only
  //   "recursive"             follow links found on every page
  //   "none"                  do not crawl at all
  const links = linksFromHtml(html, page.url);
  const discovery = linkDiscoveryMode(source);
  if (discovery === "recursive") {
    await addDiscoveredLinks(source, page.book_key, links, true);
  } else if (discovery === "entry_only" && page.url === source.entry_url) {
    await addDiscoveredLinks(source, page.book_key, links, false);
  }

  await pool.query(
    `UPDATE trading_school_pages SET status='INGESTED',title=$2,char_count=$3,error=NULL,updated_at=NOW() WHERE id=$1`,
    [page.id, title, text.length]
  );
}

async function ingestPdfBook(source) {
  const existing = await pool.query(
    `SELECT COUNT(*)::int AS n FROM trading_school_pages WHERE book_key=$1 AND status='INGESTED'`,
    [source.key]
  );
  if (Number(existing.rows[0]?.n || 0) > 0) return false;

  const book = await pool.query(
    `SELECT status, ingest_attempts FROM trading_school_books WHERE book_key=$1`,
    [source.key]
  );
  if (!shouldRetryBookIngest(book.rows[0]?.status, book.rows[0]?.ingest_attempts)) return false;

  const tmp = path.join(os.tmpdir(), `trading_school_${source.key}_${Date.now()}.jsonl`);
  try {
    const { stdout, stderr } = await execFileAsync(
      PYTHON,
      [PDF_READER, "--url", source.url, "--output", tmp],
      { timeout: 20 * 60_000, maxBuffer: 1024 * 1024 }
    );
    if (stderr?.trim()) console.warn(`📚 PDF ${source.key}: ${stderr.trim().slice(0, 500)}`);
    const meta = JSON.parse(String(stdout || "{}").trim().split(/\r?\n/).filter(Boolean).pop() || "{}");
    const lines = fs.readFileSync(tmp, "utf8").split(/\r?\n/).filter(Boolean);
    let chars = 0;
    for (const line of lines) {
      const record = JSON.parse(line);
      const text = String(record.text || "").trim();
      const pageUrl = `${source.url}#page=${record.page}`;
      const pageResult = await pool.query(
        `INSERT INTO trading_school_pages(book_key,seq,url,title,status,char_count,error)
         VALUES($1,$2,$3,$4,'INGESTED',$5,$6)
         ON CONFLICT(book_key,url) DO UPDATE SET status='INGESTED',char_count=EXCLUDED.char_count,error=EXCLUDED.error,updated_at=NOW()
         RETURNING id`,
        [source.key, record.page, pageUrl, `Page ${record.page}`, text.length, record.error]
      );
      const pageId = pageResult.rows[0].id;
      chars += text.length;
      for (const [idx, content] of splitText(text).entries()) {
        if (!content.trim()) continue;
        await pool.query(
          `INSERT INTO trading_school_chunks(book_key,page_id,chunk_no,locator,source_url,content_hash,content)
           VALUES($1,$2,$3,$4,$5,$6,$7) ON CONFLICT(book_key,content_hash) DO NOTHING`,
          [source.key, pageId, idx + 1, `Page ${record.page} / part ${idx + 1}`, pageUrl, hash(content), content]
        );
      }
    }
    await pool.query(
      `UPDATE trading_school_books SET status='INGESTED',total_chars=$2,meta=meta || $3::jsonb,last_error=NULL,updated_at=NOW() WHERE book_key=$1`,
      [source.key, chars, JSON.stringify({ pdf: meta })]
    );
    console.log(`📚 TRADING SCHOOL: full PDF ingested ${source.key} | pages=${lines.length} chars=${chars}`);
    return true;
  } finally {
    fs.unlink(tmp, () => {});
  }
}

async function refreshBookStats(bookKey) {
  await pool.query(
    `UPDATE trading_school_books b SET
       discovered_pages=(SELECT COUNT(*) FROM trading_school_pages p WHERE p.book_key=b.book_key),
       ingested_pages=(SELECT COUNT(*) FROM trading_school_pages p WHERE p.book_key=b.book_key AND p.status='INGESTED'),
       summarized_chunks=(SELECT COUNT(*) FROM trading_school_chunks c WHERE c.book_key=b.book_key AND c.ai_status='DONE'),
       total_chars=(SELECT COALESCE(SUM(char_count),0) FROM trading_school_pages p WHERE p.book_key=b.book_key),
       status=CASE
         WHEN b.status='WAITING_USER_COPY' THEN b.status
         WHEN EXISTS(SELECT 1 FROM trading_school_pages p WHERE p.book_key=b.book_key AND p.status='PENDING') THEN 'READING'
         WHEN EXISTS(SELECT 1 FROM trading_school_pages p WHERE p.book_key=b.book_key) THEN 'INGESTED'
         ELSE b.status END,
       updated_at=NOW()
     WHERE b.book_key=$1`,
    [bookKey]
  );
}

async function readingTick() {
  if (!ENABLED || !pool || reading) return;
  reading = true;
  try {
    await ensureSchema();
    await seedManifest();
    const m = manifest();

    for (const source of m.sources || []) {
      if (source.type === "user_copy_required") continue;
      if (source.type === "pdf") {
        try {
          await ingestPdfBook(source);
        } catch (error) {
          const attempted = await pool.query(
            `UPDATE trading_school_books
             SET status='ERROR',last_error=$2,ingest_attempts=ingest_attempts+1,updated_at=NOW()
             WHERE book_key=$1 RETURNING ingest_attempts`,
            [source.key, String(error?.message || error).slice(0, 3000)]
          );
          const attempts = Number(attempted.rows[0]?.ingest_attempts || 0);
          const spent = !shouldRetryBookIngest("ERROR", attempts);
          console.warn(
            `📚 PDF ${source.key} failed (attempt ${attempts}/${MAX_BOOK_INGEST_ATTEMPTS}` +
              `${spent ? ", giving up" : ""}): ${String(error?.message || error).slice(0, 400)}`
          );
        }
        await refreshBookStats(source.key);
      }
    }

    const pending = await pool.query(
      `SELECT p.id,p.book_key,p.seq,p.url,b.meta
       FROM trading_school_pages p JOIN trading_school_books b ON b.book_key=p.book_key
       WHERE p.status='PENDING' AND b.source_type LIKE 'html%'
       ORDER BY p.book_key,p.seq LIMIT $1`,
      [PAGE_BATCH]
    );

    for (const page of pending.rows) {
      const source = page.meta || {};
      try {
        await ingestHtmlPage(source, page);
        console.log(`📚 READ ${page.book_key} #${page.seq}: ${page.url}`);
      } catch (error) {
        await pool.query(
          `UPDATE trading_school_pages SET status='ERROR',error=$2,updated_at=NOW() WHERE id=$1`,
          [page.id, String(error?.message || error).slice(0, 2000)]
        );
        console.warn(`📚 READ ERROR ${page.book_key}: ${String(error?.message || error).slice(0, 500)}`);
      }
      await refreshBookStats(page.book_key);
    }
  } catch (error) {
    console.error("📚 TRADING SCHOOL READER:", error);
  } finally {
    reading = false;
  }
}

// Whether a book whose download keeps failing is still worth another tick.
function shouldRetryBookIngest(status, attempts, max = MAX_BOOK_INGEST_ATTEMPTS) {
  if (String(status || "").toUpperCase() !== "ERROR") return true;
  const parsed = Number(max);
  const limit = Number.isFinite(parsed) && parsed >= 1 ? Math.floor(parsed) : MAX_BOOK_INGEST_ATTEMPTS;
  return (Math.max(0, Number(attempts) || 0)) < limit;
}

// A chunk the model keeps refusing is retired instead of retried forever.
function nextChunkAiState(previousAttempts, max = MAX_CHUNK_AI_ATTEMPTS) {
  const attempts = Math.max(0, Number(previousAttempts) || 0) + 1;
  const limit = Math.max(1, Number(max) || 1);
  return { attempts, status: attempts >= limit ? "FAILED" : "RETRY" };
}

// A book is ready for whole-book synthesis once every chunk has settled --
// understood or permanently retired -- and at least one was understood.
function shouldSynthesizeBook(book) {
  const chunks = Number(book?.chunks) || 0;
  const done = Number(book?.done) || 0;
  const resolved = Number(book?.resolved) || 0;
  return chunks > 0 && done > 0 && resolved === chunks;
}

function parseAiJson(text) {
  const raw = String(text || "").trim();
  const fenced = raw.match(/```(?:json)?\s*([\s\S]*?)```/i)?.[1] || raw;
  const start = fenced.indexOf("{");
  const end = fenced.lastIndexOf("}");
  if (start < 0 || end <= start) throw new Error("AI did not return JSON object");
  return JSON.parse(fenced.slice(start, end + 1));
}

async function summarizeChunk(chunk) {
  const prompt = `You are building a private XAU/USD Trading School. Read this source chunk carefully IN CONTEXT. Do not give a live trade call. Do not copy long passages. Return strict JSON only with keys: summary (detailed paraphrase), concepts (array), rules (array of measurable hypotheses), exceptions (array), examples (array of paraphrased example lessons), timeframes (array from M1,M5,M15,M30,H1,GENERAL), cautions (array). Preserve nuance and conditions; do not reduce everything to candle names.\n\nBOOK: ${chunk.title}\nLOCATOR: ${chunk.locator}\nSOURCE TEXT:\n${chunk.content}`;
  const response = await callGemini(prompt);
  return parseAiJson(response);
}

async function summarizeOneChunk() {
  // Least-tried first, then by id. Ordering by id alone meant a chunk the model
  // keeps rejecting was re-picked on every single tick and nothing behind it
  // was ever read.
  const result = await pool.query(
    `SELECT c.id,c.book_key,c.locator,c.content,c.ai_attempts,b.title
     FROM trading_school_chunks c JOIN trading_school_books b ON b.book_key=c.book_key
     WHERE c.ai_status IN('PENDING','RETRY')
     ORDER BY c.ai_attempts, c.id LIMIT 1`
  );
  const chunk = result.rows[0];
  if (!chunk) return false;
  try {
    const notes = await summarizeChunk(chunk);
    await pool.query(
      `UPDATE trading_school_chunks SET ai_status='DONE',summary=$2,concepts=$3::jsonb,ai_error=NULL,ai_attempts=ai_attempts+1,updated_at=NOW() WHERE id=$1`,
      [chunk.id, String(notes.summary || "").slice(0, 30000), JSON.stringify(notes)]
    );
    await refreshBookStats(chunk.book_key);
    console.log(`📚 UNDERSTOOD ${chunk.book_key}: ${chunk.locator}`);
    return true;
  } catch (error) {
    const message = String(error?.message || error).slice(0, 2000);
    const { attempts, status } = nextChunkAiState(chunk.ai_attempts);
    const exhausted = status === "FAILED";
    await pool.query(
      `UPDATE trading_school_chunks SET ai_status=$3,ai_error=$2,ai_attempts=$4,updated_at=NOW() WHERE id=$1`,
      [chunk.id, message, status, attempts]
    );
    if (exhausted) {
      console.warn(
        `📚 CHUNK RETIRED ${chunk.book_key}: ${chunk.locator} | attempts=${attempts}`
      );
    }
    console.warn(`📚 AI READER paused/retry: ${message.slice(0, 500)}`);
    return false;
  }
}

async function synthesizeCompleteBooks() {
  const books = await pool.query(
    `SELECT b.book_key,b.title,b.ingested_pages,b.discovered_pages,
            COUNT(c.id)::int AS chunks,
            COUNT(c.id) FILTER(WHERE c.ai_status='DONE')::int AS done,
            COUNT(c.id) FILTER(WHERE c.ai_status IN('DONE','FAILED'))::int AS resolved
     FROM trading_school_books b LEFT JOIN trading_school_chunks c ON c.book_key=b.book_key
     WHERE b.status='INGESTED'
     GROUP BY b.book_key,b.title,b.ingested_pages,b.discovered_pages`
  );

  for (const book of books.rows) {
    // Synthesize once every chunk has settled: understood or permanently
    // retired. Requiring done === chunks meant a single unreadable chunk kept
    // an otherwise fully-read book from ever being synthesized.
    if (!shouldSynthesizeBook(book)) continue;
    const existing = await pool.query(`SELECT complete,source_chunks FROM trading_school_book_memory WHERE book_key=$1`, [book.book_key]);
    if (existing.rows[0]?.complete && Number(existing.rows[0]?.source_chunks || 0) === Number(book.chunks)) continue;

    const notes = await pool.query(
      `SELECT locator,summary,concepts FROM trading_school_chunks WHERE book_key=$1 AND ai_status='DONE' ORDER BY id`,
      [book.book_key]
    );
    const packed = notes.rows.map((r) => ({ locator: r.locator, summary: r.summary, notes: r.concepts }));
    const prompt = `You have now read an entire legal/free trading or forecasting source from beginning to end. Build the coherent whole-book understanding, not isolated candle rules. Return strict JSON only: synthesis (how the author's full framework fits together), principles (array), exceptions (array), timeframe_map (object with M1,M5,M15,M30,H1,GENERAL), experiment_seeds (array of measurable XAU/USD hypotheses that still require backtesting), contradictions_or_limits (array). Do not issue a live trade call.\n\nBOOK: ${book.title}\nALL CHAPTER/PAGE NOTES IN ORDER:\n${JSON.stringify(packed).slice(0, 180000)}`;
    try {
      const memory = parseAiJson(await callGemini(prompt));
      await pool.query(
        `INSERT INTO trading_school_book_memory(book_key,synthesis,principles,exceptions,timeframe_map,experiment_seeds,source_chunks,complete,updated_at)
         VALUES($1,$2,$3::jsonb,$4::jsonb,$5::jsonb,$6::jsonb,$7,TRUE,NOW())
         ON CONFLICT(book_key) DO UPDATE SET synthesis=EXCLUDED.synthesis,principles=EXCLUDED.principles,exceptions=EXCLUDED.exceptions,timeframe_map=EXCLUDED.timeframe_map,experiment_seeds=EXCLUDED.experiment_seeds,source_chunks=EXCLUDED.source_chunks,complete=TRUE,updated_at=NOW()`,
        [book.book_key, String(memory.synthesis || "").slice(0, 60000), JSON.stringify(memory.principles || []), JSON.stringify(memory.exceptions || []), JSON.stringify(memory.timeframe_map || {}), JSON.stringify(memory.experiment_seeds || []), book.chunks]
      );
      console.log(`📚 BOOK UNDERSTANDING COMPLETE: ${book.book_key} | chunks=${book.chunks}`);
    } catch (error) {
      console.warn(`📚 BOOK SYNTHESIS RETRY ${book.book_key}: ${String(error?.message || error).slice(0, 500)}`);
      return;
    }
  }
}

async function aiTick() {
  if (!ENABLED || !AI_ENABLED || !pool || aiReading) return;
  aiReading = true;
  try {
    await ensureSchema();
    const ok = await summarizeOneChunk();
    if (ok) await synthesizeCompleteBooks();
  } catch (error) {
    console.warn(`📚 AI TICK: ${String(error?.message || error).slice(0, 500)}`);
  } finally {
    aiReading = false;
  }
}

async function start() {
  if (!ENABLED) {
    console.log("📚 TRADING SCHOOL FULL READER: disabled");
    return;
  }
  if (!pool) {
    console.warn("📚 TRADING SCHOOL FULL READER: PostgreSQL unavailable");
    return;
  }
  await ensureSchema();
  await seedManifest();
  console.log("📚 TRADING SCHOOL FULL READER V2: sequential full-source ingestion enabled");
  setTimeout(() => readingTick(), 10_000).unref();
  setInterval(() => readingTick(), READ_INTERVAL_MS).unref();
  if (AI_ENABLED) {
    setTimeout(() => aiTick(), 90_000).unref();
    setInterval(() => aiTick(), AI_INTERVAL_MS).unref();
  } else {
    console.log("📚 TRADING SCHOOL AI: disabled; source ingestion continues without external AI calls");
  }
}

start().catch((error) => console.error("📚 TRADING SCHOOL START:", error));

module.exports = {
  readingTick,
  aiTick,
  ensureSchema,
  splitText,
  stripHtml,
  nextChunkAiState,
  shouldSynthesizeBook,
  shouldRetryBookIngest,
  MAX_BOOK_INGEST_ATTEMPTS,
  linkDiscoveryMode,
};
