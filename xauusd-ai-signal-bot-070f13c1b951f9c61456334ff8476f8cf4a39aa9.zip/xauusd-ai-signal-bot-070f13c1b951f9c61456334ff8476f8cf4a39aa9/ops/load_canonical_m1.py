#!/usr/bin/env python3
"""Load the verified XAU/USD M1 canonical bundle into PostgreSQL.

The bundle lives on Google Drive as XAUUSD_M1_CANONICAL_2009_2026_08.zip:
25 inner HistData archives, 6,100,989 raw rows, 6,099,893 canonical rows after
420 identical duplicates are collapsed and 332 conflicting timestamps are
quarantined, covering 2009-03-15 to 2026-08-14.

Nothing here re-implements the parsing. ai_global_trader/canonical_history.py
already opens the outer archive, checks every inner archive's SHA256 against
trading_ai/history_manifest.json, converts HistData's fixed-EST timestamps to
UTC, collapses identical duplicates and drops the quarantined conflicts, then
refuses to continue unless every per-file and global counter matches the
manifest exactly. This script gives that verifier somewhere to put the rows it
has just validated, so the data written can never diverge from the data
checked.

Safety properties, in the order they matter:

* The bundle SHA256 is verified before the archive is opened at all. A file
  that is not bit-for-bit the one the manifest describes is refused, not
  repaired.
* Rows are written with source='histdata'. The live MT5 feed writes
  source='live' and index.js only ever appends candles newer than its own
  maximum, so the two never contend for the same rows.
* Insertion uses ON CONFLICT DO NOTHING against the existing
  UNIQUE(timeframe, candle_time). Re-running after an interruption resumes
  instead of duplicating, and an existing live candle is never overwritten by
  an imported one.
* --dry-run performs the entire verification and counts everything that would
  be written without opening a write transaction.

The bundle can be a local path or a URL. A Drive share link or bare file id is
rewritten to the usercontent download host, because Drive answers a 68 MB file
on its ordinary endpoint with a virus-scan page rather than the archive. A
downloaded copy is cached and reused only when its SHA256 still matches.

Usage:
    python3 ops/load_canonical_m1.py --bundle /path/XAUUSD_M1_CANONICAL_2009_2026_08.zip --dry-run
    python3 ops/load_canonical_m1.py --url 'https://drive.google.com/file/d/<id>/view' --dry-run
    python3 ops/load_canonical_m1.py --url '<id>'          # then without --dry-run to commit
"""

from __future__ import annotations

import argparse
import hashlib
import os
import re
import struct
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from ai_global_trader.canonical_history import scan_canonical_history  # noqa: E402

EXPECTED_BUNDLE_SHA256 = (
    "b73c989c182d240d1a68302a052805984e3ae5f00d81507e49a2a09f0ceb84f5"
)
EXPECTED_BUNDLE_BYTES = 68_910_640
SOURCE_TAG = "histdata"
TIMEFRAME = "M1"
BATCH_ROWS = 20_000

INSERT_SQL = """
INSERT INTO xauusd_candles
    (timeframe, candle_time, open, high, low, close, volume, source)
VALUES %s
ON CONFLICT (timeframe, candle_time) DO NOTHING
"""


_DRIVE_ID = re.compile(
    r"/file/d/(?P<a>[A-Za-z0-9_-]{16,})|[?&]id=(?P<b>[A-Za-z0-9_-]{16,})"
)
_BARE_ID = re.compile(r"^[A-Za-z0-9_-]{16,}$")
DOWNLOAD_CHUNK = 1024 * 1024


def resolve_source_url(value: str) -> str:
    """Turn a Drive share link or bare file id into a direct download URL.

    Drive's /file/d/<id>/view page is HTML, and its uc?export=download endpoint
    answers a large file with a virus-scan interstitial rather than bytes. The
    usercontent host with confirm=t is the form that streams the file itself.
    Any other URL is passed through untouched.
    """
    text = str(value or "").strip()
    if not text:
        raise SystemExit("--url was empty")

    if _BARE_ID.match(text):
        file_id = text
    elif "drive.google.com" in text or "drive.usercontent.google.com" in text:
        found = _DRIVE_ID.search(text)
        if not found:
            raise SystemExit(f"cannot find a Drive file id in: {text}")
        file_id = found.group("a") or found.group("b")
    else:
        return text

    return (
        "https://drive.usercontent.google.com/download"
        f"?id={file_id}&export=download&confirm=t"
    )


def download_to(url: str, dest: Path, *, expected_bytes: int | None = None) -> Path:
    """Stream a URL to disk. Never holds the body in memory.

    Writes to a .part file and renames only on success, so an interrupted
    download cannot be mistaken for a complete one by the next run.
    """
    dest.parent.mkdir(parents=True, exist_ok=True)
    part = dest.with_suffix(dest.suffix + ".part")
    part.unlink(missing_ok=True)

    request = urllib.request.Request(url, headers={"User-Agent": "virus-ai-loader/1"})
    written = 0
    try:
        opened = urllib.request.urlopen(request, timeout=120)
    except urllib.error.HTTPError as exc:
        raise SystemExit(
            f"the server refused the download with HTTP {exc.code} {exc.reason}.\n"
            "For Google Drive, 403 usually means the file is not shared with "
            "'Anyone with the link'."
        ) from exc
    except urllib.error.URLError as exc:
        raise SystemExit(
            f"could not reach the download host: {exc.reason}.\n"
            "A blocked CONNECT tunnel means this machine has no route to it; "
            "run the loader somewhere with open egress, such as Railway."
        ) from exc

    with opened as response, part.open("wb") as handle:
        content_type = str(response.headers.get("Content-Type", "")).lower()
        if "text/html" in content_type:
            part.unlink(missing_ok=True)
            raise SystemExit(
                "the URL returned an HTML page, not a file.\n"
                "For Google Drive this usually means the file is not shared with "
                "'Anyone with the link', so the download is answering with a sign-in "
                "or a virus-scan page instead of the archive."
            )
        while True:
            chunk = response.read(DOWNLOAD_CHUNK)
            if not chunk:
                break
            handle.write(chunk)
            written += len(chunk)

    if expected_bytes is not None and written != expected_bytes:
        part.unlink(missing_ok=True)
        raise SystemExit(
            f"downloaded {written} bytes but the manifest records {expected_bytes}. "
            "The transfer was truncated or the link points at a different file."
        )

    part.replace(dest)
    return dest


def obtain_bundle(
    *,
    bundle: str | None,
    url: str | None,
    cache: Path,
    expected_sha: str,
    expected_bytes: int,
) -> Path:
    """Return a local path to the bundle, downloading only when needed."""
    if bundle:
        return Path(bundle).expanduser().resolve()

    if cache.exists() and file_sha256(cache) == expected_sha:
        print(f"Reusing verified local copy: {cache}", flush=True)
        return cache

    direct = resolve_source_url(url or "")
    print(f"Downloading bundle to {cache}", flush=True)
    return download_to(direct, cache, expected_bytes=expected_bytes)


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_bundle(path: Path, *, expected_sha: str) -> dict:
    if not path.exists():
        raise SystemExit(f"bundle not found: {path}")

    size = path.stat().st_size
    actual = file_sha256(path)
    if actual != expected_sha:
        raise SystemExit(
            "bundle SHA256 mismatch -- refusing to load.\n"
            f"  expected: {expected_sha}\n"
            f"  actual:   {actual}\n"
            f"  size:     {size} bytes (manifest records {EXPECTED_BUNDLE_BYTES})\n"
            "The download is incomplete or the file is not the canonical bundle."
        )
    return {"sha256": actual, "size_bytes": size}


class CandleWriter:
    """Buffer canonical rows and write them in batches.

    Unpacking the fingerprint rather than re-reading the CSV is deliberate: the
    fingerprint is the exact byte sequence the duplicate check compared, so the
    values inserted are provably the values that were verified.
    """

    def __init__(self, cursor, *, dry_run: bool, batch_rows: int = BATCH_ROWS):
        self.cursor = cursor
        self.dry_run = dry_run
        self.batch_rows = int(batch_rows)
        self.buffer: list[tuple] = []
        self.seen = 0
        self.written = 0

    def __call__(self, utc_ms: int, fingerprint: bytes) -> None:
        o, h, l, c, v = struct.unpack("!5d", fingerprint)
        candle_time = datetime.fromtimestamp(utc_ms / 1000, tz=timezone.utc)
        self.buffer.append((TIMEFRAME, candle_time, o, h, l, c, v, SOURCE_TAG))
        self.seen += 1
        if len(self.buffer) >= self.batch_rows:
            self.flush()

    def flush(self) -> None:
        if not self.buffer:
            return
        rows = self.buffer
        self.buffer = []
        if self.dry_run:
            self.written += len(rows)
            return
        from psycopg2.extras import execute_values

        execute_values(self.cursor, INSERT_SQL, rows, page_size=1000)
        self.written += len(rows)


def database_url(explicit: str | None) -> str:
    url = (
        explicit
        or os.getenv("DATABASE_PUBLIC_URL")
        or os.getenv("DATABASE_URL")
        or ""
    ).strip()
    if not url:
        raise SystemExit(
            "DATABASE_PUBLIC_URL or DATABASE_URL is required (or pass --database-url)"
        )
    return url


def report_progress(event: str, **fields: object) -> None:
    if event != "canonical_file_verified":
        return
    print(
        f"  [{fields.get('file_index')}/{fields.get('total_files')}] "
        f"{fields.get('file')} verified: "
        f"{fields.get('canonical_rows')} canonical rows",
        flush=True,
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--bundle", help="path to an already-downloaded canonical .zip")
    source.add_argument(
        "--url",
        help="Drive share link, Drive file id, or any direct URL to the .zip",
    )
    parser.add_argument(
        "--cache",
        default="/tmp/xauusd_m1_canonical.zip",
        help="where a downloaded bundle is kept; a verified copy here is reused",
    )
    parser.add_argument("--database-url", default=None)
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="verify and count without opening a write transaction",
    )
    parser.add_argument(
        "--expected-sha256",
        default=EXPECTED_BUNDLE_SHA256,
        help="override only when loading a deliberately different bundle",
    )
    parser.add_argument("--batch-rows", type=int, default=BATCH_ROWS)
    args = parser.parse_args()

    bundle = obtain_bundle(
        bundle=args.bundle,
        url=args.url,
        cache=Path(args.cache).expanduser().resolve(),
        expected_sha=args.expected_sha256,
        expected_bytes=EXPECTED_BUNDLE_BYTES,
    )

    print(f"Verifying bundle SHA256: {bundle}", flush=True)
    bundle_info = verify_bundle(bundle, expected_sha=args.expected_sha256)
    print(f"  ok  {bundle_info['sha256']}  ({bundle_info['size_bytes']} bytes)\n", flush=True)

    connection = None
    cursor = None
    if not args.dry_run:
        try:
            import psycopg2
        except ImportError as exc:  # pragma: no cover - environment dependent
            raise SystemExit("psycopg2 is required to write to PostgreSQL") from exc
        connection = psycopg2.connect(database_url(args.database_url))
        connection.autocommit = False
        cursor = connection.cursor()

    writer = CandleWriter(cursor, dry_run=args.dry_run, batch_rows=args.batch_rows)

    try:
        print("Verifying 25 inner archives and streaming canonical rows:", flush=True)
        summary = scan_canonical_history(bundle, progress=report_progress, sink=writer)
        writer.flush()

        if connection is not None:
            connection.commit()
    except Exception:
        if connection is not None:
            connection.rollback()
            print("\nRolled back: nothing was written.", file=sys.stderr, flush=True)
        raise
    finally:
        if cursor is not None:
            cursor.close()
        if connection is not None:
            connection.close()

    mode = "DRY RUN -- nothing written" if args.dry_run else "committed"
    print(
        "\n".join(
            [
                "",
                f"Canonical load complete ({mode}).",
                f"  inner archives verified : {summary['files']}",
                f"  raw rows read           : {summary['raw_rows']}",
                f"  canonical rows          : {summary['canonical_rows']}",
                f"  identical duplicates    : {summary['identical_duplicates_removed']}",
                f"  quarantined timestamps  : {summary['quarantined_timestamps']}",
                f"  first candle (UTC)      : {summary['first_utc']}",
                f"  last candle (UTC)       : {summary['last_utc']}",
                f"  rows handed to database : {writer.written}",
                f"  source tag              : {SOURCE_TAG}",
            ]
        ),
        flush=True,
    )

    if writer.seen != summary["canonical_rows"]:
        raise SystemExit(
            f"internal check failed: verifier counted {summary['canonical_rows']} "
            f"canonical rows but {writer.seen} reached the writer"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
