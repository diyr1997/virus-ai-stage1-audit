"use strict";

/**
 * Backfill XAU/USD M1 history into xauusd_candles from Dukascopy.
 *
 * Why this exists: index.js saveM1CandlesToDb() only ever inserts candles
 * strictly newer than the newest row already stored (`candle.time > maxTime`),
 * so the live path can grow the table forward but can never fill in history.
 * The Current Data Lab trains on whatever is in that table, which is why it
 * kept reporting rows=13849 / 11 trading days and never cleared its promotion
 * gate.
 *
 * Deliberately a standalone command. It is never required, imported or started
 * by the bot, so it cannot run by accident. Nothing here touches signals,
 * trading, risk or the RESEARCH_ONLY circuit; it only INSERTs price rows.
 *
 * Re-running is safe: every write is ON CONFLICT DO NOTHING against
 * UNIQUE(timeframe, candle_time), so live rows are never overwritten and an
 * interrupted run simply resumes.
 *
 *   node ops/backfill-xauusd-m1.js --from 2025-09-01 --to 2026-09-01
 *   node ops/backfill-xauusd-m1.js --from 2025-09-01 --dry-run
 *
 * Flags:
 *   --from <YYYY-MM-DD>   first UTC day to fetch (required)
 *   --to   <YYYY-MM-DD>   exclusive end day (default: today)
 *   --dry-run             fetch and report, write nothing
 *   --max-rows <n>        override the row ceiling (see the guard below)
 */

const { Pool } = require("pg");
const { getHistoricalRates } = require("dukascopy-node");

const DATABASE_URL = String(
  process.env.DATABASE_URL || process.env.DATABASE_PUBLIC_URL || ""
).trim();

// training-current-data-lab-v2.js loads the WHOLE table into memory and fails
// closed above this number (CURRENT_DATA_MEMORY_GUARD). Filling the table past
// it would not give the trainer more history, it would stop the trainer running
// at all. So this is a hard ceiling here too, not a suggestion.
const TRAINER_MAX_ROWS = Math.max(
  50_000,
  Number(process.env.CURRENT_DATA_LAB_MAX_ROWS_IN_MEMORY || 500_000)
);
// Leave headroom so the live feed can keep appending after a backfill without
// immediately tripping the trainer's guard.
const HEADROOM_ROWS = Math.max(0, Number(process.env.BACKFILL_HEADROOM_ROWS || 20_000));

const DAY_MS = 24 * 60 * 60 * 1000;
const INSERT_BATCH = 1000;

function parseArgs(argv) {
  const args = { dryRun: false };
  for (let i = 0; i < argv.length; i += 1) {
    const flag = argv[i];
    if (flag === "--dry-run") args.dryRun = true;
    else if (flag === "--from") args.from = argv[++i];
    else if (flag === "--to") args.to = argv[++i];
    else if (flag === "--max-rows") args.maxRows = Number(argv[++i]);
    else throw new Error(`Unknown argument: ${flag}`);
  }
  return args;
}

function parseDay(value, label) {
  const date = new Date(`${String(value).slice(0, 10)}T00:00:00Z`);
  if (!Number.isFinite(date.getTime())) throw new Error(`Invalid ${label}: ${value}`);
  return date;
}

function rowCeiling(maxRows) {
  const ceiling = Number.isFinite(maxRows) && maxRows > 0 ? maxRows : TRAINER_MAX_ROWS;
  return Math.max(1, ceiling - HEADROOM_ROWS);
}

// How many rows this run may still add before the trainer's guard would trip.
function remainingBudget(currentRows, maxRows) {
  return Math.max(0, rowCeiling(maxRows) - Math.max(0, Number(currentRows) || 0));
}

// Number(null) is 0 and Number("") is 0, both of which pass Number.isFinite.
// Letting them through would write a gold price of zero into the training
// table, so a missing field is rejected here rather than coerced.
function price(value) {
  if (value === null || value === undefined || value === "") return NaN;
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : NaN;
}

function normalizeRates(rates) {
  return (Array.isArray(rates) ? rates : [])
    // Optional chaining on purpose: a hole in the provider's response must be
    // dropped, not crash a run that is part way through a long backfill.
    .map((r) => ({
      timestamp: Number(r?.timestamp),
      open: price(r?.open),
      high: price(r?.high),
      low: price(r?.low),
      close: price(r?.close),
      volume: Number(r?.volume) || 0,
    }))
    .filter(
      (r) =>
        Number.isFinite(r.timestamp) &&
        Number.isFinite(r.open) &&
        Number.isFinite(r.high) &&
        Number.isFinite(r.low) &&
        Number.isFinite(r.close) &&
        // A bar whose high is below its low is not a bar.
        r.high >= r.low
    )
    .sort((a, b) => a.timestamp - b.timestamp);
}

async function fetchDay(from) {
  const rates = await getHistoricalRates({
    instrument: "xauusd",
    dates: { from, to: new Date(from.getTime() + DAY_MS) },
    timeframe: "m1",
    format: "json",
    priceType: "bid",
    batchSize: 1,
    pauseBetweenBatchesMs: 2500,
    retryCount: 5,
    pauseBetweenRetriesMs: 10_000,
    retryOnEmpty: false,
    failAfterRetryCount: false,
  });
  return normalizeRates(rates);
}

async function insertRows(pool, rows) {
  let inserted = 0;
  for (let start = 0; start < rows.length; start += INSERT_BATCH) {
    const batch = rows.slice(start, start + INSERT_BATCH);
    const values = [];
    const params = [];
    batch.forEach((row, index) => {
      const base = index * 6;
      values.push(
        `('M1', to_timestamp($${base + 1}::double precision / 1000), $${base + 2}, $${base + 3}, $${base + 4}, $${base + 5}, $${base + 6}, 'dukascopy')`
      );
      params.push(row.timestamp, row.open, row.high, row.low, row.close, row.volume);
    });
    const result = await pool.query(
      `INSERT INTO xauusd_candles(timeframe,candle_time,open,high,low,close,volume,source)
       VALUES ${values.join(",")}
       ON CONFLICT(timeframe, candle_time) DO NOTHING`,
      params
    );
    inserted += result.rowCount || 0;
  }
  return inserted;
}

async function currentRowCount(pool) {
  const result = await pool.query(
    `SELECT COUNT(*)::int AS rows FROM xauusd_candles WHERE timeframe='M1'`
  );
  return Number(result.rows[0]?.rows || 0);
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (!args.from) throw new Error("--from <YYYY-MM-DD> is required");
  if (!DATABASE_URL) throw new Error("DATABASE_URL or DATABASE_PUBLIC_URL is required");

  const from = parseDay(args.from, "--from");
  const to = args.to ? parseDay(args.to, "--to") : new Date();
  if (to.getTime() <= from.getTime()) throw new Error("--to must be after --from");

  const pool = new Pool({ connectionString: DATABASE_URL, max: 2 });
  try {
    const before = await currentRowCount(pool);
    let budget = remainingBudget(before, args.maxRows);

    console.log(
      `BACKFILL | table=${before} rows | ceiling=${rowCeiling(args.maxRows)} | budget=${budget} rows` +
        (args.dryRun ? " | DRY RUN" : "")
    );
    if (!budget) {
      console.warn(
        "BACKFILL: no budget left. The table is already at the trainer's in-memory ceiling; " +
          "raise CURRENT_DATA_LAB_MAX_ROWS_IN_MEMORY only once a chunked trainer exists."
      );
      return;
    }

    let fetched = 0;
    let inserted = 0;
    let days = 0;
    let emptyDays = 0;

    // Newest day first: the rows closest to now are the ones the trainer's
    // promotion gate counts, so a partial run still moves it forward.
    for (let day = new Date(to.getTime() - DAY_MS); day >= from; day = new Date(day.getTime() - DAY_MS)) {
      if (budget <= 0) {
        console.log("BACKFILL: row budget spent, stopping before the trainer's guard.");
        break;
      }
      let rows;
      try {
        rows = await fetchDay(day);
      } catch (error) {
        console.warn(`BACKFILL ${day.toISOString().slice(0, 10)}: fetch failed: ${String(error?.message || error).slice(0, 300)}`);
        continue;
      }
      days += 1;
      if (!rows.length) {
        emptyDays += 1;
        continue;
      }
      const take = rows.slice(0, budget);
      fetched += take.length;
      if (!args.dryRun) {
        const written = await insertRows(pool, take);
        inserted += written;
        budget -= written;
      } else {
        budget -= take.length;
      }
      console.log(
        `BACKFILL ${day.toISOString().slice(0, 10)} | fetched=${take.length} | inserted=${args.dryRun ? "(dry run)" : inserted} | budget=${Math.max(0, budget)}`
      );
    }

    const after = args.dryRun ? before : await currentRowCount(pool);
    console.log(
      `BACKFILL DONE | days=${days} (empty=${emptyDays}) | fetched=${fetched} | inserted=${args.dryRun ? 0 : inserted} | table ${before} -> ${after}`
    );
  } finally {
    await pool.end();
  }
}

if (require.main === module) {
  main().catch((error) => {
    console.error(`BACKFILL FAILED: ${error?.stack || error?.message || error}`);
    process.exitCode = 1;
  });
}

module.exports = { parseArgs, parseDay, normalizeRates, rowCeiling, remainingBudget };
