from __future__ import annotations

import os
import subprocess
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

TOKEN = os.environ.get("BACKUP_EXPORT_TOKEN", "")
DATABASE_URL = os.environ.get("DATABASE_URL", "")
LOCK = threading.Lock()

if len(TOKEN) < 32:
    raise RuntimeError("BACKUP_EXPORT_TOKEN must be at least 32 characters")
if not DATABASE_URL:
    raise RuntimeError("DATABASE_URL is required")


class Handler(BaseHTTPRequestHandler):
    server_version = "VirusAIBackupExport/1"

    def log_message(self, fmt: str, *args: object) -> None:
        return

    def do_GET(self) -> None:
        if self.path == "/health":
            body = b"ok\n"
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        if self.path != f"/export/{TOKEN}":
            self.send_response(404)
            self.end_headers()
            return

        if not LOCK.acquire(blocking=False):
            self.send_response(409)
            self.end_headers()
            return

        proc = None
        try:
            proc = subprocess.Popen([
                "pg_dump", "--format=custom", "--no-owner", "--no-privileges", DATABASE_URL
            ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Disposition", 'attachment; filename="radiant_energy_postgres_20260912.dump"')
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            assert proc.stdout is not None
            while True:
                chunk = proc.stdout.read(1024 * 1024)
                if not chunk:
                    break
                self.wfile.write(chunk)
                self.wfile.flush()
            rc = proc.wait(timeout=60)
            if rc != 0:
                err = (proc.stderr.read() if proc.stderr else b"")[:4000]
                print(f"PG_DUMP_FAILED rc={rc} stderr={err.decode('utf-8', 'replace')}", flush=True)
            else:
                print("PG_DUMP_STREAM_COMPLETE", flush=True)
        except BrokenPipeError:
            if proc and proc.poll() is None:
                proc.terminate()
            print("PG_DUMP_CLIENT_DISCONNECTED", flush=True)
        finally:
            LOCK.release()


def main() -> None:
    port = int(os.environ.get("PORT", "8080"))
    print("BACKUP_EXPORT_SERVER_READY", flush=True)
    ThreadingHTTPServer(("0.0.0.0", port), Handler).serve_forever()


if __name__ == "__main__":
    main()
