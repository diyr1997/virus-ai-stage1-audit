# AI Council Task — Full Legal-Free Book Refresh

Run ID: `BOOK_REFRESH_OPEN_FREE_2026_08_20_R1`

## Goal
Rebuild the Trading School literature map from scratch with the whole AI Council. Do not trust the existing manifest merely because an item is already present. Re-check every source independently.

## Same task for every advisor
1. Independently identify high-quality books, open textbooks, official manuals, university notes/courses and research collections relevant to this XAU/USD project.
2. Prefer sources that are legally free to read/download from the author, publisher, university, exchange, regulator, standards body, research institution or an explicit open license.
3. Reject pirate mirrors, suspicious PDF hosts and unclear copyright copies.
4. Cover these domains:
   - gold / precious-metals market structure and futures;
   - market microstructure, order flow, spread, liquidity, slippage and execution;
   - technical analysis with falsification and measurable rules;
   - intraday momentum, pullbacks, failed breakouts, reversals and regime detection;
   - systematic/algo trading and backtesting;
   - probability, statistics, time series and forecasting;
   - financial ML/AI, feature engineering, leakage/overfit control and validation;
   - risk management, sizing, drawdown and trade management;
   - MT5/MQL5 execution engineering where relevant.
5. Re-check the current Trading School library and classify every existing item as KEEP / DOWNGRADE / REPLACE / WAITING_USER_COPY / REJECT.
6. For every newly proposed source return:
   - exact title and author/institution;
   - publication/update year if known;
   - canonical/legal access route;
   - access type: FREE_OFFICIAL / FREE_OPEN_LICENSE / FREE_ONLINE / LIBRARY_OR_PAID / UNVERIFIED;
   - why it matters specifically for XAU/USD M1/M5/M15/M30/H1;
   - what must NOT be copied blindly;
   - 1–5 measurable hypotheses or engineering tests;
   - priority CRITICAL/HIGH/MEDIUM/LOW.
7. Verify availability and legality where browsing is available. If browsing is unavailable, clearly mark source availability as UNVERIFIED instead of inventing a URL.
8. Include the user-supplied Brian Shannon book in the review, but preserve the known fact that the current supplied copy is partial and must not be treated as a complete-book understanding.
9. Compare books with each other: overlaps, contradictions, incompatible assumptions, and gaps.
10. Propose a final unified curriculum ordered by dependency, not popularity.

## Peer-review phase
After independent discovery, inspect all other advisors' lists. Challenge weak sources, duplicated books, outdated material, fake/free claims, unsuitable institutional assumptions, and ideas that cannot be tested with our data. Add missing sources the others overlooked.

## Final council output
The coordinator must produce:
- `CORE_FREE_LIBRARY` — strongest legal/free sources to ingest fully;
- `SECONDARY_FREE_LIBRARY` — useful but not first priority;
- `PAID_OR_USER_COPY_ONLY` — useful but cannot be ingested without lawful access;
- `REJECT_OR_LOW_VALUE`;
- `CONTRADICTIONS_AND_GAPS`;
- `XAUUSD_TEST_HYPOTHESES`;
- `READING_ORDER`;
- `WHAT_CHANGES_IN_OUR_CURRENT_PLAN`;
- `WHAT_MUST_WAIT_FOR_BACKTEST_OR_DEMO`.

## Safety
This is research only. No book or AI opinion may directly alter BUY/SELL logic, active risk settings or MT5 execution. Any proposed trading rule must go through measurable historical/OOS/chronological tests and DEMO/shadow validation before promotion.
