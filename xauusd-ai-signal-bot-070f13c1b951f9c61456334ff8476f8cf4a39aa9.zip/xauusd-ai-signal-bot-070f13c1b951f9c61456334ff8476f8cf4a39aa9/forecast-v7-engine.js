"use strict";

const { buildTradePlanV6 } = require("./forecast-v6-engine");

const TF = Object.freeze({
  M1: { barMinutes: 1, bars: 15 },
  M5: { barMinutes: 5, bars: 12 },
  M15: { barMinutes: 15, bars: 8 },
  M30: { barMinutes: 30, bars: 8 },
  H1: { barMinutes: 60, bars: 8 },
});

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, Number(value)));
}

function finite(value) {
  return Number.isFinite(Number(value));
}

function quantile(values, q) {
  const sorted = (values || []).filter(finite).map(Number).sort((a, b) => a - b);
  if (!sorted.length) return NaN;
  if (sorted.length === 1) return sorted[0];
  const pos = clamp(q, 0, 1) * (sorted.length - 1);
  const lo = Math.floor(pos);
  const hi = Math.ceil(pos);
  const frac = pos - lo;
  return sorted[lo] * (1 - frac) + sorted[hi] * frac;
}

function median(values) {
  return quantile(values, 0.5);
}

function robustVol(returns) {
  const xs = (returns || []).filter(finite).map(Number);
  if (!xs.length) return 0;
  const med = median(xs);
  const mad = median(xs.map((x) => Math.abs(x - med)));
  const madSigma = finite(mad) ? mad * 1.4826 : 0;
  if (madSigma > 1e-9) return madSigma;
  const rms = Math.sqrt(xs.reduce((sum, x) => sum + x * x, 0) / xs.length);
  return finite(rms) ? rms : 0;
}

function ewma(values, lambda = 0.78) {
  const xs = (values || []).filter(finite).map(Number);
  if (!xs.length) return 0;
  let weighted = 0;
  let weights = 0;
  for (let i = 0; i < xs.length; i++) {
    const age = xs.length - 1 - i;
    const w = Math.pow(lambda, age);
    weighted += xs[i] * w;
    weights += w;
  }
  return weights > 0 ? weighted / weights : 0;
}

function normalizeCandles(candles) {
  return (Array.isArray(candles) ? candles : [])
    .filter((c) => finite(c?.close) && Number(c.close) > 0)
    .map((c) => ({ ...c, close: Number(c.close) }));
}

function logReturns(closes) {
  const out = [];
  for (let i = 1; i < closes.length; i++) {
    const a = Number(closes[i - 1]);
    const b = Number(closes[i]);
    if (a > 0 && b > 0) out.push(Math.log(b / a));
  }
  return out;
}

function forecastAt(forecast, minute) {
  if (!forecast?.length) return null;
  return forecast.reduce(
    (best, point) =>
      Math.abs(Number(point.minute) - minute) < Math.abs(Number(best.minute) - minute)
        ? point
        : best,
    forecast[0]
  );
}

function tfMilestones(timeframe, horizon) {
  const map = {
    M1: [5, 10, 15],
    M5: [15, 30, 60],
    M15: [30, 60, 120],
    M30: [60, 120, 240],
    H1: [120, 240, 480],
  };
  return (map[timeframe] || [horizon / 3, (2 * horizon) / 3, horizon]).map((minute) => ({
    minute: Math.min(minute, horizon),
    label: `${Math.min(minute, horizon)}м`,
  }));
}

function buildAnalogPaths({ returns, currentVol, bars, anchor }) {
  if (returns.length < bars + 12 || currentVol <= 1e-9) return [];
  const R = returns.length;
  const currentState = returns.slice(-3).map((r) => r / currentVol);
  const weights = [0.2, 0.3, 0.5];
  const candidates = [];

  for (let end = 2; end + bars < R - 2; end++) {
    const localSlice = returns.slice(Math.max(0, end - 39), end + 1);
    const localVol = robustVol(localSlice);
    if (localVol <= 1e-9) continue;
    const state = [returns[end - 2], returns[end - 1], returns[end]].map((r) => r / localVol);
    const distance = state.reduce((sum, value, i) => {
      const d = value - currentState[i];
      return sum + weights[i] * d * d;
    }, 0);
    if (!finite(distance)) continue;

    const scale = clamp(currentVol / localVol, 0.5, 2.0);
    const path = [];
    let cumulative = 0;
    for (let step = 1; step <= bars; step++) {
      const r = returns[end + step];
      if (!finite(r)) break;
      cumulative += Number(r) * scale;
      path.push(anchor * Math.exp(cumulative));
    }
    if (path.length === bars && path.every(finite)) {
      candidates.push({ distance, path, terminal: path[path.length - 1] - anchor });
    }
  }

  return candidates.sort((a, b) => a.distance - b.distance).slice(0, 24);
}

function buildAnalogEnvelope({ analogs, anchor, barMinutes, bars }) {
  const forecast = [{ minute: 0, center: anchor, low: anchor, high: anchor }];
  for (let step = 0; step < bars; step++) {
    const values = analogs.map((a) => a.path[step]);
    const q20 = quantile(values, 0.2);
    const q50 = quantile(values, 0.5);
    const q80 = quantile(values, 0.8);
    const low = Math.min(q20, q50, q80);
    const high = Math.max(q20, q50, q80);
    forecast.push({ minute: (step + 1) * barMinutes, center: q50, low, high });
  }

  const terminal = forecast[forecast.length - 1];
  const primarySign = Math.sign(terminal.center - anchor);
  const opposite = analogs.filter((a) => primarySign !== 0 && Math.sign(a.terminal) === -primarySign);
  let alternativeForecast = [];
  let alternativeEvidence = "NONE";

  if (opposite.length >= 3) {
    alternativeEvidence = "ANALOG";
    alternativeForecast = [{ minute: 0, center: anchor }];
    for (let step = 0; step < bars; step++) {
      alternativeForecast.push({
        minute: (step + 1) * barMinutes,
        center: median(opposite.map((a) => a.path[step])),
      });
    }
  } else {
    alternativeEvidence = "ADVERSE_QUANTILE";
    alternativeForecast = forecast.map((p) => ({
      minute: p.minute,
      center: primarySign >= 0 ? p.low : p.high,
    }));
  }

  return { forecast, alternativeForecast, alternativeEvidence };
}

function buildEwmaEnvelope({ returns, anchor, atr, barMinutes, bars }) {
  const recent = returns.slice(-12);
  const driftRaw = ewma(recent, 0.78);
  const totalPriceCap = Math.max(Number(atr || 0), anchor * 0.00015) * 0.45;
  const totalLogCap = Math.log((anchor + totalPriceCap) / anchor);
  const drift = clamp(driftRaw, -totalLogCap / bars, totalLogCap / bars);
  const residuals = recent.map((r) => r - drift);
  const q20 = finite(quantile(residuals, 0.2)) ? quantile(residuals, 0.2) : -Math.abs(robustVol(recent));
  const q80 = finite(quantile(residuals, 0.8)) ? quantile(residuals, 0.8) : Math.abs(robustVol(recent));
  const forecast = [{ minute: 0, center: anchor, low: anchor, high: anchor }];

  for (let step = 1; step <= bars; step++) {
    const base = drift * step;
    const spreadScale = Math.sqrt(step);
    const center = anchor * Math.exp(base);
    const a = anchor * Math.exp(base + q20 * spreadScale);
    const b = anchor * Math.exp(base + q80 * spreadScale);
    forecast.push({
      minute: step * barMinutes,
      center,
      low: Math.min(a, center, b),
      high: Math.max(a, center, b),
    });
  }

  const primarySign = Math.sign(forecast[forecast.length - 1].center - anchor);
  const alternativeForecast = forecast.map((p) => ({
    minute: p.minute,
    center: primarySign >= 0 ? p.low : p.high,
  }));
  return { forecast, alternativeForecast, alternativeEvidence: "ADVERSE_QUANTILE" };
}

function shouldBeUncertain({ analysis, mt5Quote, forecast, anchor, atr }) {
  const action = String(analysis?.action || "WAIT").toUpperCase();
  const strength = Number(analysis?.strength || 0);
  if (action === "WAIT" || strength < 60) return true;
  if (mt5Quote && mt5Quote.fresh === false) return true;
  const terminal = forecast?.[forecast.length - 1];
  if (!terminal) return true;
  const material = Math.max(Number(atr || 0) * 0.08, anchor * 0.00005);
  const bothSides = terminal.low < anchor - material && terminal.high > anchor + material;
  const weakMedian = Math.abs(terminal.center - anchor) < Math.max(Number(atr || 0) * 0.18, material);
  return bothSides && weakMedian;
}

function buildTradePlanV7(args) {
  const base = buildTradePlanV6(args);
  const timeframe = String(args?.timeframe || "M1").toUpperCase();
  const cfg = TF[timeframe] || TF.M1;
  const analysis = args?.analysis || {};
  const anchor = Number(analysis.price);
  const atr = Math.max(Number(analysis.atr || 0), anchor * 0.00015);
  const candles = normalizeCandles(args?.candles);
  const closes = candles.map((c) => c.close);
  const returns = logReturns(closes);
  const currentVol = robustVol(returns.slice(-40));
  const analogs = buildAnalogPaths({ returns, currentVol, bars: cfg.bars, anchor });

  let mode = "EWMA_FALLBACK";
  let envelope;
  if (analogs.length >= 6) {
    mode = "ANALOG";
    envelope = buildAnalogEnvelope({ analogs, anchor, barMinutes: cfg.barMinutes, bars: cfg.bars });
  } else {
    envelope = buildEwmaEnvelope({ returns, anchor, atr, barMinutes: cfg.barMinutes, bars: cfg.bars });
  }

  const uncertain = shouldBeUncertain({
    analysis,
    mt5Quote: args?.mt5Quote,
    forecast: envelope.forecast,
    anchor,
    atr,
  });
  if (uncertain) mode = "UNCERTAIN";

  const horizon = cfg.barMinutes * cfg.bars;
  const terminal = envelope.forecast[envelope.forecast.length - 1];
  const milestones = tfMilestones(timeframe, horizon).map((m) => ({
    ...m,
    point: forecastAt(envelope.forecast, m.minute),
  }));

  return {
    ...base,
    forecast: envelope.forecast,
    alternativeForecast: envelope.alternativeForecast,
    scenarioMarkers: [
      { type: "CURRENT", minute: 0, price: anchor },
      { type: "PRIMARY_END", minute: horizon, price: terminal.center },
      {
        type: "ALT_END",
        minute: horizon,
        price: envelope.alternativeForecast?.[envelope.alternativeForecast.length - 1]?.center ?? null,
      },
      { type: "UNCERTAINTY_EXPANSION", minute: horizon, low: terminal.low, high: terminal.high },
    ],
    horizon,
    p5: forecastAt(envelope.forecast, Math.min(5, horizon)),
    p10: forecastAt(envelope.forecast, Math.min(10, horizon)),
    p15: forecastAt(envelope.forecast, Math.min(15, horizon)),
    v7Milestones: milestones,
    v7State: uncertain ? "UNCERTAIN" : "DIRECTIONAL",
    v7Mode: mode,
    v7PrimaryDirection:
      uncertain || Math.abs(terminal.center - anchor) < 1e-9
        ? "WAIT"
        : terminal.center > anchor
        ? "BUY"
        : "SELL",
    v7AlternativeEvidence: envelope.alternativeEvidence,
    v7Evidence: {
      analogCount: analogs.length,
      volatility: currentVol,
      terminalMedianMove: terminal.center - anchor,
      terminalBandWidth: terminal.high - terminal.low,
    },
    forecastModel: "GRAPH_V7_ANALOG_ENVELOPE_V1",
  };
}

module.exports = {
  TF,
  buildTradePlanV7,
  quantile,
  robustVol,
  buildAnalogPaths,
};
