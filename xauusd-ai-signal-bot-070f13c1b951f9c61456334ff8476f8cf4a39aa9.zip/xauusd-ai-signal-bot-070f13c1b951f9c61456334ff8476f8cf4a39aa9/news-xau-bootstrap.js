"use strict";

// Deterministic preload for XAU NEWS FILTER V15.
// news-xau-hotfix installs the wrapper; this file then stores the wrapped
// ./news exports in Node's require cache before index.js starts.

require("./news-xau-hotfix");

const newsPath = require.resolve("./news");
const wrappedNews = require(newsPath);
require.cache[newsPath].exports = wrappedNews;

console.log("✅ XAU NEWS FILTER V15: BOOTSTRAP ACTIVE");
