"use strict";

const GOLD_CFTC_CODE = "088691";

const CFTC_URLS = {
  legacy: "https://publicreporting.cftc.gov/resource/6dca-aqww.json",
  disaggregated: "https://publicreporting.cftc.gov/resource/72hh-3qpy.json",
};

const CACHE_TTL_MS = 60 * 60 * 1000;

let cache = null;
let cacheTime = 0;

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function toNumber(value, fallback = 0) {
  if (
    value === null ||
    value === undefined ||
    value === ""
  ) {
    return fallback;
  }

  const n = Number(
    String(value)
      .replace(/,/g, "")
      .trim()
  );

  return Number.isFinite(n)
    ? n
    : fallback;
}

function pickNumber(
  row,
  keys,
  fallback = 0
) {
  if (!row) {
    return fallback;
  }

  for (const key of keys) {
    if (
      row[key] !== undefined &&
      row[key] !== null &&
      row[key] !== ""
    ) {
      const n = toNumber(
        row[key],
        NaN
      );

      if (
        Number.isFinite(n)
      ) {
        return n;
      }
    }
  }

  return fallback;
}

function formatInt(value) {
  return new Intl.NumberFormat(
    "ru-RU"
  ).format(
    Math.round(
      toNumber(value, 0)
    )
  );
}

function formatSigned(value) {
  const n = Math.round(
    toNumber(value, 0)
  );

  return n > 0
    ? `+${formatInt(n)}`
    : formatInt(n);
}

function normalizeDate(value) {
  if (!value) {
    return null;
  }

  return String(value).slice(
    0,
    10
  );
}

function formatDateRu(
  isoDate
) {
  if (!isoDate) {
    return "—";
  }

  const [
    year,
    month,
    day,
  ] = String(
    isoDate
  ).split("-");

  if (
    !year ||
    !month ||
    !day
  ) {
    return String(
      isoDate
    );
  }

  return `${day}.${month}.${year}`;
}

function buildCftcUrl(
  baseUrl,
  limit = 12
) {
  const url =
    new URL(
      baseUrl
    );

  url.searchParams.set(
    "$where",
    `cftc_contract_market_code='${GOLD_CFTC_CODE}'`
  );

  url.searchParams.set(
    "$order",
    "report_date_as_yyyy_mm_dd DESC"
  );

  url.searchParams.set(
    "$limit",
    String(limit)
  );

  return url.toString();
}

async function fetchJsonWithRetry(
  url,
  attempts = 3
) {
  let lastError =
    null;

  for (
    let attempt = 1;
    attempt <= attempts;
    attempt += 1
  ) {
    const controller =
      new AbortController();

    const timeout =
      setTimeout(
        () =>
          controller.abort(),
        15000
      );

    try {
      const response =
        await fetch(
          url,
          {
            method:
              "GET",

            headers: {
              Accept:
                "application/json",

              "User-Agent":
                "XAUUSD-AI-Signal-Bot/1.0",
            },

            signal:
              controller.signal,
          }
        );

      if (
        !response.ok
      ) {
        const body =
          await response
            .text()
            .catch(
              () => ""
            );

        throw new Error(
          `CFTC HTTP ${response.status}${
            body
              ? `: ${body.slice(
                  0,
                  180
                )}`
              : ""
          }`
        );
      }

      const data =
        await response.json();

      if (
        !Array.isArray(
          data
        )
      ) {
        throw new Error(
          "CFTC вернул неожиданный формат данных"
        );
      }

      return data;
    } catch (
      error
    ) {
      lastError =
        error;

      if (
        attempt <
        attempts
      ) {
        await sleep(
          800 *
            attempt
        );
      }
    } finally {
      clearTimeout(
        timeout
      );
    }
  }

  throw (
    lastError ||
    new Error(
      "Не удалось получить данные CFTC"
    )
  );
}

function rowsByDate(
  rows
) {
  const map =
    new Map();

  for (
    const row of
      rows || []
  ) {
    const date =
      normalizeDate(
        row
          ?.report_date_as_yyyy_mm_dd
      );

    if (
      date &&
      !map.has(
        date
      )
    ) {
      map.set(
        date,
        row
      );
    }
  }

  return map;
}

function getCommonWeeks(
  legacyRows,
  disaggregatedRows
) {
  const legacyMap =
    rowsByDate(
      legacyRows
    );

  const disaggMap =
    rowsByDate(
      disaggregatedRows
    );

  const dates = [
    ...legacyMap.keys(),
  ]
    .filter(
      (date) =>
        disaggMap.has(
          date
        )
    )
    .sort(
      (a, b) =>
        b.localeCompare(
          a
        )
    );

  if (
    dates.length <
    2
  ) {
    throw new Error(
      "CFTC: недостаточно двух совпадающих недель Legacy и Disaggregated"
    );
  }

  const currentDate =
    dates[0];

  const previousDate =
    dates[1];

  return {
    currentDate,
    previousDate,

    legacyCurrent:
      legacyMap.get(
        currentDate
      ),

    legacyPrevious:
      legacyMap.get(
        previousDate
      ),

    disaggCurrent:
      disaggMap.get(
        currentDate
      ),

    disaggPrevious:
      disaggMap.get(
        previousDate
      ),
  };
}

function classifyBias(
  nonCommNet,
  nonCommDelta,
  managedNet,
  managedDelta
) {
  let score = 0;

  if (
    nonCommNet > 0
  ) {
    score += 1;
  }

  if (
    nonCommNet < 0
  ) {
    score -= 1;
  }

  if (
    managedNet > 0
  ) {
    score += 1;
  }

  if (
    managedNet < 0
  ) {
    score -= 1;
  }

  if (
    nonCommDelta > 0
  ) {
    score += 2;
  }

  if (
    nonCommDelta < 0
  ) {
    score -= 2;
  }

  if (
    managedDelta > 0
  ) {
    score += 3;
  }

  if (
    managedDelta < 0
  ) {
    score -= 3;
  }

  if (
    score >= 4
  ) {
    return {
      direction:
        "UP",

      label:
        "крупные спекулянты усиливают бычий фон по золоту",

      emoji:
        "🟢⬆️",

      score,
    };
  }

  if (
    score <= -4
  ) {
    return {
      direction:
        "DOWN",

      label:
        "крупные спекулянты усиливают медвежий фон по золоту",

      emoji:
        "🔴⬇️",

      score,
    };
  }

  return {
    direction:
      "NEUTRAL",

    label:
      "позиционирование крупных спекулянтов смешанное",

    emoji:
      "⚪↔️",

    score,
  };
}

function makeSnapshot(
  weeks
) {
  const lc =
    weeks.legacyCurrent;

  const lp =
    weeks.legacyPrevious;

  const dc =
    weeks.disaggCurrent;

  const dp =
    weeks.disaggPrevious;

  // ==============================
  // NON-COMMERCIAL
  // ==============================

  const nonCommLong =
    pickNumber(
      lc,
      [
        "noncomm_positions_long_all",
      ]
    );

  const nonCommShort =
    pickNumber(
      lc,
      [
        "noncomm_positions_short_all",
      ]
    );

  const nonCommNet =
    nonCommLong -
    nonCommShort;

  const prevNonCommLong =
    pickNumber(
      lp,
      [
        "noncomm_positions_long_all",
      ]
    );

  const prevNonCommShort =
    pickNumber(
      lp,
      [
        "noncomm_positions_short_all",
      ]
    );

  const prevNonCommNet =
    prevNonCommLong -
    prevNonCommShort;

  const nonCommNetChange =
    nonCommNet -
    prevNonCommNet;

  // ==============================
  // MANAGED MONEY
  // ==============================

  const managedLong =
    pickNumber(
      dc,
      [
        "m_money_positions_long_all",
        "m_money_positions_long",
      ]
    );

  const managedShort =
    pickNumber(
      dc,
      [
        "m_money_positions_short_all",
        "m_money_positions_short",
      ]
    );

  const managedNet =
    managedLong -
    managedShort;

  const prevManagedLong =
    pickNumber(
      dp,
      [
        "m_money_positions_long_all",
        "m_money_positions_long",
      ]
    );

  const prevManagedShort =
    pickNumber(
      dp,
      [
        "m_money_positions_short_all",
        "m_money_positions_short",
      ]
    );

  const prevManagedNet =
    prevManagedLong -
    prevManagedShort;

  const managedNetChange =
    managedNet -
    prevManagedNet;

  // ==============================
  // КОЛИЧЕСТВО ТРЕЙДЕРОВ
  // ==============================

  const tradersManagedLong =
    pickNumber(
      dc,
      [
        "traders_m_money_long_all",
        "traders_m_money_long",
      ]
    );

  const tradersManagedShort =
    pickNumber(
      dc,
      [
        "traders_m_money_short_all",
        "traders_m_money_short",
      ]
    );

  // ==============================
  // OPEN INTEREST
  // ==============================

  const openInterest =
    pickNumber(
      dc,
      [
        "open_interest_all",
      ],
      pickNumber(
        lc,
        [
          "open_interest_all",
        ]
      )
    );

  // ==============================
  // НАПРАВЛЕНИЕ CFTC
  // ==============================

  const bias =
    classifyBias(
      nonCommNet,
      nonCommNetChange,
      managedNet,
      managedNetChange
    );

  return {
    source:
      "CFTC",

    contract:
      "GOLD - COMMODITY EXCHANGE INC.",

    cftcCode:
      GOLD_CFTC_CODE,

    reportDate:
      weeks.currentDate,

    previousReportDate:
      weeks.previousDate,

    openInterest,

    nonCommercial: {
      long:
        nonCommLong,

      short:
        nonCommShort,

      net:
        nonCommNet,

      netChange:
        nonCommNetChange,
    },

    managedMoney: {
      long:
        managedLong,

      short:
        managedShort,

      net:
        managedNet,

      netChange:
        managedNetChange,

      tradersLong:
        tradersManagedLong,

      tradersShort:
        tradersManagedShort,
    },

    bias,

    fetchedAt:
      new Date()
        .toISOString(),
  };
}

function formatCftcGoldMessage(
  snapshot
) {
  if (
    !snapshot
  ) {
    return (
      "📊 CFTC — данные временно недоступны"
    );
  }

  const nc =
    snapshot
      .nonCommercial ||
    {};

  const mm =
    snapshot
      .managedMoney ||
    {};

  const bias =
    snapshot.bias ||
    {
      direction:
        "NEUTRAL",

      label:
        "смешанный фон",

      emoji:
        "⚪↔️",
    };

  const traderLines =
    [];

  if (
    Number(
      mm.tradersLong
    ) > 0 ||
    Number(
      mm.tradersShort
    ) > 0
  ) {
    traderLines.push(
      `Трейдеров LONG: ${formatInt(
        mm.tradersLong
      )}`
    );

    traderLines.push(
      `Трейдеров SHORT: ${formatInt(
        mm.tradersShort
      )}`
    );

    traderLines.push(
      ""
    );
  }

  return [
    "📊 CFTC — GOLD / COMEX",

    "",

    `📅 Данные на: ${formatDateRu(
      snapshot.reportDate
    )}`,

    "Источник: официальный CFTC",

    "",

    "👥 NON-COMMERCIAL",

    `LONG: ${formatInt(
      nc.long
    )}`,

    `SHORT: ${formatInt(
      nc.short
    )}`,

    `NET: ${formatSigned(
      nc.net
    )}`,

    `Изменение NET за неделю: ${formatSigned(
      nc.netChange
    )}`,

    "",

    "💼 MANAGED MONEY",

    `LONG: ${formatInt(
      mm.long
    )}`,

    `SHORT: ${formatInt(
      mm.short
    )}`,

    `NET: ${formatSigned(
      mm.net
    )}`,

    `Изменение NET за неделю: ${formatSigned(
      mm.netChange
    )}`,

    "",

    ...traderLines,

    `📈 Open Interest: ${formatInt(
      snapshot.openInterest
    )}`,

    "",

    `${
      bias.emoji ||
      "⚪↔️"
    } CFTC-фон:`,

    bias.label ||
      "смешанный фон",

    "",

    "⏳ Это недельный среднесрочный фон, а не сигнал для входа на M1.",
  ].join(
    "\n"
  );
}

async function getCftcGoldSnapshot(
  options = {}
) {
  const forceRefresh =
    Boolean(
      options.forceRefresh ??
      options.force
    );

  const now =
    Date.now();

  if (
    !forceRefresh &&
    cache &&
    now -
      cacheTime <
      CACHE_TTL_MS
  ) {
    return cache;
  }

  const [
    legacyRows,
    disaggregatedRows,
  ] =
    await Promise.all([
      fetchJsonWithRetry(
        buildCftcUrl(
          CFTC_URLS.legacy
        )
      ),

      fetchJsonWithRetry(
        buildCftcUrl(
          CFTC_URLS.disaggregated
        )
      ),
    ]);

  const weeks =
    getCommonWeeks(
      legacyRows,
      disaggregatedRows
    );

  const snapshot =
    makeSnapshot(
      weeks
    );

  cache =
    snapshot;

  cacheTime =
    now;

  return snapshot;
}

module.exports = {
  getCftcGoldSnapshot,
  formatCftcGoldMessage,
};


// =====================================
// РУЧНАЯ ПРОВЕРКА
// =====================================
//
// Если запустить:
//
// node cftc.js
//
// он покажет последние данные CFTC.
//

if (
  require.main ===
  module
) {
  getCftcGoldSnapshot({
    force:
      true,
  })
    .then(
      (
        snapshot
      ) => {
        console.log(
          formatCftcGoldMessage(
            snapshot
          )
        );
      }
    )
    .catch(
      (
        error
      ) => {
        console.error(
          "❌ Ошибка CFTC:",
          error.message
        );

        process.exitCode =
          1;
      }
    );
}
