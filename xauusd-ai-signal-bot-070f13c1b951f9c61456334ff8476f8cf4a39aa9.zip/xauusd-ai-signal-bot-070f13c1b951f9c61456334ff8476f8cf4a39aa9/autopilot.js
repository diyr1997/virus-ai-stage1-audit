"use strict";

/*
  XAU/USD MARKET DATA BRIDGE — CLEAN V4
  -------------------------------------
  Этот файл теперь отвечает прежде всего за M1-данные для index.js.

  Приоритет:
  1) свежие закрытые M1 из MT5/Gold# -> PostgreSQL (source=MT5_GOLD)
  2) свежие закрытые M1 из общей таблицы PostgreSQL
  3) Dukascopy как резерв
  4) если всё устарело — ОШИБКА, а не старый торговый сигнал

  Важно:
  - незакрытая M1 не используется;
  - старый кэш не выдаётся как "LIVE";
  - setupAutopilot оставлен как совместимый no-op, потому что CLEAN V4
    уже содержит новый AUTOPILOT внутри index.js.
*/

const { getHistoricalRates } = require("dukascopy-node");
const { Pool } = require("pg");

// ======================================================
// CONFIG
// ======================================================

const DATABASE_URL = String(
  process.env.DATABASE_URL ||
  process.env.DATABASE_PUBLIC_URL ||
  ""
).trim();

const DB_ENABLED = Boolean(DATABASE_URL);

const DB_LIMIT = Math.max(
  500,
  Math.min(
    15000,
    Number(process.env.M1_DB_LIMIT || 7000)
  )
);

const LIVE_CACHE_MS = Math.max(
  5_000,
  Number(process.env.LIVE_CACHE_MS || 20_000)
);

const MARKET_DATA_MAX_AGE_MS = Math.max(
  2 * 60_000,
  Number(process.env.MARKET_DATA_MAX_AGE_MS || 5 * 60_000)
);

const CLOSED_GRACE_MS = Math.max(
  1_000,
  Number(process.env.CLOSED_CANDLE_GRACE_MS || 2_500)
);

const DUKAS_HISTORY_HOURS = Math.max(
  24,
  Number(process.env.LIVE_HISTORY_HOURS || 240)
);

const DUKAS_INCREMENTAL_LOOKBACK_MINUTES = Math.max(
  10,
  Number(process.env.LIVE_INCREMENTAL_LOOKBACK_MINUTES || 30)
);

const DUKAS_RETRIES = Math.max(
  1,
  Math.min(
    3,
    Number(process.env.LIVE_RETRIES || 2)
  )
);

const db = DB_ENABLED
  ? new Pool({
      connectionString: DATABASE_URL,
      max: 3,
      idleTimeoutMillis: 30_000,
      connectionTimeoutMillis: 10_000,
    })
  : null;

let liveCache = {
  data: null,
  updatedAt: 0,
  source: null,
};

let liveLoadPromise = null;

// ======================================================
// HELPERS
// ======================================================

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function num(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function normalizeTime(value) {
  if (typeof value === "number") {
    return value < 10_000_000_000 ? value * 1000 : value;
  }

  const t = new Date(value).getTime();
  return Number.isFinite(t) ? t : NaN;
}

function normalizeRate(rate) {
  if (Array.isArray(rate)) {
    return {
      time: normalizeTime(rate[0]),
      open: num(rate[1]),
      high: num(rate[2]),
      low: num(rate[3]),
      close: num(rate[4]),
      volume: num(rate[5]) || 0,
    };
  }

  return {
    time: normalizeTime(
      rate?.timestamp ??
      rate?.time ??
      rate?.date ??
      rate?.datetime ??
      rate?.candle_time
    ),
    open: num(rate?.open),
    high: num(rate?.high),
    low: num(rate?.low),
    close: num(rate?.close),
    volume: num(rate?.volume) || 0,
  };
}

function validCandle(candle) {
  return (
    Number.isFinite(candle?.time) &&
    Number.isFinite(candle?.open) &&
    Number.isFinite(candle?.high) &&
    Number.isFinite(candle?.low) &&
    Number.isFinite(candle?.close) &&
    candle.open > 0 &&
    candle.high > 0 &&
    candle.low > 0 &&
    candle.close > 0 &&
    candle.high >= candle.low
  );
}

function isClosedM1(candle, now = Date.now()) {
  return (
    candle.time + 60_000 <=
    now - CLOSED_GRACE_MS
  );
}

function sanitizeCandles(items) {
  const map = new Map();
  const now = Date.now();

  for (const raw of items || []) {
    const candle = normalizeRate(raw);

    if (
      validCandle(candle) &&
      isClosedM1(candle, now)
    ) {
      map.set(candle.time, candle);
    }
  }

  return [...map.values()]
    .sort((a, b) => a.time - b.time)
    .slice(-15000);
}

function latestAgeMs(candles) {
  if (!Array.isArray(candles) || !candles.length) {
    return Infinity;
  }

  const latest = candles[candles.length - 1];

  // candle.time = начало M1. Данные считаем доступными после её закрытия.
  return Math.max(
    0,
    Date.now() - (latest.time + 60_000)
  );
}

function assertFresh(candles, source) {
  if (!Array.isArray(candles) || candles.length < 40) {
    throw new Error(
      `${source}: недостаточно закрытых M1-свечей (${candles?.length || 0})`
    );
  }

  const age = latestAgeMs(candles);

  if (age > MARKET_DATA_MAX_AGE_MS) {
    const latest = candles[candles.length - 1];

    throw new Error(
      `${source}: M1 устарели. Последняя закрытая свеча ${new Date(
        latest.time
      ).toISOString()}, возраст ${Math.round(age / 60_000)} мин`
    );
  }

  return candles;
}

function logFresh(source, candles) {
  const latest = candles[candles.length - 1];
  const age = latestAgeMs(candles);

  console.log(
    `✅ M1 ${source}: ${candles.length} | ` +
    `последняя закрытая ${new Date(latest.time).toISOString()} | ` +
    `возраст ${Math.round(age / 1000)}с`
  );
}

// ======================================================
// POSTGRES: MT5 FIRST
// ======================================================

async function loadDbRows(whereSql, params = []) {
  if (!db) return [];

  const result = await db.query(
    `
      SELECT
        candle_time,
        open,
        high,
        low,
        close,
        volume,
        source
      FROM xauusd_candles
      WHERE timeframe = 'M1'
        ${whereSql}
      ORDER BY candle_time DESC
      LIMIT $${params.length + 1}
    `,
    [...params, DB_LIMIT]
  );

  return result.rows.reverse();
}

async function loadMt5M1FromDb() {
  if (!db) return null;

  try {
    // Новый Windows worker пишет source=MT5_GOLD.
    // Допускаем и будущие MT5_* варианты.
    const rows = await loadDbRows(
      "AND UPPER(source) LIKE 'MT5%'"
    );

    if (!rows.length) return null;

    const candles = sanitizeCandles(rows);
    assertFresh(candles, "MT5/PostgreSQL");
    logFresh("MT5/PostgreSQL", candles);

    return candles;
  } catch (error) {
    console.warn(
      `⚠️ MT5/PostgreSQL M1: ${error.message}`
    );
    return null;
  }
}

async function loadAnyFreshM1FromDb() {
  if (!db) return null;

  try {
    const rows = await loadDbRows("");

    if (!rows.length) return null;

    const candles = sanitizeCandles(rows);
    assertFresh(candles, "PostgreSQL");
    logFresh("PostgreSQL", candles);

    return candles;
  } catch (error) {
    console.warn(
      `⚠️ PostgreSQL M1 fallback: ${error.message}`
    );
    return null;
  }
}

// ======================================================
// DUKASCOPY FALLBACK
// ======================================================

async function fetchDukasRange(start, end) {
  const rows = await getHistoricalRates({
    instrument: "xauusd",
    dates: {
      from: start,
      to: end,
    },
    timeframe: "m1",
    priceType: "bid",
    format: "json",
    ignoreFlats: false,
    retryOnEmpty: false,
  });

  return sanitizeCandles(rows || []);
}

async function loadDukasFreshM1() {
  const end = new Date();
  let lastError = null;

  for (let attempt = 1; attempt <= DUKAS_RETRIES; attempt++) {
    try {
      let candles;

      if (liveCache.data?.length && liveCache.source === "DUKASCOPY") {
        const last = liveCache.data[liveCache.data.length - 1];

        const start = new Date(
          Math.max(
            last.time -
              DUKAS_INCREMENTAL_LOOKBACK_MINUTES * 60_000,
            end.getTime() - 8 * 60 * 60_000
          )
        );

        console.log(
          `📡 Dukascopy M1 LIVE ${attempt}/${DUKAS_RETRIES}`
        );

        const fresh = await fetchDukasRange(start, end);
        candles = sanitizeCandles([
          ...liveCache.data,
          ...fresh,
        ]);
      } else {
        const start = new Date(
          end.getTime() -
            DUKAS_HISTORY_HOURS * 60 * 60_000
        );

        console.log(
          `📡 Dukascopy M1 FULL ${attempt}/${DUKAS_RETRIES}`
        );

        candles = (
          await fetchDukasRange(start, end)
        ).slice(-DB_LIMIT);
      }

      assertFresh(candles, "Dukascopy");
      logFresh("Dukascopy", candles);

      return candles;
    } catch (error) {
      lastError = error;

      const status =
        error?.response?.status;

      console.warn(
        `⚠️ Dukascopy M1: ${status || ""} ${error.message}`
      );

      if (attempt < DUKAS_RETRIES) {
        await sleep(attempt * 3000);
      }
    }
  }

  throw (
    lastError ||
    new Error("Dukascopy: свежие M1 не получены")
  );
}

// ======================================================
// PUBLIC LIVE M1
// ======================================================

async function doLoadLiveM1(forceRefresh = false) {
  if (
    !forceRefresh &&
    liveCache.data?.length &&
    Date.now() - liveCache.updatedAt < LIVE_CACHE_MS
  ) {
    // Даже кэш отдаём только если его последняя свеча всё ещё свежая.
    assertFresh(
      liveCache.data,
      `CACHE/${liveCache.source || "UNKNOWN"}`
    );

    return liveCache.data;
  }

  // 1. Главный источник: MT5 -> PostgreSQL.
  const mt5 = await loadMt5M1FromDb();

  if (mt5) {
    liveCache = {
      data: mt5,
      updatedAt: Date.now(),
      source: "MT5_POSTGRES",
    };

    return mt5;
  }

  // 2. Если таблицу уже заполняет другой свежий источник.
  const dbFresh = await loadAnyFreshM1FromDb();

  if (dbFresh) {
    liveCache = {
      data: dbFresh,
      updatedAt: Date.now(),
      source: "POSTGRES",
    };

    return dbFresh;
  }

  // 3. Резервный интернет-источник.
  try {
    const dukas = await loadDukasFreshM1();

    liveCache = {
      data: dukas,
      updatedAt: Date.now(),
      source: "DUKASCOPY",
    };

    return dukas;
  } catch (dukasError) {
    // КРИТИЧЕСКОЕ ПРАВИЛО:
    // не возвращаем старый кэш ради того, чтобы показать пользователю сигнал.
    // Лучше честная ошибка, чем BUY/SELL по данным 20-часовой давности.
    const cacheInfo =
      liveCache.data?.length
        ? ` Старый кэш ${liveCache.source || "UNKNOWN"}: ` +
          `${Math.round(latestAgeMs(liveCache.data) / 60_000)} мин.`
        : "";

    throw new Error(
      `Нет свежих M1. MT5/PostgreSQL ещё не обновлён, ` +
      `Dukascopy тоже не дал свежие данные.${cacheInfo} ` +
      `Сигнал заблокирован для безопасности.`
    );
  }
}

async function loadLiveM1(forceRefresh = false) {
  if (liveLoadPromise) {
    return liveLoadPromise;
  }

  liveLoadPromise = doLoadLiveM1(forceRefresh);

  try {
    return await liveLoadPromise;
  } finally {
    liveLoadPromise = null;
  }
}

// ======================================================
// COMPATIBILITY
// ======================================================

function setupAutopilot() {
  // CLEAN V4 уже содержит AUTOPILOT внутри index.js.
  // Функция оставлена, чтобы старый require/import не ломал проект.
  console.warn(
    "ℹ️ setupAutopilot(): CLEAN V4 использует встроенный AUTOPILOT из index.js."
  );

  return {
    stop() {},
    scan() {
      return Promise.resolve();
    },
  };
}

async function closeMarketData() {
  if (db) {
    await db.end().catch(() => {});
  }
}

module.exports = {
  loadLiveM1,
  setupAutopilot,
  closeMarketData,
  MARKET_DATA_MAX_AGE_MS,
};
