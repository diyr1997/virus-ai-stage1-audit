"use strict";

/*
  Telegram operational security bootstrap.

  This module is designed to be preloaded before index.js. It never calls
  Telegram and never changes trading, signal, risk, or account logic.
  Responsibilities:
    1) validate TELEGRAM_BOT_TOKEN shape without displaying the secret;
    2) emit a masked/config-only startup status;
    3) redact credential-bearing Telegram URLs, token-like values, bearer
       credentials, common credential query parameters, and nested auth fields;
    4) reduce Error and non-Error rejection values to safe diagnostics.
*/

const TOKEN_ENV = "TELEGRAM_BOT_TOKEN";
const REDACTED = "[TELEGRAM_TOKEN_REDACTED]";
const GENERIC_REDACTED = "[REDACTED]";
const TELEGRAM_URL_RE = /https?:\/\/api\.telegram\.org\/bot[^\s/?#]+/gi;
const TOKEN_RE = /\b\d{5,}:[A-Za-z0-9_-]{20,}\b/g;
const BEARER_RE = /\bBearer\s+[A-Za-z0-9._~+\/-]{12,}/gi;
const QUERY_SECRET_RE = /([?&](?:token|api[_-]?key|key|secret|password|authorization|auth)=)[^&#\s]*/gi;
const ASSIGNMENT_SECRET_RE = /\b(api[_-]?key|token|password|secret|authorization|auth)\b\s*[:=]\s*([^\s,;]+)/gi;

function sanitizeString(value) {
  return String(value)
    .replace(TELEGRAM_URL_RE, "https://api.telegram.org/bot[REDACTED]")
    .replace(TOKEN_RE, REDACTED)
    .replace(BEARER_RE, "Bearer [REDACTED]")
    .replace(QUERY_SECRET_RE, "$1[REDACTED]")
    .replace(ASSIGNMENT_SECRET_RE, "$1=[REDACTED]");
}

function sanitizeForLog(value, seen = new WeakSet()) {
  if (typeof value === "string") return sanitizeString(value);
  if (value == null || typeof value === "number" || typeof value === "boolean") {
    return value;
  }
  if (typeof value === "bigint") return String(value);
  if (typeof value === "symbol") return sanitizeString(String(value));
  if (typeof value === "function") return `[Function ${value.name || "anonymous"}]`;

  if (value instanceof Error) {
    const safe = {
      name: sanitizeString(value.name || "Error"),
      message: sanitizeString(value.message || ""),
    };
    if (value.code != null) safe.code = sanitizeString(value.code);
    if (value.response?.statusCode != null) safe.statusCode = value.response.statusCode;
    if (value.response?.body?.error_code != null) safe.error_code = value.response.body.error_code;
    if (value.response?.body?.description != null) {
      safe.description = sanitizeString(value.response.body.description);
    }
    return safe;
  }

  if (typeof value === "object") {
    if (seen.has(value)) return "[Circular]";
    seen.add(value);
    if (Array.isArray(value)) return value.map((item) => sanitizeForLog(item, seen));
    const safe = {};
    for (const [key, item] of Object.entries(value)) {
      const lower = key.toLowerCase();
      if (
        lower.includes("token") ||
        lower.includes("password") ||
        lower.includes("secret") ||
        lower === "authorization" ||
        lower === "auth" ||
        lower === "api_key" ||
        lower === "apikey"
      ) {
        safe[key] = GENERIC_REDACTED;
      } else if (lower === "url" || lower === "uri" || lower === "href") {
        safe[key] = sanitizeString(item);
      } else {
        safe[key] = sanitizeForLog(item, seen);
      }
    }
    return safe;
  }

  return sanitizeString(value);
}

function sanitizeError(value) {
  return sanitizeForLog(value);
}

function installConsoleRedaction(consoleObject = console) {
  for (const method of ["log", "info", "warn", "error", "debug"]) {
    const original = consoleObject[method]?.bind(consoleObject);
    if (!original || original.__telegramSafeWrapper) continue;
    const wrapped = (...args) => original(...args.map((arg) => sanitizeForLog(arg)));
    wrapped.__telegramSafeWrapper = true;
    consoleObject[method] = wrapped;
  }
}

function validateTelegramTokenConfig(token = process.env[TOKEN_ENV]) {
  const value = String(token || "").trim();
  if (!value) {
    return { ok: false, reason: `${TOKEN_ENV} is missing`, maskedIdentity: null };
  }
  const match = /^(\d{5,}):([A-Za-z0-9_-]{20,})$/.exec(value);
  if (!match) {
    return { ok: false, reason: `${TOKEN_ENV} has invalid format`, maskedIdentity: null };
  }
  const botId = match[1];
  const maskedIdentity = botId.length <= 4 ? `${botId[0]}…` : `${botId.slice(0, 3)}…${botId.slice(-2)}`;
  return { ok: true, reason: "configured", maskedIdentity };
}

installConsoleRedaction();

const telegramConfigStatus = validateTelegramTokenConfig();
if (telegramConfigStatus.ok) {
  console.log(`🔐 Telegram credential: configured • bot-id ${telegramConfigStatus.maskedIdentity}`);
} else {
  console.error(`❌ Telegram credential configuration: ${telegramConfigStatus.reason}`);
  process.exitCode = 1;
}

module.exports = {
  REDACTED,
  GENERIC_REDACTED,
  sanitizeString,
  sanitizeForLog,
  sanitizeError,
  installConsoleRedaction,
  validateTelegramTokenConfig,
  telegramConfigStatus,
};
