"""Tests for the sealed evaluation block.

The property that matters is not "the split runs". It is that the boundary
cannot move on its own: the same config must carve the same window regardless
of how many rows arrived since, and no label may reach across it.
"""

from __future__ import annotations

import json
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pandas as pd

from final_holdout import (
    HoldoutBoundary,
    assert_sealed,
    load_boundary,
    seal,
    split_off_holdout,
)

MINUTE_MS = 60_000


def ms(year, month, day, hour=0, minute=0):
    return int(
        datetime(year, month, day, hour, minute, tzinfo=timezone.utc).timestamp() * 1000
    )


def rows(start, count, *, step_minutes=1, horizon_minutes=60):
    """Decision rows whose labels resolve horizon_minutes later."""
    return pd.DataFrame(
        [
            {
                "timestamp": start + i * step_minutes * MINUTE_MS,
                "future_ts_60": start
                + i * step_minutes * MINUTE_MS
                + horizon_minutes * MINUTE_MS,
                "close": 4000.0 + i,
            }
            for i in range(count)
        ]
    )


def boundary(embargo_minutes=120):
    return HoldoutBoundary(
        label="test-v1",
        start_ms=ms(2026, 1, 1),
        end_ms=ms(2026, 8, 14, 21, 58),
        embargo_minutes=embargo_minutes,
    )


def write_config(**overrides):
    payload = {
        "label": "test-v1",
        "holdout_start_utc": "2026-01-01T00:00:00+00:00",
        "holdout_end_utc": "2026-08-14T21:58:00+00:00",
        "embargo_minutes": 120,
    }
    payload.update(overrides)
    handle = tempfile.NamedTemporaryFile(
        "w", suffix=".json", delete=False, encoding="utf-8"
    )
    json.dump(payload, handle)
    handle.close()
    return Path(handle.name)


class ConfigTest(unittest.TestCase):
    def test_the_shipped_config_parses(self):
        loaded = load_boundary()
        self.assertEqual(loaded.label, "xauusd-m1-h1-final-holdout-v1")
        self.assertEqual(loaded.start_ms, ms(2026, 1, 1))
        self.assertGreater(loaded.end_ms, loaded.start_ms)
        self.assertGreater(loaded.embargo_minutes, 0)

    def test_a_missing_config_raises_instead_of_training_on_everything(self):
        with self.assertRaises(RuntimeError):
            load_boundary("/nonexistent/final_holdout.json")

    def test_broken_json_raises(self):
        handle = tempfile.NamedTemporaryFile(
            "w", suffix=".json", delete=False, encoding="utf-8"
        )
        handle.write("{ not json")
        handle.close()
        with self.assertRaises(RuntimeError):
            load_boundary(handle.name)

    def test_a_naive_timestamp_is_refused(self):
        path = write_config(holdout_start_utc="2026-01-01T00:00:00")
        with self.assertRaises(RuntimeError):
            load_boundary(path)

    def test_an_inverted_window_is_refused(self):
        path = write_config(
            holdout_start_utc="2026-08-14T00:00:00+00:00",
            holdout_end_utc="2026-01-01T00:00:00+00:00",
        )
        with self.assertRaises(RuntimeError):
            load_boundary(path)

    def test_a_negative_embargo_is_refused(self):
        path = write_config(embargo_minutes=-5)
        with self.assertRaises(RuntimeError):
            load_boundary(path)


class SplitTest(unittest.TestCase):
    def test_rows_inside_the_window_never_reach_training(self):
        data = pd.concat(
            [
                rows(ms(2025, 12, 1), 200),
                rows(ms(2026, 3, 1), 200),
                rows(ms(2026, 10, 1), 200),
            ],
            ignore_index=True,
        )

        trainable, holdout = split_off_holdout(data, boundary())

        self.assertEqual(len(holdout), 200)
        self.assertTrue((holdout["timestamp"] >= ms(2026, 1, 1)).all())
        self.assertTrue((holdout["timestamp"] <= ms(2026, 8, 14, 21, 58)).all())
        self.assertEqual(
            len(trainable[(trainable["timestamp"] >= ms(2026, 1, 1))
                          & (trainable["timestamp"] <= ms(2026, 8, 14, 21, 58))]),
            0,
        )

    def test_a_label_reaching_into_the_window_is_dropped(self):
        # Decision bars in the last hours of 2025 whose 60-bar label lands in
        # 2026. The row sits before the window, the answer sits inside it.
        b = boundary(embargo_minutes=0)
        data = rows(ms(2025, 12, 31, 22, 0), 180)  # 22:00 -> 00:59 next day

        trainable, holdout = split_off_holdout(data, b)

        self.assertTrue((trainable["future_ts_60"] < b.start_ms).all())
        self.assertGreater(len(data), len(trainable) + len(holdout))
        assert_sealed(trainable, holdout, b)

    def test_the_embargo_widens_the_gap_beyond_the_label_horizon(self):
        data = rows(ms(2025, 12, 31, 18, 0), 360)

        no_embargo, _ = split_off_holdout(data, boundary(embargo_minutes=0))
        with_embargo, _ = split_off_holdout(data, boundary(embargo_minutes=120))

        self.assertLess(len(with_embargo), len(no_embargo))
        self.assertEqual(len(no_embargo) - len(with_embargo), 120)

    def test_rows_after_the_window_stay_trainable(self):
        # Live M1 arriving after the sealed block is the only thing the daily
        # lab has to learn from, so it must not be swallowed by the holdout.
        data = rows(ms(2026, 9, 1), 500)
        trainable, holdout = split_off_holdout(data, boundary())

        self.assertEqual(len(holdout), 0)
        self.assertEqual(len(trainable), 500)

    def test_a_dataset_that_misses_the_window_entirely_is_not_an_error(self):
        data = rows(ms(2026, 9, 1), 100)
        trainable, holdout, report = seal(data)
        self.assertEqual(len(holdout), 0)
        self.assertEqual(len(trainable), 100)
        self.assertTrue(report["sealed"])

    def test_missing_columns_are_refused(self):
        data = rows(ms(2026, 9, 1), 10).drop(columns=["future_ts_60"])
        with self.assertRaises(RuntimeError):
            split_off_holdout(data, boundary())


class BoundaryStabilityTest(unittest.TestCase):
    def test_the_window_does_not_move_when_more_data_arrives(self):
        # The failure this guards against: a holdout defined as "the last 15%"
        # slides forward every time candles arrive, so last week's test window
        # quietly becomes this week's training data.
        small = rows(ms(2025, 6, 1), 1_000)
        grown = pd.concat([small, rows(ms(2026, 9, 1), 50_000)], ignore_index=True)

        _, holdout_small = split_off_holdout(small, boundary())
        _, holdout_grown = split_off_holdout(grown, boundary())

        self.assertEqual(len(holdout_small), 0)
        self.assertEqual(len(holdout_grown), 0)

        with_window = pd.concat(
            [small, rows(ms(2026, 2, 1), 300), rows(ms(2026, 9, 1), 50_000)],
            ignore_index=True,
        )
        _, holdout_window = split_off_holdout(with_window, boundary())
        self.assertEqual(len(holdout_window), 300)


class AssertSealedTest(unittest.TestCase):
    def test_it_catches_a_training_row_inside_the_window(self):
        b = boundary()
        leaked = rows(ms(2026, 3, 1), 10)
        with self.assertRaises(RuntimeError):
            assert_sealed(leaked, pd.DataFrame(columns=leaked.columns), b)

    def test_it_catches_a_training_label_resolving_inside_the_window(self):
        b = boundary()
        leaked = pd.DataFrame(
            [
                {
                    "timestamp": b.start_ms - 30 * MINUTE_MS,
                    "future_ts_60": b.start_ms + 30 * MINUTE_MS,
                    "close": 4000.0,
                }
            ]
        )
        with self.assertRaises(RuntimeError):
            assert_sealed(leaked, pd.DataFrame(columns=leaked.columns), b)

    def test_it_catches_a_holdout_row_outside_the_window(self):
        b = boundary()
        stray = rows(ms(2026, 11, 1), 5)
        with self.assertRaises(RuntimeError):
            assert_sealed(pd.DataFrame(columns=stray.columns), stray, b)

    def test_a_clean_split_reports_both_sides(self):
        data = pd.concat(
            [rows(ms(2025, 6, 1), 100), rows(ms(2026, 3, 1), 40)], ignore_index=True
        )
        trainable, holdout, report = seal(data)
        self.assertEqual(report["holdout_rows"], 40)
        self.assertEqual(report["trainable_rows"], 100)
        self.assertEqual(report["holdout_label"], "xauusd-m1-h1-final-holdout-v1")
        self.assertTrue(report["sealed"])


if __name__ == "__main__":
    unittest.main()
