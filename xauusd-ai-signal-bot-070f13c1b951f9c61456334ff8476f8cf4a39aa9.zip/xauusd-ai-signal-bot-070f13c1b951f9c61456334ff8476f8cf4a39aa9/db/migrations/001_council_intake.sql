BEGIN;

CREATE TABLE IF NOT EXISTS council_intake_requests (
  id TEXT PRIMARY KEY,
  task_id TEXT NOT NULL UNIQUE,
  draft_task_id TEXT UNIQUE,
  source TEXT NOT NULL,
  mutation_kind TEXT NOT NULL,
  raw_request TEXT NOT NULL,
  request_hash TEXT NOT NULL,
  context_hash TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN (
    'RECEIVED',
    'COUNCIL_PENDING',
    'PROVISIONAL_REVIEW',
    'REVIEWED',
    'AUTHORIZED_FOR_DRAFT',
    'DRAFT_REVIEW_PENDING',
    'AUTHORIZED_FOR_MERGE',
    'BLOCKED',
    'FAILED'
  )),
  provisional BOOLEAN NOT NULL DEFAULT FALSE,
  council_revision INTEGER,
  draft_ref TEXT,
  draft_hash TEXT,
  draft_authorization_hash TEXT,
  merge_authorization_hash TEXT,
  merge_council_revision INTEGER,
  last_error TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS council_intake_audit (
  id BIGSERIAL PRIMARY KEY,
  intake_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  from_state TEXT,
  to_state TEXT,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS council_intake_status_idx
  ON council_intake_requests(status, updated_at);

CREATE INDEX IF NOT EXISTS council_intake_audit_intake_idx
  ON council_intake_audit(intake_id, created_at);

COMMIT;
