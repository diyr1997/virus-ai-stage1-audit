"use strict";

const { Pool } = require("pg");

console.log("📊 TODAY AUDIT BOOTSTRAP: loaded");

const url = process.env.DATABASE_URL || process.env.DATABASE_PUBLIC_URL || "";
if (!url) {
  console.warn("📊 TODAY AUDIT: database URL missing");
} else {
  const pool = new Pool({ connectionString: url, max: 1, connectionTimeoutMillis: 10000 });

  async function runWindow(label, days) {
    const base = `
      WITH s AS (
        SELECT a.*, r.success, r.outcome,
          EXTRACT(HOUR FROM a.analyzed_at AT TIME ZONE 'Asia/Tashkent')::int AS hour_local
        FROM analysis_runs a
        JOIN analysis_results r ON r.analysis_id = a.id
        WHERE a.action IN ('BUY','SELL')
          AND r.success IS NOT NULL
          AND a.analyzed_at >= NOW() - ($1::text || ' days')::interval
      )
    `;

    const baseline = await pool.query(base + `
      SELECT COUNT(*)::int n,
        COUNT(*) FILTER (WHERE success)::int wins,
        COUNT(*) FILTER (WHERE NOT success)::int losses,
        ROUND(100.0*COUNT(*) FILTER (WHERE success)/NULLIF(COUNT(*),0),2) acc
      FROM s
    `, [days]);
    console.log(`📊 SHADOW ${label} BASELINE ` + JSON.stringify(baseline.rows[0] || {}));

    const dims = await pool.query(base + `
      SELECT timeframe, action,
        CASE WHEN strength<70 THEN '60-69' WHEN strength<80 THEN '70-79' WHEN strength<90 THEN '80-89' ELSE '90-100' END bucket,
        COUNT(*)::int n,
        COUNT(*) FILTER (WHERE success)::int wins,
        COUNT(*) FILTER (WHERE NOT success)::int losses,
        ROUND(100.0*COUNT(*) FILTER (WHERE success)/NULLIF(COUNT(*),0),2) acc
      FROM s
      GROUP BY timeframe,action,bucket
      HAVING COUNT(*) >= 5
      ORDER BY action,timeframe,bucket
    `, [days]);
    for (const row of dims.rows) console.log(`📊 SHADOW ${label} DIM ` + JSON.stringify(row));

    const rules = await pool.query(base + `
      SELECT rule,
        COUNT(*)::int n,
        COUNT(*) FILTER (WHERE success)::int wins,
        COUNT(*) FILTER (WHERE NOT success)::int losses,
        ROUND(100.0*COUNT(*) FILTER (WHERE success)/NULLIF(COUNT(*),0),2) acc
      FROM (
        SELECT s.*, 'BASELINE'::text rule FROM s
        UNION ALL
        SELECT s.*, 'SELL_RSI_LT45' FROM s
          WHERE action='BUY' OR (action='SELL' AND rsi < 45)
        UNION ALL
        SELECT s.*, 'SELL_RSI_LT45_NO_UP_NEWS' FROM s
          WHERE action='BUY' OR (action='SELL' AND rsi < 45 AND COALESCE(news_direction,'NEUTRAL') <> 'UP')
        UNION ALL
        SELECT s.*, 'SELL_RSI_LT45_TF_M1M5' FROM s
          WHERE action='BUY' OR (action='SELL' AND rsi < 45 AND timeframe IN ('M1','M5'))
        UNION ALL
        SELECT s.*, 'BLOCK_80_89' FROM s
          WHERE NOT (strength >= 80 AND strength < 90)
        UNION ALL
        SELECT s.*, 'BLOCK_BAD_HOURS_09' FROM s
          WHERE hour_local <> 9
        UNION ALL
        SELECT s.*, 'SELL_RSI45_AND_BLOCK_80_89' FROM s
          WHERE (action='BUY' OR (action='SELL' AND rsi < 45))
            AND NOT (strength >= 80 AND strength < 90)
      ) x
      GROUP BY rule ORDER BY rule
    `, [days]);
    for (const row of rules.rows) console.log(`📊 SHADOW ${label} RULE ` + JSON.stringify(row));

    const side = await pool.query(base + `
      SELECT action, COUNT(*)::int n,
        COUNT(*) FILTER (WHERE success)::int wins,
        COUNT(*) FILTER (WHERE NOT success)::int losses,
        ROUND(100.0*COUNT(*) FILTER (WHERE success)/NULLIF(COUNT(*),0),2) acc,
        ROUND(AVG(strength)::numeric,2) avg_strength,
        ROUND(AVG(rsi)::numeric,2) avg_rsi
      FROM s GROUP BY action ORDER BY action
    `, [days]);
    for (const row of side.rows) console.log(`📊 SHADOW ${label} SIDE ` + JSON.stringify(row));
  }

  setTimeout(async () => {
    try {
      console.log("📊 TODAY AUDIT: query start");
      await runWindow("7D", 7);
      await runWindow("30D", 30);
    } catch (err) {
      console.error("📊 TODAY AUDIT ERROR", err.message);
    } finally {
      await pool.end().catch(() => {});
    }
  }, 2000);
}
