# AI Council Task — Telegram Menu Cleanup Review

## User intent
The user wants the Telegram interface simplified, but does NOT want one person to decide alone. Every available AI Council advisor must independently inspect the current Telegram menu/commands, then peer-review the others and produce one reconciled proposal.

Do not delete or disable anything automatically in this task. First produce the joint UX/architecture decision.

## Current known Telegram inventory from index.js
### Main inline menu
- 📊 Проверить сигнал -> signal_menu
- 🌍 Новости 24ч -> news_general
- 📊 CFTC -> cftc
- 🤖 AUTOPILOT -> autopilot_status
- 🗄 База -> db_status
- ⚙️ Режим DEMO -> risk_mode_menu

### Signal submenu
- M1 -> signal_M1
- M5 -> signal_M5
- M15 -> signal_M15
- M30 -> signal_M30
- H1 -> signal_H1
- ⚙️ Режим DEMO -> risk_mode_menu

### Risk submenu
- 🛡 Осторожный -> risk_mode_CAUTIOUS
- ⚖️ Средний -> risk_mode_MEDIUM
- 🔥 Активный -> risk_mode_ACTIVE
- 🚀 Агрессивный -> risk_mode_AGGRESSIVE
- ⬅️ Главное меню -> main_menu

### Telegram command list registered with setMyCommands
- /start — Главное меню
- /signal — Сигнал M1/M5/M15/M30/H1
- /news — Новости XAU/USD
- /cftc — CFTC Gold
- /stats — Статистика по TF
- /stats_all — Вся статистика
- /demo_stats — DEMO статистика
- /risk — Режим риска DEMO
- /db_status — PostgreSQL
- /autopilot — AUTOPILOT
- /autopilot_on — Включить AUTOPILOT
- /autopilot_off — Выключить AUTOPILOT
- /ai_status — AI H1
- /ping — Проверка

### Additional known text handler
- /ai_review — Gemini project review, advisory only; not part of the visible setMyCommands list.

### Known callback handlers
- main_menu
- signal_menu
- signal_M1/M5/M15/M30/H1
- news_general
- cftc
- autopilot_status
- db_status
- risk_mode_menu
- risk_mode_CAUTIOUS/MEDIUM/ACTIVE/AGGRESSIVE

## What the council must decide
Each advisor must independently classify every visible menu button and command into exactly one of:
1. KEEP_IN_MAIN — frequent and important enough for the top-level menu.
2. MOVE_TO_SUBMENU — useful but cluttering the main menu.
3. KEEP_COMMAND_ONLY — useful for diagnostics/admin but should not clutter buttons/visible command menu.
4. MERGE — duplicates another action/status and should be combined.
5. REMOVE — obsolete, redundant, misleading, unsafe, or no longer useful.

Then peer-review the classifications and reconcile disagreements.

## Design goals
- Phone-first Telegram UX: minimal taps, minimal clutter.
- Main menu should contain only the actions the owner uses frequently.
- Do not remove access to critical DEMO controls or diagnostics; they can be moved into a compact submenu.
- Avoid exposing developer/debug/admin commands in the everyday menu when they are not needed.
- Avoid duplicate ways to do the same thing unless there is a clear reason.
- Keep M1/M5/M15/M30/H1 signal access simple.
- Risk mode controls must remain available, but the council should decide whether they belong in main menu or a separate DEMO/Trading submenu.
- Consider combining AUTOPILOT status/on/off into one compact control/menu rather than three visible commands.
- Consider combining PostgreSQL/worker/AI health into one STATUS/СОСТОЯНИЕ screen instead of separate technical commands if appropriate.
- Consider whether CFTC belongs in the main menu or under News/Market Context because it is slower weekly context.
- Consider whether /stats and /stats_all should be merged.
- Consider whether /demo_stats should be in a DEMO/Trading submenu.
- Consider whether /ping should remain hidden technical diagnostics rather than visible command list.
- Consider whether /ai_status and /ai_review should be hidden/admin-only rather than everyday UX.

## Safety / implementation constraints
- DEMO only; do not change REAL protections.
- Do not change trading logic, entry rules, risk logic, news scoring, graph logic, or worker behavior in this task.
- Do not introduce another Telegram polling process or another bot instance.
- Before removing a visible command/button, verify whether the handler is used by callbacks, alerts, diagnostics, or external workflows.
- Prefer hiding/de-registering from setMyCommands before deleting a useful internal handler.
- Preserve backward compatibility where inexpensive: old slash commands may continue to work even if hidden from the command menu.
- Avoid Telegram 409 duplicate-poller risk.

## Required output
Return:
- proposed_main_menu
- proposed_submenus
- command_classification_table
- buttons_to_remove
- commands_to_hide_but_keep
- commands_to_merge
- callbacks_or_handlers_that_must_remain
- migration_plan
- regression_tests
- risks
- disagreements
- final_recommendation

Do not implement deletions yet. This is a council design/review task first.
