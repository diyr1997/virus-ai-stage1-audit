# XAU/USD first-launch validation report

Generated: 2026-09-11, by Claude Code. Source: this session's actual test runs against
commit `8f06a05` (origin/main) plus a fix pushed to `fix/v7-restore-ownership-fence-recheck`
(commit `9d85b7e`). Every number below is either a real test-suite result from this
session or explicitly marked as not available. Nothing is invented, per this project's
own rule in `AGENTS.md`: *"Never invent backtest metrics, runtime status, test results,
data availability, or profitability."*

## Executive summary

**There is no completed real-market historical backtest with trade-level P&L in this
project yet**, and this report does not manufacture one. What exists and what was
verified here is **mechanism-level validation**: deterministic unit/regression tests
that prove the *rules* (WAIT-as-alternative, no look-ahead, purge/embargo, closed-candle
contract, DEMO/REAL fencing, ownership safety) are implemented correctly in code. That is
a real and necessary form of validation, but it is not the same as "N trades, X% win
rate" — and per your own instruction, a win-rate number alone would not mean "ready"
even if one existed.

One **critical safety regression was found and fixed** during this validation (see
below) before any DEMO trade would have been affected by it.

## Why trade-level metrics (win rate / P&L / profit factor / drawdown / Sharpe) are NOT_TESTED

Checked, not assumed:

- No `DATABASE_URL` or Postgres credentials are available in this Claude Code session —
  confirmed empty. The live candle/analysis/DEMO-trade history lives in Railway
  PostgreSQL, which this session cannot reach.
- Searched the entire repository for any previously recorded backtest report (win rate,
  profit factor, Sharpe, drawdown, net P&L) — found none. Every match was policy prose
  describing *how metrics should be measured*, never an actual measured result.
- The new `trading_ai/` "Trading AI shadow core" — the system whose README explicitly
  defines the promotion path required to produce these numbers — states its own current
  stage is step 1-2 of 7 (*"Data contracts and shadow logging"* / *"Historical
  dataset/window builder"*), **before** step 4, *"Walk-forward/out-of-sample evaluation
  after spread/slippage."* It has not reached that stage. Its `TradingAIShadowTrader`
  hard-codes `execution_allowed=False`, confirming it isn't live-decisioning yet either.
- The legacy production bot (`index.js`/`mt5-bridge.js`) is the system that has actually
  been trading DEMO, but its trade history is in Railway Postgres, not in this Git
  checkout, and I have no read access to it from here.

**Conclusion: trade count, win rate, net P&L, average trade, profit factor, max
drawdown, and Sharpe are all `NOT_TESTED — NEEDS_MORE_DATA (no DB access in this
session)`.** Reporting any number here would be fabrication. The real next step to get
these numbers is listed at the end of this report.

## Part 1 — Historical validation (mechanism-level, via deterministic tests)

All commands below were actually run in this session; counts are copy-pasted from real
output, not estimated.

| Check | Status | Evidence |
|---|---|---|
| BUY / SELL / WAIT as three real outcomes | **PASS** | `trading_ai/tests/test_economic_labels.py` (16/16), `trading_ai/tests/test_labels.py` (5/5) |
| WAIT as an independent alternative with utility = 0 | **PASS** | Same suites; CI job is literally named "Adaptive WAIT threshold causality" / "Economic WAIT and executable-price labels" in `current-safety-reaudit-tests.yml`, and it enforces WAIT-utility-at-zero as an invariant (commit `fd7cb67`, `66cdf1b`) |
| Execution costs (spread) modeled in labels | **PASS (mechanism)** | `spread`/cost handling present in `trading_ai/core.py`, `economic_labels.py`, `features.py`, `sampled_quotes.py`, `all_indicator_stack.py`, `indicator_universe.py`; covered by `test_pipeline_baseline.py`, `test_anchored_price_regressions.py` (6/6) |
| Slippage | **NOT_TESTED** | No dedicated slippage model/test found under this name in `trading_ai/`; only spread is explicitly modeled at the label layer. Flag this as a gap, not a pass. |
| Commission, where applicable | **NOT_TESTED** | No commission-specific code/test found. XAU/USD CFD via this broker path may or may not carry commission — unverified. |
| Closed-candle contract | **PASS** | `trading_ai/mtf.py: aggregate_closed_candles`, `indicator_universe.py` (`provenance: "closed_candle_ohlc"`, *"Compute the frozen Top-10 universe from fully closed candles only"*), `market_structure.py` (*"last closed candle"*) — these are real code-level guarantees, not just comments, and are exercised by `test_mtf.py`, `test_market_structure.py`, `test_indicator_universe.py` (all green, see full run below) |
| No look-ahead | **PASS** | `trading_ai/tests/test_pipeline_baseline.py` full suite (4/4) including the purge-boundary tests; `274c4e6`/`fd7cb67` fixed historical-outcome resolution to use bar index instead of wall-clock specifically to remove a leakage vector |
| No label leakage | **PASS** | Same as above — `274c4e6 fix(labels): resolve historical outcomes by bar index, not wall clock` is a real, tested leakage fix, not just a claim |
| Purge / embargo | **PASS** | `trading_ai/tests/test_pipeline_baseline.py -k "purge_equal_to_horizon or purge_smaller_than_horizon"` → 2/2 pass; also run as part of the full 4/4 baseline suite |
| As-of timestamps for news/CFTC | **PASS (mechanism)** | `tests/historical-news-fomc-pce-pilot.test.js`, `tests/historical-news-phase1-boundary.test.js`, `tests/historical-trust-gate.test.js`, `tests/phase1_reaction_metrics_v2.test.js` all pass (part of the 151/152 JS run below) |
| M1 gaps / missing bars | **PASS (mechanism)** | `trading_ai/tests/test_dataset.py` (2/2); weekend/missing-bar maturity leakage explicitly covered by `66cdf1b test(labels): cover weekend and missing-bar maturity leakage` |
| Session/regime behaviour | **PASS (mechanism)** | `trading_ai/tests/test_session_context.py` (14/14) |
| Per-timeframe (M1/M5/M15/M30/H1) separation | **PASS (mechanism)** | Enforced structurally by `mtf.py`/`indicator_universe.py`/`core.py`; no code path found that mixes timeframe outputs. Not the same as *performance* broken out per timeframe (see below). |
| Per-timeframe / per-year / per-regime **performance** results | **NOT_TESTED — NEEDS_MORE_DATA** | Requires an actual historical run over real price history, which needs DB access this session doesn't have |
| Final untouched holdout | **NOT_TESTED — NEEDS_MORE_DATA** | No evidence a holdout was ever carved out and left untouched for this exact model version; nothing to report without inventing it |

**Full deterministic test run this session (Python):**
```
trading_ai/tests/  → 181 passed, 0 failed
demo_mt5_worker/tests/test_v9_safety.py → 17 passed (after the fix below; was 16 pass / 1 error before)
```

**Full deterministic test run this session (JS):**
```
tests/*.test.js → 151 passed, 1 failed
```
The one JS failure is `tests/bls_archive_collector_v2.test.js`, a live network call to
`bls.gov` that returns HTTP 403 from this sandbox's network — an environment limitation,
not a code defect (already diagnosed in this session, unrelated to this report).

## Part 2 — DEMO / shadow validation

Requested error scenarios, checked against actual code and existing tests, not assumed:

| Scenario | Status | Evidence |
|---|---|---|
| Signal → candidate → worker → quote check → risk guard → DEMO order → SL/TP → log, full chain | **PARTIALLY_TESTED** | Individual stages have real tests (below); no single end-to-end integration test exercises the full chain against a real broker/DB in this session (would need live MT5 + Postgres) |
| Signal arrives but trade never opens (diagnostics) | **PASS (mechanism)** | `today-signal-audit-bootstrap.js`, `worker-status-bootstrap.test.js` — diagnostic formatter tests explicitly cover "no blocker" and "blocker present" cases |
| Duplicate candidates | **PASS** | `telegram-autosignal-dedup-bootstrap.js` design + `tests/` dedup coverage in the JS suite (part of 151/152 green run) |
| Stale quote | **PASS** | `stale-mt5-quote-guard.js` + `tests/stale-mt5-quote-guard.test.js` (green) |
| Worker heartbeat | **PASS (mechanism)** | `worker-status-bootstrap.js` + `tests/worker-status-bootstrap.test.js` (green) |
| Candidate expiry | **PASS (mechanism)** | Expiry logic present in `index.js`/`training-current-data-lab-v2.js`; covered indirectly by `training-current-data-lab-v2.test.js` (green) — no dedicated standalone expiry test found, flagging as mechanism-level only |
| Cooldown | **PASS (mechanism)** | Same as above — present in code, covered indirectly, not by a dedicated named test |
| Scenario cancellation | **PASS** | `test-scenario-cancellation.js` exists as a dedicated test and is green |
| Re-entry after close | **PASS (mechanism)** | Covered by V9 safety suite: `test_monotonic_basket_slot_does_not_reuse_closed_slot`, `test_new_candidate_cannot_reset_basket_risk_budget` (both pass) |
| Multiple simultaneous positions | **PASS** | `test_opposite_direction_is_blocked`, `test_sixth_position_not_blocked_by_count` / `test_risk_budget_can_block_sixth_without_count_cap` — basket/hedge rules explicitly tested and passing |
| Spread spike | **NOT_TESTED — NEEDS_VERIFICATION** | A spread-anomaly z-score mechanism exists (`demo_mt5_worker/impulse_shadow.py`, `fast_entry_shadow.py` — `spread_z`, MAD-based, penalizes quality above z≈2.0), but these live in **shadow** modules; I could not confirm from static reading alone whether this actually hard-blocks a live DEMO send today or is observation-only. Needs a direct answer from someone who knows the current wiring, not a guess from me. |
| News no-trade | **PASS** | `news-trade-safety-bootstrap.js` + `tests/news-trade-safety.test.js` (green); this is also the mechanism validated by today's real production log (`FAST_NEWS_V2_SENT ... pressure=SELL final=WAIT`) discussed earlier this session |
| Fail-closed on missing data | **PASS** | Explicit project-wide rule in `AGENTS.md`/`CONTEXT.md`; concretely enforced by `stale-mt5-quote-guard`, `historical-trust-gate.test.js`, and the fail-closed fast-news watcher (`fix(news): make fast news pressure-only and fail closed on final direction`, tested) |

### Critical finding from this validation pass — found and fixed

**`V9HardenedV7DemoTrader.send_order()`** — the class git history explicitly promoted to
"canonical" DEMO trader on 2026-09-10 (`1e4f00a`, `8f06a05`) — **dropped an ownership-fence
re-check that its own parent class performs as "the last operation before MT5
order_send"**. `_final_send_guard` only checks that a fence token exists, not that it is
still the *current* one. A worker instance that lost exclusive ownership (fence
superseded by another instance/session) but still held a stale token could have reached
`order_send` with it.

This was not theoretical — it's exactly what
`demo_mt5_worker/tests/test_v9_safety.py::test_final_fence_is_last_structural_gate_before_mt5_send`
is designed to catch, and running it in this session showed it crashing with an
`AttributeError` deep inside post-send bookkeeping (`mark_open`) instead of returning
`False` — meaning execution reached past the point it should have been blocked.

**Fixed** on a separate branch, `fix/v7-restore-ownership-fence-recheck` (commit
`9d85b7e`), not merged into `main` yet — awaiting your review. The fix re-adds the exact
same `ownership.is_current(fence_token, force=True)` check the parent class already had,
at the same position (immediately before `mt5.order_send`). Verified: the previously
crashing test now passes cleanly (17/17 in the file), and the full `trading_ai` suite
(181/181) is unaffected. Three pre-existing, unrelated test failures in
`test_v9_council_blockers.py`, `test_v9_preflight_source.py`, and
`test_worker_auto_watchdog.py` (stale `.bat` launcher content expectations) were
confirmed to reproduce identically on vanilla `main` before this fix — not caused by it,
not fixed by it, left alone as a separate lower-severity item.

**Practical impact today:** REAL trading is off project-wide, so the actual blast radius
of this gap was DEMO-only. Still, it is a real fail-closed violation matching exactly the
"ownership/fencing" failure mode `AGENTS.md` calls out by name, and should be reviewed
and merged before relying further on the canonical V7 trader.

## PASS / FAIL / BLOCKER / NEEDS_MORE_DATA / NOT_TESTED summary

- **PASS**: BUY/SELL/WAIT semantics, WAIT-utility-zero, closed-candle contract, no
  look-ahead, no label leakage, purge/embargo, as-of news/CFTC timestamps, M1-gap
  handling, session/regime context, timeframe separation, dedup, stale-quote guard,
  heartbeat, scenario cancellation, re-entry rules, multi-position/hedge rules, news
  no-trade, fail-closed-on-missing-data.
- **FIXED (was FAIL, now PASS on a review-pending branch)**: ownership-fence re-check
  before V7 order_send.
- **NOT_TESTED / NEEDS_VERIFICATION**: slippage modeling, commission modeling, spread-spike
  hard-block wiring in the live path, dedicated candidate-expiry/cooldown unit tests.
- **NOT_TESTED / NEEDS_MORE_DATA**: any trade-level number (count, win rate, net P&L,
  average trade, profit factor, max drawdown, Sharpe), per-timeframe/year/regime
  *performance*, final untouched holdout — all require real historical data and DB
  access this session does not have.
- **BLOCKER for a "ready" verdict**: the missing real backtest itself. Mechanism-level
  correctness is necessary but not sufficient — per your own instruction, do not call
  this "ready" on win rate or on passing unit tests alone, and this report does not.

## Real next step to get actual numbers

This session cannot produce trade-level metrics without live data access it doesn't
have. The accurate next step is to run the existing `trading_ai/pipeline.py` +
`walk_forward.py` machinery against real Railway Postgres history from an environment
that *does* have `DATABASE_URL` (a Railway job, or a session with that credential
provisioned deliberately and reviewed first — not pasted into chat/logs), producing a
dated, versioned report with real counts before any "first launch" claim is made.
