"use strict";

/*
  XAU/USD AI SIGNAL BOT — CLEAN V4.4 DUAL NEWS + RISK CONTROL
  2026-08-18

  Основа: CLEAN V4.1 TIME.

  Главные правила:
  - M1/M5/M15/M30/H1 не смешиваются.
  - Анализ только по закрытым свечам.
  - Ниже 60/100 = WAIT, DEMO-кандидат не создаётся.
  - Аналитический символ в PostgreSQL = XAUUSD.
  - Брокерский символ MT5 может быть GOLD#.
  - TIME GUARD блокирует сигналы по старым/будущим M1.
  - Режим риска DEMO меняется из Telegram и хранится в bot_settings.
  - Этот файл НЕ включает торговлю на реальном счёте.
*/

const TelegramBot = require("node-telegram-bot-api");

// Before sharp: it renders chart text through fontconfig, which caches its
// view of the world on first use. Pointing it at the vendored faces after that
// point would be too late, and every label would come out as an empty box.
const { installChartFonts, describeChartFonts } = require("./chart-fonts");
const CHART_FONTS = installChartFonts();

const sharp = require("sharp");
const { Pool } = require("pg");
const fs = require("fs");
const path = require("path");
const os = require("os");
const { promisify } = require("util");
const { execFile } = require("child_process");

const execFileAsync = promisify(execFile);

const { getGoldNewsSnapshot } = require("./news");
const {
  getCftcGoldSnapshot,
  formatCftcGoldMessage,
} = require("./cftc");
const { loadLiveM1 } = require("./autopilot");
const {
  classifyCandidateOutcome,
  ensureRejectionSchema,
  recordCandidateOutcome,
  pruneRejections,
  reportBreakdown,
} = require("./candidate-rejection-log");
const { runGeminiProjectReview } = require("./ai-review-command");
const {
  consensusLabel,
  formatGeminiNewsSection,
  getGeminiNewsReview,
  mergeNewsPressure,
} = require("./gemini-news");
const {
  createDemoTradeAlertService,
  ensureDemoTradeAlertSchema,
} = require("./demo-trade-alerts");

// ======================================================
// CONFIG
// ======================================================

const TOKEN = process.env.TELEGRAM_BOT_TOKEN;
if (!TOKEN) {
  console.error("❌ TELEGRAM_BOT_TOKEN не найден");
  process.exit(1);
}

const DATABASE_URL =
  process.env.DATABASE_URL ||
  process.env.DATABASE_PUBLIC_URL ||
  "";

const DB_ENABLED = Boolean(DATABASE_URL);

const CANONICAL_TIMEZONE = "UTC";
const USER_TIMEZONE = process.env.USER_TIMEZONE || "Asia/Tashkent";
const MT5_API_TIMEZONE = "UTC";

const TIME_FUTURE_TOLERANCE_MS = Math.max(
  15_000,
  Number(process.env.TIME_FUTURE_TOLERANCE_MS || 90_000)
);

const M1_MAX_AGE_MS = Math.max(
  120_000,
  Number(process.env.M1_MAX_AGE_MS || 5 * 60_000)
);

const NEWS_FUTURE_TOLERANCE_MS = Math.max(
  30_000,
  Number(process.env.NEWS_FUTURE_TOLERANCE_MS || 2 * 60_000)
);

const MODEL_VERSION =
  process.env.MODEL_VERSION ||
  "xauusd-clean-v4.4-gemini-grounded-news-2026-08-19";

const SIGNAL_SYMBOL = "XAUUSD";
const BROKER_SYMBOL_HINT = process.env.MT5_SYMBOL || "GOLD#";

const TF_MINUTES = {
  M1: 1,
  M5: 5,
  M15: 15,
  M30: 30,
  H1: 60,
};

const TF_ORDER = ["M1", "M5", "M15", "M30", "H1"];

const SIGNAL_THRESHOLD = Math.max(
  60,
  Math.min(100, Number(process.env.SIGNAL_THRESHOLD || 60))
);

const CANDIDATE_LOG_RETENTION_DAYS = Math.max(
  7,
  Number(process.env.CANDIDATE_LOG_RETENTION_DAYS || 45)
);

// How often the funnel is printed, and over what window. The rows are written
// on every evaluated bar already; without this nobody ever reads them, and a
// silent day stays unexplained. 0 turns the report off.
const CANDIDATE_FUNNEL_REPORT_MS = Math.max(
  0,
  Number(process.env.CANDIDATE_FUNNEL_REPORT_MS || 3_600_000)
);
const CANDIDATE_FUNNEL_WINDOW_H = Math.max(
  1,
  Number(process.env.CANDIDATE_FUNNEL_WINDOW_H || 24)
);

const TRADE_MIN_STRENGTH = Math.max(
  SIGNAL_THRESHOLD,
  Math.min(100, Number(process.env.TRADE_MIN_STRENGTH || 60))
);

const AUTOPILOT_MIN_STRENGTH = Math.max(
  SIGNAL_THRESHOLD,
  Math.min(100, Number(process.env.AUTOPILOT_MIN_STRENGTH || 60))
);

const TRADE_TFS = new Set(
  String(process.env.TRADE_TIMEFRAMES || "M1,M5,M15,M30,H1")
    .split(",")
    .map((x) => x.trim().toUpperCase())
    .filter((x) => TF_MINUTES[x])
);

const CLOSED_CANDLE_SAFETY_MS = Math.max(
  2_000,
  Number(process.env.CLOSED_CANDLE_SAFETY_MS || 5_000)
);

const MIN_CANDLES = Math.max(
  25,
  Number(process.env.MIN_CANDLES || 30)
);

const NEWS_CACHE_MS = 5 * 60_000;
const MT5_QUOTE_MAX_AGE_MS = 45_000;
const DEMO_WORKER_HEARTBEAT_MAX_AGE_MS = Math.max(
  60_000,
  Number(process.env.DEMO_WORKER_HEARTBEAT_MAX_AGE_MS || 90_000)
);

const AUTOPILOT_SCAN_MS = Math.max(
  60_000,
  Number(process.env.AUTOPILOT_SCAN_INTERVAL_MS || 60_000)
);

const AUTOPILOT_COOLDOWN_MS = Math.max(
  60_000,
  Number(process.env.AUTOPILOT_COOLDOWN_MS || 10 * 60_000)
);

const RESULT_CHECK_MS = 60_000;

const RESULT_HORIZON_MINUTES = {
  M1: 1,
  M5: 5,
  M15: 15,
  M30: 30,
  H1: 60,
};

const CANDIDATE_LIFETIME_MINUTES = {
  M1: 8,
  M5: 25,
  M15: 55,
  M30: 100,
  H1: 180,
};

const NEWS_MAX_AGE_MINUTES = {
  M1: 30,
  M5: 60,
  M15: 120,
  M30: 240,
  H1: 480,
};

// ======================================================
// DEMO RISK MODES — Telegram управляет только выбором.
// Сами параметры риска остаются в trader.py.
// ======================================================

const RISK_MODES = {
  CAUTIOUS: {
    label: "🛡 Осторожный",
    short: "Осторожный",
  },
  MEDIUM: {
    label: "⚖️ Средний",
    short: "Средний",
  },
  ACTIVE: {
    label: "🔥 Активный",
    short: "Активный",
  },
  AGGRESSIVE: {
    label: "🚀 Агрессивный",
    short: "Агрессивный",
  },
};

function normalizeRiskMode(value) {
  const mode = String(value || "")
    .trim()
    .toUpperCase();

  const aliases = {
    "ОСТОРОЖНЫЙ": "CAUTIOUS",
    "СРЕДНИЙ": "MEDIUM",
    "АКТИВНЫЙ": "ACTIVE",
    "АГРЕССИВНЫЙ": "AGGRESSIVE",
    SAFE: "CAUTIOUS",
    NORMAL: "MEDIUM",
  };

  const normalized = aliases[mode] || mode;
  return RISK_MODES[normalized] ? normalized : "MEDIUM";
}

// ======================================================
// AI H1
// ======================================================

const AI_H1_MODEL_PATH =
  process.env.AI_H1_MODEL_PATH ||
  path.join(__dirname, "xauusd_ai_final_h1_full_period.joblib");

const AI_H1_SCRIPT_PATH =
  process.env.AI_H1_SCRIPT_PATH ||
  path.join(__dirname, "ai_predict_h1.py");

const AI_PYTHON =
  process.env.PYTHON_BIN ||
  path.join(__dirname, ".venv", "bin", "python");

const AI_H1_TIMEOUT_MS = 120_000;

let aiH1Cache = {
  lastTimestamp: null,
  data: null,
  updatedAt: 0,
};

// ======================================================
// TELEGRAM
// ======================================================

const bot = new TelegramBot(TOKEN, { polling: true });

// ======================================================
// POSTGRES
// ======================================================

const dbPool = DB_ENABLED
  ? new Pool({
      connectionString: DATABASE_URL,
      max: 5,
      idleTimeoutMillis: 30_000,
      connectionTimeoutMillis: 10_000,
    })
  : null;

let dbInitPromise = null;

function num(value, fallback = null) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

async function initDatabase() {
  if (!dbPool) {
    console.warn("⚠️ PostgreSQL отключён: DATABASE_URL не найден");
    return false;
  }

  const client = await dbPool.connect();

  try {
    await client.query("BEGIN");

    await client.query(`
      CREATE TABLE IF NOT EXISTS xauusd_candles (
        id BIGSERIAL PRIMARY KEY,
        timeframe VARCHAR(5) NOT NULL DEFAULT 'M1',
        candle_time TIMESTAMPTZ NOT NULL,
        open NUMERIC(18,6) NOT NULL,
        high NUMERIC(18,6) NOT NULL,
        low NUMERIC(18,6) NOT NULL,
        close NUMERIC(18,6) NOT NULL,
        volume NUMERIC(24,8) NOT NULL DEFAULT 0,
        source VARCHAR(32) NOT NULL DEFAULT 'live',
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        UNIQUE(timeframe, candle_time)
      )
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS idx_xauusd_candles_tf_time
      ON xauusd_candles(timeframe, candle_time DESC)
    `);

    await client.query(`
      ALTER TABLE xauusd_candles
      ADD COLUMN IF NOT EXISTS source_timezone VARCHAR(64)
      NOT NULL DEFAULT 'UTC'
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS analysis_runs (
        id BIGSERIAL PRIMARY KEY,
        analyzed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        candle_time TIMESTAMPTZ NOT NULL,
        timeframe VARCHAR(5) NOT NULL,
        source VARCHAR(24) NOT NULL DEFAULT 'manual',
        action VARCHAR(8) NOT NULL,
        direction VARCHAR(8) NOT NULL,
        strength SMALLINT NOT NULL,
        analysis_price NUMERIC(18,6) NOT NULL,
        rsi NUMERIC(10,4),
        atr NUMERIC(18,6),
        score NUMERIC(10,4),
        news_direction VARCHAR(12),
        news_strength SMALLINT,
        cftc_direction VARCHAR(12),
        ai_action VARCHAR(8),
        ai_confidence NUMERIC(10,6),
        confirmation_price NUMERIC(18,6),
        invalidation_price NUMERIC(18,6),
        sl NUMERIC(18,6),
        tp1 NUMERIC(18,6),
        tp2 NUMERIC(18,6),
        tp3 NUMERIC(18,6),
        entry_status VARCHAR(32) NOT NULL DEFAULT 'WAIT_CONFIRMATION',
        model_version VARCHAR(80),
        payload JSONB NOT NULL DEFAULT '{}'::jsonb
      )
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS idx_analysis_runs_tf_time
      ON analysis_runs(timeframe, analyzed_at DESC)
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS analysis_results (
        id BIGSERIAL PRIMARY KEY,
        analysis_id BIGINT NOT NULL UNIQUE
          REFERENCES analysis_runs(id)
          ON DELETE CASCADE,
        target_at TIMESTAMPTZ NOT NULL,
        checked_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        exit_price NUMERIC(18,6),
        success BOOLEAN,
        outcome VARCHAR(40) NOT NULL,
        max_high NUMERIC(18,6),
        min_low NUMERIC(18,6),
        directional_move NUMERIC(18,6),
        rule_version VARCHAR(64),
        payload JSONB NOT NULL DEFAULT '{}'::jsonb
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS telegram_signal_messages (
        id BIGSERIAL PRIMARY KEY,
        chat_id BIGINT NOT NULL,
        message_id BIGINT NOT NULL,
        timeframe VARCHAR(5) NOT NULL,
        signal_type VARCHAR(16) NOT NULL DEFAULT 'MANUAL',
        candle_time TIMESTAMPTZ NOT NULL,
        expires_at TIMESTAMPTZ NOT NULL,
        deleted_at TIMESTAMPTZ,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        UNIQUE(chat_id, message_id)
      )
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS idx_telegram_signal_messages_expiry
      ON telegram_signal_messages(expires_at)
      WHERE deleted_at IS NULL
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS signal_alerts (
        id BIGSERIAL PRIMARY KEY,
        analysis_id BIGINT NOT NULL
          REFERENCES analysis_runs(id)
          ON DELETE CASCADE,
        sent_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        chat_id BIGINT,
        alert_type VARCHAR(20) NOT NULL DEFAULT 'AUTOPILOT',
        UNIQUE(analysis_id, chat_id, alert_type)
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS trade_candidates (
        id BIGSERIAL PRIMARY KEY,
        analysis_id BIGINT NOT NULL UNIQUE
          REFERENCES analysis_runs(id)
          ON DELETE CASCADE,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        expires_at TIMESTAMPTZ,
        symbol VARCHAR(24) NOT NULL DEFAULT 'XAUUSD',
        timeframe VARCHAR(5) NOT NULL,
        side VARCHAR(8) NOT NULL,
        strength SMALLINT NOT NULL,
        confirmation_price NUMERIC(18,6) NOT NULL,
        invalidation_price NUMERIC(18,6),
        sl NUMERIC(18,6),
        tp1 NUMERIC(18,6),
        tp2 NUMERIC(18,6),
        tp3 NUMERIC(18,6),
        status VARCHAR(32) NOT NULL DEFAULT 'WAIT_CONFIRMATION',
        payload JSONB NOT NULL DEFAULT '{}'::jsonb
      )
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS idx_trade_candidates_active
      ON trade_candidates(timeframe, side, created_at DESC)
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS mt5_quotes (
        id BIGSERIAL PRIMARY KEY,
        received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        broker_time TIMESTAMPTZ,
        symbol VARCHAR(24) NOT NULL DEFAULT 'XAUUSD',
        bid NUMERIC(18,6) NOT NULL,
        ask NUMERIC(18,6) NOT NULL,
        spread NUMERIC(18,6),
        digits SMALLINT,
        source VARCHAR(32) NOT NULL DEFAULT 'MT5'
      )
    `);

    await client.query(`
      ALTER TABLE mt5_quotes
      ADD COLUMN IF NOT EXISTS source_timezone VARCHAR(64)
      NOT NULL DEFAULT 'UTC'
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS idx_mt5_quotes_latest
      ON mt5_quotes(symbol, received_at DESC)
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS demo_trades (
        id BIGSERIAL PRIMARY KEY,
        candidate_id BIGINT
          REFERENCES trade_candidates(id)
          ON DELETE SET NULL,
        analysis_id BIGINT
          REFERENCES analysis_runs(id)
          ON DELETE SET NULL,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        opened_at TIMESTAMPTZ,
        closed_at TIMESTAMPTZ,
        symbol VARCHAR(24) NOT NULL DEFAULT 'XAUUSD',
        timeframe VARCHAR(5),
        side VARCHAR(8),
        lot NUMERIC(12,4) NOT NULL DEFAULT 0.01,
        planned_price NUMERIC(18,6),
        entry_price NUMERIC(18,6),
        exit_price NUMERIC(18,6),
        sl NUMERIC(18,6),
        tp NUMERIC(18,6),
        tp1 NUMERIC(18,6),
        tp2 NUMERIC(18,6),
        tp3 NUMERIC(18,6),
        profit NUMERIC(18,6),
        status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
        close_reason VARCHAR(40),
        mt5_ticket VARCHAR(64),
        demo_account VARCHAR(64),
        slippage NUMERIC(18,6),
        payload JSONB NOT NULL DEFAULT '{}'::jsonb
      )
    `);

    // Новое правило отмены: активный сценарий без открытой сделки
    // считается сломанным только на уровне планового SL. Сам worker
    // дополнительно требует закрытую свечу соответствующего TF.
    await client.query(`
      UPDATE trade_candidates tc
      SET
        invalidation_price = tc.sl,
        payload = jsonb_set(
          COALESCE(tc.payload, '{}'::jsonb),
          '{cancellation_rule}',
          '"CLOSED_TF_OR_DIRECTION_CHANGE"'::jsonb,
          true
        )
      WHERE tc.status IN(
          'WAIT_CONFIRMATION',
          'CONFIRMED',
          'ACTIVE'
        )
        AND (tc.expires_at IS NULL OR tc.expires_at > NOW())
        AND tc.sl IS NOT NULL
        AND NOT EXISTS (
          SELECT 1
          FROM demo_trades dt
          WHERE dt.candidate_id = tc.id
            AND dt.status = 'OPEN'
        )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS bot_settings (
        key VARCHAR(80) PRIMARY KEY,
        value TEXT NOT NULL,
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )
    `);

    await ensureDemoTradeAlertSchema(client);

    await client.query(`
      CREATE TABLE IF NOT EXISTS demo_worker_state (
        key VARCHAR(80) PRIMARY KEY,
        value JSONB NOT NULL DEFAULT '{}'::jsonb,
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )
    `);

    await client.query("COMMIT");
    console.log("✅ PostgreSQL: структура CLEAN V4.2 готова");

    // Observability only: records why each evaluated bar did or did not become
    // a candidate. Outside the transaction above, and fail-open — a missing
    // diagnostic table must never stop the bot from starting.
    try {
      await ensureRejectionSchema(dbPool);
      const pruned = await pruneRejections(dbPool, CANDIDATE_LOG_RETENTION_DAYS);
      console.log(
        `🔍 CANDIDATE OUTCOME LOG: ready | retention ${CANDIDATE_LOG_RETENTION_DAYS}d | pruned ${pruned}`
      );
    } catch (error) {
      console.warn(
        `⚠️ CANDIDATE OUTCOME LOG unavailable: ${String(error?.message || error).slice(0, 200)}`
      );
    }

    return true;
  } catch (error) {
    await client.query("ROLLBACK").catch(() => {});
    throw error;
  } finally {
    client.release();
  }
}

function ensureDatabaseReady() {
  if (!dbPool) {
    return Promise.resolve(false);
  }

  if (!dbInitPromise) {
    dbInitPromise = initDatabase().catch((error) => {
      dbInitPromise = null;
      console.error("❌ PostgreSQL:", error.message);
      return false;
    });
  }

  return dbInitPromise;
}

async function setSetting(key, value) {
  if (!dbPool || !(await ensureDatabaseReady())) {
    throw new Error("PostgreSQL не подключён");
  }

  await dbPool.query(
    `
      INSERT INTO bot_settings(key, value, updated_at)
      VALUES($1, $2, NOW())
      ON CONFLICT(key)
      DO UPDATE SET
        value = EXCLUDED.value,
        updated_at = NOW()
    `,
    [String(key), String(value)]
  );
}

async function getSetting(key, fallback = null) {
  if (!dbPool || !(await ensureDatabaseReady())) {
    return fallback;
  }

  const result = await dbPool.query(
    `
      SELECT value
      FROM bot_settings
      WHERE key = $1
      LIMIT 1
    `,
    [String(key)]
  );

  return result.rows?.[0]?.value ?? fallback;
}

async function registerTelegramSignalMessage({
  chatId,
  messageId,
  timeframe,
  candleTime,
  signalType = "MANUAL",
}) {
  if (
    !dbPool ||
    !(await ensureDatabaseReady()) ||
    !messageId ||
    !TF_MINUTES[timeframe] ||
    !Number.isFinite(new Date(candleTime).getTime())
  ) {
    return;
  }

  const candleMs = new Date(candleTime).getTime();
  const expiresAt = new Date(
    candleMs + TF_MINUTES[timeframe] * 2 * 60_000
  );

  await dbPool.query(
    `
      INSERT INTO telegram_signal_messages(
        chat_id, message_id, timeframe, signal_type,
        candle_time, expires_at
      )
      VALUES($1,$2,$3,$4,$5,$6)
      ON CONFLICT(chat_id, message_id) DO NOTHING
    `,
    [
      chatId,
      Number(messageId),
      timeframe,
      String(signalType || "MANUAL").toUpperCase(),
      new Date(candleMs),
      expiresAt,
    ]
  );
}

async function deleteExpiredTelegramSignals() {
  if (!dbPool || !(await ensureDatabaseReady())) {
    return;
  }

  const result = await dbPool.query(`
    SELECT id, chat_id, message_id
    FROM telegram_signal_messages
    WHERE deleted_at IS NULL
      AND expires_at <= NOW()
    ORDER BY expires_at ASC
    LIMIT 100
  `);

  for (const row of result.rows || []) {
    try {
      await bot.deleteMessage(row.chat_id, Number(row.message_id));
      console.log(
        `🧹 TELEGRAM SIGNAL EXPIRED | chat=${row.chat_id} message=${row.message_id}`
      );
    } catch (error) {
      console.warn(
        `⚠️ TELEGRAM SIGNAL DELETE | chat=${row.chat_id} message=${row.message_id}: ${String(error?.message || error).slice(0, 180)}`
      );
    }

    await dbPool.query(
      `
        UPDATE telegram_signal_messages
        SET deleted_at = NOW()
        WHERE id = $1
          AND deleted_at IS NULL
      `,
      [row.id]
    );
  }

  await dbPool.query(`
    DELETE FROM telegram_signal_messages
    WHERE deleted_at IS NOT NULL
      AND created_at < NOW() - INTERVAL '7 days'
  `);
}

async function rememberOwnerChat(chatId) {
  if (process.env.TELEGRAM_OWNER_CHAT_ID) {
    return;
  }

  if (!dbPool || !(await ensureDatabaseReady())) {
    return;
  }

  const existing = await getSetting("owner_chat_id", null);
  if (existing) {
    return;
  }

  await setSetting("owner_chat_id", String(chatId)).catch(() => {});
}

async function getOwnerChatId() {
  const fromEnv = Number(process.env.TELEGRAM_OWNER_CHAT_ID || 0);
  if (fromEnv) {
    return fromEnv;
  }

  const stored = Number(await getSetting("owner_chat_id", "0"));
  return stored || 0;
}

async function ownerAllowed(chatId) {
  await rememberOwnerChat(chatId);
  const owner = await getOwnerChatId();
  return !owner || Number(owner) === Number(chatId);
}

async function currentRiskMode() {
  return normalizeRiskMode(
    await getSetting("demo_risk_mode", "MEDIUM")
  );
}

async function setRiskMode(mode) {
  const normalized = normalizeRiskMode(mode);
  if (!RISK_MODES[normalized]) {
    throw new Error("Неизвестный режим");
  }

  await setSetting("demo_risk_mode", normalized);
  return normalized;
}

// ======================================================
// TIME / HELPERS
// ======================================================

function normalizeTimeframe(value) {
  const tf = String(value || "").trim().toUpperCase();
  return TF_MINUTES[tf] ? tf : null;
}

function fmtTime(value) {
  return new Date(value).toLocaleTimeString("ru-RU", {
    timeZone: USER_TIMEZONE,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
}

function fmtDateTime(value) {
  return new Date(value).toLocaleString("ru-RU", {
    timeZone: USER_TIMEZONE,
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
}

function fmtUtc(value) {
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) {
    return "—";
  }
  return date.toISOString().replace(".000Z", "Z");
}

function signedAgeMs(value) {
  const t = new Date(value).getTime();
  return Number.isFinite(t) ? Date.now() - t : Infinity;
}

function formatAgeMs(value) {
  const seconds = Math.max(0, Math.round(Number(value || 0) / 1000));

  if (seconds < 60) {
    return `${seconds} сек`;
  }

  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) {
    return `${minutes} мин`;
  }

  const hours = Math.floor(minutes / 60);
  const restMinutes = minutes % 60;
  return restMinutes ? `${hours} ч ${restMinutes} мин` : `${hours} ч`;
}

function freshnessText(value, maxAgeMs) {
  if (!value) {
    return "❌ нет данных";
  }

  const status = classifyTimestamp(value, { maxAgeMs });
  const when = fmtDateTime(value);

  if (status.reason === "FROM_FUTURE") {
    return `❌ ${when} • время из будущего`;
  }

  if (!Number.isFinite(status.ageMs)) {
    return `❌ ${when} • неверное время`;
  }

  return `${status.ok ? "✅" : "❌"} ${when} • ${formatAgeMs(
    status.ageMs
  )} назад`;
}

function classifyTimestamp(
  value,
  {
    maxAgeMs = Infinity,
    futureToleranceMs = TIME_FUTURE_TOLERANCE_MS,
  } = {}
) {
  const ageMs = signedAgeMs(value);

  if (!Number.isFinite(ageMs)) {
    return { ok: false, reason: "INVALID_TIME", ageMs };
  }

  if (ageMs < -futureToleranceMs) {
    return { ok: false, reason: "FROM_FUTURE", ageMs };
  }

  if (ageMs > maxAgeMs) {
    return { ok: false, reason: "STALE", ageMs };
  }

  return {
    ok: true,
    reason: "OK",
    ageMs: Math.max(0, ageMs),
  };
}

function limitTelegramText(text, limit = 3900) {
  const value = String(text || "");
  if (value.length <= limit) {
    return value;
  }
  return value.slice(0, limit - 30) + "\n… текст сокращён";
}

function marketProbablyClosed(date = new Date()) {
  const day = date.getUTCDay();
  const hour = date.getUTCHours();

  if (day === 6) return true;
  if (day === 0 && hour < 21) return true;
  if (day === 5 && hour >= 21) return true;
  return false;
}

function strengthLotCap(strength) {
  const s = Math.max(0, Math.min(100, Number(strength || 0)));

  if (s < 60) return 0;
  if (s <= 64) return 0.01;
  if (s <= 69) return 0.02;
  if (s <= 74) return 0.03;
  if (s <= 79) return 0.04;
  if (s <= 84) return 0.05;
  if (s <= 89) return 0.06;
  if (s <= 94) return 0.07;
  return 0.08;
}

// ======================================================
// MT5 LIVE QUOTE
// ======================================================

async function getLatestMt5Quote() {
  if (!dbPool || !(await ensureDatabaseReady())) {
    return null;
  }

  const result = await dbPool.query(`
    SELECT
      received_at,
      broker_time,
      symbol,
      bid,
      ask,
      spread,
      digits,
      source_timezone
    FROM mt5_quotes
    WHERE symbol IN('XAUUSD', 'GOLD#')
    ORDER BY received_at DESC
    LIMIT 1
  `);

  const row = result.rows?.[0];
  if (!row) {
    return null;
  }

  const receivedAt = new Date(row.received_at);
  const brokerTime = row.broker_time ? new Date(row.broker_time) : null;

  const receivedStatus = classifyTimestamp(receivedAt, {
    maxAgeMs: MT5_QUOTE_MAX_AGE_MS,
  });

  const brokerStatus = brokerTime
    ? classifyTimestamp(brokerTime, {
        maxAgeMs: Math.max(MT5_QUOTE_MAX_AGE_MS, 120_000),
      })
    : {
        ok: true,
        reason: "NO_BROKER_TIME",
        ageMs: null,
      };

  const bid = Number(row.bid);
  const ask = Number(row.ask);

  return {
    symbol: row.symbol,
    bid,
    ask,
    spread: Number(row.spread) || ask - bid,
    digits: Number(row.digits) || 2,
    receivedAt,
    brokerTime,
    sourceTimezone: row.source_timezone || MT5_API_TIMEZONE,
    ageMs: receivedStatus.ageMs,
    brokerAgeMs: brokerStatus.ageMs,
    timeStatus: receivedStatus.ok
      ? brokerStatus.reason
      : receivedStatus.reason,
    fresh: receivedStatus.ok && brokerStatus.ok,
  };
}

// ======================================================
// CANDLES — STRICT CLOSED TF
// ======================================================

function normalizeM1(raw) {
  const now = Date.now() - CLOSED_CANDLE_SAFETY_MS;

  return (raw || [])
    .map((candle) => ({
      time: Number(candle.time ?? candle.timestamp),
      open: Number(candle.open),
      high: Number(candle.high),
      low: Number(candle.low),
      close: Number(candle.close),
      volume: Number(candle.volume || 0),
    }))
    .filter(
      (candle) =>
        Number.isFinite(candle.time) &&
        [candle.open, candle.high, candle.low, candle.close].every(
          Number.isFinite
        ) &&
        candle.time + 60_000 <= now
    )
    .sort((a, b) => a.time - b.time);
}

function aggregateClosed(m1, minutes) {
  if (minutes === 1) {
    return m1;
  }

  const bucketMs = minutes * 60_000;
  const now = Date.now() - CLOSED_CANDLE_SAFETY_MS;
  const map = new Map();

  for (const candle of m1) {
    const bucket = Math.floor(candle.time / bucketMs) * bucketMs;

    if (bucket + bucketMs > now) {
      continue;
    }

    const current = map.get(bucket);

    if (!current) {
      map.set(bucket, {
        time: bucket,
        open: candle.open,
        high: candle.high,
        low: candle.low,
        close: candle.close,
        volume: candle.volume || 0,
      });
    } else {
      current.high = Math.max(current.high, candle.high);
      current.low = Math.min(current.low, candle.low);
      current.close = candle.close;
      current.volume += candle.volume || 0;
    }
  }

  return [...map.values()].sort((a, b) => a.time - b.time);
}

async function saveM1CandlesToDb(candles) {
  if (!dbPool || !candles?.length || !(await ensureDatabaseReady())) {
    return 0;
  }

  const maxResult = await dbPool.query(`
    SELECT MAX(candle_time) AS max_time
    FROM xauusd_candles
    WHERE timeframe = 'M1'
  `);

  const maxTime = maxResult.rows?.[0]?.max_time
    ? new Date(maxResult.rows[0].max_time).getTime()
    : -Infinity;

  const fresh = candles.filter((candle) => candle.time > maxTime);
  if (!fresh.length) {
    return 0;
  }

  let inserted = 0;

  for (const candle of fresh) {
    const result = await dbPool.query(
      `
        INSERT INTO xauusd_candles(
          timeframe,
          candle_time,
          open,
          high,
          low,
          close,
          volume,
          source,
          source_timezone
        )
        VALUES('M1',$1,$2,$3,$4,$5,$6,'live','UTC')
        ON CONFLICT(timeframe, candle_time)
        DO NOTHING
      `,
      [
        new Date(candle.time),
        candle.open,
        candle.high,
        candle.low,
        candle.close,
        candle.volume || 0,
      ]
    );

    inserted += result.rowCount || 0;
  }

  return inserted;
}

async function buildTimeframes(forceRefresh = false) {
  const raw = await loadLiveM1(forceRefresh);
  const m1 = normalizeM1(raw);

  if (m1.length < 60) {
    throw new Error(`Недостаточно закрытых M1 свечей: ${m1.length}`);
  }

  const lastM1 = m1.at(-1);
  const lastM1Close = new Date(lastM1.time + 60_000);
  const m1TimeStatus = classifyTimestamp(lastM1Close, {
    maxAgeMs: M1_MAX_AGE_MS,
  });

  if (!m1TimeStatus.ok) {
    throw new Error(
      `TIME GUARD: M1 ${m1TimeStatus.reason}. ` +
        `Закрытие UTC=${fmtUtc(lastM1Close)}, ` +
        `Ташкент=${fmtDateTime(lastM1Close)}. ` +
        `Новый сигнал заблокирован.`
    );
  }

  saveM1CandlesToDb(m1).catch((error) => {
    console.error("⚠️ Candle DB:", error.message);
  });

  return {
    M1: m1,
    M5: aggregateClosed(m1, 5),
    M15: aggregateClosed(m1, 15),
    M30: aggregateClosed(m1, 30),
    H1: aggregateClosed(m1, 60),
  };
}

// ======================================================
// INDICATORS
// ======================================================

function ema(values, period) {
  if (!values.length) {
    return [];
  }

  const k = 2 / (period + 1);
  const out = [values[0]];

  for (let i = 1; i < values.length; i++) {
    out.push(values[i] * k + out[i - 1] * (1 - k));
  }

  return out;
}

function calculateRSI(closes, period = 14) {
  if (closes.length < period + 1) {
    return 50;
  }

  let gains = 0;
  let losses = 0;

  for (let i = closes.length - period; i < closes.length; i++) {
    const delta = closes[i] - closes[i - 1];
    if (delta > 0) {
      gains += delta;
    } else {
      losses += -delta;
    }
  }

  const avgGain = gains / period;
  const avgLoss = losses / period;

  if (avgLoss === 0) {
    return avgGain > 0 ? 100 : 50;
  }

  const rs = avgGain / avgLoss;
  return 100 - 100 / (1 + rs);
}

function calculateATR(candles, period = 14) {
  if (candles.length < 2) {
    return 0;
  }

  const ranges = [];

  for (let i = 1; i < candles.length; i++) {
    const current = candles[i];
    const previous = candles[i - 1];

    ranges.push(
      Math.max(
        current.high - current.low,
        Math.abs(current.high - previous.close),
        Math.abs(current.low - previous.close)
      )
    );
  }

  const recent = ranges.slice(-period);
  return (
    recent.reduce((a, b) => a + b, 0) /
    Math.max(recent.length, 1)
  );
}

function finalizeAnalysis(analysis) {
  const score = Math.max(
    -100,
    Math.min(100, Number(analysis.score || 0))
  );

  const direction = score >= 0 ? "BUY" : "SELL";
  const strength = Math.max(
    20,
    Math.min(100, Math.abs(Math.round(score)))
  );

  return {
    ...analysis,
    score,
    direction,
    strength,
    action: strength >= SIGNAL_THRESHOLD ? direction : "WAIT",
  };
}

function baseAnalyze(candles) {
  const closes = candles.map((candle) => candle.close);
  const e9 = ema(closes, 9);
  const e21 = ema(closes, 21);
  const price = closes.at(-1);

  const previousPrice =
    closes[Math.max(0, closes.length - 6)];

  const momentum = price - previousPrice;
  const trend = e9.at(-1) - e21.at(-1);
  const rsi = calculateRSI(closes);
  const atr = calculateATR(candles);
  const last = candles.at(-1);

  let score = 0;
  score += trend > 0 ? 30 : -30;
  score += momentum > 0 ? 25 : -25;

  if (rsi >= 52) {
    score += 20;
  } else if (rsi <= 48) {
    score -= 20;
  }

  score += last.close >= last.open ? 15 : -15;

  return finalizeAnalysis({
    price,
    score,
    rsi,
    atr,
    trend,
    momentum,
  });
}

// ======================================================
// NEWS
// ======================================================

let newsCache = {
  data: [],
  updatedAt: 0,
};

let newsRefreshPromise = null;

async function refreshNewsCache() {
  if (!newsRefreshPromise) {
    newsRefreshPromise = (async () => {
      try {
        const items = await getGoldNewsSnapshot();
        newsCache = {
          data: Array.isArray(items) ? items : [],
          updatedAt: Date.now(),
        };
      } catch (error) {
        console.warn("⚠️ NEWS:", error.message);
      }

      return newsCache.data;
    })().finally(() => {
      newsRefreshPromise = null;
    });
  }

  return newsRefreshPromise;
}

async function loadNews(forceRefresh = false) {
  if (
    !forceRefresh &&
    newsCache.data.length &&
    Date.now() - newsCache.updatedAt < NEWS_CACHE_MS
  ) {
    return newsCache.data;
  }

  // Уже загруженные новости не должны задерживать ручной график.
  // Возвращаем последний снимок сразу, а обновление выполняем в фоне.
  if (!forceRefresh && newsCache.data.length) {
    refreshNewsCache().catch(() => {});
    return newsCache.data;
  }

  // При первом запуске снимка ещё нет, поэтому один раз ждём загрузку.
  return refreshNewsCache();
}

function newsTimestamp(item) {
  const raw = item?.timestamp ?? item?.publishedAt ?? item?.date ?? 0;

  if (typeof raw === "number") {
    return raw < 10_000_000_000 ? raw * 1000 : raw;
  }

  const t = Date.parse(raw);
  return Number.isFinite(t) ? t : 0;
}

function newsForTimeframe(items, timeframe) {
  const maxAge = NEWS_MAX_AGE_MINUTES[timeframe] || 60;
  const now = Date.now();

  return (items || [])
    .filter((item) => {
      if (item?.tradeRelevant === false) {
        return false;
      }

      const t = newsTimestamp(item);
      if (!t) {
        return false;
      }

      const age = now - t;
      if (age < -NEWS_FUTURE_TOLERANCE_MS) {
        return false;
      }

      return (
        age >= -NEWS_FUTURE_TOLERANCE_MS &&
        age <= maxAge * 60_000
      );
    })
    .sort((a, b) => newsTimestamp(b) - newsTimestamp(a));
}

function calculateNewsPressure(items, timeframe) {
  const filtered = newsForTimeframe(items, timeframe);

  if (!filtered.length) {
    return {
      direction: "NEUTRAL",
      strength: 0,
      risk: 0,
      count: 0,
      strongest: 0,
    };
  }

  const maxAge = NEWS_MAX_AGE_MINUTES[timeframe] || 60;
  const now = Date.now();

  let signedSum = 0;
  let totalWeight = 0;
  let riskSum = 0;
  let strongest = 0;

  for (const item of filtered) {
    const impact = Math.max(
      0,
      Math.min(100, Number(item?.impact || 0))
    );

    const ageMinutes = Math.max(
      0,
      (now - newsTimestamp(item)) / 60_000
    );

    const freshness = Math.max(
      0.15,
      1 - ageMinutes / Math.max(maxAge, 1)
    );

    const weight = Math.max(1, impact * freshness);
    const direction = String(item?.goldDirection || "UNKNOWN").toUpperCase();
    const sign = direction === "UP" ? 1 : direction === "DOWN" ? -1 : 0;

    signedSum += sign * weight;
    totalWeight += weight;
    riskSum += impact;
    strongest = Math.max(strongest, impact);
  }

  const normalized = totalWeight
    ? (signedSum / totalWeight) * 100
    : 0;

  return {
    direction:
      normalized > 10
        ? "UP"
        : normalized < -10
        ? "DOWN"
        : "NEUTRAL",
    strength: Math.min(100, Math.round(Math.abs(normalized))),
    risk: Math.min(100, Math.round(riskSum / filtered.length)),
    count: filtered.length,
    strongest,
  };
}

function applyNews(analysis, pressure) {
  let adjustment = 0;

  if (pressure.direction === "UP") {
    adjustment = Math.round(pressure.strength * 0.15);
  }

  if (pressure.direction === "DOWN") {
    adjustment = -Math.round(pressure.strength * 0.15);
  }

  adjustment = Math.max(-15, Math.min(15, adjustment));

  return finalizeAnalysis({
    ...analysis,
    preNewsScore: analysis.score,
    newsAdjustment: adjustment,
    score: analysis.score + adjustment,
    newsPressure: pressure,
  });
}

// ======================================================
// CFTC
// ======================================================

async function loadCftc() {
  try {
    return await getCftcGoldSnapshot();
  } catch (error) {
    console.warn("⚠️ CFTC:", error.message);
    return null;
  }
}

function applyCftc(analysis, snapshot, timeframe) {
  const direction = snapshot?.bias?.direction || "NEUTRAL";

  const weightMap = {
    M1: 0,
    M5: 1,
    M15: 3,
    M30: 5,
    H1: 7,
  };

  const weight = weightMap[timeframe] || 0;
  let adjustment = 0;

  if (direction === "UP") adjustment = weight;
  if (direction === "DOWN") adjustment = -weight;

  return finalizeAnalysis({
    ...analysis,
    preCftcScore: analysis.score,
    cftcAdjustment: adjustment,
    cftcDirection: direction,
    score: analysis.score + adjustment,
  });
}

// ======================================================
// AI H1
// ======================================================

function aiFileExists(file) {
  try {
    return fs.existsSync(file);
  } catch {
    return false;
  }
}

async function runAiH1(m1Candles) {
  if (
    !aiFileExists(AI_H1_MODEL_PATH) ||
    !aiFileExists(AI_H1_SCRIPT_PATH) ||
    !Array.isArray(m1Candles) ||
    m1Candles.length < 2400
  ) {
    return null;
  }

  const lastTimestamp = m1Candles.at(-1)?.time;

  if (
    aiH1Cache.data &&
    aiH1Cache.lastTimestamp === lastTimestamp &&
    Date.now() - aiH1Cache.updatedAt < 5 * 60_000
  ) {
    return aiH1Cache.data;
  }

  const tempFile = path.join(
    os.tmpdir(),
    `xau_ai_${process.pid}_${Date.now()}.json`
  );

  fs.writeFileSync(
    tempFile,
    JSON.stringify(
      m1Candles.slice(-7000).map((candle) => ({
        timestamp: candle.time,
        open: candle.open,
        high: candle.high,
        low: candle.low,
        close: candle.close,
        volume: candle.volume || 0,
      }))
    ),
    "utf8"
  );

  try {
    const { stdout } = await execFileAsync(
      AI_PYTHON,
      [
        AI_H1_SCRIPT_PATH,
        "--model",
        AI_H1_MODEL_PATH,
        "--candles",
        tempFile,
      ],
      {
        timeout: AI_H1_TIMEOUT_MS,
        maxBuffer: 2 * 1024 * 1024,
        env: {
          ...process.env,
          PYTHONUNBUFFERED: "1",
        },
      }
    );

    const lines = String(stdout || "")
      .trim()
      .split(/\r?\n/)
      .filter(Boolean);

    if (!lines.length) {
      return null;
    }

    const result = JSON.parse(lines.at(-1));
    if (result?.ok !== true) {
      return null;
    }

    aiH1Cache = {
      lastTimestamp,
      data: result,
      updatedAt: Date.now(),
    };

    return result;
  } catch (error) {
    console.warn("⚠️ AI H1:", error.message);
    return null;
  } finally {
    fs.unlink(tempFile, () => {});
  }
}

async function getAiH1Status() {
  if (!aiFileExists(AI_H1_MODEL_PATH)) {
    throw new Error("AI H1 model не найден");
  }

  if (!aiFileExists(AI_H1_SCRIPT_PATH)) {
    throw new Error("ai_predict_h1.py не найден");
  }

  const { stdout } = await execFileAsync(
    AI_PYTHON,
    [AI_H1_SCRIPT_PATH, "--model", AI_H1_MODEL_PATH, "--status"],
    {
      timeout: AI_H1_TIMEOUT_MS,
      maxBuffer: 1024 * 1024,
      env: {
        ...process.env,
        PYTHONUNBUFFERED: "1",
      },
    }
  );

  const lines = String(stdout || "")
    .trim()
    .split(/\r?\n/)
    .filter(Boolean);

  if (!lines.length) {
    throw new Error("AI H1 status пуст");
  }

  return JSON.parse(lines.at(-1));
}

function applyAiH1(analysis, ai) {
  if (!analysis || !ai) {
    return analysis;
  }

  const confidence = Math.max(
    0,
    Math.min(1, Number(ai.confidence || 0))
  );

  let adjustment = 0;

  if (ai.action === "BUY") {
    adjustment = Math.round(9 + confidence * 5);
  }

  if (ai.action === "SELL") {
    adjustment = -Math.round(9 + confidence * 5);
  }

  return finalizeAnalysis({
    ...analysis,
    preAiScore: analysis.score,
    aiAdjustment: adjustment,
    aiPrediction: ai,
    aiAction: ai.action,
    aiConfidence: confidence,
    score: analysis.score + adjustment,
  });
}

// ======================================================
// FULL ANALYSIS
// ======================================================

async function buildAnalyses(all, news, cftc) {
  const analyses = {};
  const pressures = {};
  let geminiNewsReview = null;

  try {
    // Один кэшируемый Google-поиск используется всеми TF. Это не создаёт
    // пять отдельных платных запросов и сохраняет единый новостной контекст.
    geminiNewsReview = await getGeminiNewsReview(news);
  } catch (error) {
    console.warn("⚠️ GEMINI NEWS ANALYSIS:", error.message);
    geminiNewsReview = { status: "error", signal: null };
  }

  for (const timeframe of TF_ORDER) {
    const candles = all[timeframe];

    if (!candles || candles.length < MIN_CANDLES) {
      analyses[timeframe] = null;
      pressures[timeframe] = mergeNewsPressure(
        calculateNewsPressure(news, timeframe),
        geminiNewsReview,
        timeframe
      );
      continue;
    }

    const pressure = mergeNewsPressure(
      calculateNewsPressure(news, timeframe),
      geminiNewsReview,
      timeframe
    );
    pressures[timeframe] = pressure;

    let analysis = baseAnalyze(candles);
    analysis = applyNews(analysis, pressure);
    analysis = applyCftc(analysis, cftc, timeframe);
    analyses[timeframe] = analysis;
  }

  if (analyses.H1) {
    const ai = await runAiH1(all.M1);
    analyses.H1 = applyAiH1(analyses.H1, ai);
  }

  return { analyses, pressures, geminiNewsReview };
}

// ======================================================
// TRADE PLAN / FORECAST
// ======================================================

function buildTradePlan(
  analysis,
  timeframe,
  mt5Quote = null,
  candles = []
) {
  const price = Number(analysis.price);
  const atr = Math.max(
    Number(analysis.atr || 0),
    price * 0.00015
  );

  const side = analysis.direction;
  const direction = side === "BUY" ? 1 : -1;

  const brokerPrice = mt5Quote?.fresh
    ? side === "BUY"
      ? mt5Quote.ask
      : mt5Quote.bid
    : price;

  const basePrice = Number.isFinite(Number(brokerPrice))
    ? Number(brokerPrice)
    : price;

  // Вход/SL/TP остаются такими же, как в V4.2.
  // Отмена теперь совпадает с плановым SL и подтверждается только
  // закрытой свечой соответствующего TF либо сменой направления.
  const confirmation = basePrice + direction * atr * 0.18;
  const sl = basePrice - direction * atr * 0.72;
  const invalidation = sl;
  const tp1 = basePrice + direction * atr * 0.5;
  const tp2 = basePrice + direction * atr * 0.9;
  const tp3 = basePrice + direction * atr * 1.35;

  // ====================================================
  // NATURAL FORECAST V4.3
  // Центральная линия НЕ тянется искусственно к TP3.
  // Она строится из силы + тренда + momentum + ритма
  // последних свечей и ATR, а затем получает небольшие
  // естественные откаты. Никакого Math.random().
  // ====================================================
  const recent = Array.isArray(candles)
    ? candles.slice(-24)
    : [];

  const deltas = [];
  for (let i = 1; i < recent.length; i++) {
    const a = Number(recent[i - 1]?.close);
    const b = Number(recent[i]?.close);
    if (Number.isFinite(a) && Number.isFinite(b)) {
      deltas.push(b - a);
    }
  }

  const rmsDelta = deltas.length
    ? Math.sqrt(
        deltas.reduce((sum, d) => sum + d * d, 0) /
          deltas.length
      )
    : atr * 0.15;

  const alignment = deltas.length
    ? deltas
        .slice(-10)
        .reduce(
          (sum, d) =>
            sum + Math.sign(d || 0) * direction,
          0
        ) / Math.min(10, deltas.length)
    : 0;

  const clamp = (value, min, max) =>
    Math.max(min, Math.min(max, value));

  const strengthFactor = clamp(
    Number(analysis.strength || 0) / 100,
    0,
    1
  );

  const momentumFactor = clamp(
    (direction * Number(analysis.momentum || 0)) /
      Math.max(atr, 1e-9),
    -1,
    1
  );

  const trendFactor = clamp(
    (direction * Number(analysis.trend || 0)) /
      Math.max(atr, 1e-9),
    -1,
    1
  );

  const volatilityFactor = clamp(
    rmsDelta / Math.max(atr, 1e-9),
    0,
    1.25
  );

  const actionMultiplier =
    analysis.action === "WAIT" ? 0.20 : 1;

  // Итоговый направленный ход в ATR.
  // Сильный сигнал даёт более выраженный дрейф,
  // но линия не обязана достигать TP2/TP3.
  const driftAtr = clamp(
    0.22 +
      0.36 * strengthFactor +
      0.08 * momentumFactor +
      0.06 * trendFactor +
      0.04 * alignment,
    0.18,
    0.78
  );

  const horizon = timeframe === "H1" ? 60 : 15;
  const pointCount = 31;
  const forecast = [];

  for (let i = 0; i < pointCount; i++) {
    const progress = i / (pointCount - 1);
    const minute = progress * horizon;

    // Немного быстрее в начале, затем плавнее.
    const eased = Math.pow(progress, 0.88);

    // Волнообразные откаты, которые равны нулю
    // в начале и в конце. Это визуализирует
    // естественное движение, а не "линейку".
    const envelope = Math.sin(Math.PI * progress);
    const wave =
      atr *
      (0.035 + 0.045 * volatilityFactor) *
      envelope *
      (
        Math.sin(progress * Math.PI * 4) +
        0.32 * Math.sin(progress * Math.PI * 7)
      );

    const directionalMove =
      direction *
      atr *
      driftAtr *
      eased *
      actionMultiplier;

    const center = price + directionalMove + wave;

    // Коридор расширяется со временем и зависит
    // от текущей волатильности и силы сигнала.
    const uncertainty =
      atr *
      (
        0.045 +
        (
          0.13 +
          0.08 * (1 - strengthFactor) +
          0.05 * volatilityFactor
        ) *
          Math.sqrt(progress)
      );

    forecast.push({
      minute,
      center,
      low: center - uncertainty,
      high: center + uncertainty,
    });
  }

  function forecastAt(minute) {
    return forecast.reduce(
      (best, point) =>
        Math.abs(point.minute - minute) <
        Math.abs(best.minute - minute)
          ? point
          : best,
      forecast[0]
    );
  }

  return {
    entry: basePrice,
    confirmation,
    invalidation,
    sl,
    tp1,
    tp2,
    tp3,
    lotCap: strengthLotCap(analysis.strength),
    forecast,
    horizon,
    p5: forecastAt(Math.min(5, horizon)),
    p10: forecastAt(Math.min(10, horizon)),
    p15: forecastAt(Math.min(15, horizon)),
  };
}

// ======================================================
// POSTGRES — SAVE ANALYSIS / CANDIDATE
// ======================================================

async function saveAnalysisRun({
  timeframe,
  candles,
  analysis,
  plan,
  source,
}) {
  if (!dbPool || !(await ensureDatabaseReady())) {
    return null;
  }

  const candle = candles.at(-1);

  const entryStatus =
    analysis.action === "WAIT" ||
    analysis.strength < TRADE_MIN_STRENGTH
      ? "NO_TRADE"
      : "WAIT_CONFIRMATION";

  const payload = {
    signal_symbol: SIGNAL_SYMBOL,
    broker_symbol_hint: BROKER_SYMBOL_HINT,
    lot_cap: plan.lotCap,
    signal_threshold: SIGNAL_THRESHOLD,
    trade_min_strength: TRADE_MIN_STRENGTH,
    news: analysis.newsPressure || null,
    news_adjustment: analysis.newsAdjustment || 0,
    cftc_adjustment: analysis.cftcAdjustment || 0,
    ai_adjustment: analysis.aiAdjustment || 0,
    ai: analysis.aiPrediction || null,
  };

  const result = await dbPool.query(
    `
      INSERT INTO analysis_runs(
        candle_time,
        timeframe,
        source,
        action,
        direction,
        strength,
        analysis_price,
        rsi,
        atr,
        score,
        news_direction,
        news_strength,
        cftc_direction,
        ai_action,
        ai_confidence,
        confirmation_price,
        invalidation_price,
        sl,
        tp1,
        tp2,
        tp3,
        entry_status,
        model_version,
        payload
      )
      VALUES(
        $1,$2,$3,$4,$5,$6,$7,$8,
        $9,$10,$11,$12,$13,$14,$15,
        $16,$17,$18,$19,$20,$21,$22,
        $23,$24::jsonb
      )
      RETURNING id, analyzed_at
    `,
    [
      new Date(candle.time),
      timeframe,
      source,
      analysis.action,
      analysis.direction,
      analysis.strength,
      analysis.price,
      analysis.rsi,
      analysis.atr,
      analysis.score,
      analysis.newsPressure?.direction || "NEUTRAL",
      analysis.newsPressure?.strength || 0,
      analysis.cftcDirection || "NEUTRAL",
      analysis.aiAction || null,
      analysis.aiConfidence ?? null,
      plan.confirmation,
      plan.invalidation,
      plan.sl,
      plan.tp1,
      plan.tp2,
      plan.tp3,
      entryStatus,
      MODEL_VERSION,
      JSON.stringify(payload),
    ]
  );

  return result.rows?.[0] || null;
}

async function findRecentActiveCandidate(timeframe, side) {
  if (!dbPool || !(await ensureDatabaseReady())) {
    return null;
  }

  const result = await dbPool.query(
    `
      SELECT id, created_at, expires_at, status
      FROM trade_candidates
      WHERE symbol = 'XAUUSD'
        AND timeframe = $1
        AND side = $2
        AND status IN('WAIT_CONFIRMATION','CONFIRMED','ACTIVE')
        AND (expires_at IS NULL OR expires_at > NOW())
      ORDER BY created_at DESC
      LIMIT 1
    `,
    [timeframe, side]
  );

  return result.rows?.[0] || null;
}

async function saveTradeCandidate(
  analysisId,
  timeframe,
  analysis,
  plan
) {
  // Same conditions, same order, same short-circuit as before: ensureDatabaseReady
  // still runs only when a pool exists. Pulled into one value so the outcome can
  // be described without asking twice.
  const dbReady = Boolean(dbPool) && Boolean(await ensureDatabaseReady());

  // Observability only. Never decides anything, never throws: the log call
  // swallows its own errors, and the whole thing is wrapped again here so a
  // diagnostic can never cost a trade.
  const logOutcome = async (hasExistingCandidate) => {
    if (!dbReady) return;
    try {
      const classification = classifyCandidateOutcome({
        dbReady,
        analysisId,
        timeframe,
        tradedTimeframes: TRADE_TFS,
        analysis,
        minStrength: TRADE_MIN_STRENGTH,
        signalThreshold: SIGNAL_THRESHOLD,
        hasExistingCandidate,
      });
      await recordCandidateOutcome(dbPool, classification, {
        candleTime: analysis?.candleTime || null,
        detail: {
          news_adjustment: analysis?.newsAdjustment ?? null,
          cftc_adjustment: analysis?.cftcAdjustment ?? null,
          ai_adjustment: analysis?.aiAdjustment ?? null,
        },
      });
    } catch {
      // Already logged inside recordCandidateOutcome; nothing to do here.
    }
  };

  if (
    !dbReady ||
    !analysisId ||
    !TRADE_TFS.has(timeframe) ||
    analysis.action === "WAIT" ||
    analysis.strength < TRADE_MIN_STRENGTH
  ) {
    await logOutcome(false);
    return null;
  }

  const existing = await findRecentActiveCandidate(
    timeframe,
    analysis.direction
  );

  if (existing) {
    await logOutcome(true);
    return Number(existing.id);
  }

  await logOutcome(false);

  const lifetime = CANDIDATE_LIFETIME_MINUTES[timeframe] || 30;
  const expiresAt = new Date(Date.now() + lifetime * 60_000);

  const payload = {
    signal_symbol: SIGNAL_SYMBOL,
    broker_symbol_hint: BROKER_SYMBOL_HINT,
    lot_cap: plan.lotCap,
    max_positions: 5,
    initial_positions: 2,
    max_additions: 3,
    strength: analysis.strength,
    source_model: MODEL_VERSION,
    cancellation_rule: "CLOSED_TF_OR_DIRECTION_CHANGE",
    cancellation_timeframe: timeframe,
    note:
      "Risk manager in DEMO bot must reduce volume/slots if account or free margin is insufficient.",
  };

  const result = await dbPool.query(
    `
      INSERT INTO trade_candidates(
        analysis_id,
        expires_at,
        symbol,
        timeframe,
        side,
        strength,
        confirmation_price,
        invalidation_price,
        sl,
        tp1,
        tp2,
        tp3,
        status,
        payload
      )
      VALUES(
        $1,$2,'XAUUSD',$3,$4,$5,
        $6,$7,$8,$9,$10,$11,
        'WAIT_CONFIRMATION',$12::jsonb
      )
      ON CONFLICT(analysis_id)
      DO NOTHING
      RETURNING id
    `,
    [
      analysisId,
      expiresAt,
      timeframe,
      analysis.direction,
      analysis.strength,
      plan.confirmation,
      plan.invalidation,
      plan.sl,
      plan.tp1,
      plan.tp2,
      plan.tp3,
      JSON.stringify(payload),
    ]
  );

  return result.rows?.[0]?.id || null;
}

async function saveSignalAlert(analysisId, chatId, alertType) {
  if (!dbPool || !(await ensureDatabaseReady()) || !analysisId) {
    return;
  }

  await dbPool.query(
    `
      INSERT INTO signal_alerts(
        analysis_id,
        chat_id,
        alert_type
      )
      VALUES($1,$2,$3)
      ON CONFLICT DO NOTHING
    `,
    [analysisId, chatId, alertType]
  );
}

// ======================================================
// MARKET SNAPSHOT / PREPARE ANALYSIS
// ======================================================

async function prepareMarketSnapshot(forceRefresh = false) {
  const [all, news, cftc, mt5Quote] = await Promise.all([
    buildTimeframes(forceRefresh),
    loadNews(forceRefresh),
    loadCftc(),
    getLatestMt5Quote().catch(() => null),
  ]);

  const built = await buildAnalyses(all, news, cftc);

  return {
    all,
    news,
    cftc,
    mt5Quote,
    analyses: built.analyses,
    pressures: built.pressures,
  };
}

async function prepareAnalysis(
  timeframe,
  source = "manual",
  snapshot = null
) {
  const tf = normalizeTimeframe(timeframe);

  if (!tf) {
    throw new Error(`Неизвестный таймфрейм: ${timeframe}`);
  }

  const market = snapshot || (await prepareMarketSnapshot(false));
  const candles = market.all[tf];
  const analysis = market.analyses[tf];

  if (!candles || candles.length < MIN_CANDLES || !analysis) {
    throw new Error(
      `Недостаточно закрытых свечей для ${tf}: ${candles?.length || 0}`
    );
  }

  const candle = candles.at(-1);
  const plan = buildTradePlan(analysis, tf, market.mt5Quote, candles);

  const saved = await saveAnalysisRun({
    timeframe: tf,
    candles,
    analysis,
    plan,
    source,
  });

  let candidateId = null;

  if (saved?.id) {
    candidateId = await saveTradeCandidate(
      saved.id,
      tf,
      analysis,
      plan
    ).catch((error) => {
      console.error("⚠️ Candidate:", error.message);
      return null;
    });
  }

  return {
    timeframe: tf,
    market,
    candles,
    candle,
    analysis,
    plan,
    analysisId: saved?.id || null,
    candidateId,
    analyzedAt: saved?.analyzed_at
      ? new Date(saved.analyzed_at)
      : new Date(),
  };
}

// ======================================================
// SIGNAL TEXT
// ======================================================

function tfLine(timeframe, analysis) {
  if (!analysis) {
    return `${timeframe.padEnd(3)} : —`;
  }

  const icon =
    analysis.action === "BUY"
      ? "🟢"
      : analysis.action === "SELL"
      ? "🔴"
      : "⚪";

  return `${timeframe.padEnd(3)} : ${icon} ${analysis.action} | ${analysis.strength}/100`;
}

function buildSignalText({
  timeframe,
  analyses,
  analysis,
  plan,
  analyzedAt,
  candle,
  mt5Quote,
}) {
  const icon =
    analysis.action === "BUY"
      ? "🟢"
      : analysis.action === "SELL"
      ? "🔴"
      : "⚪";

  const condition =
    analysis.direction === "BUY"
      ? `ASK > ${plan.confirmation.toFixed(2)}`
      : `BID < ${plan.confirmation.toFixed(2)}`;

  const cancellationCondition =
    analysis.direction === "BUY"
      ? `только закрытая свеча ${timeframe} < ${plan.invalidation.toFixed(
          2
        )}`
      : `только закрытая свеча ${timeframe} > ${plan.invalidation.toFixed(
          2
        )}`;

  const mt5Block = mt5Quote?.fresh
    ? `📡 MT5 LIVE (${mt5Quote.symbol})\nBID: ${mt5Quote.bid.toFixed(
        mt5Quote.digits
      )}\nASK: ${mt5Quote.ask.toFixed(
        mt5Quote.digits
      )}\nSpread: ${mt5Quote.spread.toFixed(mt5Quote.digits)}`
    : "📡 MT5 LIVE: свежая котировка пока не получена";

  const news = analysis.newsPressure || {};

  const newsIcon =
    news.direction === "UP"
      ? "🟢⬆️"
      : news.direction === "DOWN"
      ? "🔴⬇️"
      : "⚪↔️";

  const googleNewsBlock = news.googleAvailable
    ? `\n🤖 Google Search: ${newsDirectionIcon(
        news.googleDirection
      )} ${news.googleDirection} • ${news.googleConfidence || 0}/100\nОфициальных источников: ${
        news.googleOfficialSources || 0
      } • Согласование: ${consensusLabel(
        news.newsConsensus || "PRIMARY_ONLY"
      )}`
    : "";

  const tfBlock = TF_ORDER.map((tf) =>
    tfLine(tf, analyses[tf])
  ).join("\n");

  const status =
    analysis.action === "WAIT"
      ? "⏳ СЕЙЧАС НЕ ВХОДИТЬ"
      : "🟡 ЖДАТЬ ПОДТВЕРЖДЕНИЯ";

  const tradeBlock =
    analysis.action === "WAIT"
      ? `Причина:\nсила ниже ${SIGNAL_THRESHOLD}/100 или после фильтров нет безопасного направления.`
      : `✅ Условие входа:\n${condition}\n\n❌ Отмена сценария:\n${cancellationCondition}\nили свежий ${timeframe} сменился на противоположное направление/WAIT\n\n🛡 SL:\n${plan.sl.toFixed(
          2
        )}\n\n🎯 TP1:\n${plan.tp1.toFixed(
          2
        )}\n\n🎯 TP2:\n${plan.tp2.toFixed(
          2
        )}\n\n🎯 TP3:\n${plan.tp3.toFixed(
          2
        )}\n\n📦 Верхний лимит лота по силе:\n${plan.lotCap.toFixed(
          2
        )}\n(реальный объём DEMO-бот уменьшает по balance/equity/free margin/риску)`;

  return `${icon} XAU/USD — ${analysis.action} • ${timeframe}

${status}

🕒 Анализ сделан:
${fmtDateTime(analyzedAt)}

🕯 Последняя ЗАКРЫТАЯ свеча ${timeframe}:
${fmtTime(candle.time)}

💰 Цена анализа:
${analysis.price.toFixed(2)}

${mt5Block}

📊 Сила направления:
${analysis.strength}/100

${tfBlock}

🌍 Новости ${timeframe}:
${newsIcon} ${news.direction || "NEUTRAL"} • ${news.strength || 0}/100
Учтено свежих событий: ${news.count || 0}
Макс. влияние: ${news.strongest || 0}/100
${googleNewsBlock}

📊 CFTC:
${analysis.cftcDirection || "NEUTRAL"} • недельный фон

${
    analysis.aiAction
      ? `🧠 AI H1: ${analysis.aiAction} • ${(
          Number(analysis.aiConfidence || 0) * 100
        ).toFixed(1)}%`
      : ""
  }

${tradeBlock}

🔮 Прогнозный коридор:
5м  → ${plan.p5.low.toFixed(2)} – ${plan.p5.high.toFixed(2)}
10м → ${plan.p10.low.toFixed(2)} – ${plan.p10.high.toFixed(2)}
15м → ${plan.p15.low.toFixed(2)} – ${plan.p15.high.toFixed(2)}

ℹ️ ${analysis.strength}/100 — сила направления, не вероятность выигрыша.

⚠️ Вероятностный анализ, не гарантия результата.`;
}

// ======================================================
// GRAPH
// ======================================================

function escapeSvg(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function createSVG({
  candles,
  analysis,
  plan,
  timeframe,
  analyzedAt,
  candle,
  mt5Quote,
}) {
  const WIDTH = 1440;
  const HEIGHT = 900;
  const LEFT = 58;
  const TOP = 170;
  const BOTTOM = 712;
  const PRICE_AXIS_LEFT = 1310;
  const RIGHT = PRICE_AXIS_LEFT;
  const REAL_RIGHT = 858;
  const FONT = "DejaVu Sans, Arial, sans-serif";

  const displayed = candles.slice(-48);
  const forecast = Array.isArray(plan.forecast) ? plan.forecast : [];
  const finite = (value) => Number.isFinite(Number(value));
  const prices = [];

  for (const c of displayed) {
    if (finite(c.high) && finite(c.low)) prices.push(Number(c.high), Number(c.low));
  }

  for (const p of forecast) {
    if (finite(p.high) && finite(p.low)) prices.push(Number(p.high), Number(p.low));
  }

  for (const value of [
    analysis.price,
    mt5Quote?.bid,
    mt5Quote?.ask,
    plan.confirmation,
    plan.sl,
    plan.tp1,
    plan.tp2,
    plan.tp3,
  ]) {
    if (finite(value)) prices.push(Number(value));
  }

  let minPrice = prices.length ? Math.min(...prices) : Number(analysis.price || 0) - 1;
  let maxPrice = prices.length ? Math.max(...prices) : Number(analysis.price || 0) + 1;
  let range = Math.max(maxPrice - minPrice, Math.abs(Number(analysis.price || 1)) * 0.00025, 0.01);
  const pad = range * 0.09;
  minPrice -= pad;
  maxPrice += pad;
  range = maxPrice - minPrice;

  const priceY = (price) =>
    TOP + ((maxPrice - Number(price)) / range) * (BOTTOM - TOP);

  const clampY = (y) => Math.max(TOP + 7, Math.min(BOTTOM - 7, y));
  const candleStep = (REAL_RIGHT - LEFT - 18) / Math.max(displayed.length, 1);
  const candleWidth = Math.max(5, Math.min(13, candleStep * 0.68));
  const signalColor =
    analysis.action === "BUY"
      ? "#26a69a"
      : analysis.action === "SELL"
      ? "#ef5350"
      : "#b2b5be";
  const signalFill =
    analysis.action === "BUY"
      ? "#123f3c"
      : analysis.action === "SELL"
      ? "#4a2428"
      : "#2a2e39";
  const quoteDigits = Math.max(2, Math.min(5, Number(mt5Quote?.digits || 2)));
  const currentPrice = finite(mt5Quote?.bid)
    ? Number(mt5Quote.bid)
    : Number(analysis.price);
  const priceText = finite(currentPrice) ? currentPrice.toFixed(quoteDigits) : "—";
  const directionText =
    analysis.action === "BUY"
      ? "ПОКУПКА"
      : analysis.action === "SELL"
      ? "ПРОДАЖА"
      : "ОЖИДАНИЕ";
  const closedText = fmtDateTime(candle.time);
  const analysisText = fmtDateTime(analyzedAt);
  const chartNews = analysis.newsPressure || {};
  const chartGoogleText = chartNews.googleAvailable
    ? `Google ${chartNews.googleDirection} ${chartNews.googleConfidence || 0}/100`
    : "Google: нет подтверждённого влияния";
  const formatAxisTime = (value) =>
    new Date(value).toLocaleTimeString("ru-RU", {
      timeZone: USER_TIMEZONE,
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    });

  let svg = `
<svg xmlns="http://www.w3.org/2000/svg" width="${WIDTH}" height="${HEIGHT}">
<defs>
  <linearGradient id="forecastFade" x1="0" x2="1" y1="0" y2="0">
    <stop offset="0%" stop-color="${signalColor}" stop-opacity="0.22"/>
    <stop offset="100%" stop-color="${signalColor}" stop-opacity="0.06"/>
  </linearGradient>
  <filter id="softGlow" x="-30%" y="-30%" width="160%" height="160%">
    <feGaussianBlur stdDeviation="4" result="blur"/>
    <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
  </filter>
</defs>
<rect width="100%" height="100%" fill="#0d1117"/>

<text x="58" y="48" fill="#f0f3fa" font-family="${FONT}" font-size="29" font-weight="700">XAU/USD</text>
<text x="58" y="79" fill="#787b86" font-family="${FONT}" font-size="15">GOLD • ${escapeSvg(timeframe)} • PRO CHART</text>
<text x="320" y="52" fill="#f0f3fa" font-family="${FONT}" font-size="32" font-weight="700">${priceText}</text>
<text x="320" y="79" fill="#787b86" font-family="${FONT}" font-size="14">MT5 ${escapeSvg(mt5Quote?.symbol || "GOLD#")} • BID</text>

<rect x="1095" y="26" width="286" height="63" rx="12" fill="${signalFill}" stroke="${signalColor}" stroke-opacity="0.55"/>
<circle cx="1122" cy="57" r="7" fill="${signalColor}"/>
<text x="1141" y="52" fill="${signalColor}" font-family="${FONT}" font-size="18" font-weight="700">${directionText}</text>
<text x="1141" y="75" fill="#d1d4dc" font-family="${FONT}" font-size="14">Сила ${analysis.strength}/100</text>

<rect x="58" y="108" width="1323" height="40" rx="8" fill="#131722" stroke="#2a2e39"/>
<text x="76" y="134" fill="#b2b5be" font-family="${FONT}" font-size="14">Закрытая ${escapeSvg(timeframe)}: ${escapeSvg(closedText)}</text>
<text x="430" y="134" fill="#b2b5be" font-family="${FONT}" font-size="14">Анализ: ${escapeSvg(analysisText)}</text>
<text x="765" y="134" fill="#787b86" font-family="${FONT}" font-size="14">Реальные свечи</text>
<text x="1068" y="134" fill="${signalColor}" font-family="${FONT}" font-size="14">Прогнозный сценарий</text>

<rect x="${LEFT}" y="${TOP}" width="${PRICE_AXIS_LEFT - LEFT}" height="${BOTTOM - TOP + 40}" fill="#131722" stroke="#2a2e39"/>
<rect x="${REAL_RIGHT}" y="${TOP}" width="${RIGHT - REAL_RIGHT}" height="${BOTTOM - TOP}" fill="#171b26"/>
<rect x="${PRICE_AXIS_LEFT}" y="${TOP}" width="71" height="${BOTTOM - TOP + 40}" fill="#10141e" stroke="#2a2e39"/>
`;

  for (let i = 0; i <= 6; i++) {
    const y = TOP + ((BOTTOM - TOP) * i) / 6;
    const p = maxPrice - (range * i) / 6;
    svg += `
<line x1="${LEFT}" y1="${y}" x2="${RIGHT}" y2="${y}" stroke="#2a2e39" stroke-width="1"/>
<text x="${PRICE_AXIS_LEFT + 9}" y="${y + 5}" fill="#9598a1" font-family="${FONT}" font-size="13">${p.toFixed(2)}</text>`;
  }

  for (let i = 0; i <= 8; i++) {
    const x = LEFT + ((RIGHT - LEFT) * i) / 8;
    svg += `
<line x1="${x}" y1="${TOP}" x2="${x}" y2="${BOTTOM}" stroke="#242834" stroke-width="1"/>`;
  }

  displayed.forEach((c, index) => {
    const x = LEFT + 9 + index * candleStep + candleStep / 2;
    const openY = clampY(priceY(c.open));
    const closeY = clampY(priceY(c.close));
    const highY = clampY(priceY(c.high));
    const lowY = clampY(priceY(c.low));
    const up = Number(c.close) >= Number(c.open);
    const color = up ? "#26a69a" : "#ef5350";
    const bodyTop = Math.min(openY, closeY);
    const bodyHeight = Math.max(2.5, Math.abs(openY - closeY));
    svg += `
<line x1="${x}" y1="${highY}" x2="${x}" y2="${lowY}" stroke="${color}" stroke-width="1.6"/>
<rect x="${x - candleWidth / 2}" y="${bodyTop}" width="${candleWidth}" height="${bodyHeight}" fill="${color}" rx="1"/>`;
  });

  const timeIndexes = [...new Set([0, 12, 24, 36, displayed.length - 1])]
    .filter((index) => index >= 0 && index < displayed.length);
  for (const index of timeIndexes) {
    const x = LEFT + 9 + index * candleStep + candleStep / 2;
    svg += `
<line x1="${x}" y1="${BOTTOM}" x2="${x}" y2="${BOTTOM + 7}" stroke="#787b86"/>
<text x="${x}" y="${BOTTOM + 27}" text-anchor="middle" fill="#787b86" font-family="${FONT}" font-size="12">${escapeSvg(formatAxisTime(displayed[index].time))}</text>`;
  }

  svg += `
<line x1="${REAL_RIGHT}" y1="${TOP}" x2="${REAL_RIGHT}" y2="${BOTTOM}" stroke="#d1d4dc" stroke-width="1.3" stroke-dasharray="5 7" opacity="0.72"/>
<rect x="${REAL_RIGHT - 38}" y="${TOP + 11}" width="76" height="25" rx="5" fill="#2a2e39"/>
<text x="${REAL_RIGHT}" y="${TOP + 29}" text-anchor="middle" fill="#d1d4dc" font-family="${FONT}" font-size="12" font-weight="700">СЕЙЧАС</text>`;

  if (forecast.length) {
    const forecastX = (index) =>
      REAL_RIGHT + 14 +
      (index / Math.max(forecast.length - 1, 1)) * (RIGHT - REAL_RIGHT - 30);
    const centerPoints = forecast
      .map((p, i) => `${forecastX(i)},${clampY(priceY(p.center))}`)
      .join(" ");
    const highPoints = forecast
      .map((p, i) => `${forecastX(i)},${clampY(priceY(p.high))}`)
      .join(" ");
    const lowPoints = [...forecast]
      .reverse()
      .map((p, ri) => `${forecastX(forecast.length - 1 - ri)},${clampY(priceY(p.low))}`)
      .join(" ");
    svg += `
<polygon points="${highPoints} ${lowPoints}" fill="url(#forecastFade)"/>
<polyline points="${centerPoints}" fill="none" stroke="${signalColor}" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round" filter="url(#softGlow)"/>`;

    const milestones = [
      { label: "5м", point: plan.p5 },
      { label: "10м", point: plan.p10 },
      { label: "15м", point: plan.p15 },
    ];
    for (const milestone of milestones) {
      const p = milestone.point;
      if (!p || !finite(p.center)) continue;
      const horizon = Math.max(1, Number(plan.horizon || 15));
      const progress = Math.max(0, Math.min(1, Number(p.minute || 0) / horizon));
      const x = REAL_RIGHT + 14 + progress * (RIGHT - REAL_RIGHT - 30);
      const y = clampY(priceY(p.center));
      const labelY = analysis.action === "SELL" ? y - 13 : y + 25;
      svg += `
<circle cx="${x}" cy="${y}" r="4" fill="${signalColor}" stroke="#f0f3fa" stroke-width="1.2"/>
<text x="${x}" y="${labelY}" text-anchor="middle" fill="#d1d4dc" font-family="${FONT}" font-size="12" font-weight="700">${milestone.label}</text>`;
    }
  }

  function drawLevel(price, label, color) {
    if (!finite(price)) return;
    const y = clampY(priceY(price));
    svg += `
<line x1="${LEFT}" y1="${y}" x2="${RIGHT}" y2="${y}" stroke="${color}" stroke-width="1.2" stroke-dasharray="6 5" opacity="0.76"/>
<rect x="${PRICE_AXIS_LEFT + 3}" y="${y - 11}" width="112" height="22" rx="4" fill="${color}"/>
<text x="${PRICE_AXIS_LEFT + 8}" y="${y + 5}" fill="#ffffff" font-family="${FONT}" font-size="11" font-weight="700">${escapeSvg(label)} ${Number(price).toFixed(2)}</text>`;
  }

  if (analysis.action !== "WAIT") {
    drawLevel(plan.confirmation, "ENTRY", "#f2c94c");
    drawLevel(plan.sl, "SL", "#ef5350");
    drawLevel(plan.tp1, "TP1", "#26a69a");
    drawLevel(plan.tp2, "TP2", "#26a69a");
    drawLevel(plan.tp3, "TP3", "#26a69a");
  }

  if (finite(currentPrice)) {
    const y = clampY(priceY(currentPrice));
    svg += `
<line x1="${LEFT}" y1="${y}" x2="${RIGHT}" y2="${y}" stroke="#4c9aff" stroke-width="1.2" stroke-dasharray="3 4" opacity="0.82"/>
<rect x="${PRICE_AXIS_LEFT + 2}" y="${y - 12}" width="76" height="24" rx="4" fill="#2962ff"/>
<text x="${PRICE_AXIS_LEFT + 40}" y="${y + 5}" text-anchor="middle" fill="#ffffff" font-family="${FONT}" font-size="12" font-weight="700">${priceText}</text>`;
  }

  const askText = finite(mt5Quote?.ask) ? Number(mt5Quote.ask).toFixed(quoteDigits) : "—";
  const spreadText = finite(mt5Quote?.spread) ? Number(mt5Quote.spread).toFixed(quoteDigits) : "—";
  svg += `
<rect x="58" y="780" width="628" height="67" rx="10" fill="#131722" stroke="#2a2e39"/>
<text x="78" y="807" fill="#787b86" font-family="${FONT}" font-size="13">MT5 LIVE • ${escapeSvg(mt5Quote?.symbol || "GOLD#")}</text>
<text x="78" y="832" fill="#d1d4dc" font-family="${FONT}" font-size="16" font-weight="700">BID ${priceText}   ASK ${askText}   SPREAD ${spreadText}</text>

<rect x="706" y="780" width="675" height="67" rx="10" fill="#131722" stroke="#2a2e39"/>
<text x="726" y="807" fill="#787b86" font-family="${FONT}" font-size="13">СЦЕНАРИЙ</text>
<text x="726" y="832" fill="${signalColor}" font-family="${FONT}" font-size="16" font-weight="700">${directionText} • ${analysis.strength}/100</text>
<text x="1000" y="832" fill="#787b86" font-family="${FONT}" font-size="13">Не является гарантией результата</text>

<text x="58" y="878" fill="#5d606b" font-family="${FONT}" font-size="12">Новости ${escapeSvg(
    chartNews.direction || "NEUTRAL"
  )} ${Number(chartNews.strength || 0)}/100 • ${escapeSvg(
    chartGoogleText
  )} • DEMO risk-control</text>
</svg>`;

  return svg;
}

async function createChart(args) {
  return sharp(Buffer.from(createSVG(args)))
    .resize({ width: 1080, withoutEnlargement: true })
    .flatten({ background: "#0d1117" })
    .jpeg({ quality: 86, progressive: true })
    .toBuffer();
}

// ======================================================
// TELEGRAM KEYBOARDS
// ======================================================

function timeframeKeyboard() {
  return {
    inline_keyboard: [
      [
        { text: "M1", callback_data: "signal_M1" },
        { text: "M5", callback_data: "signal_M5" },
        { text: "M15", callback_data: "signal_M15" },
      ],
      [
        { text: "M30", callback_data: "signal_M30" },
        { text: "H1", callback_data: "signal_H1" },
      ],
      [
        { text: "⚙️ Режим DEMO", callback_data: "risk_mode_menu" },
      ],
    ],
  };
}

function mainKeyboard() {
  return {
    inline_keyboard: [
      [
        {
          text: "📊 Проверить сигнал",
          callback_data: "signal_menu",
        },
      ],
      [
        { text: "🌍 Новости 24ч", callback_data: "news_general" },
        { text: "📊 CFTC", callback_data: "cftc" },
      ],
      [
        { text: "🤖 AUTOPILOT", callback_data: "autopilot_status" },
        { text: "🗄 База", callback_data: "db_status" },
      ],
      [
        { text: "⚙️ Режим DEMO", callback_data: "risk_mode_menu" },
      ],
    ],
  };
}

function riskModeKeyboard(currentMode) {
  const mark = (mode) => (currentMode === mode ? "✅ " : "");

  return {
    inline_keyboard: [
      [
        {
          text: `${mark("CAUTIOUS")}🛡 Осторожный`,
          callback_data: "risk_mode_CAUTIOUS",
        },
        {
          text: `${mark("MEDIUM")}⚖️ Средний`,
          callback_data: "risk_mode_MEDIUM",
        },
      ],
      [
        {
          text: `${mark("ACTIVE")}🔥 Активный`,
          callback_data: "risk_mode_ACTIVE",
        },
        {
          text: `${mark("AGGRESSIVE")}🚀 Агрессивный`,
          callback_data: "risk_mode_AGGRESSIVE",
        },
      ],
      [
        {
          text: "⬅️ Главное меню",
          callback_data: "main_menu",
        },
      ],
    ],
  };
}

function riskModeText(mode) {
  const normalized = normalizeRiskMode(mode);
  const info = RISK_MODES[normalized];

  return `⚙️ РЕЖИМ MT5 DEMO

Сейчас выбран:
${info.label}

Выбери режим кнопкой ниже.

✅ Выбор сохраняется в PostgreSQL.
✅ Второй DEMO-бот автоматически подхватывает изменение.
✅ Перезапуск торгового бота для смены режима не нужен.

🔒 Эти кнопки управляют только DEMO-риск-менеджментом.`;
}

async function sendRiskModeMenu(chatId) {
  if (!(await ownerAllowed(chatId))) {
    await bot.sendMessage(
      chatId,
      "⛔ Изменять режим DEMO может только владелец бота."
    );
    return;
  }

  if (!dbPool || !(await ensureDatabaseReady())) {
    await bot.sendMessage(
      chatId,
      "❌ PostgreSQL недоступен. Режим DEMO сейчас изменить нельзя."
    );
    return;
  }

  const mode = await currentRiskMode();

  await bot.sendMessage(chatId, riskModeText(mode), {
    reply_markup: riskModeKeyboard(mode),
  });
}

// ======================================================
// SEND SIGNAL
// ======================================================

async function sendPreparedSignal(chatId, prepared, prefix = "") {
  const image = await createChart({
    candles: prepared.candles,
    analysis: prepared.analysis,
    plan: prepared.plan,
    timeframe: prepared.timeframe,
    analyzedAt: prepared.analyzedAt,
    candle: prepared.candle,
    mt5Quote: prepared.market.mt5Quote,
  });

  const text = buildSignalText({
    timeframe: prepared.timeframe,
    analyses: prepared.market.analyses,
    analysis: prepared.analysis,
    plan: prepared.plan,
    analyzedAt: prepared.analyzedAt,
    candle: prepared.candle,
    mt5Quote: prepared.market.mt5Quote,
  });

  const fullText = prefix ? `${prefix}\n\n${text}` : text;
  const captionLimit = 950;
  let splitAt = fullText.length;

  if (fullText.length > captionLimit) {
    splitAt = fullText.lastIndexOf("\n", captionLimit);
    if (splitAt < 600) {
      splitAt = captionLimit;
    }
  }

  const caption = fullText.slice(0, splitAt).trim();
  const continuation = fullText.slice(splitAt).trim();

  const signalType = prefix === "🚨 АВТОСИГНАЛ" ? "AUTOPILOT" : "MANUAL";

  const photoMessage = await bot.sendPhoto(
    chatId,
    image,
    {
      caption,
      reply_markup: timeframeKeyboard(),
    },
    {
      filename: `xauusd_${prepared.timeframe}.jpg`,
      contentType: "image/jpeg",
    }
  );

  await registerTelegramSignalMessage({
    chatId,
    messageId: photoMessage?.message_id,
    timeframe: prepared.timeframe,
    candleTime: prepared.candle?.time,
    signalType,
  }).catch((error) => {
    console.warn("⚠️ TELEGRAM SIGNAL REGISTRY:", error.message);
  });

  if (continuation) {
    const continuationMessage = await bot.sendMessage(
      chatId,
      `↪️ ПРОДОЛЖЕНИЕ\n\n${limitTelegramText(continuation)}`,
      { reply_markup: timeframeKeyboard() }
    );

    await registerTelegramSignalMessage({
      chatId,
      messageId: continuationMessage?.message_id,
      timeframe: prepared.timeframe,
      candleTime: prepared.candle?.time,
      signalType,
    }).catch((error) => {
      console.warn("⚠️ TELEGRAM SIGNAL REGISTRY:", error.message);
    });
  }
}

const manualSignalJobs = new Set();

async function sendSignal(chatId, timeframe) {
  const tf = normalizeTimeframe(timeframe);

  if (!tf) {
    await bot.sendMessage(chatId, "Выбери таймфрейм:", {
      reply_markup: timeframeKeyboard(),
    });
    return;
  }

  await rememberOwnerChat(chatId);

  if (marketProbablyClosed()) {
    await bot.sendMessage(
      chatId,
      "🌙 XAU/USD сейчас закрыт. Новости, CFTC и статистика доступны.",
      { reply_markup: mainKeyboard() }
    );
    return;
  }

  const jobKey = String(chatId);

  if (manualSignalJobs.has(jobKey)) {
    await bot.sendMessage(
      chatId,
      "⏳ Предыдущий график ещё готовится. Дождись его отправки."
    );
    return;
  }

  manualSignalJobs.add(jobKey);
  const startedAt = Date.now();
  let waiting = null;

  console.log(`📊 MANUAL ${tf}: начинаю анализ`);

  try {
    waiting = await bot.sendMessage(
      chatId,
      `⏳ Анализирую XAU/USD ${tf} строго по закрытой ${tf}-свече...`
    );

    const prepared = await prepareAnalysis(tf, "manual");

    await bot
      .deleteMessage(chatId, waiting?.message_id)
      .catch(() => {});

    await sendPreparedSignal(chatId, prepared);

    console.log(
      `✅ MANUAL ${tf}: график отправлен за ${(
        (Date.now() - startedAt) /
        1000
      ).toFixed(1)}с`
    );
  } catch (error) {
    if (waiting?.message_id) {
      await bot
        .deleteMessage(chatId, waiting.message_id)
        .catch(() => {});
    }

    console.error(
      `❌ SIGNAL ${tf} (${((Date.now() - startedAt) / 1000).toFixed(
        1
      )}с):`,
      error
    );

    await bot.sendMessage(
      chatId,
      `❌ Ошибка анализа ${tf}: ${error.message}`,
      { reply_markup: timeframeKeyboard() }
    ).catch(() => {});
  } finally {
    manualSignalJobs.delete(jobKey);
  }
}

// ======================================================
// NEWS MESSAGES
// ======================================================

function regionIcon(region) {
  const map = {
    USA: "🇺🇸",
    CHINA: "🇨🇳",
    JAPAN: "🇯🇵",
    EUROPE: "🇪🇺",
    UK: "🇬🇧",
    MIDDLE_EAST: "🌍",
    AFRICA: "🌍",
    LATAM: "🌎",
    GLOBAL: "🌐",
  };

  return map[String(region || "").toUpperCase()] || "🌐";
}

function newsDirectionIcon(direction) {
  if (direction === "UP") return "🟢⬆️";
  if (direction === "DOWN") return "🔴⬇️";
  return "⚪↔️";
}

function formatNewsList(items, timeframe = null) {
  const filtered = timeframe
    ? newsForTimeframe(items, timeframe)
    : (items || [])
        .filter((item) => {
          const t = newsTimestamp(item);
          return t && Date.now() - t <= 24 * 60 * 60_000;
        })
        .sort((a, b) => newsTimestamp(b) - newsTimestamp(a));

  const shown = filtered.slice(0, 10);

  if (!shown.length) {
    return timeframe
      ? `🌍 Для ${timeframe} сейчас нет достаточно свежих полезных новостей.`
      : "🌍 За последние 24 часа полезных новостей из подключённых источников пока нет.";
  }

  const pressure = timeframe
    ? calculateNewsPressure(items, timeframe)
    : calculateNewsPressure(items, "H1");

  let text = timeframe
    ? `🌍 XAU/USD — НОВОСТИ ДЛЯ ${timeframe}\n\n`
    : "🌍 XAU/USD — ПОЛЕЗНЫЕ НОВОСТИ 24Ч\n\n";

  shown.forEach((item, index) => {
    const direction = String(
      item?.goldDirection || "UNKNOWN"
    ).toUpperCase();

    const impact = Math.max(
      0,
      Math.min(100, Number(item?.impact || 0))
    );

    const time = newsTimestamp(item);

    text += `${index + 1}. ${regionIcon(item?.region)} ${
      item?.title || item?.originalTitle || "Без заголовка"
    }\n`;
    text += `Источник: ${item?.source || "—"}\n`;
    text += `Регион: ${item?.region || "GLOBAL"}\n`;
    text += `Влияние: ${impact}/100\n`;
    text += `Золото: ${newsDirectionIcon(direction)}\n`;
    text += `Почему важно: ${
      item?.relevanceReason || "Связано с золотом/макро/риском"
    }\n`;
    text += `Время: ${time ? fmtDateTime(time) : "—"}\n\n`;
  });

  text += `ИТОГ: ${newsDirectionIcon(pressure.direction)} ${
    pressure.direction
  }\n`;
  text += `Сила: ${pressure.strength}/100\n`;
  text += `Учтено: ${pressure.count}\n`;
  text += `Самое сильное: ${pressure.strongest}/100`;

  return limitTelegramText(text);
}

async function sendNews(chatId, timeframe = null) {
  const items = await loadNews(true);

  await bot.sendMessage(
    chatId,
    formatNewsList(items, timeframe),
    { reply_markup: mainKeyboard() }
  );

  // Gemini проверяет новости независимо через Google Search. Итог объединяется
  // с основным движком теми же ограниченными правилами, что использует график.
  try {
    await bot.sendChatAction(chatId, "typing").catch(() => {});
    const review = await getGeminiNewsReview(items, timeframe);
    const mergeTimeframe = timeframe || "H1";
    const combinedPressure = mergeNewsPressure(
      calculateNewsPressure(items, mergeTimeframe),
      review,
      mergeTimeframe
    );
    const section = formatGeminiNewsSection(review, combinedPressure);
    if (section) {
      await bot.sendMessage(chatId, section, {
        reply_markup: mainKeyboard(),
        disable_web_page_preview: true,
      });
    }
  } catch (error) {
    console.warn("⚠️ GEMINI NEWS:", error.message);
    await bot.sendMessage(
      chatId,
      "⚠️ Google-проверка сейчас недоступна. Обычный новостной движок продолжает работать.",
      { reply_markup: mainKeyboard() }
    );
  }
}

// ======================================================
// ANALYSIS RESULT CHECK / STATS
// ======================================================

async function checkPendingAnalysisResults() {
  if (
    !dbPool ||
    !(await ensureDatabaseReady()) ||
    marketProbablyClosed()
  ) {
    return;
  }

  const pending = await dbPool.query(`
    SELECT
      a.id,
      a.analyzed_at,
      a.candle_time,
      a.timeframe,
      a.action,
      a.direction,
      a.strength,
      a.analysis_price,
      a.atr
    FROM analysis_runs a
    LEFT JOIN analysis_results r
      ON r.analysis_id = a.id
    WHERE r.id IS NULL
      AND a.analyzed_at <
        NOW() - (
          CASE a.timeframe
            WHEN 'M1' THEN INTERVAL '1 minute'
            WHEN 'M5' THEN INTERVAL '5 minutes'
            WHEN 'M15' THEN INTERVAL '15 minutes'
            WHEN 'M30' THEN INTERVAL '30 minutes'
            WHEN 'H1' THEN INTERVAL '60 minutes'
            ELSE INTERVAL '15 minutes'
          END
        )
    ORDER BY a.analyzed_at ASC
    LIMIT 60
  `);

  if (!pending.rows.length) {
    return;
  }

  const raw = await loadLiveM1(false);
  const m1 = normalizeM1(raw);

  if (!m1.length) {
    return;
  }

  for (const row of pending.rows) {
    const horizon = RESULT_HORIZON_MINUTES[row.timeframe] || 15;
    const start = new Date(row.analyzed_at).getTime();
    const target = start + horizon * 60_000;

    const observed = m1.filter(
      (c) => c.time >= start && c.time <= target + 60_000
    );

    if (!observed.length) {
      continue;
    }

    const last = observed.at(-1);
    const maxHigh = Math.max(...observed.map((c) => c.high));
    const minLow = Math.min(...observed.map((c) => c.low));
    const startPrice = Number(row.analysis_price);
    const exitPrice = last.close;

    const signedMove =
      row.direction === "BUY"
        ? exitPrice - startPrice
        : startPrice - exitPrice;

    const tolerance = Math.max(
      Number(row.atr || 0) * 0.08,
      startPrice * 0.00003
    );

    let success = null;
    let outcome = "WAIT";

    if (row.action === "WAIT") {
      success = Math.abs(exitPrice - startPrice) <= tolerance;
      outcome = success ? "WAIT_CORRECT" : "WAIT_MISSED_MOVE";
    } else {
      success = signedMove > tolerance;
      outcome = success
        ? "DIRECTION_CORRECT"
        : signedMove < -tolerance
        ? "DIRECTION_WRONG"
        : "FLAT";
    }

    await dbPool.query(
      `
        INSERT INTO analysis_results(
          analysis_id,
          target_at,
          exit_price,
          success,
          outcome,
          max_high,
          min_low,
          directional_move,
          rule_version,
          payload
        )
        VALUES(
          $1,$2,$3,$4,$5,$6,$7,$8,
          'clean-v4-direction',$9::jsonb
        )
        ON CONFLICT(analysis_id)
        DO NOTHING
      `,
      [
        row.id,
        new Date(target),
        exitPrice,
        success,
        outcome,
        maxHigh,
        minLow,
        signedMove,
        JSON.stringify({ horizon_minutes: horizon }),
      ]
    );
  }
}

async function sendStats(chatId, timeframe = null) {
  if (!dbPool || !(await ensureDatabaseReady())) {
    await bot.sendMessage(chatId, "⚠️ PostgreSQL не подключён.");
    return;
  }

  const params = [];
  let where = "";

  if (timeframe) {
    params.push(timeframe);
    where = "WHERE a.timeframe = $1";
  }

  const result = await dbPool.query(
    `
      SELECT
        a.timeframe,
        COUNT(*)::int AS total,
        COUNT(r.id)::int AS checked,
        COUNT(*) FILTER(WHERE r.success = TRUE)::int AS wins,
        COUNT(*) FILTER(WHERE r.success = FALSE)::int AS losses
      FROM analysis_runs a
      LEFT JOIN analysis_results r
        ON r.analysis_id = a.id
      ${where}
      GROUP BY a.timeframe
      ORDER BY CASE a.timeframe
        WHEN 'M1' THEN 1
        WHEN 'M5' THEN 2
        WHEN 'M15' THEN 3
        WHEN 'M30' THEN 4
        WHEN 'H1' THEN 5
        ELSE 99
      END
    `,
    params
  );

  if (!result.rows.length) {
    await bot.sendMessage(chatId, "📊 Статистика пока пустая.");
    return;
  }

  let text = "📊 СТАТИСТИКА АНАЛИЗОВ\n\n";

  for (const row of result.rows) {
    const checked = Number(row.checked || 0);
    const wins = Number(row.wins || 0);
    const rate = checked ? ((wins / checked) * 100).toFixed(1) : "—";

    text += `${row.timeframe}: всего ${row.total} • проверено ${checked} • верно ${wins} • неверно ${row.losses} • ${rate}%\n`;
  }

  await bot.sendMessage(chatId, text, {
    reply_markup: mainKeyboard(),
  });
}

async function sendDemoStats(chatId) {
  if (!dbPool || !(await ensureDatabaseReady())) {
    await bot.sendMessage(chatId, "⚠️ PostgreSQL не подключён.");
    return;
  }

  const [tradeResult, mode] = await Promise.all([
    dbPool.query(`
      SELECT
        COUNT(*)::int AS total,
        COUNT(*) FILTER(WHERE status = 'OPEN')::int AS open,
        COUNT(*) FILTER(WHERE status = 'CLOSED')::int AS closed,
        COALESCE(
          SUM(profit) FILTER(WHERE status = 'CLOSED'),
          0
        ) AS profit
      FROM demo_trades
    `),
    currentRiskMode(),
  ]);

  const row = tradeResult.rows[0];

  await bot.sendMessage(
    chatId,
    `🤖 DEMO СТАТИСТИКА

⚙️ Режим риска: ${RISK_MODES[mode].label}

Всего записей: ${row.total}
Открыто: ${row.open}
Закрыто: ${row.closed}
Суммарный результат: ${Number(row.profit || 0).toFixed(2)}`,
    {
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "⚙️ Изменить режим",
              callback_data: "risk_mode_menu",
            },
          ],
          [
            {
              text: "⬅️ Главное меню",
              callback_data: "main_menu",
            },
          ],
        ],
      },
    }
  );
}

async function sendDbStatus(chatId) {
  if (!dbPool || !(await ensureDatabaseReady())) {
    await bot.sendMessage(chatId, "❌ PostgreSQL не подключён.");
    return;
  }

  const [
    candles,
    analyses,
    results,
    candidates,
    trades,
    quotes,
    worker,
    mode,
    traderStatus,
  ] = await Promise.all([
    dbPool.query(`
      SELECT
        COUNT(*)::int AS n,
        MAX(candle_time) FILTER(
          WHERE UPPER(source) LIKE 'MT5%'
        ) AS latest_mt5_m1
      FROM xauusd_candles
      WHERE timeframe = 'M1'
    `),
    dbPool.query("SELECT COUNT(*)::int AS n FROM analysis_runs"),
    dbPool.query("SELECT COUNT(*)::int AS n FROM analysis_results"),
    dbPool.query("SELECT COUNT(*)::int AS n FROM trade_candidates"),
    dbPool.query("SELECT COUNT(*)::int AS n FROM demo_trades"),
    dbPool.query(`
      SELECT
        COUNT(*)::int AS n,
        MAX(received_at) AS latest_quote
      FROM mt5_quotes
    `),
    dbPool.query(`
      SELECT value, updated_at
      FROM demo_worker_state
      WHERE key = 'heartbeat'
      LIMIT 1
    `),
    currentRiskMode(),
    getSetting("demo_trader_status", "UNKNOWN"),
  ]);

  const candleRow = candles.rows[0] || {};
  const quoteRow = quotes.rows[0] || {};
  const workerRow = worker.rows[0] || {};
  const heartbeat = workerRow.value || {};
  const heartbeatStatus = classifyTimestamp(workerRow.updated_at, {
    maxAgeMs: DEMO_WORKER_HEARTBEAT_MAX_AGE_MS,
  });
  const workerOnline = heartbeat.alive === true && heartbeatStatus.ok;
  const workerState = workerOnline
    ? "✅ ONLINE"
    : heartbeat.alive === false
    ? "⏹ ОСТАНОВЛЕН"
    : "❌ НЕТ СВЕЖЕГО HEARTBEAT";

  const traderParts = String(traderStatus || "UNKNOWN").split("|");
  const traderState =
    traderParts[0] === "READY"
      ? "✅ ГОТОВ"
      : traderParts[0] === "PAUSED"
      ? "⏸ ПАУЗА"
      : "⚪ НЕТ СТАТУСА";
  const traderDetails = traderParts.slice(1).join(" • ");

  await bot.sendMessage(
    chatId,
    `🗄 PostgreSQL

✅ Подключён

📡 LIVE СОСТОЯНИЕ

🤖 DEMO worker: ${workerState}
Heartbeat: ${freshnessText(
      workerRow.updated_at,
      DEMO_WORKER_HEARTBEAT_MAX_AGE_MS
    )}
Символ MT5: ${heartbeat.symbol || BROKER_SYMBOL_HINT}
Версия worker: ${heartbeat.version || "не указана"}

🕯 Последняя закрытая MT5 M1:
${freshnessText(candleRow.latest_mt5_m1, M1_MAX_AGE_MS)}

💱 Последняя MT5 котировка:
${freshnessText(
      quoteRow.latest_quote,
      Math.max(MT5_QUOTE_MAX_AGE_MS, 90_000)
    )}

⚙️ DEMO trader: ${traderState}${
      traderDetails ? ` • ${traderDetails}` : ""
    }

📊 БАЗА

🕯 M1 свечей: ${candleRow.n}
🧠 Анализов: ${analyses.rows[0].n}
🧪 Проверено: ${results.rows[0].n}
🎯 DEMO кандидатов: ${candidates.rows[0].n}
🤖 DEMO сделок: ${trades.rows[0].n}
📡 MT5 котировок: ${quoteRow.n}

⚙️ DEMO режим: ${RISK_MODES[mode].label}

Версия:
${MODEL_VERSION}`,
    { reply_markup: mainKeyboard() }
  );
}

// ======================================================
// AUTOPILOT
// ======================================================

let autopilotRunning = false;

let autopilotEnabled =
  String(process.env.AUTOPILOT_ENABLED || "true").toLowerCase() !==
  "false";

const lastAutoCandle = {};
const lastAutoAlert = {};

async function autopilotScan({ forceMessage = false } = {}) {
  if (
    autopilotRunning ||
    !autopilotEnabled ||
    marketProbablyClosed()
  ) {
    return;
  }

  autopilotRunning = true;

  try {
    const owner = await getOwnerChatId();
    if (!owner) {
      return;
    }

    const snapshot = await prepareMarketSnapshot(false);
    let sent = 0;

    for (const timeframe of TF_ORDER) {
      const candles = snapshot.all[timeframe];
      const analysis = snapshot.analyses[timeframe];

      if (!candles?.length || !analysis) {
        continue;
      }

      const candle = candles.at(-1);

      if (lastAutoCandle[timeframe] === candle.time) {
        continue;
      }

      lastAutoCandle[timeframe] = candle.time;

      const prepared = await prepareAnalysis(
        timeframe,
        "autopilot",
        snapshot
      );

      if (
        analysis.action === "WAIT" ||
        analysis.strength < AUTOPILOT_MIN_STRENGTH
      ) {
        continue;
      }

      const key = `${timeframe}:${analysis.direction}`;

      if (
        Date.now() - Number(lastAutoAlert[key] || 0) <
        AUTOPILOT_COOLDOWN_MS
      ) {
        continue;
      }

      lastAutoAlert[key] = Date.now();

      await sendPreparedSignal(
        owner,
        prepared,
        "🚨 АВТОСИГНАЛ"
      );

      if (prepared.analysisId) {
        await saveSignalAlert(
          prepared.analysisId,
          owner,
          "AUTOPILOT"
        ).catch(() => {});
      }

      sent++;
    }

    if (forceMessage && sent === 0) {
      await bot.sendMessage(
        owner,
        "✅ AUTOPILOT проверил все TF. Нового сильного сигнала сейчас нет."
      );
    }
  } catch (error) {
    console.error("❌ AUTOPILOT:", error);
  } finally {
    autopilotRunning = false;
  }
}

async function autopilotText() {
  const mode = await currentRiskMode().catch(() => "MEDIUM");

  return `🤖 AUTOPILOT — XAU/USD

${
    autopilotEnabled ? "✅ ВКЛЮЧЁН" : "⏹ ВЫКЛЮЧЕН"
  }

📡 Проверка: каждые ${Math.round(
    AUTOPILOT_SCAN_MS / 60_000
  )} мин
🎯 Минимальная сила: ${AUTOPILOT_MIN_STRENGTH}/100
📊 TF: ${TF_ORDER.join(" / ")}

⚙️ DEMO риск: ${RISK_MODES[mode].label}

✅ Только закрытые свечи.
✅ Один выбранный TF не превращается в другой.
✅ Кандидат DEMO от ${TRADE_MIN_STRENGTH}/100.
✅ Дубли ограничены cooldown ${Math.round(
    AUTOPILOT_COOLDOWN_MS / 60_000
  )} мин.`;
}

// ======================================================
// TELEGRAM COMMANDS
// ======================================================

bot.setMyCommands([
  { command: "start", description: "Главное меню" },
  { command: "signal", description: "Сигнал M1/M5/M15/M30/H1" },
  { command: "news", description: "Новости XAU/USD" },
  { command: "cftc", description: "CFTC Gold" },
  { command: "stats", description: "Статистика по TF" },
  { command: "stats_all", description: "Вся статистика" },
  { command: "demo_stats", description: "DEMO статистика" },
  { command: "risk", description: "Режим риска DEMO" },
  { command: "db_status", description: "PostgreSQL" },
  { command: "autopilot", description: "AUTOPILOT" },
  { command: "autopilot_on", description: "Включить AUTOPILOT" },
  { command: "autopilot_off", description: "Выключить AUTOPILOT" },
  { command: "ai_status", description: "AI H1" },
  { command: "ping", description: "Проверка" },
]).catch((error) => {
  console.error("⚠️ setMyCommands:", error.message);
});

bot.onText(/^\/start(?:@\w+)?$/i, async (message) => {
  await rememberOwnerChat(message.chat.id);

  const mode = await currentRiskMode().catch(() => "MEDIUM");

  await bot.sendMessage(
    message.chat.id,
    `🤖 XAU/USD AI Signal Bot — CLEAN V4.4

✅ M1/M5/M15/M30/H1 разделены
✅ только закрытые свечи
✅ TIME GUARD
✅ порог новых сделок ${SIGNAL_THRESHOLD}/100
✅ совместные мировые новости: основной движок + Google
✅ CFTC
✅ AI H1
✅ PostgreSQL
✅ кандидаты для MT5 DEMO
✅ управление режимом риска из Telegram

⚙️ Сейчас DEMO: ${RISK_MODES[mode].label}

Выбери действие:`,
    { reply_markup: mainKeyboard() }
  );
});

bot.onText(
  /^\/signal(?:@\w+)?(?:\s+(M1|M5|M15|M30|H1))?$/i,
  async (message, match) => {
    const tf = normalizeTimeframe(match?.[1]);

    if (!tf) {
      await bot.sendMessage(message.chat.id, "Выбери таймфрейм:", {
        reply_markup: timeframeKeyboard(),
      });
      return;
    }

    await sendSignal(message.chat.id, tf);
  }
);

bot.onText(
  /^\/news(?:@\w+)?(?:\s+(M1|M5|M15|M30|H1))?$/i,
  async (message, match) => {
    const tf = normalizeTimeframe(match?.[1]);
    await sendNews(message.chat.id, tf);
  }
);

bot.onText(/^\/cftc(?:@\w+)?$/i, async (message) => {
  try {
    const snapshot = await getCftcGoldSnapshot({ force: true });
    await bot.sendMessage(
      message.chat.id,
      formatCftcGoldMessage(snapshot),
      { reply_markup: mainKeyboard() }
    );
  } catch (error) {
    await bot.sendMessage(
      message.chat.id,
      `❌ CFTC: ${error.message}`
    );
  }
});

bot.onText(
  /^\/stats(?:@\w+)?(?:\s+(M1|M5|M15|M30|H1))?$/i,
  async (message, match) => {
    await sendStats(
      message.chat.id,
      normalizeTimeframe(match?.[1])
    );
  }
);

bot.onText(/^\/stats_all(?:@\w+)?$/i, async (message) => {
  await sendStats(message.chat.id);
});

bot.onText(/^\/demo_stats(?:@\w+)?$/i, async (message) => {
  await sendDemoStats(message.chat.id);
});

bot.onText(/^\/risk(?:@\w+)?$/i, async (message) => {
  await sendRiskModeMenu(message.chat.id);
});

bot.onText(/^\/db_status(?:@\w+)?$/i, async (message) => {
  await sendDbStatus(message.chat.id);
});

bot.onText(/^\/autopilot(?:@\w+)?$/i, async (message) => {
  await bot.sendMessage(
    message.chat.id,
    await autopilotText(),
    { reply_markup: mainKeyboard() }
  );
});

bot.onText(/^\/autopilot_on(?:@\w+)?$/i, async (message) => {
  if (!(await ownerAllowed(message.chat.id))) {
    await bot.sendMessage(message.chat.id, "⛔ Только владелец.");
    return;
  }

  autopilotEnabled = true;
  await bot.sendMessage(message.chat.id, "▶️ AUTOPILOT включён.");

  autopilotScan({ forceMessage: true }).catch(() => {});
});

bot.onText(/^\/autopilot_off(?:@\w+)?$/i, async (message) => {
  if (!(await ownerAllowed(message.chat.id))) {
    await bot.sendMessage(message.chat.id, "⛔ Только владелец.");
    return;
  }

  autopilotEnabled = false;
  await bot.sendMessage(message.chat.id, "⏹ AUTOPILOT выключен.");
});

bot.onText(/^\/ai_status(?:@\w+)?$/i, async (message) => {
  try {
    const status = await getAiH1Status();

    await bot.sendMessage(
      message.chat.id,
      `🧠 AI H1\n\n${JSON.stringify(status, null, 2).slice(0, 3500)}`
    );
  } catch (error) {
    await bot.sendMessage(
      message.chat.id,
      `❌ AI H1: ${error.message}`
    );
  }
});

bot.onText(/^\/ping(?:@\w+)?$/i, async (message) => {
  const mode = await currentRiskMode().catch(() => "MEDIUM");

  await bot.sendMessage(
    message.chat.id,
    `✅ Бот работает • ${MODEL_VERSION}\n⚙️ DEMO: ${RISK_MODES[mode].label}`
  );
});

// ======================================================
// CALLBACKS
// ======================================================

bot.on("callback_query", async (query) => {
  const data = query.data || "";
  const chatId = query.message?.chat?.id;

  if (!chatId) {
    return;
  }

  try {
    if (data === "main_menu") {
      await bot.answerCallbackQuery(query.id);

      const mode = await currentRiskMode().catch(() => "MEDIUM");

      await bot.sendMessage(
        chatId,
        `🤖 Главное меню\n\n⚙️ DEMO: ${RISK_MODES[mode].label}`,
        { reply_markup: mainKeyboard() }
      );
      return;
    }

    if (data === "signal_menu") {
      await bot.answerCallbackQuery(query.id);
      await bot.sendMessage(chatId, "Выбери таймфрейм:", {
        reply_markup: timeframeKeyboard(),
      });
      return;
    }

    let match = /^signal_(M1|M5|M15|M30|H1)$/.exec(data);

    if (match) {
      const tf = match[1];

      await bot.answerCallbackQuery(query.id, {
        text: `Анализ ${tf}...`,
      });

      await sendSignal(chatId, tf);
      return;
    }

    if (data === "news_general") {
      await bot.answerCallbackQuery(query.id, {
        text: "Обновляю новости...",
      });

      await sendNews(chatId);
      return;
    }

    if (data === "cftc") {
      await bot.answerCallbackQuery(query.id);

      const snapshot = await getCftcGoldSnapshot({ force: true });

      await bot.sendMessage(
        chatId,
        formatCftcGoldMessage(snapshot),
        { reply_markup: mainKeyboard() }
      );
      return;
    }

    if (data === "autopilot_status") {
      await bot.answerCallbackQuery(query.id);

      await bot.sendMessage(
        chatId,
        await autopilotText(),
        { reply_markup: mainKeyboard() }
      );
      return;
    }

    if (data === "db_status") {
      await bot.answerCallbackQuery(query.id);
      await sendDbStatus(chatId);
      return;
    }

    if (data === "risk_mode_menu") {
      await bot.answerCallbackQuery(query.id);
      await sendRiskModeMenu(chatId);
      return;
    }

    match = /^risk_mode_(CAUTIOUS|MEDIUM|ACTIVE|AGGRESSIVE)$/.exec(
      data
    );

    if (match) {
      if (!(await ownerAllowed(chatId))) {
        await bot.answerCallbackQuery(query.id, {
          text: "Только владелец",
          show_alert: true,
        });
        return;
      }

      const mode = await setRiskMode(match[1]);

      await bot.answerCallbackQuery(query.id, {
        text: `Режим: ${RISK_MODES[mode].short}`,
      });

      const text =
        `✅ Режим DEMO изменён\n\n` +
        `${RISK_MODES[mode].label}\n\n` +
        `🤖 Торговый DEMO-бот подхватит новую настройку автоматически.`;

      try {
        await bot.editMessageText(text, {
          chat_id: chatId,
          message_id: query.message.message_id,
          reply_markup: riskModeKeyboard(mode),
        });
      } catch {
        await bot.sendMessage(chatId, text, {
          reply_markup: riskModeKeyboard(mode),
        });
      }

      console.log(`✅ DEMO RISK MODE -> ${mode}`);
      return;
    }

    await bot.answerCallbackQuery(query.id).catch(() => {});
  } catch (error) {
    console.error("❌ CALLBACK:", error);

    await bot
      .answerCallbackQuery(query.id, {
        text: "Ошибка",
        show_alert: false,
      })
      .catch(() => {});

    await bot
      .sendMessage(chatId, `❌ ${error.message}`)
      .catch(() => {});
  }
});

// ======================================================

 
// ======================================================
// GEMINI PROJECT REVIEW — advisory only
// ======================================================
bot.onText(/^\/ai_review(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const extra = String(match?.[1] || "").trim();
  try {
    await bot.sendMessage(chatId, "🔎 Gemini начинает аудит проекта. Это может занять некоторое время...");
    const result = await runGeminiProjectReview(extra);
    const report = String(result.report || "Gemini не вернул отчёт.");
    const chunks = report.match(/[\s\S]{1,3800}/g) || [report];
    for (const chunk of chunks) await bot.sendMessage(chatId, "🤖 GEMINI — АУДИТ ПРОЕКТА\n\n" + chunk);
  } catch (error) {
    console.error("❌ GEMINI REVIEW:", error.message);
    await bot.sendMessage(chatId, "❌ Gemini пока не запустился: " + error.message);
  }
});

// TIMERS / ERRORS / START
// ======================================================

ensureDatabaseReady().then(() => {
  console.log(
    DB_ENABLED
      ? "✅ PostgreSQL подключён"
      : "⚠️ PostgreSQL отключён"
  );
});

const demoTradeAlertService = dbPool
  ? createDemoTradeAlertService({
      pool: dbPool,
      bot,
      ensureReady: ensureDatabaseReady,
      getOwnerChatId,
      timeZone: USER_TIMEZONE,
    })
  : null;

demoTradeAlertService?.start();

setTimeout(() => {
  checkPendingAnalysisResults().catch(() => {});
  autopilotScan().catch(() => {});
}, 15_000);

const telegramSignalExpiryTimer = setInterval(() => {
  deleteExpiredTelegramSignals().catch((error) => {
    console.error("⚠️ TELEGRAM SIGNAL EXPIRY:", error.message);
  });
}, 15_000);

telegramSignalExpiryTimer.unref?.();

const resultTimer = setInterval(() => {
  checkPendingAnalysisResults().catch((error) => {
    console.error("⚠️ RESULT:", error.message);
  });
}, RESULT_CHECK_MS);

const autopilotTimer = setInterval(() => {
  autopilotScan().catch((error) => {
    console.error("⚠️ AUTOPILOT:", error.message);
  });
}, AUTOPILOT_SCAN_MS);

resultTimer.unref?.();
autopilotTimer.unref?.();

// Read back what the candidate log has been writing. Observability only: it
// prints, it never decides, and a failure here is printed rather than raised.
if (CANDIDATE_FUNNEL_REPORT_MS > 0) {
  const logFunnel = async () => {
    const line = await reportBreakdown(dbPool, CANDIDATE_FUNNEL_WINDOW_H);
    if (line) console.log(line);
  };

  // Once shortly after boot, so a restart does not hide the funnel for an hour.
  setTimeout(() => logFunnel().catch(() => {}), 120_000).unref?.();

  const funnelTimer = setInterval(() => {
    logFunnel().catch(() => {});
  }, CANDIDATE_FUNNEL_REPORT_MS);
  funnelTimer.unref?.();
}

bot.on("polling_error", (error) => {
  console.error("❌ TELEGRAM:", error.message);
});

process.on("unhandledRejection", (error) => {
  console.error("❌ UNHANDLED:", error);
});

process.on("uncaughtException", (error) => {
  console.error("❌ UNCAUGHT:", error);
});

console.log("✅ XAU/USD AI Signal Bot CLEAN V4.2 RISK CONTROL запущен");
console.log(describeChartFonts(CHART_FONTS));
console.log(`✅ Canonical timezone: ${CANONICAL_TIMEZONE}`);
console.log(`✅ User timezone: ${USER_TIMEZONE}`);
console.log(`✅ Signal threshold: ${SIGNAL_THRESHOLD}/100`);
console.log(`✅ Trade threshold: ${TRADE_MIN_STRENGTH}/100`);
console.log(`✅ Trade TF: ${[...TRADE_TFS].join(",")}`);
console.log("✅ Telegram DEMO risk control: ON");

