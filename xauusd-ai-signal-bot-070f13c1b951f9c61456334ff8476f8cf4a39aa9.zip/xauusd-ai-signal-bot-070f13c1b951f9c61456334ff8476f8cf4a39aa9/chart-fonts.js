"use strict";

/**
 * Make sure the chart has a font to draw with.
 *
 * The chart SVG asks for `DejaVu Sans, Arial, sans-serif` and is rendered by
 * sharp, which draws text through librsvg -> pango -> fontconfig. sharp ships
 * its own copy of those libraries but it does NOT ship any font: it expects to
 * find one on the host. The Railpack runtime image the bot is deployed on
 * carries no font package at all, so fontconfig matches nothing, pango falls
 * back to .notdef, and every single glyph -- Latin, digits and Cyrillic alike
 * -- comes out as an empty rectangle. That is the tofu chart: the drawing is
 * correct, only the letters are missing.
 *
 * Installing a font package on the host would fix it, but it would fix it
 * invisibly and only there. Instead the two DejaVu Sans faces the chart
 * actually uses (regular and bold) live in assets/fonts/, and this module
 * points fontconfig at them at startup. The chart then renders the same way on
 * Railway, in Docker, and on a developer laptop.
 *
 * Two rules it must never break:
 *
 *   - It never throws. A chart with ugly text is bad; a bot that will not boot
 *     because of a font is worse. Every failure path returns `ready: false`
 *     with a reason and leaves the environment untouched.
 *   - It never hides a font the host already has. The generated config lists
 *     the usual system font directories alongside the vendored one, so an
 *     image that does ship fonts keeps all of them.
 */

const fs = require("fs");
const os = require("os");
const path = require("path");

/** The family the chart SVG names first. */
const FAMILY = "DejaVu Sans";

/** Where the vendored faces live. */
const FONT_DIR = path.join(__dirname, "assets", "fonts");

/** Both are required: the chart uses font-weight 700 for most labels. */
const REQUIRED_FILES = Object.freeze(["DejaVuSans.ttf", "DejaVuSans-Bold.ttf"]);

/** A truncated or LFS-pointer file would pass fs.existsSync and fail to load. */
const MIN_FONT_BYTES = 50_000;

/**
 * Kept in the config so a host that does ship fonts does not lose them the
 * moment we take over FONTCONFIG_FILE.
 */
const SYSTEM_FONT_DIRS = Object.freeze([
  "/usr/share/fonts",
  "/usr/local/share/fonts",
  "/opt/homebrew/share/fonts",
  "/System/Library/Fonts",
]);

function escapeXml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

/**
 * A minimal fontconfig config: where to look, where to cache, and what the
 * generic families the SVG might fall through to should resolve to.
 *
 * The aliases matter because taking over FONTCONFIG_FILE also drops the
 * distribution's default substitution rules. Without them `sans-serif` would
 * resolve to nothing on a bare image even though the file is right there.
 */
function buildConfig(fontDir, cacheDir) {
  const dirs = [fontDir, ...SYSTEM_FONT_DIRS]
    .map((dir) => `  <dir>${escapeXml(dir)}</dir>`)
    .join("\n");

  const aliases = ["sans-serif", "sans", "Arial", "Helvetica", "Verdana"]
    .map(
      (generic) =>
        `  <alias binding="same">\n` +
        `    <family>${escapeXml(generic)}</family>\n` +
        `    <prefer><family>${escapeXml(FAMILY)}</family></prefer>\n` +
        `  </alias>`
    )
    .join("\n");

  return `<?xml version="1.0"?>
<!DOCTYPE fontconfig SYSTEM "urn:fontconfig:fonts.dtd">
<fontconfig>
${dirs}
  <cachedir>${escapeXml(cacheDir)}</cachedir>
${aliases}
</fontconfig>
`;
}

/**
 * Point fontconfig at the vendored faces.
 *
 * Must run before anything renders text. Returns a description of what
 * happened; callers log it rather than react to it.
 */
function installChartFonts({
  fontDir = FONT_DIR,
  cacheRoot = os.tmpdir(),
  env = process.env,
} = {}) {
  const result = {
    ready: false,
    family: FAMILY,
    fontDir,
    configPath: null,
    files: [],
    reason: "unknown",
  };

  try {
    // An operator who set this deliberately knows their host better than we
    // do. Leave it alone rather than silently overriding it.
    if (env.FONTCONFIG_FILE) {
      result.reason = "host_fontconfig_respected";
      result.configPath = env.FONTCONFIG_FILE;
      return result;
    }

    const missing = [];
    for (const name of REQUIRED_FILES) {
      const file = path.join(fontDir, name);
      let size = 0;
      try {
        size = fs.statSync(file).size;
      } catch {
        size = 0;
      }
      if (size < MIN_FONT_BYTES) missing.push(name);
      else result.files.push(name);
    }

    if (missing.length) {
      result.reason = `font_files_missing:${missing.join(",")}`;
      return result;
    }

    // fontconfig needs a writable cache directory, and refuses to build one
    // it cannot create. Keeping it out of the repo also keeps it out of git.
    const cacheDir = path.join(cacheRoot, "virus-ai-fontconfig");
    fs.mkdirSync(cacheDir, { recursive: true });

    const configPath = path.join(cacheDir, "fonts.conf");
    fs.writeFileSync(configPath, buildConfig(fontDir, cacheDir), "utf8");

    env.FONTCONFIG_FILE = configPath;
    // FONTCONFIG_PATH is what older fontconfig builds read; harmless here and
    // it costs nothing to satisfy both.
    env.FONTCONFIG_PATH = cacheDir;

    result.configPath = configPath;
    result.ready = true;
    result.reason = "vendored_fonts_installed";
    return result;
  } catch (error) {
    result.reason = `font_setup_failed:${String(error?.message || error).slice(0, 120)}`;
    return result;
  }
}

/** One line for the startup log, so a broken chart is visible before a user sees it. */
function describeChartFonts(state) {
  if (!state) return "🔤 CHART FONTS: unknown";
  return state.ready
    ? `🔤 CHART FONTS: ready | ${state.family} | ${state.files.join(", ")}`
    : `🔤 CHART FONTS: NOT installed | ${state.reason} | chart text may render as empty boxes`;
}

module.exports = {
  FAMILY,
  FONT_DIR,
  REQUIRED_FILES,
  buildConfig,
  installChartFonts,
  describeChartFonts,
};
