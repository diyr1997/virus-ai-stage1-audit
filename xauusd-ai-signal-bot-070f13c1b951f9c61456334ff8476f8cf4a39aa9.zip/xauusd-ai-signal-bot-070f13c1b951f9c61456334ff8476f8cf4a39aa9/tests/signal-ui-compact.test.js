"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");
const path = require("path");

process.env.GRAPH_V6_VERIFY_ONLY = "1";
process.env.SIGNAL_UI_COMPACT_VERIFY_ONLY = "1";

const { applyPatch: applyGraphPatch } = require("../graph-v6-bootstrap");
const { applyCompactPatch } = require("../signal-ui-compact-bootstrap");

const rawIndex = fs.readFileSync(path.join(__dirname, "..", "index.js"), "utf8");

test("readable UI keeps old-style Telegram blocks without verbose extras", () => {
  const graphPatched = applyGraphPatch(rawIndex);
  const patched = applyCompactPatch(graphPatched);

  assert.match(patched, /🟡 ЖДАТЬ ПОДТВЕРЖДЕНИЯ/);
  assert.match(patched, /📊 Сила направления:/);
  assert.match(patched, /✅ УСЛОВИЕ ВХОДА/);
  assert.match(patched, /❌ ОТМЕНА СЦЕНАРИЯ/);
  assert.match(patched, /🛡 SL/);
  assert.match(patched, /🎯 ЦЕЛИ/);
  assert.match(patched, /TP1: \$\{plan\.tp1\.toFixed\(2\)\}/);
  assert.match(patched, /TP2: \$\{plan\.tp2\.toFixed\(2\)\}/);
  assert.match(patched, /TP3: \$\{plan\.tp3\.toFixed\(2\)\}/);
  assert.doesNotMatch(patched, /🔮 Прогнозный коридор:/);
  assert.doesNotMatch(patched, /📦 Верхний лимит лота по силе:/);
  assert.doesNotMatch(patched, /Учтено свежих событий:/);
});

test("chart restores original geometry and uses clear Russian status", () => {
  const graphPatched = applyGraphPatch(rawIndex);
  const patched = applyCompactPatch(graphPatched);

  assert.match(patched, /const WIDTH = 1440;/);
  assert.match(patched, /const HEIGHT = 900;/);
  assert.match(patched, /const TOP = 170;/);
  assert.match(patched, /const BOTTOM = 712;/);
  assert.match(patched, /\? "BUY"/);
  assert.match(patched, /\? "SELL"/);
  assert.match(patched, /ЖДАТЬ ПОДТВЕРЖДЕНИЯ/);
  assert.match(patched, /НЕ ВХОДИТЬ/);
  assert.doesNotMatch(patched, /const HEIGHT = 720;/);
  assert.match(patched, /if \(forecast\.length && analysis\.action !== "WAIT"\)/);
});

test("V7 uncertainty does not erase a strong BUY/SELL setup", () => {
  const previous = process.env.GRAPH_V7_ENABLED;
  process.env.GRAPH_V7_ENABLED = "1";
  delete require.cache[require.resolve("../graph-v6-bootstrap")];
  const { applyPatch: applyGraphV7Patch } = require("../graph-v6-bootstrap");

  const graphPatched = applyGraphV7Patch(rawIndex);
  const patched = applyCompactPatch(graphPatched);

  assert.match(
    patched,
    /const visualAction = analysis\.action === "WAIT" \? "WAIT" : \(analysis\.direction \|\| analysis\.action\);/
  );
  assert.doesNotMatch(
    patched,
    /plan\.v7State === "UNCERTAIN" \? "WAIT"/
  );

  if (previous === undefined) delete process.env.GRAPH_V7_ENABLED;
  else process.env.GRAPH_V7_ENABLED = previous;
});
