"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");

const {
  OUTCOMES,
  classifyCandidateOutcome,
  recordCandidateOutcome,
  pruneRejections,
  formatBreakdown,
  reportBreakdown,
} = require("../candidate-rejection-log");

const TRADED = new Set(["M1", "M5", "M15"]);

function verdict(overrides = {}) {
  return {
    action: "BUY",
    direction: "BUY",
    score: 72,
    strength: 72,
    ...overrides,
  };
}

function classify(overrides = {}) {
  return classifyCandidateOutcome({
    dbReady: true,
    analysisId: 1234,
    timeframe: "M5",
    tradedTimeframes: TRADED,
    analysis: verdict(),
    minStrength: 60,
    signalThreshold: 60,
    hasExistingCandidate: false,
    ...overrides,
  });
}

test("a bar that clears every gate is recorded as accepted", () => {
  const result = classify();
  assert.equal(result.outcome, OUTCOMES.ACCEPTED);
  assert.equal(result.accepted, true);
  assert.equal(result.direction, "BUY");
  assert.equal(result.strength, 72);
});

test("the model's own refusal is reported, not a bare WAIT", () => {
  // Three different market situations that all look like silence from outside.
  const cases = [
    ["models_disagree", OUTCOMES.AI_MODELS_DISAGREE],
    ["confidence_below_threshold", OUTCOMES.AI_CONFIDENCE_BELOW_THRESHOLD],
    ["move_below_threshold", OUTCOMES.AI_MOVE_BELOW_THRESHOLD],
  ];
  for (const [aiReason, expected] of cases) {
    const result = classify({
      analysis: verdict({
        action: "WAIT",
        aiPrediction: {
          reason: aiReason,
          confidence: 0.55,
          predicted_return_bps: 1.1,
        },
      }),
    });
    assert.equal(result.outcome, expected, aiReason);
    assert.equal(result.accepted, false);
    assert.equal(result.aiReason, aiReason);
    assert.equal(result.aiConfidence, 0.55);
    assert.equal(result.aiPredictedBps, 1.1);
  }
});

test("WAIT without an AI reason is attributed to the score threshold", () => {
  const result = classify({ analysis: verdict({ action: "WAIT" }) });
  assert.equal(result.outcome, OUTCOMES.SCORE_BELOW_SIGNAL_THRESHOLD);
  assert.equal(result.signalThreshold, 60);
});

test("an unrecognised AI reason is kept rather than silently reclassified", () => {
  const result = classify({
    analysis: verdict({
      action: "WAIT",
      aiPrediction: { reason: "some_future_reason" },
    }),
  });
  assert.equal(result.outcome, OUTCOMES.AI_WAIT_OTHER);
  assert.equal(result.aiReason, "some_future_reason");
});

test("strength below the trade floor is its own outcome", () => {
  const result = classify({
    analysis: verdict({ action: "BUY", strength: 55 }),
    minStrength: 60,
  });
  assert.equal(result.outcome, OUTCOMES.STRENGTH_BELOW_TRADE_MIN);
  assert.equal(result.strength, 55);
  assert.equal(result.minStrength, 60);
});

test("an existing candidate is not counted as a rejected signal", () => {
  // The signal was good. There was simply already one open in that direction.
  // Counting this as a refusal would make the funnel look worse than it is.
  const result = classify({ hasExistingCandidate: true });
  assert.equal(result.outcome, OUTCOMES.DUPLICATE_ACTIVE_CANDIDATE);
  assert.equal(result.accepted, false);
});

test("infrastructure failures are separated from market verdicts", () => {
  assert.equal(classify({ dbReady: false }).outcome, OUTCOMES.DB_NOT_READY);
  assert.equal(classify({ analysisId: null }).outcome, OUTCOMES.NO_ANALYSIS_ID);
  assert.equal(
    classify({ timeframe: "H4" }).outcome,
    OUTCOMES.TIMEFRAME_NOT_TRADED
  );
});

test("the first binding gate wins, not the last true condition", () => {
  // Everything is wrong at once. The answer must be the cheapest gate, so the
  // breakdown names the constraint to fix rather than a pile of symptoms.
  const result = classifyCandidateOutcome({
    dbReady: false,
    analysisId: null,
    timeframe: "H4",
    tradedTimeframes: TRADED,
    analysis: verdict({ action: "WAIT", strength: 5 }),
    minStrength: 60,
    hasExistingCandidate: true,
  });
  assert.equal(result.outcome, OUTCOMES.DB_NOT_READY);
});

test("a traded-timeframe list may be an array or a Set, or absent", () => {
  assert.equal(classify({ tradedTimeframes: ["M5"] }).outcome, OUTCOMES.ACCEPTED);
  assert.equal(
    classify({ tradedTimeframes: ["M15"] }).outcome,
    OUTCOMES.TIMEFRAME_NOT_TRADED
  );
  assert.equal(classify({ tradedTimeframes: null }).outcome, OUTCOMES.ACCEPTED);
});

test("missing numbers become null instead of NaN reaching the database", () => {
  const result = classify({
    analysis: {
      action: "WAIT",
      aiPrediction: { reason: "move_below_threshold", confidence: "not a number" },
    },
  });
  assert.equal(result.score, null);
  assert.equal(result.strength, null);
  assert.equal(result.aiConfidence, null);
  assert.equal(result.aiPredictedBps, null);
});

test("classification never mutates the analysis it was handed", () => {
  const analysis = verdict({ action: "WAIT" });
  const snapshot = JSON.stringify(analysis);
  classify({ analysis });
  assert.equal(JSON.stringify(analysis), snapshot);
});

test("a failing database never throws into the signal path", async () => {
  const exploding = {
    query: async () => {
      throw new Error("connection refused");
    },
  };
  const written = await recordCandidateOutcome(exploding, classify());
  assert.equal(written, false, "must report failure, not raise it");

  const pruned = await pruneRejections(exploding, 30);
  assert.equal(pruned, 0);
});

test("no pool is a silent no-op, not a crash", async () => {
  assert.equal(await recordCandidateOutcome(null, classify()), false);
  assert.equal(await pruneRejections(null), 0);
});

test("a written row carries the values the classification reported", async () => {
  const captured = [];
  const pool = {
    query: async (sql, params) => {
      captured.push({ sql, params });
      return { rowCount: 1 };
    },
  };

  const classification = classify({
    analysis: verdict({
      action: "WAIT",
      aiPrediction: {
        reason: "move_below_threshold",
        confidence: 0.81,
        predicted_return_bps: 1.4,
      },
    }),
  });
  const ok = await recordCandidateOutcome(pool, classification, {
    candleTime: new Date("2026-09-21T21:00:00Z"),
    detail: { note: "smoke" },
  });

  assert.equal(ok, true);
  assert.equal(captured.length, 1);
  const [, params] = [captured[0].sql, captured[0].params];
  assert.equal(params[1], "M5");
  assert.equal(params[2], OUTCOMES.AI_MOVE_BELOW_THRESHOLD);
  assert.equal(params[3], false);
  assert.equal(params[9], "move_below_threshold");
  assert.equal(params[10], 0.81);
  assert.equal(params[11], 1.4);
  assert.equal(JSON.parse(params[12]).note, "smoke");
});

test("the funnel line names the gates in the order they bite", () => {
  const line = formatBreakdown(
    [
      { outcome: OUTCOMES.ACCEPTED, bars: 3 },
      { outcome: OUTCOMES.AI_CONFIDENCE_BELOW_THRESHOLD, bars: 600 },
      { outcome: OUTCOMES.STRENGTH_BELOW_TRADE_MIN, bars: 97 },
    ],
    12
  );

  assert.match(line, /^📊 CANDIDATE FUNNEL 12h \| 700 bars \|/);
  const order = line.split(" | ").slice(2).map((part) => part.split(" ")[0]);
  assert.deepEqual(order, [
    OUTCOMES.AI_CONFIDENCE_BELOW_THRESHOLD,
    OUTCOMES.STRENGTH_BELOW_TRADE_MIN,
    OUTCOMES.ACCEPTED,
  ]);
  assert.ok(line.includes("(85.7%)"), line);
});

test("an empty window says so rather than printing a misleading zero", () => {
  assert.equal(formatBreakdown([], 6), "📊 CANDIDATE FUNNEL 6h | no bars evaluated");
  assert.match(formatBreakdown(null), /no bars evaluated/);
  assert.match(
    formatBreakdown([{ outcome: OUTCOMES.ACCEPTED, bars: 0 }]),
    /no bars evaluated/
  );
});

test("a database that cannot answer produces a warning line, not a throw", async () => {
  const exploding = {
    query: async () => {
      throw new Error("relation does not exist");
    },
  };
  const line = await reportBreakdown(exploding, 24);
  assert.match(line, /^⚠️ CANDIDATE FUNNEL unavailable: relation does not exist/);

  assert.equal(await reportBreakdown(null), null, "no pool means nothing to say");
});

test("the report asks for the window it was given", async () => {
  const seen = [];
  const pool = {
    query: async (sql, params) => {
      seen.push(params[0]);
      return { rows: [{ outcome: OUTCOMES.ACCEPTED, bars: 2 }] };
    },
  };
  const line = await reportBreakdown(pool, 8);
  assert.deepEqual(seen, ["8"]);
  assert.match(line, /^📊 CANDIDATE FUNNEL 8h \| 2 bars \| ACCEPTED 2 \(100\.0%\)$/);
});
