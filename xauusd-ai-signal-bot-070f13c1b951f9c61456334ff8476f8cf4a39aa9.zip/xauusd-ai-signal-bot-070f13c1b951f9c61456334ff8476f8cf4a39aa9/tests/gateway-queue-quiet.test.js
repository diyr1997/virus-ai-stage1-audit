"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");

const {
  permanentQueueDefect,
  alreadyReported,
  rememberReported,
  parseQueuePayload,
  MAX_REMEMBERED_QUEUE_FILES,
} = require("../ai-council-gateway");

test("a file defect is permanent, so it is reported once and then stays quiet", () => {
  // The regression: ~10 dead queue files were re-fetched and re-logged every
  // 30 seconds, forever, because a broken file fails identically every time.
  const memory = new Map();
  const file = { path: "tasks/dead.json", sha: "aaa" };
  assert.equal(alreadyReported(memory, file), false, "first sight must be reported");
  rememberReported(memory, file);
  assert.equal(alreadyReported(memory, file), true, "second sight must stay quiet");
});

test("a file that actually changes is looked at again", () => {
  const memory = new Map();
  rememberReported(memory, { path: "tasks/dead.json", sha: "aaa" });
  assert.equal(
    alreadyReported(memory, { path: "tasks/dead.json", sha: "bbb" }),
    false,
    "a new sha means the file was edited and deserves another read"
  );
});

test("the memory is bounded so a long-lived gateway cannot grow forever", () => {
  const memory = new Map();
  for (let i = 0; i < 60; i += 1) {
    rememberReported(memory, { path: `tasks/f${i}.json`, sha: String(i) }, 25);
  }
  assert.equal(memory.size, 25);
  assert.equal(memory.has("tasks/f0.json"), false, "oldest entries are dropped first");
  assert.equal(memory.has("tasks/f59.json"), true, "newest entry is kept");
});

test("a file with no usable identity is never remembered", () => {
  const memory = new Map();
  rememberReported(memory, {});
  assert.equal(memory.size, 0);
  assert.equal(alreadyReported(memory, {}), false);
  assert.equal(alreadyReported(new Map(), null), false);
});

test("every unfixable queue defect is marked permanent", () => {
  const cases = [
    ["not JSON at all", "is not valid JSON"],
    ['{"task":"x"}', "invalid transport marker"],
    ['{"transport":"AI_COUNCIL_GATEWAY_V1","task":"   "}', "has empty task"],
  ];
  for (const [text, expected] of cases) {
    assert.throws(
      () => parseQueuePayload(text, { name: "f.json" }),
      (error) => {
        assert.match(error.message, new RegExp(expected));
        assert.equal(error.permanentQueueDefect, true, `${expected} must be permanent`);
        return true;
      }
    );
  }
});

test("a transient failure is not marked permanent, so it is retried", () => {
  // Only the file's own content is a permanent defect. A network or API error
  // must come back on the next poll rather than silencing the file forever.
  assert.equal(new Error("socket hang up").permanentQueueDefect, undefined);
  assert.equal(permanentQueueDefect("bad file").permanentQueueDefect, true);
});

test("a valid queue file still parses and is never silenced", () => {
  const payload = parseQueuePayload(
    JSON.stringify({ transport: "AI_COUNCIL_GATEWAY_V1", task: "проверь золото", task_id: "T1" }),
    { name: "ok.json" }
  );
  assert.equal(payload.task, "проверь золото");
  assert.ok(payload.taskId);
  assert.ok(MAX_REMEMBERED_QUEUE_FILES >= 50);
});
