"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const { spawnSync } = require("node:child_process");

process.env.EXTERNAL_ADVISORS_ENABLED = "0";
const providers = require("../ai-providers");
const { isAdvisorGroundedPrompt } = require("../solo-advisor-guard");
const { buildGeminiNewsPrompt } = require("../gemini-news");

test("solo guard recognizes advisor prompts but not normal news prompts", () => {
  assert.equal(isAdvisorGroundedPrompt("You are one member of the XAU/USD AI Council"), true);
  assert.equal(isAdvisorGroundedPrompt("XAU/USD weekly engineering review"), true);
  assert.equal(isAdvisorGroundedPrompt("Council review: inspect architecture"), true);
  assert.equal(isAdvisorGroundedPrompt("Check current gold news for CPI and FOMC releases"), false);
  assert.equal(isAdvisorGroundedPrompt("World Gold Council reports central-bank gold demand"), false);
});

test("real Gemini news prompt is not misclassified as advisor work", () => {
  const prompt = buildGeminiNewsPrompt(
    [],
    "M5",
    new Date("2026-08-24T16:00:00Z")
  );
  assert.match(prompt, /World Gold Council/i);
  assert.equal(isAdvisorGroundedPrompt(prompt), false);
});

test("solo guard blocks non-news advisor providers before network", async () => {
  await assert.rejects(providers.callDeepSeek("review project"), /EXTERNAL_ADVISORS_DISABLED/);
  await assert.rejects(providers.callClaude("review project"), /EXTERNAL_ADVISORS_DISABLED/);
  await assert.rejects(providers.callGemini("review project"), /EXTERNAL_ADVISORS_DISABLED/);
  await assert.rejects(providers.callProvider("gemini", "review project"), /EXTERNAL_ADVISORS_DISABLED/);
});

test("solo guard blocks grounded Council review before network", async () => {
  await assert.rejects(
    providers.callGeminiGrounded("You are one member of the XAU/USD AI Council. Architecture review."),
    /EXTERNAL_ADVISORS_DISABLED/
  );
});

test("enabled mode preserves the real DeepSeek provider", () => {
  const script = [
    'process.env.EXTERNAL_ADVISORS_ENABLED = "1";',
    'const providers = require("./ai-providers");',
    'const original = providers.callDeepSeek;',
    'const guard = require("./solo-advisor-guard");',
    'if (!guard.EXTERNAL_ADVISORS_ENABLED) process.exit(2);',
    'if (providers.callDeepSeek !== original) process.exit(3);',
  ].join("\n");
  const result = spawnSync(process.execPath, ["-e", script], {
    cwd: process.cwd(),
    encoding: "utf8",
  });
  assert.equal(result.status, 0, result.stderr || result.stdout);
});
