"use strict";

const assert = require("assert");
const {computeEventMetrics,sourceDiagnostics,summarize}=require("../research/phase1_reaction_metrics_v2");
const eventMs=Date.parse("2025-01-15T13:30:00Z");
const event={ordinal:0,family:"CPI",event_type:"CPI",year:2025,event_time_utc:new Date(eventMs).toISOString(),official_source:"https://www.bls.gov/news.release/archives/cpi_01152025.htm"};
function candle(timestamp,close=2700){return{timestamp,open:close,high:close+0.2,low:close-0.2,close};}
function exactWindowRows(){const rows=[candle(eventMs-60000,2699.9)];for(let i=0;i<60;i+=1)rows.push(candle(eventMs+i*60000,2700+i*0.01));return rows;}
const sparse=exactWindowRows();const ok=computeEventMetrics(event,sparse,0.10);assert.equal(ok.status,"OK");assert.equal(ok.source_rows,61);assert.equal(ok.horizons["60"].status,"OK");assert.equal(ok.reversal.status,"OK");assert.equal(sourceDiagnostics(sparse).source_coverage_ratio_vs_1440,Number((61/1440).toFixed(6)));
const missingBaseline=sparse.filter(r=>r.timestamp!==eventMs-60000);assert.equal(computeEventMetrics(event,missingBaseline).status,"MISSING_OR_INVALID_BASELINE_T_MINUS_1");
const missingT30=sparse.filter(r=>r.timestamp!==eventMs+29*60000);const missing=computeEventMetrics(event,missingT30);assert.equal(missing.horizons["30"].status,"MISSING_M1");assert.equal(missing.horizons["60"].status,"MISSING_M1");assert.equal(missing.reversal.status,"MISSING_M1");
const invalid=exactWindowRows();const bad=invalid.find(r=>r.timestamp===eventMs+10*60000);bad.high=bad.low-1;const invalidResult=computeEventMetrics(event,invalid);assert.equal(invalidResult.horizons["15"].status,"INVALID_OHLC");assert.equal(invalidResult.reversal.status,"INVALID_OHLC");
const summary=summarize([ok,missing,invalidResult],0.10);assert.equal(summary.manifest_events,3);assert.equal(summary.eligible_events,3);assert.equal(summary.excluded_pre_boundary,0);assert.equal(summary.valid_60m,1);assert.equal(summary.missing_m1_events,1);assert.equal(summary.invalid_ohlc_events,1);assert.equal(summary.retrieval_errors,0);
console.log("Sparse historical fetch fail-closed unit tests passed");
