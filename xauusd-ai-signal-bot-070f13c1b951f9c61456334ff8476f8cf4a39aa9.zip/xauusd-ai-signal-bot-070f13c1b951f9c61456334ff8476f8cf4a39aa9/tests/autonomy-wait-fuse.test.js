"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");

const {
  nextWaitState,
  DEFAULT_MAX_CONSECUTIVE_WAITS,
} = require("../autonomy/roadmap-coordinator-core");

test("the first sight of a wait reason is recorded once", () => {
  const first = nextWaitState(undefined, "NO_SYNTHESIS", 5);
  assert.deepEqual(first, { reason: "NO_SYNTHESIS", count: 1, action: "persist" });
});

test("repeating the same wait reason writes nothing", () => {
  // The regression: the coordinator committed on every poll while a gate stayed
  // unsatisfied, one commit per minute, each firing a CI run.
  let state = nextWaitState(undefined, "NO_SYNTHESIS", 100);
  assert.equal(state.action, "persist");
  for (let poll = 2; poll <= 50; poll += 1) {
    state = nextWaitState(state, "NO_SYNTHESIS", 100);
    assert.equal(state.action, "quiet", `poll ${poll} should stay silent`);
    assert.equal(state.count, poll);
  }
});

test("a changed reason is recorded and restarts the streak", () => {
  const waiting = nextWaitState({ reason: "NO_SYNTHESIS", count: 12 }, "FINAL_GATE_MISSING", 60);
  assert.deepEqual(waiting, {
    reason: "FINAL_GATE_MISSING",
    count: 1,
    action: "persist",
  });
});

test("an unsatisfiable gate ends in block rather than waiting forever", () => {
  let state = nextWaitState(undefined, "NO_SYNTHESIS", 3);
  assert.equal(state.action, "persist");
  state = nextWaitState(state, "NO_SYNTHESIS", 3);
  assert.equal(state.action, "quiet");
  state = nextWaitState(state, "NO_SYNTHESIS", 3);
  assert.equal(state.action, "block");
  assert.equal(state.count, 3);
});

test("a junk or missing bound never yields an unbounded wait", () => {
  assert.equal(nextWaitState(undefined, "X", 0).action, "persist");
  assert.equal(nextWaitState(undefined, "X", -5).action, "persist");
  assert.equal(nextWaitState(undefined, "X", "nonsense").action, "persist");
  assert.equal(nextWaitState({ reason: "X", count: 9999 }, "X", 1).action, "block");
  assert.equal(nextWaitState({ reason: "X", count: "bad" }, "X", 60).count, 1);
  assert.equal(typeof DEFAULT_MAX_CONSECUTIVE_WAITS, "number");
  assert.ok(DEFAULT_MAX_CONSECUTIVE_WAITS > 0);
});

test("one hour of silence is the default before a human is asked", () => {
  assert.equal(DEFAULT_MAX_CONSECUTIVE_WAITS, 60);
});
