"use strict";

const assert = require("assert");

const OLD = process.env.TELEGRAM_BOT_TOKEN;
process.env.TELEGRAM_BOT_TOKEN = "123456789:abcdefghijklmnopqrstuvwxyzABCDE12345";
const security = require("../telegram-security-bootstrap");

try {
  const fakeToken = "987654321:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghi12345";
  const url = `https://api.telegram.org/bot${fakeToken}/getUpdates`;
  const safe = security.sanitizeString(`request ${url} token=${fakeToken}`);
  assert(!safe.includes(fakeToken));
  assert(safe.includes("[REDACTED]") || safe.includes(security.REDACTED));

  const nested = security.sanitizeForLog({
    url,
    token: fakeToken,
    request: { href: url },
    response: { statusCode: 401, body: { error_code: 401, description: "Unauthorized" } },
  });
  assert(!JSON.stringify(nested).includes(fakeToken));
  assert.strictEqual(nested.token, "[REDACTED]");

  const bearer = "Bearer abcdefghijklmnopqrstuvwxyz0123456789";
  const query = "https://example.test/path?token=secret-value&x=1";
  const genericSafe = security.sanitizeString(`${bearer} ${query} api_key=secret-key`);
  assert(!genericSafe.includes("abcdefghijklmnopqrstuvwxyz0123456789"));
  assert(!genericSafe.includes("secret-value"));
  assert(!genericSafe.includes("secret-key"));

  const authObject = security.sanitizeForLog({
    authorization: bearer,
    api_key: "hidden-key",
    password: "hidden-password",
    href: query,
  });
  assert.strictEqual(authObject.authorization, "[REDACTED]");
  assert.strictEqual(authObject.api_key, "[REDACTED]");
  assert.strictEqual(authObject.password, "[REDACTED]");
  assert(!JSON.stringify(authObject).includes("secret-value"));

  assert.strictEqual(security.validateTelegramTokenConfig("").ok, false);
  assert.strictEqual(security.validateTelegramTokenConfig("bad-token").ok, false);
  const valid = security.validateTelegramTokenConfig(fakeToken);
  assert.strictEqual(valid.ok, true);
  assert(valid.maskedIdentity);
  assert(!valid.maskedIdentity.includes(fakeToken.split(":")[1]));

  const err = new Error(`ETELEGRAM: 401 Unauthorized ${url}`);
  err.code = "ETELEGRAM";
  err.response = { statusCode: 401, body: { error_code: 401, description: "Unauthorized" } };
  const safeError = security.sanitizeError(err);
  assert.strictEqual(safeError.statusCode, 401);
  assert.strictEqual(safeError.error_code, 401);
  assert.strictEqual(safeError.description, "Unauthorized");
  assert(!JSON.stringify(safeError).includes(fakeToken));

  const nonErrorRejection = security.sanitizeError({
    reason: `rejected ${url}`,
    token: fakeToken,
  });
  assert(!JSON.stringify(nonErrorRejection).includes(fakeToken));

  const consoleEvents = [];
  const fakeConsole = {
    log: (...args) => consoleEvents.push(["log", ...args]),
    info: (...args) => consoleEvents.push(["info", ...args]),
    warn: (...args) => consoleEvents.push(["warn", ...args]),
    error: (...args) => consoleEvents.push(["error", ...args]),
    debug: (...args) => consoleEvents.push(["debug", ...args]),
  };
  security.installConsoleRedaction(fakeConsole);
  fakeConsole.log(url);
  fakeConsole.error(new Error(`failure ${url}`));
  assert(!JSON.stringify(consoleEvents).includes(fakeToken));
  assert(consoleEvents.some((event) => event[0] === "log"));
  assert(consoleEvents.some((event) => event[0] === "error"));

  console.log("telegram-security-bootstrap tests: OK");
} finally {
  if (OLD === undefined) delete process.env.TELEGRAM_BOT_TOKEN;
  else process.env.TELEGRAM_BOT_TOKEN = OLD;
}
