"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const {
  dependenciesDone,
  phaseZeroDone,
  nextItem,
  promoteReady,
  parseFinalGate,
  requiredAdvisorsReady,
  executorChecklistComplete,
  canCloseAudit,
} = require("../autonomy/roadmap-coordinator-core");

function sampleState() {
  return {
    items: [
      { id: "0.1", order: 1, phase: "0", status: "READY", dependencies: [] },
      { id: "0.2", order: 2, phase: "0", status: "WAITING", dependencies: ["0.1"] },
      { id: "B1", order: 100, phase: "B", status: "WAITING", dependencies: ["0.2"] },
    ],
  };
}

test("phase0 gates roadmap", () => {
  const state = sampleState();
  assert.equal(nextItem(state).id, "0.1");
  state.items[0].status = "DONE";
  promoteReady(state);
  assert.equal(state.items[1].status, "READY");
  assert.equal(nextItem(state).id, "0.2");
  state.items[1].status = "DONE";
  promoteReady(state);
  assert.equal(phaseZeroDone(state), true);
  assert.equal(state.items[2].status, "READY");
});

test("dependency must be DONE", () => {
  const state = sampleState();
  assert.equal(dependenciesDone(state.items[1], state), false);
  state.items[0].status = "DONE";
  assert.equal(dependenciesDone(state.items[1], state), true);
});

test("final gate parser is fail closed", () => {
  assert.equal(parseFinalGate("FINAL_GATE: PASS"), "PASS");
  assert.equal(parseFinalGate("FINAL_GATE = BLOCKED"), "BLOCKED");
  assert.equal(parseFinalGate("looks good"), "UNKNOWN");
  assert.equal(parseFinalGate("FINAL_GATE: PASS\nFINAL_GATE: BLOCKED"), "UNKNOWN");
});

test("audit requires at least two unique ready advisers", () => {
  const item = { requires_final_gate: false };
  const base = { task: { final_plan: "ok" }, readyAdvisors: ["deepseek"] };
  assert.equal(canCloseAudit(item, base, 2).ok, false);
  const enough = { task: { final_plan: "ok" }, readyAdvisors: ["deepseek", "claude"] };
  assert.equal(canCloseAudit(item, enough, 2).ok, true);
});

test("named Phase-0 advisers cannot be substituted", () => {
  const item = {
    requires_final_gate: false,
    required_advisors: ["deepseek", "claude"],
  };
  const wrongPair = { task: { final_plan: "ok" }, readyAdvisors: ["deepseek", "gemini"] };
  assert.equal(requiredAdvisorsReady(item, wrongPair), false);
  const blocked = canCloseAudit(item, wrongPair, 2);
  assert.equal(blocked.ok, false);
  assert.equal(blocked.reason, "REQUIRED_ADVISORS_NOT_READY");

  const requiredPair = { task: { final_plan: "ok" }, readyAdvisors: ["deepseek", "claude"] };
  assert.equal(requiredAdvisorsReady(item, requiredPair), true);
  assert.equal(canCloseAudit(item, requiredPair, 2).ok, true);
});

test("executor work cannot close from council text alone", () => {
  const snapshot = { task: { final_plan: "looks complete" }, readyAdvisors: ["deepseek", "claude"] };
  const incomplete = {
    requires_executor: true,
    requires_final_gate: false,
    checklist: { CHECKED: true, IMPLEMENTED: true, TESTS_PASSED: false, COUNCIL_PASSED: true },
  };
  assert.equal(executorChecklistComplete(incomplete), false);
  const blocked = canCloseAudit(incomplete, snapshot, 2);
  assert.equal(blocked.ok, false);
  assert.equal(blocked.reason, "EXECUTOR_EVIDENCE_INCOMPLETE");

  const complete = {
    ...incomplete,
    checklist: { CHECKED: true, IMPLEMENTED: true, TESTS_PASSED: true, COUNCIL_PASSED: true },
  };
  assert.equal(executorChecklistComplete(complete), true);
  assert.equal(canCloseAudit(complete, snapshot, 2).ok, true);
});

test("final reconciliation blocks unless explicit PASS", () => {
  const item = { requires_final_gate: true };
  const blocked = {
    task: { final_plan: "findings\nFINAL_GATE: BLOCKED" },
    readyAdvisors: ["deepseek", "claude"],
  };
  const result = canCloseAudit(item, blocked, 2);
  assert.equal(result.ok, false);
  assert.equal(result.blocked, true);

  const pass = {
    task: { final_plan: "all clear\nFINAL_GATE: PASS" },
    readyAdvisors: ["deepseek", "claude"],
  };
  assert.equal(canCloseAudit(item, pass, 2).ok, true);
});
