"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");

const {
  buildGeminiNewsPrompt,
  clearGeminiNewsCache,
  formatGeminiNewsSection,
  getGeminiNewsReview,
  isMarketRelevantGoldText,
  mergeNewsPressure,
  officialSourceKey,
  parseGeminiNewsSignal,
  prepareCandidates,
} = require("../gemini-news");

const sampleItems = [
  {
    title: "Federal Reserve releases statement",
    source: "Federal Reserve",
    timestamp: Date.parse("2026-08-19T10:00:00Z"),
    url: "https://www.federalreserve.gov/example",
    impact: 90,
    goldDirection: "UP",
    relevanceReason: "ФРС / процентные ставки",
  },
];

test("prompt requires primary sources and treats feed data as untrusted", () => {
  const prompt = buildGeminiNewsPrompt(
    sampleItems,
    "M15",
    new Date("2026-08-19T12:00:00Z")
  );

  assert.match(prompt, /ОБЯЗАТЕЛЬНО используй Google Search/);
  assert.match(prompt, /официальные государственные органы/);
  assert.match(prompt, /непроверенные входные данные/);
  assert.match(prompt, /Таймфрейм M15/);
  assert.match(prompt, /federalreserve\.gov/);
  assert.match(prompt, /золотые медали/);
  assert.match(prompt, /География должна быть мировой/);
});

test("candidate preparation keeps a compact normalized record", () => {
  const [candidate] = prepareCandidates(sampleItems);
  assert.equal(candidate.source, "Federal Reserve");
  assert.equal(candidate.publishedAt, "2026-08-19T10:00:00.000Z");
  assert.equal(candidate.impact, 90);
});

test("review uses provider, keeps citations and caches the result", async () => {
  clearGeminiNewsCache();
  let calls = 0;
  const provider = async () => {
    calls += 1;
    return {
      text: 'ФРС подтвердила решение по процентной ставке, влияющее на доллар и золото.\nMACHINE_RESULT: {"direction":"UP","confidence":82,"eventCount":1,"latestEventTime":"2026-08-19T10:00:00Z"}',
      model: "test-model",
      sources: [
        {
          title: "Federal Reserve",
          url: "https://www.federalreserve.gov/example",
        },
      ],
    };
  };

  const first = await getGeminiNewsReview(sampleItems, "H1", { provider });
  const second = await getGeminiNewsReview(sampleItems, "H1", { provider });

  assert.equal(first.status, "ok");
  assert.equal(first.sources.length, 1);
  assert.equal(first.signal.direction, "UP");
  assert.equal(first.signal.officialSourceCount, 1);
  assert.equal(second.cached, true);
  assert.equal(calls, 1);
});

test("machine result is parsed but removed from the Telegram text", () => {
  const parsed = parseGeminiNewsSignal(
    'BLS опубликовало инфляцию CPI, важную для ставки ФРС и золота.\nMACHINE_RESULT: {"direction":"DOWN","confidence":88,"eventCount":2,"latestEventTime":"2026-08-19T11:00:00Z"}',
    [
      { title: "BLS", url: "https://www.bls.gov/news.release/cpi.htm" },
      {
        title: "Federal Reserve",
        url: "https://www.federalreserve.gov/newsevents.htm",
      },
    ]
  );

  assert.equal(parsed.signal.valid, true);
  assert.equal(parsed.signal.direction, "DOWN");
  assert.equal(parsed.signal.confidence, 88);
  assert.equal(parsed.signal.officialSourceCount, 2);
  assert.equal(parsed.signal.eventTimestamp, Date.parse("2026-08-19T11:00:00Z"));
  assert.doesNotMatch(parsed.cleanedText, /MACHINE_RESULT/);
});

test("official citations count organizations, not pages", () => {
  assert.equal(
    officialSourceKey({
      title: "Federal Reserve Board",
      url: "https://www.federalreserve.gov/a",
    }),
    "FED"
  );

  const parsed = parseGeminiNewsSignal(
    'ФРС и BLS подтвердили данные по ставке и инфляции, влияющие на золото.\nMACHINE_RESULT: {"direction":"UP","confidence":90,"eventCount":2,"latestEventTime":"2026-08-19T11:00:00Z"}',
    [
      { title: "Federal Reserve", url: "https://www.federalreserve.gov/a" },
      { title: "FOMC", url: "https://www.federalreserve.gov/b" },
      { title: "BLS", url: "https://www.bls.gov/c" },
    ]
  );

  assert.equal(parsed.signal.officialSourceCount, 2);
});

test("market relevance gate rejects medals and jewelry", () => {
  assert.equal(
    isMarketRelevantGoldText("ФРС изменила ставку, доллар и золото реагируют"),
    true
  );
  assert.equal(
    isMarketRelevantGoldText("Команда выиграла золотую медаль и кубок"),
    false
  );
  assert.equal(
    isMarketRelevantGoldText("Скидка на золотые ювелирные украшения 24 карата"),
    false
  );
});

test("Google affects pressure only with strong officially grounded evidence", () => {
  const merged = mergeNewsPressure(
    { direction: "UP", strength: 60, count: 3, strongest: 90 },
    {
      status: "ok",
      signal: {
        valid: true,
        direction: "UP",
        confidence: 80,
        officialSourceCount: 2,
        eventTimestamp: Date.now() - 10 * 60_000,
      },
    },
    "H1"
  );

  assert.equal(merged.googleApplied, true);
  assert.equal(merged.newsConsensus, "CONFIRMED");
  assert.ok(merged.strength > 60);

  const blocked = mergeNewsPressure(
    { direction: "NEUTRAL", strength: 0 },
    {
      status: "ok",
      signal: {
        valid: true,
        direction: "DOWN",
        confidence: 95,
        officialSourceCount: 0,
        eventTimestamp: Date.now() - 10 * 60_000,
      },
    },
    "H1"
  );

  assert.equal(blocked.googleApplied, false);
  assert.equal(blocked.direction, "NEUTRAL");
});

test("Telegram section shows the combined result", () => {
  const text = formatGeminiNewsSection(
    {
      status: "ok",
      text: "Факт подтверждён.",
      sources: [
        {
          title: "BLS",
          url: "https://www.bls.gov/example",
        },
      ],
    },
    {
      direction: "UP",
      strength: 67,
      newsConsensus: "CONFIRMED",
    }
  );

  assert.match(text, /GOOGLE \+ ОСНОВНОЙ/);
  assert.match(text, /ОБЩИЙ РЕЗУЛЬТАТ/);
  assert.match(text, /оба анализа совпали/);
  assert.match(text, /https:\/\/www\.bls\.gov\/example/);
  assert.match(text, /не команда на сделку/);
});

test("missing key leaves the original news engine available", async () => {
  const oldKey = process.env.GEMINI_API_KEY;
  delete process.env.GEMINI_API_KEY;
  try {
    const review = await getGeminiNewsReview(sampleItems, "M1");
    assert.equal(review.status, "not_configured");
    assert.match(formatGeminiNewsSection(review), /Обычный новостной движок/);
  } finally {
    if (oldKey) process.env.GEMINI_API_KEY = oldKey;
  }
});

