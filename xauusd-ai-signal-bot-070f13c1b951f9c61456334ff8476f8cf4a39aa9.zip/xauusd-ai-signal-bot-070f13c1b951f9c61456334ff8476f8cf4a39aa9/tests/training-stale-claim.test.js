"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");

// No database and no autostart: this is a unit test of the claim rule.
delete process.env.DATABASE_URL;
delete process.env.DATABASE_PUBLIC_URL;
process.env.CURRENT_DATA_LAB_DISABLE_AUTOSTART = "1";
const { claimableStatus } = require("../training-current-data-lab-v2");

test("only a reaped run is reclaimable", () => {
  // The regression: Saturday's H17 slot started, died before finishing, and its
  // RUNNING row stayed forever. The scheduler then decided START and skipped on
  // the same key every minute, and that slot was lost for good.
  assert.equal(claimableStatus("STALE"), true);
  assert.equal(claimableStatus("stale"), true);
});

test("finished work is never re-run on a timer", () => {
  // Retaking SUCCESS would repeat completed training; retaking FAILED would
  // retry a real failure every tick. Both are unbounded loops.
  assert.equal(claimableStatus("SUCCESS"), false);
  assert.equal(claimableStatus("FAILED"), false);
  assert.equal(claimableStatus("RUNNING"), false);
});

test("a missing or junk status is never treated as reclaimable", () => {
  assert.equal(claimableStatus(undefined), false);
  assert.equal(claimableStatus(null), false);
  assert.equal(claimableStatus(""), false);
  assert.equal(claimableStatus(0), false);
  assert.equal(claimableStatus({}), false);
});
