"use strict";
const assert = require("assert");
const {
  parseReleaseTimestamp,
  extractReleaseLabel,
  archiveLinks,
  SOURCES,
  HEADER_PREFIX_CHARS,
  DATE_PROXIMITY_LINES,
} = require("../research/collect_bls_archives_2003_2005");

const employmentEst = `Transmission of material in this release is\nembargoed until 8:30 A.M. (EST),\nFriday, January 9, 2004.\n\nTHE EMPLOYMENT SITUATION: DECEMBER 2003`;
const employmentEdt = `Transmission of material in this release is\nembargoed until 8:30 a.m. (EDT),\nFriday, May 2, 2003.\n\nTHE EMPLOYMENT SITUATION: APRIL 2003`;
const cpiRealStyle = `TRANSMISSION OF MATERIAL IN THIS\nRELEASE IS EMBARGOED\nUNTIL 8:30 A.M. (EST)\nFriday, February 21, 2003\n\nCONSUMER PRICE INDEX: JANUARY 2003`;

assert.equal(HEADER_PREFIX_CHARS, 2000);
assert.equal(DATE_PROXIMITY_LINES, 5);
assert.deepStrictEqual(parseReleaseTimestamp(employmentEst), {
  event_time_utc: "2004-01-09T13:30:00.000Z",
  us_eastern_local: "2004-01-09T08:30:00",
  eastern_zone: "EST",
  expected_utc_offset_minutes: -300,
});
assert.deepStrictEqual(parseReleaseTimestamp(employmentEdt), {
  event_time_utc: "2003-05-02T12:30:00.000Z",
  us_eastern_local: "2003-05-02T08:30:00",
  eastern_zone: "EDT",
  expected_utc_offset_minutes: -240,
});
assert.deepStrictEqual(parseReleaseTimestamp(cpiRealStyle), {
  event_time_utc: "2003-02-21T13:30:00.000Z",
  us_eastern_local: "2003-02-21T08:30:00",
  eastern_zone: "EST",
  expected_utc_offset_minutes: -300,
});
assert.equal(extractReleaseLabel(cpiRealStyle), "JANUARY 2003");

// Council-required edge cases: historical DST-boundary dates are interpreted
// strictly from the zone printed by BLS, never inferred from today's rules.
assert.equal(parseReleaseTimestamp(`8:30 A.M. (EST)\nSunday, March 9, 2003`).event_time_utc, "2003-03-09T13:30:00.000Z");
assert.equal(parseReleaseTimestamp(`8:30 A.M. (EST)\nSunday, November 2, 2003`).event_time_utc, "2003-11-02T13:30:00.000Z");
assert.equal(parseReleaseTimestamp(`12:00 P.M. (EDT)\nFriday, June 6, 2003`).event_time_utc, "2003-06-06T16:00:00.000Z");

assert.throws(() => parseReleaseTimestamp("no timestamp"), /RELEASE_TIME_AMBIGUOUS count=0/);
assert.throws(
  () => parseReleaseTimestamp(`8:30 A.M. (EST)\nFriday, January 10, 2003\n9:30 A.M. (EST)`),
  /RELEASE_TIME_AMBIGUOUS count=2/
);
assert.throws(
  () => parseReleaseTimestamp(`8:30 A.M. (EST)\nFriday, January 10, 2003\nMonday, January 13, 2003`),
  /RELEASE_DATE_AMBIGUOUS count=2/
);
assert.throws(
  () => parseReleaseTimestamp(`8:30 A.M. (PST)\nFriday, January 10, 2003`),
  /RELEASE_TIME_AMBIGUOUS count=0/
);
assert.throws(
  () => parseReleaseTimestamp(`8:30 A.M. (EST)\nline2\nline3\nline4\nline5\nline6\nFriday, January 10, 2003`),
  /RELEASE_DATE_AMBIGUOUS count=0/
);

async function fetchText(url) {
  const res = await fetch(url, { headers: { "user-agent": "xauusd-research-audit-test/2.0" } });
  if (!res.ok) throw new Error(`HTTP ${res.status} ${url}`);
  return res.text();
}

async function liveIntegrationSample() {
  let parsed = 0;
  for (const source of SOURCES) {
    const landing = await fetchText(source.landing);
    const links = archiveLinks(landing, source).filter(x => x.year === 2003).slice(0, 5);
    assert.equal(links.length, 5, `${source.family}: expected five 2003 sample links`);
    for (const link of links) {
      const raw = await fetchText(link.url);
      const ts = parseReleaseTimestamp(raw);
      assert.match(ts.event_time_utc, /^2003-/);
      assert.ok(ts.eastern_zone === "EST" || ts.eastern_zone === "EDT");
      parsed += 1;
    }
  }
  assert.equal(parsed, 10, "Council-required live integration sample must parse 10 BLS 2003 files");
}

liveIntegrationSample()
  .then(() => console.log("BLS archive collector parser + 10-file live integration tests passed"))
  .catch(err => { console.error(err?.stack || err); process.exit(1); });
