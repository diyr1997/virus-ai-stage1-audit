"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");

const {
  decayImpact,
  highImpactGuard,
  clampCandidateExpiry,
  normalizeCandidateValues,
  MT5_M1_FRESHNESS_SQL,
} = require("../news-trade-safety-bootstrap");

test("fresh high-impact official release activates no-trade guard", () => {
  const now = Date.now();
  const result = highImpactGuard([
    {
      timestamp: now - 60_000,
      impact: 95,
      eventKind: "OFFICIAL_RELEASE",
      relevanceReason: "CPI",
    },
  ], now);
  assert.equal(result.active, true);
  assert.match(result.reason, /HIGH_IMPACT_NEWS/);
});

test("old release does not keep no-trade guard active", () => {
  const now = Date.now();
  const result = highImpactGuard([
    { timestamp: now - 10 * 60_000, impact: 95, eventKind: "OFFICIAL_RELEASE" },
  ], now);
  assert.equal(result.active, false);
});

test("scheduled event honors symmetric plus-minus five minute window", () => {
  const now = Date.now();
  const result = highImpactGuard([
    {
      scheduledAt: now + 4 * 60_000,
      timestamp: now - 60_000,
      impact: 94,
      eventKind: "OFFICIAL_RELEASE",
      relevanceReason: "NFP scheduled",
    },
  ], now);
  assert.equal(result.active, true);
});

test("news impact decays with age", () => {
  const now = Date.now();
  const fresh = decayImpact({ timestamp: now, impact: 90, eventKind: "REAL_EVENT" }, now);
  const old = decayImpact({ timestamp: now - 120 * 60_000, impact: 90, eventKind: "REAL_EVENT" }, now);
  assert.ok(old < fresh);
});

test("M1 candidate cannot live longer than two minutes", () => {
  const now = Date.now();
  const expiry = Date.parse(clampCandidateExpiry("M1", new Date(now + 20 * 60_000).toISOString(), now));
  assert.ok(expiry <= now + 2 * 60_000);
  assert.ok(expiry > now);
});

test("M5 candidate cannot live longer than ten minutes", () => {
  const now = Date.now();
  const expiry = Date.parse(clampCandidateExpiry("M5", new Date(now + 30 * 60_000).toISOString(), now));
  assert.ok(expiry <= now + 10 * 60_000);
  assert.ok(expiry > now);
});

test("higher timeframes keep their proposed expiry", () => {
  const now = Date.now();
  const proposed = new Date(now + 45 * 60_000).toISOString();
  assert.equal(clampCandidateExpiry("M15", proposed, now), proposed);
});

test("candidate normalization updates expires_at but never TP3", () => {
  const now = Date.now();
  const originalTp3 = 4512.34;
  const values = [
    101,
    new Date(now + 20 * 60_000).toISOString(),
    "M1",
    "BUY",
    90,
    4501.0,
    4498.0,
    4496.0,
    4506.0,
    4509.0,
    originalTp3,
    JSON.stringify({ max_positions: 5, initial_positions: 2, max_additions: 3 }),
  ];

  const out = normalizeCandidateValues(values, 70_000, 5_000, now);
  assert.equal(out[2], "M1");
  assert.equal(out[10], originalTp3);
  assert.ok(Date.parse(out[1]) <= now + 2 * 60_000);
  const payload = JSON.parse(out[11]);
  assert.equal(payload.max_positions, undefined);
  assert.equal(payload.initial_positions, undefined);
  assert.equal(payload.max_additions, undefined);
  assert.equal(payload.fixed_position_count_cap, false);
  assert.equal(payload.candidate_max_age_ms, 120_000);
});

test("MT5 M1 freshness is measured from candle close, not candle open", () => {
  assert.match(MT5_M1_FRESHNESS_SQL, /MAX\(candle_time\) \+ INTERVAL '1 minute'/);
  assert.doesNotMatch(
    MT5_M1_FRESHNESS_SQL,
    /NOW\(\) - MAX\(candle_time\)\)\) \* 1000/
  );
});
