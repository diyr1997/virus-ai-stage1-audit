"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");
const path = require("path");

const guard = require("../stale-mt5-quote-guard");
const { buildTradePlanV7 } = require("../forecast-v7-engine");

test("chart source ignores stale MT5 bid/ask without injecting zero", () => {
  const source = fs.readFileSync(path.resolve(__dirname, "../index.js"), "utf8");
  const patched = guard.patchIndex(source);

  assert.match(patched, /mt5Quote\?\.fresh \? mt5Quote\?\.bid : undefined/);
  assert.match(patched, /mt5Quote\?\.fresh \? mt5Quote\?\.ask : undefined/);
  assert.doesNotMatch(patched, /mt5Quote\?\.fresh \? mt5Quote\?\.bid : null/);
  assert.match(patched, /mt5Quote\?\.fresh && finite\(mt5Quote\?\.bid\)/);
  assert.match(patched, /mt5Quote\?\.fresh && finite\(mt5Quote\?\.ask\)/);
  assert.match(patched, /CLOUD • ANALYSIS PRICE/);
});

function candles(count = 180, start = 4600) {
  const out = [];
  let price = start;
  for (let i = 0; i < count; i++) {
    const step = i % 7 === 0 ? -0.12 : 0.42;
    const open = price;
    price += step;
    out.push({
      time: new Date(Date.UTC(2026, 7, 21, 10, i)).toISOString(),
      open,
      high: Math.max(open, price) + 0.18,
      low: Math.min(open, price) - 0.18,
      close: price,
    });
  }
  return out;
}

test("stale quote alone does not force V7 UNCERTAIN", () => {
  const plan = buildTradePlanV7({
    timeframe: "M5",
    analysis: {
      price: 4615,
      direction: "BUY",
      action: "BUY",
      strength: 91,
      atr: 5,
      momentum: 1.2,
      trend: 1.1,
    },
    mt5Quote: {
      fresh: false,
      bid: 4524.15,
      ask: 4524.49,
      spread: 0.34,
    },
    candles: candles(),
    lotCap: 0.07,
  });

  assert.notEqual(plan.v7Mode, "UNCERTAIN");
  assert.equal(plan.v7State, "DIRECTIONAL");
});
