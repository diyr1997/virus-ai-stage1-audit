"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");

const {
  parseMeasurement,
  comparableMeasurements,
  inferNewsPressure,
  combine,
  normalizeTeMessage,
  parseRss,
} = require("../fast-news-watcher-v2");

function teEvent(overrides = {}) {
  return {
    sourceType: "TE_STRUCTURED",
    category: "Producer Price Index PPI MoM",
    title: "United States Producer Price Inflation MoM",
    description: "",
    actual: "0.4%",
    forecast: "0.2%",
    previous: "0.1%",
    ...overrides,
  };
}

test("hotter PPI is pressure only, not a standalone final SELL", () => {
  const pressure = inferNewsPressure(teEvent());
  assert.equal(pressure.pressure, "SELL");
  const final = combine(pressure, { fresh: false, reason: "NO_AI" });
  assert.equal(final.direction, "WAIT");
  assert.equal(final.reason, "NO_VALIDATED_DIRECTIONAL_SOURCE");
});

test("cooler CPI is BUY pressure but AI WAIT still final WAIT", () => {
  const pressure = inferNewsPressure(teEvent({
    category: "Consumer Price Index CPI YoY",
    title: "United States CPI YoY",
    actual: "2.4%",
    forecast: "2.6%",
  }));
  assert.equal(pressure.pressure, "BUY");
  assert.equal(combine(pressure, { fresh: true, direction: "WAIT", strength: 80 }).direction, "WAIT");
});

test("validated AI must agree with pressure before a direction is emitted", () => {
  const pressure = inferNewsPressure(teEvent());
  const agree = combine(pressure, { fresh: true, direction: "SELL", strength: 82 });
  assert.equal(agree.direction, "SELL");
  assert.equal(agree.reason, "NEWS_PRESSURE_AND_VALIDATED_INTERNAL_AI_AGREE");

  const conflict = combine(pressure, { fresh: true, direction: "BUY", strength: 90 });
  assert.equal(conflict.direction, "WAIT");
  assert.equal(conflict.reason, "CONFLICT");
});

test("neutral news cannot borrow a directional AI result", () => {
  const final = combine(
    { pressure: "NEUTRAL", confidence: 25 },
    { fresh: true, direction: "BUY", strength: 95 },
  );
  assert.equal(final.direction, "WAIT");
  assert.equal(final.reason, "NEWS_PRESSURE_NEUTRAL");
});

test("unit mismatch is refused instead of silently comparing scalars", () => {
  const cmp = comparableMeasurements(teEvent({ actual: "0.4%", forecast: "0.4" }));
  assert.equal(cmp.ok, false);
  assert.equal(cmp.reason, "UNIT_OR_PERIOD_MISMATCH");
  const pressure = inferNewsPressure(teEvent({ actual: "0.4%", forecast: "0.4" }));
  assert.equal(pressure.pressure, "NEUTRAL");
});

test("period mismatch is refused", () => {
  const cmp = comparableMeasurements(teEvent({ actual: "0.4% MoM", forecast: "0.4% YoY" }));
  assert.equal(cmp.ok, false);
  assert.equal(cmp.reason, "UNIT_OR_PERIOD_MISMATCH");
});

test("ambiguous multi-number text fails parsing", () => {
  assert.equal(parseMeasurement("0.4% (prev 0.2%)").ok, false);
  assert.equal(parseMeasurement("Q1 2026 GDP 2.1% (Q4 2025: 3.4%)").ok, false);
  assert.equal(parseMeasurement("N/A").ok, false);
  assert.equal(parseMeasurement("<0.1").ok, false);
  const count = parseMeasurement("1,234.5K");
  assert.equal(count.ok, true);
  assert.equal(count.unit, "COUNT");
  assert.equal(count.value, 1234500);
});

test("TE event identity does not change when actual/forecast are revised", () => {
  const a = normalizeTeMessage({ topic: "calendar", data: {
    CalendarId: 123, Country: "United States", Category: "CPI", Event: "CPI YoY",
    Date: "2026-09-10T12:30:00Z", Actual: "2.5%", Forecast: "2.6%", Previous: "2.7%",
  }});
  const b = normalizeTeMessage({ topic: "calendar", data: {
    CalendarId: 123, Country: "United States", Category: "CPI", Event: "CPI YoY",
    Date: "2026-09-10T12:30:00Z", Actual: "2.4%", Forecast: "2.6%", Previous: "2.7%",
  }});
  assert.equal(a.key, b.key);
  assert.notEqual(a.revisionFingerprint, b.revisionFingerprint);
});

test("RSS remains explicitly keyword-only and has no structured surprise", () => {
  const xml = `<?xml version="1.0"?><rss><channel><item><guid>x1</guid><title>CPI increased in August</title><description>Consumer prices rose.</description><pubDate>Thu, 10 Sep 2026 12:30:00 GMT</pubDate><link>https://example.test/cpi</link></item></channel></rss>`;
  const [item] = parseRss(xml, { name: "BLS CPI", impact: 98 });
  assert.equal(item.sourceType, "RSS_KEYWORD");
  assert.equal(item.actual, null);
  assert.equal(item.forecast, null);
  const pressure = inferNewsPressure(item);
  const final = combine(pressure, { fresh: false });
  assert.equal(final.direction, "WAIT");
});

test("geopolitical keyword is pressure only", () => {
  const pressure = inferNewsPressure({
    sourceType: "RSS_KEYWORD",
    category: "geopolitics",
    title: "missile attack escalates conflict",
    description: "",
    actual: null,
    forecast: null,
  });
  assert.equal(pressure.pressure, "BUY");
  assert.equal(combine(pressure, { fresh: false }).direction, "WAIT");
});
