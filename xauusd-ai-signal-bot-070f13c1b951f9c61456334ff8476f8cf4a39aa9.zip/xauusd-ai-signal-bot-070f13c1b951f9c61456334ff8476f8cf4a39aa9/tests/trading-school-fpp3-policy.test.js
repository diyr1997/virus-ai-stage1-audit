"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const {
  canonicalizeFpp3Url,
  isTextualContentType,
  visibleTextLength,
  fpp3WaitMs,
} = require("../trading-school-fpp3-policy");

test("FPP3 canonicalizer admits only root and flat HTML content pages", () => {
  assert.equal(canonicalizeFpp3Url("https://otexts.com/fpp3/"), "https://otexts.com/fpp3/");
  assert.equal(canonicalizeFpp3Url("graphics.html#section?x=1"), "https://otexts.com/fpp3/graphics.html");
  assert.equal(canonicalizeFpp3Url("https://otexts.com/fpp3/data-methods.html?utm=x#top"), "https://otexts.com/fpp3/data-methods.html");
  assert.equal(canonicalizeFpp3Url("https://otexts.com/fpp3/extrafiles/review.pdf"), null);
  assert.equal(canonicalizeFpp3Url("https://otexts.com/fpp3/chapter.qmd"), null);
  assert.equal(canonicalizeFpp3Url("https://otexts.com/fpp3/data.csv"), null);
  assert.equal(canonicalizeFpp3Url("https://otexts.com/fpp3cn/"), null);
  assert.equal(canonicalizeFpp3Url("https://example.com/fpp3/graphics.html"), null);
});

test("FPP3 content type policy is text only", () => {
  assert.equal(isTextualContentType("text/html; charset=utf-8"), true);
  assert.equal(isTextualContentType("application/xhtml+xml"), true);
  assert.equal(isTextualContentType("text/plain"), true);
  assert.equal(isTextualContentType("application/pdf"), false);
  assert.equal(isTextualContentType("application/octet-stream"), false);
  assert.equal(isTextualContentType(""), false);
});

test("visible text gate rejects script-only or chrome-only HTML", () => {
  const challenge = `<html><head><style>${"x".repeat(1000)}</style></head><body><script>${"y".repeat(2000)}</script><nav>${"z".repeat(500)}</nav></body></html>`;
  assert.equal(visibleTextLength(challenge), 0);

  const realPage = `<html><body><main><h1>Forecasting</h1><p>${"useful forecasting text ".repeat(30)}</p></main></body></html>`;
  assert.ok(visibleTextLength(realPage) > 300);
});

test("FPP3 request spacing is deterministic", () => {
  assert.equal(fpp3WaitMs(1000, 1200, 1500), 1300);
  assert.equal(fpp3WaitMs(1000, 2500, 1500), 0);
  assert.equal(fpp3WaitMs(0, 1200, 1500), 0);
});
