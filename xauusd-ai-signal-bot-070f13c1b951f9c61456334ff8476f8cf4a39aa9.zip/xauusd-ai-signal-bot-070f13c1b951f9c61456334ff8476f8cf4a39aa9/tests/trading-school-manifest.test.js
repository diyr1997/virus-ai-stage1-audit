"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const path = require("node:path");

const manifest = require("../trading_school/library_manifest.json");

// Types the reader actually knows how to fetch, and what each one needs to be
// fetchable at all. A source missing these is a book that silently never loads.
const REQUIRED_BY_TYPE = {
  html_collection: ["entry_url", "allowed_hosts", "path_prefix", "max_pages"],
  html_book: ["entry_url", "allowed_hosts", "path_prefix", "max_pages"],
  pdf: ["url"],
  github_mit_readmes: ["api_tree_url", "raw_base_url"],
  user_copy_required: ["landing_url"],
};

test("every source declares the fields its own type needs", () => {
  for (const source of manifest.sources) {
    const required = REQUIRED_BY_TYPE[source.type];
    assert.ok(required, `${source.key}: unknown type ${source.type}`);
    for (const field of required) {
      assert.ok(source[field], `${source.key}: missing ${field}`);
    }
    for (const field of ["key", "title", "role", "access"]) {
      assert.ok(source[field], `${source.key}: missing ${field}`);
    }
  }
});

test("book keys are unique", () => {
  const keys = manifest.sources.map((s) => s.key);
  assert.equal(new Set(keys).size, keys.length, "duplicate book_key would collide in the database");
});

test("a crawled source allows the host it starts from", () => {
  // allowedLink() matches hostname exactly, so a source whose entry_url host is
  // absent from allowed_hosts crawls its first page and then stops dead.
  for (const source of manifest.sources) {
    if (!source.entry_url || !source.allowed_hosts) continue;
    const host = new URL(source.entry_url).hostname.toLowerCase();
    const allowed = source.allowed_hosts.map((h) => String(h).toLowerCase());
    assert.ok(allowed.includes(host), `${source.key}: entry host ${host} not in allowed_hosts`);
  }
});

test("a path prefix is a rooted path, not a stray fragment", () => {
  // The entry_url is an index page and may sit outside the prefix on purpose:
  // Zerodha starts at /varsity/module/... and follows chapters under
  // /varsity/chapter/. What must hold is that the prefix is a real path, since
  // allowedLink() compares it with String.startsWith on pathname.
  for (const source of manifest.sources) {
    if (!source.path_prefix) continue;
    assert.ok(
      source.path_prefix.startsWith("/"),
      `${source.key}: path_prefix ${source.path_prefix} is not rooted`
    );
    assert.ok(
      source.max_pages > 0,
      `${source.key}: max_pages must be positive or the crawl reads nothing`
    );
  }
});

test("every fetched source is declared free, official or public domain", () => {
  // The manifest's own rule: pirate mirrors are never ingested. Anything the
  // reader downloads by itself must say where the right to read it comes from.
  for (const source of manifest.sources) {
    if (source.type === "user_copy_required") continue;
    assert.match(
      source.access,
      /free|open|public_domain|official/,
      `${source.key}: access "${source.access}" does not state a lawful route`
    );
  }
});

test("a paid book is never fetched automatically", () => {
  for (const source of manifest.sources) {
    if (!/paid|user_copy_required/.test(source.access)) continue;
    assert.equal(
      source.type,
      "user_copy_required",
      `${source.key}: paid access must not be an automatically fetched type`
    );
  }
});
