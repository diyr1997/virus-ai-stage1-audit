"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");

// The loader must be inert on require: it is a command, never part of boot.
delete process.env.DATABASE_URL;
delete process.env.DATABASE_PUBLIC_URL;
const {
  parseArgs,
  parseDay,
  normalizeRates,
  rowCeiling,
  remainingBudget,
} = require("../ops/backfill-xauusd-m1");

test("the row budget stops short of the trainer's in-memory guard", () => {
  // training-current-data-lab-v2.js fails closed above 500k rows, so filling
  // past it would stop training entirely rather than improve it.
  const ceiling = rowCeiling(500_000);
  assert.ok(ceiling < 500_000, "ceiling must leave headroom for the live feed");
  assert.equal(remainingBudget(13_849, 500_000), ceiling - 13_849);
  assert.equal(remainingBudget(0, 500_000), ceiling);
});

test("a table already at the ceiling gets no budget at all", () => {
  assert.equal(remainingBudget(500_000, 500_000), 0);
  assert.equal(remainingBudget(999_999, 500_000), 0);
});

test("a junk current count never produces a negative or infinite budget", () => {
  const ceiling = rowCeiling(500_000);
  assert.equal(remainingBudget(-5, 500_000), ceiling);
  assert.equal(remainingBudget("nonsense", 500_000), ceiling);
  assert.equal(remainingBudget(undefined, 500_000), ceiling);
  assert.ok(Number.isFinite(remainingBudget(100, undefined)));
});

test("arguments parse into an explicit, non-defaulting range", () => {
  const args = parseArgs(["--from", "2025-09-01", "--to", "2026-09-01"]);
  assert.equal(args.from, "2025-09-01");
  assert.equal(args.to, "2026-09-01");
  assert.equal(args.dryRun, false);
  assert.equal(parseArgs(["--from", "2025-09-01", "--dry-run"]).dryRun, true);
  assert.throws(() => parseArgs(["--wat"]), /Unknown argument/);
});

test("days parse as UTC midnight, and junk is rejected", () => {
  assert.equal(parseDay("2026-09-20", "--from").toISOString(), "2026-09-20T00:00:00.000Z");
  assert.throws(() => parseDay("not-a-date", "--from"), /Invalid --from/);
});

test("malformed rates are dropped rather than written as junk prices", () => {
  const rows = normalizeRates([
    { timestamp: 3000, open: 1, high: 2, low: 0.5, close: 1.5, volume: 7 },
    { timestamp: 1000, open: 1, high: 2, low: 0.5, close: 1.5 },
    { timestamp: "bad", open: 1, high: 2, low: 0.5, close: 1.5 },
    { timestamp: 2000, open: null, high: 2, low: 0.5, close: 1.5 },
    null,
  ]);
  assert.deepEqual(rows.map((r) => r.timestamp), [1000, 3000], "sorted ascending, junk removed");
  assert.equal(rows[0].volume, 0, "a missing volume becomes 0, not NaN");
});

test("a non-array response yields nothing instead of throwing", () => {
  assert.deepEqual(normalizeRates(undefined), []);
  assert.deepEqual(normalizeRates(null), []);
  assert.deepEqual(normalizeRates("nope"), []);
});

test("a missing price is rejected, never coerced to zero", () => {
  // Number(null) and Number("") are both 0 and both pass Number.isFinite, so a
  // naive filter would write a gold price of 0.00 into the training table.
  const rows = normalizeRates([
    { timestamp: 1000, open: null, high: 2, low: 1, close: 1.5 },
    { timestamp: 2000, open: "", high: 2, low: 1, close: 1.5 },
    { timestamp: 3000, open: 1, high: 2, low: 1, close: undefined },
    { timestamp: 4000, open: 0, high: 2, low: 1, close: 1.5 },
    { timestamp: 5000, open: -1, high: 2, low: 1, close: 1.5 },
  ]);
  assert.deepEqual(rows, [], "every row above is missing or impossible");
});

test("an inverted bar is rejected", () => {
  const rows = normalizeRates([
    { timestamp: 1000, open: 1.5, high: 1, low: 2, close: 1.5 },
    { timestamp: 2000, open: 1.5, high: 2, low: 1, close: 1.5 },
  ]);
  assert.deepEqual(rows.map((r) => r.timestamp), [2000]);
});
