"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");
const os = require("os");
const path = require("path");

const {
  FAMILY,
  FONT_DIR,
  REQUIRED_FILES,
  buildConfig,
  installChartFonts,
  describeChartFonts,
} = require("../chart-fonts");

function tempRoot() {
  return fs.mkdtempSync(path.join(os.tmpdir(), "chart-fonts-test-"));
}

test("the faces the chart asks for are actually in the repository", () => {
  for (const name of REQUIRED_FILES) {
    const file = path.join(FONT_DIR, name);
    const buffer = fs.readFileSync(file);
    assert.ok(buffer.length > 50_000, `${name} is too small to be a real font`);
    // TrueType files start with the version tag 0x00010000, OpenType with
    // "OTTO". Anything else means a placeholder or an LFS pointer got committed.
    const tag = buffer.readUInt32BE(0);
    assert.ok(
      tag === 0x00010000 || tag === 0x4f54544f || tag === 0x74727565,
      `${name} is not a font file (tag ${tag.toString(16)})`
    );
  }
});

test("installing points fontconfig at the vendored directory", () => {
  const env = {};
  const state = installChartFonts({ cacheRoot: tempRoot(), env });

  assert.equal(state.ready, true, state.reason);
  assert.equal(state.reason, "vendored_fonts_installed");
  assert.equal(env.FONTCONFIG_FILE, state.configPath);
  assert.equal(env.FONTCONFIG_PATH, path.dirname(state.configPath));

  const config = fs.readFileSync(state.configPath, "utf8");
  assert.ok(config.includes(`<dir>${FONT_DIR}</dir>`), "vendored dir not listed");
  assert.ok(config.includes("<dir>/usr/share/fonts</dir>"), "system fonts dropped");
  assert.ok(config.includes(`<prefer><family>${FAMILY}</family></prefer>`));
});

test("a font config the host already set is left alone", () => {
  const env = { FONTCONFIG_FILE: "/etc/fonts/fonts.conf" };
  const state = installChartFonts({ cacheRoot: tempRoot(), env });

  assert.equal(state.ready, false);
  assert.equal(state.reason, "host_fontconfig_respected");
  assert.equal(env.FONTCONFIG_FILE, "/etc/fonts/fonts.conf");
  assert.equal(env.FONTCONFIG_PATH, undefined);
});

test("missing fonts are reported, never thrown, and never half-applied", () => {
  const env = {};
  const state = installChartFonts({
    fontDir: path.join(tempRoot(), "not-here"),
    cacheRoot: tempRoot(),
    env,
  });

  assert.equal(state.ready, false);
  assert.match(state.reason, /^font_files_missing:/);
  assert.equal(env.FONTCONFIG_FILE, undefined, "must not point at an empty dir");
  assert.match(describeChartFonts(state), /empty boxes/);
});

test("an unusable cache directory degrades instead of crashing the bot", () => {
  // A regular file where a directory belongs: mkdir fails, and the bot must
  // still boot with a plain reason rather than an exception at require time.
  const blocked = path.join(tempRoot(), "not-a-directory");
  fs.writeFileSync(blocked, "");

  const env = {};
  const state = installChartFonts({ cacheRoot: blocked, env });

  assert.equal(state.ready, false);
  assert.match(state.reason, /^font_setup_failed:/);
  assert.equal(env.FONTCONFIG_FILE, undefined);
});

test("paths with XML metacharacters cannot break out of the config", () => {
  const config = buildConfig('/fonts/a&b<c>"d"', "/cache");
  assert.ok(config.includes("/fonts/a&amp;b&lt;c&gt;"));
  assert.ok(!config.includes("<c>"));
});

/**
 * The real regression: when no font is found, pango draws .notdef for every
 * character, so two different strings of the same length render to the exact
 * same pixels. That is what the broken chart looked like. Rendering two
 * visually distinct strings and comparing the bytes therefore detects tofu
 * directly, without needing a reference image.
 */
test("chart text renders as glyphs, not as identical boxes", async (t) => {
  let sharp;
  try {
    sharp = require("sharp");
  } catch {
    t.skip("sharp is not installed in this environment");
    return;
  }

  const env = {};
  const state = installChartFonts({ cacheRoot: tempRoot(), env });
  assert.equal(state.ready, true, state.reason);

  // sharp reads fontconfig from the process environment, not from ours.
  const previous = process.env.FONTCONFIG_FILE;
  process.env.FONTCONFIG_FILE = env.FONTCONFIG_FILE;
  t.after(() => {
    if (previous === undefined) delete process.env.FONTCONFIG_FILE;
    else process.env.FONTCONFIG_FILE = previous;
  });

  const render = (text) =>
    sharp(
      Buffer.from(
        `<svg xmlns="http://www.w3.org/2000/svg" width="360" height="60">` +
          `<rect width="360" height="60" fill="#131722"/>` +
          `<text x="10" y="42" fill="#f0f3fa" font-family="${FAMILY}, Arial, sans-serif" ` +
          `font-size="28" font-weight="700">${text}</text></svg>`
      )
    )
      .png()
      .toBuffer();

  // Cyrillic, because that is what the chart labels are written in and what a
  // Latin-only font would still turn into boxes.
  const [wide, narrow] = await Promise.all([render("ЖЖЖ"), render("ЛЛЛ")]);
  assert.ok(!wide.equals(narrow), "every glyph rendered the same: fonts missing");

  // And the text is drawn at all: a blank strip would also pass the test above
  // if both renders were empty in different ways, so check ink exists.
  const { data, info } = await sharp(wide)
    .removeAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });
  let light = 0;
  for (let i = 0; i < data.length; i += info.channels) {
    if (data[i] > 200) light += 1;
  }
  assert.ok(light > 200, `expected drawn text, found ${light} light pixels`);
});
