"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");

process.env.AI_COUNCIL_ISSUE140_AUDIT_ENABLED = "0";
const { buildDeepSeekAuditText, exactDeepSeekError } = require("../ai-council-issue140-audit-bootstrap");

test("publishes actual DeepSeek independent and peer responses when complete", () => {
  const snapshot = {
    task: { status: "COMPLETE" },
    readyAdvisors: ["deepseek"],
    unavailableAdvisors: [],
    runs: [
      { advisor: "deepseek", phase: "independent", status: "SUCCESS", response: "independent answer" },
      { advisor: "deepseek", phase: "peer_review", status: "SUCCESS", response: "peer answer" },
    ],
  };
  const text = buildDeepSeekAuditText(snapshot);
  assert.match(text, /deepseek_audit=COMPLETE/);
  assert.match(text, /independent answer/);
  assert.match(text, /peer answer/);
  assert.match(text, /DEEPSEEK_AUDIT_ISSUE_140/);
});

test("records exact error and PENDING_DEEPSEEK_AUDIT when provider is unavailable", () => {
  const snapshot = {
    task: { status: "WAITING_QUORUM" },
    unavailableAdvisors: [{ advisor: "deepseek", error: "AUTH_OR_CREDITS: AI API 401" }],
    runs: [],
  };
  assert.equal(exactDeepSeekError(snapshot), "AUTH_OR_CREDITS: AI API 401");
  const text = buildDeepSeekAuditText(snapshot);
  assert.match(text, /deepseek_audit=PENDING_DEEPSEEK_AUDIT/);
  assert.match(text, /provider_error=AUTH_OR_CREDITS: AI API 401/);
});
