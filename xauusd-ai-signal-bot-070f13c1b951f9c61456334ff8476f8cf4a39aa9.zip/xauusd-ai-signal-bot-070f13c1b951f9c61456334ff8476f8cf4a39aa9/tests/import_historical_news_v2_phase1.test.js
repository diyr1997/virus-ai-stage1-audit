"use strict";
const assert=require("assert");
const fs=require("fs"),path=require("path");
const {
  loadAndValidate,validatePayload,EXPECTED_DATASET,EXPECTED_ZIP_SHA,EXPECTED_JSON_SHA,
  schemaSql,insertEventSql,groupSql
}=require("../research/import_historical_news_v2_phase1");
const crypto=require("crypto");
const sha=b=>crypto.createHash("sha256").update(b).digest("hex");
const b64=fs.readFileSync(path.join(__dirname,"..","research","evidence","historical_news_v2","historical-news-v2-bls-2003-2005.zip.b64"),"utf8").replace(/\s+/g,"");
const zip=Buffer.from(b64,"base64");assert.equal(sha(zip),EXPECTED_ZIP_SHA);
const good=loadAndValidate();assert.equal(good.events.length,72);assert.equal(good.payload.dataset_sha256,EXPECTED_DATASET);assert.equal(sha(Buffer.from(good.raw)),EXPECTED_JSON_SHA);
const mutated=JSON.parse(good.raw);mutated.events[0].family="BAD";assert.throws(()=>validatePayload(JSON.stringify(mutated)),/DATASET_SHA_MISMATCH/);
const badHash=JSON.parse(good.raw);badHash.events[0].official_source="https://example.com/bad.txt";badHash.dataset_sha256=sha(Buffer.from(JSON.stringify(badHash.events)));assert.throws(()=>validatePayload(JSON.stringify(badHash)),/DATASET_SHA_MISMATCH|BAD_SOURCE/);
const dup=JSON.parse(good.raw);dup.events[1].family=dup.events[0].family;dup.events[1].event_time_utc=dup.events[0].event_time_utc;dup.dataset_sha256=sha(Buffer.from(JSON.stringify(dup.events)));assert.throws(()=>validatePayload(JSON.stringify(dup)),/DATASET_SHA_MISMATCH|DUP_FAMILY_TIME/);

assert.match(schemaSql,/\brelease_year\s+SMALLINT\b/);
assert.doesNotMatch(schemaSql,/(?:^|[,\s(])year\s+SMALLINT\b/i);
assert.match(insertEventSql,/\bfamily,release_year,event_time_utc\b/);
assert.doesNotMatch(insertEventSql,/\bfamily,year,event_time_utc\b/i);
assert.match(groupSql,/\bAS\s+release_year\b/i);
const sqlWrites=[schemaSql,insertEventSql,groupSql].join("\n");
for(const productionTable of ["signals","trades","candidates","model_registry","news_state"]){
  assert.doesNotMatch(sqlWrites,new RegExp(`(?:INSERT\\s+INTO|UPDATE|DELETE\\s+FROM)\\s+${productionTable}\\b`,"i"));
}
assert.equal(good.events[0].year>=2003&&good.events[0].year<=2005,true);
console.log("Phase 1 evidence/import validation and release_year SQL regression tests passed");
