"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");

const { buildTradePlanV7 } = require("../forecast-v7-engine");

function candles(count = 180, start = 4400) {
  const out = [];
  let price = start;
  const pattern = [0.8, 0.5, -0.35, 1.1, -0.55, 0.4, 0.75, -0.25, -0.6, 0.9];
  for (let i = 0; i < count; i++) {
    price = Math.max(1, price + pattern[i % pattern.length]);
    out.push({
      time: new Date(Date.UTC(2026, 7, 20, 0, i)).toISOString(),
      open: price - 0.2,
      high: price + 0.5,
      low: price - 0.6,
      close: price,
    });
  }
  return out;
}

function analysis(action = "BUY", strength = 82) {
  return {
    price: 4400,
    direction: action === "SELL" ? "SELL" : "BUY",
    action,
    strength,
    atr: 6,
    momentum: action === "SELL" ? -1 : 1,
    trend: action === "SELL" ? -1 : 1,
  };
}

for (const tf of ["M1", "M5", "M15", "M30", "H1"]) {
  test(`${tf}: finite ordered V7 envelope`, () => {
    const input = candles();
    const before = JSON.stringify(input);
    const plan = buildTradePlanV7({
      analysis: analysis("BUY", 82),
      timeframe: tf,
      mt5Quote: { fresh: true, bid: 4400, ask: 4400.2 },
      candles: input,
      lotCap: 0.05,
    });
    assert.equal(plan.forecastModel, "GRAPH_V7_ANALOG_ENVELOPE_V1");
    assert.ok(plan.forecast.length >= 2);
    for (const point of plan.forecast) {
      assert.ok(Number.isFinite(point.minute));
      assert.ok(Number.isFinite(point.low));
      assert.ok(Number.isFinite(point.center));
      assert.ok(Number.isFinite(point.high));
      assert.ok(point.low <= point.center);
      assert.ok(point.center <= point.high);
    }
    assert.equal(JSON.stringify(input), before, "historical candles must not be mutated");
  });
}

test("same inputs are deterministic", () => {
  const args = {
    analysis: analysis("SELL", 87),
    timeframe: "M5",
    mt5Quote: { fresh: true, bid: 4400, ask: 4400.2 },
    candles: candles(),
    lotCap: 0.06,
  };
  const a = buildTradePlanV7(args);
  const b = buildTradePlanV7(args);
  assert.deepEqual(a.forecast, b.forecast);
  assert.deepEqual(a.alternativeForecast, b.alternativeForecast);
  assert.equal(a.v7Mode, b.v7Mode);
});

test("WAIT is visually uncertain, not directional", () => {
  const plan = buildTradePlanV7({
    analysis: analysis("WAIT", 50),
    timeframe: "M1",
    mt5Quote: { fresh: true, bid: 4400, ask: 4400.2 },
    candles: candles(),
  });
  assert.equal(plan.v7State, "UNCERTAIN");
  assert.equal(plan.v7PrimaryDirection, "WAIT");
});

test("stale quote forces uncertain state", () => {
  const plan = buildTradePlanV7({
    analysis: analysis("BUY", 90),
    timeframe: "M1",
    mt5Quote: { fresh: false, bid: 4400, ask: 4400.2 },
    candles: candles(),
  });
  assert.equal(plan.v7State, "UNCERTAIN");
});

test("small history uses deterministic fallback", () => {
  const plan = buildTradePlanV7({
    analysis: analysis("BUY", 80),
    timeframe: "H1",
    mt5Quote: { fresh: true, bid: 4400, ask: 4400.2 },
    candles: candles(18),
  });
  assert.ok(["EWMA_FALLBACK", "UNCERTAIN"].includes(plan.v7Mode));
  assert.ok(plan.v7Evidence.analogCount < 6);
});

test("trade levels remain identical to V6 contract", () => {
  const plan = buildTradePlanV7({
    analysis: analysis("BUY", 90),
    timeframe: "M5",
    mt5Quote: { fresh: true, bid: 4400, ask: 4400.2 },
    candles: candles(),
    lotCap: 0.07,
  });
  assert.ok(Number.isFinite(plan.entry));
  assert.ok(Number.isFinite(plan.confirmation));
  assert.ok(Number.isFinite(plan.invalidation));
  assert.ok(Number.isFinite(plan.sl));
  assert.ok(Number.isFinite(plan.tp1));
  assert.ok(Number.isFinite(plan.tp2));
  assert.ok(Number.isFinite(plan.tp3));
  assert.equal(plan.lotCap, 0.07);
});
