"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const path = require("path");

const modulePath = path.resolve(__dirname, "..", "ai-council-claude-bridge.js");
const bridgeForModeTests = require(modulePath);

const ENV_KEYS = ["CLAUDE_CODE_BRIDGE_ENABLED", "ANTHROPIC_API_KEY"];

function withEnv(env, fn) {
  const previous = {};
  for (const key of ENV_KEYS) {
    previous[key] = process.env[key];
    if (env[key] === undefined) delete process.env[key];
    else process.env[key] = env[key];
  }
  try {
    fn();
  } finally {
    for (const key of ENV_KEYS) {
      if (previous[key] === undefined) delete process.env[key];
      else process.env[key] = previous[key];
    }
  }
}

// --- mode selection / priority (issue #212: "preserve existing Anthropic
// API path when ANTHROPIC_API_KEY is intentionally configured"). These
// functions read process.env on every call (no module-level caching), so
// no require-cache reload is needed - just set/restore env around the call.

test("bridge disabled: not active even with no API key", () => {
  withEnv({}, () => {
    assert.equal(bridgeForModeTests.claudeBridgeEnabled(), false);
    assert.equal(bridgeForModeTests.claudeBridgeActive(), false);
  });
});

test("API mode still wins when both a key and the bridge flag are set", () => {
  withEnv({ CLAUDE_CODE_BRIDGE_ENABLED: "1", ANTHROPIC_API_KEY: "sk-configured" }, () => {
    assert.equal(bridgeForModeTests.claudeBridgeEnabled(), true);
    assert.equal(bridgeForModeTests.hasAnthropicApiKey(), true);
    assert.equal(bridgeForModeTests.claudeBridgeActive(), false);
  });
});

test("bridge mode without API key is active", () => {
  withEnv({ CLAUDE_CODE_BRIDGE_ENABLED: "1" }, () => {
    assert.equal(bridgeForModeTests.claudeBridgeActive(), true);
  });
});

// --- validateClaudeResultPayload: the fail-closed core ---

const bridge = bridgeForModeTests;

function validResult(overrides = {}) {
  return JSON.stringify({
    transport: bridge.RESULT_TRANSPORT,
    task_id: "TASK1",
    phase: "independent",
    task_sha256: "abc123",
    response: "Findings: looks fine. Risks: none.",
    ...overrides,
  });
}

const allowedCommit = { author: { login: "diyr1997" }, committer: { login: "diyr1997" } };

test("valid independent result imports successfully", () => {
  const result = bridge.validateClaudeResultPayload({
    rawText: validResult(),
    commit: allowedCommit,
    taskId: "TASK1",
    phase: "independent",
    taskSha256: "abc123",
  });
  assert.equal(result.ok, true);
  assert.match(result.response, /Findings/);
});

test("rejects malformed JSON", () => {
  const result = bridge.validateClaudeResultPayload({
    rawText: "{not valid json",
    commit: allowedCommit,
    taskId: "TASK1",
    phase: "independent",
    taskSha256: "abc123",
  });
  assert.equal(result.ok, false);
  assert.equal(result.reason, "MALFORMED_JSON");
});

test("rejects wrong transport marker", () => {
  const result = bridge.validateClaudeResultPayload({
    rawText: validResult({ transport: "SOMETHING_ELSE" }),
    commit: allowedCommit,
    taskId: "TASK1",
    phase: "independent",
    taskSha256: "abc123",
  });
  assert.equal(result.ok, false);
  assert.equal(result.reason, "WRONG_TRANSPORT_MARKER");
});

test("rejects wrong task_id", () => {
  const result = bridge.validateClaudeResultPayload({
    rawText: validResult({ task_id: "OTHER_TASK" }),
    commit: allowedCommit,
    taskId: "TASK1",
    phase: "independent",
    taskSha256: "abc123",
  });
  assert.equal(result.ok, false);
  assert.equal(result.reason, "WRONG_TASK_ID");
});

test("rejects wrong phase", () => {
  const result = bridge.validateClaudeResultPayload({
    rawText: validResult({ phase: "peer_review" }),
    commit: allowedCommit,
    taskId: "TASK1",
    phase: "independent",
    taskSha256: "abc123",
  });
  assert.equal(result.ok, false);
  assert.equal(result.reason, "WRONG_PHASE");
});

test("rejects a result from a GitHub author/committer outside the allowlist", () => {
  const result = bridge.validateClaudeResultPayload({
    rawText: validResult(),
    commit: { author: { login: "someone-else" }, committer: { login: "someone-else" } },
    taskId: "TASK1",
    phase: "independent",
    taskSha256: "abc123",
  });
  assert.equal(result.ok, false);
  assert.equal(result.reason, "WRONG_AUTHOR");
});

test("rejects a stale/changed task (task_sha256 mismatch)", () => {
  const result = bridge.validateClaudeResultPayload({
    rawText: validResult({ task_sha256: "different-hash" }),
    commit: allowedCommit,
    taskId: "TASK1",
    phase: "independent",
    taskSha256: "abc123",
  });
  assert.equal(result.ok, false);
  assert.equal(result.reason, "STALE_OR_CHANGED_TASK");
});

test("rejects an empty response", () => {
  const result = bridge.validateClaudeResultPayload({
    rawText: validResult({ response: "   " }),
    commit: allowedCommit,
    taskId: "TASK1",
    phase: "independent",
    taskSha256: "abc123",
  });
  assert.equal(result.ok, false);
  assert.equal(result.reason, "EMPTY_RESPONSE");
});

test("redacts secrets accidentally present in a response before accepting it", () => {
  const result = bridge.validateClaudeResultPayload({
    rawText: validResult({ response: "token=verysecret123456 looks fine" }),
    commit: allowedCommit,
    taskId: "TASK1",
    phase: "independent",
    taskSha256: "abc123",
  });
  assert.equal(result.ok, true);
  assert.match(result.response, /token=\[REDACTED\]/i);
});

// --- decideImportOutcome: unknown task / waiting / duplicate / stale result ---

test("unknown task: no bridge row means the task was never published", () => {
  const outcome = bridge.decideImportOutcome({
    bridgeRow: null,
    file: { sha: "x", text: validResult(), commit: allowedCommit },
    taskId: "TASK1",
    phase: "independent",
  });
  assert.equal(outcome.success, false);
  assert.equal(outcome.reason, "UNKNOWN_TASK");
});

test("still waiting: task published, no result file yet", () => {
  const outcome = bridge.decideImportOutcome({
    bridgeRow: { task_id: "TASK1", phase: "independent", task_sha256: "abc123", status: "PUBLISHED" },
    file: null,
    taskId: "TASK1",
    phase: "independent",
  });
  assert.equal(outcome.success, false);
  assert.equal(outcome.reason, "WAITING");
});

test("duplicate result: already imported, same file seen again is a harmless no-op", () => {
  const outcome = bridge.decideImportOutcome({
    bridgeRow: {
      task_id: "TASK1",
      phase: "independent",
      task_sha256: "abc123",
      status: "IMPORTED",
      result_sha: "sha-A",
    },
    file: { sha: "sha-A", text: validResult(), commit: allowedCommit },
    taskId: "TASK1",
    phase: "independent",
  });
  assert.equal(outcome.success, false);
  assert.equal(outcome.reason, "DUPLICATE_RESULT");
});

test("stale/changed result: already imported, a different file tries to replace it", () => {
  const outcome = bridge.decideImportOutcome({
    bridgeRow: {
      task_id: "TASK1",
      phase: "independent",
      task_sha256: "abc123",
      status: "IMPORTED",
      result_sha: "sha-A",
    },
    file: { sha: "sha-B", text: validResult(), commit: allowedCommit },
    taskId: "TASK1",
    phase: "independent",
  });
  assert.equal(outcome.success, false);
  assert.equal(outcome.reason, "STALE_OR_CHANGED_RESULT");
});

test("first valid result for a published, not-yet-imported task succeeds", () => {
  const outcome = bridge.decideImportOutcome({
    bridgeRow: { task_id: "TASK1", phase: "independent", task_sha256: "abc123", status: "PUBLISHED" },
    file: { sha: "sha-A", text: validResult(), commit: allowedCommit },
    taskId: "TASK1",
    phase: "independent",
  });
  assert.equal(outcome.success, true);
  assert.equal(outcome.resultSha, "sha-A");
});

// --- filenames / redaction sanity ---

test("task and result filenames are namespaced by task id and phase", () => {
  assert.equal(bridge.taskFilePath("TASK1", "independent"), ".ai-council-queue/claude-tasks/TASK1__independent.json");
  assert.equal(bridge.resultFilePath("TASK1", "peer_review"), ".ai-council-queue/claude-results/TASK1__peer_review.json");
});

test("redactPotentialSecrets strips obvious secrets", () => {
  const redacted = bridge.redactPotentialSecrets("api_key=sk-abc123 password: hunter2");
  assert.match(redacted, /api_key=\[REDACTED\]/i);
  assert.match(redacted, /password=\[REDACTED\]/i);
});
