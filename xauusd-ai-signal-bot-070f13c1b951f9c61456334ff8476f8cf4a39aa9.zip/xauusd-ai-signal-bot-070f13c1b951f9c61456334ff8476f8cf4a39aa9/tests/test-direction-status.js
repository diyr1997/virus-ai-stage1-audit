"use strict";

process.env.DIRECTION_STATUS_BOOTSTRAP_ENABLED = "0";
const Module = require("module");
const originalLoad = Module._load;
Module._load = function stubDependencies(request, parent, isMain) {
  if (request === "node-telegram-bot-api") return class TelegramBot {};
  if (request === "pg") return { Pool: class Pool {} };
  return originalLoad.call(this, request, parent, isMain);
};

const assert = require("assert");
const { aggregateDirectionComparisons, confidenceBucket } = require("../direction-status-bootstrap.js");

assert.strictEqual(confidenceBucket(89.9), "80-89");
assert.strictEqual(confidenceBucket(90), "90+");

const base = { horizon_seconds: 60, direction_confidence: 84, market_regime: "HIGH_VOL", trading_session: "LONDON" };
const report = aggregateDirectionComparisons([
  { ...base, comparison: "BOTH_CORRECT" },
  { ...base, comparison: "V2_BETTER" },
  { ...base, comparison: "LEGACY_BETTER" },
  { ...base, comparison: "BOTH_WRONG" },
  { ...base, flat_direction: true, comparison: "BOTH_WRONG" },
  { ...base, comparison: "V2_ONLY" },
]);

assert.strictEqual(report.horizons.length, 1);
assert.deepStrictEqual(
  Object.fromEntries(["total", "BOTH_CORRECT", "V2_BETTER", "LEGACY_BETTER", "BOTH_WRONG"].map((k) => [k, report.horizons[0][k]])),
  { total: 4, BOTH_CORRECT: 1, V2_BETTER: 1, LEGACY_BETTER: 1, BOTH_WRONG: 1 },
);
assert.strictEqual(report.horizons[0].v2Accuracy, 50);
assert.strictEqual(report.horizons[0].legacyAccuracy, 50);
assert.strictEqual(report.confidence[0].value, "80-89");
assert.strictEqual(report.regimes[0].value, "HIGH_VOL");
assert.strictEqual(report.sessions[0].value, "LONDON");
assert.strictEqual(report.excluded.flat, 1);
assert.strictEqual(report.excluded.noLegacyComparison, 1);
console.log("direction status aggregation: OK");
