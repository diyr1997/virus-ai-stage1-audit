"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");

process.env.WORKER_STATUS_BOOTSTRAP_ENABLED = "0";
const {
  BLOCK_EVENT_TYPES,
  MAX_TELEGRAM_TEXT,
  appendWithinTelegramLimit,
  augmentDbStatusText,
  cleanText,
  formatPipelineDiagnostics,
  formatWorkerDiagnostics,
  normalizeValue,
  rowsToMap,
} = require("../worker-status-bootstrap");

test("cleanText removes multiline control whitespace and clamps output", () => {
  assert.equal(cleanText(" a\n\tb   c ", 20), "a b c");
  assert.equal(cleanText("123456", 4), "1234");
});

test("normalizeValue accepts objects and JSON strings fail-closed", () => {
  assert.deepEqual(normalizeValue({ ok: true }), { ok: true });
  assert.deepEqual(normalizeValue('{"ok":true}'), { ok: true });
  assert.deepEqual(normalizeValue("not-json"), {});
});

test("rowsToMap keeps only approved worker state keys", () => {
  const map = rowsToMap([
    { key: "preflight", value: { overall: "PASS" }, updated_at: "2026-08-24T17:00:00Z" },
    { key: "secret", value: { token: "must-not-render" }, updated_at: "2026-08-24T17:00:00Z" },
  ]);
  assert.equal(map.has("preflight"), true);
  assert.equal(map.has("secret"), false);
});

test("formatter renders preflight market watchdog and last error without secrets", () => {
  const text = formatWorkerDiagnostics([
    {
      key: "preflight",
      updated_at: new Date().toISOString(),
      value: {
        overall: "FAIL",
        database_ok: true,
        mt5_demo_ok: true,
        time_trusted: true,
        tick_fresh: false,
        closed_m1_fresh: false,
        password: "never-show-this",
      },
    },
    {
      key: "market_state",
      updated_at: new Date().toISOString(),
      value: {
        state: "PAUSED",
        trade_allowed: false,
        reason: "GOLD quotes and closed M1 are stale",
      },
    },
    {
      key: "worker_watchdog",
      updated_at: new Date().toISOString(),
      value: {
        restart_requested: true,
        failures: 6,
        reason: "persistent get_tick failure",
      },
    },
    {
      key: "last_error",
      updated_at: new Date().toISOString(),
      value: { message: "MT5 reconnect failed" },
    },
  ]);

  assert.match(text, /Preflight: FAIL/);
  assert.match(text, /DB ✅/);
  assert.match(text, /TICK ❌/);
  assert.match(text, /M1 ❌/);
  assert.match(text, /Market: PAUSED/);
  assert.match(text, /вход заблокирован/);
  assert.match(text, /RESTART REQUESTED/);
  assert.match(text, /failures=6/);
  assert.match(text, /MT5 reconnect failed/);
  assert.doesNotMatch(text, /never-show-this/);
});

test("entry pipeline formatter shows candidate events and dedicated latest blocker", () => {
  const now = new Date().toISOString();
  const text = formatPipelineDiagnostics({
    candidate: {
      id: 42,
      created_at: now,
      expires_at: now,
      timeframe: "M5",
      side: "BUY",
      strength: 84,
      status: "CONFIRMED",
    },
    blocker: {
      created_at: now,
      event_type: "FAST_ENTRY_SLOT_BLOCKED",
      candidate_id: 42,
      payload: { reason: "SLOT_NOT_ALLOWED" },
    },
    events: [
      {
        created_at: now,
        event_type: "ENTRY_SKIPPED",
        payload: { reason: "NOT_ENOUGH_SAFE_MARGIN" },
      },
    ],
  });
  assert.match(text, /ENTRY PIPELINE/);
  assert.match(text, /#42/);
  assert.match(text, /M5 BUY/);
  assert.match(text, /84\/100/);
  assert.match(text, /Последний блок входа/);
  assert.match(text, /FAST_ENTRY_SLOT_BLOCKED/);
  assert.match(text, /SLOT_NOT_ALLOWED/);
  assert.match(text, /ENTRY_SKIPPED/);
  assert.match(text, /NOT_ENOUGH_SAFE_MARGIN/);
});

test("dedicated blocker query covers critical V9 fail-closed paths", () => {
  for (const eventType of [
    "FAST_ENTRY_BLOCKED",
    "ORDER_CLAIM_BLOCKED",
    "ORDER_SEND_AMBIGUOUS",
    "MT5_STATE_UNAVAILABLE",
    "RECONCILE_BLOCKED",
    "REVERSAL_NOT_IMPLEMENTED_SAFE_BLOCK",
  ]) {
    assert.equal(BLOCK_EVENT_TYPES.includes(eventType), true, `${eventType} must be visible in /db_status`);
  }
});

test("entry pipeline formatter explicitly says when no blocker exists", () => {
  const text = formatPipelineDiagnostics({ candidate: null, events: [], blocker: null });
  assert.match(text, /Последний блок входа: свежих записей нет/);
});

test("formatter is useful before new V9 worker has written diagnostic rows", () => {
  const text = formatWorkerDiagnostics([]);
  assert.match(text, /Preflight: ⏳/);
  assert.match(text, /Market: состояние worker пока не записано/);
  assert.match(text, /Watchdog: ✅/);
  assert.match(text, /Last error: ✅/);
});

test("Telegram length guard never lets diagnostics push text past safe limit", () => {
  const base = "x".repeat(MAX_TELEGRAM_TEXT - 100);
  const augmented = appendWithinTelegramLimit(base, "y".repeat(1000));
  assert.equal(augmented.length, MAX_TELEGRAM_TEXT);
  assert.equal(appendWithinTelegramLimit("x".repeat(MAX_TELEGRAM_TEXT), "suffix").length, MAX_TELEGRAM_TEXT);
});

test("augmentDbStatusText leaves unrelated Telegram messages untouched", async () => {
  assert.equal(await augmentDbStatusText("обычное сообщение"), "обычное сообщение");
});
