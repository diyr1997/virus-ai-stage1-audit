"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");

// Must stay inert on require: the door is opened by env, never by loading it.
delete process.env.VIRUS_AI_CHAT_ENABLED;
delete process.env.DATABASE_URL;
delete process.env.DATABASE_PUBLIC_URL;
const {
  buildCouncilTaskId,
  buildCompactContext,
  buildDigestPrompt,
  shouldHandle,
} = require("../virus-ai-chat-bootstrap");

test("a council task id is unique per chat and safe as an identifier", () => {
  assert.equal(buildCouncilTaskId(12345, 1700000000000), "CHAT_12345_1700000000000");
  assert.match(buildCouncilTaskId("owner"), /^CHAT_OWNER_\d+$/);
  // A hostile chat id must not escape into the identifier.
  assert.equal(
    buildCouncilTaskId("1; DROP TABLE ai_council_tasks--", 1),
    "CHAT_1_DROP_TABLE_AI_COUNCIL_TASKS--_1"
  );
  assert.match(buildCouncilTaskId(1, NaN), /^CHAT_1_\d+$/);
});

test("the chat context is the live snapshot, not the 94k master context", () => {
  const context = buildCompactContext({ m1: { close: 3000 }, trade: null }, ["gemini"]);
  assert.ok(context.includes("RUNTIME SNAPSHOT"));
  assert.ok(context.includes("3000"));
  assert.ok(context.includes("REAL trading is disabled"));
  // The whole point: a chat question must not drag the frozen project files
  // through every advisor on every phase.
  assert.ok(context.length < 4000, `context was ${context.length} chars`);
});

test("the digest prompt forbids inventing anything beyond the verdict", () => {
  const prompt = buildDigestPrompt("Почему не было сделки?", "VERDICT TEXT", ["deepseek", "gemini"]);
  assert.ok(prompt.includes("VERDICT TEXT"));
  assert.ok(prompt.includes("Почему не было сделки?"));
  assert.ok(prompt.includes("deepseek, gemini"));
  assert.ok(prompt.includes("Не выдумывай числа"));
  assert.ok(prompt.includes("простым русским языком"));
});

test("a digest with no advisors still renders instead of printing undefined", () => {
  const prompt = buildDigestPrompt("q", "v");
  assert.ok(prompt.includes("неизвестно"));
  assert.ok(!prompt.includes("undefined"));
});

test("the door stays shut while disabled, whoever writes", () => {
  assert.equal(shouldHandle({ chat: { id: 1 }, text: "привет" }), false);
});

const { seatingLine } = require("../virus-ai-chat-bootstrap");

test("the reply names who was missing and why, not just who answered", () => {
  // Observed live: the first real Council answer came back with one advisor at
  // the table and no way to tell whether the other two errored, were disabled
  // or were never configured.
  const line = seatingLine({
    readyAdvisors: ["gemini"],
    unavailableAdvisors: [
      { advisor: "deepseek", error: "AI API 402: Insufficient Balance" },
      { advisor: "grok", error: "NOT_CONFIGURED" },
    ],
  });
  assert.match(line, /за столом: gemini/);
  assert.match(line, /не ответили: deepseek \(AI API 402: Insufficient Balance\); grok \(NOT_CONFIGURED\)/);
  assert.ok(line.includes("\n"), "must be a real newline, not a literal backslash-n");
  assert.ok(!line.includes("\\n"), "a literal \\n would show as text in Telegram");
});

test("a full table says nothing about anyone missing", () => {
  const line = seatingLine({ readyAdvisors: ["gemini", "deepseek", "grok"], unavailableAdvisors: [] });
  assert.equal(line, "— за столом: gemini, deepseek, grok");
});

test("an empty table says so rather than printing an empty list", () => {
  assert.match(seatingLine({}), /за столом: никого/);
  assert.match(seatingLine(null), /за столом: никого/);
});

test("a multi-line advisor error is trimmed to its first line", () => {
  // Advisor errors can carry a whole stack; the reply must stay readable.
  const line = seatingLine({
    readyAdvisors: [],
    unavailableAdvisors: [{ advisor: "claude", error: "AI API 400: disabled\n  at fetch (x)\n  at y" }],
  });
  assert.match(line, /claude \(AI API 400: disabled\)/);
  assert.equal(line.split("\n").length, 2, "one seating line plus one missing line");
});

test("the context names who was invited, because the Council asked for it", () => {
  // Observed live: asked who was on the council, the Council answered that it
  // could not tell and refused to guess - correctly, because nothing in its
  // context said. This is who was invited; who answered is appended later.
  const context = buildCompactContext({ m1: null }, ["gemini", "deepseek", "grok"]);
  assert.match(context, /COUNCIL SEATS INVITED TO THIS TASK: gemini, deepseek, grok/);
  assert.match(context, /Do not claim which of them answered/);
});

test("an unknown roster says so rather than printing an empty list", () => {
  assert.match(buildCompactContext({ m1: null }, []), /INVITED TO THIS TASK: unknown/);
  assert.match(buildCompactContext({ m1: null }), /INVITED TO THIS TASK: unknown/);
});

test("naming the roster does not blow the context budget", () => {
  const context = buildCompactContext({ m1: { close: 3000 } }, ["gemini", "deepseek", "grok", "chatgpt"]);
  assert.ok(context.length < 4000, `context was ${context.length} chars`);
});
