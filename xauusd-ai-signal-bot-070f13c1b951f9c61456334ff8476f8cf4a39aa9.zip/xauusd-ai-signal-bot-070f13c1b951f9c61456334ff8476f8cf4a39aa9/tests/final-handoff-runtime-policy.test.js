"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");

const worker = fs.readFileSync("demo_mt5_worker/worker.py", "utf8");
const trader = fs.readFileSync("demo_mt5_worker/trader.py", "utf8");
const v9 = fs.readFileSync("demo_mt5_worker/trader_v9.py", "utf8");
const v2 = fs.readFileSync("demo_mt5_worker/trader_v9_hardened_v2.py", "utf8");
const v3 = fs.readFileSync("demo_mt5_worker/trader_v9_hardened_v3.py", "utf8");
const v4 = fs.readFileSync("demo_mt5_worker/trader_v9_hardened_v4.py", "utf8");
const v6 = fs.readFileSync("demo_mt5_worker/trader_v9_hardened_v6.py", "utf8");
const v7 = fs.readFileSync("demo_mt5_worker/trader_v9_hardened_v7.py", "utf8");
const bat = fs.readFileSync("demo_mt5_worker/start_demo_bot.bat", "utf8");
const launcher = fs.readFileSync("demo_mt5_worker/windows_launcher.py", "utf8");
const verifier = fs.readFileSync("demo_mt5_worker/verify_v9_package.py", "utf8");
const builder = fs.readFileSync("binance_xau/build_v9_download.py", "utf8");

test("automatic worker remains DEMO only", () => {
  assert.match(worker, /DEMO_ONLY = True/);
  assert.match(worker, /ACCOUNT_TRADE_MODE_DEMO/);
});

test("canonical trader is hardened V9 v7 with fresh account guard", () => {
  assert.match(trader, /DemoTrader = V9HardenedV7DemoTrader/);
  assert.match(v6, /class V9HardenedV6DemoTrader\(V9HardenedV5DemoTrader\)/);
  assert.match(v7, /class V9HardenedV7DemoTrader\(V9HardenedV6DemoTrader\)/);
  assert.match(v7, /def _fresh_demo_account_guard/);
  assert.match(v7, /FRESH_ACCOUNT_NOT_DEMO/);
  assert.match(v7, /FRESH_ACCOUNT_LOGIN_CHANGED/);
  assert.match(v7, /result = self\.mt5\.order_send\(request\)/);
  assert.match(verifier, /DemoTrader = V9HardenedV7DemoTrader/);
  assert.match(builder, /trader_v9_hardened_v7\.py/);
});

test("strong impulse fast-entry keeps threshold 80 and bypasses confirmation only", () => {
  assert.match(v4, /FAST_ENTRY_MIN_STRENGTH/);
  assert.match(v4, /"80"/);
  assert.match(v4, /STRONG_IMPULSE_BYPASS_CONFIRMATION_ONLY/);
  assert.match(v4, /CURRENT_PRICE_AT_OR_BELOW_SL/);
  assert.match(v4, /CURRENT_PRICE_AT_OR_ABOVE_SL/);
});

test("V9 removes arbitrary fixed position count policy", () => {
  assert.match(v9, /profile\.pop\("max_positions", None\)/);
  assert.match(v9, /def direction_guard/);
});

test("MT5 unavailable state fails closed and unresolved is reconciliation-only", () => {
  assert.match(v2, /positions_get returned None/);
  assert.match(v3, /UNRESOLVED_RECHECK_SECONDS/);
  assert.match(v3, /auto_retry/);
});

test("Windows BAT is minimal and delegates runtime logic to Python", () => {
  assert.match(bat, /windows_launcher\.py/);
  assert.doesNotMatch(bat, /STALE_FEED_RESTART_SECONDS/);
  assert.doesNotMatch(bat, /FAST_ENTRY_MIN_STRENGTH/);
  assert.match(launcher, /STALE_FEED_RESTART_SECONDS/);
  assert.match(launcher, /FAST_ENTRY_MIN_STRENGTH/);
  assert.match(launcher, /compileall\.compile_dir/);
  assert.match(launcher, /verify_v9_package\.py/);
  assert.match(launcher, /worker_watchdog_v2\.py/);
});

test("download builder normalizes BAT and CMD files to CRLF without BOM", () => {
  assert.match(builder, /utf-8-sig/);
  assert.match(builder, /replace\("\\n", "\\r\\n"\)/);
  assert.match(builder, /\.bat/);
  assert.match(builder, /\.cmd/);
});
