"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");

const { assessCandidateTrust, strengthBucket } = require("../historical-trust-gate-bootstrap");

function candidate(tf, side, strength) {
  return [
    1,
    new Date(Date.now() + 60_000).toISOString(),
    tf,
    side,
    strength,
    4500,
    4495,
    4490,
    4510,
    4520,
    4530,
    "{}",
  ];
}

test("strength buckets preserve 80 fast-entry boundary", () => {
  assert.equal(strengthBucket(69), "60-69");
  assert.equal(strengthBucket(70), "70-79");
  assert.equal(strengthBucket(80), "80-89");
  assert.equal(strengthBucket(90), "90-100");
});

test("blocks historically toxic M30 SELL 60-69", () => {
  const out = assessCandidateTrust(candidate("M30", "SELL", 65));
  assert.equal(out.allow, false);
  assert.equal(out.key, "M30|SELL|60-69");
  assert.equal(out.evidence.acc30d, 8.33);
});

test("blocks historically toxic M15 SELL 80-89", () => {
  const out = assessCandidateTrust(candidate("M15", "SELL", 85));
  assert.equal(out.allow, false);
  assert.equal(out.key, "M15|SELL|80-89");
});

test("keeps strong M15 SELL 90+ path available", () => {
  const out = assessCandidateTrust(candidate("M15", "SELL", 95));
  assert.equal(out.allow, true);
});

test("does not globally block 80-89 because some BUY classes are good", () => {
  const out = assessCandidateTrust(candidate("M5", "BUY", 85));
  assert.equal(out.allow, true);
});

test("does not alter M1 SELL yet because audit did not justify a hard class block", () => {
  const out = assessCandidateTrust(candidate("M1", "SELL", 85));
  assert.equal(out.allow, true);
});
