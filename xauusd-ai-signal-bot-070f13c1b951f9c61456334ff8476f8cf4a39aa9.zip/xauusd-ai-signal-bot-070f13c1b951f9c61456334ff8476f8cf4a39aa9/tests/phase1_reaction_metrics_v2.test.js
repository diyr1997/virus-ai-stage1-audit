"use strict";
const assert=require("assert");
const {LAG_OFFSETS,computeEventMetrics,reactionLagProfile,reversalState,summarize}=require("../research/phase1_reaction_metrics_v2");
const base=Date.parse("2003-05-06T12:30:00Z");
function candle(ts,o,h,l,c){return{timestamp:ts,open:o,high:h,low:l,close:c}}
function rows60(){const out=[candle(base-60000,350,350.1,349.9,350)];for(let i=0;i<60;i++)out.push(candle(base+i*60000,350,350.05,349.95,350));return out}
const event={ordinal:0,family:"CPI",event_type:"CPI",year:2003,event_time_utc:new Date(base).toISOString(),official_source:"https://www.bls.gov/news.release/history/cpi_05062003.txt"};
{
 const r=rows60();r[1]=candle(base,350,350.3,349.98,350.2);r[2]=candle(base+60000,350.2,350.25,349.8,349.9);
 const m=computeEventMetrics(event,r,0.10);
 assert.equal(m.baseline_price,350); assert.equal(m.horizons["1"].target_timestamp_utc,new Date(base).toISOString()); assert.equal(m.horizons["1"].target_close,350.2);
 assert.equal(m.reversal.state,"REVERSAL"); assert.equal(m.reversal.initial_direction,"UP");
 assert.deepEqual(m.reaction_lag_profile.sampled_lag_minutes,LAG_OFFSETS);
}
{
 const r=rows60();r.splice(5,1);const m=computeEventMetrics(event,r,0.10);assert.equal(m.horizons["5"].status,"MISSING_M1");assert.equal(m.reversal.status,"MISSING_M1");assert.equal(m.reaction_lag_profile.full_0_60m_peak.status,"PARTIAL_MISSING_OR_INVALID_M1");
}
{
 const r=rows60();r[1]=candle(base,350,350.2,349.8,350);const m=computeEventMetrics(event,r,0.10);assert.equal(m.reversal.state,"AMBIGUOUS");
}
{
 const r=rows60();r[10]=candle(base+9*60000,350,349.9,350.1,350);const m=computeEventMetrics(event,r,0.10);assert.equal(m.horizons["15"].status,"INVALID_OHLC");
}
{
 const w=[candle(base,350,350.2,350.01,350.1),candle(base+60000,350.1,350.12,349.85,349.9),candle(base+120000,349.9,349.95,349.8,349.85)];const s=reversalState(w,350,0.1);assert.equal(s.initial_direction,"UP");assert.equal(s.state,"REVERSAL");assert.equal(s.opposite_threshold_seen,true);
}
{
 const s=summarize([{family:"CPI",horizons:{"60":{status:"OK"}},reversal:{status:"OK",state:"ONE_SIDED"}},{family:"CPI",horizons:{"60":{status:"OK"}},reversal:{status:"OK",state:"NO_THRESHOLD"}}],0.1);assert.equal(s.threshold_reach_rate,0.5);assert.equal(s.threshold_gate,"ACCEPTABLE_RANGE");
}
{
 const rows=[];
 for(let i=60;i>=1;i--)rows.push(candle(base-i*60000,350,350.1,349.9,350));
 for(let i=0;i<=60;i++){const close=i<5?350:(i===5?351:350.2);rows.push(candle(base+i*60000,350,Math.max(350.05,close),Math.min(349.95,close),close));}
 const byTs=new Map(rows.map(r=>[r.timestamp,r]));const p=reactionLagProfile(base,byTs,350);
 assert.equal(p.points["0"].move_abs,0);assert.equal(p.points["5"].move_abs,1);assert.equal(p.sampled_peak_abs_close_move.delay_min,5);assert.equal(p.full_0_60m_peak.status,"OK");assert.equal(p.full_0_60m_peak.delay_min,5);assert.equal(p.first_pre_60m_range_break.status,"OK");assert.equal(p.first_pre_60m_range_break.delay_min,5);
}
{
 const rows=[];
 for(let i=60;i>=1;i--)rows.push(candle(base-i*60000,350,350.1,349.9,350));
 for(let i=0;i<=60;i++){if(i===2)continue;const close=i<5?350:(i===5?351:350.2);rows.push(candle(base+i*60000,350,Math.max(350.05,close),Math.min(349.95,close),close));}
 const byTs=new Map(rows.map(r=>[r.timestamp,r]));const p=reactionLagProfile(base,byTs,350);
 assert.equal(p.points["2"].status,"MISSING_M1");assert.equal(p.full_0_60m_peak.status,"PARTIAL_MISSING_OR_INVALID_M1");assert.equal(p.first_pre_60m_range_break.status,"UNDETERMINED_MISSING_M1");assert.equal(p.first_pre_60m_range_break.delay_min,5);
}
{
 const s=summarize([
  {family:"CPI",status:"OK",horizons:{"60":{status:"OK"}},reversal:{status:"OK",state:"ONE_SIDED"},reaction_lag_profile:{status:"OK",sampled_peak_abs_close_move:{delay_min:5},full_0_60m_peak:{delay_min:5},first_pre_60m_range_break:{status:"OK",delay_min:5}}},
  {family:"CPI",status:"OK",horizons:{"60":{status:"OK"}},reversal:{status:"OK",state:"ONE_SIDED"},reaction_lag_profile:{status:"OK",sampled_peak_abs_close_move:{delay_min:15},full_0_60m_peak:{delay_min:10},first_pre_60m_range_break:{status:"OK",delay_min:3}}}
 ],0.1);
 assert.equal(s.by_family.CPI.median_sampled_peak_delay_min,10);assert.equal(s.by_family.CPI.median_full_0_60m_peak_delay_min,7.5);assert.equal(s.by_family.CPI.median_pre_60m_range_break_delay_min,4);
}
console.log("phase1_reaction_metrics_v2 tests passed");
