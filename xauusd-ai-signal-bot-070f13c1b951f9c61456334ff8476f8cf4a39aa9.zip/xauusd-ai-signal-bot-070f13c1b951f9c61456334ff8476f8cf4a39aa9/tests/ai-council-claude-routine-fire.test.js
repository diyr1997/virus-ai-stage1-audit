"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const path = require("path");

const routine = require(path.resolve(__dirname, "..", "ai-council-claude-routine-fire.js"));

const VALID_URL = "https://api.anthropic.com/v1/claude_code/routines/trig_test123/fire";
const ENV_KEYS = [
  "CLAUDE_ROUTINE_AUTOFIRE_ENABLED",
  "CLAUDE_ROUTINE_URL",
  "CLAUDE_ROUTINE_TOKEN",
  "CLAUDE_ROUTINE_FIRE_TIMEOUT_MS",
  "CLAUDE_BRIDGE_TASKS_DIR",
];

async function withEnv(env, fn) {
  const previous = {};
  for (const key of ENV_KEYS) {
    previous[key] = process.env[key];
    if (env[key] === undefined) delete process.env[key];
    else process.env[key] = env[key];
  }
  try {
    return await fn();
  } finally {
    for (const key of ENV_KEYS) {
      if (previous[key] === undefined) delete process.env[key];
      else process.env[key] = previous[key];
    }
  }
}

function validTaskObject(overrides = {}) {
  const payload = {
    transport: "AI_COUNCIL_CLAUDE_TASK_V1",
    task_id: "TASK1",
    phase: "independent",
    task_type: "review",
    task: "review",
    context_snapshot: "",
    peer_responses: [],
    created_at: "2026-09-13T00:00:00.000Z",
    ...overrides,
  };
  payload.task_sha256 = routine.taskPayloadSha256(payload);
  return payload;
}

function validTask(overrides = {}) {
  return JSON.stringify(validTaskObject(overrides));
}

test("Routine URL is restricted to the official Anthropic fire endpoint", () => {
  assert.equal(routine.validateRoutineFireUrl(VALID_URL).ok, true);
  for (const bad of [
    "http://api.anthropic.com/v1/claude_code/routines/trig_x/fire",
    "https://example.com/v1/claude_code/routines/trig_x/fire",
    "https://api.anthropic.com/v1/claude_code/routines/not_a_trigger/fire",
    "https://api.anthropic.com/v1/claude_code/routines/trig_x/fire?redirect=evil",
    "not-a-url",
  ]) {
    assert.equal(routine.validateRoutineFireUrl(bad).ok, false);
  }
});

test("autofire is fail-closed unless flag, trusted URL, and token all exist", async () => {
  await withEnv({ CLAUDE_ROUTINE_AUTOFIRE_ENABLED: "1" }, async () => {
    assert.equal(routine.routineAutofireConfigured(), false);
    assert.equal(routine.initialRoutineFireStatus(), "DISABLED");
  });
  await withEnv({ CLAUDE_ROUTINE_URL: VALID_URL, CLAUDE_ROUTINE_TOKEN: "secret" }, async () => {
    assert.equal(routine.routineAutofireConfigured(), false);
    assert.equal(routine.initialRoutineFireStatus(), "DISABLED");
  });
  await withEnv({
    CLAUDE_ROUTINE_AUTOFIRE_ENABLED: "1",
    CLAUDE_ROUTINE_URL: "https://evil.example/fire",
    CLAUDE_ROUTINE_TOKEN: "secret",
  }, async () => {
    assert.equal(routine.routineAutofireConfigured(), false);
    assert.equal(routine.initialRoutineFireStatus(), "DISABLED");
  });
  await withEnv({
    CLAUDE_ROUTINE_AUTOFIRE_ENABLED: "1",
    CLAUDE_ROUTINE_URL: VALID_URL,
    CLAUDE_ROUTINE_TOKEN: "secret",
  }, async () => {
    assert.equal(routine.routineAutofireConfigured(), true);
    assert.equal(routine.initialRoutineFireStatus(), "PENDING");
  });
});

test("validates exact task path, identity, and immutable task hash", async () => {
  await withEnv({}, async () => {
    const payload = validTaskObject();
    const rawTaskText = JSON.stringify(payload);
    const accepted = routine.validateRoutineFireTarget({
      taskId: "TASK1",
      phase: "independent",
      taskPath: ".ai-council-queue/claude-tasks/TASK1__independent.json",
      rawTaskText,
      expectedTaskSha256: payload.task_sha256,
    });
    assert.equal(accepted.ok, true);

    assert.equal(routine.validateRoutineFireTarget({
      taskId: "TASK1",
      phase: "independent",
      taskPath: "../TASK1__independent.json",
      rawTaskText,
      expectedTaskSha256: payload.task_sha256,
    }).ok, false);

    assert.equal(routine.validateRoutineFireTarget({
      taskId: "TASK1",
      phase: "peer_review",
      taskPath: ".ai-council-queue/claude-tasks/TASK1__peer_review.json",
      rawTaskText,
      expectedTaskSha256: payload.task_sha256,
    }).reason, "PHASE_CONTENT_MISMATCH");

    const mutated = { ...payload, task: "changed after publish" };
    assert.equal(routine.validateRoutineFireTarget({
      taskId: "TASK1",
      phase: "independent",
      taskPath: ".ai-council-queue/claude-tasks/TASK1__independent.json",
      rawTaskText: JSON.stringify(mutated),
      expectedTaskSha256: payload.task_sha256,
    }).reason, "TASK_CONTENT_SHA_MISMATCH");

    const wrongHashField = { ...payload, task_sha256: "0".repeat(64) };
    assert.equal(routine.validateRoutineFireTarget({
      taskId: "TASK1",
      phase: "independent",
      taskPath: ".ai-council-queue/claude-tasks/TASK1__independent.json",
      rawTaskText: JSON.stringify(wrongHashField),
      expectedTaskSha256: payload.task_sha256,
    }).reason, "TASK_SHA_FIELD_MISMATCH");
  });
});

test("sanitized task id must match exact published filename", async () => {
  await withEnv({}, async () => {
    const taskId = "TASK WITH SPACES";
    const payload = validTaskObject({ task_id: taskId });
    const result = routine.validateRoutineFireTarget({
      taskId,
      phase: "independent",
      taskPath: ".ai-council-queue/claude-tasks/TASK_WITH_SPACES__independent.json",
      rawTaskText: JSON.stringify(payload),
      expectedTaskSha256: payload.task_sha256,
    });
    assert.equal(result.ok, true);
  });
});

test("Retry-After is honored and bounded", () => {
  assert.equal(routine.retryAfterDelayMs("5", 0), 5000);
  assert.equal(routine.retryAfterDelayMs("999999", 0), 600000);
  assert.equal(routine.retryAfterDelayMs("not-a-date", 0), 0);
});

test("fires one exact selector with required headers and does not expose token", async () => {
  await withEnv({
    CLAUDE_ROUTINE_URL: VALID_URL,
    CLAUDE_ROUTINE_TOKEN: "super-secret-token",
  }, async () => {
    let captured;
    const result = await routine.fireClaudeRoutine({
      taskId: "TASK1",
      phase: "independent",
      taskPath: ".ai-council-queue/claude-tasks/TASK1__independent.json",
      taskSha256: "a".repeat(64),
      fetchImpl: async (url, options) => {
        captured = { url, options };
        return {
          ok: true,
          status: 200,
          headers: { get: () => null },
          text: async () => JSON.stringify({
            claude_code_session_id: "session_123",
            claude_code_session_url: "https://claude.ai/code/session_123",
          }),
        };
      },
    });
    assert.equal(result.sessionId, "session_123");
    assert.equal(captured.url, VALID_URL);
    assert.equal(captured.options.method, "POST");
    assert.equal(captured.options.headers.authorization, "Bearer super-secret-token");
    assert.equal(captured.options.headers["anthropic-beta"], "experimental-cc-routine-2026-04-01");
    const body = JSON.parse(captured.options.body);
    assert.match(body.text, /task_id=TASK1/);
    assert.match(body.text, /task_path=.ai-council-queue\/claude-tasks\/TASK1__independent.json/);
    assert.match(body.text, /task_sha256=a{64}/);
    assert.equal(JSON.stringify(result).includes("super-secret-token"), false);
  });
});

test("HTTP failures are classified conservatively", async () => {
  await withEnv({
    CLAUDE_ROUTINE_URL: VALID_URL,
    CLAUDE_ROUTINE_TOKEN: "secret",
  }, async () => {
    for (const [status, expected] of [
      [429, "FAILED_HTTP_SAFE"],
      [500, "FAILED_HTTP_AMBIGUOUS"],
      [400, "FAILED_VALIDATION"],
    ]) {
      await assert.rejects(
        routine.fireClaudeRoutine({
          taskId: "TASK1",
          phase: "independent",
          taskPath: ".ai-council-queue/claude-tasks/TASK1__independent.json",
          taskSha256: "a".repeat(64),
          fetchImpl: async () => ({
            ok: false,
            status,
            headers: { get: () => (status === 429 ? "7" : null) },
            text: async () => "{}",
          }),
        }),
        (error) => {
          assert.equal(routine.classifyRoutineFireFailure(error).status, expected);
          if (status === 429) assert.equal(routine.retryAfterDelayMs(error.retryAfter, 0), 7000);
          assert.equal(String(error.message).includes("secret"), false);
          return true;
        }
      );
    }
  });

  assert.equal(routine.classifyRoutineFireFailure({ code: "ENOTFOUND" }).status, "FAILED_HTTP_SAFE");
  assert.equal(routine.classifyRoutineFireFailure({ code: "EAI_AGAIN" }).status, "FAILED_HTTP_SAFE");
  assert.equal(routine.classifyRoutineFireFailure({ code: "ECONNREFUSED" }).status, "FAILED_HTTP_AMBIGUOUS");
  assert.equal(routine.classifyRoutineFireFailure({ name: "AbortError" }).status, "FAILED_HTTP_AMBIGUOUS");
});
