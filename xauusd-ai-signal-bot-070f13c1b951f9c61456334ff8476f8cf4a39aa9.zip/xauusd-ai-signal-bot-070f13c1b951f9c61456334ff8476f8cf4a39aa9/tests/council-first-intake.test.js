"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const {
  STATES,
  actionNeedsCouncil,
  checkMutationPolicy,
  makeIds,
  canTransition,
  assertTransition,
  deriveReviewState,
  parseMergeDecision,
  canonicalJson,
  hashFrozenContext,
  verifyFrozenContext,
  makeAuthorizationHash,
  timingSafeHashEqual,
  assertMutationPayloadSafety,
} = require("../council-first-intake");

const TEST_SECRET = "test-council-first-secret-0123456789-abcdef";

test("read-only requests bypass Council while unknown actions fail closed into Council", () => {
  assert.equal(actionNeedsCouncil("status"), false);
  assert.equal(actionNeedsCouncil("health_check"), false);
  assert.equal(actionNeedsCouncil("council_audit_persist"), false);
  assert.equal(actionNeedsCouncil("change_trading_logic"), true);
  assert.equal(actionNeedsCouncil("UNKNOWN_MUTATION_TYPE"), true);

  const unknown = checkMutationPolicy({
    mutationKind: "UNKNOWN_MUTATION_TYPE",
    mutation: { type: "UNKNOWN_MUTATION_TYPE" },
  });
  assert.equal(unknown.requiresCouncil, true);
  assert.equal(unknown.allowed, false);
});

test("same request creates deterministic request hash while IDs remain source-scoped", () => {
  const a = makeIds({ source: "chatgpt", rawRequest: "change M1", now: 1000 });
  const b = makeIds({ source: "telegram", rawRequest: "change M1", now: 1000 });
  assert.equal(a.requestHash, b.requestHash);
  assert.notEqual(a.intakeId, b.intakeId);
  assert.match(a.taskId, /^COUNCIL_INTAKE_/);
});

test("frozen context hashing is canonical for object key order and detects changes", () => {
  const first = { a: 1, b: { z: 3, c: 2 }, list: [3, 2, 1] };
  const reordered = { list: [3, 2, 1], b: { c: 2, z: 3 }, a: 1 };
  const changed = { a: 1, b: { z: 4, c: 2 }, list: [3, 2, 1] };
  assert.equal(canonicalJson(first), canonicalJson(reordered));
  assert.equal(hashFrozenContext(first), hashFrozenContext(reordered));
  assert.notEqual(hashFrozenContext(first), hashFrozenContext(changed));
  assert.equal(verifyFrozenContext(reordered, hashFrozenContext(first)), true);
  assert.equal(verifyFrozenContext(changed, hashFrozenContext(first)), false);
});

test("state machine permits reviewed -> draft -> draft review -> merge", () => {
  assert.equal(canTransition(STATES.REVIEWED, STATES.AUTHORIZED_FOR_DRAFT), true);
  assert.equal(canTransition(STATES.AUTHORIZED_FOR_DRAFT, STATES.DRAFT_REVIEW_PENDING), true);
  assert.equal(canTransition(STATES.DRAFT_REVIEW_PENDING, STATES.AUTHORIZED_FOR_MERGE), true);
});

test("state machine rejects direct received -> merge and other shortcuts", () => {
  assert.equal(canTransition(STATES.RECEIVED, STATES.AUTHORIZED_FOR_MERGE), false);
  assert.equal(canTransition(STATES.COUNCIL_PENDING, STATES.AUTHORIZED_FOR_DRAFT), false);
  assert.throws(
    () => assertTransition(STATES.RECEIVED, STATES.AUTHORIZED_FOR_MERGE),
    /INVALID_COUNCIL_FIRST_TRANSITION/
  );
});

test("Council snapshot with no final plan stays pending", () => {
  assert.equal(
    deriveReviewState({
      task: { final_plan: null },
      readyAdvisors: ["deepseek"],
      configuredAdvisors: ["deepseek"],
      quorum: 1,
    }),
    STATES.COUNCIL_PENDING
  );
});

test("provider outage produces explicit provisional review, not fake full consensus", () => {
  assert.equal(
    deriveReviewState({
      task: { final_plan: "review" },
      readyAdvisors: ["deepseek"],
      configuredAdvisors: ["deepseek", "gemini", "grok"],
      quorum: 1,
    }),
    STATES.PROVISIONAL_REVIEW
  );
});

test("all configured advisors complete becomes reviewed", () => {
  assert.equal(
    deriveReviewState({
      task: { final_plan: "review" },
      readyAdvisors: ["deepseek", "gemini"],
      configuredAdvisors: ["deepseek", "gemini"],
      quorum: 1,
    }),
    STATES.REVIEWED
  );
});

test("MERGE_DECISION parser is exact and fail-closed", () => {
  assert.equal(parseMergeDecision("MERGE_DECISION: APPROVE"), "APPROVE");
  assert.equal(parseMergeDecision("notes\nMERGE_DECISION: BLOCK"), "BLOCK");
  assert.throws(() => parseMergeDecision("Looks good"), /INVALID_MERGE_DECISION/);
  assert.throws(() => parseMergeDecision("MERGE_DECISION: approve"), /INVALID_MERGE_DECISION/);
  assert.throws(() => parseMergeDecision("MERGE_DECISION: APPROVE BLOCK"), /INVALID_MERGE_DECISION/);
  assert.throws(
    () => parseMergeDecision("MERGE_DECISION: APPROVE\nMERGE_DECISION: BLOCK"),
    /INVALID_MERGE_DECISION/
  );
});

test("authorization token hash uses HMAC and is bound to intake, stage and token", () => {
  const hash = makeAuthorizationHash("CFI_1", "draft", "secret-token", TEST_SECRET);
  assert.equal(
    timingSafeHashEqual(
      hash,
      makeAuthorizationHash("CFI_1", "draft", "secret-token", TEST_SECRET)
    ),
    true
  );
  assert.equal(
    timingSafeHashEqual(hash, makeAuthorizationHash("CFI_1", "merge", "secret-token", TEST_SECRET)),
    false
  );
  assert.equal(
    timingSafeHashEqual(hash, makeAuthorizationHash("CFI_2", "draft", "secret-token", TEST_SECRET)),
    false
  );
  assert.equal(
    timingSafeHashEqual(hash, makeAuthorizationHash("CFI_1", "draft", "wrong", TEST_SECRET)),
    false
  );
});

test("authorization hashing fails closed without a strong server secret", () => {
  assert.throws(
    () => makeAuthorizationHash("CFI_1", "draft", "token", "short"),
    /AUTH_SECRET|missing or too short/
  );
});

test("REAL-account mutations are blocked independently of Council authorization", () => {
  assert.throws(
    () => assertMutationPayloadSafety({ type: "ENABLE_REAL_TRADING" }),
    /DEMO_ONLY/
  );
  assert.throws(
    () => assertMutationPayloadSafety({ type: "CONFIG_CHANGE", accountMode: "REAL" }),
    /DEMO_ONLY/
  );
  assert.equal(assertMutationPayloadSafety({ type: "DEMO_CONFIG_CHANGE", accountMode: "DEMO" }), true);
});

test("Bot #1 and Bot #2 mutation scopes cannot be silently mixed", () => {
  assert.throws(
    () => assertMutationPayloadSafety({
      type: "STATE_CHANGE",
      sourceBot: "bot1",
      targetBot: "bot2",
    }),
    /BOT_SCOPE_ISOLATION/
  );
  assert.equal(
    assertMutationPayloadSafety({ type: "STATE_CHANGE", sourceBot: "bot2", targetBot: "bot2" }),
    true
  );
});
