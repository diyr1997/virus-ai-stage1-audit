"use strict";

/**
 * Local Ollama advisor tests.
 *
 * Every HTTP call is mocked: http://ollama.railway.internal:11434 only exists
 * inside the Railway private network and must never be contacted from CI or
 * from a developer machine.
 */

const test = require("node:test");
const assert = require("node:assert/strict");

const {
  LOCAL_ADVISOR_ID,
  localAdvisorEnabled,
  getOllamaConfig,
  callLocalQwen,
} = require("../local-advisor");
const { ALL_ADVISORS, ROLES, parseDisabledAdvisors } = require("../ai-council");
const { advisorConfigured } = require("../ai-council-persistent");
const { classifyAdvisorError } = require("../ai-council-dynamic");

const LOCAL_ENV_KEYS = [
  "LOCAL_ADVISOR_ENABLED",
  "OLLAMA_BASE_URL",
  "OLLAMA_MODEL",
  "OLLAMA_TIMEOUT_MS",
  "OLLAMA_MAX_OUTPUT_TOKENS",
];

function withEnv(values, fn) {
  const previous = new Map(LOCAL_ENV_KEYS.map((key) => [key, process.env[key]]));
  for (const key of LOCAL_ENV_KEYS) delete process.env[key];
  for (const [key, value] of Object.entries(values)) process.env[key] = value;
  const restore = () => {
    for (const [key, value] of previous) {
      if (value === undefined) delete process.env[key];
      else process.env[key] = value;
    }
  };
  const result = fn();
  if (result && typeof result.finally === "function") return result.finally(restore);
  restore();
  return result;
}

function withFetch(handler, fn) {
  const original = global.fetch;
  const calls = [];
  global.fetch = async (url, init) => {
    calls.push({ url: String(url), init });
    return handler(url, init);
  };
  const restore = () => {
    global.fetch = original;
  };
  const result = fn(calls);
  if (result && typeof result.finally === "function") return result.finally(restore);
  restore();
  return result;
}

function withCapturedWarnings(fn) {
  const original = console.warn;
  const lines = [];
  console.warn = (...args) => lines.push(args.join(" "));
  const restore = () => {
    console.warn = original;
  };
  const result = fn(lines);
  if (result && typeof result.finally === "function") return result.finally(restore);
  restore();
  return result;
}

function jsonResponse(body, status = 200) {
  return {
    ok: status >= 200 && status < 300,
    status,
    text: async () => JSON.stringify(body),
  };
}

test("local advisor is registered in the council with its own role", () => {
  assert.equal(LOCAL_ADVISOR_ID, "local-qwen");
  assert.ok(ALL_ADVISORS.includes("local-qwen"));
  assert.equal(typeof ROLES["local-qwen"], "string");
  assert.ok(ROLES["local-qwen"].length > 0);
});

test("local advisor honours AI_COUNCIL_DISABLED_ADVISORS like every other member", () => {
  assert.deepEqual(parseDisabledAdvisors("local-qwen"), ["local-qwen"]);
  assert.deepEqual(parseDisabledAdvisors(" DeepSeek ; LOCAL-QWEN "), [
    "deepseek",
    "local-qwen",
  ]);
  assert.deepEqual(parseDisabledAdvisors("gemini"), ["gemini"]);
});

test("defaults match the documented Railway Ollama service", () => {
  withEnv({}, () => {
    assert.equal(localAdvisorEnabled(), false);
    assert.deepEqual(getOllamaConfig(), {
      baseUrl: "http://ollama.railway.internal:11434",
      model: "qwen2.5:3b",
      timeoutMs: 120_000,
      maxOutputTokens: 512,
    });
  });
});

test("malformed numeric settings fall back to the defaults", () => {
  withEnv({ OLLAMA_TIMEOUT_MS: "not-a-number", OLLAMA_MAX_OUTPUT_TOKENS: "-5" }, () => {
    const config = getOllamaConfig();
    assert.equal(config.timeoutMs, 120_000);
    assert.equal(config.maxOutputTokens, 512);
  });
});

test("advisor is off by default and never opens a connection", async () => {
  await withEnv({}, () =>
    withFetch(
      () => {
        throw new Error("fetch must not be called while the advisor is disabled");
      },
      async (calls) => {
        assert.equal(advisorConfigured("local-qwen"), false);
        const error = await callLocalQwen("ping").then(
          () => null,
          (err) => err
        );
        assert.ok(error);
        assert.equal(error.code, "NOT_CONFIGURED");
        assert.equal(classifyAdvisorError(error), "NOT_CONFIGURED");
        assert.equal(calls.length, 0);
      }
    )
  );
});

test("LOCAL_ADVISOR_ENABLED=true makes the advisor configured", async () => {
  await withEnv({ LOCAL_ADVISOR_ENABLED: "true" }, async () => {
    assert.equal(localAdvisorEnabled(), true);
    assert.equal(advisorConfigured("local-qwen"), true);
  });
  await withEnv({ LOCAL_ADVISOR_ENABLED: "false" }, async () => {
    assert.equal(advisorConfigured("local-qwen"), false);
  });
});

test("enabled advisor posts the Ollama chat request and returns message.content", async () => {
  await withEnv({ LOCAL_ADVISOR_ENABLED: "1" }, () =>
    withFetch(
      () => jsonResponse({ message: { role: "assistant", content: "  local verdict  " } }),
      async (calls) => {
        const text = await callLocalQwen("review this diff");
        assert.equal(text, "local verdict");
        assert.equal(calls.length, 1);
        assert.equal(calls[0].url, "http://ollama.railway.internal:11434/api/chat");
        assert.equal(calls[0].init.method, "POST");
        assert.equal(calls[0].init.headers["content-type"], "application/json");
        assert.deepEqual(JSON.parse(calls[0].init.body), {
          model: "qwen2.5:3b",
          messages: [{ role: "user", content: "review this diff" }],
          stream: false,
          options: { temperature: 0.2, num_predict: 512 },
        });
      }
    )
  );
});

test("base url, model and output budget are configurable", async () => {
  await withEnv(
    {
      LOCAL_ADVISOR_ENABLED: "yes",
      OLLAMA_BASE_URL: "http://127.0.0.1:11434/",
      OLLAMA_MODEL: "qwen2.5:7b",
      OLLAMA_MAX_OUTPUT_TOKENS: "256",
    },
    () =>
      withFetch(
        () => jsonResponse({ message: { content: "ok" } }),
        async (calls) => {
          assert.equal(await callLocalQwen("hi"), "ok");
          assert.equal(calls[0].url, "http://127.0.0.1:11434/api/chat");
          const body = JSON.parse(calls[0].init.body);
          assert.equal(body.model, "qwen2.5:7b");
          assert.equal(body.options.num_predict, 256);
        }
      )
  );
});

test("an unreachable Ollama service is a plain advisor error, not a crash", async () => {
  await withEnv({ LOCAL_ADVISOR_ENABLED: "1" }, () =>
    withFetch(
      () => {
        throw Object.assign(new Error("fetch failed"), {
          cause: new Error("connect ECONNREFUSED 10.0.0.2:11434"),
        });
      },
      async () =>
        withCapturedWarnings(async (warnings) => {
          const error = await callLocalQwen("ping").then(
            () => null,
            (err) => err
          );
          assert.ok(error);
          assert.match(error.message, /Ollama is unreachable/);
          assert.match(error.message, /ollama\.railway\.internal:11434/);
          assert.equal(classifyAdvisorError(error), "TEMPORARY_ERROR");
          assert.equal(warnings.length, 1);
          assert.match(warnings[0], /LOCAL ADVISOR \(local-qwen\): Ollama is unreachable/);
        })
    )
  );
});

test("an HTTP error from Ollama is reported with its status", async () => {
  await withEnv({ LOCAL_ADVISOR_ENABLED: "1" }, () =>
    withFetch(
      () => jsonResponse({ error: 'model "qwen2.5:3b" not found' }, 404),
      async () =>
        withCapturedWarnings(async (warnings) => {
          const error = await callLocalQwen("ping").then(
            () => null,
            (err) => err
          );
          assert.ok(error);
          assert.equal(error.statusCode, 404);
          assert.match(error.message, /Ollama API 404/);
          assert.match(error.message, /not found/);
          assert.match(warnings[0], /LOCAL ADVISOR \(local-qwen\): Ollama API 404/);
        })
    )
  );
});

test("an empty completion is rejected instead of being stored as an answer", async () => {
  await withEnv({ LOCAL_ADVISOR_ENABLED: "1" }, () =>
    withFetch(
      () => jsonResponse({ message: { content: "   " } }),
      async () => {
        await assert.rejects(callLocalQwen("ping"), /empty response/);
      }
    )
  );
});

test("a hung Ollama request is aborted by OLLAMA_TIMEOUT_MS", async () => {
  await withEnv({ LOCAL_ADVISOR_ENABLED: "1", OLLAMA_TIMEOUT_MS: "5000" }, () =>
    withFetch(
      (_url, init) =>
        new Promise((_resolve, reject) => {
          init.signal.addEventListener("abort", () =>
            reject(
              Object.assign(new Error("This operation was aborted"), {
                name: "AbortError",
              })
            )
          );
        }),
      async () =>
        withCapturedWarnings(async (warnings) => {
          const started = Date.now();
          const error = await callLocalQwen("ping").then(
            () => null,
            (err) => err
          );
          assert.ok(error);
          assert.match(error.message, /timed out after 5000 ms/);
          assert.equal(classifyAdvisorError(error), "TIMEOUT");
          assert.ok(Date.now() - started >= 4_000);
          assert.match(warnings[0], /LOCAL ADVISOR \(local-qwen\): Ollama request timed out/);
        })
    )
  );
});

test("local-qwen resolves through the shared provider dispatcher", async () => {
  const { callProvider } = require("../ai-providers");
  await withEnv({ LOCAL_ADVISOR_ENABLED: "1" }, () =>
    withFetch(
      () => jsonResponse({ message: { content: "dispatched" } }),
      async (calls) => {
        assert.equal(await callProvider("local-qwen", "ping"), "dispatched");
        assert.equal(calls.length, 1);
      }
    )
  );
});
