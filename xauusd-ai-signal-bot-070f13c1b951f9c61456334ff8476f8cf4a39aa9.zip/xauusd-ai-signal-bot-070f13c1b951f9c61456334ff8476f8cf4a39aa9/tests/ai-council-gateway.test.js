"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const {
  taskIdForIssue,
  taskIdForQueueFile,
  safeTaskId,
  isGatewayIssue,
  redactPotentialSecrets,
  issueTaskText,
  parseQueuePayload,
  isAllowedQueueAuthor,
  retryPendingCouncilTasks,
  retryPendingGatewayCouncilTasks,
} = require("../ai-council-gateway");

test("gateway accepts only marked owner issues", () => {
  const issue = {
    number: 42,
    title: "[AI COUNCIL] Review V9",
    body: "<!-- AI_COUNCIL_GATEWAY -->\nCheck V9",
    user: { login: "diyr1997" },
  };
  assert.equal(isGatewayIssue(issue), true);
  assert.equal(taskIdForIssue(issue.number), "CHAT_GITHUB_ISSUE_42");
});

test("gateway rejects unmarked issue", () => {
  const issue = {
    title: "Normal issue",
    body: "Check V9",
    user: { login: "diyr1997" },
  };
  assert.equal(isGatewayIssue(issue), false);
});

test("gateway redacts obvious secrets before council", () => {
  const redacted = redactPotentialSecrets("API_KEY=abc123 password:secret123 Bearer abcdefghijklmnop");
  assert.match(redacted, /API_KEY=\[REDACTED\]/i);
  assert.match(redacted, /password=\[REDACTED\]/i);
  assert.match(redacted, /Bearer \[REDACTED\]/i);
});

test("issue task text strips transport marker", () => {
  const issue = {
    title: "[AI COUNCIL] Review risk",
    body: "<!-- AI_COUNCIL_GATEWAY -->\nCheck basket risk",
  };
  const text = issueTaskText(issue);
  assert.equal(text.includes("AI_COUNCIL_GATEWAY"), false);
  assert.match(text, /Review risk/);
  assert.match(text, /Check basket risk/);
});

test("contents queue payload is validated and secrets are redacted", () => {
  const file = { name: "0001-smoke.json", sha: "abcdef1234567890" };
  const payload = parseQueuePayload(JSON.stringify({
    transport: "AI_COUNCIL_GATEWAY_V1",
    task_id: "smoke test 1",
    task_type: "chat_gateway",
    requested_by: "diyr1997",
    task: "Review connection. token=verysecret",
  }), file);
  assert.equal(payload.taskId, "SMOKE_TEST_1");
  assert.equal(payload.requestedBy, "diyr1997");
  assert.match(payload.task, /token=\[REDACTED\]/i);
});

test("contents queue rejects missing transport marker", () => {
  assert.throws(() => parseQueuePayload(JSON.stringify({ task: "x" }), { name: "bad.json" }), /transport marker/);
});

test("queue task id fallback is stable from name and blob sha", () => {
  assert.equal(
    taskIdForQueueFile({ name: "001-review-v9.json", sha: "abcdef1234567890" }),
    "CHAT_QUEUE_001-REVIEW-V9_ABCDEF123456"
  );
  assert.equal(safeTaskId("hello world"), "HELLO_WORLD");
});

test("queue author accepts allowed GitHub login only", () => {
  assert.equal(isAllowedQueueAuthor({ author: { login: "diyr1997" } }), true);
  assert.equal(isAllowedQueueAuthor({ author: { login: "someoneelse" } }), false);
});

// --- retry wiring: a task accepted by acceptNewIssue/acceptQueueFile only
// ever gets processCouncilTask() called once, at acceptance. An advisor
// phase stuck RETRY/PENDING there (e.g. the Claude Code Cloud bridge
// publishing a task and waiting on its result file) is never revisited
// unless each gateway pass also re-drains the shared non-COMPLETE task
// queue. This guards that wiring stays in place structurally, without
// mocking pg/fetch (this repo's tests never mock those).

test("retryPendingCouncilTasks is exported and callable", () => {
  assert.equal(typeof retryPendingCouncilTasks, "function");
});

test("runGatewayPass re-drains pending council tasks before handling new issues/files", () => {
  const source = fs.readFileSync(
    path.resolve(__dirname, "..", "ai-council-gateway.js"),
    "utf8"
  );
  const bodyMatch = source.match(/async function runGatewayPass\(\)[\s\S]*?\n}\n/);
  assert.ok(bodyMatch, "runGatewayPass body not found");
  const body = bodyMatch[0];
  assert.match(body, /await\s+retryPendingCouncilTasks\(\)/);
  const retryIndex = body.indexOf("retryPendingCouncilTasks()");
  const issuePassIndex = body.indexOf("runIssuePass()");
  const contentsPassIndex = body.indexOf("runContentsPass()");
  assert.ok(retryIndex >= 0 && retryIndex < issuePassIndex);
  assert.ok(retryIndex >= 0 && retryIndex < contentsPassIndex);
});

test("retryPendingCouncilTasks swallows errors instead of throwing (keeps the gateway pass alive)", () => {
  const source = fs.readFileSync(
    path.resolve(__dirname, "..", "ai-council-gateway.js"),
    "utf8"
  );
  const bodyMatch = source.match(/async function retryPendingCouncilTasks\(\)[\s\S]*?\n}\n/);
  assert.ok(bodyMatch, "retryPendingCouncilTasks body not found");
  assert.match(bodyMatch[0], /catch\s*\(error\)/);
});

// --- retry scope: this gateway must only ever re-drive its OWN tasks
// (tracked in ai_council_gateway_issues/ai_council_gateway_files), never
// the shared ai_council_tasks table at large — other producers (book
// refresh, self-review, repo audit, ...) leave their own non-COMPLETE rows
// there, and re-driving those on every poll would mean unrelated advisor
// calls and a possible retry storm unrelated to this gateway's job.

function gatewaySource() {
  return fs.readFileSync(path.resolve(__dirname, "..", "ai-council-gateway.js"), "utf8");
}

function retryGatewayFunctionBody() {
  const match = gatewaySource().match(
    /async function retryPendingGatewayCouncilTasks\([\s\S]*?\n}\n/
  );
  assert.ok(match, "retryPendingGatewayCouncilTasks body not found");
  return match[0];
}

test("retryPendingGatewayCouncilTasks is exported and callable", () => {
  assert.equal(typeof retryPendingGatewayCouncilTasks, "function");
});

test("the gateway no longer imports the generic, repo-wide processPendingCouncilTasks", () => {
  const source = gatewaySource();
  assert.doesNotMatch(source, /processPendingCouncilTasks/);
});

test("gateway retry scopes to its own gateway mapping tables, not the shared task table at large", () => {
  const body = retryGatewayFunctionBody();
  assert.match(body, /ai_council_gateway_issues/);
  assert.match(body, /ai_council_gateway_files/);
  // Scoped by an IN (...) subquery against ai_council_tasks, not a bare
  // "select every non-COMPLETE row" query.
  assert.match(body, /t\.id\s+IN\s*\(/i);
});

test("gateway retry excludes COMPLETE tasks", () => {
  const body = retryGatewayFunctionBody();
  assert.match(body, /status\s*<>\s*'COMPLETE'/);
});

test("gateway retry dedupes a task_id present in both the issue and file mapping tables (UNION, not UNION ALL)", () => {
  const body = retryGatewayFunctionBody();
  assert.match(body, /\bUNION\b(?!\s+ALL)/);
  assert.doesNotMatch(body, /UNION ALL/);
});

test("gateway retry applies a LIMIT and a minimum-age backoff, not an unbounded re-drive", () => {
  const body = retryGatewayFunctionBody();
  assert.match(body, /LIMIT\s+\$1/);
  assert.match(body, /make_interval/);
  assert.match(body, /Math\.max\(1,\s*Math\.min\(20,\s*Number\(limit\)/);
});

test("gateway retry orders oldest-first", () => {
  const body = retryGatewayFunctionBody();
  assert.match(body, /ORDER BY\s+t\.updated_at\s+ASC/i);
});

test("a single failing task inside retryPendingGatewayCouncilTasks does not abort the rest of the batch", () => {
  const body = retryGatewayFunctionBody();
  assert.match(body, /for\s*\(const row of rows\)/);
  assert.match(body, /catch\s*\(error\)/);
});

test("retryPendingCouncilTasks delegates to the gateway-scoped retry, not a repo-wide one", () => {
  const source = gatewaySource();
  const bodyMatch = source.match(/async function retryPendingCouncilTasks\(\)[\s\S]*?\n}\n/);
  assert.ok(bodyMatch, "retryPendingCouncilTasks body not found");
  assert.match(bodyMatch[0], /retryPendingGatewayCouncilTasks\(/);
});
