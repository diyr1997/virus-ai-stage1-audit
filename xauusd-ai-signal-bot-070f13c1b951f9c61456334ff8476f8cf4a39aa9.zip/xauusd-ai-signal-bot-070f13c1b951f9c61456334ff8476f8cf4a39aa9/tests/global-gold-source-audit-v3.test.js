"use strict";
const assert=require("assert");
const {SOURCE_GROUPS,CADENCE_RULES,buildRegistry,trainingEligible}=require("../research/global_gold_source_audit_v3");

const r=buildRegistry();
assert.equal(r.schema,"GLOBAL_GOLD_SOURCE_AUDIT_V3");
assert.equal(r.research_only,true);
assert.ok(r.source_count>=150,"complete global source universe must remain represented");
assert.equal(r.sources.length,r.source_count);
assert.equal(new Set(r.sources.map(s=>s.source_id)).size,r.source_count,"source ids must be unique after dedup");
assert.equal(new Set(r.sources.map(s=>s.name)).size,r.source_count,"source names must be unique after dedup");
assert.ok(r.registry_sha256&&r.registry_sha256.length===64);

for(const [group,names] of Object.entries(SOURCE_GROUPS)){
  for(const name of names){
    const s=r.sources.find(x=>x.name===name);
    assert.ok(s,`missing source ${group}: ${name}`);
    assert.ok(s.regions.includes(group),`source ${name} lost region ${group}`);
  }
}

for(const s of r.sources){
  assert.ok(s.source_id);
  assert.ok(["PRIMARY","SECONDARY","MARKET_REFERENCE"].includes(s.role),`bad role ${s.name}`);
  assert.ok(CADENCE_RULES[s.cadence],`bad cadence ${s.name}`);
  assert.ok(s.historical_status,`missing historical status ${s.name}`);
  assert.equal(s.production_eligible,false,`research registry must never activate production: ${s.name}`);
}

function byName(name){const s=r.sources.find(x=>x.name===name);assert.ok(s,`not found ${name}`);return s;}
assert.equal(byName("Fed/FOMC").historical_status,"REPLAYED");
assert.equal(byName("BLS").replay_mode,"M1_LAG");
assert.equal(byName("CFTC").cadence,"WEEKLY");
assert.equal(byName("USGS gold/mineral statistics").replay_mode,"STRUCTURAL_ONLY");
assert.equal(byName("Reuters").role,"SECONDARY");
assert.equal(byName("Reuters").replay_mode,"LEAD_LAG_CONFIRMATION");
assert.equal(byName("Dukascopy XAUUSD spot").role,"MARKET_REFERENCE");
assert.equal(byName("OctaFX historical spot").role,"MARKET_REFERENCE");
assert.equal(byName("CME/COMEX").historical_status,"PENDING_HISTORICAL_AUDIT");
assert.equal(byName("LBMA").historical_status,"PENDING_HISTORICAL_AUDIT");
assert.equal(byName("SAFE").cadence,"MONTHLY");

assert.equal(trainingEligible(byName("BLS"),false),false,"point-in-time provenance is mandatory");
assert.equal(trainingEligible(byName("BLS"),true),true,"replayed source can become research-training eligible only with point-in-time evidence");
assert.equal(trainingEligible(byName("ECB"),true),false,"KEEP_SHADOW cannot enter training yet");
assert.equal(trainingEligible(byName("CME/COMEX"),true),false,"pending audit cannot enter training");

console.log(`global gold source audit v3 tests passed: ${r.source_count} unique sources`);
