"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");

function read(path) {
  return fs.readFileSync(path, "utf8");
}

test("current handoff documentation names V5 fast80 watchdog", () => {
  const ledger = read("PROJECT_LEDGER_2026-08-21_FINAL_HANDOFF.md");
  assert.match(ledger, /xauusd-demo-worker-v9-fenced-basket-v5-fast80-watchdog-2026-08-25/);
  assert.match(ledger, /handoff\/v9-clean-download-2026-08-21/);
  assert.match(ledger, /V9HardenedV4DemoTrader/);
  assert.match(ledger, /Fast-entry threshold remains 80\/100/);
  assert.match(ledger, /xauusd-demo-worker-v9\.zip/);
  assert.match(ledger, /xauusd-demo-worker-v9-v5-fast80-watchdog\.zip/);
});

test("reversal close-and-flip and Graph V7 remain unshipped", () => {
  const ledger = read("PROJECT_LEDGER_2026-08-21_FINAL_HANDOFF.md");
  assert.match(ledger, /Reversal close-and-flip V4 stays research\/shadow/);
  assert.match(ledger, /Graph V7 predictive changes stay research\/shadow/);
});
