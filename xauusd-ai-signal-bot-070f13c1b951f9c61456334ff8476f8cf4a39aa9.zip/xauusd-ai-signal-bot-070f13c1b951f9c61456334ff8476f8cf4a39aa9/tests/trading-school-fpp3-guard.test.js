"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");

// This unit test must exercise the real exported classifier. Prevent any DB
// side effects even if a developer happens to have a DATABASE_URL locally.
delete process.env.DATABASE_URL;
delete process.env.DATABASE_PUBLIC_URL;
const { classifyFpp3Pages } = require("../trading-school-fpp3-guard");

test("first canonical ERROR is retryable, same page after retry is blocked", () => {
  const rows = [
    { id: 10, url: "https://otexts.com/fpp3/graphics.html", status: "ERROR" },
    { id: 11, url: "https://otexts.com/fpp3/", status: "INGESTED" },
  ];
  const first = classifyFpp3Pages(rows, []);
  assert.deepEqual(first.retryableErrors, [10]);
  assert.deepEqual(first.blockedErrors, []);
  assert.equal(first.complete, false);

  const second = classifyFpp3Pages(rows, [10]);
  assert.deepEqual(second.retryableErrors, []);
  assert.deepEqual(second.blockedErrors, [10]);
  assert.equal(second.complete, false);
});

test("pending canonical page prevents completion", () => {
  const result = classifyFpp3Pages([
    { id: 1, url: "https://otexts.com/fpp3/", status: "INGESTED" },
    { id: 2, url: "https://otexts.com/fpp3/planning.html", status: "PENDING" },
  ]);
  assert.deepEqual(result.canonicalPending, [2]);
  assert.equal(result.complete, false);
});

test("non-content resource is classified without overwriting an ingested row", () => {
  const result = classifyFpp3Pages([
    { id: 20, url: "https://otexts.com/fpp3/extrafiles/review.pdf", status: "PENDING" },
    { id: 21, url: "https://otexts.com/fpp3/extrafiles/legacy.pdf", status: "INGESTED" },
  ]);
  assert.deepEqual(result.nonContent, [20]);
});

test("complete requires at least one ingested canonical page and no pending/errors", () => {
  assert.equal(classifyFpp3Pages([], []).complete, false);
  assert.equal(
    classifyFpp3Pages([
      { id: 1, url: "https://otexts.com/fpp3/", status: "INGESTED" },
      { id: 2, url: "https://otexts.com/fpp3/graphics.html", status: "INGESTED" },
    ]).complete,
    true
  );
});

test("a retired page no longer blocks completion", () => {
  // Production shape: three pages burned their single recovery retry while the
  // rest of the book was fine. While they sat in ERROR the book could never
  // complete, so every reconcile re-DEFERRED all fpp3 chunks. Once the guard
  // retires them to SKIPPED the book is allowed to finish.
  const stuck = [
    { id: 1, url: "https://otexts.com/fpp3/", status: "INGESTED" },
    { id: 2, url: "https://otexts.com/fpp3/graphics.html", status: "ERROR" },
    { id: 3, url: "https://otexts.com/fpp3/decomposition.html", status: "ERROR" },
    { id: 4, url: "https://otexts.com/fpp3/regression.html", status: "ERROR" },
  ];
  const before = classifyFpp3Pages(stuck, [2, 3, 4]);
  assert.deepEqual(before.blockedErrors, [2, 3, 4]);
  assert.equal(before.complete, false);

  const retired = stuck.map((row) =>
    row.status === "ERROR"
      ? { ...row, status: "SKIPPED", error: "FPP3_RETRY_EXHAUSTED" }
      : row
  );
  const after = classifyFpp3Pages(retired, [2, 3, 4]);
  assert.deepEqual(after.blockedErrors, []);
  assert.deepEqual(after.canonicalPending, []);
  assert.equal(after.complete, true);
});

test("retiring never resurrects a page that is still worth one retry", () => {
  const fresh = classifyFpp3Pages(
    [
      { id: 1, url: "https://otexts.com/fpp3/", status: "INGESTED" },
      { id: 2, url: "https://otexts.com/fpp3/graphics.html", status: "ERROR" },
    ],
    []
  );
  assert.deepEqual(fresh.retryableErrors, [2]);
  assert.deepEqual(fresh.blockedErrors, []);
  assert.equal(fresh.complete, false);
});
