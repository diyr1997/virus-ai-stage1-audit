import unittest

import numpy as np
import pandas as pd

from research.short_horizon_labels import (
    BarrierSpec,
    causal_atr,
    label_intervals,
    purged_train_mask,
    triple_barrier_labels,
    uniqueness_weights,
    validate_m1,
)


class ShortHorizonLabelsTests(unittest.TestCase):
    def sample(self, n=80):
        t = pd.date_range("2026-01-01", periods=n, freq="1min", tz="UTC")
        close = 2000.0 + np.arange(n) * 0.1
        return pd.DataFrame({
            "time": t,
            "open": close - 0.02,
            "high": close + 0.08,
            "low": close - 0.08,
            "close": close,
        })

    def test_validate_detects_duplicate(self):
        df = self.sample(20)
        df.loc[10, "time"] = df.loc[9, "time"]
        report = validate_m1(df)
        self.assertEqual(report["duplicate_times"], 1)

    def test_atr_is_causal_and_warms_up(self):
        df = self.sample(30)
        atr = causal_atr(df, 14)
        self.assertTrue(atr.iloc[:13].isna().all())
        self.assertTrue(np.isfinite(atr.iloc[14]))

    def test_triple_barrier_uses_future_path_only_for_label(self):
        df = self.sample(40)
        labels = triple_barrier_labels(df, BarrierSpec(horizon=5, tp_atr=0.5, sl_atr=0.5), atr_window=5)
        resolved = labels[labels.label != "UNRESOLVED"]
        self.assertTrue(len(resolved) > 0)
        self.assertTrue(set(resolved.label).issubset({"BUY", "SELL", "WAIT"}))

    def test_uniqueness_downweights_overlap(self):
        times = pd.date_range("2026-01-01", periods=3, freq="1min", tz="UTC")
        intervals = label_intervals(times, [5, 5, 5])
        w = uniqueness_weights(intervals)
        self.assertEqual(len(w), 3)
        self.assertTrue((w < 1.0).all())
        self.assertTrue((w > 0.0).all())

    def test_purge_removes_intersecting_intervals(self):
        times = pd.date_range("2026-01-01 00:00", periods=10, freq="1min", tz="UTC")
        intervals = label_intervals(times, [5] * 10)
        mask = purged_train_mask(
            intervals,
            pd.Timestamp("2026-01-01 00:08", tz="UTC"),
            pd.Timestamp("2026-01-01 00:09", tz="UTC"),
            embargo_minutes=1,
        )
        self.assertFalse(mask[4])  # [00:04,00:09] overlaps test/embargo
        self.assertTrue(mask[0])   # [00:00,00:05] safely before blocked window


if __name__ == "__main__":
    unittest.main()
