"use strict";

process.env.CURRENT_DATA_LAB_DISABLE_AUTOSTART = "1";

const fs = require("fs");
const path = require("path");
const test = require("node:test");
const assert = require("node:assert/strict");
const { auditCandles } = require("../training-data-policy");
const {
  assertMemorySafety,
  newDataCooldownPassed,
  withTimeout,
} = require("../training-current-data-lab-v2");

function sourceText() {
  return fs.readFileSync(path.join(__dirname, "..", "training-current-data-lab-v2.js"), "utf8");
}

test("memory guard accepts current dataset size and rejects huge in-memory export", () => {
  assert.equal(assertMemorySafety(6771, 500000), true);
  assert.throws(() => assertMemorySafety(5000001, 500000), /CURRENT_DATA_MEMORY_GUARD/);
});

test("six-hour new-data cooldown blocks repeated retraining", () => {
  const now = Date.UTC(2026, 7, 22, 12, 0, 0);
  assert.equal(newDataCooldownPassed(now - 5 * 60 * 60_000, now), false);
  assert.equal(newDataCooldownPassed(now - 6 * 60 * 60_000, now), true);
});

test("withTimeout fails a hanging operation without process exit", async () => {
  await assert.rejects(
    withTimeout(new Promise(() => {}), 10, "TEST_SCHEMA"),
    /TEST_SCHEMA_TIMEOUT_10ms/
  );
});

test("withTimeout consumes a rejection that arrives after timeout", async () => {
  let unhandled = false;
  const listener = () => { unhandled = true; };
  process.once("unhandledRejection", listener);

  const originalError = console.error;
  const logs = [];
  console.error = (...args) => logs.push(args.join(" "));
  try {
    const late = new Promise((_, reject) => setTimeout(() => reject(new Error("late-ddl-error")), 25));
    await assert.rejects(withTimeout(late, 5, "TEST_SCHEMA"), /TEST_SCHEMA_TIMEOUT_5ms/);
    await new Promise((resolve) => setTimeout(resolve, 40));
  } finally {
    console.error = originalError;
    process.removeListener("unhandledRejection", listener);
  }

  assert.equal(unhandled, false);
  assert.ok(logs.some((line) => line.includes("TEST_SCHEMA LATE_REJECTION") && line.includes("late-ddl-error")));
});

test("weekend-sized market gaps are reported but do not fail OHLC quality", () => {
  const friday = Date.UTC(2026, 7, 21, 20, 59, 0);
  const monday = Date.UTC(2026, 7, 24, 1, 0, 0);
  const mk = (timestamp, p) => ({ timestamp, open:p, high:p+1, low:p-1, close:p+0.2, volume:1 });
  const audit = auditCandles([mk(friday, 4300), mk(monday, 4310)]);
  assert.ok(audit.gapsOver5m >= 1);
  assert.equal(audit.qualityPass, true);
});

test("source contains distributed advisory lock and exact row-count mismatch guard", () => {
  const source = sourceText();
  assert.match(source, /pg_try_advisory_lock/);
  assert.match(source, /pg_advisory_unlock/);
  assert.match(source, /CURRENT_DATA_COUNT_MISMATCH/);
  assert.match(source, /CHAMPION_CHANGED_DURING_TRAINING/);
});

test("diagnostic instrumentation proves module, schema and scheduler path", () => {
  const source = sourceText();
  assert.match(source, /CURRENT DATA LAB V2 MODULE_LOADED/);
  assert.match(source, /start\(\) called/);
  assert.match(source, /ensureSchema START/);
  assert.match(source, /ensureSchema DONE/);
  assert.match(source, /CURRENT_DATA_SCHEMA/);
  assert.match(source, /LATE_REJECTION/);
  assert.match(source, /Scheduler decision:/);
});

test("stale reaper touches only RUNNING rows older than 30 minutes", () => {
  const source = sourceText();
  assert.match(source, /STALE_RUN_MS = 30 \* 60_000/);
  assert.match(source, /WHERE status='RUNNING' AND started_at < \$1/);
  assert.match(source, /status='STALE'/);
});

test("exploratory trainer purge covers target horizon plus max feature lookback", () => {
  const source = fs.readFileSync(path.join(__dirname, "..", "exploratory_train_h1.py"), "utf8");
  assert.match(source, /TARGET_HORIZON_BARS = 60/);
  assert.match(source, /MAX_FEATURE_LOOKBACK_BARS = 1200/);
  assert.match(source, /PURGE_BARS = TARGET_HORIZON_BARS \+ MAX_FEATURE_LOOKBACK_BARS/);
});

test("old weekend trainer remains available for rollback", () => {
  assert.equal(fs.existsSync(path.join(__dirname, "..", "weekend-upgrade.js")), true);
});
