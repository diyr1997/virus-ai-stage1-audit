"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const {
  classifyAdvisorError,
  computeCouncilState,
} = require("../ai-council-dynamic");

function run(advisor, phase, status, error = null) {
  return { advisor, phase, status, error };
}

test("unconfigured advisors do not block completion", () => {
  const runs = [
    run("deepseek", "independent", "SUCCESS"),
    run("deepseek", "peer_review", "SUCCESS"),
  ];
  const state = computeCouncilState({
    runs,
    configuredAdvisors: ["deepseek"],
    advisors: ["gemini", "deepseek", "claude", "grok"],
    minReadyAdvisors: 1,
  });
  assert.equal(state.status, "COMPLETE");
  assert.deepEqual(state.readyAdvisors, ["deepseek"]);
  assert.deepEqual(state.notConfigured.sort(), ["claude", "gemini", "grok"]);
});

test("configured but temporarily failed advisor produces READY_PARTIAL", () => {
  const runs = [
    run("deepseek", "independent", "SUCCESS"),
    run("deepseek", "peer_review", "SUCCESS"),
    run("gemini", "independent", "RETRY", "RATE_LIMITED"),
    run("gemini", "peer_review", "PENDING"),
  ];
  const state = computeCouncilState({
    runs,
    configuredAdvisors: ["deepseek", "gemini"],
    advisors: ["gemini", "deepseek"],
    minReadyAdvisors: 1,
  });
  assert.equal(state.status, "READY_PARTIAL");
  assert.deepEqual(state.readyAdvisors, ["deepseek"]);
  assert.deepEqual(state.pendingConfigured, ["gemini"]);
});

test("no successful advisor means WAITING_QUORUM", () => {
  const state = computeCouncilState({
    runs: [run("gemini", "independent", "RETRY", "RATE_LIMITED")],
    configuredAdvisors: ["gemini"],
    advisors: ["gemini"],
    minReadyAdvisors: 1,
  });
  assert.equal(state.status, "WAITING_QUORUM");
  assert.equal(state.hasQuorum, false);
});

test("claude waiting on the Claude Code Cloud bridge does not block dynamic quorum (issue #212)", () => {
  const runs = [
    run("deepseek", "independent", "SUCCESS"),
    run("deepseek", "peer_review", "SUCCESS"),
    run("claude", "independent", "RETRY", "WAITING_CLAUDE_CODE_CLOUD:WAITING"),
    run("claude", "peer_review", "PENDING"),
  ];
  const state = computeCouncilState({
    runs,
    configuredAdvisors: ["deepseek", "claude"],
    advisors: ["gemini", "deepseek", "claude", "grok"],
    minReadyAdvisors: 1,
  });
  assert.equal(state.status, "READY_PARTIAL");
  assert.equal(state.hasQuorum, true);
  assert.deepEqual(state.readyAdvisors, ["deepseek"]);
  assert.deepEqual(state.pendingConfigured, ["claude"]);
});

test("error classifier separates quota and credits", () => {
  assert.equal(classifyAdvisorError({ statusCode: 429, message: "quota exceeded" }), "RATE_LIMITED");
  assert.equal(classifyAdvisorError({ statusCode: 403, message: "no credits" }), "AUTH_OR_CREDITS");
  assert.equal(classifyAdvisorError(new Error("NOT_CONFIGURED")), "NOT_CONFIGURED");
});
