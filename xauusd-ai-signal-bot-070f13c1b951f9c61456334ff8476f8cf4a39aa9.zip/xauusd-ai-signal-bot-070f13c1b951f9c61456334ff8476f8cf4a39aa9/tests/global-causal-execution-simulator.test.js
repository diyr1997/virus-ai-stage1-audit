"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const { simulateForecasts } = require("../global_causal/execution_simulator");

function candle(ts, open, close) {
  return { timestamp: ts, open, high: Math.max(open, close), low: Math.min(open, close), close };
}

test("execution simulator permits multiple opportunities while enforcing cooldown", () => {
  const t = Date.parse("2020-01-02T10:00:00Z");
  const forecasts = [
    { forecast_id:"f1", as_of:new Date(t).toISOString(), forecast:{horizons:{"5m":{lean:"UP"}}} },
    { forecast_id:"f2", as_of:new Date(t+2*60000).toISOString(), forecast:{horizons:{"5m":{lean:"UP"}}} },
    { forecast_id:"f3", as_of:new Date(t+6*60000).toISOString(), forecast:{horizons:{"5m":{lean:"DOWN"}}} }
  ];
  const candles=[];
  for(let i=0;i<=12;i++) candles.push(candle(t+i*60000,100+i,101+i));
  const out=simulateForecasts(forecasts,candles,{starting_balance_usd:100,cooldown_minutes:5,lot_size:.01});
  assert.equal(out.summary.trades,2);
  assert.equal(out.summary.wins,1);
  assert.equal(out.summary.losses,1);
  assert.equal(out.daily.length,1);
});

test("execution simulator never trades neutral forecasts", () => {
  const t=Date.parse("2020-01-02T10:00:00Z");
  const out=simulateForecasts([{forecast_id:"f",as_of:new Date(t).toISOString(),forecast:{horizons:{"5m":{lean:"NEUTRAL"}}}}],[candle(t,100,100),candle(t+5*60000,100,100)]);
  assert.equal(out.summary.trades,0);
});
