"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");

const {
  parseRss,
  parseNumber,
  normalizeTeMessage,
  inferDirection,
  combine,
} = require("../fast-news-watcher");

test("parseNumber handles percent and K suffix", () => {
  assert.equal(parseNumber("3.2%"), 3.2);
  assert.equal(parseNumber("250K"), 250000);
});

test("hotter PPI surprise maps to first-order XAU SELL", () => {
  const event = normalizeTeMessage({
    topic: "calendar",
    data: { Country: "United States", Category: "Producer Prices", Event: "PPI MoM", Actual: "0.4%", Forecast: "0.2%", Previous: "0.1%", Importance: 3 },
  });
  const signal = inferDirection(event);
  assert.equal(signal.direction, "SELL");
  assert.equal(signal.family, "INFLATION");
});

test("cooler CPI surprise maps to first-order XAU BUY", () => {
  const signal = inferDirection({ category: "CPI inflation", title: "CPI MoM", actual: "0.1%", forecast: "0.3%", description: "" });
  assert.equal(signal.direction, "BUY");
});

test("unknown unstructured release is WAIT rather than guessed", () => {
  const signal = inferDirection({ category: "Other", title: "Official release published", description: "" });
  assert.equal(signal.direction, "WAIT");
});

test("news and fresh internal AI agreement boosts confidence", () => {
  const out = combine(
    { direction: "BUY", confidence: 74 },
    { fresh: true, direction: "BUY", strength: 81 }
  );
  assert.equal(out.direction, "BUY");
  assert.ok(out.confidence > 81);
});

test("news/AI conflict fails closed to WAIT", () => {
  const out = combine(
    { direction: "SELL", confidence: 74 },
    { fresh: true, direction: "BUY", strength: 85 }
  );
  assert.equal(out.direction, "WAIT");
});

test("RSS parser extracts official item without sending anything", () => {
  const rows = parseRss(
    `<rss><channel><item><title><![CDATA[PPI rose 0.3 percent]]></title><link>https://example.test/release</link><pubDate>Thu, 10 Sep 2026 12:30:00 GMT</pubDate><guid>x1</guid></item></channel></rss>`,
    { name: "BLS PPI", impact: 95 }
  );
  assert.equal(rows.length, 1);
  assert.equal(rows[0].source, "BLS PPI");
  assert.equal(rows[0].title, "PPI rose 0.3 percent");
});
