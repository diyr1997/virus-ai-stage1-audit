"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const {
  classifyTrainingTier,
  auditCandles,
  promotionDecision,
  dataFingerprint,
  shouldRunNewDataExperiment,
} = require("../training-data-policy");

// The shape trainModel() hands to the promotion gate for a dataset that passed
// every quality check, so each test below varies only the thing it is about.
function cleanAudit(rows) {
  return {
    rows,
    tradingDays: 0,
    duplicates: 0,
    invalid: 0,
    gapsOver5m: 0,
    maxGapMinutes: 1,
    firstTimestamp: 0,
    lastTimestamp: 0,
    qualityPass: true,
  };
}

function candle(i, dayOffset = 0) {
  const base = Date.UTC(2026, 7, 1 + dayOffset, 0, 0, 0);
  const timestamp = base + i * 60_000;
  const price = 4300 + i * 0.01;
  return {
    timestamp,
    open: price,
    high: price + 0.2,
    low: price - 0.2,
    close: price + 0.05,
    volume: 1,
  };
}

test("500 rows are audit-only, not idle failure", () => {
  const tier = classifyTrainingTier({ rows: 500, tradingDays: 1 });
  assert.equal(tier.tier, "AUDIT_ONLY");
  assert.equal(tier.canTrain, false);
  assert.equal(tier.canPromote, false);
});

test("1000, 2000 and 5000 rows run exploratory training", () => {
  for (const rows of [1000, 2000, 5000]) {
    const tier = classifyTrainingTier({ rows, tradingDays: 3 });
    assert.equal(tier.tier, "EXPLORATORY");
    assert.equal(tier.canTrain, true);
    assert.equal(tier.canPromote, false);
  }
});

test("8000 rows become candidate shadow but cannot promote", () => {
  const tier = classifyTrainingTier({ rows: 8000, tradingDays: 7 });
  assert.equal(tier.tier, "CANDIDATE_SHADOW");
  assert.equal(tier.canTrain, true);
  assert.equal(tier.canPromote, false);
});

test("15000 rows still cannot promote before ten trading days", () => {
  const tier = classifyTrainingTier({ rows: 15000, tradingDays: 9 });
  assert.equal(tier.canTrain, true);
  assert.equal(tier.canPromote, false);
  assert.match(tier.reason, /trading_days/);
});

test("15000 rows and ten trading days unlock champion-challenger evaluation", () => {
  const tier = classifyTrainingTier({ rows: 15000, tradingDays: 10 });
  assert.equal(tier.tier, "CHAMPION_CHALLENGER");
  assert.equal(tier.canTrain, true);
  assert.equal(tier.canPromote, true);
});

// The exact production incident: on 2026-09-17 the daily upgrade path promoted
// school-v1-h1-daily-t00 after training on ~13.8k rows / 11 trading days, in
// front of a model fitted on 1,545,615 samples. Accepted metrics are not enough.
test("a challenger trained on 13849 rows over 11 days cannot take the champion", () => {
  const tier = classifyTrainingTier({ rows: 13849, tradingDays: 11 });
  const decision = promotionDecision({
    accepted: true,
    tier,
    audit: cleanAudit(13849),
  });
  assert.equal(decision.promote, false);
  assert.match(decision.reason, /promotion_rows_below_15000/);
});

test("promotion needs the data gate AND the out-of-sample metrics", () => {
  const passingTier = classifyTrainingTier({ rows: 20000, tradingDays: 14 });
  assert.equal(passingTier.canPromote, true);

  assert.equal(
    promotionDecision({ accepted: false, tier: passingTier, audit: cleanAudit(20000) })
      .promote,
    false,
    "enough data must not promote a challenger the metrics rejected"
  );
  assert.equal(
    promotionDecision({ accepted: true, tier: passingTier, audit: cleanAudit(20000) })
      .promote,
    true
  );
});

test("dirty candles block promotion even when everything else passes", () => {
  const tier = classifyTrainingTier({ rows: 20000, tradingDays: 14 });
  const audit = { ...cleanAudit(20000), duplicates: 3, qualityPass: false };
  const decision = promotionDecision({ accepted: true, tier, audit });
  assert.equal(decision.promote, false);
  assert.equal(decision.reason, "data_quality_failed");
});

test("the promotion gate is fail-closed when a caller forgets an input", () => {
  const tier = classifyTrainingTier({ rows: 20000, tradingDays: 14 });
  assert.equal(promotionDecision().promote, false);
  assert.equal(promotionDecision({ accepted: true }).promote, false);
  assert.equal(
    promotionDecision({ accepted: true, audit: cleanAudit(20000) }).promote,
    false,
    "a missing tier must never be read as permission"
  );
  assert.equal(
    promotionDecision({ accepted: true, tier }).promote,
    false,
    "a missing audit must never be read as clean data"
  );
});

test("current-like 6771 rows are used for exploratory training", () => {
  const tier = classifyTrainingTier({ rows: 6771, tradingDays: 5 });
  assert.equal(tier.tier, "EXPLORATORY");
  assert.equal(tier.canTrain, true);
  assert.equal(tier.canPromote, false);
});

test("audit detects valid candles and trading days", () => {
  const rows = [candle(0, 0), candle(1, 0), candle(0, 1), candle(1, 1)];
  const audit = auditCandles(rows);
  assert.equal(audit.rows, 4);
  assert.equal(audit.tradingDays, 2);
  assert.equal(audit.duplicates, 0);
  assert.equal(audit.invalid, 0);
  assert.equal(audit.qualityPass, true);
});

test("audit fails closed on duplicate timestamps", () => {
  const a = candle(0, 0);
  const audit = auditCandles([a, { ...a }]);
  assert.equal(audit.duplicates, 1);
  assert.equal(audit.qualityPass, false);
});

test("data fingerprint is deterministic and changes with data", () => {
  const rows = [candle(0), candle(1)];
  const same = [candle(0), candle(1)];
  const changed = [candle(0), { ...candle(1), close: 9999 }];
  assert.equal(dataFingerprint(rows), dataFingerprint(same));
  assert.notEqual(dataFingerprint(rows), dataFingerprint(changed));
});

test("new-data trigger reruns after each configured growth step", () => {
  assert.equal(shouldRunNewDataExperiment({ currentRows: 6771, lastRows: 6000, step: 1000 }), false);
  assert.equal(shouldRunNewDataExperiment({ currentRows: 7001, lastRows: 6000, step: 1000 }), true);
});
