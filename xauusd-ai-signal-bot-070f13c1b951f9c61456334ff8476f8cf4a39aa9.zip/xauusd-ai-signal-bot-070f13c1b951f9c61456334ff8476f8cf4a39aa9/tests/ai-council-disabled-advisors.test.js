"use strict";

const assert = require("assert");
const path = require("path");

const modulePath = path.resolve(__dirname, "..", "ai-council.js");

function loadWithDisabled(value) {
  const previous = process.env.AI_COUNCIL_DISABLED_ADVISORS;
  if (value === undefined) delete process.env.AI_COUNCIL_DISABLED_ADVISORS;
  else process.env.AI_COUNCIL_DISABLED_ADVISORS = value;
  delete require.cache[modulePath];
  const loaded = require(modulePath);
  if (previous === undefined) delete process.env.AI_COUNCIL_DISABLED_ADVISORS;
  else process.env.AI_COUNCIL_DISABLED_ADVISORS = previous;
  delete require.cache[modulePath];
  return loaded;
}

{
  const council = loadWithDisabled(undefined);
  assert.deepStrictEqual(council.DISABLED_ADVISORS, []);
  assert.deepStrictEqual(council.ADVISORS, [
    "chatgpt",
    "gemini",
    "deepseek",
    "claude",
    "grok",
    "kimi",
    "perplexity",
    "local-qwen",
  ]);
}

{
  const council = loadWithDisabled("gemini,grok,claude");
  assert.deepStrictEqual(council.DISABLED_ADVISORS, ["gemini", "grok", "claude"]);
  assert.deepStrictEqual(council.ADVISORS, [
    "chatgpt",
    "deepseek",
    "kimi",
    "perplexity",
    "local-qwen",
  ]);
  assert.strictEqual(council.advisorDisabled("gemini"), true);
  assert.strictEqual(council.advisorDisabled("deepseek"), false);
}

{
  const council = loadWithDisabled(" GEMINI ; grok gemini,unknown ");
  assert.deepStrictEqual(council.DISABLED_ADVISORS, ["gemini", "grok"]);
  assert.deepStrictEqual(council.ADVISORS, [
    "chatgpt",
    "deepseek",
    "claude",
    "kimi",
    "perplexity",
    "local-qwen",
  ]);
}

{
  const council = loadWithDisabled("local-qwen");
  assert.deepStrictEqual(council.DISABLED_ADVISORS, ["local-qwen"]);
  assert.strictEqual(council.ADVISORS.includes("local-qwen"), false);
  assert.strictEqual(council.advisorDisabled("LOCAL-QWEN"), true);
}

console.log("AI Council disabled-advisor tests: PASS");
