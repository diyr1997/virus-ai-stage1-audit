"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const {
  EXECUTOR_MARKER,
  executorBranch,
  isForbiddenPath,
  dangerousAddedLines,
  validateExecutorResult,
} = require("../autonomy/claude-executor-core");

const BASE = "a".repeat(40);
const HEAD = "b".repeat(40);

function response(overrides = {}) {
  const payload = {
    version: EXECUTOR_MARKER,
    item_id: "0.R",
    status: "CHANGES_READY",
    branch: "autonomy/0.r-a1",
    base_sha: BASE,
    head_sha: HEAD,
    changed_files: ["src/fix.js", "tests/fix.test.js"],
    tests: [{ command: "node --test tests/fix.test.js", exit_code: 0, summary: "1 pass" }],
    summary: "safe remediation",
    rollback: "drop branch",
    ...overrides,
  };
  return `work complete\n${EXECUTOR_MARKER}\n${JSON.stringify(payload)}`;
}

test("executor branch is deterministic and isolated", () => {
  assert.equal(executorBranch("0.R", 1), "autonomy/0.r-a1");
  assert.equal(executorBranch("B 12", 3), "autonomy/b-12-a3");
});

test("executor forbids workflow, action and secret paths", () => {
  assert.equal(isForbiddenPath(".github/workflows/deploy.yml"), true);
  assert.equal(isForbiddenPath(".github/actions/local/action.yml"), true);
  assert.equal(isForbiddenPath("config/.env.production"), true);
  assert.equal(isForbiddenPath("keys/server.pem"), true);
  assert.equal(isForbiddenPath("trading_ai/model.py"), false);
});

test("explicit REAL/LIVE trading enablement in added diff lines is blocked", () => {
  assert.deepEqual(dangerousAddedLines("+VIRUS_AI_REAL_TRADING_ENABLED=1\n safe"), ["VIRUS_AI_REAL_TRADING_ENABLED=1"]);
  assert.deepEqual(dangerousAddedLines("+LIVE_TRADING: true\n+DEMO_ONLY=true"), ["LIVE_TRADING: true"]);
  assert.deepEqual(dangerousAddedLines("-REAL_TRADING=1\n+REAL_TRADING=0"), []);
});

test("valid structured result passes", () => {
  const result = validateExecutorResult({
    text: response(),
    itemId: "0.R",
    expectedBranch: "autonomy/0.r-a1",
    expectedBaseSha: BASE,
  });
  assert.equal(result.ok, true);
  assert.equal(result.result.head_sha, HEAD);
  assert.equal(result.result.tests[0].exit_code, 0);
});

test("wrong branch or base is rejected", () => {
  const branch = validateExecutorResult({
    text: response({ branch: "main" }),
    itemId: "0.R",
    expectedBranch: "autonomy/0.r-a1",
    expectedBaseSha: BASE,
  });
  assert.equal(branch.ok, false);
  assert.equal(branch.reason, "WRONG_BRANCH");

  const base = validateExecutorResult({
    text: response({ base_sha: "c".repeat(40) }),
    itemId: "0.R",
    expectedBranch: "autonomy/0.r-a1",
    expectedBaseSha: BASE,
  });
  assert.equal(base.ok, false);
  assert.equal(base.reason, "WRONG_BASE_SHA");
});

test("failed or missing tests are rejected", () => {
  const failed = validateExecutorResult({
    text: response({ tests: [{ command: "npm test", exit_code: 1, summary: "failed" }] }),
    itemId: "0.R",
    expectedBranch: "autonomy/0.r-a1",
    expectedBaseSha: BASE,
  });
  assert.equal(failed.ok, false);
  assert.equal(failed.reason, "TESTS_FAILED");

  const missing = validateExecutorResult({
    text: response({ tests: [] }),
    itemId: "0.R",
    expectedBranch: "autonomy/0.r-a1",
    expectedBaseSha: BASE,
  });
  assert.equal(missing.ok, false);
  assert.equal(missing.reason, "NO_TEST_EVIDENCE");
});

test("reported forbidden changed file is rejected", () => {
  const result = validateExecutorResult({
    text: response({ changed_files: ["src/fix.js", ".github/workflows/pwn.yml"] }),
    itemId: "0.R",
    expectedBranch: "autonomy/0.r-a1",
    expectedBaseSha: BASE,
  });
  assert.equal(result.ok, false);
  assert.equal(result.reason, "FORBIDDEN_CHANGED_PATH");
});
