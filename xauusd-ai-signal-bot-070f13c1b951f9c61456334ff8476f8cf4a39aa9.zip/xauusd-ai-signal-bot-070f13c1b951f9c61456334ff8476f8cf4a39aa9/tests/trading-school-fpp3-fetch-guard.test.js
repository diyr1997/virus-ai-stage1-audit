"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");

delete process.env.DATABASE_URL;
delete process.env.DATABASE_PUBLIC_URL;
process.env.TRADING_SCHOOL_FPP3_FETCH_GAP_MS = "1000";

const calls = [];
function fakeResponse(url, finalUrl = url, body = null) {
  const responseBody = body ?? `<html><body>${"useful forecasting text ".repeat(30)}</body></html>`;
  return {
    ok: true,
    status: 200,
    statusText: "OK",
    url: finalUrl,
    headers: new Headers({ "content-type": "text/html; charset=utf-8" }),
    async text() {
      return responseBody;
    },
  };
}

global.fetch = async (url) => {
  const value = String(url);
  calls.push(value);
  if (value.endsWith("/redirect-test.html")) {
    return fakeResponse(value, "https://example.com/redirected.html");
  }
  if (value.endsWith("/blank-test.html")) {
    return fakeResponse(
      value,
      value,
      `<html><head><style>${"x".repeat(1000)}</style></head><body><script>${"y".repeat(2000)}</script><nav>${"z".repeat(500)}</nav></body></html>`
    );
  }
  return fakeResponse(value);
};

require("../trading-school-fpp3-guard");

test("non-FPP3 fetch is passed through unchanged", async () => {
  const response = await global.fetch("https://example.com/data");
  assert.equal(response.url, "https://example.com/data");
  assert.equal(calls.at(-1), "https://example.com/data");
});

test("FPP3 fetch canonicalizes query/hash and returns textual response", async () => {
  const response = await global.fetch(
    "https://otexts.com/fpp3/graphics.html?utm=test#section"
  );
  assert.equal(calls.at(-1), "https://otexts.com/fpp3/graphics.html");
  const body = await response.text();
  assert.ok(body.length > 300);
  assert.equal(response.headers.get("content-type"), "text/html; charset=utf-8");
});

test("non-content FPP3 URL is rejected before network", async () => {
  const before = calls.length;
  await assert.rejects(
    global.fetch("https://otexts.com/fpp3/extrafiles/review.pdf"),
    /FPP3_NON_CONTENT_URL/
  );
  assert.equal(calls.length, before);
});

test("cross-origin FPP3 redirect is blocked", async () => {
  await assert.rejects(
    global.fetch("https://otexts.com/fpp3/redirect-test.html"),
    /FPP3_REDIRECT_BLOCKED/
  );
  assert.equal(calls.at(-1), "https://otexts.com/fpp3/redirect-test.html");
});

test("200 HTML with no visible content is rejected", async () => {
  await assert.rejects(
    global.fetch("https://otexts.com/fpp3/blank-test.html"),
    /FPP3_SHORT_VISIBLE_RESPONSE/
  );
});
