"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");

// No database in unit tests: the reader must load and stay inert without one.
delete process.env.DATABASE_URL;
delete process.env.DATABASE_PUBLIC_URL;
const {
  nextChunkAiState,
  shouldSynthesizeBook,
  aiTick,
} = require("../trading-school-reader");

test("a failing chunk retries, then is retired instead of retrying forever", () => {
  assert.deepEqual(nextChunkAiState(0, 3), { attempts: 1, status: "RETRY" });
  assert.deepEqual(nextChunkAiState(1, 3), { attempts: 2, status: "RETRY" });
  assert.deepEqual(nextChunkAiState(2, 3), { attempts: 3, status: "FAILED" });
  assert.deepEqual(nextChunkAiState(9, 3), { attempts: 10, status: "FAILED" });
});

test("a missing or junk attempt count never yields an unbounded retry", () => {
  assert.deepEqual(nextChunkAiState(undefined, 1), { attempts: 1, status: "FAILED" });
  assert.deepEqual(nextChunkAiState(null, 2), { attempts: 1, status: "RETRY" });
  assert.deepEqual(nextChunkAiState(-5, 1), { attempts: 1, status: "FAILED" });
  assert.deepEqual(nextChunkAiState("x", 1), { attempts: 1, status: "FAILED" });
  assert.equal(nextChunkAiState(0, 0).status, "FAILED");
});

test("one unreadable chunk no longer blocks whole-book synthesis", () => {
  // The regression: 87 understood + 1 permanently unreadable used to mean the
  // book was never synthesized, because done !== chunks.
  assert.equal(shouldSynthesizeBook({ chunks: 88, done: 87, resolved: 88 }), true);
  assert.equal(shouldSynthesizeBook({ chunks: 88, done: 88, resolved: 88 }), true);
});

test("synthesis still waits while any chunk is unread", () => {
  assert.equal(shouldSynthesizeBook({ chunks: 88, done: 87, resolved: 87 }), false);
  assert.equal(shouldSynthesizeBook({ chunks: 88, done: 0, resolved: 88 }), false);
  assert.equal(shouldSynthesizeBook({ chunks: 0, done: 0, resolved: 0 }), false);
  assert.equal(shouldSynthesizeBook(undefined), false);
});

test("aiTick is a safe no-op with no database", async () => {
  await assert.doesNotReject(() => aiTick());
});

const { shouldRetryBookIngest, MAX_BOOK_INGEST_ATTEMPTS } = require("../trading-school-reader");

test("a book whose download keeps failing eventually stops being retried", () => {
  // The regression, introduced and observed live: a PDF source whose URL the
  // reader cannot fetch failed once a minute, forever, because nothing counted
  // the attempts.
  assert.equal(shouldRetryBookIngest("ERROR", 0, 3), true);
  assert.equal(shouldRetryBookIngest("ERROR", 2, 3), true);
  assert.equal(shouldRetryBookIngest("ERROR", 3, 3), false);
  assert.equal(shouldRetryBookIngest("ERROR", 99, 3), false);
});

test("only a book already in ERROR is ever given up on", () => {
  // A healthy or not-yet-tried book must never be skipped, whatever the counter
  // happens to hold.
  for (const status of ["NEW", "QUEUED", "READING", "INGESTED", undefined, null, ""]) {
    assert.equal(shouldRetryBookIngest(status, 999, 1), true, `status ${status} must stay retryable`);
  }
});

test("a junk attempt bound falls back to the default instead of giving up at once", () => {
  assert.equal(shouldRetryBookIngest("ERROR", 0, 0), true);
  assert.equal(shouldRetryBookIngest("ERROR", 0, -5), true);
  assert.equal(shouldRetryBookIngest("ERROR", 0, "nonsense"), true);
  assert.equal(shouldRetryBookIngest("ERROR", "bad", 3), true);
  assert.ok(MAX_BOOK_INGEST_ATTEMPTS >= 1);
});

const { linkDiscoveryMode } = require("../trading-school-reader");

test("a source added to the manifest is allowed to crawl at all", () => {
  // The regression: link discovery was hard-coded to two book keys, so
  // babypips_pipsology and nist_statistics_handbook read their entry page and
  // stopped, with no way to say otherwise in the manifest.
  assert.equal(linkDiscoveryMode({ key: "babypips_pipsology" }), "entry_only");
  assert.equal(linkDiscoveryMode({ key: "nist_statistics_handbook" }), "entry_only");
});

test("the two original books keep exactly the behaviour they had", () => {
  assert.equal(linkDiscoveryMode({ key: "fpp3" }), "recursive");
  assert.equal(linkDiscoveryMode({ key: "zerodha_ta" }), "entry_only");
});

test("a source can declare its own crawl mode", () => {
  assert.equal(linkDiscoveryMode({ key: "x", link_discovery: "recursive" }), "recursive");
  assert.equal(linkDiscoveryMode({ key: "x", link_discovery: "none" }), "none");
  assert.equal(linkDiscoveryMode({ key: "x", link_discovery: "ENTRY_ONLY" }), "entry_only");
  // fpp3 may still be overridden explicitly rather than by its name.
  assert.equal(linkDiscoveryMode({ key: "fpp3", link_discovery: "none" }), "none");
});

test("an unrecognised or missing mode falls back, never crashes", () => {
  assert.equal(linkDiscoveryMode({ key: "x", link_discovery: "nonsense" }), "entry_only");
  assert.equal(linkDiscoveryMode({ key: "x", link_discovery: 42 }), "entry_only");
  assert.equal(linkDiscoveryMode({}), "entry_only");
  assert.equal(linkDiscoveryMode(null), "entry_only");
});
