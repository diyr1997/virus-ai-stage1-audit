"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");

const railpack = JSON.parse(fs.readFileSync("railpack.json", "utf8"));
const startCommand = String(railpack?.deploy?.startCommand || "");
const variables = railpack?.deploy?.variables || {};

test("Railway starts the isolated AI Council issue gateway", () => {
  assert.match(startCommand, /-r \.\/ai-council-gateway-bootstrap\.js/);
  assert.match(startCommand, /index\.js$/);
  assert.equal(variables.AI_COUNCIL_GATEWAY_ENABLED, "1");
  assert.equal(variables.EXTERNAL_ADVISORS_ENABLED, "1");
  assert.equal(variables.GITHUB_COUNCIL_TRANSPORT, "issues");
});

test("council runtime remains advisory-only and does not enable real trading", () => {
  assert.equal(variables.AI_COUNCIL_PERSISTENT_ENABLED, "0");
  assert.doesNotMatch(startCommand, /demo_mt5_worker|worker_auto|real.?trad/i);
});
