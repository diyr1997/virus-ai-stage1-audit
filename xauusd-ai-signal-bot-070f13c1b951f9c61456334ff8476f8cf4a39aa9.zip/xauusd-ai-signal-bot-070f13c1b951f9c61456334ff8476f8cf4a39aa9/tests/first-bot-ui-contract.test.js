"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");
const path = require("path");

process.env.GRAPH_V6_VERIFY_ONLY = "1";
process.env.SIGNAL_UI_COMPACT_VERIFY_ONLY = "1";

const { applyPatch: applyGraphPatch } = require("../graph-v6-bootstrap");
const { applyCompactPatch } = require("../signal-ui-compact-bootstrap");

const source = fs.readFileSync(path.join(__dirname, "..", "index.js"), "utf8");

test("first bot readable patch preserves photo send path and old graph geometry", () => {
  const patched = applyCompactPatch(applyGraphPatch(source));

  assert.match(patched, /await bot\.sendPhoto\(/);
  assert.match(patched, /const captionLimit = 950;/);
  assert.match(patched, /📊 Сила направления:/);
  assert.match(patched, /return `\$\{tf\}: \$\{tfIcon\} \$\{tfSide\} \| \$\{item\.strength\}\/100`/);
  assert.match(patched, /🟡 ЖДАТЬ ПОДТВЕРЖДЕНИЯ/);
  assert.match(patched, /✅ УСЛОВИЕ ВХОДА/);
  assert.match(patched, /❌ ОТМЕНА СЦЕНАРИЯ/);
  assert.match(patched, /Закрытая \$\{timeframe\} < \$\{invalidation\.toFixed\(2\)\}/);
  assert.match(patched, /Закрытая \$\{timeframe\} > \$\{invalidation\.toFixed\(2\)\}/);
  assert.match(patched, /🛡 SL/);
  assert.match(patched, /🎯 ЦЕЛИ/);
  assert.match(patched, /TP1: \$\{plan\.tp1\.toFixed\(2\)\}\nTP2: \$\{plan\.tp2\.toFixed\(2\)\}\nTP3: \$\{plan\.tp3\.toFixed\(2\)\}/);
  assert.match(patched, /const HEIGHT = 900;/);
  assert.match(patched, /const TOP = 170;/);
  assert.match(patched, /const BOTTOM = 712;/);
  assert.doesNotMatch(patched, /const HEIGHT = 720;/);
  assert.doesNotMatch(patched, /🔮 Прогнозный коридор:/);
  assert.doesNotMatch(patched, /📦 Верхний лимит лота по силе:/);
});
