"use strict";

const fs = require("fs");
const path = require("path");
const { Pool } = require("pg");
const { callDeepSeek } = require("./ai-providers");

const DATABASE_URL = String(process.env.DATABASE_URL || process.env.DATABASE_PUBLIC_URL || "").trim();
const RUN_KEY = "DEEPSEEK_FIRST_REVIEW_2026_08_20";
const EXTERNAL_ADVISORS_ENABLED = !/^(0|false|no|disabled)$/i.test(
  String(process.env.EXTERNAL_ADVISORS_ENABLED || "1")
);
const pool = DATABASE_URL ? new Pool({ connectionString: DATABASE_URL, max: 1, idleTimeoutMillis: 30000 }) : null;

function readSafe(rel, maxChars = 16000) {
  try {
    return fs.readFileSync(path.join(__dirname, rel), "utf8").slice(0, maxChars);
  } catch {
    return "";
  }
}

async function ensureSchema() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS ai_integration_reviews (
      run_key VARCHAR(100) PRIMARY KEY,
      provider VARCHAR(40) NOT NULL,
      status VARCHAR(24) NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      finished_at TIMESTAMPTZ,
      response TEXT,
      error TEXT,
      payload JSONB NOT NULL DEFAULT '{}'::jsonb
    )
  `);
}

async function run() {
  if (!EXTERNAL_ADVISORS_ENABLED) {
    console.log("🧠 DEEPSEEK FIRST REVIEW: disabled by EXTERNAL_ADVISORS_ENABLED=0");
    return;
  }
  if (!pool) {
    console.warn("🧠 DEEPSEEK FIRST REVIEW: PostgreSQL unavailable; skipped");
    return;
  }

  await ensureSchema();
  const payload = JSON.stringify({ model: process.env.DEEPSEEK_MODEL || "deepseek-v4-flash", shadow_only: true });
  const claimed = await pool.query(
    `INSERT INTO ai_integration_reviews(run_key,provider,status,payload)
     VALUES($1,'deepseek','RUNNING',$2::jsonb)
     ON CONFLICT(run_key) DO UPDATE
       SET status='RUNNING', finished_at=NULL, response=NULL, error=NULL, payload=EXCLUDED.payload
       WHERE ai_integration_reviews.status='FAILED'
     RETURNING run_key`,
    [RUN_KEY, payload]
  );
  if (!claimed.rowCount) {
    console.log("🧠 DEEPSEEK FIRST REVIEW: already successful or currently running; skipped");
    return;
  }

  const tasks = readSafe("AI_COUNCIL_NEXT_TASKS_2026-08-20.md", 18000);
  const ledger = readSafe("PROJECT_LEDGER_2026-08-20.md", 14000);

  const prompt = `You are DeepSeek acting as an independent engineering/trading-systems reviewer for a private XAU/USD DEMO-only project.\n\nIMPORTANT SAFETY:\n- Advisory only. Do not execute trades. Do not suggest enabling REAL trading.\n- Do not claim to have read source material that is not included below.\n- The Brian Shannon source is PARTIAL and missing Chapters 15-18; do not claim those chapters were reviewed.\n- Prefer measurable hypotheses, deterministic tests, rollback conditions, and causal/no-leakage features.\n\nPROJECT LEDGER:\n${ledger}\n\nCOUNCIL TASKS:\n${tasks}\n\nReturn a concise but concrete review with these sections:\n1) TOP 10 priorities for the project now.\n2) NEWS: missing primary/current sources for XAU/USD and how each should be filtered/scored.\n3) CODE/DEMO: likely failure modes or architecture risks and minimal safe patch ideas.\n4) TRADING SCHOOL: how to turn book-derived ideas into testable M1/M5/M15/M30/H1 hypotheses without blindly mixing authors.\n5) REVERSAL/PULLBACK: what should be tested before any close-and-flip logic is allowed.\n6) TEST MATRIX: exact shadow/OOS checks and rejection criteria.\n7) DISAGREEMENTS/UNCERTAINTY: what you cannot conclude from the supplied material.\n\nDo not produce production code yet. First produce review and test plan only.`;

  try {
    const response = String(await callDeepSeek(prompt) || "").trim();
    if (!response) throw new Error("DeepSeek returned an empty response");
    await pool.query(
      `UPDATE ai_integration_reviews SET status='SUCCESS',finished_at=NOW(),response=$2,error=NULL WHERE run_key=$1`,
      [RUN_KEY, response]
    );
    console.log(`🧠 DEEPSEEK FIRST REVIEW SUCCESS | model=${process.env.DEEPSEEK_MODEL || "deepseek-v4-flash"} | chars=${response.length}`);
    console.log(`🧠 DEEPSEEK REVIEW PREVIEW | ${response.replace(/\s+/g, " ").slice(0, 900)}`);
  } catch (error) {
    const message = String(error?.message || error).slice(0, 3000);
    await pool.query(
      `UPDATE ai_integration_reviews SET status='FAILED',finished_at=NOW(),error=$2 WHERE run_key=$1`,
      [RUN_KEY, message]
    ).catch(() => {});
    console.error(`❌ DEEPSEEK FIRST REVIEW: ${message}`);
  }
}

if (EXTERNAL_ADVISORS_ENABLED) {
  console.log("🧠 DEEPSEEK FIRST REVIEW: armed; starts in 55 sec");
  setTimeout(() => run().catch((e) => console.error("❌ DEEPSEEK FIRST REVIEW:", e)), 55000).unref();
} else {
  console.log("🧠 DEEPSEEK FIRST REVIEW: disabled by EXTERNAL_ADVISORS_ENABLED=0");
}

module.exports = { run };
