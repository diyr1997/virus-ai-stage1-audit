"use strict";

const { Pool } = require("pg");

const DATABASE_URL = String(process.env.DATABASE_URL || process.env.DATABASE_PUBLIC_URL || "").trim();
const SOURCE_KEY = "DEEPSEEK_FIRST_REVIEW_2026_08_20";
const EXPORT_KEY = "DEEPSEEK_FIRST_REVIEW_EXPORT_2026_08_20";
const EXTERNAL_ADVISORS_ENABLED = !/^(0|false|no|disabled)$/i.test(
  String(process.env.EXTERNAL_ADVISORS_ENABLED || "1")
);
const pool = DATABASE_URL ? new Pool({ connectionString: DATABASE_URL, max: 1, idleTimeoutMillis: 30000 }) : null;

async function run() {
  if (!EXTERNAL_ADVISORS_ENABLED) return;
  if (!pool) return;
  const done = await pool.query("SELECT 1 FROM ai_integration_reviews WHERE run_key=$1 AND status='SUCCESS'", [EXPORT_KEY]);
  if (done.rowCount) {
    console.log("🧠 DEEPSEEK REVIEW EXPORT: already completed");
    return;
  }
  const row = await pool.query("SELECT response FROM ai_integration_reviews WHERE run_key=$1 AND status='SUCCESS'", [SOURCE_KEY]);
  const text = String(row.rows?.[0]?.response || "").trim();
  if (!text) {
    console.warn("🧠 DEEPSEEK REVIEW EXPORT: source response unavailable");
    return;
  }
  const chunkSize = 3200;
  const chunks = [];
  for (let i = 0; i < text.length; i += chunkSize) chunks.push(text.slice(i, i + chunkSize));
  chunks.forEach((chunk, index) => console.log(`🧠 DEEPSEEK REVIEW FULL ${index + 1}/${chunks.length} | ${chunk}`));
  await pool.query(
    `INSERT INTO ai_integration_reviews(run_key,provider,status,finished_at,response,payload)
     VALUES($1,'deepseek','SUCCESS',NOW(),$2,$3::jsonb)
     ON CONFLICT(run_key) DO NOTHING`,
    [EXPORT_KEY, `exported ${chunks.length} chunks`, JSON.stringify({ source_key: SOURCE_KEY, chars: text.length, chunks: chunks.length })]
  );
}

if (EXTERNAL_ADVISORS_ENABLED) {
  console.log("🧠 DEEPSEEK REVIEW EXPORT: armed; starts in 70 sec");
  setTimeout(() => run().catch((e) => console.error("❌ DEEPSEEK REVIEW EXPORT:", e)), 70000).unref();
} else {
  console.log("🧠 DEEPSEEK REVIEW EXPORT: disabled by EXTERNAL_ADVISORS_ENABLED=0");
}

module.exports = { run };
