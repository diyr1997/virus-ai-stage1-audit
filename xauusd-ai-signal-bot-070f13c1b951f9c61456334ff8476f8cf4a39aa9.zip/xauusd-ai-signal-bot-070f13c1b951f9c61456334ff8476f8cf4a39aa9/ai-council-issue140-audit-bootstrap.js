"use strict";

const { runGatewayPass, redactPotentialSecrets } = require("./ai-council-gateway");
const { getCouncilSnapshot } = require("./ai-council-dynamic");

const ENABLED = !/^(0|false|no|disabled)$/i.test(
  String(process.env.AI_COUNCIL_ISSUE140_AUDIT_ENABLED || "0")
);
const ISSUE_NUMBER = 140;
const TASK_ID = "CHAT_GITHUB_ISSUE_140";
const MARKER = "<!-- DEEPSEEK_AUDIT_ISSUE_140 -->";
const GITHUB_TOKEN = String(process.env.GITHUB_REVIEW_TOKEN || "").trim();
const GITHUB_REPO = String(process.env.GITHUB_COUNCIL_REPO || "diyr1997/xauusd-ai-signal-bot").trim();
const START_DELAY_MS = Math.max(5_000, Number(process.env.AI_COUNCIL_ISSUE140_AUDIT_DELAY_MS || 8_000));

function deepSeekRun(snapshot, phase) {
  return (snapshot?.runs || []).find(
    (run) => run.advisor === "deepseek" && run.phase === phase && run.status === "SUCCESS" && String(run.response || "").trim()
  );
}

function bounded(value, limit = 24_000) {
  const text = redactPotentialSecrets(String(value || "").trim());
  return text.length <= limit ? text : `${text.slice(0, limit)}\n\n[TRUNCATED_BY_AUDIT_BOOTSTRAP: ${text.length - limit} chars]`;
}

function exactDeepSeekError(snapshot) {
  const unavailable = (snapshot?.unavailableAdvisors || []).find((item) => item.advisor === "deepseek");
  if (unavailable?.error) return String(unavailable.error);
  const failed = (snapshot?.runs || []).filter((run) => run.advisor === "deepseek" && run.status !== "SUCCESS");
  const last = failed[failed.length - 1];
  return String(last?.error || "NO_DEEPSEEK_RESULT_RECORDED");
}

function buildDeepSeekAuditText(snapshot) {
  const independent = deepSeekRun(snapshot, "independent");
  const peer = deepSeekRun(snapshot, "peer_review");
  const complete = Boolean(independent && peer);
  const lines = [
    MARKER,
    "## DeepSeek audit — issue #140",
    "",
    `task=${TASK_ID}`,
    `deepseek_audit=${complete ? "COMPLETE" : "PENDING_DEEPSEEK_AUDIT"}`,
    `council_status=${String(snapshot?.task?.status || "UNKNOWN")}`,
    "",
  ];
  if (!complete) {
    lines.push(`provider_error=${bounded(exactDeepSeekError(snapshot), 1200)}`, "");
  }
  lines.push(
    "### DeepSeek independent response",
    "",
    independent ? bounded(independent.response) : "PENDING_DEEPSEEK_AUDIT",
    "",
    "### DeepSeek peer review",
    "",
    peer ? bounded(peer.response) : "PENDING_DEEPSEEK_AUDIT"
  );
  return lines.join("\n").slice(0, 60_000);
}

function repoParts() {
  const [owner, repo] = GITHUB_REPO.split("/");
  if (!owner || !repo) throw new Error("GITHUB_COUNCIL_REPO must be owner/repo");
  return { owner, repo };
}

async function githubRequest(path, options = {}) {
  if (!GITHUB_TOKEN) throw new Error("GITHUB_REVIEW_TOKEN is not configured");
  const response = await fetch(`https://api.github.com${path}`, {
    ...options,
    headers: {
      accept: "application/vnd.github+json",
      authorization: `Bearer ${GITHUB_TOKEN}`,
      "x-github-api-version": "2022-11-28",
      "user-agent": "xauusd-ai-council-issue140-audit",
      ...(options.headers || {}),
    },
  });
  const raw = await response.text();
  const data = raw ? (() => { try { return JSON.parse(raw); } catch { return raw; } })() : null;
  if (!response.ok) throw new Error(`GitHub API ${response.status}: ${String(data?.message || raw).slice(0, 800)}`);
  return data;
}

async function alreadyPublished() {
  const { owner, repo } = repoParts();
  const comments = await githubRequest(`/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/issues/${ISSUE_NUMBER}/comments?per_page=100`);
  return (Array.isArray(comments) ? comments : []).some((comment) => String(comment?.body || "").includes(MARKER));
}

async function publishAudit() {
  console.log("🧠 ISSUE140 DEEPSEEK AUDIT: forcing live gateway pass");
  await runGatewayPass();
  const snapshot = await getCouncilSnapshot(TASK_ID);
  if (!snapshot) throw new Error(`${TASK_ID} snapshot missing after gateway pass`);
  if (await alreadyPublished()) {
    console.log("🧠 ISSUE140 DEEPSEEK AUDIT: already published; no duplicate comment");
    return;
  }
  const { owner, repo } = repoParts();
  const body = buildDeepSeekAuditText(snapshot);
  await githubRequest(`/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/issues/${ISSUE_NUMBER}/comments`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ body }),
  });
  console.log(`🧠 ISSUE140 DEEPSEEK AUDIT: published ${deepSeekRun(snapshot, "independent") && deepSeekRun(snapshot, "peer_review") ? "COMPLETE" : "PENDING_DEEPSEEK_AUDIT"}`);
}

if (ENABLED) {
  const timer = setTimeout(() => {
    publishAudit().catch((error) => console.warn(`⚠️ ISSUE140 DEEPSEEK AUDIT: ${error.message}`));
  }, START_DELAY_MS);
  timer.unref();
}

module.exports = { buildDeepSeekAuditText, exactDeepSeekError, publishAudit };
