"use strict";

const crypto = require("crypto");

const DEFAULTS = Object.freeze({
  exploratoryMinRows: 1000,
  promotionMinRows: 15000,
  promotionMinTradingDays: 10,
});

function finiteNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function classifyTrainingTier({ rows, tradingDays }, options = {}) {
  const cfg = { ...DEFAULTS, ...options };
  const count = Math.max(0, Math.floor(finiteNumber(rows)));
  const days = Math.max(0, Math.floor(finiteNumber(tradingDays)));

  if (count < cfg.exploratoryMinRows) {
    return {
      tier: "AUDIT_ONLY",
      canTrain: false,
      canPromote: false,
      reason: `rows_below_exploratory_min_${count}_of_${cfg.exploratoryMinRows}`,
    };
  }

  if (count < cfg.promotionMinRows || days < cfg.promotionMinTradingDays) {
    return {
      tier: count >= 8000 ? "CANDIDATE_SHADOW" : "EXPLORATORY",
      canTrain: true,
      canPromote: false,
      reason:
        count < cfg.promotionMinRows
          ? `promotion_rows_below_${cfg.promotionMinRows}`
          : `promotion_trading_days_below_${cfg.promotionMinTradingDays}`,
    };
  }

  return {
    tier: "CHAMPION_CHALLENGER",
    canTrain: true,
    canPromote: true,
    reason: "promotion_data_gate_passed",
  };
}

function utcDay(timestampMs) {
  const d = new Date(Number(timestampMs));
  return Number.isFinite(d.getTime()) ? d.toISOString().slice(0, 10) : null;
}

function auditCandles(candles) {
  const rows = Array.isArray(candles) ? candles : [];
  const seen = new Set();
  const days = new Set();
  let duplicates = 0;
  let invalid = 0;
  let gapsOver5m = 0;
  let maxGapMinutes = 0;
  let previousTs = null;

  for (const row of rows) {
    const ts = finiteNumber(row?.timestamp, NaN);
    const open = finiteNumber(row?.open, NaN);
    const high = finiteNumber(row?.high, NaN);
    const low = finiteNumber(row?.low, NaN);
    const close = finiteNumber(row?.close, NaN);

    if (![ts, open, high, low, close].every(Number.isFinite)) {
      invalid += 1;
      continue;
    }
    if (seen.has(ts)) duplicates += 1;
    seen.add(ts);
    const day = utcDay(ts);
    if (day) days.add(day);

    if (high < Math.max(open, close) || low > Math.min(open, close) || high < low) {
      invalid += 1;
    }

    if (previousTs !== null && ts > previousTs) {
      const gapMinutes = (ts - previousTs) / 60000;
      maxGapMinutes = Math.max(maxGapMinutes, gapMinutes);
      if (gapMinutes > 5) gapsOver5m += 1;
    }
    previousTs = ts;
  }

  const firstTs = rows.length ? finiteNumber(rows[0]?.timestamp, null) : null;
  const lastTs = rows.length ? finiteNumber(rows[rows.length - 1]?.timestamp, null) : null;
  return {
    rows: rows.length,
    tradingDays: days.size,
    duplicates,
    invalid,
    gapsOver5m,
    maxGapMinutes: Number(maxGapMinutes.toFixed(3)),
    firstTimestamp: firstTs,
    lastTimestamp: lastTs,
    qualityPass: rows.length > 0 && duplicates === 0 && invalid === 0,
  };
}

// A trained challenger may replace the live champion only when every gate
// agrees: the candles it learned from are clean, the dataset is large enough
// to generalise, and the out-of-sample metrics accepted it.
//
// This is deliberately fail-closed. A caller that forgets to pass the audit or
// the tier gets a refusal, not a promotion: the daily upgrade path used to skip
// these checks entirely and put a model trained on ~11 trading days in front of
// live signals.
function promotionDecision({ accepted, tier, audit } = {}) {
  if (!audit || audit.qualityPass !== true) {
    return { promote: false, reason: "data_quality_failed" };
  }
  if (!tier || tier.canPromote !== true) {
    return { promote: false, reason: String(tier?.reason || "tier_unknown") };
  }
  if (accepted !== true) {
    return { promote: false, reason: "oos_metrics_rejected" };
  }
  return { promote: true, reason: String(tier.reason || "promotion_data_gate_passed") };
}

function dataFingerprint(candles) {
  const rows = Array.isArray(candles) ? candles : [];
  const hash = crypto.createHash("sha256");
  hash.update(`rows=${rows.length}\n`);
  for (const row of rows) {
    hash.update(
      `${row?.timestamp ?? ""}|${row?.open ?? ""}|${row?.high ?? ""}|${row?.low ?? ""}|${row?.close ?? ""}|${row?.volume ?? ""}\n`
    );
  }
  return hash.digest("hex");
}

function shouldRunNewDataExperiment({ currentRows, lastRows, step = 1000 }) {
  const current = Math.max(0, Math.floor(finiteNumber(currentRows)));
  const previous = Math.max(0, Math.floor(finiteNumber(lastRows)));
  const threshold = Math.max(1, Math.floor(finiteNumber(step, 1000)));
  return current >= DEFAULTS.exploratoryMinRows && current - previous >= threshold;
}

module.exports = {
  DEFAULTS,
  classifyTrainingTier,
  auditCandles,
  promotionDecision,
  dataFingerprint,
  shouldRunNewDataExperiment,
};
