"use strict";

/**
 * Unified Trading Intelligence Core V1 SHADOW tests U..Z.
 *
 * Tests conditional/composite knowledge features built from the normalized
 * Trading School core. Same 7000 real XAU/USD M1 candles, same active champion,
 * held-out validation, three validation blocks. Never promotes.
 */

require("./weekend-upgrade");
require("./trading-school-regime-shadow");

const fs = require("fs");
const os = require("os");
const path = require("path");
const { promisify } = require("util");
const { execFile } = require("child_process");
const { Pool } = require("pg");
const { resolveActiveH1ModelPath } = require("./model-registry");

const execFileAsync = promisify(execFile);
const DATABASE_URL = String(process.env.DATABASE_URL || process.env.DATABASE_PUBLIC_URL || "").trim();
const PYTHON = process.env.PYTHON_BIN || path.join(__dirname, ".venv", "bin", "python");
const BUILTIN_MODEL = path.join(__dirname, "xauusd_ai_final_h1_full_period.joblib");

const CORE = [
  "core_impulse_consensus",
  "core_mtf_trend_consensus",
  "core_pullback_in_trend",
  "core_contextual_breakout",
  "core_conflict_penalty",
];

const TESTS = [
  ["U", "impulse_consensus", [CORE[0]]],
  ["V", "mtf_trend_consensus", [CORE[1]]],
  ["W", "pullback_in_trend", [CORE[2]]],
  ["X", "contextual_breakout", [CORE[3]]],
  ["Y", "conflict_penalty", [CORE[4]]],
  ["Z", "unified_core_all", CORE],
].map(([test, name, features]) => ({
  test,
  name,
  features,
  runKey: `TRADING_INTELLIGENCE_CORE_V1_SHADOW_${test}_${name.toUpperCase()}_2026_08_20`,
}));

const pool = DATABASE_URL ? new Pool({ connectionString: DATABASE_URL, max: 1, idleTimeoutMillis: 30_000 }) : null;

async function ensureSchema() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS trading_school_bootstrap_runs (
      run_key VARCHAR(100) PRIMARY KEY,
      status VARCHAR(24) NOT NULL,
      started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      finished_at TIMESTAMPTZ,
      report JSONB NOT NULL DEFAULT '{}'::jsonb,
      error TEXT
    )
  `);
}

async function claim(runKey) {
  const r = await pool.query(
    `INSERT INTO trading_school_bootstrap_runs(run_key,status)
     VALUES($1,'RUNNING') ON CONFLICT(run_key) DO NOTHING RETURNING run_key`,
    [runKey]
  );
  return r.rowCount === 1;
}

async function finish(runKey, status, report = {}, error = null) {
  await pool.query(
    `UPDATE trading_school_bootstrap_runs
     SET status=$2, finished_at=NOW(), report=$3::jsonb, error=$4
     WHERE run_key=$1`,
    [runKey, status, JSON.stringify(report), error]
  );
}

async function exportCandles() {
  const r = await pool.query(`
    SELECT (EXTRACT(EPOCH FROM candle_time)*1000)::bigint AS timestamp,
           open::float8, high::float8, low::float8, close::float8, volume::float8
    FROM xauusd_candles
    WHERE timeframe='M1'
    ORDER BY candle_time DESC
    LIMIT 7000
  `);
  return r.rows.reverse();
}

async function runOne(item, championPath, candlesPath) {
  if (!(await claim(item.runKey))) {
    console.log(`🧠 CORE ${item.test}: ${item.name} already completed/claimed`);
    return { test: item.test, name: item.name, skippedExisting: true };
  }

  const started = Date.now();
  const candidatePath = path.join(os.tmpdir(), `core_${item.name}_${Date.now()}.joblib`);
  const pyCode = [
    "import json,sys",
    "import trading_school.bootstrap_train_h1 as b",
    "from trading_school.features_v1 import add_unified_core_features",
    "orig=b.add_all_features",
    "b.add_all_features=lambda df:add_unified_core_features(orig(df))",
    `b.SCHOOL_FEATURES=${JSON.stringify(item.features)}`,
    "r=b.train(sys.argv[1],sys.argv[2],sys.argv[3])",
    "print(json.dumps(r,ensure_ascii=False,allow_nan=False))",
  ].join(";");

  console.log(`🧠 CORE ${item.test} START | ${item.features.join(",")}`);
  try {
    const { stdout, stderr } = await execFileAsync(
      PYTHON,
      ["-c", pyCode, championPath, candlesPath, candidatePath],
      { timeout: 20 * 60_000, maxBuffer: 4 * 1024 * 1024 }
    );
    if (stderr?.trim()) console.log(`🧠 CORE ${item.test} stderr:`, stderr.trim().slice(0, 1000));
    const line = String(stdout || "").trim().split(/\r?\n/).filter(Boolean).pop();
    const training = JSON.parse(line || "{}");
    if (!training.ok) throw new Error(training.error || "core training failed");

    training.shadow_only = true;
    training.test = item.test;
    training.group = "unified_trading_intelligence_core_v1";
    training.core_features = item.features;
    training.promoted = false;
    training.active_model_changed = false;
    training.elapsed_seconds = Number(((Date.now() - started) / 1000).toFixed(2));
    training.note = "Unified-core conditional feature test. Never promoted.";
    await finish(item.runKey, "SUCCESS", training);

    const c = training.champion_metrics || {};
    const n = training.challenger_metrics || {};
    console.log(
      `🧠 CORE ${item.test} DONE | accepted=${Boolean(training.accepted)} | promoted=false | ` +
      `dir=${Number(n.direction_accuracy || 0).toFixed(6)} | ` +
      `dir_gain=${(Number(n.direction_accuracy || 0)-Number(c.direction_accuracy || 0)).toFixed(6)} | ` +
      `mae=${Number(n.return_mae_bps || 0).toFixed(4)} | blocks=${JSON.stringify(training.block_gains || [])} | ` +
      `elapsed=${training.elapsed_seconds}s`
    );
    return training;
  } catch (error) {
    await finish(item.runKey, "FAILED", { shadow_only: true, test: item.test, core_features: item.features }, String(error?.message || error)).catch(() => {});
    console.error(`❌ CORE ${item.test}:`, error);
    return { failed: true, test: item.test, name: item.name, core_features: item.features, error: String(error?.message || error) };
  } finally {
    fs.unlink(candidatePath, () => {});
  }
}

async function run() {
  if (!pool) {
    console.warn("🧠 CORE SERIES: PostgreSQL unavailable; skipped");
    return;
  }
  await ensureSchema();
  const candles = await exportCandles();
  console.log(`🧠 UNIFIED CORE SERIES U..Z: ${candles.length} real M1 candles loaded once`);
  if (candles.length < 5000) return;

  const championPath = await resolveActiveH1ModelPath(BUILTIN_MODEL);
  const candlesPath = path.join(os.tmpdir(), `unified_core_candles_${Date.now()}.json`);
  fs.writeFileSync(candlesPath, JSON.stringify(candles), "utf8");
  try {
    const results = [];
    for (const item of TESTS) results.push(await runOne(item, championPath, candlesPath));

    const compact = results.filter((r) => !r.skippedExisting).map((r) => {
      const cm = r.champion_metrics || {};
      const nm = r.challenger_metrics || {};
      return {
        test: r.test,
        features: r.core_features,
        accepted: Boolean(r.accepted),
        promoted: false,
        dir: nm.direction_accuracy,
        dir_gain: (nm.direction_accuracy ?? 0) - (cm.direction_accuracy ?? 0),
        mae: nm.return_mae_bps,
        block_gains: r.block_gains,
        failed: Boolean(r.failed),
      };
    });
    compact.sort((a, b) => Number(b.dir_gain || -999) - Number(a.dir_gain || -999));
    console.log(`🧠 UNIFIED CORE SERIES U..Z COMPLETE | ranked=${JSON.stringify(compact)}`);
  } finally {
    fs.unlink(candlesPath, () => {});
  }
}

console.log("🧠 UNIFIED TRADING INTELLIGENCE CORE V1 shadow U..Z armed; starts in 20 sec");
setTimeout(() => run().catch((e) => console.error("❌ UNIFIED CORE SERIES:", e)), 20_000).unref();
