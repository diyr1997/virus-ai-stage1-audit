# VIRUS AI — current project state

Durable **resume cursor** for engineering agents. Shorter and more changeable
than `CONTEXT.md`.

Do not treat runtime statuses here as permanently true. Re-verify live services,
tests, data ranges and deployments before acting on them. **Never store secrets
in this file.**

Last updated: **2026-09-15**, post-merge consistency pass after PR #225.

## Current phase

- Market priority: **XAU/USD first**.
- Project phase: research / challenger integration / validation tooling / DEMO-shadow preparation.
- Separate live-data/order-flow research is being explored for cTrader/Binance-style L2 feeds; it is not production-authorized.
- **REAL trading: disabled.**
- `main` HEAD verified immediately before this docs-only hotfix branch:
  `b29eb13840a06969dddba9c406e8289367fdb78a` (merge of PR #225).
- PR #225 is merged. `CONTEXT.md`, `PROJECT_STATE.md`, toolbox manifests and
  `tools/research_env/` are now on `main`.

## Mandatory collaborative review rule

For every material project change — trading-data decision, model/feature change,
execution/safety change, or production-facing Telegram/news change — do not rely
on one analyst or one tool alone.

1. The primary working agent/tool proposes or implements the change.
2. At least one independent installed tool inspects the same evidence from its
   specialization where available (Graphify for dependency impact,
   SkillSpector for external-skill security, research env for quantitative
   validation, Council advisors for design review).
3. The coordinating assistant independently checks evidence, disagreements,
   tests, timestamps and safety constraints.
4. No majority vote overrides hard evidence, causal/as-of rules, execution
   costs, DEMO/REAL guards or a failed test.
5. If an expected advisor/tool is unavailable, timed out, unconfigured or out of
   credits, record that fact instead of pretending it reviewed the change.
6. External AI Council opinions remain advisory and never become runtime trade authority.

## Last verified toolbox facts

Canonical evidence:
`AI_TOOLBOX_FINAL_AUDIT_2026-09-15.md`,
`AI_TOOLBOX_MASTER_INVENTORY_2026-09-15.json`,
`AI_TOOLBOX_ADOPTION_MATRIX_2026-09-15.json`, and PR #225.

- **Master inventory: 72 unique external candidates.** Every candidate has a final status.
- **NVIDIA SkillSpector 2.11.2** (`03e8f56b`) — ACTIVE security gate. Payload-only scans are preferred because whole-repo scans can flag tests/docs that are never installed. Semantic analyzers were unavailable without a separate API key, so its findings are static-pattern evidence, not a complete semantic guarantee.
- **Graphify 0.9.61** — ACTIVE. Real index of this repo: **3841 nodes, 9160 edges, 345 files**; dependency and impact queries worked.
- **Context7 + Claude built-in code/security review** — ACTIVE.
- **Ponytail 4.10.0** — READY, payload scan clean and guardrail behavior tested. Activation still requires the user-side Claude `/plugin` flow; it is not a project blocker.
- **Andrej Karpathy Skills** — WATCH. Security-clean but intentionally not installed because it overlaps `AGENTS.md` + Ponytail.
- **Headroom 0.37.0** — ISOLATED_TEST. It can save tokens, but compression can be lossy depending on payload; do not place it in front of audit/evidence without a fidelity check.
- **OmniRoute 3.8.50** — NEEDS_CONFIG. Install/doctor/health work, but compression returned HTTP 503 in the fresh test and no real provider completion was obtained. It is not a completion blocker.
- **Optuna 5.0.0 + ruptures 1.1.10** — ACTIVE in the reproducible research-only env.
- **purgedcv 0.1.6** — READY, not ACTIVE for the current design. Parity test found 0 leakage in the native expanding-window walk-forward and 0 in purgedcv; a purge-only k-fold layout produced 60 backward violations, so purgedcv becomes important if/when CPCV/k-fold is used.
- **orderflow-metrics** — WATCH. Formula parity passed against a hand-written Cont-Kukanov-Stoikov reference: 8 fixtures + 5000 randomized trials + cumulative checks. Correct formula arithmetic is not evidence of trading edge.
- **Strix** — BLOCKED, genuine. Its live skill payload includes `curl ... | bash`; do not override without a safer digest-pinned installation path and a new review.
- **Google Skills** — BLOCKED / not cleanly approved. Whole catalog scan did not complete (`coverage_percent=0.0`) and one concrete credential→network taint was found. The project currently has no Google Cloud footprint, so there is no capability gap requiring it.
- **Anthropic Skills** — REJECTED as duplicate, not as malicious. Its earlier scanner flags were false-positive/irrelevant to the already-enabled document skills.
- **Matt Pocock Skills** — REJECTED as duplicate; Wayfinder/handoff concepts are already native in `CONTEXT.md` / `PROJECT_STATE.md`.
- **Scout (`pedrobraiti/market-research-mcp`) and Valet (`pedrobraiti/agentic-trading-mcp`)** — exact upstreams confirmed by direct clone; MIT; not automatically adopted.
- **Fynance** — REJECTED under that unresolved name; do not invent a repository.
- **QM** — ISOLATED_TEST. Railway service/deployment was observed live and had zero configured secrets, but no retained `QM_TOOLBOX_READY` boot marker was found, so runtime boot remains unverified.
- No toolbox result is evidence that the trading model is profitable.

## Current blockers / unknowns

- **Weekend Trainer Safety CI is red repo-wide.** Recent jobs fail in roughly 3–5 seconds before the actual safety tests run, including unrelated PR #224. This is a CI/runner-signal problem and should be repaired separately; do not interpret the red check as a passed safety test.
- **OmniRoute compression/free routing remain unproven.** Never expose real provider keys through its default non-loopback serving mode without authentication hardening.
- **AI System Architect** has still never produced one real project review. Keep BLOCKED/NEEDS_CREDENTIALS until it does.
- **QM** boot marker remains unverified even though the service itself is live.
- **Strix** remains genuinely blocked. **Google Skills** remains unneeded/unapproved unless a specific per-skill capability gap appears.
- Foundation-model shadows (Kronos, Chronos-2, TimesFM-2.5, etc.) remain research-only and are not decision-eligible unless their own validation gates pass.
- No verified evidence yet proves sustainable positive net trading expectancy.

## Toolbox branch reconciliation

`ai/integrate-agent-toolbox-2026-09-10` **must not be merged wholesale.** It was
cut from an older `main` and could delete newer work.

The reviewed manifests and durable docs needed from that branch were ported
file-by-file through PR #225. Treat PR #225 / current `main` as the canonical
toolbox state, not the old branch.

## Resume cursor

Continue from here without restarting completed toolbox discovery:

1. **Do not reopen the 72-tool audit by default.** Only revisit a tool when a concrete capability gap appears.
2. Ponytail activation is optional user-side setup: `/plugin marketplace add DietrichGebert/ponytail` then `/plugin install ponytail@ponytail`, followed by `/plugin` verification. Lack of Ponytail does not block engineering work.
3. Keep Strix blocked and Google Skills skipped unless a specific need justifies a narrow, fresh payload-only review.
4. Repair the **Weekend Trainer Safety** CI/runner failure so the named safety gate actually executes and produces signal.
5. Return to the live-data workstream. For XAU/USD, any replacement M1/tick/L2 source must be independently timestamped, causal, cross-validated and fail-closed before satisfying freshness/execution gates.
6. For order-flow research, treat cTrader/Binance L2, trades/prints, imbalance, OFI, microprice, sweep/absorption and latency as a separate event-driven research path. DEMO/shadow first; measure `event_received -> decision -> order_sent -> fill -> close` before making speed claims.
7. Keep **REAL trading disabled** throughout.

## Update rule

After any meaningful verified change, update only the sections that changed:
`Last verified toolbox facts`, `Current blockers / unknowns`, and `Resume cursor`.

Reference durable evidence by file, commit, issue, deployment id, test result or
report hash. **Never replace an unverified state with an optimistic claim.**
