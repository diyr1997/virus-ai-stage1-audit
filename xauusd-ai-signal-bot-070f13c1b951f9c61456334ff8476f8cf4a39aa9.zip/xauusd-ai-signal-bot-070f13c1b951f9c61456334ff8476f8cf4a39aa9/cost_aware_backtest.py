"""Net-of-cost evaluation for the H1 challenger.

Direction accuracy answers "how often was the sign right". It does not answer
"was there money left afterwards", and those two come apart badly at this
horizon: the emit threshold is 0.25 * 8.78 bps = 2.20 bps, which on $4000 gold
is $0.88 an ounce, against a round trip that costs roughly $0.46. The edge per
trade is about two times friction, so a model can gain direction accuracy and
still lose money by trading more often or by winning smaller.

Everything here is priced per ounce and per round trip, so no lot size or
account balance is involved and the numbers stay comparable between runs.

Three rules keep the simulation honest:

* Exit where the label exits. A trade opened on a decision bar closes at that
  row's ``future_close_60`` -- the same future price ``target_return_bps`` is
  built from, already checked to sit 55-70 minutes ahead so it never steps over
  a weekend or a data gap. Training and evaluation therefore describe the same
  event.
* One position at a time. After entering, every row is skipped until its
  timestamp reaches the open trade's exit timestamp. Overlapping entries would
  let one account hold sixty positions at once and invent capital it does not
  have.
* Emit exactly as production does. ``emit_decisions`` mirrors the rule in
  ai_predict_h1.py, so the backtest counts the trades the live bot would have
  taken and not the ones the model merely had an opinion about.

Entry fills at the decision bar's close, which assumes the order is placed the
moment the bar closes. That is optimistic by design; ``slippage_usd_per_side``
is what pays for it, and raising it is the way to test a slower fill.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class TradingCosts:
    """Round-trip friction, quoted per ounce in price units.

    Defaults describe a typical retail XAU/USD account. They are deliberately
    not optimistic: a tighter broker only makes the measured result better.
    """

    spread_usd: float = 0.30
    slippage_usd_per_side: float = 0.05
    commission_usd_per_oz: float = 0.06

    @property
    def round_trip_usd(self) -> float:
        return (
            float(self.spread_usd)
            + 2.0 * float(self.slippage_usd_per_side)
            + float(self.commission_usd_per_oz)
        )


DEFAULT_COSTS = TradingCosts()


def emit_decisions(
    probs: np.ndarray,
    classes: np.ndarray,
    predicted_return_bps: np.ndarray,
    thresholds: dict,
) -> tuple[np.ndarray, np.ndarray]:
    """Reproduce ai_predict_h1.py's BUY/SELL/WAIT rule over a whole frame.

    Returns ``(emit, direction)`` where ``emit`` marks the rows the live bot
    would have traded and ``direction`` is +1 or -1 on every row.
    """
    probs = np.asarray(probs, dtype=float)
    classes = np.asarray(classes)
    ret = np.asarray(predicted_return_bps, dtype=float)

    best = probs.argmax(axis=1)
    sign = classes[best].astype(int)
    confidence = probs.max(axis=1)

    reg_sign = np.where(ret >= 0.0, 1, -1)
    agreement = sign == reg_sign

    target_scale = max(float(thresholds.get("target_scale_bps", 0.0)), 1e-9)
    strength_ratio = np.abs(ret) / target_scale

    conf_thr = float(thresholds.get("direction_confidence", 0.60))
    strength_thr = float(thresholds.get("predicted_strength_ratio", 0.25))

    emit = agreement & (confidence >= conf_thr) & (strength_ratio >= strength_thr)
    return emit, sign


def _empty_result(costs: TradingCosts) -> dict:
    return {
        "trades": 0,
        "gross_usd_per_oz": 0.0,
        "friction_usd_per_oz": 0.0,
        "net_usd_per_oz": 0.0,
        "net_bps_per_trade": None,
        "gross_bps_per_trade": None,
        "win_rate": None,
        "profit_factor": None,
        "max_drawdown_usd_per_oz": 0.0,
        "friction_share_of_gross": None,
        "round_trip_cost_usd": costs.round_trip_usd,
        "signal_rows": 0,
        "rows": 0,
    }


def simulate(
    frame: pd.DataFrame,
    emit: np.ndarray,
    direction: np.ndarray,
    *,
    costs: TradingCosts = DEFAULT_COSTS,
) -> dict:
    """Walk the frame in time order and price every non-overlapping trade.

    ``frame`` must carry ``timestamp``, ``close``, ``future_close_60`` and
    ``future_ts_60``; _build_dataset produces all four and has already dropped
    rows whose label spans a gap.
    """
    required = {"timestamp", "close", "future_close_60", "future_ts_60"}
    missing = required - set(frame.columns)
    if missing:
        raise RuntimeError(
            "cost-aware backtest needs columns: " + ", ".join(sorted(missing))
        )

    emit = np.asarray(emit, dtype=bool)
    direction = np.asarray(direction, dtype=int)
    if len(emit) != len(frame) or len(direction) != len(frame):
        raise RuntimeError("emit/direction length must match the frame")

    order = np.argsort(frame["timestamp"].to_numpy(dtype="int64"), kind="stable")
    timestamps = frame["timestamp"].to_numpy(dtype="int64")[order]
    entries = frame["close"].to_numpy(dtype=float)[order]
    exits = frame["future_close_60"].to_numpy(dtype=float)[order]
    exit_ts = frame["future_ts_60"].to_numpy(dtype="int64")[order]
    emit = emit[order]
    direction = direction[order]

    round_trip = costs.round_trip_usd
    net_moves: list[float] = []
    gross_moves: list[float] = []
    net_bps: list[float] = []
    gross_bps: list[float] = []

    free_from_ts = np.iinfo("int64").min

    for i in range(len(timestamps)):
        if not emit[i] or timestamps[i] < free_from_ts:
            continue

        entry = entries[i]
        exit_price = exits[i]
        if not np.isfinite(entry) or not np.isfinite(exit_price) or entry <= 0.0:
            continue

        gross = float(direction[i]) * (exit_price - entry)
        net = gross - round_trip

        gross_moves.append(gross)
        net_moves.append(net)
        gross_bps.append(gross / entry * 10_000.0)
        net_bps.append(net / entry * 10_000.0)

        free_from_ts = exit_ts[i]

    if not net_moves:
        result = _empty_result(costs)
        result["signal_rows"] = int(emit.sum())
        result["rows"] = int(len(frame))
        return result

    net_arr = np.asarray(net_moves, dtype=float)
    gross_arr = np.asarray(gross_moves, dtype=float)

    # Drawdown measured against the running peak of the equity curve, never
    # against the starting point: a run that doubles and then halves has a real
    # drawdown even though it is still above where it began.
    equity = np.cumsum(net_arr)
    peak = np.maximum.accumulate(np.concatenate(([0.0], equity)))[1:]
    max_drawdown = float(np.min(equity - peak)) if len(equity) else 0.0

    wins = net_arr[net_arr > 0.0]
    losses = net_arr[net_arr <= 0.0]
    loss_sum = float(-losses.sum())
    gross_total = float(gross_arr.sum())
    friction_total = float(round_trip * len(net_arr))

    return {
        "trades": int(len(net_arr)),
        "gross_usd_per_oz": gross_total,
        "friction_usd_per_oz": friction_total,
        "net_usd_per_oz": float(net_arr.sum()),
        "net_bps_per_trade": float(np.mean(net_bps)),
        "gross_bps_per_trade": float(np.mean(gross_bps)),
        "win_rate": float(len(wins) / len(net_arr)),
        "profit_factor": (
            float(wins.sum() / loss_sum) if loss_sum > 0.0 else None
        ),
        "max_drawdown_usd_per_oz": min(0.0, max_drawdown),
        "friction_share_of_gross": (
            float(friction_total / abs(gross_total))
            if abs(gross_total) > 1e-12
            else None
        ),
        "round_trip_cost_usd": round_trip,
        "signal_rows": int(emit.sum()),
        "rows": int(len(frame)),
    }


def evaluate_bundle(
    bundle: dict,
    frame: pd.DataFrame,
    features: list[str],
    *,
    costs: TradingCosts = DEFAULT_COSTS,
) -> dict:
    """Score one model on one frame the way the live bot would have traded it."""
    X = frame[features].to_numpy(dtype=np.float32)
    dmodel = bundle["direction_models"][60]
    rmodel = bundle["return_models"][60]
    thresholds = bundle["thresholds"][60]

    probs = dmodel.predict_proba(X)
    classes = np.asarray(dmodel.classes_)
    predicted = np.asarray(rmodel.predict(X), dtype=float)

    emit, direction = emit_decisions(probs, classes, predicted, thresholds)
    return simulate(frame, emit, direction, costs=costs)


def net_verdict(champion: dict, challenger: dict, *, min_trades: int = 30) -> tuple[bool, list[str]]:
    """Decide whether the challenger is acceptable on money, not on accuracy.

    Fail-closed: anything unmeasurable is a refusal, because the caller uses
    this to decide whether a model goes in front of live signals.
    """
    reasons: list[str] = []

    n_trades = int(challenger.get("trades") or 0)
    if n_trades < int(min_trades):
        reasons.append(f"net_trades_below_{min_trades}_got_{n_trades}")

    challenger_edge = challenger.get("net_bps_per_trade")
    if challenger_edge is None:
        reasons.append("net_edge_unmeasurable")
    elif float(challenger_edge) <= 0.0:
        reasons.append(f"net_edge_not_positive={float(challenger_edge):+.3f}bps")

    champion_edge = champion.get("net_bps_per_trade") if champion else None
    if (
        champion_edge is not None
        and challenger_edge is not None
        and float(challenger_edge) < float(champion_edge)
    ):
        reasons.append(
            f"net_edge_below_champion={float(challenger_edge):+.3f}"
            f"_vs_{float(champion_edge):+.3f}bps"
        )

    return len(reasons) == 0, reasons
