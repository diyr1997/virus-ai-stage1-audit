"use strict";

const { Pool } = require("pg");
const { ADVISORS, ROLES } = require("./ai-council");
const {
  advisorConfigured,
  ensureCouncilSchema,
} = require("./ai-council-persistent");
const {
  callProvider,
  callGeminiGrounded,
  callDeepSeek,
  callClaude,
} = require("./ai-providers");
const { callGrok, callGrokResearch } = require("./grok-provider");
const {
  claudeBridgeActive,
  publishClaudeTask,
  importClaudeResult,
} = require("./ai-council-claude-bridge");

const DATABASE_URL = String(process.env.DATABASE_URL || "").trim();
const pool = DATABASE_URL ? new Pool({ connectionString: DATABASE_URL }) : null;
const MIN_READY_ADVISORS = Math.max(
  1,
  Number(process.env.AI_COUNCIL_MIN_READY_ADVISORS || 1)
);

function requirePool() {
  if (!pool) throw new Error("DATABASE_URL is not configured");
  return pool;
}

function groundedToText(result) {
  if (!result || typeof result === "string") return String(result || "").trim();
  if (result.rateLimited) {
    const error = new Error(`Provider rate limited until ${result.retryAt || "later"}`);
    error.code = "RATE_LIMITED";
    throw error;
  }
  const text = String(result.text || "").trim();
  if (!text) throw new Error("Provider returned empty research response");
  const sources = Array.isArray(result.sources) ? result.sources : [];
  if (!sources.length) return text;
  return `${text}\n\nVERIFIABLE SOURCES:\n${sources
    .map((s, index) => `${index + 1}. ${s.title || "Source"} — ${s.url}`)
    .join("\n")}`;
}

async function callAdvisorForTask(advisor, taskType, prompt) {
  const research = /research|book|source|news/i.test(String(taskType || ""));
  if (advisor === "grok") {
    return groundedToText(research ? await callGrokResearch(prompt) : await callGrok(prompt));
  }
  if (advisor === "gemini" && research) {
    return groundedToText(await callGeminiGrounded(prompt));
  }
  if (advisor === "deepseek") return String(await callDeepSeek(prompt)).trim();
  if (advisor === "claude") return String(await callClaude(prompt)).trim();
  return String(await callProvider(advisor, prompt)).trim();
}

function buildPrompt({ task, taskType, contextSnapshot, advisor, peerResponses = [] }) {
  const role = ROLES[advisor] || "Independent reviewer";
  const peer = peerResponses.length
    ? `\n\nOTHER ADVISORS' RESPONSES TO CRITIQUE:\n${JSON.stringify(peerResponses, null, 2)}`
    : "";

  return [
    "You are one member of the XAU/USD AI Council.",
    "Every configured advisor receives the same task and the same frozen project context.",
    "Missing or temporarily unavailable advisors never block the active council.",
    "First think independently. Do not wait for or imitate another advisor's answer.",
    "In peer-review phase, actively look for mistakes, contradictions, missing evidence and better alternatives.",
    "Do not trade, expose secrets, or silently change production.",
    "When a claim depends on a source, distinguish VERIFIED from UNVERIFIED. Do not invent URLs or availability.",
    `TASK TYPE: ${taskType}`,
    `YOUR ROLE: ${role}`,
    "",
    "FROZEN PROJECT CONTEXT:",
    contextSnapshot,
    "",
    "TASK:",
    task,
    peer,
    "",
    "Return: summary, findings, proposed_changes, rejected_or_doubtful_ideas, evidence_and_sources, risks, tests, disagreements, confidence.",
  ].join("\n");
}

function classifyAdvisorError(error) {
  const message = String(error?.message || error || "Unknown error");
  const statusCode = Number(error?.statusCode || 0);
  if (/NOT_CONFIGURED|not configured/i.test(message)) return "NOT_CONFIGURED";
  if (statusCode === 429 || /RATE_LIMITED|quota|rate.?limit|RESOURCE_EXHAUSTED/i.test(message)) {
    return "RATE_LIMITED";
  }
  if (statusCode === 401 || statusCode === 403 || /credits?|licenses?|permission-denied|unauthor/i.test(message)) {
    return "AUTH_OR_CREDITS";
  }
  if (/abort|timeout|timed out/i.test(message)) return "TIMEOUT";
  return "TEMPORARY_ERROR";
}

function computeCouncilState({
  runs,
  configuredAdvisors,
  advisors = ADVISORS,
  minReadyAdvisors = MIN_READY_ADVISORS,
}) {
  const configured = new Set(configuredAdvisors || []);
  const readyAdvisors = (configuredAdvisors || []).filter((advisor) =>
    ["independent", "peer_review"].every((phase) =>
      runs.some(
        (run) =>
          run.advisor === advisor &&
          run.phase === phase &&
          run.status === "SUCCESS"
      )
    )
  );
  const pendingConfigured = (configuredAdvisors || []).filter(
    (advisor) => !readyAdvisors.includes(advisor)
  );
  const notConfigured = advisors.filter((advisor) => !configured.has(advisor));
  const hasQuorum = readyAdvisors.length >= Math.max(1, Number(minReadyAdvisors) || 1);
  const allConfiguredComplete =
    configuredAdvisors.length > 0 && readyAdvisors.length === configuredAdvisors.length;

  let status = "WAITING_QUORUM";
  if (allConfiguredComplete) status = "COMPLETE";
  else if (hasQuorum) status = "READY_PARTIAL";

  return {
    status,
    hasQuorum,
    allConfiguredComplete,
    readyAdvisors,
    pendingConfigured,
    notConfigured,
  };
}

async function getTask(taskId) {
  const { rows } = await requirePool().query(
    "SELECT * FROM ai_council_tasks WHERE id=$1",
    [taskId]
  );
  return rows[0] || null;
}

async function getRuns(taskId) {
  const { rows } = await requirePool().query(
    "SELECT * FROM ai_council_runs WHERE task_id=$1 ORDER BY advisor, phase",
    [taskId]
  );
  return rows;
}

async function saveRunSuccess(taskId, advisor, phase, response) {
  await requirePool().query(
    `UPDATE ai_council_runs
     SET status='SUCCESS', response=$4, error=NULL, attempts=attempts+1,
         completed_at=NOW(), updated_at=NOW()
     WHERE task_id=$1 AND advisor=$2 AND phase=$3`,
    [taskId, advisor, phase, response]
  );
}

async function saveRunUnavailable(taskId, advisor, phase, error, status = "RETRY") {
  const code = classifyAdvisorError(error);
  const message = String(error?.message || error || "Unknown error").slice(0, 1400);
  await requirePool().query(
    `UPDATE ai_council_runs
     SET status=$4, response=NULL, error=$5,
         attempts=attempts + CASE WHEN $4='RETRY' THEN 1 ELSE 0 END,
         updated_at=NOW()
     WHERE task_id=$1 AND advisor=$2 AND phase=$3`,
    [taskId, advisor, phase, status, `${code}: ${message}`]
  );
}

async function attemptClaudeBridgePhase(task, phase, peerResponses) {
  try {
    const imported = await importClaudeResult({ taskId: task.id, phase });
    if (imported.success) {
      await saveRunSuccess(task.id, "claude", phase, imported.response);
      return true;
    }
    // A rejected/invalid result (wrong marker, wrong author, stale, etc.)
    // never blocks the council or is treated as a fatal error - it simply
    // means claude stays PENDING/RETRY for this phase, same as any other
    // advisor waiting on a slow or unavailable provider.
    await publishClaudeTask({
      taskId: task.id,
      phase,
      taskType: task.task_type,
      task: task.task,
      contextSnapshot: task.context_snapshot,
      peerResponses,
    });
    await saveRunUnavailable(
      task.id,
      "claude",
      phase,
      new Error(`WAITING_CLAUDE_CODE_CLOUD:${imported.reason}`),
      "RETRY"
    );
  } catch (error) {
    await saveRunUnavailable(task.id, "claude", phase, error, "RETRY");
  }
  return false;
}

async function attemptAdvisorPhase(task, advisor, phase, peerResponses = []) {
  if (!advisorConfigured(advisor)) {
    await saveRunUnavailable(task.id, advisor, phase, new Error("NOT_CONFIGURED"), "UNAVAILABLE");
    return false;
  }

  if (advisor === "claude" && claudeBridgeActive()) {
    return attemptClaudeBridgePhase(task, phase, peerResponses);
  }

  try {
    const prompt = buildPrompt({
      task: task.task,
      taskType: task.task_type,
      contextSnapshot: task.context_snapshot,
      advisor,
      peerResponses,
    });
    const response = await callAdvisorForTask(advisor, task.task_type, prompt);
    if (!response) throw new Error("Empty advisor response");
    await saveRunSuccess(task.id, advisor, phase, response);
    return true;
  } catch (error) {
    await saveRunUnavailable(task.id, advisor, phase, error, "RETRY");
    return false;
  }
}

async function runPhaseInParallel(task, phase, runs, peerResponses = []) {
  const jobs = ADVISORS.map(async (advisor) => {
    const existing = runs.find((run) => run.advisor === advisor && run.phase === phase);
    if (existing?.status === "SUCCESS") return false;

    if (phase === "peer_review") {
      const independent = runs.find(
        (run) =>
          run.advisor === advisor &&
          run.phase === "independent" &&
          run.status === "SUCCESS"
      );
      if (!independent) {
        if (!advisorConfigured(advisor)) {
          await saveRunUnavailable(task.id, advisor, phase, new Error("NOT_CONFIGURED"), "UNAVAILABLE");
        }
        return false;
      }
    }

    return attemptAdvisorPhase(task, advisor, phase, peerResponses);
  });

  const settled = await Promise.allSettled(jobs);
  return settled.some(
    (result) => result.status === "fulfilled" && result.value === true
  );
}

async function synthesizeTask(task, successfulResponses, readyAdvisors) {
  if (!successfulResponses.length || !readyAdvisors.length) return false;

  const synthesisPrompt = [
    "You are the coordinator for the XAU/USD AI Council.",
    "Reconcile the advisor responses below. Do not decide by majority vote.",
    "Prefer verifiable evidence, testability, robustness and DEMO safety.",
    "Explicitly list disagreements and unavailable configured advisors.",
    "A result may be usable with a dynamic quorum; mark it PARTIAL if configured advisors are still unavailable.",
    "If a late advisor later adds a material objection, the council will synthesize a new revision.",
    "",
    `TASK: ${task.task}`,
    "",
    "ADVISOR RESPONSES:",
    JSON.stringify(successfulResponses, null, 2),
    "",
    "Return: consensus, strongest_disagreements, approved_for_testing, rejected, needs_more_evidence, exact_next_tests, provisional_items, final_recommendation.",
  ].join("\n");

  const order = [...new Set([...readyAdvisors, "deepseek", "gemini", "grok", "claude"])];
  for (const coordinator of order) {
    if (!advisorConfigured(coordinator)) continue;
    try {
      const text = await callAdvisorForTask(coordinator, "synthesis", synthesisPrompt);
      if (!text) continue;
      await requirePool().query(
        `UPDATE ai_council_tasks
         SET final_plan=$2, last_coordinator=$3, revision=revision+1,
             updated_at=NOW()
         WHERE id=$1`,
        [task.id, text, coordinator]
      );
      return true;
    } catch (error) {
      console.warn(`AI COUNCIL coordinator ${coordinator} unavailable: ${error.message}`);
    }
  }
  return false;
}

function configuredAdvisorList() {
  return ADVISORS.filter((advisor) => advisorConfigured(advisor));
}

function unavailableDetails(runs, state) {
  return [...state.pendingConfigured, ...state.notConfigured].map((advisor) => {
    const advisorRuns = runs.filter((run) => run.advisor === advisor);
    const errors = advisorRuns
      .map((run) => String(run.error || "").trim())
      .filter(Boolean);
    return {
      advisor,
      configured: !state.notConfigured.includes(advisor),
      statuses: advisorRuns.map((run) => ({ phase: run.phase, status: run.status })),
      error: errors[0] || (state.notConfigured.includes(advisor) ? "NOT_CONFIGURED" : "NOT_READY"),
    };
  });
}

async function processCouncilTask(taskId) {
  const task = await getTask(taskId);
  if (!task) throw new Error(`Unknown council task: ${taskId}`);

  let runs = await getRuns(taskId);
  let progress = await runPhaseInParallel(task, "independent", runs);

  runs = await getRuns(taskId);
  const independent = runs
    .filter((run) => run.phase === "independent" && run.status === "SUCCESS")
    .map((run) => ({ advisor: run.advisor, response: run.response }));

  const peerProgress = await runPhaseInParallel(task, "peer_review", runs, independent);
  progress = progress || peerProgress;

  runs = await getRuns(taskId);
  const completed = runs
    .filter((run) => run.status === "SUCCESS")
    .map((run) => ({ advisor: run.advisor, phase: run.phase, response: run.response }));

  const configuredAdvisors = configuredAdvisorList();
  let state = computeCouncilState({ runs, configuredAdvisors });

  if (state.hasQuorum && (progress || !task.final_plan)) {
    await synthesizeTask(task, completed, state.readyAdvisors);
  }

  const refreshed = await getTask(taskId);
  runs = await getRuns(taskId);
  state = computeCouncilState({ runs, configuredAdvisors });
  let status = state.status;
  if (state.hasQuorum && !refreshed?.final_plan) status = "WAITING_SYNTHESIS";

  await requirePool().query(
    `UPDATE ai_council_tasks
     SET status=$2, updated_at=NOW()
     WHERE id=$1`,
    [taskId, status]
  );

  return {
    taskId,
    status,
    revision: Number(refreshed?.revision || 0),
    readyAdvisors: state.readyAdvisors,
    configuredAdvisors,
    unavailableAdvisors: unavailableDetails(runs, state),
    completedRuns: completed.length,
    configuredRuns: configuredAdvisors.length * 2,
    supportedRuns: ADVISORS.length * 2,
    quorum: MIN_READY_ADVISORS,
  };
}

async function getCouncilSnapshot(taskId) {
  const task = await getTask(taskId);
  if (!task) return null;
  const runs = await getRuns(taskId);
  const configuredAdvisors = configuredAdvisorList();
  const state = computeCouncilState({ runs, configuredAdvisors });
  return {
    task,
    runs,
    configuredAdvisors,
    readyAdvisors: state.readyAdvisors,
    unavailableAdvisors: unavailableDetails(runs, state),
    quorum: MIN_READY_ADVISORS,
  };
}

async function processPendingCouncilTasks(limit = 10) {
  await ensureCouncilSchema();
  const { rows } = await requirePool().query(
    `SELECT id FROM ai_council_tasks
     WHERE status <> 'COMPLETE'
     ORDER BY updated_at ASC
     LIMIT $1`,
    [Math.max(1, Math.min(50, Number(limit) || 10))]
  );

  const results = [];
  for (const row of rows) {
    try {
      results.push(await processCouncilTask(row.id));
    } catch (error) {
      console.warn(`AI COUNCIL task ${row.id} failed: ${error.message}`);
    }
  }
  return results;
}

module.exports = {
  MIN_READY_ADVISORS,
  buildPrompt,
  classifyAdvisorError,
  computeCouncilState,
  configuredAdvisorList,
  processCouncilTask,
  processPendingCouncilTasks,
  getCouncilSnapshot,
};
