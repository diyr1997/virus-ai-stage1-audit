"use strict";

const TelegramBot = require("node-telegram-bot-api");
const { Pool } = require("pg");

const ENABLED = String(process.env.WORKER_STATUS_BOOTSTRAP_ENABLED || "1") !== "0";
const DATABASE_URL = process.env.DATABASE_URL || process.env.DATABASE_PUBLIC_URL || "";
const STATUS_KEYS = ["preflight", "market_state", "worker_watchdog", "last_error"];
const BLOCK_EVENT_TYPES = [
  "ENTRY_SKIPPED",
  "FAST_ENTRY_BLOCKED",
  "FAST_ENTRY_SLOT_BLOCKED",
  "ORDER_CLAIM_BLOCKED",
  "ORDER_SEND_BLOCKED",
  "ORDER_SEND_AMBIGUOUS",
  "ORDER_REJECTED",
  "SCENARIO_CANCELLED",
  "DIRECTION_BLOCKED",
  "ADD_BLOCKED",
  "RISK_BLOCKED",
  "MARGIN_BLOCKED",
  "DEMO_MIN_LOT_MARGIN_BLOCK",
  "NO_HEDGE_BLOCKED",
  "STALE_BLOCKED",
  "MT5_STATE_UNAVAILABLE",
  "RECONCILE_BLOCKED",
  "REVERSAL_NOT_IMPLEMENTED_SAFE_BLOCK",
];
const MAX_REASON = 180;
const MAX_TELEGRAM_TEXT = 4000;

let pool = null;
let installed = false;

function cleanText(value, limit = MAX_REASON) {
  return String(value ?? "")
    .replace(/[\r\n\t]+/g, " ")
    .replace(/\s{2,}/g, " ")
    .trim()
    .slice(0, limit);
}

function yesNo(value) {
  return value === true ? "✅" : value === false ? "❌" : "?";
}

function normalizeValue(value) {
  if (!value) return {};
  if (typeof value === "object" && !Array.isArray(value)) return value;
  try {
    const parsed = JSON.parse(String(value));
    return parsed && typeof parsed === "object" && !Array.isArray(parsed)
      ? parsed
      : {};
  } catch (_) {
    return {};
  }
}

function rowsToMap(rows) {
  const out = new Map();
  for (const row of rows || []) {
    if (!row || !STATUS_KEYS.includes(String(row.key || ""))) continue;
    out.set(String(row.key), {
      value: normalizeValue(row.value),
      updated_at: row.updated_at || null,
    });
  }
  return out;
}

function formatAge(value) {
  if (!value) return "нет времени";
  const ms = Date.parse(value);
  if (!Number.isFinite(ms)) return "время неизвестно";
  const age = Math.max(0, Date.now() - ms);
  if (age < 60_000) return `${Math.floor(age / 1000)} сек назад`;
  if (age < 3_600_000) return `${Math.floor(age / 60_000)} мин назад`;
  return `${Math.floor(age / 3_600_000)} ч ${Math.floor((age % 3_600_000) / 60_000)} мин назад`;
}

function secondsText(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return null;
  if (n < 60) return `${Math.round(n)}с`;
  return `${Math.floor(n / 60)}м ${Math.round(n % 60)}с`;
}

function formatWorkerDiagnostics(rows) {
  const map = rows instanceof Map ? rows : rowsToMap(rows);
  const lines = ["", "🧭 WORKER DIAGNOSTICS"];

  const preflightRow = map.get("preflight");
  if (preflightRow) {
    const p = preflightRow.value;
    const overall = cleanText(p.overall || "UNKNOWN", 40);
    const planned = p.planned_market_closed === true
      ? ` • планово закрыт: ${cleanText(p.planned_market_state || "YES", 40)}`
      : "";
    lines.push(`Preflight: ${overall || "UNKNOWN"} • ${formatAge(preflightRow.updated_at)}${planned}`);
    lines.push(
      `DB ${yesNo(p.database_ok)} • MT5 DEMO ${yesNo(p.mt5_demo_ok)} • TIME ${yesNo(p.time_trusted)} • TICK ${yesNo(p.tick_fresh)} • M1 ${yesNo(p.closed_m1_fresh)}`
    );
  } else {
    lines.push("Preflight: ⏳ ещё не записан новым V9 worker");
  }

  const marketRow = map.get("market_state");
  if (marketRow) {
    const m = marketRow.value;
    const state = cleanText(m.state || "UNKNOWN", 48);
    const allowed = m.trade_allowed === true ? "✅ вход разрешён" : "⛔ вход заблокирован";
    lines.push(`Market: ${state || "UNKNOWN"} • ${allowed} • ${formatAge(marketRow.updated_at)}`);
    const tickAge = secondsText(m.tick_age_seconds);
    const m1Age = secondsText(m.m1_age_seconds);
    const staleFor = secondsText(m.stale_feed_seconds);
    const restartAt = secondsText(m.stale_feed_restart_seconds);
    if (tickAge || m1Age) {
      lines.push(`Data age: TICK ${tickAge || "?"} • M1 ${m1Age || "?"}`);
    }
    if (staleFor) {
      lines.push(`Stale feed: ${staleFor}${restartAt ? ` • авто-restart после ${restartAt}` : ""}`);
    }
    const reason = cleanText(m.reason);
    if (reason) lines.push(`Причина: ${reason}`);
  } else {
    lines.push("Market: состояние worker пока не записано");
  }

  const watchdogRow = map.get("worker_watchdog");
  if (watchdogRow) {
    const w = watchdogRow.value;
    const requested = w.restart_requested === true ? "🔁 RESTART REQUESTED" : "ℹ️ запись есть";
    const failureValue = w.consecutive_failures ?? w.failures;
    const failures = Number.isFinite(Number(failureValue)) ? ` • failures=${Number(failureValue)}` : "";
    const reason = cleanText(w.reason || w.message);
    lines.push(`Watchdog: ${requested}${failures} • ${formatAge(watchdogRow.updated_at)}`);
    if (reason) lines.push(`Watchdog reason: ${reason}`);
  } else {
    lines.push("Watchdog: ✅ аварийный restart не зафиксирован");
  }

  const errorRow = map.get("last_error");
  if (errorRow) {
    const e = errorRow.value;
    const message = cleanText(e.message || e.error || e.reason);
    lines.push(`Last error: ${message || "есть запись без текста"} • ${formatAge(errorRow.updated_at)}`);
  } else {
    lines.push("Last error: ✅ нет записи");
  }

  return lines.join("\n");
}

function formatPipelineDiagnostics(data) {
  const candidate = data?.candidate || null;
  const events = Array.isArray(data?.events) ? data.events : [];
  const blocker = data?.blocker || null;
  const lines = ["", "🔎 ENTRY PIPELINE"];

  if (!candidate) {
    lines.push("Последний кандидат: нет записей");
  } else {
    const tf = cleanText(candidate.timeframe || "?", 8);
    const side = cleanText(candidate.side || "?", 8);
    const strength = Number.isFinite(Number(candidate.strength)) ? Number(candidate.strength) : "?";
    const status = cleanText(candidate.status || "?", 32);
    lines.push(`Кандидат #${candidate.id} • ${tf} ${side} • ${strength}/100 • ${status}`);
    lines.push(`Создан: ${formatAge(candidate.created_at)}${candidate.expires_at ? ` • expiry ${formatAge(candidate.expires_at)}` : ""}`);
  }

  if (blocker) {
    const payload = normalizeValue(blocker.payload);
    const reason = cleanText(payload.reason || payload.stage || payload.comment || payload.error || "нет текста", 140);
    const candidateId = blocker.candidate_id ? ` • candidate #${blocker.candidate_id}` : "";
    lines.push(`⛔ Последний блок входа: ${cleanText(blocker.event_type || "BLOCK", 40)}${candidateId} • ${reason} • ${formatAge(blocker.created_at)}`);
  } else {
    lines.push("⛔ Последний блок входа: свежих записей нет");
  }

  if (!events.length) {
    lines.push("V9 events: пока нет свежих событий");
  } else {
    lines.push("Последние V9 events:");
    for (const row of events.slice(0, 4)) {
      const payload = normalizeValue(row.payload);
      const reason = cleanText(payload.reason || payload.stage || payload.comment || "", 100);
      const suffix = reason ? ` • ${reason}` : "";
      lines.push(`• ${cleanText(row.event_type || "EVENT", 40)}${suffix} • ${formatAge(row.created_at)}`);
    }
  }

  return lines.join("\n");
}

function appendWithinTelegramLimit(baseText, suffix) {
  const base = String(baseText || "");
  if (base.length >= MAX_TELEGRAM_TEXT) return base;
  const room = MAX_TELEGRAM_TEXT - base.length;
  if (room < 32) return base;
  return base + String(suffix || "").slice(0, room);
}

function getPool() {
  if (!DATABASE_URL) return null;
  if (!pool) {
    pool = new Pool({
      connectionString: DATABASE_URL,
      max: 1,
      idleTimeoutMillis: 10_000,
      connectionTimeoutMillis: 3_000,
      query_timeout: 3_000,
    });
  }
  return pool;
}

async function loadWorkerStatusRows() {
  const db = getPool();
  if (!db) return [];
  const result = await db.query(
    `
      SELECT key, value, updated_at
      FROM demo_worker_state
      WHERE key = ANY($1::text[])
    `,
    [STATUS_KEYS]
  );
  return result.rows || [];
}

async function loadPipelineDiagnostics() {
  const db = getPool();
  if (!db) return { candidate: null, events: [], blocker: null };
  const [candidateResult, eventsResult, blockerResult] = await Promise.all([
    db.query(`
      SELECT id, created_at, expires_at, timeframe, side, strength, status
      FROM trade_candidates
      ORDER BY id DESC
      LIMIT 1
    `),
    db.query(`
      SELECT created_at, event_type, candidate_id, trade_id, payload
      FROM demo_trader_events
      ORDER BY id DESC
      LIMIT 4
    `),
    db.query(`
      SELECT created_at, event_type, candidate_id, trade_id, payload
      FROM demo_trader_events
      WHERE event_type = ANY($1::text[])
      ORDER BY id DESC
      LIMIT 1
    `, [BLOCK_EVENT_TYPES]),
  ]);
  return {
    candidate: candidateResult.rows?.[0] || null,
    events: eventsResult.rows || [],
    blocker: blockerResult.rows?.[0] || null,
  };
}

async function augmentDbStatusText(text) {
  if (typeof text !== "string" || !text.startsWith("🗄 PostgreSQL")) return text;
  if (text.includes("🧭 WORKER DIAGNOSTICS")) return text;

  try {
    const [rows, pipeline] = await Promise.all([
      loadWorkerStatusRows(),
      loadPipelineDiagnostics(),
    ]);
    let next = appendWithinTelegramLimit(text, formatWorkerDiagnostics(rows));
    next = appendWithinTelegramLimit(next, formatPipelineDiagnostics(pipeline));
    return next;
  } catch (error) {
    const reason = cleanText(error && error.message ? error.message : error, 120);
    return appendWithinTelegramLimit(
      text,
      `\n\n🧭 WORKER DIAGNOSTICS\n⚠️ Не удалось прочитать worker/pipeline state${reason ? `: ${reason}` : ""}`
    );
  }
}

function install() {
  if (!ENABLED || installed) return false;
  if (!TelegramBot || !TelegramBot.prototype || typeof TelegramBot.prototype.sendMessage !== "function") {
    return false;
  }

  const originalSendMessage = TelegramBot.prototype.sendMessage;
  TelegramBot.prototype.sendMessage = async function patchedSendMessage(chatId, text, options) {
    const nextText = await augmentDbStatusText(text);
    return originalSendMessage.call(this, chatId, nextText, options);
  };

  installed = true;
  console.log("✅ WORKER STATUS BOOTSTRAP: /db_status worker + entry-pipeline diagnostics enabled");
  return true;
}

if (ENABLED) install();

module.exports = {
  BLOCK_EVENT_TYPES,
  MAX_TELEGRAM_TEXT,
  STATUS_KEYS,
  appendWithinTelegramLimit,
  augmentDbStatusText,
  cleanText,
  formatPipelineDiagnostics,
  formatWorkerDiagnostics,
  install,
  loadPipelineDiagnostics,
  normalizeValue,
  rowsToMap,
  secondsText,
};
