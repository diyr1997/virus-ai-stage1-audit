const fs = require("fs");
const path = require("path");
const os = require("os");
const { promisify } = require("util");
const { execFile } = require("child_process");
const { resolveActiveH1ModelPath } = require("./model-registry");
const execFileAsync = promisify(execFile);

// ======================================================
// AI H1 — обученная модель на горизонт +60 минут
// ======================================================

const AI_H1_MODEL_PATH =
  process.env.AI_H1_MODEL_PATH ||
  path.join(__dirname, "xauusd_ai_final_h1_full_period.joblib");

const AI_H1_SCRIPT_PATH =
  process.env.AI_H1_SCRIPT_PATH ||
  path.join(__dirname, "ai_predict_h1.py");

const AI_PYTHON =
  process.env.PYTHON_BIN ||
  path.join(__dirname, ".venv", "bin", "python");

const AI_H1_TIMEOUT_MS = 120 * 1000;
const AI_H1_CACHE_TIME = 5 * 60 * 1000;

let aiH1Cache = {
  lastTimestamp: null,
  modelPath: null,
  data: null,
  updatedAt: 0,
};

function aiFileExists(filePath) {
  try {
    return fs.existsSync(filePath);
  } catch (_) {
    return false;
  }
}

async function activeModelPath() {
  const modelPath = await resolveActiveH1ModelPath(AI_H1_MODEL_PATH);
  if (!aiFileExists(modelPath)) {
    throw new Error("AI H1 model file not found");
  }
  return modelPath;
}

async function runAiH1(m1Candles) {
  const modelPath = await activeModelPath();

  if (!aiFileExists(AI_H1_SCRIPT_PATH)) {
    throw new Error("AI H1 predictor file not found");
  }

  if (!Array.isArray(m1Candles) || m1Candles.length < 2400) {
    throw new Error(
      `AI H1: нужно минимум 2400 M1-свечей, получено ${m1Candles?.length || 0}`
    );
  }

  const lastTimestamp = m1Candles[m1Candles.length - 1]?.time;

  if (
    aiH1Cache.data &&
    aiH1Cache.lastTimestamp === lastTimestamp &&
    aiH1Cache.modelPath === modelPath &&
    Date.now() - aiH1Cache.updatedAt < AI_H1_CACHE_TIME
  ) {
    return aiH1Cache.data;
  }

  const tempFile = path.join(
    os.tmpdir(),
    `xauusd_ai_h1_${process.pid}_${Date.now()}.json`
  );

  const payload = m1Candles.slice(-7000).map((c) => ({
    timestamp: c.time,
    open: c.open,
    high: c.high,
    low: c.low,
    close: c.close,
    volume: c.volume || 0,
  }));

  fs.writeFileSync(tempFile, JSON.stringify(payload), "utf8");

  try {
    const { stdout, stderr } = await execFileAsync(
      AI_PYTHON,
      [
        AI_H1_SCRIPT_PATH,
        "--model",
        modelPath,
        "--candles",
        tempFile,
      ],
      {
        timeout: AI_H1_TIMEOUT_MS,
        maxBuffer: 2 * 1024 * 1024,
        env: { ...process.env, PYTHONUNBUFFERED: "1" },
      }
    );

    if (stderr && stderr.trim()) {
      console.log("🧠 AI H1 stderr:", stderr.trim().slice(0, 1000));
    }

    const lines = String(stdout || "")
      .trim()
      .split(/\r?\n/)
      .filter(Boolean);

    if (!lines.length) throw new Error("AI H1 вернул пустой ответ");

    const result = JSON.parse(lines[lines.length - 1]);
    if (!result || result.ok !== true) {
      throw new Error(result?.error || "AI H1 prediction failed");
    }

    aiH1Cache = {
      lastTimestamp,
      modelPath,
      data: result,
      updatedAt: Date.now(),
    };

    return result;
  } finally {
    fs.unlink(tempFile, () => {});
  }
}

async function getAiH1Status() {
  const modelPath = await activeModelPath();

  if (!aiFileExists(AI_H1_SCRIPT_PATH)) {
    throw new Error("Файл ai_predict_h1.py не найден");
  }

  const { stdout } = await execFileAsync(
    AI_PYTHON,
    [
      AI_H1_SCRIPT_PATH,
      "--model",
      modelPath,
      "--status",
    ],
    {
      timeout: AI_H1_TIMEOUT_MS,
      maxBuffer: 1024 * 1024,
      env: { ...process.env, PYTHONUNBUFFERED: "1" },
    }
  );

  const lines = String(stdout || "")
    .trim()
    .split(/\r?\n/)
    .filter(Boolean);

  if (!lines.length) throw new Error("AI H1 status: пустой ответ");
  return JSON.parse(lines[lines.length - 1]);
}

// AI не заменяет свечи, новости и CFTC.
// Он добавляет ограниченный вес только H1.
function applyAiH1ToAnalysis(analysis, ai) {
  if (!analysis || !ai) return analysis;

  const beforeScore = Number(analysis.score || 0);
  let aiAdjustment = 0;

  if (ai.action === "BUY" || ai.action === "SELL") {
    const confidence = Math.max(
      0,
      Math.min(1, Number(ai.confidence || 0))
    );

    const weight = Math.max(
      10,
      Math.min(
        15,
        Math.round(10 + Math.max(0, confidence - 0.60) * 12.5)
      )
    );

    aiAdjustment = ai.action === "BUY" ? weight : -weight;
  }

  const score = Math.max(-100, Math.min(100, beforeScore + aiAdjustment));
  const direction = score >= 0 ? "BUY" : "SELL";
  const strength = Math.min(100, Math.max(20, Math.abs(Math.round(score))));
  const action = strength >= 55 ? direction : "WAIT";

  return {
    ...analysis,
    preAiScore: beforeScore,
    aiPrediction: ai,
    aiAdjustment,
    score,
    direction,
    strength,
    action,
  };
}

module.exports = {
  AI_H1_MODEL_PATH,
  AI_H1_SCRIPT_PATH,
  aiFileExists,
  runAiH1,
  getAiH1Status,
  applyAiH1ToAnalysis,
};
