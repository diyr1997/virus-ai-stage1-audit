"use strict";

const fs = require("fs");
const path = require("path");
const { callGemini } = require("./ai-providers");

function readText(name) {
  return fs.readFileSync(path.join(__dirname, name), "utf8");
}

async function runGeminiProjectReview(extraQuestion = "") {
  const context = readText("AI_COUNCIL_PROJECT_CONTEXT.md");
  const task = readText("AI_COUNCIL_FIRST_GEMINI_REVIEW.md");

  const prompt = [
    "You are the Gemini reviewer for the XAU/USD project.",
    "Use the project context and review task below.",
    "This is an advisory audit only. Do not trade, modify files, expose secrets, or change production.",
    "",
    "PROJECT CONTEXT:",
    context,
    "",
    "REVIEW TASK:",
    task,
    extraQuestion ? `\nUSER'S EXTRA QUESTION:\n${extraQuestion}` : "",
    "",
    "Return a practical Russian-language report with prioritized actions.",
  ].join("\n");

  const report = await callGemini(prompt);

  return {
    provider: "gemini",
    type: "project_review",
    created_at: new Date().toISOString(),
    advisory_only: true,
    report,
  };
}

module.exports = { runGeminiProjectReview };
