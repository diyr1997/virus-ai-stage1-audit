"use strict";

/**
 * Local Ollama advisor adapter for the XAU/USD AI Council.
 * Advisory only: this module has no trading or production-write capabilities.
 *
 * The model runs on a private Railway service reachable only over the internal
 * network (no API key, no public egress). The advisor is opt-in via
 * LOCAL_ADVISOR_ENABLED and stays OFF by default; when Ollama is unreachable or
 * slow the call fails as a normal advisor error, so the Council simply marks
 * this member unavailable instead of losing its quorum.
 */

const LOCAL_ADVISOR_ID = "local-qwen";
const DEFAULT_BASE_URL = "http://ollama.railway.internal:11434";
const DEFAULT_MODEL = "qwen2.5:3b";
const DEFAULT_TIMEOUT_MS = 120_000;
const DEFAULT_MAX_OUTPUT_TOKENS = 512;
const TEMPERATURE = 0.2;

function localAdvisorEnabled() {
  return /^(1|true|yes|on|enabled)$/i.test(
    String(process.env.LOCAL_ADVISOR_ENABLED || "false").trim()
  );
}

// A malformed numeric variable must not silently produce NaN: an NaN timeout
// would abort every local call immediately and look like a broken advisor.
function positiveNumber(raw, fallback, minimum) {
  const value = Number(raw);
  if (!Number.isFinite(value) || value <= 0) return fallback;
  return Math.max(minimum, value);
}

function getOllamaConfig() {
  return {
    baseUrl:
      String(process.env.OLLAMA_BASE_URL || DEFAULT_BASE_URL)
        .trim()
        .replace(/\/+$/, "") || DEFAULT_BASE_URL,
    model: String(process.env.OLLAMA_MODEL || DEFAULT_MODEL).trim() || DEFAULT_MODEL,
    timeoutMs: positiveNumber(
      process.env.OLLAMA_TIMEOUT_MS,
      DEFAULT_TIMEOUT_MS,
      5_000
    ),
    maxOutputTokens: positiveNumber(
      process.env.OLLAMA_MAX_OUTPUT_TOKENS,
      DEFAULT_MAX_OUTPUT_TOKENS,
      64
    ),
  };
}

function notConfiguredError() {
  const error = new Error(
    "LOCAL_ADVISOR_ENABLED is not configured: local Ollama advisor is disabled"
  );
  error.code = "NOT_CONFIGURED";
  return error;
}

// Transport-level problems are logged here (never the prompt, never a
// credential) so an operator can see WHY the local advisor went missing; the
// Council itself only records the advisor as unavailable.
function logTransportFailure(message) {
  console.warn(`⚠️ LOCAL ADVISOR (${LOCAL_ADVISOR_ID}): ${message}`);
}

async function postJson(url, body, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  let response;
  try {
    response = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
  } catch (error) {
    // A cold or missing Ollama service must never escape as an unhandled
    // failure: it is reported as an ordinary advisor error and classified by
    // the Council as TIMEOUT / TEMPORARY_ERROR.
    if (controller.signal.aborted) {
      const timeout = new Error(`Ollama request timed out after ${timeoutMs} ms: ${url}`);
      logTransportFailure(timeout.message);
      throw timeout;
    }
    const unreachable = new Error(
      `Ollama is unreachable at ${url}: ${String(error?.message || error).slice(0, 300)}`
    );
    logTransportFailure(unreachable.message);
    throw unreachable;
  } finally {
    clearTimeout(timer);
  }

  const raw = await response.text();
  let data;
  try {
    data = JSON.parse(raw);
  } catch {
    data = { raw };
  }

  if (!response.ok) {
    const error = new Error(
      `Ollama API ${response.status}: ${String(
        data?.error || raw || "Unknown Ollama API error"
      ).slice(0, 1000)}`
    );
    error.statusCode = response.status;
    logTransportFailure(error.message);
    throw error;
  }

  return data;
}

async function callLocalQwen(prompt) {
  if (!localAdvisorEnabled()) throw notConfiguredError();

  const { baseUrl, model, timeoutMs, maxOutputTokens } = getOllamaConfig();
  const data = await postJson(
    `${baseUrl}/api/chat`,
    {
      model,
      messages: [{ role: "user", content: String(prompt || "") }],
      stream: false,
      options: { temperature: TEMPERATURE, num_predict: maxOutputTokens },
    },
    timeoutMs
  );

  const text = String(data?.message?.content || "").trim();
  if (!text) throw new Error("Local Ollama advisor returned empty response");
  return text;
}

module.exports = {
  LOCAL_ADVISOR_ID,
  localAdvisorEnabled,
  getOllamaConfig,
  callLocalQwen,
};
