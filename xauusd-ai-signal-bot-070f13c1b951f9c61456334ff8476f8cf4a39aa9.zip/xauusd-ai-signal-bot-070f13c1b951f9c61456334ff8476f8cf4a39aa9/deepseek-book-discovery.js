"use strict";

const fs = require("fs");
const path = require("path");
const { Pool } = require("pg");
const { callDeepSeek } = require("./ai-providers");

const DATABASE_URL = String(process.env.DATABASE_URL || process.env.DATABASE_PUBLIC_URL || "").trim();
const RUN_KEY = "DEEPSEEK_BOOK_DISCOVERY_2026_08_20_V1";
const EXTERNAL_ADVISORS_ENABLED = !/^(0|false|no|disabled)$/i.test(
  String(process.env.EXTERNAL_ADVISORS_ENABLED || "1")
);
const pool = DATABASE_URL ? new Pool({ connectionString: DATABASE_URL, max: 1, idleTimeoutMillis: 30000 }) : null;

function readSafe(rel, maxChars) {
  try {
    return fs.readFileSync(path.join(__dirname, rel), "utf8").slice(0, maxChars);
  } catch {
    return "";
  }
}

async function ensureSchema() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS ai_integration_reviews (
      run_key VARCHAR(100) PRIMARY KEY,
      provider VARCHAR(40) NOT NULL,
      status VARCHAR(24) NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      finished_at TIMESTAMPTZ,
      response TEXT,
      error TEXT,
      payload JSONB NOT NULL DEFAULT '{}'::jsonb
    )
  `);
}

async function run() {
  if (!EXTERNAL_ADVISORS_ENABLED) {
    console.log("📚 DEEPSEEK BOOK DISCOVERY: disabled by EXTERNAL_ADVISORS_ENABLED=0");
    return;
  }
  if (!pool) return console.warn("📚 DEEPSEEK BOOK DISCOVERY: PostgreSQL unavailable; skipped");
  if (!process.env.DEEPSEEK_API_KEY) return console.warn("📚 DEEPSEEK BOOK DISCOVERY: no API key; skipped");

  await ensureSchema();
  const payload = JSON.stringify({ model: process.env.DEEPSEEK_MODEL || "deepseek-v4-flash", advisory_only: true, live_web_search: false });
  const claimed = await pool.query(
    `INSERT INTO ai_integration_reviews(run_key,provider,status,payload)
     VALUES($1,'deepseek','RUNNING',$2::jsonb)
     ON CONFLICT(run_key) DO UPDATE
       SET status='RUNNING', finished_at=NULL, response=NULL, error=NULL, payload=EXCLUDED.payload
       WHERE ai_integration_reviews.status='FAILED'
     RETURNING run_key`,
    [RUN_KEY, payload]
  );
  if (!claimed.rowCount) {
    console.log("📚 DEEPSEEK BOOK DISCOVERY: already successful/running; skipped");
    return;
  }

  const manifest = readSafe("trading_school/library_manifest.json", 26000);
  const ledger = readSafe("PROJECT_LEDGER_2026-08-20.md", 10000);

  const prompt = `You are DeepSeek acting as an independent research advisor for a private DEMO-only XAU/USD trading project. You do NOT have live web search in this request. Do not claim current prices, current availability, or that you searched the web. Use your own knowledge to propose books; another system will verify editions/access later.\n\nPROJECT CONTEXT:\n${ledger}\n\nCURRENT BOOK/SOURCE MANIFEST:\n${manifest}\n\nTASK:\nIndependently identify authoritative books that are MISSING from the current manifest and could materially improve this exact project, especially XAU/USD M1/M5 with M15/M30/H1 context. Prefer 2000-2026 unless an older work is uniquely foundational. Focus on: (1) market microstructure/order flow/spread/slippage/execution, (2) rigorous technical-analysis falsification and overfit control, (3) systematic/algorithmic research architecture, (4) intraday trend/pullback/reversal/regime detection, (5) modern financial ML/AI validation, (6) futures/commodity/gold context where genuinely useful.\n\nReturn:\nA) TOP 15 missing books ranked for THIS PROJECT, with author, title, approximate edition/year if known, domain, why it helps, what NOT to copy blindly to M1/M5, and 2-4 measurable hypotheses it could generate.\nB) Mark each as CRITICAL/HIGH/MEDIUM/LOW.\nC) Identify 5 books in the CURRENT manifest that are highest priority and explain why.\nD) Identify books/types that are popular but low-value for this project and why.\nE) Propose a clean experiment design to compare: each book independently -> domain synthesis -> unified synthesis -> champion.\nF) Explicitly flag uncertainty in edition/year instead of inventing details.\n\nDo not write production trading code and do not recommend REAL trading. This is research/advisory only.`;

  try {
    const response = String(await callDeepSeek(prompt) || "").trim();
    if (!response) throw new Error("DeepSeek returned empty response");
    await pool.query(
      `UPDATE ai_integration_reviews SET status='SUCCESS',finished_at=NOW(),response=$2,error=NULL WHERE run_key=$1`,
      [RUN_KEY, response]
    );
    console.log(`📚 DEEPSEEK BOOK DISCOVERY SUCCESS | chars=${response.length}`);
    console.log(`📚 DEEPSEEK BOOK DISCOVERY PREVIEW | ${response.replace(/\s+/g, " ").slice(0, 1400)}`);
  } catch (error) {
    const message = String(error?.message || error).slice(0, 3000);
    await pool.query(
      `UPDATE ai_integration_reviews SET status='FAILED',finished_at=NOW(),error=$2 WHERE run_key=$1`,
      [RUN_KEY, message]
    ).catch(() => {});
    console.error(`❌ DEEPSEEK BOOK DISCOVERY: ${message}`);
  }
}

if (EXTERNAL_ADVISORS_ENABLED) {
  console.log("📚 DEEPSEEK BOOK DISCOVERY: armed; starts in 75 sec");
  setTimeout(() => run().catch((e) => console.error("❌ DEEPSEEK BOOK DISCOVERY:", e)), 75000).unref();
} else {
  console.log("📚 DEEPSEEK BOOK DISCOVERY: disabled by EXTERNAL_ADVISORS_ENABLED=0");
}

module.exports = { run };
