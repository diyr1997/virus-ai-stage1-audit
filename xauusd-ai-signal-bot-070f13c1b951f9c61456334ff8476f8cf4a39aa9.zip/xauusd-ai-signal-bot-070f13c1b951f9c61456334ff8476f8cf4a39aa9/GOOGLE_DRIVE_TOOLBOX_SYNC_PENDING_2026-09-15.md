# Google Drive toolbox sync — pending changes, 2026-09-15

Source of truth for this file: `AI_TOOLBOX_FINAL_AUDIT_2026-09-15.md` and
`AI_TOOLBOX_MASTER_INVENTORY_2026-09-15.json` in this same commit.

The Google Drive document `VIRUS AI — INVENTORY OF TOOLS, MODULES & PLANS`
(id `1P3K8avABjez82Ri8bMaUG7zNT4chQCWiXHSKpb_x33s`) **was read successfully**
this session. It was not edited: it is a large, hand-structured, bilingual
document, and this audit's Drive tool access in this session was exercised
read-side only (search/read/metadata). Editing its body is a real,
irreversible-in-place change to a canonical shared document, so it is left
for an explicit follow-up rather than modified as a side effect of a code
audit branch. This file is the exact, honest record of what should be
merged into it, so the change is reviewable before it happens.

## Section D (external open-source tools) — status changes to apply

Update these rows' status text using the "Claude Council isolated smoke-test"
convention already used in the document:

- **Optuna** — add: "Re-verified 2026-09-15 by Claude Code in a fresh isolated
  venv (5.0.0): deterministic TPE minimization test passed (best_x=2.0048 for
  target x=2)."
- **ruptures** — add: "Re-verified 2026-09-15 (1.1.10): PELT recovered all
  injected changepoints exactly on a synthetic 4-segment signal."
- **purgedcv** — add: "Re-verified 2026-09-15 (0.1.6) with the *current* API
  (`PurgedKFold(prediction_times=..., evaluation_times=..., purge_horizon=...,
  embargo_fraction=...)` — the constructor signature has changed since the
  document was last written and the old `purge=`/`embargo=` keyword arguments
  no longer exist). 0 leakage violations across 500 rows / 5 folds."
- **orderflow-metrics** — the exact upstream is now resolved:
  `https://github.com/twowaymind/orderflow-metrics`, MIT, PyPI package
  `orderflow-metrics==0.29.0` (published 2026-09-11). Update the "no url"
  entry accordingly. Formula-parity re-test still needed before any ADOPT.
- **Fynance** — still unresolved. This session's independent WebSearch could
  not locate a matching repository. Recommend either the user supplies the
  exact URL or this candidate is dropped from the list rather than left
  perpetually "needs exact upstream."

## New candidates to add to section D (found in `tools/quant_toolbox`,
`tools/ml_challenger`, `tools/news_toolbox` manifests on the unmerged
`ai/integrate-agent-toolbox-2026-09-10` branch, and in unmerged shadow-model
research branches — none of these were previously in this Drive document)

Quant/ML: Microsoft Qlib, Microsoft RD-Agent, QuantConnect LEAN, vectorbt,
tsfresh, River, NeuralForecast, OpenBB, FinGPT, FinBERT, FinRobot, FinRL,
CCXT, Hummingbot, PyTorch Forecasting (DeepAR/DeepVAR).

News/crawling: Crawl4AI, news-please, Trafilatura, Newspaper4k, Firecrawl
(AGPL-3.0 — license review required before code reuse), RSSHub (AGPL-3.0),
Perplexity MCP (needs `PERPLEXITY_API_KEY`).

Shadow-tested forecasting models (all unmerged, all still prospective-only,
none decision-eligible yet): Chronos-2, Moirai-2.0/uni2ts (license CC-BY-NC-4.0
— **permanently excludes production use**), FinCast (hardware-blocked, needs
≥16GiB RAM), TimesFM-2.5.

Other: `spotware/OpenApiPy` (official cTrader Open API Python SDK, research
track only).

Already in active use, worth noting in section A: `stefan-jansen/machine-learning-for-trading`
(MIT companion repo, ingested as Trading School reading material via
`trading_school/library_manifest.json` — this is not a toolbox candidate, it's
already-adopted reference material).

## Counter note

This document's own counter (46 = 11 done + 23 in-progress + 12 future) counts
*project modules*, not *external tool candidates* — do not merge it with the
72-candidate toolbox count from `AI_TOOLBOX_MASTER_INVENTORY_2026-09-15.json`.
They are two different countable things and should stay reported separately,
exactly as this document already does with its own section D disclaimer
("Статус этого раздела: КАНДИДАТЫ НА РАЗБОР... Они пока не увеличивают
основной счётчик 46 крупных элементов").

## Action needed from the user

Google Drive write access for this session was not exercised for a live
document body edit of this size. If the user wants this merged automatically
next session, say so explicitly; otherwise, apply the above manually or ask
for it in a follow-up turn.
