# Railway Resource Lifecycle Policy

Status: ACTIVE
Scope: VIRUS AI / XAUUSD / AI Council infrastructure

## Core rule
Railway is not a permanent archive for experiments. Keep only resources that are required for the current production-like DEMO/shadow/research system, shared infrastructure, or an explicitly approved active experiment.

## Allowed long-lived resources
A Railway service may remain long-lived only if it is one of:
1. Core database / persistent storage required by the active system.
2. Core gateway / API / bot / worker required for the active DEMO or shadow architecture.
3. Shared toolbox infrastructure used by multiple approved workflows.
4. User-facing application currently maintained (for example the 3D office).
5. A temporary migration service with an explicit retirement condition.

## Experiment lifecycle
Every experimental service must have:
- a single stated purpose;
- an owner/module name;
- a start date;
- a success criterion;
- a failure criterion;
- an explicit retirement action.

After the experiment finishes:
- PASS + selected for adoption: merge/integrate the change into the canonical service, verify it, then delete the temporary experiment service.
- PASS but not selected: preserve only the report/artifact needed for audit, then delete the temporary service.
- FAIL: preserve logs/results needed for diagnosis, then delete the temporary service.
- INCONCLUSIVE: keep only while a concrete next run is scheduled; otherwise archive evidence and delete.

## Replacement rule
Do not create a new permanent Railway service when an existing canonical service can be upgraded safely. Prefer:
1. branch/test in GitHub;
2. CI or short-lived isolated test;
3. review/security gate;
4. deploy to canonical service;
5. verify;
6. remove the temporary test resource.

## Council gate
Before creating a new long-lived Railway service, the AI Council must answer:
- Why can this not run in an existing canonical service or CI job?
- What persistent state does it require?
- What is the expected lifetime?
- What event deletes it?

If these cannot be answered, do not create the service.

## Resource budget
Target steady state: a small fixed set of canonical services, not dozens of one-off services. New temporary experiments must not accumulate. Cleanup is part of the experiment definition, not a later manual task.

## Safety
REAL trading remains disabled unless separately approved through the project safety gates. Experimental services must not receive production trading authority, MT5 real-trading access, or unnecessary secrets.

## Canonical decision states
Each Railway resource must be classified as one of:
- KEEP_CORE
- KEEP_ACTIVE_EXPERIMENT
- PROMOTE_THEN_DELETE_TEST
- ARCHIVE_THEN_DELETE
- DELETE_NOW

The Council should periodically reclassify resources and remove stale experiments.
