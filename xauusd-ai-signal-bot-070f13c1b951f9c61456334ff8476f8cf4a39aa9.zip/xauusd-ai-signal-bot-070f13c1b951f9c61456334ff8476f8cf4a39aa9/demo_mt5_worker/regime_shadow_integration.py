from __future__ import annotations

import time

from impulse_shadow import ImpulseShadowEngine
from regime_shadow import RegimeShadow


_ORIGINAL_OBSERVE = ImpulseShadowEngine.observe


def _install() -> None:
    if getattr(ImpulseShadowEngine, "_regime_shadow_integration_installed", False):
        return

    original_init = ImpulseShadowEngine.__init__

    def patched_init(self, *args, **kwargs):
        original_init(self, *args, **kwargs)
        self.regime_shadow = RegimeShadow()
        self._regime_shadow_last_key = ""
        self._regime_shadow_last_log_at = 0.0

    def patched_observe(self, tick, min_interval: float = 1.0):
        snapshot = _ORIGINAL_OBSERVE(self, tick, min_interval=min_interval)
        if not snapshot or str(snapshot.get("state") or "") == "WARMUP":
            return snapshot

        if "tick_ts" not in snapshot:
            raw_ms = float(getattr(tick, "time_msc", 0) or 0)
            snapshot["tick_ts"] = raw_ms / 1000.0 if raw_ms > 0 else float(getattr(tick, "time", 0) or 0)

        result = self.regime_shadow.evaluate(snapshot)
        snapshot["regime_shadow"] = result

        key = f"{result.get('session')}:{result.get('market_regime')}:{result.get('suggested_fast_threshold')}"
        now = time.monotonic()
        if key != self._regime_shadow_last_key or now - self._regime_shadow_last_log_at >= 30.0:
            print(
                "[V9 REGIME SHADOW] "
                f"session={result.get('session')} | regime={result.get('market_regime')} | "
                f"suggested_fast={result.get('suggested_fast_threshold')} | "
                f"velocity={result.get('velocity_atr_per_min')} | spread_z={result.get('spread_z')} | "
                f"chop={result.get('chop_score')} | persist={result.get('tick_persistence')} | "
                f"eff={result.get('tick_efficiency')} | execution impact=NONE",
                flush=True,
            )
            self._regime_shadow_last_log_at = now
        self._regime_shadow_last_key = key
        return snapshot

    ImpulseShadowEngine.__init__ = patched_init
    ImpulseShadowEngine.observe = patched_observe
    ImpulseShadowEngine._regime_shadow_integration_installed = True


_install()
