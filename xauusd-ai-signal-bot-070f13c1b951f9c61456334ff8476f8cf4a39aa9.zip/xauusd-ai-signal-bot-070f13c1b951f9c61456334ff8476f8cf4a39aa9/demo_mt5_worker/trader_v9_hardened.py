from __future__ import annotations

import json
import time
from datetime import timezone

from psycopg2.extras import Json

from trader_legacy import integer, num, utcnow
from trader_v9 import BasketStateMachine, V9DemoTrader


class V9HardenedDemoTrader(V9DemoTrader):
    """Safety hardening layer for the V9 canonical trader.

    This class deliberately overrides only the external-send critical path and
    reconciliation/slot accounting so the main V9 policy remains easy to audit.
    """

    def ensure_schema(self):
        super().ensure_schema()
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute("ALTER TABLE demo_trades ADD COLUMN IF NOT EXISTS basket_slot INTEGER")
                # A normal UNIQUE index allows many NULLs in PostgreSQL and can be
                # inferred by ON CONFLICT(order_claim_key). Keep the old partial
                # index harmlessly for upgrade compatibility.
                cur.execute(
                    "CREATE UNIQUE INDEX IF NOT EXISTS uq_demo_trades_order_claim_key_v9 ON demo_trades(order_claim_key)"
                )
        finally:
            conn.close()

    def reject_trade(self, trade_id, reason, details=None):
        super().reject_trade(trade_id, reason, details)
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "UPDATE demo_trades SET order_claim_key=NULL WHERE id=%s AND status='REJECTED'",
                    (int(trade_id),),
                )
        finally:
            conn.close()

    def max_basket_slot(self, basket_id):
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT COALESCE(MAX(basket_slot),0)
                    FROM demo_trades
                    WHERE symbol=%s AND basket_id=%s
                      AND status IN('PENDING','OPEN','CLOSED')
                    """,
                    (self.symbol, str(basket_id)),
                )
                row = cur.fetchone()
        finally:
            conn.close()
        return integer(row[0], 0) if row else 0

    def next_basket_slot(self, side, basket_id):
        live_count = sum(
            1 for p in self.bot_mt5_positions()
            if self.mt5_position_side(p) == str(side).upper()
        )
        return max(self.max_basket_slot(basket_id), live_count) + 1

    def _trade_id_from_comment(self, position):
        for part in self._position_comment(position).replace("|", " ").split():
            if part.startswith("t") and part[1:].isdigit():
                return integer(part[1:], 0)
        return 0

    def reconcile_open_ticket_comments(self):
        rows = {int(r["id"]): r for r in self._active_trade_rows()}
        for position in self.bot_mt5_positions():
            ticket = integer(getattr(position, "ticket", 0), 0)
            trade_id = self._trade_id_from_comment(position)
            if not ticket or not trade_id or trade_id not in rows:
                continue
            row = rows[trade_id]
            if row.get("status") == "PENDING":
                entry = num(getattr(position, "price_open", 0.0)) or num(row.get("entry_price"))
                self.mark_open(
                    trade_id,
                    ticket,
                    entry,
                    num(row.get("entry_price")) or entry,
                    {"reconciled_from_comment": True},
                )
                continue
            if row.get("status") == "OPEN" and integer(row.get("mt5_ticket"), 0) != ticket:
                conn = self.connect()
                try:
                    with conn.cursor() as cur:
                        cur.execute(
                            """
                            UPDATE demo_trades
                            SET mt5_ticket=%s,
                                payload=COALESCE(payload,'{}'::jsonb) || %s::jsonb
                            WHERE id=%s AND status='OPEN'
                            """,
                            (str(ticket), json.dumps({"ticket_reconciled_from_comment": True}), trade_id),
                        )
                finally:
                    conn.close()

    def reconcile_pending_claims(self):
        """Return True only when no unresolved PENDING order claim remains."""
        rows = [r for r in self._active_trade_rows() if r.get("status") == "PENDING"]
        unresolved = []
        for row in rows:
            trade_id = int(row["id"])
            live = self._position_for_trade_id(trade_id)
            if live is not None:
                entry = num(getattr(live, "price_open", 0.0)) or num(row.get("entry_price"))
                self.mark_open(
                    trade_id,
                    integer(getattr(live, "ticket", 0), 0),
                    entry,
                    num(row.get("entry_price")) or entry,
                    {"reconciled_after_restart": True},
                )
                continue

            created = row.get("created_at")
            if created is None:
                unresolved.append(trade_id)
                continue
            if created.tzinfo is None:
                created = created.replace(tzinfo=timezone.utc)
            age = max(0.0, (utcnow() - created).total_seconds())
            payload = row.get("payload") or {}
            if isinstance(payload, str):
                try:
                    payload = json.loads(payload)
                except Exception:
                    payload = {}

            if age < self.CLAIM_GRACE_SECONDS:
                unresolved.append(trade_id)
                continue

            if not bool(payload.get("send_attempted")):
                self.reject_trade(
                    trade_id,
                    "STALE_UNSENT_CLAIM",
                    {"age_sec": age, "send_attempted": False},
                )
                continue

            # Never guess that an ambiguous send failed. Keep the claim alive and
            # block every new order until a later pass sees the position/comment.
            deal = self._history_deal_for_trade_id(trade_id)
            self._set_pending_payload(
                trade_id,
                {
                    "reconcile_required": True,
                    "reconcile_checked_at": utcnow().isoformat(),
                    "history_evidence": bool(deal is not None),
                    "age_sec": age,
                },
            )
            unresolved.append(trade_id)
        return not unresolved

    def unknown_live_positions(self):
        self.reconcile_open_ticket_comments()
        known = self._db_open_ticket_map()
        return [
            p for p in self.bot_mt5_positions()
            if integer(getattr(p, "ticket", 0), 0) not in known
        ]

    def reconcile_or_fail_closed(self):
        if not self.reconcile_pending_claims():
            now = time.monotonic()
            if now - self._last_reconcile_block_event >= 15.0:
                self.event(
                    "RECONCILE_BLOCKED",
                    payload={"reason": "UNRESOLVED_PENDING_ORDER_CLAIM"},
                )
                self._last_reconcile_block_event = now
            return False
        unknown = self.unknown_live_positions()
        if not unknown:
            return True
        now = time.monotonic()
        if now - self._last_reconcile_block_event >= 15.0:
            self.event(
                "RECONCILE_BLOCKED",
                payload={
                    "reason": "UNKNOWN_LIVE_MT5_POSITION",
                    "tickets": [str(integer(getattr(p, "ticket", 0), 0)) for p in unknown],
                },
            )
            self._last_reconcile_block_event = now
        return False

    def claim_pending_trade(
        self,
        candidate,
        lot,
        price,
        tp,
        account,
        mode,
        slot_no,
        risk_meta,
        basket_id,
        fence_token,
    ):
        claim_key = self._claim_key(basket_id, slot_no)
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO demo_trades(
                        candidate_id,analysis_id,symbol,timeframe,side,lot,
                        planned_price,sl,tp,tp1,tp2,tp3,status,demo_account,payload,
                        basket_id,basket_slot,order_claim_key,fence_token
                    ) VALUES(
                        %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
                        'PENDING',%s,%s,%s,%s,%s,%s
                    )
                    ON CONFLICT(order_claim_key) DO NOTHING
                    RETURNING id
                    """,
                    (
                        int(candidate["id"]),
                        int(candidate["analysis_id"]),
                        self.symbol,
                        str(candidate["timeframe"]),
                        str(candidate["side"]).upper(),
                        float(lot),
                        float(price),
                        num(candidate["sl"]) or None,
                        tp or None,
                        num(candidate["tp1"]) or None,
                        num(candidate["tp2"]) or None,
                        num(candidate["tp3"]) or None,
                        str(getattr(account, "login", "")),
                        Json({"risk_mode": mode, "slot_no": slot_no, **risk_meta}),
                        str(basket_id),
                        int(slot_no),
                        claim_key,
                        int(fence_token),
                    ),
                )
                row = cur.fetchone()
                return int(row[0]) if row else None
        finally:
            conn.close()

    def _final_send_guard(self, side, fence_token):
        # Structural checks first. The forced fencing round trip is intentionally
        # performed after the PENDING payload write and immediately before order_send.
        ok, reason, _ = self.direction_guard(side)
        if not ok:
            return False, reason
        if self.unknown_live_positions():
            return False, "UNKNOWN_LIVE_MT5_POSITION"
        if fence_token is None:
            return False, "NO_FENCE_TOKEN"
        return True, "OK"

    def send_order(self, candidate, tick, account, lot, mode, slot_no, risk_meta):
        self.assert_demo(account)
        side = str(candidate["side"]).upper()
        price = self.current_price(side, tick)
        sl = num(candidate["sl"])
        tp = self.tp_for_slot(candidate, slot_no)
        basket_id = str(candidate.get("_v9_basket_id") or "")
        fence_token = self.ownership.current_token()
        if side not in {"BUY", "SELL"} or lot <= 0 or price <= 0 or sl <= 0 or tp <= 0 or not basket_id or fence_token is None:
            return False

        trade_id = self.claim_pending_trade(
            candidate, lot, price, tp, account, mode, slot_no, risk_meta, basket_id, fence_token
        )
        if trade_id is None:
            self.event(
                "ORDER_CLAIM_BLOCKED",
                candidate.get("id"),
                payload={"basket_id": basket_id, "slot_no": slot_no},
            )
            return False

        before = self.matching_position_tickets(side)
        accepted = {
            integer(getattr(self.mt5, "TRADE_RETCODE_DONE", 10009)),
            integer(getattr(self.mt5, "TRADE_RETCODE_DONE_PARTIAL", 10010)),
            integer(getattr(self.mt5, "TRADE_RETCODE_PLACED", 10008)),
        }
        last_details = {"stage": "not_sent"}

        for filling in self.fill_modes():
            request = {
                "action": self.mt5.TRADE_ACTION_DEAL,
                "symbol": self.symbol,
                "volume": float(lot),
                "type": self.order_type(side),
                "price": float(price),
                "sl": float(sl),
                "tp": float(tp),
                "deviation": int(self.deviation),
                "magic": int(self.magic),
                "comment": f"XDV9 t{trade_id} f{fence_token}"[:31],
                "type_time": self.mt5.ORDER_TIME_GTC,
                "type_filling": filling,
            }
            check = self.mt5.order_check(request)
            if check is None:
                last_details = {"stage": "order_check", "error": str(self.mt5.last_error()), "filling": filling}
                continue
            check_retcode = integer(getattr(check, "retcode", -1), -1)
            check_ok = {0, integer(getattr(self.mt5, "TRADE_RETCODE_DONE", 10009))}
            if check_retcode not in check_ok:
                last_details = {
                    "stage": "order_check",
                    "retcode": check_retcode,
                    "comment": str(getattr(check, "comment", "")),
                    "filling": filling,
                }
                continue

            guard_ok, guard_reason = self._final_send_guard(side, fence_token)
            if not guard_ok:
                self.reject_trade(
                    trade_id,
                    "FINAL_SEND_GUARD_BLOCKED",
                    {"reason": guard_reason, "fence_token": fence_token},
                )
                return False

            self._set_pending_payload(
                trade_id,
                {
                    "send_attempted": True,
                    "send_attempted_at": utcnow().isoformat(),
                    "fence_token": fence_token,
                },
            )
            # This forced DB round trip is the last operation before MT5 order_send.
            if not self.ownership.is_current(fence_token, force=True):
                self.reject_trade(
                    trade_id,
                    "STALE_OR_LOST_FENCE",
                    {"stage": "immediately_before_order_send", "fence_token": fence_token},
                )
                self.event(
                    "ORDER_SEND_BLOCKED",
                    candidate.get("id"),
                    trade_id,
                    {"reason": "STALE_OR_LOST_FENCE", "stage": "immediately_before_order_send"},
                )
                return False

            result = self.mt5.order_send(request)
            if result is None:
                last_details = {
                    "stage": "order_send_ambiguous",
                    "error": str(self.mt5.last_error()),
                    "filling": filling,
                }
                self._set_pending_payload(trade_id, {"ambiguous_send": True, **last_details})
                self.event("ORDER_SEND_AMBIGUOUS", candidate["id"], trade_id, last_details)
                return False

            retcode = integer(getattr(result, "retcode", -1), -1)
            if retcode not in accepted:
                last_details = {
                    "stage": "order_send",
                    "retcode": retcode,
                    "comment": str(getattr(result, "comment", "")),
                    "filling": filling,
                }
                continue

            time.sleep(0.2)
            after = self.matching_position_tickets(side)
            new_tickets = list(after - before)
            live = self._position_for_trade_id(trade_id)
            ticket = (
                new_tickets[0]
                if new_tickets
                else integer(getattr(live, "ticket", 0), 0) if live is not None else 0
            )
            entry = (
                num(getattr(live, "price_open", 0.0))
                if live is not None
                else num(getattr(result, "price", 0.0), price) or price
            )
            if ticket:
                self.mark_open(
                    trade_id,
                    ticket,
                    entry,
                    price,
                    {
                        "order_id": str(getattr(result, "order", "")),
                        "deal_id": str(getattr(result, "deal", "")),
                        "retcode": retcode,
                        "filling": filling,
                        "basket_id": basket_id,
                        "fence_token": fence_token,
                    },
                )
                self.update_candidate_status(candidate["id"], "ACTIVE")
                self.event(
                    "TRADE_OPENED",
                    candidate["id"],
                    trade_id,
                    {
                        "side": side,
                        "lot": lot,
                        "slot_no": slot_no,
                        "risk_mode": mode,
                        "entry": entry,
                        "sl": sl,
                        "tp": tp,
                        "risk_amount": risk_meta.get("risk_amount"),
                        "ticket": str(ticket),
                        "basket_id": basket_id,
                        "fence_token": fence_token,
                    },
                )
            else:
                self._set_pending_payload(
                    trade_id,
                    {
                        "accepted_waiting_reconcile": True,
                        "order_id": str(getattr(result, "order", "")),
                        "deal_id": str(getattr(result, "deal", "")),
                        "retcode": retcode,
                    },
                )
                self.event(
                    "ORDER_ACCEPTED_WAITING_RECONCILE",
                    candidate["id"],
                    trade_id,
                    {"basket_id": basket_id, "fence_token": fence_token},
                )
            return True

        self.reject_trade(trade_id, "ORDER_REJECTED", last_details)
        self.event("ORDER_REJECTED", candidate["id"], trade_id, last_details)
        return False


HardenedDemoTrader = V9HardenedDemoTrader
