from __future__ import annotations

import os

from trader_legacy import integer, num
from trader_v9_hardened_v4 import V9HardenedV4DemoTrader


class V9HardenedV5DemoTrader(V9HardenedV4DemoTrader):
    """DEMO strong-impulse exit-target hardening.

    V4 already gives FAST80 a separate confirmation bypass while preserving every
    structural and account safety guard. V5 keeps those entry rules unchanged and
    only prevents a strong impulse from being cut at the nearest TP1 target.

    Policy:
      * strength 80-89 -> use at least TP2 when available;
      * strength 90-100 -> use TP3 when available;
      * ordinary signals (<80) keep the legacy slot-based TP policy exactly;
      * SL, DEMO-only guard, risk budgets and all V9 fencing remain untouched.

    The thresholds are configurable so the policy can be tuned from historical
    results without changing code.
    """

    FAST_EXIT_TP3_MIN_STRENGTH = max(
        80,
        min(100, int(os.getenv("FAST_EXIT_TP3_MIN_STRENGTH", "90"))),
    )

    PIPELINE_EVENTS = V9HardenedV4DemoTrader.PIPELINE_EVENTS | {
        "FAST_EXIT_TARGET_EXTENDED",
    }

    @staticmethod
    def _valid_target(side, entry_ref, target):
        side = str(side or "").upper()
        entry_ref = num(entry_ref)
        target = num(target)
        if target <= 0:
            return False
        if entry_ref <= 0:
            return True
        if side == "BUY":
            return target > entry_ref
        if side == "SELL":
            return target < entry_ref
        return False

    def tp_for_slot(self, candidate, slot_no):
        legacy_tp = super().tp_for_slot(candidate, slot_no)
        strength = integer(candidate.get("strength"), 0)
        if strength < self.FAST_ENTRY_MIN_STRENGTH:
            return legacy_tp

        side = str(candidate.get("side") or "").upper()
        entry_ref = (
            num(candidate.get("confirmation_price"))
            or num(candidate.get("analysis_price"))
        )
        tp1 = num(candidate.get("tp1"))
        tp2 = num(candidate.get("tp2"))
        tp3 = num(candidate.get("tp3"))

        if strength >= self.FAST_EXIT_TP3_MIN_STRENGTH:
            preferred = (("TP3", tp3), ("TP2", tp2), ("TP1", tp1))
        else:
            preferred = (("TP2", tp2), ("TP3", tp3), ("TP1", tp1))

        selected_name = "LEGACY"
        selected_tp = legacy_tp
        for name, target in preferred:
            if self._valid_target(side, entry_ref, target):
                selected_name = name
                selected_tp = target
                break

        # Never replace a valid legacy target with an invalid/missing one.
        if not self._valid_target(side, entry_ref, selected_tp):
            selected_name = "LEGACY"
            selected_tp = legacy_tp

        if num(selected_tp) != num(legacy_tp):
            self.event(
                "FAST_EXIT_TARGET_EXTENDED",
                candidate.get("id"),
                payload={
                    "reason": "STRONG_IMPULSE_AVOID_EARLY_TP1",
                    "strength": strength,
                    "slot_no": int(slot_no),
                    "side": side,
                    "legacy_tp": num(legacy_tp),
                    "selected_target": selected_name,
                    "selected_tp": num(selected_tp),
                    "tp1": tp1,
                    "tp2": tp2,
                    "tp3": tp3,
                    "tp3_min_strength": self.FAST_EXIT_TP3_MIN_STRENGTH,
                },
            )

        return selected_tp


DemoTraderV9Final = V9HardenedV5DemoTrader
