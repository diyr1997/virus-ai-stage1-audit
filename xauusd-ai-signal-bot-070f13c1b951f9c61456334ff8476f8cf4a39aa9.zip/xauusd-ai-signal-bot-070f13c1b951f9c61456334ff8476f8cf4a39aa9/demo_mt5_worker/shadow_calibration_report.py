from __future__ import annotations

from typing import Any


class ShadowCalibrationReport:
    """READ ONLY: aggregates SHADOW_FAST_OUTCOME events for calibration."""

    def __init__(self, connect_fn, symbol: str):
        self.connect_fn = connect_fn
        self.symbol = str(symbol)

    def summarize(self, lookback_hours: int = 24, min_samples: int = 1) -> list[dict[str, Any]]:
        conn = self.connect_fn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT
                        COALESCE(payload->>'shadow_reason', 'UNKNOWN') AS reason,
                        COALESCE(payload->>'shadow_recommendation', 'UNKNOWN') AS recommendation,
                        COALESCE((payload->>'horizon_sec')::INT, 0) AS horizon_sec,
                        COUNT(*) AS samples,
                        AVG(NULLIF(payload->>'net_atr','')::DOUBLE PRECISION) AS avg_net_atr,
                        AVG(NULLIF(payload->>'mfe_atr','')::DOUBLE PRECISION) AS avg_mfe_atr,
                        AVG(NULLIF(payload->>'mae_atr','')::DOUBLE PRECISION) AS avg_mae_atr,
                        AVG(CASE WHEN COALESCE((payload->>'would_have_helped')::BOOLEAN, FALSE) THEN 1.0 ELSE 0.0 END) AS helped_rate
                    FROM demo_trader_events
                    WHERE event_type = 'SHADOW_FAST_OUTCOME'
                      AND symbol = %s
                      AND created_at >= NOW() - (%s * INTERVAL '1 hour')
                    GROUP BY 1,2,3
                    HAVING COUNT(*) >= %s
                    ORDER BY horizon_sec ASC, samples DESC, reason ASC
                    """,
                    (self.symbol, max(1, int(lookback_hours)), max(1, int(min_samples))),
                )
                rows = cur.fetchall()
        finally:
            conn.close()

        result: list[dict[str, Any]] = []
        for reason, recommendation, horizon, samples, avg_net, avg_mfe, avg_mae, helped in rows:
            result.append({
                "reason": str(reason),
                "recommendation": str(recommendation),
                "horizon_sec": int(horizon or 0),
                "samples": int(samples or 0),
                "avg_net_atr": round(float(avg_net), 4) if avg_net is not None else None,
                "avg_mfe_atr": round(float(avg_mfe), 4) if avg_mfe is not None else None,
                "avg_mae_atr": round(float(avg_mae), 4) if avg_mae is not None else None,
                "helped_rate": round(float(helped), 4) if helped is not None else None,
                "read_only": True,
                "execution_impact": "NONE",
            })
        return result
