from __future__ import annotations

from direction_shadow import DirectionShadowEngine
from direction_outcome_tracker import DirectionOutcomeTracker
from impulse_shadow import ImpulseShadowEngine


# SHADOW ONLY integration. No entry/exit/order methods are touched.
_original_impulse_init = ImpulseShadowEngine.__init__
_original_impulse_observe = ImpulseShadowEngine.observe


def _patched_impulse_init(self, *args, **kwargs):
    _original_impulse_init(self, *args, **kwargs)
    self.direction_shadow_v2 = DirectionShadowEngine(self.mt5, self.symbol)


def _patched_impulse_observe(self, tick, min_interval=1.0):
    snapshot = _original_impulse_observe(self, tick, min_interval=min_interval)
    if not snapshot or str(snapshot.get("state") or "").upper() == "WARMUP":
        return snapshot
    snapshot["legacy_direction"] = str(snapshot.get("direction") or "FLAT").upper()
    try:
        direction = self.direction_shadow_v2.observe(snapshot)
        snapshot.update(direction)
    except Exception as exc:
        snapshot["direction_v2_error"] = str(exc)[:300]
    return snapshot


ImpulseShadowEngine.__init__ = _patched_impulse_init
ImpulseShadowEngine.observe = _patched_impulse_observe


from trader_v9_hardened_v4 import V9HardenedV4DemoTrader  # noqa: E402

_original_v4_init = V9HardenedV4DemoTrader.__init__
_original_v4_event = V9HardenedV4DemoTrader.event


def _patched_v4_init(self, *args, **kwargs):
    _original_v4_init(self, *args, **kwargs)
    self.direction_outcome_tracker_v2 = DirectionOutcomeTracker(self.mt5, self.symbol)


def _patched_v4_event(self, event_type, candidate_id=None, trade_id=None, payload=None):
    _original_v4_event(self, event_type, candidate_id, trade_id, payload)
    if str(event_type or "").upper() != "SHADOW_IMPULSE_STATE":
        return
    data = payload or {}
    if not data.get("direction_v2"):
        return
    direction_payload = {
        key: data.get(key)
        for key in (
            "direction_v2", "legacy_direction", "direction_score", "direction_confidence", "direction_state",
            "supportive_tf_weight", "opposing_tf_weight", "tick_component", "tf_component",
            "direction_flips", "tf", "tick_ts", "execution_impact", "shadow_only",
            "impulse_score", "pullback_score", "weakening_score", "reversal_score", "chop_score",
        )
        if key in data
    }
    regime = data.get("regime_shadow")
    if isinstance(regime, dict):
        direction_payload["market_regime"] = str(regime.get("market_regime") or "UNKNOWN").upper()
        direction_payload["trading_session"] = str(regime.get("session") or "UNKNOWN").upper()
    _original_v4_event(self, "SHADOW_DIRECTION_V2", candidate_id, trade_id, direction_payload)
    try:
        outcomes = self.direction_outcome_tracker_v2.observe(direction_payload)
    except Exception as exc:
        _original_v4_event(self, "SHADOW_DIRECTION_OUTCOME_ERROR", candidate_id, trade_id, {
            "reason": str(exc)[:300], "execution_impact": "NONE", "shadow_only": True,
        })
        return
    for outcome in outcomes:
        _original_v4_event(self, "SHADOW_DIRECTION_OUTCOME", candidate_id, trade_id, outcome)


V9HardenedV4DemoTrader.__init__ = _patched_v4_init
V9HardenedV4DemoTrader.event = _patched_v4_event
print("[V9 DIRECTION SHADOW] Direction Engine V2 + OLD-vs-V2 segmented outcomes ACTIVE | execution impact=NONE", flush=True)
