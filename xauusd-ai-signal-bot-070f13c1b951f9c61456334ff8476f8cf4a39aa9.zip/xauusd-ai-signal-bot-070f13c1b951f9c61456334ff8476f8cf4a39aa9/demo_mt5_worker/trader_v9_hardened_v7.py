from __future__ import annotations

import time

from trader_legacy import integer, num, utcnow
from trader_v9_hardened_v6 import V9HardenedV6DemoTrader


class V9HardenedV7DemoTrader(V9HardenedV6DemoTrader):
    """Canonical V7: re-read MT5 account immediately before every order_send.

    The worker already blocks non-DEMO accounts at connection time and each loop,
    but an MT5 account can theoretically change between that check and a later
    order_send. V7 closes that time-of-check/time-of-use gap for both new DEAL
    orders and protective SL/TP modifications.
    """

    PIPELINE_EVENTS = V9HardenedV6DemoTrader.PIPELINE_EVENTS | {
        "FRESH_ACCOUNT_SEND_BLOCKED",
    }

    def _fresh_demo_account_guard(self, expected_login=None):
        getter = getattr(self.mt5, "account_info", None)
        if not callable(getter):
            return False, "ACCOUNT_INFO_UNAVAILABLE", None
        try:
            account = getter()
        except Exception as exc:
            return False, f"ACCOUNT_INFO_EXCEPTION:{type(exc).__name__}", None
        if account is None:
            return False, "ACCOUNT_INFO_NONE", None

        demo_mode = integer(getattr(self.mt5, "ACCOUNT_TRADE_MODE_DEMO", 0), 0)
        trade_mode = integer(getattr(account, "trade_mode", -999), -999)
        if trade_mode != demo_mode:
            return False, "FRESH_ACCOUNT_NOT_DEMO", account

        expected = integer(expected_login, 0)
        current = integer(getattr(account, "login", 0), 0)
        if expected > 0 and current > 0 and current != expected:
            return False, "FRESH_ACCOUNT_LOGIN_CHANGED", account

        return True, "OK", account

    def send_order(self, candidate, tick, account, lot, mode, slot_no, risk_meta):
        # Preserve all V9 semantics, but put the fresh account check directly next
        # to order_send instead of relying only on the account object from the loop.
        self.assert_demo(account)
        side = str(candidate["side"]).upper()
        price = self.current_price(side, tick)
        sl = num(candidate["sl"])
        tp = self.tp_for_slot(candidate, slot_no)
        basket_id = str(candidate.get("_v9_basket_id") or "")
        fence_token = self.ownership.current_token()
        if side not in {"BUY", "SELL"} or lot <= 0 or price <= 0 or sl <= 0 or tp <= 0 or not basket_id or fence_token is None:
            return False

        trade_id = self.claim_pending_trade(
            candidate, lot, price, tp, account, mode, slot_no, risk_meta, basket_id, fence_token
        )
        if trade_id is None:
            self.event("ORDER_CLAIM_BLOCKED", candidate.get("id"), payload={"basket_id": basket_id, "slot_no": slot_no})
            return False

        before = self.matching_position_tickets(side)
        accepted = {
            integer(getattr(self.mt5, "TRADE_RETCODE_DONE", 10009)),
            integer(getattr(self.mt5, "TRADE_RETCODE_DONE_PARTIAL", 10010)),
            integer(getattr(self.mt5, "TRADE_RETCODE_PLACED", 10008)),
        }
        last_details = {"stage": "not_sent"}
        ambiguous_send = False
        expected_login = integer(getattr(account, "login", 0), 0)

        for filling in self.fill_modes():
            request = {
                "action": self.mt5.TRADE_ACTION_DEAL,
                "symbol": self.symbol,
                "volume": float(lot),
                "type": self.order_type(side),
                "price": float(price),
                "sl": float(sl),
                "tp": float(tp),
                "deviation": int(self.deviation),
                "magic": int(self.magic),
                "comment": f"XDV9 t{trade_id} f{fence_token}"[:31],
                "type_time": self.mt5.ORDER_TIME_GTC,
                "type_filling": filling,
            }
            check = self.mt5.order_check(request)
            if check is None:
                last_details = {"stage": "order_check", "error": str(self.mt5.last_error()), "filling": filling}
                continue
            check_retcode = integer(getattr(check, "retcode", -1), -1)
            check_ok = {0, integer(getattr(self.mt5, "TRADE_RETCODE_DONE", 10009))}
            if check_retcode not in check_ok:
                last_details = {
                    "stage": "order_check",
                    "retcode": check_retcode,
                    "comment": str(getattr(check, "comment", "")),
                    "filling": filling,
                }
                continue

            guard_ok, guard_reason = self._final_send_guard(side, fence_token)
            if not guard_ok:
                self.reject_trade(trade_id, "FINAL_SEND_GUARD_BLOCKED", {"reason": guard_reason, "fence_token": fence_token})
                self.event("ORDER_SEND_BLOCKED", candidate.get("id"), trade_id, {"reason": guard_reason})
                return False

            # Critical V7 guard: query the terminal again after order_check and all
            # other gates, immediately before the actual broker-facing send.
            fresh_ok, fresh_reason, _ = self._fresh_demo_account_guard(expected_login)
            if not fresh_ok:
                self.reject_trade(trade_id, "FINAL_SEND_GUARD_BLOCKED", {"reason": fresh_reason, "fence_token": fence_token})
                self.event("FRESH_ACCOUNT_SEND_BLOCKED", candidate.get("id"), trade_id, {"reason": fresh_reason})
                return False

            self._set_pending_payload(
                trade_id,
                {"send_attempted": True, "send_attempted_at": utcnow().isoformat(), "fence_token": fence_token},
            )
            # No account-independent work is allowed between this fresh guard and
            # the send other than the bookkeeping line above. The worker remains
            # DEMO-only; any account-mode mismatch on the next pass also aborts.
            fresh_ok, fresh_reason, _ = self._fresh_demo_account_guard(expected_login)
            if not fresh_ok:
                self.reject_trade(trade_id, "FINAL_SEND_GUARD_BLOCKED", {"reason": fresh_reason, "fence_token": fence_token})
                self.event("FRESH_ACCOUNT_SEND_BLOCKED", candidate.get("id"), trade_id, {"reason": fresh_reason})
                return False

            # This forced DB round trip is the last operation before MT5 order_send.
            # _final_send_guard above only checks that a fence_token exists, not
            # that it is still the current one; without this re-check a worker
            # that lost ownership (fence superseded elsewhere) would still reach
            # order_send with its stale token.
            if not self.ownership.is_current(fence_token, force=True):
                self.reject_trade(trade_id, "STALE_OR_LOST_FENCE", {"stage": "immediately_before_order_send", "fence_token": fence_token})
                self.event("ORDER_SEND_BLOCKED", candidate.get("id"), trade_id, {"reason": "STALE_OR_LOST_FENCE", "stage": "immediately_before_order_send"})
                return False
            result = self.mt5.order_send(request)

            if result is None:
                ambiguous_send = True
                last_details = {"stage": "order_send_ambiguous", "error": str(self.mt5.last_error()), "filling": filling}
                break
            retcode = integer(getattr(result, "retcode", -1), -1)
            if retcode not in accepted:
                last_details = {
                    "stage": "order_send",
                    "retcode": retcode,
                    "comment": str(getattr(result, "comment", "")),
                    "filling": filling,
                }
                continue

            time.sleep(0.2)
            after = self.matching_position_tickets(side)
            new_tickets = list(after - before)
            ticket = new_tickets[0] if new_tickets else integer(
                getattr(result, "order", 0) or getattr(result, "deal", 0)
            )
            entry = num(getattr(result, "price", 0.0), price) or price
            self.mark_open(
                trade_id,
                ticket,
                entry,
                price,
                {
                    "order_id": str(getattr(result, "order", "")),
                    "deal_id": str(getattr(result, "deal", "")),
                    "retcode": retcode,
                    "filling": filling,
                    "basket_id": basket_id,
                    "fence_token": fence_token,
                },
            )
            self.update_candidate_status(candidate["id"], "ACTIVE")
            self.event(
                "TRADE_OPENED",
                candidate["id"],
                trade_id,
                {
                    "side": side,
                    "lot": lot,
                    "slot_no": slot_no,
                    "risk_mode": mode,
                    "entry": entry,
                    "sl": sl,
                    "tp": tp,
                    "risk_amount": risk_meta.get("risk_amount"),
                    "ticket": str(ticket),
                    "basket_id": basket_id,
                    "fence_token": fence_token,
                },
            )
            return True

        if ambiguous_send:
            self._set_pending_payload(trade_id, {"ambiguous_send": True, **last_details})
            self.event("ORDER_SEND_AMBIGUOUS", candidate["id"], trade_id, last_details)
            return False
        self.reject_trade(trade_id, "ORDER_REJECTED", last_details)
        self.event("ORDER_REJECTED", candidate["id"], trade_id, last_details)
        return False

    def _modify_position_sl(self, row, position, new_sl, stage):
        ticket = integer(getattr(position, "ticket", 0), 0)
        if ticket <= 0 or new_sl is None:
            return False
        current_tp = num(getattr(position, "tp", 0.0)) or num(row.get("db_tp"))
        request = {
            "action": self.mt5.TRADE_ACTION_SLTP,
            "symbol": self.symbol,
            "position": ticket,
            "sl": float(new_sl),
            "tp": float(current_tp),
            "magic": int(self.magic),
        }

        fresh_ok, fresh_reason, _ = self._fresh_demo_account_guard()
        if not fresh_ok:
            self.event(
                "FRESH_ACCOUNT_SEND_BLOCKED",
                row.get("candidate_id"),
                row.get("trade_id"),
                {"reason": fresh_reason, "ticket": str(ticket), "operation": "SLTP"},
            )
            return False

        try:
            result = self.mt5.order_send(request)
        except Exception as exc:
            self.event(
                "FAST_PROTECT_SL_BLOCKED",
                row.get("candidate_id"),
                row.get("trade_id"),
                {"reason": "SLTP_EXCEPTION", "error": str(exc), "ticket": str(ticket)},
            )
            return False
        if result is None:
            self.event(
                "FAST_PROTECT_SL_BLOCKED",
                row.get("candidate_id"),
                row.get("trade_id"),
                {"reason": "SLTP_NONE", "ticket": str(ticket), "error": str(self.mt5.last_error())},
            )
            return False
        retcode = integer(getattr(result, "retcode", -1), -1)
        accepted = {
            integer(getattr(self.mt5, "TRADE_RETCODE_DONE", 10009), 10009),
            integer(getattr(self.mt5, "TRADE_RETCODE_NO_CHANGES", 10025), 10025),
        }
        if retcode not in accepted:
            self.event(
                "FAST_PROTECT_SL_BLOCKED",
                row.get("candidate_id"),
                row.get("trade_id"),
                {
                    "reason": "SLTP_REJECTED",
                    "retcode": retcode,
                    "comment": str(getattr(result, "comment", "")),
                    "ticket": str(ticket),
                    "requested_sl": float(new_sl),
                },
            )
            return False

        self.event(
            "FAST_PROTECT_SL_MOVED",
            row.get("candidate_id"),
            row.get("trade_id"),
            {
                "reason": stage,
                "strength": integer(row.get("strength"), 0),
                "side": str(row.get("side") or "").upper(),
                "ticket": str(ticket),
                "entry": num(getattr(position, "price_open", 0.0)) or num(row.get("entry_price")),
                "old_sl": num(getattr(position, "sl", 0.0)) or num(row.get("db_sl")),
                "new_sl": float(new_sl),
                "tp": current_tp,
                "tp1": num(row.get("tp1")),
                "tp2": num(row.get("tp2")),
                "tp3": num(row.get("tp3")),
            },
        )
        return True


DemoTraderV9Final = V9HardenedV7DemoTrader
