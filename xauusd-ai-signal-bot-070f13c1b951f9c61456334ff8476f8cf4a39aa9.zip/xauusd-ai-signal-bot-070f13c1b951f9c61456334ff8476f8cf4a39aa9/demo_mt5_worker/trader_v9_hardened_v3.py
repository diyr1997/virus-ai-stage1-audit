from __future__ import annotations

import json
import os
from datetime import datetime, timezone

from psycopg2.extras import Json

from trader_legacy import num, utcnow
from trader_v9_hardened_v2 import V9HardenedV2DemoTrader


class V9HardenedV3DemoTrader(V9HardenedV2DemoTrader):
    """Final commit-order, diagnostics and UNRESOLVED recheck hardening."""

    UNRESOLVED_RECHECK_SECONDS = max(
        5.0, float(os.getenv("V9_UNRESOLVED_RECHECK_SECONDS", "30"))
    )

    def ensure_schema(self):
        super().ensure_schema()
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "ALTER TABLE trade_candidates ADD COLUMN IF NOT EXISTS status_reason TEXT"
                )
                cur.execute(
                    """
                    UPDATE trade_candidates
                    SET status_reason = CASE
                        WHEN status='WAIT_CONFIRMATION' THEN 'WAIT_CONFIRMATION: confirmation price not reached yet'
                        WHEN status='CONFIRMED' THEN 'CONFIRMED: confirmation price reached'
                        WHEN status='ACTIVE' THEN 'ACTIVE: at least one DEMO trade is open'
                        WHEN status='EXPIRED' THEN 'EXPIRED: candidate lifetime reached'
                        WHEN status='CANCELLED' THEN 'CANCELLED: scenario invalidated'
                        WHEN status='NO_ENTRY' THEN 'NO_ENTRY: strength below minimum or entry policy blocked'
                        ELSE 'STATUS: ' || status
                    END
                    WHERE status_reason IS NULL OR BTRIM(status_reason)=''
                    """
                )
        finally:
            conn.close()

    @staticmethod
    def _default_candidate_reason(status):
        status = str(status or "").upper()
        return {
            "WAIT_CONFIRMATION": "WAIT_CONFIRMATION: confirmation price not reached yet",
            "CONFIRMED": "CONFIRMED: confirmation price reached",
            "ACTIVE": "ACTIVE: at least one DEMO trade is open",
            "EXPIRED": "EXPIRED: candidate lifetime reached",
            "CANCELLED": "CANCELLED: scenario invalidated",
            "NO_ENTRY": "NO_ENTRY: strength below minimum or entry policy blocked",
        }.get(status, f"STATUS: {status}")

    def update_candidate_status(self, candidate_id, status, reason=None):
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE trade_candidates
                    SET status=%s, status_reason=%s
                    WHERE id=%s
                    """,
                    (
                        str(status)[:32],
                        str(reason or self._default_candidate_reason(status))[:500],
                        int(candidate_id),
                    ),
                )
        finally:
            conn.close()

    def event(
        self,
        event_type,
        candidate_id=None,
        trade_id=None,
        payload=None,
    ):
        super().event(event_type, candidate_id, trade_id, payload)
        if candidate_id is None:
            return
        event_type = str(event_type or "").upper()
        payload = payload or {}
        reason = str(payload.get("reason") or "").strip()
        if not reason:
            reason = {
                "TRADE_OPENED": "order opened successfully",
                "ORDER_CLAIM_BLOCKED": "duplicate basket-slot order claim blocked",
                "ORDER_SEND_BLOCKED": "final send safety guard blocked order",
                "ORDER_SEND_AMBIGUOUS": "MT5 send result ambiguous; reconciliation required",
                "ORDER_REJECTED": "MT5 rejected order",
                "ADD_BLOCKED": "same-side addition blocked by V9 policy",
                "DIRECTION_BLOCKED": "opposite direction blocked while basket is active",
                "ENTRY_SKIPPED": "entry skipped by risk, margin or basket policy",
                "SCENARIO_CANCELLED": "scenario invalidated by newer closed analysis",
                "REVERSAL_SHADOW": "opposite signal observed; reversal remains shadow/off",
                "REVERSAL_NOT_IMPLEMENTED_SAFE_BLOCK": "reversal requested but live close-and-flip is disabled",
            }.get(event_type, event_type or "EVENT")
        conn = None
        try:
            conn = self.connect()
            with conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE trade_candidates
                    SET status_reason=%s
                    WHERE id=%s
                    """,
                    (f"{event_type}: {reason}"[:500], int(candidate_id)),
                )
        except Exception:
            pass
        finally:
            if conn is not None:
                conn.close()

    @staticmethod
    def _parse_iso(value):
        if not value:
            return None
        try:
            dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        except Exception:
            return None

    def claim_pending_trade(
        self,
        candidate,
        lot,
        price,
        tp,
        account,
        mode,
        slot_no,
        risk_meta,
        basket_id,
        fence_token,
    ):
        """Insert and COMMIT the idempotency claim before any external send path."""
        claim_key = self._claim_key(basket_id, slot_no)
        conn = self.connect()
        old_autocommit = getattr(conn, "autocommit", True)
        try:
            conn.autocommit = False
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO demo_trades(
                        candidate_id,analysis_id,symbol,timeframe,side,lot,
                        planned_price,sl,tp,tp1,tp2,tp3,status,demo_account,payload,
                        basket_id,basket_slot,order_claim_key,fence_token
                    ) VALUES(
                        %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
                        'PENDING',%s,%s,%s,%s,%s,%s
                    )
                    ON CONFLICT(order_claim_key) DO NOTHING
                    RETURNING id
                    """,
                    (
                        int(candidate["id"]),
                        int(candidate["analysis_id"]),
                        self.symbol,
                        str(candidate["timeframe"]),
                        str(candidate["side"]).upper(),
                        float(lot),
                        float(price),
                        num(candidate["sl"]) or None,
                        tp or None,
                        num(candidate["tp1"]) or None,
                        num(candidate["tp2"]) or None,
                        num(candidate["tp3"]) or None,
                        str(getattr(account, "login", "")),
                        Json({"risk_mode": mode, "slot_no": slot_no, **risk_meta}),
                        str(basket_id),
                        int(slot_no),
                        claim_key,
                        int(fence_token),
                    ),
                )
                row = cur.fetchone()
            conn.commit()
            return int(row[0]) if row else None
        except Exception:
            try:
                conn.rollback()
            except Exception:
                pass
            raise
        finally:
            try:
                conn.autocommit = old_autocommit
            except Exception:
                pass
            conn.close()

    def _set_pending_payload(self, trade_id, patch):
        """COMMIT send_attempted/reconcile metadata before returning to send_order."""
        conn = self.connect()
        old_autocommit = getattr(conn, "autocommit", True)
        try:
            conn.autocommit = False
            with conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE demo_trades
                    SET payload=COALESCE(payload,'{}'::jsonb) || %s::jsonb
                    WHERE id=%s AND status IN('PENDING','UNRESOLVED')
                    """,
                    (json.dumps(patch or {}), int(trade_id)),
                )
            conn.commit()
        except Exception:
            try:
                conn.rollback()
            except Exception:
                pass
            raise
        finally:
            try:
                conn.autocommit = old_autocommit
            except Exception:
                pass
            conn.close()

    def _unresolved_recheck_due(self, row):
        payload = row.get("payload") or {}
        if isinstance(payload, str):
            try:
                payload = json.loads(payload)
            except Exception:
                payload = {}
        last = self._parse_iso(payload.get("unresolved_recheck_at"))
        if last is None:
            return True
        return (utcnow() - last).total_seconds() >= self.UNRESOLVED_RECHECK_SECONDS

    def _stamp_unresolved_recheck(self, trade_id):
        self._set_pending_payload(
            trade_id,
            {"unresolved_recheck_at": utcnow().isoformat(), "auto_retry": False},
        )

    def reconcile_pending_claims(self):
        """Retry reconciliation with backoff; never retry the MT5 order itself."""
        rows = [
            r for r in self._active_trade_rows()
            if r.get("status") in {"PENDING", "UNRESOLVED"}
        ]
        unresolved = []
        for row in rows:
            trade_id = int(row["id"])

            if row.get("status") == "UNRESOLVED":
                if not self._unresolved_recheck_due(row):
                    unresolved.append(trade_id)
                    continue
                self._stamp_unresolved_recheck(trade_id)
                live = self._position_for_trade_id(trade_id)
                if live is not None:
                    entry = num(getattr(live, "price_open", 0.0)) or num(row.get("entry_price"))
                    self.mark_open(
                        trade_id,
                        int(getattr(live, "ticket", 0) or 0),
                        entry,
                        num(row.get("entry_price")) or entry,
                        {"reconciled_from_unresolved": True},
                    )
                    continue
                unresolved.append(trade_id)
                continue

            live = self._position_for_trade_id(trade_id)
            if live is not None:
                entry = num(getattr(live, "price_open", 0.0)) or num(row.get("entry_price"))
                self.mark_open(
                    trade_id,
                    int(getattr(live, "ticket", 0) or 0),
                    entry,
                    num(row.get("entry_price")) or entry,
                    {"reconciled_after_restart": True},
                )
                continue

            created = row.get("created_at")
            if created is None:
                unresolved.append(trade_id)
                continue
            if created.tzinfo is None:
                created = created.replace(tzinfo=timezone.utc)
            age = max(0.0, (utcnow() - created).total_seconds())
            payload = row.get("payload") or {}
            if isinstance(payload, str):
                try:
                    payload = json.loads(payload)
                except Exception:
                    payload = {}

            if age < self.CLAIM_GRACE_SECONDS:
                unresolved.append(trade_id)
                continue
            if not bool(payload.get("send_attempted")):
                self.reject_trade(
                    trade_id,
                    "STALE_UNSENT_CLAIM",
                    {"age_sec": age, "send_attempted": False},
                )
                continue

            self._set_pending_payload(
                trade_id,
                {
                    "reconcile_required": True,
                    "reconcile_checked_at": utcnow().isoformat(),
                    "age_sec": age,
                    "auto_retry": False,
                },
            )
            if age >= self.UNRESOLVED_AFTER_SECONDS:
                self._mark_unresolved(trade_id, age)
            unresolved.append(trade_id)
        return not unresolved


DemoTraderV9Final = V9HardenedV3DemoTrader
