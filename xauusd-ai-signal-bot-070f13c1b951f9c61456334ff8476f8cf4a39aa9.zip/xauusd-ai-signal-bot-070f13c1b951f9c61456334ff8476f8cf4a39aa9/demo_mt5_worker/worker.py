from __future__ import annotations

import logging
import os
import signal
import sys
import time
from datetime import datetime, timezone
from typing import Optional

import MetaTrader5 as mt5
import psycopg2
from psycopg2.extras import Json, execute_values

from trader import DemoTrader


# ============================================================
# CONFIG
# ============================================================

DATABASE_URL = (
    os.getenv("DATABASE_PUBLIC_URL")
    or os.getenv("DATABASE_URL")
    or ""
).strip()

MT5_SYMBOL = os.getenv("MT5_SYMBOL", "XAUUSD").strip()
MT5_PATH = os.getenv("MT5_PATH", "").strip()
MT5_SERVER = os.getenv("MT5_SERVER", "").strip()
MT5_PASSWORD = os.getenv("MT5_PASSWORD", "").strip()
MT5_LOGIN_RAW = os.getenv("MT5_LOGIN", "").strip()

POLL_SECONDS = max(
    0.5,
    float(os.getenv("WORKER_POLL_SECONDS", "1.0")),
)

QUOTE_WRITE_SECONDS = max(
    1.0,
    float(os.getenv("QUOTE_WRITE_SECONDS", "3.0")),
)

SYNC_CLOSED_SECONDS = max(
    5.0,
    float(os.getenv("SYNC_CLOSED_SECONDS", "15.0")),
)

RECONNECT_SECONDS = max(
    2.0,
    float(os.getenv("RECONNECT_SECONDS", "5.0")),
)

# Новое: синхронизация закрытых M1 свечей MT5 -> PostgreSQL.
CANDLE_SYNC_SECONDS = max(
    3.0,
    float(os.getenv("CANDLE_SYNC_SECONDS", "5.0")),
)

# При первом запуске забираем достаточно M1 истории, чтобы
# аналитик смог строить M1/M5/M15/M30/H1.
CANDLE_BACKFILL_COUNT = max(
    2000,
    int(os.getenv("CANDLE_BACKFILL_COUNT", "5000")),
)

# В обычном цикле достаточно перечитывать несколько последних
# закрытых свечей: ON CONFLICT безопасно обновит их.
CANDLE_REFRESH_COUNT = max(
    3,
    int(os.getenv("CANDLE_REFRESH_COUNT", "10")),
)

MAGIC = int(os.getenv("MT5_MAGIC", "260817"))
SOURCE = os.getenv("MT5_QUOTE_SOURCE", "DEMO_WORKER")
CANDLE_SOURCE = os.getenv("MT5_CANDLE_SOURCE", "MT5_GOLD")
WORKER_VERSION = (
    os.getenv(
        "DEMO_WORKER_VERSION",
        "xauusd-demo-worker-v6-confirmed-cancel-2026-08-18",
    ).strip()
    or "xauusd-demo-worker-v6-confirmed-cancel-2026-08-18"
)

# ======================================================
# TIME POLICY — CLEAN V4.3
# ======================================================
# Внутри worker и PostgreSQL все времена свечей хранятся в UTC.
# Ташкентское время используется только для отображения человеку.
# Raw-время MT5 сохраняется/проверяется отдельно.
#
# Некоторые брокерские MT5-серверы могут отдавать epoch со сдвигом
# серверного времени. Поэтому worker НЕ "угадывает" часовой пояс вслепую:
# он сравнивает MT5 tick.time с системным UTC и применяет коррекцию
# только если разница очень близка к целому числу часов.
DISPLAY_TIMEZONE = os.getenv("DISPLAY_TIMEZONE", "Asia/Tashkent").strip() or "Asia/Tashkent"

MT5_TIME_OFFSET_HOURS_RAW = os.getenv("MT5_TIME_OFFSET_HOURS", "").strip()
MT5_TIME_OFFSET_SECONDS = 0
MT5_TIME_OFFSET_READY = False
MT5_TIME_OFFSET_CONFIDENT = False

# Допустимая погрешность при автоопределении часового сдвига.
MT5_OFFSET_RESIDUAL_MAX_SECONDS = max(
    60,
    int(os.getenv("MT5_OFFSET_RESIDUAL_MAX_SECONDS", "600")),
)

# Если закрытая M1 старше этого времени — новые DEMO-входы блокируются.
MAX_M1_STALE_SECONDS = max(
    120,
    int(os.getenv("MAX_M1_STALE_SECONDS", "300")),
)

# Свеча не может быть "из будущего" дальше этой погрешности.
MAX_FUTURE_SECONDS = max(
    30,
    int(os.getenv("MAX_FUTURE_SECONDS", "120")),
)

# ВАЖНО:
# Этот проект специально сделан только для DEMO.
# Реальный счёт кодом блокируется.
DEMO_ONLY = True


# ============================================================
# LOGGING
# ============================================================

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s | %(levelname)s | %(message)s",
)

log = logging.getLogger("xauusd-demo-worker")


# ============================================================
# GLOBAL STATE
# ============================================================

STOP = False


def _stop_handler(signum, frame):
    global STOP
    STOP = True
    log.info("Получен сигнал остановки: %s", signum)


signal.signal(signal.SIGINT, _stop_handler)

if hasattr(signal, "SIGTERM"):
    signal.signal(signal.SIGTERM, _stop_handler)


# ============================================================
# HELPERS
# ============================================================

def parse_login() -> Optional[int]:
    if not MT5_LOGIN_RAW:
        return None

    try:
        return int(MT5_LOGIN_RAW)
    except ValueError as exc:
        raise RuntimeError(
            "MT5_LOGIN должен быть номером DEMO-счёта."
        ) from exc



def _round_to_hour(seconds_value: float) -> int:
    return int(round(float(seconds_value) / 3600.0) * 3600)


def _iso_utc_from_epoch(epoch_value: int) -> str:
    return datetime.fromtimestamp(
        int(epoch_value),
        tz=timezone.utc,
    ).isoformat()


def detect_mt5_time_offset(force: bool = False) -> int:
    """
    Canonical rule:
      - Python/system UTC = source of truth.
      - MT5 raw tick time is checked against system UTC.
      - A correction is applied only when the difference is very close
        to a whole-hour offset.
      - If the difference is ambiguous, worker keeps offset=0 and marks
        the time source as untrusted; trading will be blocked by freshness/
        future guards instead of guessing.
    """
    global MT5_TIME_OFFSET_SECONDS
    global MT5_TIME_OFFSET_READY
    global MT5_TIME_OFFSET_CONFIDENT

    if MT5_TIME_OFFSET_READY and not force:
        return MT5_TIME_OFFSET_SECONDS

    # Manual override, if ever needed.
    if MT5_TIME_OFFSET_HOURS_RAW:
        try:
            hours = float(MT5_TIME_OFFSET_HOURS_RAW)
        except ValueError as exc:
            raise RuntimeError(
                "MT5_TIME_OFFSET_HOURS должен быть числом, например 0, 2 или 3."
            ) from exc

        if abs(hours) > 14:
            raise RuntimeError(
                "MT5_TIME_OFFSET_HOURS вне допустимого диапазона ±14 часов."
            )

        MT5_TIME_OFFSET_SECONDS = int(round(hours * 3600))
        MT5_TIME_OFFSET_READY = True
        MT5_TIME_OFFSET_CONFIDENT = True

        log.info(
            "TIME | manual MT5 offset=%+.1fh | canonical=UTC | display=%s",
            MT5_TIME_OFFSET_SECONDS / 3600.0,
            DISPLAY_TIMEZONE,
        )
        return MT5_TIME_OFFSET_SECONDS

    tick = mt5.symbol_info_tick(MT5_SYMBOL)

    if tick is None or not getattr(tick, "time", 0):
        MT5_TIME_OFFSET_SECONDS = 0
        MT5_TIME_OFFSET_READY = True
        MT5_TIME_OFFSET_CONFIDENT = False
        log.warning(
            "TIME | MT5 tick.time недоступен. Автокоррекция не применена."
        )
        return 0

    raw_tick = int(tick.time)
    utc_now = int(time.time())
    diff = raw_tick - utc_now

    candidate = _round_to_hour(diff)
    residual = diff - candidate

    # Если raw MT5 почти совпадает с UTC — никакая коррекция не нужна.
    if abs(diff) <= MT5_OFFSET_RESIDUAL_MAX_SECONDS:
        offset = 0
        confident = True
    # Если разница близка к целому числу часов — считаем это broker/server offset.
    elif (
        abs(candidate) <= 14 * 3600
        and abs(residual) <= MT5_OFFSET_RESIDUAL_MAX_SECONDS
    ):
        offset = candidate
        confident = True
    else:
        offset = 0
        confident = False

    MT5_TIME_OFFSET_SECONDS = int(offset)
    MT5_TIME_OFFSET_READY = True
    MT5_TIME_OFFSET_CONFIDENT = bool(confident)

    corrected_tick = raw_tick - MT5_TIME_OFFSET_SECONDS

    log.info(
        "TIME | raw_mt5=%s | corrected_utc=%s | system_utc=%s | "
        "offset=%+.1fh | residual=%+.0fs | trusted=%s | display=%s",
        _iso_utc_from_epoch(raw_tick),
        _iso_utc_from_epoch(corrected_tick),
        datetime.now(timezone.utc).isoformat(),
        MT5_TIME_OFFSET_SECONDS / 3600.0,
        residual,
        "YES" if MT5_TIME_OFFSET_CONFIDENT else "NO",
        DISPLAY_TIMEZONE,
    )

    save_worker_state(
        "time_policy",
        {
            "canonical_timezone": "UTC",
            "display_timezone": DISPLAY_TIMEZONE,
            "mt5_raw_tick_utc_interpretation": _iso_utc_from_epoch(raw_tick),
            "mt5_corrected_utc": _iso_utc_from_epoch(corrected_tick),
            "system_utc": datetime.now(timezone.utc).isoformat(),
            "mt5_offset_seconds": MT5_TIME_OFFSET_SECONDS,
            "mt5_offset_hours": MT5_TIME_OFFSET_SECONDS / 3600.0,
            "residual_seconds": residual,
            "trusted": MT5_TIME_OFFSET_CONFIDENT,
            "updated_at_utc": datetime.now(timezone.utc).isoformat(),
        },
    )

    return MT5_TIME_OFFSET_SECONDS


def normalize_mt5_epoch(raw_epoch: int) -> int:
    return int(raw_epoch) - int(detect_mt5_time_offset())


def clear_mt5_m1_for_rebuild():
    """
    Rebuild only MT5-sourced M1 rows.
    This prevents old rows with a wrong timezone shift from coexisting
    with corrected UTC rows. Other sources are untouched.
    """
    conn = db_connect()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                DELETE FROM xauusd_candles
                WHERE timeframe = 'M1'
                  AND UPPER(source) LIKE 'MT5%'
                """
            )
            deleted = cur.rowcount or 0

        log.info(
            "TIME | MT5 M1 UTC rebuild: removed=%s",
            deleted,
        )
    finally:
        conn.close()


def candle_age_seconds(latest: Optional[datetime]) -> float:
    if latest is None:
        return float("inf")

    return (
        datetime.now(timezone.utc) - latest
    ).total_seconds()


def validate_closed_m1_time(latest: Optional[datetime]) -> tuple[bool, str]:
    """
    Returns (ok, reason).
    A future candle or a stale candle is not allowed to drive new DEMO entries.
    """
    if latest is None:
        return False, "нет закрытой M1"

    age = candle_age_seconds(latest)

    if age < -MAX_FUTURE_SECONDS:
        return (
            False,
            f"M1 из будущего на {abs(age):.0f} сек",
        )

    if age > MAX_M1_STALE_SECONDS:
        return (
            False,
            f"M1 устарела на {age / 60.0:.1f} мин",
        )

    return True, "OK"


def db_connect():
    if not DATABASE_URL:
        raise RuntimeError(
            "Не найден DATABASE_PUBLIC_URL или DATABASE_URL."
        )

    kwargs = {
        "connect_timeout": 10,
        "application_name": "xauusd_demo_worker",
    }

    sslmode = os.getenv("DB_SSLMODE", "").strip()

    if sslmode:
        kwargs["sslmode"] = sslmode

    connection = psycopg2.connect(
        DATABASE_URL,
        **kwargs,
    )

    connection.autocommit = True
    return connection


def ensure_db_schema():
    conn = db_connect()

    try:
        with conn.cursor() as cur:
            # Живые BID/ASK.
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS mt5_quotes (
                    id BIGSERIAL PRIMARY KEY,
                    received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    broker_time TIMESTAMPTZ,
                    symbol VARCHAR(24) NOT NULL DEFAULT 'XAUUSD',
                    bid NUMERIC(18,6) NOT NULL,
                    ask NUMERIC(18,6) NOT NULL,
                    spread NUMERIC(18,6),
                    digits SMALLINT,
                    source VARCHAR(32) NOT NULL DEFAULT 'MT5'
                )
                """
            )

            cur.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_mt5_quotes_latest
                ON mt5_quotes(symbol, received_at DESC)
                """
            )

            # Новое: общая таблица закрытых свечей для аналитического бота.
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS xauusd_candles (
                    id BIGSERIAL PRIMARY KEY,
                    timeframe VARCHAR(5) NOT NULL DEFAULT 'M1',
                    candle_time TIMESTAMPTZ NOT NULL,
                    open NUMERIC(18,6) NOT NULL,
                    high NUMERIC(18,6) NOT NULL,
                    low NUMERIC(18,6) NOT NULL,
                    close NUMERIC(18,6) NOT NULL,
                    volume NUMERIC(24,8) NOT NULL DEFAULT 0,
                    source VARCHAR(32) NOT NULL DEFAULT 'live',
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    UNIQUE(timeframe, candle_time)
                )
                """
            )

            cur.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_xauusd_candles_tf_time
                ON xauusd_candles(timeframe, candle_time DESC)
                """
            )

            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS demo_worker_state (
                    key VARCHAR(80) PRIMARY KEY,
                    value JSONB NOT NULL DEFAULT '{}'::jsonb,
                    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                )
                """
            )

        log.info(
            "PostgreSQL: quotes + M1 candles + worker state готовы."
        )
    finally:
        conn.close()


def save_worker_state(key: str, value: dict):
    conn = None

    try:
        conn = db_connect()

        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO demo_worker_state(key, value, updated_at)
                VALUES (%s, %s, NOW())
                ON CONFLICT(key)
                DO UPDATE SET
                    value = EXCLUDED.value,
                    updated_at = NOW()
                """,
                (
                    key,
                    Json(value),
                ),
            )
    except Exception as exc:
        log.warning("Не удалось сохранить worker state: %s", exc)
    finally:
        if conn is not None:
            conn.close()


# ============================================================
# MT5 CONNECTION
# ============================================================

def mt5_initialize():
    login = parse_login()

    kwargs = {
        "timeout": 60000,
    }

    if login is not None:
        kwargs["login"] = login

    if MT5_SERVER:
        kwargs["server"] = MT5_SERVER

    if MT5_PASSWORD:
        kwargs["password"] = MT5_PASSWORD

    if MT5_PATH:
        ok = mt5.initialize(
            MT5_PATH,
            **kwargs,
        )
    else:
        ok = mt5.initialize(
            **kwargs,
        )

    if not ok:
        raise RuntimeError(
            f"MT5 initialize() не удалось: {mt5.last_error()}"
        )

    account = mt5.account_info()

    if account is None:
        mt5.shutdown()
        raise RuntimeError(
            f"MT5 account_info() не удалось: {mt5.last_error()}"
        )

    demo_mode = getattr(
        mt5,
        "ACCOUNT_TRADE_MODE_DEMO",
        0,
    )

    if DEMO_ONLY and int(account.trade_mode) != int(demo_mode):
        login_value = getattr(account, "login", "?")
        server_value = getattr(account, "server", "?")

        mt5.shutdown()

        raise RuntimeError(
            "ЗАБЛОКИРОВАНО: подключён не DEMO-счёт. "
            f"login={login_value}, server={server_value}. "
            "Этот бот специально не торгует на REAL."
        )

    if not mt5.symbol_select(
        MT5_SYMBOL,
        True,
    ):
        mt5.shutdown()

        raise RuntimeError(
            f"Не удалось выбрать {MT5_SYMBOL}: {mt5.last_error()}"
        )

    info = mt5.symbol_info(MT5_SYMBOL)

    if info is None:
        mt5.shutdown()

        raise RuntimeError(
            f"symbol_info({MT5_SYMBOL}) не найден: {mt5.last_error()}"
        )

    log.info(
        "MT5 подключён | DEMO login=%s | server=%s | symbol=%s | digits=%s",
        getattr(account, "login", "?"),
        getattr(account, "server", "?"),
        MT5_SYMBOL,
        getattr(info, "digits", "?"),
    )

    save_worker_state(
        "mt5_connection",
        {
            "connected": True,
            "demo": True,
            "login": str(getattr(account, "login", "")),
            "server": str(getattr(account, "server", "")),
            "symbol": MT5_SYMBOL,
            "connected_at": datetime.now(
                timezone.utc
            ).isoformat(),
        },
    )

    return account


def ensure_mt5_connection():
    terminal = mt5.terminal_info()
    account = mt5.account_info()

    if terminal is None or account is None:
        mt5.shutdown()
        return mt5_initialize()

    demo_mode = getattr(
        mt5,
        "ACCOUNT_TRADE_MODE_DEMO",
        0,
    )

    if DEMO_ONLY and int(account.trade_mode) != int(demo_mode):
        raise RuntimeError(
            "ЗАБЛОКИРОВАНО: MT5 переключён с DEMO на другой тип счёта."
        )

    return account


# ============================================================
# QUOTES
# ============================================================

def get_tick():
    tick = mt5.symbol_info_tick(
        MT5_SYMBOL
    )

    if tick is None:
        raise RuntimeError(
            f"Нет тика {MT5_SYMBOL}: {mt5.last_error()}"
        )

    bid = float(tick.bid)
    ask = float(tick.ask)

    if bid <= 0 or ask <= 0:
        raise RuntimeError(
            f"Некорректная котировка: bid={bid}, ask={ask}"
        )

    if ask < bid:
        raise RuntimeError(
            f"Некорректный spread: bid={bid}, ask={ask}"
        )

    return tick


def save_quote(tick):
    info = mt5.symbol_info(
        MT5_SYMBOL
    )

    digits = (
        int(info.digits)
        if info is not None
        else 2
    )

    bid = float(tick.bid)
    ask = float(tick.ask)
    spread = ask - bid

    broker_time = None

    if getattr(tick, "time", 0):
        broker_time = datetime.fromtimestamp(
            normalize_mt5_epoch(int(tick.time)),
            tz=timezone.utc,
        )

    conn = db_connect()

    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO mt5_quotes(
                    received_at,
                    broker_time,
                    symbol,
                    bid,
                    ask,
                    spread,
                    digits,
                    source
                )
                VALUES(
                    NOW(),
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s
                )
                """,
                (
                    broker_time,
                    MT5_SYMBOL,
                    bid,
                    ask,
                    spread,
                    digits,
                    SOURCE,
                ),
            )
    finally:
        conn.close()


def cleanup_old_quotes():
    keep_hours = max(
        24,
        int(os.getenv("QUOTE_KEEP_HOURS", "72")),
    )

    conn = db_connect()

    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                DELETE FROM mt5_quotes
                WHERE received_at <
                    NOW() - (%s * INTERVAL '1 hour')
                """,
                (keep_hours,),
            )

            deleted = cur.rowcount or 0

        if deleted:
            log.info(
                "Удалено старых MT5 котировок: %s",
                deleted,
            )
    finally:
        conn.close()


# ============================================================
# CLOSED M1 CANDLES: MT5 -> POSTGRESQL
# ============================================================

def get_closed_m1_rates(count: int):
    """
    start_pos=1 специально пропускает bar 0:
    bar 0 = текущая незакрытая M1 свеча.
    В БД отправляются только закрытые M1 свечи.
    """
    rates = mt5.copy_rates_from_pos(
        MT5_SYMBOL,
        mt5.TIMEFRAME_M1,
        1,
        int(count),
    )

    if rates is None:
        raise RuntimeError(
            f"copy_rates_from_pos({MT5_SYMBOL}, M1) не удалось: "
            f"{mt5.last_error()}"
        )

    rows = []

    for rate in rates:
        raw_ts = int(rate["time"])

        if raw_ts <= 0:
            continue

        ts = normalize_mt5_epoch(raw_ts)

        candle_time = datetime.fromtimestamp(
            ts,
            tz=timezone.utc,
        )

        open_price = float(rate["open"])
        high_price = float(rate["high"])
        low_price = float(rate["low"])
        close_price = float(rate["close"])

        if min(
            open_price,
            high_price,
            low_price,
            close_price,
        ) <= 0:
            continue

        volume = float(
            rate["tick_volume"]
            if "tick_volume" in rate.dtype.names
            else 0
        )

        rows.append(
            (
                "M1",
                candle_time,
                open_price,
                high_price,
                low_price,
                close_price,
                volume,
                CANDLE_SOURCE,
            )
        )

    rows.sort(key=lambda x: x[1])
    return rows


def save_closed_m1_rates(count: int) -> tuple[int, Optional[datetime]]:
    rows = get_closed_m1_rates(count)

    if not rows:
        return 0, None

    conn = db_connect()

    try:
        with conn.cursor() as cur:
            execute_values(
                cur,
                """
                INSERT INTO xauusd_candles(
                    timeframe,
                    candle_time,
                    open,
                    high,
                    low,
                    close,
                    volume,
                    source
                )
                VALUES %s
                ON CONFLICT(timeframe, candle_time)
                DO UPDATE SET
                    open = EXCLUDED.open,
                    high = EXCLUDED.high,
                    low = EXCLUDED.low,
                    close = EXCLUDED.close,
                    volume = EXCLUDED.volume,
                    source = EXCLUDED.source
                """,
                rows,
                page_size=500,
            )
    finally:
        conn.close()

    latest = rows[-1][1]

    save_worker_state(
        "mt5_m1_candles",
        {
            "alive": True,
            "symbol": MT5_SYMBOL,
            "timeframe": "M1",
            "last_closed_candle_utc": latest.isoformat(),
            "rows_synced": len(rows),
            "source": CANDLE_SOURCE,
            "updated_at": datetime.now(timezone.utc).isoformat(),
        },
    )

    return len(rows), latest


def initial_candle_backfill():
    count, latest = save_closed_m1_rates(
        CANDLE_BACKFILL_COUNT
    )

    if latest is None:
        log.warning(
            "MT5 M1: при стартовой загрузке закрытые свечи не получены."
        )
        return

    age_seconds = candle_age_seconds(latest)

    log.info(
        "MT5 M1 BACKFILL | rows=%s | last_closed=%s | age=%.1fs",
        count,
        latest.isoformat(),
        age_seconds,
    )


# ============================================================
# MAIN LOOP
# ============================================================

def main():
    if sys.platform != "win32":
        log.warning(
            "MetaTrader5 Python обычно запускается на Windows рядом "
            "с установленным терминалом MT5."
        )

    ensure_db_schema()
    account = mt5_initialize()

    # Единая политика времени:
    # MT5 raw -> normalized UTC -> PostgreSQL UTC -> Telegram/Tashkent display.
    detect_mt5_time_offset(force=True)

    if not MT5_TIME_OFFSET_CONFIDENT:
        log.warning(
            "TIME | Время MT5 не удалось однозначно сопоставить с UTC. "
            "Новые DEMO-входы будут заблокированы до нормальной синхронизации."
        )

    # Перестраиваем только MT5 M1, чтобы в БД не осталось старых
    # свечей со сдвинутыми timestamps.
    clear_mt5_m1_for_rebuild()

    # Загружаем последние закрытые M1 уже в canonical UTC.
    initial_candle_backfill()

    trader = DemoTrader(
        database_url=DATABASE_URL,
        mt5_module=mt5,
        symbol=MT5_SYMBOL,
        magic=MAGIC,
    )

    last_quote_write = 0.0
    last_candle_sync = 0.0
    last_closed_sync = 0.0
    last_cleanup = 0.0
    last_heartbeat = 0.0
    last_tick_price = None
    latest_closed_m1 = None
    time_guard_log_at = 0.0

    log.info(
        "DEMO worker %s запущен. Реальный счёт заблокирован.",
        WORKER_VERSION,
    )

    while not STOP:
        try:
            account = ensure_mt5_connection()
            tick = get_tick()

            now = time.monotonic()

            if (
                now - last_quote_write
                >= QUOTE_WRITE_SECONDS
            ):
                save_quote(tick)
                last_quote_write = now

            # Новое: каждые несколько секунд сохраняем последние
            # ЗАКРЫТЫЕ M1 свечи. Текущая формирующаяся свеча исключена.
            if (
                now - last_candle_sync
                >= CANDLE_SYNC_SECONDS
            ):
                synced, latest = save_closed_m1_rates(
                    CANDLE_REFRESH_COUNT
                )

                if latest is not None:
                    latest_closed_m1 = latest

                if latest is not None and (
                    last_candle_sync == 0.0
                    or int(now) % 30 < int(CANDLE_SYNC_SECONDS)
                ):
                    log.info(
                        "MT5 M1 | synced=%s | last_closed=%s",
                        synced,
                        latest.isoformat(),
                    )

                last_candle_sync = now

            time_ok, time_reason = validate_closed_m1_time(
                latest_closed_m1
            )

            if MT5_TIME_OFFSET_CONFIDENT and time_ok:
                trader.step(
                    tick=tick,
                    account=account,
                )
            else:
                if (
                    time_guard_log_at == 0.0
                    or now - time_guard_log_at >= 60.0
                ):
                    reason = (
                        time_reason
                        if MT5_TIME_OFFSET_CONFIDENT
                        else "MT5 timezone/UTC mapping не подтверждён"
                    )
                    log.warning(
                        "TIME GUARD | DEMO новые входы на паузе | %s",
                        reason,
                    )
                    time_guard_log_at = now

            if (
                now - last_closed_sync
                >= SYNC_CLOSED_SECONDS
            ):
                trader.sync_closed_trades()
                last_closed_sync = now

            if (
                now - last_cleanup
                >= 6 * 60 * 60
            ):
                cleanup_old_quotes()
                last_cleanup = now

            if (
                now - last_heartbeat
                >= 30.0
            ):
                bid = float(tick.bid)
                ask = float(tick.ask)

                log.info(
                    "LIVE %s | bid=%.2f ask=%.2f | account=%s",
                    MT5_SYMBOL,
                    bid,
                    ask,
                    getattr(account, "login", "?"),
                )

                save_worker_state(
                    "heartbeat",
                    {
                        "alive": True,
                        "demo": True,
                        "version": WORKER_VERSION,
                        "symbol": MT5_SYMBOL,
                        "bid": bid,
                        "ask": ask,
                        "account": str(
                            getattr(
                                account,
                                "login",
                                "",
                            )
                        ),
                        "server": str(
                            getattr(
                                account,
                                "server",
                                "",
                            )
                        ),
                        "time": datetime.now(
                            timezone.utc
                        ).isoformat(),
                    },
                )

                last_heartbeat = now

            current_price = float(tick.bid)

            if last_tick_price != current_price:
                last_tick_price = current_price

            time.sleep(POLL_SECONDS)

        except KeyboardInterrupt:
            break

        except Exception as exc:
            log.exception(
                "Ошибка worker: %s",
                exc,
            )

            save_worker_state(
                "last_error",
                {
                    "message": str(exc),
                    "time": datetime.now(
                        timezone.utc
                    ).isoformat(),
                },
            )

            try:
                mt5.shutdown()
            except Exception:
                pass

            time.sleep(
                RECONNECT_SECONDS
            )

            try:
                account = mt5_initialize()
                # После переподключения восстанавливаем свежую историю.
                initial_candle_backfill()
            except Exception as reconnect_exc:
                log.error(
                    "Повторное подключение MT5 не удалось: %s",
                    reconnect_exc,
                )

    log.info(
        "Останавливаю DEMO worker..."
    )

    try:
        trader.close()
    except Exception:
        pass

    try:
        mt5.shutdown()
    except Exception:
        pass

    save_worker_state(
        "heartbeat",
        {
            "alive": False,
            "demo": True,
            "version": WORKER_VERSION,
            "symbol": MT5_SYMBOL,
            "time": datetime.now(
                timezone.utc
            ).isoformat(),
        },
    )

    log.info(
        "DEMO worker остановлен."
    )


if __name__ == "__main__":
    main()
