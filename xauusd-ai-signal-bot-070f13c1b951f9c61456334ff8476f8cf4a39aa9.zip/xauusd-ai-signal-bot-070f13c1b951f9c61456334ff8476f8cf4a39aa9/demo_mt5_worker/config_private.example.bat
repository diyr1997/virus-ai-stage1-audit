@echo off

REM ==========================================================
REM ЛОКАЛЬНЫЕ НАСТРОЙКИ ВТОРОГО DEMO-БОТА
REM
REM ВАЖНО:
REM 1) Сделай копию этого файла.
REM 2) Назови копию: config_private.bat
REM 3) Заполни значения ниже.
REM 4) config_private.bat НЕ загружай в GitHub.
REM ==========================================================

REM PostgreSQL Railway.
REM Вставь полный публичный адрес PostgreSQL.
set "DATABASE_PUBLIC_URL="

REM MT5 DEMO.
REM Номер DEMO-счета.
set "MT5_LOGIN="

REM Пароль DEMO-счета.
REM Если MT5 уже открыт и авторизован, иногда можно оставить пустым.
set "MT5_PASSWORD="

REM Точное имя сервера из MT5.
set "MT5_SERVER="

REM Точное имя золота у брокера.
REM Раньше у твоего DEMO-счета инструмент отображался как GOLD#.
set "MT5_SYMBOL=GOLD#"

REM Символ кандидатов аналитического бота в PostgreSQL.
REM Обычно его менять не нужно.
set "SIGNAL_SYMBOL=XAUUSD"

REM Путь к terminal64.exe.
REM Если библиотека сама находит открытый MT5, можно оставить пустым.
REM Пример:
REM set "MT5_PATH=C:\Program Files\MetaTrader 5\terminal64.exe"
set "MT5_PATH="

REM Режим риска:
REM CAUTIOUS   = Осторожный
REM MEDIUM     = Средний
REM ACTIVE     = Активный
REM AGGRESSIVE = Агрессивный
set "DEMO_RISK_MODE=MEDIUM"

REM Остальные настройки обычно менять не нужно.
set "WORKER_POLL_SECONDS=1.0"
set "QUOTE_WRITE_SECONDS=3.0"
set "SYNC_CLOSED_SECONDS=15.0"
set "RECONNECT_SECONDS=5.0"
set "MT5_MAGIC=260817"
set "MT5_DEVIATION_POINTS=50"

REM UTC-защита новых DEMO-входов.
set "DISPLAY_TIMEZONE=Asia/Tashkent"
set "MAX_M1_STALE_SECONDS=300"
set "MAX_FUTURE_SECONDS=120"
