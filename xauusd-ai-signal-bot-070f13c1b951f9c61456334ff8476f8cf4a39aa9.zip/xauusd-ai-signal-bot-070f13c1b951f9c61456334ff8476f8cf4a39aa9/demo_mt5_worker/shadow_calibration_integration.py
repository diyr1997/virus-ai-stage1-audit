from __future__ import annotations

import os
import time

from shadow_calibration_report import ShadowCalibrationReport
from trader_v9_hardened_v4 import V9HardenedV4DemoTrader


_ORIGINAL_INIT = V9HardenedV4DemoTrader.__init__
_ORIGINAL_STEP = V9HardenedV4DemoTrader.step


def _install() -> None:
    if getattr(V9HardenedV4DemoTrader, "_shadow_calibration_integration_installed", False):
        return

    def patched_init(self, *args, **kwargs):
        _ORIGINAL_INIT(self, *args, **kwargs)
        self.shadow_calibration_report = ShadowCalibrationReport(self.connect, self.symbol)
        self._shadow_calibration_last_at = 0.0
        self._shadow_calibration_interval = max(60.0, float(os.getenv("SHADOW_CALIBRATION_SECONDS", "300")))
        self._shadow_calibration_lookback_hours = max(1, int(os.getenv("SHADOW_CALIBRATION_LOOKBACK_HOURS", "24")))

    def patched_step(self, tick, account):
        now = time.monotonic()
        if now - self._shadow_calibration_last_at >= self._shadow_calibration_interval:
            self._shadow_calibration_last_at = now
            try:
                rows = self.shadow_calibration_report.summarize(
                    lookback_hours=self._shadow_calibration_lookback_hours,
                    min_samples=1,
                )
                if rows:
                    for row in rows[:24]:
                        print(
                            "[V9 CALIBRATION SHADOW] "
                            f"reason={row.get('reason')} | rec={row.get('recommendation')} | "
                            f"h={row.get('horizon_sec')}s | samples={row.get('samples')} | "
                            f"avg_net_atr={row.get('avg_net_atr')} | avg_mfe_atr={row.get('avg_mfe_atr')} | "
                            f"avg_mae_atr={row.get('avg_mae_atr')} | helped_rate={row.get('helped_rate')} | "
                            "execution impact=NONE",
                            flush=True,
                        )
                else:
                    print("[V9 CALIBRATION SHADOW] waiting for outcome samples | execution impact=NONE", flush=True)
            except Exception as exc:
                print(f"[V9 CALIBRATION SHADOW] read-only report error | {exc}", flush=True)
        return _ORIGINAL_STEP(self, tick, account)

    V9HardenedV4DemoTrader.__init__ = patched_init
    V9HardenedV4DemoTrader.step = patched_step
    V9HardenedV4DemoTrader._shadow_calibration_integration_installed = True


_install()
