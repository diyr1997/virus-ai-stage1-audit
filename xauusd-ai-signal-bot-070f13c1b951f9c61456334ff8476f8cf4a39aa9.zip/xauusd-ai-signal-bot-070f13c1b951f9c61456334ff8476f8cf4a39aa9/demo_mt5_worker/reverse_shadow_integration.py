from __future__ import annotations

import time

from impulse_shadow import ImpulseShadowEngine
from reverse_shadow import ReverseShadowStateMachine


_ORIGINAL_OBSERVE = ImpulseShadowEngine.observe


def _install() -> None:
    if getattr(ImpulseShadowEngine, "_reverse_shadow_integration_installed", False):
        return

    original_init = ImpulseShadowEngine.__init__

    def patched_init(self, *args, **kwargs):
        original_init(self, *args, **kwargs)
        self.reverse_shadow = ReverseShadowStateMachine()
        self._reverse_shadow_last_state = ""
        self._reverse_shadow_last_log_at = 0.0

    def patched_observe(self, tick, min_interval: float = 1.0):
        snapshot = _ORIGINAL_OBSERVE(self, tick, min_interval=min_interval)
        if not snapshot or str(snapshot.get("state") or "") == "WARMUP":
            return snapshot

        getter = getattr(self.mt5, "positions_get", None)
        if not callable(getter):
            snapshot["reverse_shadow_error"] = "POSITIONS_GET_UNAVAILABLE"
            return snapshot

        try:
            positions = getter(symbol=self.symbol)
        except Exception as exc:
            snapshot["reverse_shadow_error"] = f"POSITIONS_GET_EXCEPTION:{exc}"
            return snapshot
        if positions is None:
            snapshot["reverse_shadow_error"] = "POSITIONS_GET_NONE"
            return snapshot

        profit_results = list(snapshot.get("profit_lock") or [])
        result = self.reverse_shadow.observe(positions, snapshot, profit_results)
        snapshot["reverse_shadow"] = result

        state = str(result.get("state") or "UNKNOWN")
        recommendation = str(result.get("recommendation") or "UNKNOWN")
        now = time.monotonic()
        changed = state != self._reverse_shadow_last_state
        urgent = recommendation in {
            "CLOSE_THEN_WAIT_FLAT",
            "REVERSE_CANDIDATE_AFTER_FLAT_RECHECK",
            "SAFETY_ALERT_ONLY",
        }
        if changed or urgent or now - self._reverse_shadow_last_log_at >= 15.0:
            print(
                "[V9 REVERSE SHADOW] "
                f"state={state} | rec={recommendation} | "
                f"reason={result.get('reason')} | current={result.get('current_side')} | "
                f"target={result.get('target_side')} | impulse={result.get('impulse_score')} | "
                f"reversal={result.get('reversal_score')} | late={result.get('late_penalty')} | "
                "execution impact=NONE",
                flush=True,
            )
            self._reverse_shadow_last_log_at = now
        self._reverse_shadow_last_state = state
        return snapshot

    ImpulseShadowEngine.__init__ = patched_init
    ImpulseShadowEngine.observe = patched_observe
    ImpulseShadowEngine._reverse_shadow_integration_installed = True


_install()
