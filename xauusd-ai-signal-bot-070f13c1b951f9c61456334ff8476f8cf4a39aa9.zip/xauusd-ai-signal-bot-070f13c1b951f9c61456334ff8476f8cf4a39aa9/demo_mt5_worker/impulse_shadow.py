from __future__ import annotations

import math
import statistics
import time
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Deque, Optional

from profit_lock_shadow import ProfitLockShadow


def _num(value: Any, default: float = 0.0) -> float:
    try:
        value = float(value)
        return value if math.isfinite(value) else default
    except (TypeError, ValueError):
        return default


def _clamp(value: float, low: float = 0.0, high: float = 100.0) -> float:
    return max(low, min(high, float(value)))


def _median(values) -> float:
    values = [float(x) for x in values if math.isfinite(float(x))]
    return statistics.median(values) if values else 0.0


@dataclass
class TickSample:
    ts: float
    bid: float
    ask: float

    @property
    def mid(self) -> float:
        return (self.bid + self.ask) / 2.0

    @property
    def spread(self) -> float:
        return max(0.0, self.ask - self.bid)


class ImpulseShadowEngine:
    """Read-only microstructure/impulse observer.

    This engine is intentionally SHADOW ONLY. It never opens, closes, modifies,
    confirms or blocks a trade. Its job is to collect interpretable features for
    later walk-forward calibration of entry, pullback, exhaustion and reversal.
    Profit-lock evaluation is also shadow-only and can only read open positions.
    """

    def __init__(self, mt5_module, symbol: str, max_ticks: int = 600):
        self.mt5 = mt5_module
        self.symbol = str(symbol)
        self.ticks: Deque[TickSample] = deque(maxlen=max(120, int(max_ticks)))
        self.last_snapshot_at = 0.0
        self.last_state = "WARMUP"

        self.impulse_direction = 0
        self.impulse_origin_price = 0.0
        self.impulse_origin_at = 0.0
        self.impulse_extreme = 0.0
        self.peak_velocity_norm = 0.0
        self.peak_impulse_score = 0.0

        self.profit_lock_shadow = ProfitLockShadow()
        self._profit_last_print_at = 0.0
        self._profit_last_recommendation: dict[int, str] = {}

    def _append_tick(self, tick) -> Optional[TickSample]:
        bid = _num(getattr(tick, "bid", 0.0))
        ask = _num(getattr(tick, "ask", 0.0))
        if bid <= 0 or ask <= 0 or ask < bid:
            return None

        raw_ms = _num(getattr(tick, "time_msc", 0.0))
        raw_s = _num(getattr(tick, "time", 0.0))
        ts = raw_ms / 1000.0 if raw_ms > 0 else raw_s
        if ts <= 0:
            ts = time.time()

        sample = TickSample(ts=ts, bid=bid, ask=ask)
        if self.ticks and ts < self.ticks[-1].ts:
            ts = self.ticks[-1].ts
            sample = TickSample(ts=ts, bid=bid, ask=ask)
        self.ticks.append(sample)
        return sample

    @staticmethod
    def _row_value(row, key: str, default: float = 0.0) -> float:
        try:
            return _num(row[key], default)
        except (KeyError, IndexError, TypeError, ValueError):
            return default

    def _hydrate_recent_ticks(self, current: TickSample, lookback_seconds: float = 90.0) -> int:
        """Backfill the shadow observer from MT5 when the trading loop is slow.

        The execution loop can spend several seconds in PostgreSQL/risk checks,
        so sampling only one terminal tick per loop may keep the 10s/30s
        windows in WARMUP forever. Reading terminal tick history is read-only
        and keeps Direction V2 independent from execution decisions.
        """
        getter = getattr(self.mt5, "copy_ticks_from", None)
        flag = getattr(self.mt5, "COPY_TICKS_ALL", None)
        if not callable(getter) or flag is None or current.ts <= 0:
            return 0

        start_ts = max(0.0, current.ts - max(30.0, float(lookback_seconds)))
        try:
            rows = getter(
                self.symbol,
                datetime.fromtimestamp(start_ts, timezone.utc),
                5000,
                flag,
            )
        except Exception:
            return 0
        if rows is None or len(rows) == 0:
            return 0

        samples = list(self.ticks)
        for row in rows:
            bid = self._row_value(row, "bid")
            ask = self._row_value(row, "ask")
            raw_ms = self._row_value(row, "time_msc")
            raw_s = self._row_value(row, "time")
            ts = raw_ms / 1000.0 if raw_ms > 0 else raw_s
            if bid <= 0 or ask <= 0 or ask < bid or ts < start_ts or ts > current.ts + 1.0:
                continue
            samples.append(TickSample(ts=ts, bid=bid, ask=ask))

        unique = {}
        for sample in samples:
            key = (int(round(sample.ts * 1000.0)), round(sample.bid, 8), round(sample.ask, 8))
            unique[key] = sample
        merged = sorted(unique.values(), key=lambda sample: sample.ts)
        maxlen = self.ticks.maxlen or 600
        self.ticks.clear()
        self.ticks.extend(merged[-maxlen:])
        return len(merged)

    @staticmethod
    def _atr(rates, period: int = 14) -> float:
        if rates is None or len(rates) < 3:
            return 0.0
        rows = list(rates)
        trs = []
        prev_close = _num(rows[0]["close"])
        for row in rows[1:]:
            high = _num(row["high"])
            low = _num(row["low"])
            close = _num(row["close"])
            tr = max(high - low, abs(high - prev_close), abs(low - prev_close))
            if tr > 0:
                trs.append(tr)
            prev_close = close
        if not trs:
            return 0.0
        return sum(trs[-period:]) / min(period, len(trs))

    def _closed_m1(self, count: int = 64):
        getter = getattr(self.mt5, "copy_rates_from_pos", None)
        tf = getattr(self.mt5, "TIMEFRAME_M1", None)
        if not callable(getter) or tf is None:
            return None
        try:
            return getter(self.symbol, tf, 1, int(count))
        except Exception:
            return None

    def _window(self, seconds: float) -> list[TickSample]:
        if not self.ticks:
            return []
        cutoff = self.ticks[-1].ts - float(seconds)
        return [t for t in self.ticks if t.ts >= cutoff]

    @staticmethod
    def _directional_stats(window: list[TickSample]):
        if len(window) < 4:
            return 0, 0.0, 0.0, 0.0
        deltas = []
        for a, b in zip(window, window[1:]):
            d = b.mid - a.mid
            if d != 0:
                deltas.append(d)
        if not deltas:
            return 0, 0.0, 0.0, 0.0

        gross = sum(abs(d) for d in deltas)
        net = sum(deltas)
        direction = 1 if net > 0 else -1 if net < 0 else 0
        directional = sum(abs(d) for d in deltas if (d > 0) == (direction > 0))
        persistence = directional / gross if gross > 0 and direction else 0.0
        efficiency = abs(net) / gross if gross > 0 else 0.0
        span = max(1e-3, window[-1].ts - window[0].ts)
        velocity = abs(net) / span
        return direction, persistence, efficiency, velocity

    def _reset_impulse(self, direction: int, price: float, now: float, velocity_norm: float, score: float):
        self.impulse_direction = int(direction)
        self.impulse_origin_price = float(price)
        self.impulse_origin_at = float(now)
        self.impulse_extreme = float(price)
        self.peak_velocity_norm = max(0.0, float(velocity_norm))
        self.peak_impulse_score = max(0.0, float(score))

    def _observe_profit_lock(self, snapshot: dict, sample: TickSample) -> list[dict]:
        getter = getattr(self.mt5, "positions_get", None)
        if not callable(getter):
            return []
        try:
            positions = getter(symbol=self.symbol)
        except Exception as exc:
            snapshot["profit_lock_shadow_error"] = f"POSITIONS_GET_EXCEPTION:{exc}"
            return []
        if positions is None:
            snapshot["profit_lock_shadow_error"] = "POSITIONS_GET_NONE"
            return []

        results = self.profit_lock_shadow.evaluate(positions, snapshot, sample.bid, sample.ask)
        if not results:
            self._profit_last_recommendation.clear()
            return []

        now = time.monotonic()
        for result in results:
            ticket = int(_num(result.get("ticket")))
            recommendation = str(result.get("recommendation") or "UNKNOWN")
            changed = self._profit_last_recommendation.get(ticket) != recommendation
            urgent = recommendation == "CLOSE_CANDIDATE"
            if changed or urgent or now - self._profit_last_print_at >= 10.0:
                print(
                    "[V9 PROFIT SHADOW] "
                    f"ticket={ticket} | side={result.get('side')} | rec={recommendation} | "
                    f"reason={result.get('reason')} | gain={result.get('current_gain_distance')} | "
                    f"mfe={result.get('mfe_distance')} | giveback={result.get('giveback_ratio')} | "
                    f"allowed={result.get('allowed_giveback_ratio')} | "
                    f"state={result.get('impulse_state')} | weakening={result.get('weakening_score')} | "
                    f"reversal={result.get('reversal_score')} | execution impact=NONE",
                    flush=True,
                )
                self._profit_last_print_at = now
            self._profit_last_recommendation[ticket] = recommendation
        return results

    def observe(self, tick, min_interval: float = 1.0) -> Optional[dict]:
        sample = self._append_tick(tick)
        if sample is None:
            return None

        now_mono = time.monotonic()
        if now_mono - self.last_snapshot_at < max(0.25, float(min_interval)):
            return None
        self.last_snapshot_at = now_mono

        w10 = self._window(10.0)
        w30 = self._window(30.0)
        w60 = self._window(60.0)
        if len(w10) < 5 or len(w30) < 8:
            self._hydrate_recent_ticks(sample)
            w10 = self._window(10.0)
            w30 = self._window(30.0)
            w60 = self._window(60.0)
        if len(w10) < 5 or len(w30) < 8:
            return {
                "state": "WARMUP",
                "ticks_10s": len(w10),
                "ticks_30s": len(w30),
            }

        rates = self._closed_m1(64)
        atr = self._atr(rates, 14)
        if atr <= 0:
            return {"state": "WARMUP", "reason": "NO_CLOSED_M1_ATR"}

        direction, persistence, efficiency, vel10 = self._directional_stats(w10)
        dir30, persistence30, efficiency30, vel30 = self._directional_stats(w30)

        half = max(3, len(w10) // 2)
        _, _, _, vel_first = self._directional_stats(w10[:half])
        _, _, _, vel_second = self._directional_stats(w10[half - 1:])
        acceleration = (vel_second - vel_first) / max(vel_first, atr / 600.0, 1e-9)

        velocity_norm = vel10 * 60.0 / atr
        velocity_score = _clamp(velocity_norm / 0.60 * 30.0)
        persistence_score = _clamp((persistence - 0.50) / 0.35 * 25.0)
        efficiency_score = _clamp(efficiency / 0.75 * 20.0)
        accel_score = _clamp(max(0.0, acceleration) / 2.0 * 10.0)

        spreads = [t.spread for t in w60 if t.spread > 0]
        spread = sample.spread
        spread_median = _median(spreads)
        abs_dev = [abs(x - spread_median) for x in spreads]
        spread_mad = _median(abs_dev)
        spread_z = (spread - spread_median) / max(1e-9, 1.4826 * spread_mad) if spread_median > 0 else 0.0
        spread_penalty = _clamp(max(0.0, spread_z - 1.0) * 8.0, 0.0, 25.0)

        body_ratio = 0.0
        range_ratio = 0.0
        breakout = 0.0
        last_close = sample.mid
        if rates is not None and len(rates) >= 12:
            last = rates[-1]
            o = _num(last["open"])
            h = _num(last["high"])
            l = _num(last["low"])
            c = _num(last["close"])
            candle_range = max(0.0, h - l)
            body_ratio = abs(c - o) / candle_range if candle_range > 0 else 0.0
            range_ratio = candle_range / atr if atr > 0 else 0.0
            prior = list(rates)[-11:-1]
            prior_high = max(_num(r["high"]) for r in prior)
            prior_low = min(_num(r["low"]) for r in prior)
            if direction > 0 and last_close > prior_high:
                breakout = _clamp((last_close - prior_high) / atr, 0.0, 1.0)
            elif direction < 0 and last_close < prior_low:
                breakout = _clamp((prior_low - last_close) / atr, 0.0, 1.0)

        candle_score = _clamp(body_ratio * min(1.0, range_ratio / 1.2) * 8.0)
        breakout_score = breakout * 7.0

        impulse_score = _clamp(
            velocity_score
            + persistence_score
            + efficiency_score
            + accel_score
            + candle_score
            + breakout_score
            - spread_penalty
        )

        chop_score = _clamp((1.0 - efficiency30) * 65.0 + max(0.0, 0.60 - persistence30) * 60.0)

        if direction and impulse_score >= 60.0:
            if self.impulse_direction != direction or self.impulse_origin_price <= 0:
                self._reset_impulse(direction, sample.mid, sample.ts, velocity_norm, impulse_score)

        if self.impulse_direction:
            if self.impulse_direction > 0:
                self.impulse_extreme = max(self.impulse_extreme, sample.mid)
            else:
                self.impulse_extreme = min(self.impulse_extreme, sample.mid)
            self.peak_velocity_norm = max(self.peak_velocity_norm, velocity_norm)
            self.peak_impulse_score = max(self.peak_impulse_score, impulse_score)

        impulse_size = abs(self.impulse_extreme - self.impulse_origin_price) if self.impulse_origin_price > 0 else 0.0
        retracement = 0.0
        if impulse_size > 0:
            retracement = abs(self.impulse_extreme - sample.mid) / impulse_size

        velocity_decay = 0.0
        if self.peak_velocity_norm > 0:
            velocity_decay = _clamp(1.0 - velocity_norm / self.peak_velocity_norm, 0.0, 1.0) / 100.0

        age_seconds = max(0.0, sample.ts - self.impulse_origin_at) if self.impulse_origin_at > 0 else 0.0
        extension_atr = abs(sample.mid - self.impulse_origin_price) / atr if self.impulse_origin_price > 0 else 0.0
        late_penalty = _clamp(
            max(0.0, extension_atr - 0.8) * 22.0
            + max(0.0, age_seconds - 90.0) / 90.0 * 15.0
            + velocity_decay * 35.0,
            0.0,
            100.0,
        )

        opposite = bool(direction and self.impulse_direction and direction != self.impulse_direction)
        structure_damage = _clamp(max(0.0, retracement - 0.25) / 0.75 * 45.0)
        opposite_pressure = _clamp((impulse_score if opposite else 0.0) * 0.40)
        reversal_score = _clamp(structure_damage + opposite_pressure + velocity_decay * 20.0)
        pullback_score = _clamp(
            (1.0 - min(1.0, retracement)) * 45.0
            + (1.0 - min(1.0, velocity_decay)) * 20.0
            + (20.0 if not opposite else 0.0)
            + (15.0 if chop_score < 55.0 else 0.0)
        )
        weakening_score = _clamp(velocity_decay * 55.0 + max(0.0, retracement - 0.10) * 45.0)

        if chop_score >= 70.0 and impulse_score < 65.0:
            state = "CHOP"
        elif reversal_score >= 65.0 and opposite:
            state = "TRUE_REVERSAL_CANDIDATE"
        elif weakening_score >= 60.0 and impulse_size > 0:
            state = "WEAKENING_IMPULSE"
        elif retracement > 0.05 and pullback_score >= reversal_score + 10.0:
            state = "NORMAL_PULLBACK"
        elif impulse_score >= 70.0:
            state = "IMPULSE_ACTIVE"
        elif impulse_score >= 55.0:
            state = "IMPULSE_BUILDING"
        else:
            state = "NOISE"

        self.last_state = state
        snapshot = {
            "state": state,
            "direction": "BUY" if direction > 0 else "SELL" if direction < 0 else "FLAT",
            "impulse_score": round(impulse_score, 2),
            "pullback_score": round(pullback_score, 2),
            "weakening_score": round(weakening_score, 2),
            "reversal_score": round(reversal_score, 2),
            "chop_score": round(chop_score, 2),
            "late_penalty": round(late_penalty, 2),
            "tick_persistence": round(persistence, 4),
            "tick_efficiency": round(efficiency, 4),
            "velocity_atr_per_min": round(velocity_norm, 4),
            "velocity_decay": round(velocity_decay, 4),
            "acceleration": round(acceleration, 4),
            "spread": round(spread, 6),
            "spread_median": round(spread_median, 6),
            "spread_z": round(spread_z, 3),
            "atr_m1": round(atr, 6),
            "body_ratio_closed_m1": round(body_ratio, 4),
            "range_atr_closed_m1": round(range_ratio, 4),
            "breakout_atr": round(breakout, 4),
            "impulse_age_sec": round(age_seconds, 1),
            "extension_atr": round(extension_atr, 4),
            "retracement_ratio": round(retracement, 4),
            "origin_price": round(self.impulse_origin_price, 6),
            "extreme_price": round(self.impulse_extreme, 6),
            "current_price": round(sample.mid, 6),
            "shadow_only": True,
        }
        snapshot["profit_lock"] = self._observe_profit_lock(snapshot, sample)
        return snapshot
