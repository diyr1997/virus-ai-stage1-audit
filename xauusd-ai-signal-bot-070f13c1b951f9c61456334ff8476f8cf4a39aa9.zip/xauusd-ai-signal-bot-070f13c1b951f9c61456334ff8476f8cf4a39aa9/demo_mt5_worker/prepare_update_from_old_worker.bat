@echo off
setlocal EnableExtensions
cd /d "%~dp0"

if "%~1"=="" goto USAGE

set "OLD_DIR=%~1"
set "OLD_CFG=%OLD_DIR%\config_private.bat"
set "NEW_CFG=%CD%\config_private.bat"

if not exist "%OLD_CFG%" goto OLD_MISSING
if exist "%NEW_CFG%" goto NEW_EXISTS

set "BACKUP=%CD%\config_private.backup.bat"
copy /y "%OLD_CFG%" "%BACKUP%" >nul || goto COPY_FAIL
copy /y "%OLD_CFG%" "%NEW_CFG%" >nul || goto COPY_FAIL

echo [OK] config_private.bat copied into the NEW worker folder.
echo [OK] Backup created: config_private.backup.bat
echo [INFO] Old worker folder was NOT deleted or changed.
echo [INFO] This helper does NOT start the worker and does NOT send any orders.
echo [NEXT] Close the old worker CMD first, then run start_demo_bot.bat from this NEW folder.
exit /b 0

:USAGE
echo Usage:
echo   prepare_update_from_old_worker.bat "C:\path\to\OLD_worker_folder"
echo.
echo Example:
echo   prepare_update_from_old_worker.bat "C:\Users\1\Downloads\xauusd-demo-trader-clean"
exit /b 2

:OLD_MISSING
echo [ERROR] Old config_private.bat not found:
echo         %OLD_CFG%
echo [SAFE] Nothing was changed.
exit /b 3

:NEW_EXISTS
echo [ERROR] config_private.bat already exists in the NEW worker folder.
echo [SAFE] Refusing to overwrite it automatically.
echo [SAFE] Nothing was changed.
exit /b 4

:COPY_FAIL
echo [ERROR] Failed to copy config_private.bat.
echo [SAFE] Old worker folder was not changed.
exit /b 5
