from __future__ import annotations

import compileall
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent
EXPECTED_VERSION = "xauusd-demo-worker-v9-fenced-basket-v5-fast80-watchdog-2026-08-25"
REQUIRED = {
    "worker.py", "worker_auto.py", "worker_watchdog_v2.py", "worker_ownership.py",
    "trader.py", "trader_legacy.py", "trader_v9.py", "trader_v9_hardened.py",
    "trader_v9_hardened_v2.py", "trader_v9_hardened_v3.py",
    "trader_v9_hardened_v4.py", "trader_v9_hardened_v5.py",
    "trader_v9_hardened_v6.py", "trader_v9_hardened_v7.py",
    "impulse_shadow.py", "direction_shadow.py", "direction_shadow_integration.py",
    "direction_outcome_tracker.py", "profit_lock_shadow.py", "reverse_shadow.py",
    "reverse_shadow_integration.py", "fast_entry_shadow.py",
    "fast_entry_shadow_integration.py", "regime_shadow.py",
    "regime_shadow_integration.py", "shadow_outcome_tracker.py",
    "shadow_calibration_report.py", "shadow_calibration_integration.py",
    "requirements.txt", "start_demo_bot.bat", "windows_launcher.py", "diagnose_v9.py",
    "diagnose_demo_bot.bat", "config_private.example.bat",
    "prepare_update_from_old_worker.bat", "verify_v9_package.py",
}
FORBIDDEN_PATTERNS = ("apply_", "patch_", ".v9_package_handoff")


def fail(message):
    print(f"[V9 CHECK ERROR] {message}")
    raise SystemExit(1)


def read(name):
    path = ROOT / name
    if not path.is_file():
        fail(f"missing required file: {name}")
    return path.read_text(encoding="utf-8-sig")


def require(text, needle, label):
    if needle not in text:
        fail(f"{label}: required safety marker not found: {needle}")


def main():
    if sys.version_info < (3, 10):
        fail(f"Python 3.10+ required; found {sys.version.split()[0]}")
    if not compileall.compile_dir(ROOT, quiet=1, force=True):
        fail("one or more Python files failed to compile")

    names = {p.name for p in ROOT.iterdir() if p.is_file()}
    missing = sorted(REQUIRED - names)
    if missing:
        fail("missing runtime files: " + ", ".join(missing))
    forbidden = sorted(n for n in names if any(p.lower() in n.lower() for p in FORBIDDEN_PATTERNS))
    if forbidden:
        fail("legacy/build files present: " + ", ".join(forbidden))

    worker, trader, v9, v2, v3, v4, v7 = [
        read(n) for n in (
            "worker.py", "trader.py", "trader_v9.py", "trader_v9_hardened_v2.py",
            "trader_v9_hardened_v3.py", "trader_v9_hardened_v4.py",
            "trader_v9_hardened_v7.py",
        )
    ]
    shadow, direction, directionint, directionout, profit, reverse, revint, fast, fastint, regime, regimeint, outcomes, calib, calibint = [
        read(n) for n in (
            "impulse_shadow.py", "direction_shadow.py", "direction_shadow_integration.py",
            "direction_outcome_tracker.py", "profit_lock_shadow.py", "reverse_shadow.py",
            "reverse_shadow_integration.py", "fast_entry_shadow.py",
            "fast_entry_shadow_integration.py", "regime_shadow.py",
            "regime_shadow_integration.py", "shadow_outcome_tracker.py",
            "shadow_calibration_report.py", "shadow_calibration_integration.py",
        )
    ]
    watchdog, launcher, bat, diagnostic, dlauncher, template, migrate = [
        read(n) for n in (
            "worker_watchdog_v2.py", "windows_launcher.py", "start_demo_bot.bat",
            "diagnose_v9.py", "diagnose_demo_bot.bat", "config_private.example.bat",
            "prepare_update_from_old_worker.bat",
        )
    ]

    checks = [
        (worker, "DEMO_ONLY = True", "DEMO guard"),
        (worker, "ACCOUNT_TRADE_MODE_DEMO", "DEMO trade-mode guard"),
        (trader, "DemoTrader = V9HardenedV7DemoTrader", "canonical trader"),
        (trader, "from trader_v9_hardened_v7 import V9HardenedV7DemoTrader", "V7 import"),
        (v7, "class V9HardenedV7DemoTrader(V9HardenedV6DemoTrader)", "V7 inheritance"),
        (v7, "def _fresh_demo_account_guard", "fresh DEMO account guard"),
        (v7, "FRESH_ACCOUNT_NOT_DEMO", "fresh REAL-account block"),
        (v7, "FRESH_ACCOUNT_LOGIN_CHANGED", "fresh login-change block"),
        (v7, "result = self.mt5.order_send(request)", "broker send path"),
        (trader, "import reverse_shadow_integration", "reverse integration"),
        (trader, "import fast_entry_shadow_integration", "fast integration"),
        (trader, "import regime_shadow_integration", "regime integration"),
        (trader, "import shadow_calibration_integration", "calibration integration"),
        (v9, 'profile.pop("max_positions", None)', "dynamic basket sizing"),
        (v9, "def direction_guard", "opposite-side guard"),
        (v2, "positions_get returned None", "MT5 fail-closed guard"),
        (v3, "UNRESOLVED_RECHECK_SECONDS", "UNRESOLVED reconciliation"),
        (v3, '"auto_retry": False', "no ambiguous-send retry"),
        (v4, "FAST_ENTRY_MIN_STRENGTH", "fast-entry threshold"),
        (v4, "STRONG_IMPULSE_BYPASS_CONFIRMATION_ONLY", "fast-entry bypass"),
        (v4, "FAST_ENTRY_WAIT_IGNORED", "fast transient WAIT protection"),
        (v4, "FAST_ENTRY_SLOT_BLOCKED", "fast silent slot diagnostics"),
        (v4, "CURRENT_PRICE_AT_OR_BELOW_SL", "BUY SL guard"),
        (v4, "CURRENT_PRICE_AT_OR_ABOVE_SL", "SELL SL guard"),
        (v4, "SHADOW_FAST_OUTCOME", "outcome DB wiring"),
        (shadow, "SHADOW ONLY", "shadow marker"),
        (direction, "SHADOW ONLY", "direction shadow"),
        (directionint, "execution impact=NONE", "direction isolation"),
        (directionout, "HORIZONS = (60, 180, 300)", "direction outcome horizons"),
        (directionout, "confidence_bucket", "direction confidence buckets"),
        (directionout, "market_regime", "direction regime dimension"),
        (directionout, "trading_session", "direction session dimension"),
        (directionout, "BOTH_CORRECT", "legacy vs V2 comparison"),
        (profit, "SHADOW ONLY", "profit shadow"),
        (reverse, "SHADOW ONLY", "reverse shadow"),
        (fast, "SHADOW ONLY", "fast shadow"),
        (regime, "SHADOW ONLY", "regime shadow"),
        (regime, "LONDON_NEW_YORK_OVERLAP", "session regime"),
        (regime, "suggested_fast_threshold", "dynamic threshold suggestion"),
        (regimeint, "execution impact=NONE", "regime isolation"),
        (outcomes, "HORIZONS = (30, 60, 180, 300)", "outcome horizons"),
        (outcomes, "mfe_atr", "MFE calibration"),
        (outcomes, "mae_atr", "MAE calibration"),
        (calib, "READ ONLY", "calibration read-only marker"),
        (calib, "SHADOW_FAST_OUTCOME", "calibration outcome query"),
        (calib, "helped_rate", "calibration usefulness metric"),
        (calibint, "execution impact=NONE", "calibration isolation"),
        (calibint, "SHADOW_CALIBRATION_SECONDS", "calibration interval"),
        (watchdog, "STALE_FEED_RESTART_SECONDS", "watchdog"),
        (launcher, EXPECTED_VERSION, "launcher version"),
        (launcher, "FAST80 WAIT-FIX ACTIVE", "launcher wait-fix marker"),
        (launcher, "FAST80 DIAGNOSTICS ACTIVE", "launcher diagnostics marker"),
        (launcher, "verify_v9_package.py", "self-check"),
        (diagnostic, "core.mt5_initialize()", "diagnostic guard"),
        (dlauncher, "diagnose_v9.py", "diagnostic launcher"),
        (migrate, "Refusing to overwrite", "migration no-overwrite"),
        (migrate, "does NOT start the worker", "migration no-autostart"),
        (migrate, "Old worker folder was NOT deleted or changed", "migration preserves old folder"),
    ]
    for text, needle, label in checks:
        require(text, needle, label)

    for label, text in (
        ("direction_shadow.py", direction),
        ("direction_shadow_integration.py", directionint),
        ("direction_outcome_tracker.py", directionout),
        ("profit_lock_shadow.py", profit),
        ("reverse_shadow.py", reverse),
        ("reverse_shadow_integration.py", revint),
        ("fast_entry_shadow.py", fast),
        ("fast_entry_shadow_integration.py", fastint),
        ("regime_shadow.py", regime),
        ("regime_shadow_integration.py", regimeint),
        ("shadow_outcome_tracker.py", outcomes),
        ("shadow_calibration_report.py", calib),
        ("shadow_calibration_integration.py", calibint),
    ):
        for forbidden_call in (
            "order_send", "TRADE_ACTION", "position_close", "close_position(",
            "open_position(", "modify_position", "TRADE_ACTION_SLTP", "order_check(",
        ):
            if forbidden_call in text:
                fail(f"{label} must remain read-only: forbidden marker {forbidden_call}")

    require(bat, "windows_launcher.py", "minimal BAT")
    if "STALE_FEED_RESTART_SECONDS" in bat or "FAST_ENTRY_MIN_STRENGTH" in bat:
        fail("start_demo_bot.bat must remain minimal")
    if "order_send" in diagnostic or "trader.step" in diagnostic or "DemoTrader(" in diagnostic:
        fail("diagnostic must remain read-only")
    for marker in (
        'set "DATABASE_PUBLIC_URL="', 'set "MT5_LOGIN="', 'set "MT5_PASSWORD="',
        'set "MT5_SERVER="', 'set "MT5_PATH="',
    ):
        require(template, marker, "safe config template")
    if re.search(r"DEMO_REVERSAL_ENABLED[^\n]*=1", launcher, flags=re.I):
        fail("reversal must remain disabled/shadow")

    print(f"[V9 CHECK OK] {EXPECTED_VERSION}")
    print(f"[V9 CHECK OK] Python {sys.version.split()[0]}")
    print("[V9 CHECK OK] every Python file compiles")
    print("[V9 CHECK OK] canonical trader is V7 with fresh DEMO account guard")
    print("[V9 CHECK OK] FAST80 startup markers present")
    print("[V9 CHECK OK] FAST80 ignores only transient WAIT after arming and logs silent slot blocks")
    print("[V9 CHECK OK] safe config migration helper present and fail-closed")
    print("[V9 CHECK OK] FAST shadow outcomes persist MFE/MAE at 30/60/180/300s")
    print("[V9 CHECK OK] Direction OLD-vs-V2 outcomes persist 1/3/5m confidence/regime/session dimensions")
    print("[V9 CHECK OK] SHADOW calibration aggregates reason/horizon usefulness read-only")
    print("[V9 CHECK OK] regime shadow classifies session/volatility and only suggests thresholds")
    print("[V9 CHECK OK] local config_private.bat is allowed after extraction")


if __name__ == "__main__":
    main()
