BEGIN;

ALTER TABLE demo_trades ADD COLUMN IF NOT EXISTS basket_id TEXT;
ALTER TABLE demo_trades ADD COLUMN IF NOT EXISTS basket_slot INTEGER;
ALTER TABLE demo_trades ADD COLUMN IF NOT EXISTS order_claim_key TEXT;
ALTER TABLE demo_trades ADD COLUMN IF NOT EXISTS fence_token BIGINT;
CREATE SEQUENCE IF NOT EXISTS demo_basket_id_seq;

WITH groups AS (
    SELECT symbol,
           UPPER(side) AS side,
           'B' || nextval('demo_basket_id_seq')::text AS basket_id
    FROM demo_trades
    WHERE status IN ('PENDING','OPEN','UNRESOLVED')
      AND basket_id IS NULL
    GROUP BY symbol, UPPER(side)
)
UPDATE demo_trades d
SET basket_id = g.basket_id
FROM groups g
WHERE d.symbol = g.symbol
  AND UPPER(d.side) = g.side
  AND d.status IN ('PENDING','OPEN','UNRESOLVED')
  AND d.basket_id IS NULL;

WITH ranked AS (
    SELECT id,
           ROW_NUMBER() OVER (
               PARTITION BY basket_id
               ORDER BY COALESCE(opened_at, created_at), id
           ) AS rn
    FROM demo_trades
    WHERE status IN ('PENDING','OPEN','UNRESOLVED')
      AND basket_id IS NOT NULL
      AND basket_slot IS NULL
)
UPDATE demo_trades d
SET basket_slot = ranked.rn
FROM ranked
WHERE d.id = ranked.id;

UPDATE demo_trades
SET order_claim_key = 'LEGACY|' || basket_id || '|trade:' || id::text
WHERE status IN ('PENDING','OPEN','UNRESOLVED')
  AND basket_id IS NOT NULL
  AND order_claim_key IS NULL;

UPDATE demo_trades
SET fence_token = 0
WHERE status IN ('PENDING','OPEN','UNRESOLVED')
  AND fence_token IS NULL;

CREATE UNIQUE INDEX IF NOT EXISTS uq_demo_trades_order_claim_key_v9
ON demo_trades(order_claim_key);

DO $$
DECLARE missing_count BIGINT;
BEGIN
    SELECT COUNT(*) INTO missing_count
    FROM demo_trades
    WHERE status IN ('PENDING','OPEN','UNRESOLVED')
      AND (
          basket_id IS NULL OR
          basket_slot IS NULL OR
          order_claim_key IS NULL OR
          fence_token IS NULL
      );
    IF missing_count <> 0 THEN
        RAISE EXCEPTION 'V9 migration validation failed: % active rows incomplete', missing_count;
    END IF;
END $$;

COMMIT;

-- Historical CLOSED/REJECTED rows are intentionally allowed to retain NULL V9 fields.
-- PostgreSQL UNIQUE indexes allow multiple NULL values, while every new V9 order claim
-- is non-NULL and therefore protected against duplicate basket-slot sends.
