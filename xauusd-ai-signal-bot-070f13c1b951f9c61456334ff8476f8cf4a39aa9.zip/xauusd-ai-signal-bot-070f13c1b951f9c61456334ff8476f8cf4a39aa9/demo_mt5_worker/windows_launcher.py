from __future__ import annotations

import compileall
import json
import os
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent
VERSION = "xauusd-demo-worker-v9-fenced-basket-v5-fast80-watchdog-2026-08-25"
LOCAL_LOCK_PATH = ROOT / ".v9_windows_launcher.lock"
_LOCAL_LOCK_HANDLE = None

DEFAULTS = {
    "DEMO_WORKER_VERSION": VERSION,
    "GOLD_DAILY_BREAK_START": "01:55",
    "GOLD_DAILY_BREAK_END": "03:10",
    "DEMO_REVERSAL_ENABLED": "0",
    "V9_UNRESOLVED_AFTER_SECONDS": "60",
    "V9_UNRESOLVED_RECHECK_SECONDS": "30",
    "STALE_FEED_RESTART_SECONDS": "180",
    "FAST_ENTRY_MIN_STRENGTH": "80",
}


def die(message: str, code: int = 1) -> int:
    print(f"[ERROR] {message}")
    return code


def run(args: list[str], *, required: bool = True) -> int:
    print("[RUN]", " ".join(args))
    completed = subprocess.run(args, cwd=ROOT)
    if required and completed.returncode != 0:
        raise RuntimeError(f"command failed ({completed.returncode}): {' '.join(args)}")
    return completed.returncode


def acquire_local_launcher_lock() -> None:
    """Prevent two copies of this Windows launcher from running at once.

    PostgreSQL ownership/fencing remains the final trading safety barrier. This
    local lock only makes accidental double-clicks fail fast and keeps logs clean.
    The OS releases the byte-range lock automatically when this process exits.
    """
    global _LOCAL_LOCK_HANDLE
    if os.name != "nt":
        return
    try:
        import msvcrt

        handle = open(LOCAL_LOCK_PATH, "a+b")
        handle.seek(0)
        if handle.tell() == 0:
            handle.write(b"0")
            handle.flush()
        handle.seek(0)
        try:
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError as exc:
            handle.close()
            raise RuntimeError(
                "Another XAUUSD V9 Windows launcher is already running. "
                "Close the old worker/CMD window before starting this package."
            ) from exc
        _LOCAL_LOCK_HANDLE = handle
        print(f"LOCAL LAUNCHER LOCK: ACTIVE | {LOCAL_LOCK_PATH.name}")
    except RuntimeError:
        raise
    except Exception as exc:
        raise RuntimeError(f"Unable to acquire local launcher lock: {exc}") from exc


def configure_environment() -> None:
    for key, value in DEFAULTS.items():
        os.environ.setdefault(key, value)


def validate_environment() -> None:
    if not (os.getenv("DATABASE_PUBLIC_URL") or os.getenv("DATABASE_URL")):
        raise RuntimeError("DATABASE_PUBLIC_URL or DATABASE_URL is not set in config_private.bat")
    if not os.getenv("MT5_LOGIN"):
        raise RuntimeError("MT5_LOGIN is not set in config_private.bat")
    if not os.getenv("MT5_SERVER"):
        raise RuntimeError("MT5_SERVER is not set in config_private.bat")


def load_build_manifest() -> dict[str, object]:
    path = ROOT / "BUILD_MANIFEST.json"
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception as exc:
        raise RuntimeError(f"BUILD_MANIFEST.json is unreadable: {exc}") from exc
    if data.get("execution_scope") != "DEMO_ONLY":
        raise RuntimeError("BUILD_MANIFEST execution_scope must be DEMO_ONLY")
    return data


def install_requirements() -> None:
    req = ROOT / "requirements.txt"
    if not req.is_file():
        raise RuntimeError("requirements.txt is missing")
    run([sys.executable, "-m", "pip", "install", "-r", str(req)])


def verify_package() -> None:
    if sys.version_info < (3, 10):
        raise RuntimeError(f"Python 3.10+ required; found {sys.version.split()[0]}")
    ok = compileall.compile_dir(ROOT, quiet=1, force=True)
    if not ok:
        raise RuntimeError("Python compile check failed")
    run([sys.executable, str(ROOT / "verify_v9_package.py")])


def run_diagnostic() -> None:
    code = run([sys.executable, str(ROOT / "diagnose_v9.py")], required=False)
    if code != 0:
        print(f"[WARNING] read-only diagnostic returned {code}; worker will start fail-closed and reconnect")


def worker_loop() -> int:
    worker = ROOT / "worker_watchdog_v2.py"
    if not worker.is_file():
        return die("worker_watchdog_v2.py is missing")

    manifest = load_build_manifest()
    build_id = str(manifest.get("build_id") or "SOURCE-TREE")
    source_sha = str(manifest.get("source_sha256") or "n/a")
    generated = str(manifest.get("generated_at_utc") or "n/a")

    print("=" * 58)
    print("XAUUSD DEMO worker V9 V5 FAST80 WATCHDOG")
    print(f"VERSION: {VERSION}")
    print(f"PACKAGE BUILD_ID: {build_id}")
    print(f"PACKAGE SOURCE_SHA256: {source_sha}")
    print(f"PACKAGE GENERATED_UTC: {generated}")
    print("FAST80 WAIT-FIX ACTIVE | transient WAIT<60 no longer cancels armed FAST80")
    print("FAST80 DIAGNOSTICS ACTIVE | slot/risk/order blocks must be logged")
    print("LOCAL DUPLICATE-LAUNCH GUARD ACTIVE")
    print("DEMO ONLY - REAL accounts remain blocked")
    print("=" * 58)

    while True:
        code = subprocess.call([sys.executable, str(worker)], cwd=ROOT)
        if code == 0:
            print("Worker stopped normally.")
            return 0
        print(f"[WARNING] worker exited with code {code}; restarting in 10 seconds")
        time.sleep(10)


def main() -> int:
    try:
        acquire_local_launcher_lock()
        configure_environment()
        validate_environment()
        install_requirements()
        verify_package()
        run_diagnostic()
        return worker_loop()
    except KeyboardInterrupt:
        print("Stopped by user.")
        return 0
    except Exception as exc:
        return die(str(exc))


if __name__ == "__main__":
    raise SystemExit(main())