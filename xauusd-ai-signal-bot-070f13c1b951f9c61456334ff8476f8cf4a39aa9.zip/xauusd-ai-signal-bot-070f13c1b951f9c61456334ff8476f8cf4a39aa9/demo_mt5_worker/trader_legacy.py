from __future__ import annotations

import json
import logging
import math
import os
import time
from datetime import datetime, timedelta, timezone

import psycopg2
from psycopg2.extras import Json


log = logging.getLogger("xauusd-demo-trader")


# ============================================================
# РЕЖИМЫ РИСКА — ТОЛЬКО ДЛЯ DEMO-БОТА №2
# ============================================================

RISK_PROFILES = {
    "CAUTIOUS": {
        "scenario_risk_pct": 0.50,
        "portfolio_risk_pct": 1.50,
        "daily_loss_pct": 1.50,
        "free_margin_reserve_pct": 70.0,
        "max_positions": 2,
        "initial_slots": 1,
        "add_step_ratio": 0.45,
        "min_entry_gap_sec": 30,
    },
    "MEDIUM": {
        "scenario_risk_pct": 1.00,
        "portfolio_risk_pct": 3.00,
        "daily_loss_pct": 2.50,
        "free_margin_reserve_pct": 55.0,
        "max_positions": 3,
        "initial_slots": 2,
        "add_step_ratio": 0.30,
        "min_entry_gap_sec": 20,
    },
    "ACTIVE": {
        "scenario_risk_pct": 1.50,
        "portfolio_risk_pct": 4.50,
        "daily_loss_pct": 4.00,
        "free_margin_reserve_pct": 40.0,
        "max_positions": 4,
        "initial_slots": 2,
        "add_step_ratio": 0.22,
        "min_entry_gap_sec": 12,
    },
    "AGGRESSIVE": {
        # Только DEMO. worker.py отдельно блокирует REAL.
        "scenario_risk_pct": 2.50,
        "portfolio_risk_pct": 7.50,
        "daily_loss_pct": 6.00,
        "free_margin_reserve_pct": 30.0,
        "max_positions": 5,
        "initial_slots": 2,
        "add_step_ratio": 0.15,
        "min_entry_gap_sec": 8,
    },
}

# Лестница силы — верхний предел на ОДНУ новую позицию.
STRENGTH_LOTS = (
    (60, 64, 0.01),
    (65, 69, 0.02),
    (70, 74, 0.03),
    (75, 79, 0.04),
    (80, 84, 0.05),
    (85, 89, 0.06),
    (90, 94, 0.07),
    (95, 100, 0.08),
)


def num(value, default=0.0):
    try:
        value = float(value)
        return value if math.isfinite(value) else default
    except (TypeError, ValueError):
        return default


def integer(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def utcnow():
    return datetime.now(timezone.utc)


def normalize_mode(value):
    value = str(value or "").strip().upper()
    aliases = {
        "ОСТОРОЖНЫЙ": "CAUTIOUS",
        "СРЕДНИЙ": "MEDIUM",
        "АКТИВНЫЙ": "ACTIVE",
        "АГРЕССИВНЫЙ": "AGGRESSIVE",
        "SAFE": "CAUTIOUS",
        "NORMAL": "MEDIUM",
    }
    value = aliases.get(value, value)
    return value if value in RISK_PROFILES else "MEDIUM"


def strength_lot_cap(strength):
    strength = max(0, min(100, integer(strength)))
    for low, high, lot in STRENGTH_LOTS:
        if low <= strength <= high:
            return lot
    return 0.0


class DemoTrader:
    def __init__(
        self,
        database_url,
        mt5_module,
        symbol="XAUUSD",
        magic=260817,
    ):
        self.database_url = str(database_url or "").strip()
        self.mt5 = mt5_module

        # Торговый символ MT5, например GOLD#.
        self.symbol = str(symbol or "XAUUSD").strip()

        # Символ аналитического бота в PostgreSQL.
        self.signal_symbol = (
            str(os.getenv("SIGNAL_SYMBOL", "XAUUSD") or "XAUUSD")
            .strip()
            .upper()
        )

        self.magic = int(magic)

        if not self.database_url:
            raise RuntimeError("DATABASE_URL не найден.")

        self.default_mode = normalize_mode(
            os.getenv("DEMO_RISK_MODE", "MEDIUM")
        )
        self.deviation = max(
            1,
            int(os.getenv("MT5_DEVIATION_POINTS", "50")),
        )
        self.mode_cache = self.default_mode
        self.mode_cache_at = 0.0
        self.last_status_write = 0.0

        self.ensure_schema()
        self.set_setting_if_missing(
            "demo_risk_mode",
            self.default_mode,
        )

        log.info(
            "DemoTrader готов | signal=%s -> MT5=%s | режим=%s",
            self.signal_symbol,
            self.symbol,
            self.default_mode,
        )

    # ========================================================
    # DB
    # ========================================================

    def connect(self):
        kwargs = {
            "connect_timeout": 10,
            "application_name": "xauusd_demo_trader",
        }

        sslmode = os.getenv("DB_SSLMODE", "").strip()
        if sslmode:
            kwargs["sslmode"] = sslmode

        conn = psycopg2.connect(
            self.database_url,
            **kwargs,
        )
        conn.autocommit = True
        return conn

    def ensure_schema(self):
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    CREATE TABLE IF NOT EXISTS bot_settings (
                        key VARCHAR(80) PRIMARY KEY,
                        value TEXT NOT NULL,
                        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                    )
                    """
                )
                cur.execute(
                    """
                    CREATE TABLE IF NOT EXISTS demo_trader_events (
                        id BIGSERIAL PRIMARY KEY,
                        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                        event_type VARCHAR(40) NOT NULL,
                        candidate_id BIGINT,
                        trade_id BIGINT,
                        symbol VARCHAR(24),
                        payload JSONB NOT NULL DEFAULT '{}'::jsonb
                    )
                    """
                )
        finally:
            conn.close()

    def set_setting_if_missing(self, key, value):
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO bot_settings(key, value, updated_at)
                    VALUES(%s, %s, NOW())
                    ON CONFLICT(key) DO NOTHING
                    """,
                    (str(key), str(value)),
                )
        finally:
            conn.close()

    def set_setting(self, key, value):
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO bot_settings(key, value, updated_at)
                    VALUES(%s, %s, NOW())
                    ON CONFLICT(key)
                    DO UPDATE SET
                        value = EXCLUDED.value,
                        updated_at = NOW()
                    """,
                    (str(key), str(value)),
                )
        finally:
            conn.close()

    def get_setting(self, key, fallback):
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT value
                    FROM bot_settings
                    WHERE key = %s
                    LIMIT 1
                    """,
                    (str(key),),
                )
                row = cur.fetchone()
            return str(row[0]) if row else fallback
        finally:
            conn.close()

    def event(
        self,
        event_type,
        candidate_id=None,
        trade_id=None,
        payload=None,
    ):
        conn = None
        try:
            conn = self.connect()
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO demo_trader_events(
                        event_type,
                        candidate_id,
                        trade_id,
                        symbol,
                        payload
                    )
                    VALUES(%s, %s, %s, %s, %s)
                    """,
                    (
                        str(event_type)[:40],
                        candidate_id,
                        trade_id,
                        self.symbol,
                        Json(payload or {}),
                    ),
                )
        except Exception as exc:
            log.warning("EVENT DB: %s", exc)
        finally:
            if conn:
                conn.close()

    # ========================================================
    # MODE
    # ========================================================

    def risk_mode(self):
        now = time.monotonic()

        if now - self.mode_cache_at >= 5:
            self.mode_cache = normalize_mode(
                self.get_setting(
                    "demo_risk_mode",
                    self.default_mode,
                )
            )
            self.mode_cache_at = now

        return self.mode_cache, RISK_PROFILES[self.mode_cache]

    # ========================================================
    # CANDIDATES / ANALYSIS
    # ========================================================

    def load_candidates(self):
        # Кандидаты создаются аналитическим ботом как XAUUSD,
        # а MT5 у брокера может торговать GOLD#.
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT
                        tc.id,
                        tc.analysis_id,
                        tc.created_at,
                        tc.expires_at,
                        tc.symbol,
                        tc.timeframe,
                        tc.side,
                        tc.strength,
                        tc.confirmation_price,
                        tc.invalidation_price,
                        tc.sl,
                        tc.tp1,
                        tc.tp2,
                        tc.tp3,
                        tc.status,
                        tc.payload,
                        ar.candle_time AS source_candle_time
                    FROM trade_candidates tc
                    LEFT JOIN analysis_runs ar
                      ON ar.id = tc.analysis_id
                    WHERE UPPER(tc.symbol) = %s
                      AND tc.status IN(
                          'WAIT_CONFIRMATION',
                          'CONFIRMED',
                          'ACTIVE'
                      )
                    ORDER BY tc.strength DESC, tc.created_at ASC
                    LIMIT 20
                    """,
                    (self.signal_symbol,),
                )
                names = [d[0] for d in cur.description]
                return [
                    dict(zip(names, row))
                    for row in cur.fetchall()
                ]
        finally:
            conn.close()

    def update_candidate_status(self, candidate_id, status):
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE trade_candidates
                    SET status = %s
                    WHERE id = %s
                    """,
                    (str(status)[:32], int(candidate_id)),
                )
        finally:
            conn.close()

    def load_latest_analyses(self):
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT DISTINCT ON (timeframe)
                        id,
                        timeframe,
                        analyzed_at,
                        candle_time,
                        action,
                        direction,
                        strength,
                        analysis_price
                    FROM analysis_runs
                    WHERE timeframe IN(
                        'M1', 'M5', 'M15', 'M30', 'H1'
                    )
                    ORDER BY timeframe, analyzed_at DESC, id DESC
                    """
                )

                names = [d[0] for d in cur.description]
                rows = [
                    dict(zip(names, row))
                    for row in cur.fetchall()
                ]
        finally:
            conn.close()

        return {
            str(row["timeframe"]).upper(): row
            for row in rows
        }

    @staticmethod
    def _aware_utc(value):
        if not isinstance(value, datetime):
            return None

        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)

        return value.astimezone(timezone.utc)

    def analysis_is_newer(self, candidate, latest):
        if not latest:
            return False

        source_candle = self._aware_utc(
            candidate.get("source_candle_time")
        )
        latest_candle = self._aware_utc(
            latest.get("candle_time")
        )

        if source_candle and latest_candle:
            return latest_candle > source_candle

        if integer(latest.get("id")) == integer(
            candidate.get("analysis_id")
        ):
            return False

        created_at = self._aware_utc(candidate.get("created_at"))
        analyzed_at = self._aware_utc(latest.get("analyzed_at"))

        if created_at and analyzed_at:
            return analyzed_at > created_at

        return True

    def latest_analysis_allows_add(self, candidate, latest=None):
        if latest is None:
            latest = self.load_latest_analyses().get(
                str(candidate["timeframe"]).upper()
            )

        if not latest:
            return True, "NO_NEW_ANALYSIS"

        if not self.analysis_is_newer(candidate, latest):
            return True, "CANDIDATE_NEWER"

        action = str(latest.get("action") or "").upper()
        direction = str(latest.get("direction") or "").upper()
        strength = integer(latest.get("strength"))

        if action == "WAIT" or strength < 60:
            return False, "STRENGTH_BELOW_60_OR_WAIT"

        if direction != str(candidate["side"]).upper():
            return False, "DIRECTION_CHANGED"

        return True, "OK"

    def candidate_trades(self, candidate_id, open_only=False):
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                where = (
                    "AND status = 'OPEN'"
                    if open_only
                    else "AND status IN('PENDING','OPEN','CLOSED')"
                )

                cur.execute(
                    f"""
                    SELECT
                        id, opened_at, side, lot,
                        entry_price, sl, tp,
                        mt5_ticket, payload, status
                    FROM demo_trades
                    WHERE candidate_id = %s
                    {where}
                    ORDER BY id ASC
                    """,
                    (int(candidate_id),),
                )

                names = [d[0] for d in cur.description]
                return [
                    dict(zip(names, row))
                    for row in cur.fetchall()
                ]
        finally:
            conn.close()

    # ========================================================
    # ACCOUNT GUARDS
    # ========================================================

    def assert_demo(self, account):
        demo_mode = getattr(
            self.mt5,
            "ACCOUNT_TRADE_MODE_DEMO",
            0,
        )

        if int(account.trade_mode) != int(demo_mode):
            raise RuntimeError(
                "ЗАБЛОКИРОВАНО: обнаружен не DEMO-счёт."
            )

    def daily_realized_profit(self):
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT COALESCE(SUM(profit), 0)
                    FROM demo_trades
                    WHERE status = 'CLOSED'
                      AND closed_at >= date_trunc('day', NOW())
                    """
                )
                row = cur.fetchone()

            return num(row[0])
        finally:
            conn.close()

    def account_allows_new_trade(self, account, profile):
        # Перед новой сделкой учитываем balance/equity/margin/free margin.
        balance = max(0.0, num(getattr(account, "balance", 0.0)))
        equity = max(0.0, num(getattr(account, "equity", 0.0)))
        margin = max(0.0, num(getattr(account, "margin", 0.0)))
        free_margin = max(0.0, num(getattr(account, "margin_free", 0.0)))

        if balance <= 0:
            return False, "NO_BALANCE"
        if equity <= 0:
            return False, "NO_EQUITY"

        risk_base = min(balance, equity)
        daily_limit = risk_base * profile["daily_loss_pct"] / 100.0

        if self.daily_realized_profit() <= -daily_limit:
            return False, "DAILY_LOSS_LIMIT"

        reserve = (
            risk_base
            * profile["free_margin_reserve_pct"]
            / 100.0
        )

        if free_margin <= reserve:
            return False, "FREE_MARGIN_RESERVE"

        if margin > 0 and free_margin <= 0:
            return False, "NO_FREE_MARGIN"

        return True, "OK"

    # ========================================================
    # RISK / LOT
    # ========================================================

    def order_type(self, side):
        if str(side).upper() == "BUY":
            return self.mt5.ORDER_TYPE_BUY

        return self.mt5.ORDER_TYPE_SELL

    def risk_money(self, side, lot, entry, sl):
        if lot <= 0 or entry <= 0 or sl <= 0:
            return 0.0

        value = self.mt5.order_calc_profit(
            self.order_type(side),
            float(lot),
            float(entry),
            float(sl),
        )

        return abs(num(value)) if value is not None else 0.0

    def all_open_bot_trades(self):
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT
                        candidate_id, side, lot,
                        entry_price, sl, payload
                    FROM demo_trades
                    WHERE symbol = %s
                      AND status = 'OPEN'
                    """,
                    (self.symbol,),
                )

                names = [d[0] for d in cur.description]

                return [
                    dict(zip(names, row))
                    for row in cur.fetchall()
                ]
        finally:
            conn.close()

    def used_risk(self, trades):
        total = 0.0

        for trade in trades:
            risk = self.risk_money(
                trade["side"],
                num(trade["lot"]),
                num(trade["entry_price"]),
                num(trade["sl"]),
            )

            if risk <= 0:
                payload = trade.get("payload") or {}

                if isinstance(payload, str):
                    try:
                        payload = json.loads(payload)
                    except Exception:
                        payload = {}

                risk = num(payload.get("risk_amount"))

            total += max(0.0, risk)

        return total

    def volume_rules(self):
        info = self.mt5.symbol_info(self.symbol)

        if info is None:
            raise RuntimeError(
                f"symbol_info({self.symbol}) недоступен."
            )

        vmin = max(0.0, num(info.volume_min, 0.01))
        vmax = max(vmin, num(info.volume_max, 100.0))
        vstep = max(0.0001, num(info.volume_step, 0.01))

        return vmin, vmax, vstep

    @staticmethod
    def floor_volume(value, vmin, vmax, vstep):
        value = min(vmax, max(0.0, value))

        if value < vmin:
            return 0.0

        result = math.floor(
            (value + 1e-12) / vstep
        ) * vstep

        result = round(result, 4)

        return result if result >= vmin else 0.0

    def choose_volume(self, candidate, account, profile, price):
        # Сила сигнала задаёт только верхний предел лота.
        # Фактический лот уменьшается по риску до SL и свободной марже.
        strength = integer(candidate["strength"])
        side = str(candidate["side"]).upper()
        sl = num(candidate["sl"])
        cap = strength_lot_cap(strength)

        if strength < 60 or cap <= 0 or sl <= 0:
            return 0.0, {
                "reason": "NO_SAFE_SIGNAL_OR_SL",
                "strength": strength,
                "strength_cap": cap,
            }

        balance = max(0.0, num(getattr(account, "balance", 0.0)))
        equity = max(0.0, num(getattr(account, "equity", 0.0)))
        margin = max(0.0, num(getattr(account, "margin", 0.0)))
        free_margin = max(0.0, num(getattr(account, "margin_free", 0.0)))

        if balance <= 0:
            return 0.0, {"reason": "NO_BALANCE"}
        if equity <= 0:
            return 0.0, {"reason": "NO_EQUITY"}

        risk_base = min(balance, equity)

        candidate_open = self.candidate_trades(
            candidate["id"],
            open_only=True,
        )
        all_open = self.all_open_bot_trades()

        scenario_budget = (
            risk_base
            * profile["scenario_risk_pct"]
            / 100.0
        )
        portfolio_budget = (
            risk_base
            * profile["portfolio_risk_pct"]
            / 100.0
        )

        scenario_used = self.used_risk(candidate_open)
        portfolio_used = self.used_risk(all_open)

        available_risk = min(
            max(0.0, scenario_budget - scenario_used),
            max(0.0, portfolio_budget - portfolio_used),
        )

        risk_one_lot = self.risk_money(
            side,
            1.0,
            price,
            sl,
        )

        if available_risk <= 0:
            return 0.0, {
                "reason": "RISK_BUDGET_FULL",
                "scenario_budget": scenario_budget,
                "scenario_used": scenario_used,
                "portfolio_budget": portfolio_budget,
                "portfolio_used": portfolio_used,
            }

        if risk_one_lot <= 0:
            return 0.0, {"reason": "SL_RISK_CALC_FAILED"}

        lot_by_risk = available_risk / risk_one_lot

        vmin, vmax, vstep = self.volume_rules()
        lot = self.floor_volume(
            min(cap, lot_by_risk),
            vmin,
            vmax,
            vstep,
        )

        if lot <= 0:
            return 0.0, {
                "reason": "RISK_TOO_SMALL_FOR_MIN_LOT",
                "strength_cap": cap,
                "lot_by_risk": lot_by_risk,
                "min_lot": vmin,
            }

        reserve = (
            risk_base
            * profile["free_margin_reserve_pct"]
            / 100.0
        )
        spendable = max(0.0, free_margin - reserve)

        while lot >= vmin:
            required_margin = self.mt5.order_calc_margin(
                self.order_type(side),
                float(lot),
                float(price),
            )

            required_margin_value = (
                num(required_margin)
                if required_margin is not None
                else 0.0
            )

            if (
                required_margin is not None
                and required_margin_value > 0
                and required_margin_value <= spendable
            ):
                final_risk = self.risk_money(
                    side,
                    lot,
                    price,
                    sl,
                )
                projected_free_margin = max(
                    0.0,
                    free_margin - required_margin_value,
                )

                return lot, {
                    "reason": "OK",
                    "risk_amount": final_risk,
                    "strength": strength,
                    "strength_cap": cap,
                    "lot_by_risk": lot_by_risk,
                    "scenario_budget": scenario_budget,
                    "scenario_used": scenario_used,
                    "portfolio_budget": portfolio_budget,
                    "portfolio_used": portfolio_used,
                    "balance_before": balance,
                    "equity_before": equity,
                    "risk_base": risk_base,
                    "margin_before": margin,
                    "free_margin_before": free_margin,
                    "required_margin": required_margin_value,
                    "projected_free_margin": projected_free_margin,
                    "reserve_required": reserve,
                }

            lot = self.floor_volume(
                lot - vstep,
                vmin,
                vmax,
                vstep,
            )

            if lot <= 0:
                break

        return 0.0, {
            "reason": "NOT_ENOUGH_SAFE_MARGIN",
            "balance_before": balance,
            "equity_before": equity,
            "margin_before": margin,
            "free_margin_before": free_margin,
            "reserve_required": reserve,
            "strength_cap": cap,
        }

    # ========================================================
    # ENTRY CONDITIONS
    # ========================================================

    def confirmation_hit(self, candidate, tick):
        confirm = num(
            candidate["confirmation_price"]
        )

        side = str(
            candidate["side"]
        ).upper()

        if side == "BUY":
            return num(tick.ask) >= confirm

        return num(tick.bid) <= confirm

    def effective_invalidation_price(self, candidate):
        # Новое правило использует плановый SL как структурную границу.
        # Это также исправляет уже созданные кандидаты со старой близкой
        # invalidation_price, не меняя SL открытых позиций.
        sl = num(candidate.get("sl"))
        if sl > 0:
            return sl

        return num(candidate.get("invalidation_price"))

    def scenario_cancellation_reason(self, candidate, latest):
        """Отмена только по НОВОЙ закрытой свече/смене направления."""
        if not latest or not self.analysis_is_newer(candidate, latest):
            return None

        action = str(latest.get("action") or "").upper()
        direction = str(latest.get("direction") or "").upper()
        strength = integer(latest.get("strength"))
        side = str(candidate.get("side") or "").upper()

        if action == "WAIT" or strength < 60:
            return "FRESH_WAIT_OR_BELOW_60"

        if direction != side:
            return "DIRECTION_CHANGED"

        invalidation = self.effective_invalidation_price(candidate)
        close_price = num(latest.get("analysis_price"))

        if invalidation <= 0 or close_price <= 0:
            return None

        if side == "BUY" and close_price <= invalidation:
            return "CLOSED_TF_BELOW_INVALIDATION"

        if side == "SELL" and close_price >= invalidation:
            return "CLOSED_TF_ABOVE_INVALIDATION"

        return None

    def current_price(self, side, tick):
        return (
            num(tick.ask)
            if str(side).upper() == "BUY"
            else num(tick.bid)
        )

    def slot_allowed(
        self,
        candidate,
        slot_no,
        tick,
        profile,
    ):
        if slot_no <= int(
            profile["initial_slots"]
        ):
            return True

        confirm = num(
            candidate["confirmation_price"]
        )

        tp1 = num(
            candidate["tp1"]
        )

        side = str(
            candidate["side"]
        ).upper()

        price = self.current_price(
            side,
            tick,
        )

        reference = abs(
            tp1 - confirm
        )

        if reference <= 0:
            reference = (
                abs(
                    confirm
                    - num(candidate["sl"])
                )
                * 0.5
            )

        reference = max(
            reference,
            0.01,
        )

        if side == "BUY":
            progress = max(
                0.0,
                price - confirm,
            )
        else:
            progress = max(
                0.0,
                confirm - price,
            )

        add_number = (
            slot_no
            - int(profile["initial_slots"])
        )

        required = (
            reference
            * profile["add_step_ratio"]
            * add_number
        )

        return progress >= required

    def last_entry_age(self, candidate_id):
        conn = self.connect()

        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT MAX(opened_at)
                    FROM demo_trades
                    WHERE candidate_id = %s
                    """,
                    (int(candidate_id),),
                )

                row = cur.fetchone()
        finally:
            conn.close()

        opened_at = (
            row[0]
            if row
            else None
        )

        if not opened_at:
            return float("inf")

        if opened_at.tzinfo is None:
            opened_at = opened_at.replace(
                tzinfo=timezone.utc
            )

        return max(
            0.0,
            (
                utcnow()
                - opened_at
            ).total_seconds(),
        )

    def tp_for_slot(
        self,
        candidate,
        slot_no,
    ):
        tp1 = num(candidate["tp1"])
        tp2 = num(candidate["tp2"])
        tp3 = num(candidate["tp3"])

        if slot_no == 1:
            return tp1 or tp2 or tp3

        if slot_no <= 3:
            return tp2 or tp1 or tp3

        return tp3 or tp2 or tp1

    # ========================================================
    # ORDER HELPERS
    # ========================================================

    def matching_position_tickets(self, side):
        positions = self.mt5.positions_get(
            symbol=self.symbol
        )

        if positions is None:
            return set()

        expected = (
            self.mt5.POSITION_TYPE_BUY
            if str(side).upper() == "BUY"
            else self.mt5.POSITION_TYPE_SELL
        )

        tickets = set()

        for position in positions:
            if integer(
                getattr(position, "type", -1),
                -1,
            ) != integer(
                expected,
                -2,
            ):
                continue

            magic = integer(
                getattr(position, "magic", 0),
                0,
            )

            if magic != self.magic:
                continue

            ticket = integer(
                getattr(position, "ticket", 0),
                0,
            )

            if ticket:
                tickets.add(ticket)

        return tickets

    def insert_pending_trade(
        self,
        candidate,
        lot,
        price,
        tp,
        account,
        mode,
        slot_no,
        risk_meta,
    ):
        conn = self.connect()

        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO demo_trades(
                        candidate_id,
                        analysis_id,
                        symbol,
                        timeframe,
                        side,
                        lot,
                        planned_price,
                        sl,
                        tp,
                        tp1,
                        tp2,
                        tp3,
                        status,
                        demo_account,
                        payload
                    )
                    VALUES(
                        %s,%s,%s,%s,%s,
                        %s,%s,
                        %s,%s,%s,%s,%s,
                        'PENDING',%s,%s
                    )
                    RETURNING id
                    """,
                    (
                        int(candidate["id"]),
                        int(candidate["analysis_id"]),
                        self.symbol,
                        str(candidate["timeframe"]),
                        str(
                            candidate["side"]
                        ).upper(),
                        float(lot),
                        float(price),
                        num(
                            candidate["sl"]
                        ) or None,
                        tp or None,
                        num(
                            candidate["tp1"]
                        ) or None,
                        num(
                            candidate["tp2"]
                        ) or None,
                        num(
                            candidate["tp3"]
                        ) or None,
                        str(
                            getattr(
                                account,
                                "login",
                                "",
                            )
                        ),
                        Json(
                            {
                                "risk_mode": mode,
                                "slot_no": slot_no,
                                **risk_meta,
                            }
                        ),
                    ),
                )

                return int(
                    cur.fetchone()[0]
                )
        finally:
            conn.close()

    def mark_open(
        self,
        trade_id,
        ticket,
        entry,
        planned_price,
        extra_payload,
    ):
        slippage = (
            num(entry)
            - num(planned_price)
        )

        conn = self.connect()

        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE demo_trades
                    SET
                        opened_at = NOW(),
                        entry_price = %s,
                        mt5_ticket = %s,
                        slippage = %s,
                        status = 'OPEN',
                        payload =
                            COALESCE(
                                payload,
                                '{}'::jsonb
                            )
                            || %s::jsonb
                    WHERE id = %s
                      AND status = 'PENDING'
                    """,
                    (
                        float(entry),
                        str(ticket),
                        float(slippage),
                        json.dumps(
                            extra_payload
                            or {}
                        ),
                        int(trade_id),
                    ),
                )
        finally:
            conn.close()

    def reject_trade(
        self,
        trade_id,
        reason,
        details=None,
    ):
        conn = self.connect()

        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE demo_trades
                    SET
                        status = 'REJECTED',
                        close_reason = %s,
                        payload =
                            COALESCE(
                                payload,
                                '{}'::jsonb
                            )
                            || %s::jsonb
                    WHERE id = %s
                      AND status = 'PENDING'
                    """,
                    (
                        str(reason)[:40],
                        json.dumps(
                            details
                            or {}
                        ),
                        int(trade_id),
                    ),
                )
        finally:
            conn.close()

    def fill_modes(self):
        modes = []

        info = self.mt5.symbol_info(
            self.symbol
        )

        preferred = [
            getattr(
                self.mt5,
                "ORDER_FILLING_IOC",
                None,
            ),
            getattr(
                self.mt5,
                "ORDER_FILLING_FOK",
                None,
            ),
            getattr(
                self.mt5,
                "ORDER_FILLING_RETURN",
                None,
            ),
        ]

        if info is not None:
            broker_mode = getattr(
                info,
                "filling_mode",
                None,
            )

            if broker_mode is not None:
                preferred.insert(
                    0,
                    broker_mode,
                )

        for mode in preferred:
            if (
                mode is not None
                and mode not in modes
            ):
                modes.append(mode)

        return modes

    def send_order(
        self,
        candidate,
        tick,
        account,
        lot,
        mode,
        slot_no,
        risk_meta,
    ):
        self.assert_demo(account)

        side = str(
            candidate["side"]
        ).upper()

        price = self.current_price(
            side,
            tick,
        )

        sl = num(
            candidate["sl"]
        )

        tp = self.tp_for_slot(
            candidate,
            slot_no,
        )

        if (
            side not in {"BUY", "SELL"}
            or lot <= 0
            or price <= 0
            or sl <= 0
            or tp <= 0
        ):
            return False

        trade_id = self.insert_pending_trade(
            candidate,
            lot,
            price,
            tp,
            account,
            mode,
            slot_no,
            risk_meta,
        )

        before = self.matching_position_tickets(
            side
        )

        accepted = {
            integer(
                getattr(
                    self.mt5,
                    "TRADE_RETCODE_DONE",
                    10009,
                )
            ),
            integer(
                getattr(
                    self.mt5,
                    "TRADE_RETCODE_DONE_PARTIAL",
                    10010,
                )
            ),
            integer(
                getattr(
                    self.mt5,
                    "TRADE_RETCODE_PLACED",
                    10008,
                )
            ),
        }

        last_details = {
            "stage": "not_sent"
        }

        for filling in self.fill_modes():
            request = {
                "action":
                    self.mt5.TRADE_ACTION_DEAL,
                "symbol":
                    self.symbol,
                "volume":
                    float(lot),
                "type":
                    self.order_type(side),
                "price":
                    float(price),
                "sl":
                    float(sl),
                "tp":
                    float(tp),
                "deviation":
                    int(self.deviation),
                "magic":
                    int(self.magic),
                "comment":
                    f"XAUDEMO c{candidate['id']} s{slot_no}"[:31],
                "type_time":
                    self.mt5.ORDER_TIME_GTC,
                "type_filling":
                    filling,
            }

            check = self.mt5.order_check(
                request
            )

            if check is None:
                last_details = {
                    "stage": "order_check",
                    "error": str(
                        self.mt5.last_error()
                    ),
                    "filling": filling,
                }
                continue

            check_retcode = integer(
                getattr(
                    check,
                    "retcode",
                    -1,
                ),
                -1,
            )

            check_ok = {
                0,
                integer(
                    getattr(
                        self.mt5,
                        "TRADE_RETCODE_DONE",
                        10009,
                    )
                ),
            }

            if check_retcode not in check_ok:
                last_details = {
                    "stage": "order_check",
                    "retcode": check_retcode,
                    "comment": str(
                        getattr(
                            check,
                            "comment",
                            "",
                        )
                    ),
                    "filling": filling,
                }
                continue

            result = self.mt5.order_send(
                request
            )

            if result is None:
                last_details = {
                    "stage": "order_send",
                    "error": str(
                        self.mt5.last_error()
                    ),
                    "filling": filling,
                }
                continue

            retcode = integer(
                getattr(
                    result,
                    "retcode",
                    -1,
                ),
                -1,
            )

            if retcode not in accepted:
                last_details = {
                    "stage": "order_send",
                    "retcode": retcode,
                    "comment": str(
                        getattr(
                            result,
                            "comment",
                            "",
                        )
                    ),
                    "filling": filling,
                }
                continue

            time.sleep(0.2)

            after = self.matching_position_tickets(
                side
            )

            new_tickets = list(
                after - before
            )

            ticket = (
                new_tickets[0]
                if new_tickets
                else integer(
                    getattr(
                        result,
                        "order",
                        0,
                    )
                    or getattr(
                        result,
                        "deal",
                        0,
                    )
                )
            )

            entry = num(
                getattr(
                    result,
                    "price",
                    0.0,
                ),
                price,
            )

            if entry <= 0:
                entry = price

            self.mark_open(
                trade_id,
                ticket,
                entry,
                price,
                {
                    "order_id": str(
                        getattr(
                            result,
                            "order",
                            "",
                        )
                    ),
                    "deal_id": str(
                        getattr(
                            result,
                            "deal",
                            "",
                        )
                    ),
                    "retcode": retcode,
                    "filling": filling,
                },
            )

            self.update_candidate_status(
                candidate["id"],
                "ACTIVE",
            )

            self.event(
                "TRADE_OPENED",
                candidate["id"],
                trade_id,
                {
                    "side": side,
                    "lot": lot,
                    "slot_no": slot_no,
                    "risk_mode": mode,
                    "entry": entry,
                    "sl": sl,
                    "tp": tp,
                    "risk_amount":
                        risk_meta.get(
                            "risk_amount"
                        ),
                    "ticket":
                        str(ticket),
                },
            )

            log.info(
                "OPEN %s %s lot=%.2f slot=%s entry=%.2f SL=%.2f TP=%.2f mode=%s",
                self.symbol,
                side,
                lot,
                slot_no,
                entry,
                sl,
                tp,
                mode,
            )

            return True

        self.reject_trade(
            trade_id,
            "ORDER_REJECTED",
            last_details,
        )

        self.event(
            "ORDER_REJECTED",
            candidate["id"],
            trade_id,
            last_details,
        )

        return False

    # ========================================================
    # MAIN STEP
    # ========================================================

    def step(self, tick, account):
        self.assert_demo(account)

        mode, profile = self.risk_mode()

        safe, reason = (
            self.account_allows_new_trade(
                account,
                profile,
            )
        )

        if not safe:
            if (
                time.monotonic()
                - self.last_status_write
                >= 30
            ):
                self.set_setting(
                    "demo_trader_status",
                    f"PAUSED|{mode}|{reason}",
                )

                self.last_status_write = (
                    time.monotonic()
                )

            return

        candidates = self.load_candidates()
        latest_analyses = (
            self.load_latest_analyses()
            if candidates
            else {}
        )

        for candidate in candidates:
            cid = int(
                candidate["id"]
            )

            strength = integer(
                candidate["strength"]
            )

            if strength < 60:
                self.update_candidate_status(
                    cid,
                    "NO_ENTRY",
                )
                continue

            expires_at = (
                candidate.get(
                    "expires_at"
                )
            )

            if expires_at:
                if expires_at.tzinfo is None:
                    expires_at = (
                        expires_at.replace(
                            tzinfo=timezone.utc
                        )
                    )

                if utcnow() >= expires_at:
                    if not self.candidate_trades(
                        cid,
                        open_only=True,
                    ):
                        self.update_candidate_status(
                            cid,
                            "EXPIRED",
                        )
                    continue

            open_trades = self.candidate_trades(
                cid,
                open_only=True,
            )

            latest = latest_analyses.get(
                str(candidate["timeframe"]).upper()
            )

            cancel_reason = (
                None
                if open_trades
                else self.scenario_cancellation_reason(
                    candidate,
                    latest,
                )
            )

            if cancel_reason:
                self.update_candidate_status(
                    cid,
                    "CANCELLED",
                )

                latest_candle = (
                    latest.get("candle_time")
                    if latest
                    else None
                )

                self.event(
                    "SCENARIO_CANCELLED",
                    cid,
                    payload={
                        "reason": cancel_reason,
                        "timeframe": candidate["timeframe"],
                        "side": candidate["side"],
                        "closed_candle": (
                            latest_candle.isoformat()
                            if hasattr(latest_candle, "isoformat")
                            else None
                        ),
                        "closed_price": (
                            num(latest.get("analysis_price"))
                            if latest
                            else None
                        ),
                        "invalidation_price":
                            self.effective_invalidation_price(
                                candidate
                            ),
                    },
                )

                log.info(
                    "CANCEL %s %s %s | reason=%s | close=%.2f | level=%.2f",
                    candidate["timeframe"],
                    candidate["side"],
                    cid,
                    cancel_reason,
                    num(latest.get("analysis_price")) if latest else 0.0,
                    self.effective_invalidation_price(candidate),
                )
                continue

            if (
                candidate["status"]
                == "WAIT_CONFIRMATION"
            ):
                if not self.confirmation_hit(
                    candidate,
                    tick,
                ):
                    continue

                self.update_candidate_status(
                    cid,
                    "CONFIRMED",
                )

                candidate[
                    "status"
                ] = "CONFIRMED"

            allowed, guard_reason = (
                self.latest_analysis_allows_add(
                    candidate,
                    latest,
                )
            )

            if not allowed:
                self.event(
                    "ADD_BLOCKED",
                    cid,
                    payload={
                        "reason":
                            guard_reason
                    },
                )
                continue

            created = self.candidate_trades(
                cid,
                open_only=False,
            )

            max_positions = min(
                5,
                int(
                    profile[
                        "max_positions"
                    ]
                ),
            )

            if len(created) >= max_positions:
                continue

            slot_no = len(created) + 1

            if not self.slot_allowed(
                candidate,
                slot_no,
                tick,
                profile,
            ):
                continue

            if self.last_entry_age(
                cid
            ) < int(
                profile[
                    "min_entry_gap_sec"
                ]
            ):
                continue

            side = str(
                candidate["side"]
            ).upper()

            price = self.current_price(
                side,
                tick,
            )

            lot, risk_meta = (
                self.choose_volume(
                    candidate,
                    account,
                    profile,
                    price,
                )
            )

            if lot <= 0:
                self.event(
                    "ENTRY_SKIPPED",
                    cid,
                    payload={
                        "slot_no": slot_no,
                        "risk_mode": mode,
                        **risk_meta,
                    },
                )
                continue

            if self.send_order(
                candidate,
                tick,
                account,
                lot,
                mode,
                slot_no,
                risk_meta,
            ):
                # Только одна новая позиция за один проход.
                # Следующая проверяется заново worker.py.
                break

        if (
            time.monotonic()
            - self.last_status_write
            >= 30
        ):
            self.set_setting(
                "demo_trader_status",
                (
                    f"READY|{mode}|"
                    f"equity={num(account.equity):.2f}|"
                    f"free_margin={num(account.margin_free):.2f}"
                ),
            )

            self.last_status_write = (
                time.monotonic()
            )

    # ========================================================
    # CLOSED TRADES
    # ========================================================

    def open_trades_for_sync(self):
        conn = self.connect()

        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT
                        id,
                        candidate_id,
                        opened_at,
                        side,
                        lot,
                        entry_price,
                        sl,
                        tp,
                        mt5_ticket,
                        payload
                    FROM demo_trades
                    WHERE symbol = %s
                      AND status = 'OPEN'
                      AND mt5_ticket IS NOT NULL
                    ORDER BY opened_at ASC
                    """,
                    (self.symbol,),
                )

                names = [
                    d[0]
                    for d in cur.description
                ]

                return [
                    dict(
                        zip(
                            names,
                            row,
                        )
                    )
                    for row in cur.fetchall()
                ]
        finally:
            conn.close()

    def mark_closed(
        self,
        trade,
        closed_at,
        exit_price,
        profit,
        reason,
    ):
        conn = self.connect()

        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE demo_trades
                    SET
                        closed_at = %s,
                        exit_price = %s,
                        profit = %s,
                        status = 'CLOSED',
                        close_reason = %s
                    WHERE id = %s
                      AND status = 'OPEN'
                    """,
                    (
                        closed_at,
                        exit_price,
                        profit,
                        str(reason)[:40],
                        int(trade["id"]),
                    ),
                )
        finally:
            conn.close()

        self.event(
            "TRADE_CLOSED",
            trade.get(
                "candidate_id"
            ),
            trade.get("id"),
            {
                "exit_price":
                    exit_price,
                "profit":
                    profit,
                "reason":
                    reason,
            },
        )

    def position_still_open(self, ticket):
        if not ticket:
            return False

        positions = self.mt5.positions_get(
            ticket=integer(
                ticket,
                0,
            )
        )

        return bool(positions)

    def infer_close_reason(
        self,
        trade,
        exit_price,
    ):
        side = str(
            trade.get(
                "side",
                ""
            )
        ).upper()

        sl = num(
            trade.get("sl")
        )

        tp = num(
            trade.get("tp")
        )

        tolerance = max(
            0.05,
            abs(
                num(exit_price)
            )
            * 0.00002,
        )

        if side == "BUY":
            if (
                sl > 0
                and num(exit_price)
                <= sl + tolerance
            ):
                return "SL"

            if (
                tp > 0
                and num(exit_price)
                >= tp - tolerance
            ):
                return "TP"

        if side == "SELL":
            if (
                sl > 0
                and num(exit_price)
                >= sl - tolerance
            ):
                return "SL"

            if (
                tp > 0
                and num(exit_price)
                <= tp + tolerance
            ):
                return "TP"

        return "MT5_CLOSED"

    def sync_closed_trades(self):
        trades = self.open_trades_for_sync()

        if not trades:
            return 0

        synced = 0

        for trade in trades:
            ticket = integer(
                trade.get(
                    "mt5_ticket"
                ),
                0,
            )

            if ticket and self.position_still_open(
                ticket
            ):
                continue

            opened_at = trade.get(
                "opened_at"
            )

            if opened_at is None:
                opened_at = (
                    utcnow()
                    - timedelta(days=1)
                )

            if opened_at.tzinfo is None:
                opened_at = opened_at.replace(
                    tzinfo=timezone.utc
                )

            date_from = (
                opened_at
                - timedelta(minutes=5)
            )

            date_to = (
                utcnow()
                + timedelta(minutes=1)
            )

            deals = self.mt5.history_deals_get(
                date_from,
                date_to,
            )

            if deals is None:
                log.warning(
                    "history_deals_get: %s",
                    self.mt5.last_error(),
                )
                continue

            matching = []

            for deal in deals:
                if str(
                    getattr(
                        deal,
                        "symbol",
                        "",
                    )
                ) != self.symbol:
                    continue

                magic = integer(
                    getattr(
                        deal,
                        "magic",
                        0,
                    ),
                    0,
                )

                if magic != self.magic:
                    continue

                position_id = integer(
                    getattr(
                        deal,
                        "position_id",
                        0,
                    ),
                    0,
                )

                order_id = integer(
                    getattr(
                        deal,
                        "order",
                        0,
                    ),
                    0,
                )

                deal_ticket = integer(
                    getattr(
                        deal,
                        "ticket",
                        0,
                    ),
                    0,
                )

                if ticket and ticket not in {
                    position_id,
                    order_id,
                    deal_ticket,
                }:
                    continue

                matching.append(
                    deal
                )

            if not matching:
                continue

            matching.sort(
                key=lambda d: (
                    integer(
                        getattr(
                            d,
                            "time_msc",
                            0,
                        ),
                        0,
                    ),
                    integer(
                        getattr(
                            d,
                            "ticket",
                            0,
                        ),
                        0,
                    ),
                )
            )

            exit_deal = matching[-1]

            exit_price = num(
                getattr(
                    exit_deal,
                    "price",
                    0.0,
                )
            )

            profit = sum(
                num(
                    getattr(
                        deal,
                        "profit",
                        0.0,
                    )
                )
                + num(
                    getattr(
                        deal,
                        "swap",
                        0.0,
                    )
                )
                + num(
                    getattr(
                        deal,
                        "commission",
                        0.0,
                    )
                )
                for deal in matching
            )

            time_msc = integer(
                getattr(
                    exit_deal,
                    "time_msc",
                    0,
                ),
                0,
            )

            if time_msc > 0:
                closed_at = datetime.fromtimestamp(
                    time_msc / 1000.0,
                    tz=timezone.utc,
                )
            else:
                closed_at = utcnow()

            reason = self.infer_close_reason(
                trade,
                exit_price,
            )

            self.mark_closed(
                trade,
                closed_at,
                exit_price,
                profit,
                reason,
            )

            synced += 1

            log.info(
                "CLOSED trade=%s ticket=%s exit=%.2f profit=%.2f reason=%s",
                trade["id"],
                ticket,
                exit_price,
                profit,
                reason,
            )

        return synced

    # ========================================================
    # SHUTDOWN
    # ========================================================

    def close(self):
        try:
            self.set_setting(
                "demo_trader_status",
                "STOPPED",
            )
        except Exception:
            pass
