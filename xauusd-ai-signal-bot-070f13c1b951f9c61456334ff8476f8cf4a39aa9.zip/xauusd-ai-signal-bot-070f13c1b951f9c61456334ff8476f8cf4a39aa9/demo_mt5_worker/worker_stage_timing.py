from __future__ import annotations

import functools
import os
import time
from collections import defaultdict, deque
from contextlib import contextmanager
from dataclasses import dataclass
from math import ceil
from typing import Callable, Deque, Dict, Iterable, Optional


@dataclass(frozen=True)
class StageStats:
    stage: str
    count: int
    p50_ms: float
    p95_ms: float
    max_ms: float


def _percentile(values: Iterable[float], q: float) -> float:
    ordered = sorted(float(value) for value in values)
    if not ordered:
        return 0.0
    if len(ordered) == 1:
        return ordered[0]
    q = min(1.0, max(0.0, float(q)))
    position = (len(ordered) - 1) * q
    low = int(position)
    high = min(len(ordered) - 1, ceil(position))
    if low == high:
        return ordered[low]
    weight = position - low
    return ordered[low] * (1.0 - weight) + ordered[high] * weight


class WorkerStageTimingObserver:
    """In-memory/stdout timing only; never writes timing rows to PostgreSQL.

    The observer is deliberately independent from trading decisions. It records
    elapsed wall-clock durations using a monotonic performance clock and emits
    bounded structured text. Exceptions from the wrapped operation are never
    caught or replaced; the ``finally`` path only records elapsed time.
    """

    def __init__(
        self,
        *,
        clock_ns: Callable[[], int] = time.perf_counter_ns,
        window_size: int = 240,
        summary_interval_seconds: float = 30.0,
        slow_stage_ms: float = 1_000.0,
        slow_cycle_ms: float = 5_000.0,
        slow_log_interval_seconds: float = 30.0,
        emit: Callable[[str], None] = print,
    ):
        if int(window_size) < 2:
            raise ValueError("window_size must be >= 2")
        if float(summary_interval_seconds) <= 0:
            raise ValueError("summary_interval_seconds must be > 0")
        if float(slow_stage_ms) <= 0 or float(slow_cycle_ms) <= 0:
            raise ValueError("slow thresholds must be > 0")
        if float(slow_log_interval_seconds) <= 0:
            raise ValueError("slow_log_interval_seconds must be > 0")

        self.clock_ns = clock_ns
        self.window_size = int(window_size)
        self.summary_interval_seconds = float(summary_interval_seconds)
        self.slow_stage_ms = float(slow_stage_ms)
        self.slow_cycle_ms = float(slow_cycle_ms)
        self.slow_log_interval_seconds = float(slow_log_interval_seconds)
        self.emit = emit
        self._samples: Dict[str, Deque[float]] = defaultdict(
            lambda: deque(maxlen=self.window_size)
        )
        self._last_summary_ns: Optional[int] = None
        self._last_loop_start_ns: Optional[int] = None
        self._last_slow_log_ns: Dict[str, int] = {}
        self._suppressed_slow_logs: Dict[str, int] = defaultdict(int)

    def record_ms(self, stage: str, elapsed_ms: float) -> None:
        name = str(stage or "unknown").strip() or "unknown"
        value = max(0.0, float(elapsed_ms))
        self._samples[name].append(value)
        threshold = self.slow_cycle_ms if name == "loop_cycle_start_to_start" else self.slow_stage_ms
        if value < threshold:
            return

        now_ns = self.clock_ns()
        last_ns = self._last_slow_log_ns.get(name)
        due = (
            last_ns is None
            or (now_ns - last_ns) / 1_000_000_000.0 >= self.slow_log_interval_seconds
        )
        if not due:
            self._suppressed_slow_logs[name] += 1
            return

        suppressed = self._suppressed_slow_logs.pop(name, 0)
        self._last_slow_log_ns[name] = now_ns
        self.emit(
            f"[WORKER TIMING] SLOW | stage={name} | elapsed_ms={value:.3f} | "
            f"threshold_ms={threshold:.3f} | suppressed_since_last={suppressed}"
        )

    @contextmanager
    def stage(self, stage: str):
        start = self.clock_ns()
        try:
            yield
        finally:
            elapsed_ms = (self.clock_ns() - start) / 1_000_000.0
            self.record_ms(stage, elapsed_ms)

    def timed_call(self, stage: str, func: Callable, *args, **kwargs):
        with self.stage(stage):
            return func(*args, **kwargs)

    def mark_loop_start(self) -> None:
        """Record start-to-start cadence at the outer ensure-connection boundary.

        This includes normal worker sleep and any reconnect/error delay between two
        calls to ``ensure_mt5_connection``. It is therefore a cycle/cadence metric,
        not a pure CPU/work-time metric.
        """

        now_ns = self.clock_ns()
        if self._last_loop_start_ns is not None:
            self.record_ms(
                "loop_cycle_start_to_start",
                (now_ns - self._last_loop_start_ns) / 1_000_000.0,
            )
        self._last_loop_start_ns = now_ns
        self.maybe_emit_summary(now_ns=now_ns)

    def stats(self, stage: str) -> StageStats:
        values = list(self._samples.get(stage, ()))
        return StageStats(
            stage=str(stage),
            count=len(values),
            p50_ms=_percentile(values, 0.50),
            p95_ms=_percentile(values, 0.95),
            max_ms=max(values) if values else 0.0,
        )

    def snapshot(self) -> list[StageStats]:
        return [self.stats(stage) for stage in sorted(self._samples)]

    def maybe_emit_summary(self, *, now_ns: Optional[int] = None, force: bool = False) -> bool:
        now_ns = self.clock_ns() if now_ns is None else int(now_ns)
        if self._last_summary_ns is None:
            self._last_summary_ns = now_ns
            return False
        elapsed = (now_ns - self._last_summary_ns) / 1_000_000_000.0
        if not force and elapsed < self.summary_interval_seconds:
            return False
        rows = self.snapshot()
        if rows:
            payload = " ; ".join(
                f"{row.stage}:n={row.count},p50={row.p50_ms:.3f},p95={row.p95_ms:.3f},max={row.max_ms:.3f}ms"
                for row in rows
            )
            self.emit(
                f"[WORKER TIMING] SUMMARY | window={self.window_size} | {payload}"
            )
        self._last_summary_ns = now_ns
        return bool(rows)


def _env_flag(name: str, default: str = "0") -> bool:
    return str(os.getenv(name, default)).strip().lower() in {"1", "true", "yes", "on"}


def build_observer_from_env(*, emit: Callable[[str], None] = print) -> WorkerStageTimingObserver:
    return WorkerStageTimingObserver(
        window_size=max(20, int(os.getenv("WORKER_TIMING_WINDOW", "240"))),
        summary_interval_seconds=max(
            5.0, float(os.getenv("WORKER_TIMING_SUMMARY_SECONDS", "30"))
        ),
        slow_stage_ms=max(10.0, float(os.getenv("WORKER_TIMING_SLOW_STAGE_MS", "1000"))),
        slow_cycle_ms=max(100.0, float(os.getenv("WORKER_TIMING_SLOW_CYCLE_MS", "5000"))),
        slow_log_interval_seconds=max(
            5.0, float(os.getenv("WORKER_TIMING_SLOW_LOG_INTERVAL_SECONDS", "30"))
        ),
        emit=emit,
    )


def _wrap_function(obj, name: str, stage: str, observer: WorkerStageTimingObserver, *, loop_start: bool = False):
    """Wrap module callables or normal class instance methods.

    When ``obj`` is a class, assigning this plain wrapper function to the class is
    descriptor-safe for the targeted normal instance methods: Python binds the
    wrapper to the eventual instance and passes ``self`` as the first argument.
    The wrapper then invokes the original function with the same argument tuple.
    No staticmethod/classmethod targets are used by this instrumentation.
    """

    original = getattr(obj, name)
    if getattr(original, "_worker_timing_wrapped", False):
        return False

    @functools.wraps(original)
    def wrapped(*args, **kwargs):
        if loop_start:
            observer.mark_loop_start()
        return observer.timed_call(stage, original, *args, **kwargs)

    wrapped._worker_timing_wrapped = True  # type: ignore[attr-defined]
    wrapped._worker_timing_original = original  # type: ignore[attr-defined]
    setattr(obj, name, wrapped)
    return True


def _wrap_state_writer(core, observer: WorkerStageTimingObserver):
    original = core.save_worker_state
    if getattr(original, "_worker_timing_wrapped", False):
        return False

    @functools.wraps(original)
    def wrapped(key, value):
        safe_key = str(key or "unknown").strip().lower().replace(" ", "_")[:60]
        return observer.timed_call(f"save_worker_state.{safe_key}", original, key, value)

    wrapped._worker_timing_wrapped = True  # type: ignore[attr-defined]
    wrapped._worker_timing_original = original  # type: ignore[attr-defined]
    core.save_worker_state = wrapped
    return True


def install_worker_timing(auto_module, *, enabled: Optional[bool] = None, observer: Optional[WorkerStageTimingObserver] = None):
    """Install diagnostic wrappers after watchdog guards have been installed.

    This function changes no return values, arguments, call order, exception flow,
    trade decisions, or order APIs. It only wraps existing calls with monotonic
    timers and bounded stdout/in-memory aggregation.

    Timing is intentionally nested in places. For example, ``trader_step`` may
    contain several ``trader_db_connect`` samples, and ``candle_sync`` can contain
    worker DB/state-write samples. Those values must not be summed as disjoint
    durations; nesting is useful for locating which sub-operation dominates a
    slow outer stage.
    """

    if enabled is None:
        enabled = _env_flag("WORKER_TIMING_ENABLED", "0")
    if not enabled:
        return None

    existing = getattr(auto_module, "_worker_stage_timing_observer", None)
    if existing is not None:
        return existing

    observer = observer or build_observer_from_env()
    core = auto_module.core

    # Outer-loop stage boundaries. In worker_watchdog_v2 this installer is called
    # only after stale-feed guards replace save_quote/classify_market_state, so the
    # final guarded runtime paths are what get timed.
    _wrap_function(core, "ensure_mt5_connection", "ensure_mt5_connection", observer, loop_start=True)
    _wrap_function(core, "get_tick", "get_tick", observer)
    _wrap_function(core, "save_quote", "save_quote", observer)
    _wrap_function(core, "save_closed_m1_rates", "candle_sync", observer)
    _wrap_function(auto_module, "classify_market_state", "classify_market_state", observer)
    _wrap_function(core, "cleanup_old_quotes", "cleanup_old_quotes", observer)

    # worker.py functions resolve db_connect through their module global at call
    # time. No _original_db_connect alias exists in the current source, so replacing
    # core.db_connect here captures subsequent worker DB connection attempts.
    _wrap_function(core, "db_connect", "worker_db_connect", observer)
    _wrap_state_writer(core, observer)

    # DemoTrader is the canonical V9HardenedV6 class alias. These targets are
    # normal instance methods (possibly inherited). Assigning the wrapper to the
    # subclass keeps normal descriptor binding; tests exercise a real bound-method
    # shape before merge.
    trader_cls = core.DemoTrader
    _wrap_function(trader_cls, "connect", "trader_db_connect", observer)
    _wrap_function(trader_cls, "step", "trader_step", observer)
    _wrap_function(trader_cls, "sync_closed_trades", "sync_closed_trades", observer)

    # Deliberately no wrapping of mt5.order_send/order_check or any order API.
    auto_module._worker_stage_timing_observer = observer
    observer.emit(
        "[WORKER TIMING] ACTIVE | diagnostics_only=YES | db_writes=NO | order_logic_change=NO"
    )
    return observer
