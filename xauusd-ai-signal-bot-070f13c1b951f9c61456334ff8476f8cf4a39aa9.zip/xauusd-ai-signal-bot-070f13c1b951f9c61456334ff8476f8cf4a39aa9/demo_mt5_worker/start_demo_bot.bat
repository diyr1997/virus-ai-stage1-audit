@echo off
setlocal
cd /d "%~dp0"

if not exist config_private.bat goto NO_CONFIG
call config_private.bat

py -3 windows_launcher.py
if not errorlevel 9009 goto END
python windows_launcher.py
if not errorlevel 9009 goto END

echo [ERROR] Python not found.
goto HOLD

:NO_CONFIG
echo [ERROR] config_private.bat not found.
goto HOLD

:END
set EXIT_CODE=%errorlevel%
if "%EXIT_CODE%"=="0" exit /b 0
echo [ERROR] Launcher exited with code %EXIT_CODE%.

:HOLD
pause
exit /b 1
