from __future__ import annotations

from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
WORKER_AUTO = ROOT / "worker_auto.py"
LAUNCHER = ROOT / "windows_launcher.py"


class WorkerAutoWatchdogSourceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.worker = WORKER_AUTO.read_text(encoding="utf-8-sig")
        cls.launcher = LAUNCHER.read_text(encoding="utf-8-sig")

    def test_launcher_restarts_nonzero_worker_exit(self) -> None:
        # The restart-on-nonzero-exit loop moved from a start_demo_bot.bat
        # :RUN_WORKER/goto label into windows_launcher.py's worker_loop(),
        # which now runs worker_watchdog_v2.py (a wrapper around
        # worker_auto.py) in a subprocess restart loop.
        self.assertIn("def worker_loop()", self.launcher)
        self.assertIn('worker = ROOT / "worker_watchdog_v2.py"', self.launcher)
        self.assertIn("if code == 0:", self.launcher)
        self.assertIn("restarting in 10 seconds", self.launcher)
        self.assertIn("while True:", self.launcher)

    def test_auto_worker_has_bounded_fatal_watchdog(self) -> None:
        self.assertIn("WORKER_FATAL_ERROR_LIMIT", self.worker)
        self.assertIn("WORKER_FATAL_EXIT_CODE", self.worker)
        self.assertIn("def _force_launcher_restart", self.worker)
        self.assertIn("raise SystemExit(WORKER_FATAL_EXIT_CODE)", self.worker)

    def test_connection_and_runtime_failures_are_counted(self) -> None:
        self.assertGreaterEqual(
            self.worker.count("consecutive_connection_errors += 1"),
            2,
        )
        self.assertIn("consecutive_runtime_errors += 1", self.worker)
        self.assertIn("consecutive_connection_errors = 0", self.worker)
        self.assertIn("consecutive_runtime_errors = 0", self.worker)

    def test_watchdog_marks_restart_in_worker_state(self) -> None:
        self.assertIn('"worker_watchdog"', self.worker)
        self.assertIn('"restart_requested": True', self.worker)
        self.assertIn('"alive": False', self.worker)


if __name__ == "__main__":
    unittest.main()
