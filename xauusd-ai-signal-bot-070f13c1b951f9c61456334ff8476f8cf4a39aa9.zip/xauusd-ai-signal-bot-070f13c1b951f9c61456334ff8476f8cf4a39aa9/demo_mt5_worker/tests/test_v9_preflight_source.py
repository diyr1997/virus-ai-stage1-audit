from __future__ import annotations

from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
DIAG = ROOT / "diagnose_v9.py"
DIAG_BAT = ROOT / "diagnose_demo_bot.bat"
START_BAT = ROOT / "start_demo_bot.bat"
LAUNCHER = ROOT / "windows_launcher.py"
VERIFY = ROOT / "verify_v9_package.py"


class V9PreflightSourceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.diag = DIAG.read_text(encoding="utf-8-sig")
        cls.diag_bat = DIAG_BAT.read_text(encoding="utf-8-sig")
        cls.start_bat = START_BAT.read_text(encoding="utf-8-sig")
        cls.launcher = LAUNCHER.read_text(encoding="utf-8-sig")
        cls.verify = VERIFY.read_text(encoding="utf-8-sig")

    def test_diagnostic_is_read_only_and_uses_existing_demo_guard(self) -> None:
        self.assertIn("core.mt5_initialize()", self.diag)
        self.assertIn("core.get_tick()", self.diag)
        self.assertIn("core.get_closed_m1_rates(3)", self.diag)
        self.assertIn("core.validate_closed_m1_time", self.diag)
        self.assertNotIn("order_send", self.diag)
        self.assertNotIn("trader.step", self.diag)
        self.assertNotIn("DemoTrader(", self.diag)

    def test_diagnostic_persists_safe_preflight_state(self) -> None:
        self.assertIn('core.save_worker_state("preflight", payload)', self.diag)
        self.assertIn('"database_ok"', self.diag)
        self.assertIn('"mt5_demo_ok"', self.diag)
        self.assertIn('"tick_fresh"', self.diag)
        self.assertIn('"closed_m1_fresh"', self.diag)
        self.assertIn('"time_trusted"', self.diag)

    def test_planned_market_closure_is_not_false_failure(self) -> None:
        self.assertIn("auto.planned_market_closed_now()", self.diag)
        self.assertIn('payload["time_trusted"] or planned_closed', self.diag)
        self.assertIn('"time_unverified_market_closed"', self.diag)
        self.assertIn('"PASS_MARKET_CLOSED"', self.diag)

    def test_manual_diagnostic_launcher_never_starts_worker(self) -> None:
        self.assertIn("diagnose_v9.py", self.diag_bat)
        self.assertNotIn("worker_auto.py", self.diag_bat)

    def test_normal_launcher_runs_diagnostic_but_keeps_reconnect_path(self) -> None:
        # start_demo_bot.bat is now a thin wrapper that just invokes
        # windows_launcher.py; the diagnostic-then-reconnect sequence this
        # test protects lives there now.
        self.assertIn("windows_launcher.py", self.start_bat)
        self.assertIn("def run_diagnostic()", self.launcher)
        self.assertIn('run([sys.executable, str(ROOT / "diagnose_v9.py")], required=False)', self.launcher)
        self.assertIn("worker will start fail-closed and reconnect", self.launcher)
        self.assertIn("def worker_loop()", self.launcher)
        # main() must run the diagnostic and then always proceed to the
        # worker loop unconditionally - a failed diagnostic must not stop
        # the worker from at least attempting to reconnect.
        self.assertIn("run_diagnostic()\n        return worker_loop()", self.launcher)

    def test_package_verifier_requires_diagnostic_files(self) -> None:
        self.assertIn('"diagnose_v9.py"', self.verify)
        self.assertIn('"diagnose_demo_bot.bat"', self.verify)


if __name__ == "__main__":
    unittest.main()
