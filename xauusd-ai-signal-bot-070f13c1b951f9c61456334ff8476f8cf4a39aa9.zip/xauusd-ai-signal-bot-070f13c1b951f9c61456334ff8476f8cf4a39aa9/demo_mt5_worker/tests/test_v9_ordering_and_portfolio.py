import inspect
import sys
import types
import unittest
from types import SimpleNamespace

if "psycopg2" not in sys.modules:
    psycopg2 = types.ModuleType("psycopg2")
    psycopg2.connect = lambda *args, **kwargs: None
    extras = types.ModuleType("psycopg2.extras")
    extras.Json = lambda value: value
    sys.modules["psycopg2"] = psycopg2
    sys.modules["psycopg2.extras"] = extras

from trader_legacy import RISK_PROFILES
from trader_v9_hardened_v2 import V9HardenedV2DemoTrader
from worker_ownership import WorkerOwnershipLock


class FakeMt5:
    ORDER_TYPE_BUY = 0
    ORDER_TYPE_SELL = 1
    POSITION_TYPE_BUY = 0
    POSITION_TYPE_SELL = 1

    def positions_get(self, symbol=None):
        del symbol
        return []

    @staticmethod
    def order_calc_profit(order_type, lot, entry, exit_price):
        direction = 1.0 if order_type == 0 else -1.0
        return direction * (float(exit_price) - float(entry)) * float(lot) * 100.0

    @staticmethod
    def order_calc_margin(order_type, lot, price):
        del order_type, price
        return 1000.0 * float(lot)

    @staticmethod
    def symbol_info(symbol):
        del symbol
        return SimpleNamespace(volume_min=0.01, volume_max=100.0, volume_step=0.01)


def make_trader():
    trader = V9HardenedV2DemoTrader.__new__(V9HardenedV2DemoTrader)
    trader.mt5 = FakeMt5()
    trader.symbol = "GOLD#"
    trader.magic = 260817
    trader._last_reconcile_block_event = 0.0
    trader.reconcile_or_fail_closed = lambda: True
    return trader


def trade(basket_id, lot):
    return {
        "id": 1,
        "candidate_id": 1,
        "side": "BUY",
        "lot": lot,
        "entry_price": 100.0,
        "sl": 99.0,
        "payload": {},
        "status": "OPEN",
        "basket_id": basket_id,
    }


class OrderingAndPortfolioTests(unittest.TestCase):
    def test_send_attempted_is_committed_before_final_fence_and_mt5_send(self):
        source = inspect.getsource(V9HardenedV2DemoTrader.send_order)
        attempted = source.index('"send_attempted": True')
        fence = source.index("self.ownership.is_current")
        send = source.index("self.mt5.order_send")
        self.assertLess(attempted, fence)
        self.assertLess(fence, send)

    def test_ownership_session_keeps_advisory_lock_connection_until_release(self):
        source = inspect.getsource(WorkerOwnershipLock)
        self.assertIn("pg_try_advisory_lock", source)
        self.assertIn("self.conn = conn", source)
        self.assertIn("pg_advisory_unlock", source)

    def test_portfolio_budget_counts_other_active_basket(self):
        trader = make_trader()
        current = trade("B2", 0.01)
        other = trade("B1", 0.20)
        trader.basket_risk_trades = lambda side, basket_id=None: [current]
        trader.all_active_risk_trades = lambda: [current, other]
        account = SimpleNamespace(balance=1000.0, equity=1000.0, margin=0.0, margin_free=1000.0)
        candidate = {
            "id": 3,
            "strength": 100,
            "side": "BUY",
            "sl": 99.0,
            "_v9_basket_id": "B2",
        }
        lot, meta = trader.choose_volume(candidate, account, dict(RISK_PROFILES["MEDIUM"]), 100.0)
        self.assertAlmostEqual(meta["scenario_used"], 1.0)
        self.assertAlmostEqual(meta["portfolio_used"], 21.0)
        self.assertGreater(lot, 0.0)

    def test_partial_close_lower_live_lot_reduces_risk_not_resets_basket(self):
        trader = make_trader()
        remaining = trade("B1", 0.03)
        trader.basket_risk_trades = lambda side, basket_id=None: [remaining]
        trader.all_active_risk_trades = lambda: [remaining]
        account = SimpleNamespace(balance=1000.0, equity=1000.0, margin=0.0, margin_free=1000.0)
        candidate = {
            "id": 4,
            "strength": 100,
            "side": "BUY",
            "sl": 99.0,
            "_v9_basket_id": "B1",
        }
        lot, meta = trader.choose_volume(candidate, account, dict(RISK_PROFILES["MEDIUM"]), 100.0)
        self.assertAlmostEqual(meta["scenario_used"], 3.0)
        self.assertGreater(lot, 0.0)


if __name__ == "__main__":
    unittest.main()
