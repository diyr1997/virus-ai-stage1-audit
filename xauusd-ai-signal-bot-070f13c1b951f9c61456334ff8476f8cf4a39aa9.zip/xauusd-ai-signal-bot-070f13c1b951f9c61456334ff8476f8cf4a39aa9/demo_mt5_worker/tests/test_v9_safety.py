import sys
import time
import types
import unittest
from datetime import timedelta
from types import SimpleNamespace

if "psycopg2" not in sys.modules:
    psycopg2 = types.ModuleType("psycopg2")
    psycopg2.connect = lambda *args, **kwargs: None
    extras = types.ModuleType("psycopg2.extras")
    extras.Json = lambda value: value
    sys.modules["psycopg2"] = psycopg2
    sys.modules["psycopg2.extras"] = extras

from trader import DemoTrader
from trader_legacy import RISK_PROFILES, utcnow
from trader_v9 import BasketStateMachine
from trader_v9_hardened_v7 import V9HardenedV7DemoTrader
from worker_ownership import WorkerOwnershipLock


class FakeMt5:
    ORDER_TYPE_BUY = 0
    ORDER_TYPE_SELL = 1
    POSITION_TYPE_BUY = 0
    POSITION_TYPE_SELL = 1
    ACCOUNT_TRADE_MODE_DEMO = 0
    TRADE_ACTION_DEAL = 1
    TRADE_ACTION_SLTP = 6
    ORDER_TIME_GTC = 0
    ORDER_FILLING_IOC = 0
    TRADE_RETCODE_DONE = 10009
    TRADE_RETCODE_DONE_PARTIAL = 10010
    TRADE_RETCODE_PLACED = 10008
    TRADE_RETCODE_NO_CHANGES = 10025

    def __init__(self, positions=None):
        self.positions = list(positions or [])
        self.send_calls = 0
        self.current_account = SimpleNamespace(login=1, trade_mode=self.ACCOUNT_TRADE_MODE_DEMO)

    def account_info(self):
        return self.current_account

    def positions_get(self, symbol=None, ticket=None):
        del symbol
        if ticket is not None:
            return [p for p in self.positions if getattr(p, "ticket", None) == ticket]
        return list(self.positions)

    @staticmethod
    def order_calc_profit(order_type, lot, entry, exit_price):
        direction = 1.0 if order_type == 0 else -1.0
        return direction * (float(exit_price) - float(entry)) * float(lot) * 100.0

    @staticmethod
    def order_calc_margin(order_type, lot, price):
        del order_type, price
        return 1000.0 * float(lot)

    @staticmethod
    def symbol_info(symbol):
        del symbol
        return SimpleNamespace(volume_min=0.01, volume_max=100.0, volume_step=0.01)

    def order_check(self, request):
        del request
        return SimpleNamespace(retcode=0, comment="ok")

    def order_send(self, request):
        self.send_calls += 1
        return SimpleNamespace(retcode=self.TRADE_RETCODE_DONE, order=99, deal=99, price=request.get("price", 0.0))

    @staticmethod
    def last_error():
        return (0, "")


def pos(side="BUY", entry=100.0, lot=0.01, ticket=1, comment=""):
    return SimpleNamespace(
        type=FakeMt5.POSITION_TYPE_BUY if side == "BUY" else FakeMt5.POSITION_TYPE_SELL,
        magic=260817,
        price_open=entry,
        volume=lot,
        profit=1.0,
        ticket=ticket,
        comment=comment,
        sl=95.0,
        tp=110.0,
    )


def candidate(candidate_id=900, side="BUY", strength=100):
    return {
        "id": candidate_id,
        "analysis_id": candidate_id + 1000,
        "timeframe": "M5",
        "side": side,
        "strength": strength,
        "confirmation_price": 100.0,
        "invalidation_price": 95.0,
        "sl": 95.0,
        "tp1": 110.0,
        "tp2": 115.0,
        "tp3": 120.0,
        "status": "CONFIRMED",
    }


def make_trader(positions=None):
    trader = V9HardenedV7DemoTrader.__new__(V9HardenedV7DemoTrader)
    trader.mt5 = FakeMt5(positions)
    trader.symbol = "GOLD#"
    trader.signal_symbol = "XAUUSD"
    trader.magic = 260817
    trader.deviation = 50
    trader.last_status_write = 0.0
    trader._last_reconcile_block_event = 0.0
    trader._last_ownership_block_event = 0.0
    trader.reversal_enabled = False
    trader.event = lambda *args, **kwargs: None
    trader.last_symbol_entry_age = lambda: 9999.0
    return trader


class V9SafetyTests(unittest.TestCase):
    def test_canonical_demo_trader_is_hardened_v9_v7(self):
        self.assertIs(DemoTrader, V9HardenedV7DemoTrader)

    def test_state_machine_never_flips_directly(self):
        self.assertFalse(BasketStateMachine.can_transition("LONG", "SHORT"))
        self.assertFalse(BasketStateMachine.can_transition("SHORT", "LONG"))
        self.assertTrue(BasketStateMachine.can_transition("LONG", "CLOSING"))
        self.assertTrue(BasketStateMachine.can_transition("CLOSING", "RECONCILING"))
        self.assertTrue(BasketStateMachine.can_transition("RECONCILING", "FLAT"))

    def test_sixth_position_not_blocked_by_count(self):
        trader = make_trader([pos("BUY", ticket=i + 1) for i in range(5)])
        tick = SimpleNamespace(bid=110.0, ask=110.1)
        self.assertTrue(trader.slot_allowed(candidate(), 6, tick, dict(RISK_PROFILES["AGGRESSIVE"])))

    def test_opposite_direction_is_blocked(self):
        trader = make_trader([pos("BUY")])
        ok, reason, sides = trader.direction_guard("SELL")
        self.assertFalse(ok)
        self.assertEqual(reason, "ACTIVE_BUY_BLOCKS_SELL")
        self.assertEqual(sides, ["BUY"])

    def test_reversal_stays_shadow_disabled_by_default(self):
        trader = make_trader([pos("BUY")])
        events = []
        trader.event = lambda event_type, *args, **kwargs: events.append(event_type)
        self.assertTrue(trader._opposite_signal_shadow(candidate(side="SELL")))
        self.assertIn("REVERSAL_SHADOW", events)

    def test_unknown_live_mt5_position_fails_closed(self):
        trader = make_trader([pos("BUY", ticket=77)])
        trader.reconcile_open_ticket_comments = lambda: None
        trader._db_open_ticket_map = lambda: {}
        self.assertEqual([p.ticket for p in trader.unknown_live_positions()], [77])

    def test_monotonic_basket_slot_does_not_reuse_closed_slot(self):
        trader = make_trader([pos("BUY", ticket=i + 1) for i in range(5)])
        trader.max_basket_slot = lambda basket_id: 7
        self.assertEqual(trader.next_basket_slot("BUY", "B1"), 8)

    def test_claim_key_is_basket_slot_not_candidate_or_timeframe(self):
        trader = make_trader([])
        self.assertEqual(trader._claim_key("BASKET-X", 6), "GOLD#|BASKET-X|slot:6")

    def test_attempted_ambiguous_pending_blocks_every_new_send(self):
        trader = make_trader([])
        trader._active_trade_rows = lambda: [{
            "id": 9,
            "status": "PENDING",
            "created_at": utcnow() - timedelta(seconds=30),
            "entry_price": 100.0,
            "payload": {"send_attempted": True},
        }]
        trader._position_for_trade_id = lambda trade_id: None
        trader._set_pending_payload = lambda *args, **kwargs: None
        self.assertFalse(trader.reconcile_pending_claims())

    def test_stale_unsent_claim_can_be_retired_safely(self):
        trader = make_trader([])
        retired = []
        trader._active_trade_rows = lambda: [{
            "id": 9,
            "status": "PENDING",
            "created_at": utcnow() - timedelta(seconds=30),
            "entry_price": 100.0,
            "payload": {},
        }]
        trader._position_for_trade_id = lambda trade_id: None
        trader.reject_trade = lambda trade_id, *args, **kwargs: retired.append(trade_id)
        self.assertTrue(trader.reconcile_pending_claims())
        self.assertEqual(retired, [9])

    def _prepare_send_trader(self):
        trader = make_trader([])
        trader.ownership = SimpleNamespace(
            current_token=lambda: 7,
            is_current=lambda token, force=False: True,
        )
        trader.claim_pending_trade = lambda *args, **kwargs: 123
        trader.matching_position_tickets = lambda side: set()
        trader.fill_modes = lambda: [0]
        trader.reject_trade = lambda *args, **kwargs: None
        trader._set_pending_payload = lambda *args, **kwargs: None
        trader.unknown_live_positions = lambda: []
        trader.tp_for_slot = lambda c, slot: c["tp1"]
        trader.current_price = lambda side, tick: tick.ask if side == "BUY" else tick.bid
        return trader

    def test_final_fence_is_last_structural_gate_before_mt5_send(self):
        trader = self._prepare_send_trader()
        trader.ownership = SimpleNamespace(current_token=lambda: 7, is_current=lambda token, force=False: False)
        c = candidate()
        c["_v9_basket_id"] = "BASKET-X"
        account = SimpleNamespace(login=1, trade_mode=0)
        tick = SimpleNamespace(bid=100.0, ask=100.1)
        self.assertFalse(trader.send_order(c, tick, account, 0.01, "AGGRESSIVE", 1, {"risk_amount": 1.0}))
        self.assertEqual(trader.mt5.send_calls, 0)

    def test_fresh_real_account_switch_is_blocked_immediately_before_deal_send(self):
        trader = self._prepare_send_trader()
        # The account object handed to send_order is still DEMO, simulating a
        # switch in the terminal after the worker-loop check.
        stale_demo_account = SimpleNamespace(login=1, trade_mode=FakeMt5.ACCOUNT_TRADE_MODE_DEMO)
        trader.mt5.current_account = SimpleNamespace(login=1, trade_mode=1)
        c = candidate()
        c["_v9_basket_id"] = "BASKET-X"
        tick = SimpleNamespace(bid=100.0, ask=100.1)
        self.assertFalse(trader.send_order(c, tick, stale_demo_account, 0.01, "AGGRESSIVE", 1, {"risk_amount": 1.0}))
        self.assertEqual(trader.mt5.send_calls, 0)

    def test_fresh_demo_login_change_is_blocked_before_deal_send(self):
        trader = self._prepare_send_trader()
        stale_demo_account = SimpleNamespace(login=1, trade_mode=FakeMt5.ACCOUNT_TRADE_MODE_DEMO)
        trader.mt5.current_account = SimpleNamespace(login=2, trade_mode=FakeMt5.ACCOUNT_TRADE_MODE_DEMO)
        c = candidate()
        c["_v9_basket_id"] = "BASKET-X"
        tick = SimpleNamespace(bid=100.0, ask=100.1)
        self.assertFalse(trader.send_order(c, tick, stale_demo_account, 0.01, "AGGRESSIVE", 1, {"risk_amount": 1.0}))
        self.assertEqual(trader.mt5.send_calls, 0)

    def test_fresh_real_account_switch_blocks_protective_sltp_send(self):
        trader = make_trader([])
        trader.mt5.current_account = SimpleNamespace(login=1, trade_mode=1)
        row = {
            "candidate_id": 7,
            "trade_id": 8,
            "db_tp": 120.0,
            "strength": 90,
            "side": "BUY",
            "entry_price": 100.0,
            "db_sl": 95.0,
            "tp1": 110.0,
            "tp2": 115.0,
            "tp3": 120.0,
        }
        self.assertFalse(trader._modify_position_sl(row, pos(ticket=99), 101.0, "TEST"))
        self.assertEqual(trader.mt5.send_calls, 0)

    def test_new_candidate_cannot_reset_basket_risk_budget(self):
        trader = make_trader([])
        existing = {
            "id": 1,
            "candidate_id": 111,
            "side": "BUY",
            "lot": 0.05,
            "entry_price": 100.0,
            "sl": 99.0,
            "payload": {},
            "status": "OPEN",
            "basket_id": "B1",
        }
        trader.reconcile_or_fail_closed = lambda: True
        trader.basket_risk_trades = lambda side, basket_id=None: [existing]
        trader.all_active_risk_trades = lambda: [existing]
        account = SimpleNamespace(balance=1000.0, equity=1000.0, margin=0.0, margin_free=1000.0)
        c = candidate(candidate_id=999, side="BUY")
        c["sl"] = 99.0
        c["_v9_basket_id"] = "B1"
        lot, meta = trader.choose_volume(c, account, dict(RISK_PROFILES["MEDIUM"]), price=100.0)
        self.assertAlmostEqual(meta["scenario_used"], 5.0, places=6)
        self.assertGreater(lot, 0.0)

    def test_risk_budget_can_block_sixth_without_count_cap(self):
        trader = make_trader([])
        existing = {
            "id": 1,
            "candidate_id": 111,
            "side": "BUY",
            "lot": 0.10,
            "entry_price": 100.0,
            "sl": 99.0,
            "payload": {},
            "status": "OPEN",
            "basket_id": "B1",
        }
        trader.reconcile_or_fail_closed = lambda: True
        trader.basket_risk_trades = lambda side, basket_id=None: [existing]
        trader.all_active_risk_trades = lambda: [existing]
        account = SimpleNamespace(balance=1000.0, equity=1000.0, margin=0.0, margin_free=1000.0)
        c = candidate(candidate_id=1001, side="BUY")
        c["sl"] = 99.0
        c["_v9_basket_id"] = "B1"
        lot, meta = trader.choose_volume(c, account, dict(RISK_PROFILES["MEDIUM"]), price=100.0)
        self.assertEqual(lot, 0.0)
        self.assertEqual(meta["reason"], "RISK_BUDGET_FULL")

    def test_stale_fence_generation_is_rejected(self):
        class Cursor:
            def __enter__(self): return self
            def __exit__(self, *args): return False
            def execute(self, *args, **kwargs): pass
            def fetchone(self): return None
        class Conn:
            def cursor(self): return Cursor()
            def close(self): pass
        lock = WorkerOwnershipLock.__new__(WorkerOwnershipLock)
        lock.lock_id = 1
        lock.owner_id = "worker-a"
        lock.conn = Conn()
        lock.acquired = True
        lock.token = 5
        lock.health_seconds = 0.0
        lock.last_health_at = time.monotonic() - 10
        self.assertFalse(lock.is_current(5, force=True))
        self.assertFalse(lock.acquired)


if __name__ == "__main__":
    unittest.main()
