from __future__ import annotations

import unittest
from types import SimpleNamespace

from impulse_shadow import ImpulseShadowEngine


class FakeMt5:
    TIMEFRAME_M1 = 1
    COPY_TICKS_ALL = 0

    def __init__(self):
        self.now = 1_800_000_000.0
        self.rows = []
        for index in range(51):
            ts = self.now - 50.0 + index
            price = 2600.0 + index * 0.01
            self.rows.append({
                "time": int(ts),
                "time_msc": int(ts * 1000.0),
                "bid": price,
                "ask": price + 0.20,
            })

    def copy_ticks_from(self, symbol, start, count, flags):
        return list(self.rows)

    def copy_rates_from_pos(self, symbol, timeframe, start, count):
        rows = []
        for index in range(64):
            price = 2580.0 + index * 0.10
            rows.append({
                "open": price,
                "high": price + 0.50,
                "low": price - 0.50,
                "close": price + 0.20,
            })
        return rows

    def positions_get(self, symbol=None):
        return []


class ImpulseShadowHydrationTests(unittest.TestCase):
    def test_recent_mt5_tick_history_exits_warmup_on_first_slow_loop_sample(self):
        mt5 = FakeMt5()
        current = mt5.rows[-1]
        tick = SimpleNamespace(
            time=current["time"],
            time_msc=current["time_msc"],
            bid=current["bid"],
            ask=current["ask"],
        )

        engine = ImpulseShadowEngine(mt5, "GOLD#")
        snapshot = engine.observe(tick)

        self.assertIsNotNone(snapshot)
        self.assertNotEqual(snapshot["state"], "WARMUP")
        self.assertGreaterEqual(len(engine._window(10.0)), 5)
        self.assertGreaterEqual(len(engine._window(30.0)), 8)


if __name__ == "__main__":
    unittest.main()
