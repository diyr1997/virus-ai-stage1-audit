import importlib.util
import sys
import types
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace


def load_trader_module():
    psycopg2 = types.ModuleType("psycopg2")
    psycopg2.connect = lambda *args, **kwargs: None

    extras = types.ModuleType("psycopg2.extras")
    extras.Json = lambda value: value

    sys.modules.setdefault("psycopg2", psycopg2)
    sys.modules.setdefault("psycopg2.extras", extras)

    path = Path(__file__).resolve().parents[1] / "trader.py"
    spec = importlib.util.spec_from_file_location("demo_trader_for_test", path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


trader_module = load_trader_module()


class FakeMt5:
    ORDER_TYPE_BUY = 0
    ORDER_TYPE_SELL = 1
    ACCOUNT_TRADE_MODE_DEMO = 0
    POSITION_TYPE_BUY = 0
    POSITION_TYPE_SELL = 1

    def positions_get(self, symbol=None, ticket=None):
        del symbol, ticket
        return []

    @staticmethod
    def order_calc_profit(order_type, lot, entry, sl):
        del order_type, entry, sl
        return -100.0 * float(lot)

    @staticmethod
    def order_calc_margin(order_type, lot, price):
        del order_type, price
        return 1000.0 * float(lot)

    @staticmethod
    def symbol_info(symbol):
        del symbol
        return SimpleNamespace(
            volume_min=0.01,
            volume_max=100.0,
            volume_step=0.01,
        )


def make_trader():
    trader = trader_module.DemoTrader.__new__(trader_module.DemoTrader)
    trader.mt5 = FakeMt5()
    trader.symbol = "GOLD#"
    trader.signal_symbol = "XAUUSD"
    trader.magic = 260817
    trader._last_reconcile_block_event = 0.0
    trader.reconcile_or_fail_closed = lambda: True
    trader.basket_risk_trades = lambda side, basket_id=None: []
    trader.all_active_risk_trades = lambda: []
    trader.active_basket_id = lambda side, create_if_flat=False: "TEST-BASKET"
    trader.daily_realized_profit = lambda: 0.0
    return trader


def candidate(strength=100):
    return {
        "id": 1,
        "strength": strength,
        "side": "BUY",
        "sl": 99.0,
        "_v9_basket_id": "TEST-BASKET",
    }


def scenario_candidate(side="SELL"):
    source_candle = datetime(
        2026,
        8,
        18,
        17,
        30,
        tzinfo=timezone.utc,
    )
    return {
        "id": 77,
        "analysis_id": 7001,
        "created_at": source_candle + timedelta(minutes=5, seconds=25),
        "source_candle_time": source_candle,
        "timeframe": "M5",
        "strength": 89,
        "side": side,
        # Старый близкий уровень из пользовательского примера.
        "invalidation_price": 4366.75,
        # Новая структурная граница отмены.
        "sl": 4367.71,
    }


def latest_analysis(
    *,
    action="SELL",
    direction="SELL",
    strength=89,
    close=4366.80,
    candle_minutes=5,
):
    return {
        "id": 7002,
        "timeframe": "M5",
        "analyzed_at": datetime(
            2026,
            8,
            18,
            17,
            40,
            5,
            tzinfo=timezone.utc,
        ),
        "candle_time": datetime(
            2026,
            8,
            18,
            17,
            30 + candle_minutes,
            tzinfo=timezone.utc,
        ),
        "action": action,
        "direction": direction,
        "strength": strength,
        "analysis_price": close,
    }


class RiskManagerTests(unittest.TestCase):
    def test_strength_ladder(self):
        cases = {
            59: 0.0,
            60: 0.01,
            64: 0.01,
            65: 0.02,
            70: 0.03,
            75: 0.04,
            80: 0.05,
            85: 0.06,
            90: 0.07,
            95: 0.08,
            100: 0.08,
        }
        for strength, expected in cases.items():
            with self.subTest(strength=strength):
                self.assertEqual(
                    trader_module.strength_lot_cap(strength),
                    expected,
                )

    def test_risk_uses_lower_of_balance_and_equity(self):
        trader = make_trader()
        account = SimpleNamespace(
            balance=1000.0,
            equity=500.0,
            margin=0.0,
            margin_free=1000.0,
        )

        lot, meta = trader.choose_volume(
            candidate(100),
            account,
            trader_module.RISK_PROFILES["MEDIUM"],
            price=100.0,
        )

        self.assertEqual(lot, 0.05)
        self.assertEqual(meta["risk_base"], 500.0)

    def test_lot_is_reduced_to_preserve_free_margin(self):
        trader = make_trader()
        account = SimpleNamespace(
            balance=1000.0,
            equity=1000.0,
            margin=430.0,
            margin_free=570.0,
        )

        lot, meta = trader.choose_volume(
            candidate(100),
            account,
            trader_module.RISK_PROFILES["MEDIUM"],
            price=100.0,
        )

        self.assertEqual(lot, 0.02)
        self.assertEqual(meta["required_margin"], 20.0)
        self.assertGreaterEqual(
            meta["projected_free_margin"],
            meta["reserve_required"],
        )

    def test_too_small_account_skips_new_entry(self):
        trader = make_trader()
        account = SimpleNamespace(
            balance=100.0,
            equity=80.0,
            margin=0.0,
            margin_free=80.0,
            # RISK_TOO_SMALL_FOR_MIN_LOT routes through assert_demo(account)
            # before the entry is skipped; a DEMO trade_mode is required.
            trade_mode=FakeMt5.ACCOUNT_TRADE_MODE_DEMO,
        )

        lot, meta = trader.choose_volume(
            candidate(100),
            account,
            trader_module.RISK_PROFILES["MEDIUM"],
            price=100.0,
        )

        self.assertEqual(lot, 0.0)
        # trader_v9_hardened_v4 now attempts a DEMO minimum-lot override
        # before giving up; with this account's free margin it still can't
        # afford the broker's minimum lot, so the final reason is the more
        # specific margin-block outcome rather than the original
        # RISK_TOO_SMALL_FOR_MIN_LOT this test predates.
        self.assertEqual(meta["reason"], "DEMO_MIN_LOT_MARGIN_BLOCK")

    def test_real_account_is_always_rejected(self):
        trader = make_trader()
        with self.assertRaisesRegex(RuntimeError, "не DEMO"):
            trader.assert_demo(SimpleNamespace(trade_mode=1))

    def test_sell_touch_above_old_level_does_not_cancel(self):
        trader = make_trader()

        reason = trader.scenario_cancellation_reason(
            scenario_candidate(),
            latest_analysis(close=4366.80),
        )

        self.assertIsNone(reason)
        self.assertEqual(
            trader.effective_invalidation_price(scenario_candidate()),
            4367.71,
        )

    def test_sell_closed_m5_above_sl_cancels(self):
        trader = make_trader()

        reason = trader.scenario_cancellation_reason(
            scenario_candidate(),
            latest_analysis(close=4367.90),
        )

        self.assertEqual(reason, "CLOSED_TF_ABOVE_INVALIDATION")

    def test_buy_closed_m5_below_sl_cancels(self):
        trader = make_trader()
        candidate_row = scenario_candidate(side="BUY")
        candidate_row["invalidation_price"] = 4362.00
        candidate_row["sl"] = 4361.30

        latest = latest_analysis(
            action="BUY",
            direction="BUY",
            strength=89,
            close=4361.20,
        )

        self.assertEqual(
            trader.scenario_cancellation_reason(
                candidate_row,
                latest,
            ),
            "CLOSED_TF_BELOW_INVALIDATION",
        )

    def test_fresh_wait_or_opposite_direction_cancels(self):
        trader = make_trader()
        candidate_row = scenario_candidate()

        self.assertEqual(
            trader.scenario_cancellation_reason(
                candidate_row,
                latest_analysis(
                    action="WAIT",
                    direction="SELL",
                    strength=55,
                    close=4365.00,
                ),
            ),
            "FRESH_WAIT_OR_BELOW_60",
        )
        self.assertEqual(
            trader.scenario_cancellation_reason(
                candidate_row,
                latest_analysis(
                    action="BUY",
                    direction="BUY",
                    strength=80,
                    close=4365.00,
                ),
            ),
            "DIRECTION_CHANGED",
        )

    def test_same_closed_candle_cannot_cancel_new_candidate(self):
        trader = make_trader()
        candidate_row = scenario_candidate()
        same_candle = latest_analysis(close=4370.00, candle_minutes=0)

        self.assertIsNone(
            trader.scenario_cancellation_reason(
                candidate_row,
                same_candle,
            )
        )


if __name__ == "__main__":
    unittest.main()
