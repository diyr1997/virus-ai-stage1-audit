import inspect
import sys
import types
import unittest
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace

if "psycopg2" not in sys.modules:
    psycopg2 = types.ModuleType("psycopg2")
    psycopg2.connect = lambda *args, **kwargs: None
    extras = types.ModuleType("psycopg2.extras")
    extras.Json = lambda value: value
    sys.modules["psycopg2"] = psycopg2
    sys.modules["psycopg2.extras"] = extras

from trader import DemoTrader
from trader_legacy import utcnow
from trader_v9_hardened_v2 import Mt5StateUnavailable
from trader_v9_hardened_v3 import V9HardenedV3DemoTrader
from trader_v9_hardened_v7 import V9HardenedV7DemoTrader


class FakeMt5:
    POSITION_TYPE_BUY = 0
    POSITION_TYPE_SELL = 1

    def __init__(self, positions=()):
        self.positions = list(positions)
        self.return_none = False

    def positions_get(self, symbol=None):
        del symbol
        return None if self.return_none else list(self.positions)

    @staticmethod
    def last_error():
        return (100, "offline")


def make_trader(positions=()):
    trader = V9HardenedV3DemoTrader.__new__(V9HardenedV3DemoTrader)
    trader.mt5 = FakeMt5(positions)
    trader.symbol = "GOLD#"
    trader.magic = 260817
    trader._last_reconcile_block_event = 0.0
    trader.event = lambda *args, **kwargs: None
    return trader


class RecordingCursor:
    def __init__(self, events, fetch=(123,)):
        self.events = events
        self.fetch = fetch

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def execute(self, sql, params=None):
        self.events.append(("execute", " ".join(str(sql).split()), params))

    def fetchone(self):
        return self.fetch


class RecordingConnection:
    def __init__(self, events, fetch=(123,)):
        self.events = events
        self.autocommit = True
        self.fetch = fetch

    def cursor(self):
        return RecordingCursor(self.events, self.fetch)

    def commit(self):
        self.events.append(("commit",))

    def rollback(self):
        self.events.append(("rollback",))

    def close(self):
        self.events.append(("close",))


class CouncilBlockerTests(unittest.TestCase):
    def test_canonical_entry_is_current_hardened_trader(self):
        # The canonical trader has moved past V3 since this test was written
        # (currently V7, per verify_v9_package.py's own check); assert
        # against the live alias instead of pinning a specific old version.
        self.assertIs(DemoTrader, V9HardenedV7DemoTrader)

    def test_mt5_positions_failure_is_not_misread_as_flat(self):
        trader = make_trader()
        trader.mt5.return_none = True
        with self.assertRaises(Mt5StateUnavailable):
            trader.bot_mt5_positions()

    def test_partial_close_does_not_touch_db_when_positions_api_failed(self):
        trader = make_trader()
        trader.mt5.return_none = True
        trader._active_trade_rows = lambda: []
        db_writes = []
        trader.connect = lambda: db_writes.append("connect")
        with self.assertRaises(Mt5StateUnavailable):
            trader.reconcile_open_ticket_comments()
        self.assertEqual(db_writes, [])

    def test_send_attempted_claim_becomes_unresolved_not_retryable(self):
        trader = make_trader()
        trader.CLAIM_GRACE_SECONDS = 5
        trader.UNRESOLVED_AFTER_SECONDS = 60
        marked = []
        trader._active_trade_rows = lambda: [{
            "id": 8,
            "status": "PENDING",
            "created_at": utcnow() - timedelta(seconds=90),
            "entry_price": 100.0,
            "payload": {"send_attempted": True},
        }]
        trader._position_for_trade_id = lambda trade_id: None
        trader._set_pending_payload = lambda *args, **kwargs: None
        trader._mark_unresolved = lambda trade_id, age: marked.append(trade_id)
        self.assertFalse(trader.reconcile_pending_claims())
        self.assertEqual(marked, [8])

    def test_existing_unresolved_claim_blocks_replacement_worker(self):
        trader = make_trader()
        trader.UNRESOLVED_RECHECK_SECONDS = 30
        trader._active_trade_rows = lambda: [{
            "id": 9,
            "status": "UNRESOLVED",
            "payload": {"unresolved_recheck_at": utcnow().isoformat()},
        }]
        called = []
        trader._position_for_trade_id = lambda trade_id: called.append(trade_id)
        self.assertFalse(trader.reconcile_pending_claims())
        self.assertEqual(called, [])

    def test_unresolved_rechecks_after_backoff_but_never_resends_order(self):
        trader = make_trader()
        trader.UNRESOLVED_RECHECK_SECONDS = 30
        trader._active_trade_rows = lambda: [{
            "id": 10,
            "status": "UNRESOLVED",
            "entry_price": 100.0,
            "payload": {
                "unresolved_recheck_at": (utcnow() - timedelta(seconds=31)).isoformat(),
                "auto_retry": False,
            },
        }]
        stamps = []
        checks = []
        trader._stamp_unresolved_recheck = lambda trade_id: stamps.append(trade_id)
        trader._position_for_trade_id = lambda trade_id: checks.append(trade_id) or None
        self.assertFalse(trader.reconcile_pending_claims())
        self.assertEqual(stamps, [10])
        self.assertEqual(checks, [10])
        self.assertFalse(hasattr(trader.mt5, "order_send"))

    def test_tocou_duplicate_window_is_closed_by_committed_claim(self):
        replacement = make_trader()
        replacement._active_trade_rows = lambda: [{
            "id": 101,
            "status": "PENDING",
            "created_at": utcnow() - timedelta(seconds=10),
            "entry_price": 100.0,
            "payload": {"send_attempted": True, "fence_token": 7},
        }]
        replacement._position_for_trade_id = lambda trade_id: None
        replacement._set_pending_payload = lambda *args, **kwargs: None
        self.assertFalse(replacement.reconcile_pending_claims())

    def test_claim_insert_is_committed_before_method_returns(self):
        trader = make_trader()
        events = []
        trader.connect = lambda: RecordingConnection(events, fetch=(321,))
        candidate = {
            "id": 1,
            "analysis_id": 2,
            "timeframe": "M5",
            "side": "BUY",
            "sl": 99.0,
            "tp1": 110.0,
            "tp2": 115.0,
            "tp3": 120.0,
        }
        account = SimpleNamespace(login=999)
        trade_id = trader.claim_pending_trade(
            candidate, 0.01, 100.0, 110.0, account, "MEDIUM", 1, {}, "B1", 7
        )
        self.assertEqual(trade_id, 321)
        names = [event[0] for event in events]
        self.assertIn("commit", names)
        self.assertLess(names.index("commit"), names.index("close"))
        self.assertNotIn("rollback", names)

    def test_send_attempted_payload_update_is_explicitly_committed(self):
        trader = make_trader()
        events = []
        trader.connect = lambda: RecordingConnection(events)
        trader._set_pending_payload(321, {"send_attempted": True})
        names = [event[0] for event in events]
        self.assertIn("commit", names)
        self.assertLess(names.index("commit"), names.index("close"))
        executed = "\n".join(event[1] for event in events if event[0] == "execute")
        self.assertIn("UPDATE demo_trades", executed)

    def test_migration_is_transactional_and_validates_active_rows(self):
        root = Path(__file__).resolve().parents[1]
        sql = (root / "migrations" / "v9_safety_backfill.sql").read_text(encoding="utf-8")
        self.assertIn("BEGIN;", sql)
        self.assertIn("COMMIT;", sql)
        self.assertIn("ROW_NUMBER() OVER", sql)
        self.assertIn("V9 migration validation failed", sql)
        self.assertIn("demo_basket_id_seq", sql)

    def test_postgres_unique_null_semantics_are_intentional(self):
        root = Path(__file__).resolve().parents[1]
        sql = (root / "migrations" / "v9_safety_backfill.sql").read_text(encoding="utf-8")
        self.assertIn("CREATE UNIQUE INDEX", sql)
        self.assertIn("Historical CLOSED/REJECTED rows are intentionally allowed", sql)
        source = inspect.getsource(V9HardenedV3DemoTrader)
        self.assertIn("order_claim_key", source)
        self.assertIn("conn.commit()", source)

    def test_import_chain_has_single_canonical_trader(self):
        root = Path(__file__).resolve().parents[1]
        worker = (root / "worker.py").read_text(encoding="utf-8")
        auto = (root / "worker_auto.py").read_text(encoding="utf-8")
        trader = (root / "trader.py").read_text(encoding="utf-8")
        self.assertIn("from trader import DemoTrader", worker)
        self.assertIn("import worker as core", auto)
        self.assertNotIn("apply_impulse_entry_guard_v3", trader)
        # Deployment moved the canonical-trader check from start_demo_bot.bat
        # text (now a thin wrapper around windows_launcher.py) to the same
        # alias verify_v9_package.py itself checks at package time.
        self.assertIn("from trader_v9_hardened_v7 import V9HardenedV7DemoTrader", trader)
        self.assertIn("DemoTrader = V9HardenedV7DemoTrader", trader)


if __name__ == "__main__":
    unittest.main()
