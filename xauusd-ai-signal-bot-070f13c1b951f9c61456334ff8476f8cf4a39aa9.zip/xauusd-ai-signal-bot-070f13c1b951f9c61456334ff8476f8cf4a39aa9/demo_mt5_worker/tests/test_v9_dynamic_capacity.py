import sys
import types
import unittest
from types import SimpleNamespace

if "psycopg2" not in sys.modules:
    psycopg2 = types.ModuleType("psycopg2")
    psycopg2.connect = lambda *args, **kwargs: None
    extras = types.ModuleType("psycopg2.extras")
    extras.Json = lambda value: value
    sys.modules["psycopg2"] = psycopg2
    sys.modules["psycopg2.extras"] = extras

from trader_legacy import RISK_PROFILES
from trader_v9_hardened_v3 import V9HardenedV3DemoTrader


class FakeMt5:
    ORDER_TYPE_BUY = 0
    ORDER_TYPE_SELL = 1
    POSITION_TYPE_BUY = 0
    POSITION_TYPE_SELL = 1

    def __init__(self, positions=None, margin_per_lot=1000.0):
        self.positions = list(positions or [])
        self.margin_per_lot = float(margin_per_lot)

    def positions_get(self, symbol=None):
        del symbol
        return list(self.positions)

    @staticmethod
    def order_calc_profit(order_type, lot, entry, exit_price):
        direction = 1.0 if order_type == FakeMt5.ORDER_TYPE_BUY else -1.0
        return direction * (float(exit_price) - float(entry)) * float(lot) * 100.0

    def order_calc_margin(self, order_type, lot, price):
        del order_type, price
        return self.margin_per_lot * float(lot)

    @staticmethod
    def symbol_info(symbol):
        del symbol
        return SimpleNamespace(volume_min=0.01, volume_max=100.0, volume_step=0.01)


def pos(ticket, lot=0.01, entry=100.0):
    return SimpleNamespace(
        type=FakeMt5.POSITION_TYPE_BUY,
        magic=260817,
        price_open=entry,
        volume=lot,
        profit=1.0,
        ticket=ticket,
        comment="",
    )


def candidate(candidate_id=700):
    return {
        "id": candidate_id,
        "analysis_id": candidate_id + 1000,
        "timeframe": "M5",
        "side": "BUY",
        "strength": 100,
        "confirmation_price": 100.0,
        "invalidation_price": 95.0,
        "sl": 99.0,
        "tp1": 110.0,
        "tp2": 115.0,
        "tp3": 120.0,
        "status": "CONFIRMED",
        "_v9_basket_id": "B1",
    }


def make_trader(positions=None, margin_per_lot=1000.0):
    trader = V9HardenedV3DemoTrader.__new__(V9HardenedV3DemoTrader)
    trader.mt5 = FakeMt5(positions, margin_per_lot=margin_per_lot)
    trader.symbol = "GOLD#"
    trader.magic = 260817
    trader._last_reconcile_block_event = 0.0
    trader.event = lambda *args, **kwargs: None
    trader.reconcile_or_fail_closed = lambda: True
    trader.last_symbol_entry_age = lambda: 9999.0
    return trader


def db_trade(lot=0.01, entry=100.0, sl=99.0):
    return {
        "id": 1,
        "candidate_id": 1,
        "side": "BUY",
        "lot": lot,
        "entry_price": entry,
        "sl": sl,
        "payload": {},
        "status": "OPEN",
        "basket_id": "B1",
    }


class DynamicCapacityMatrixTests(unittest.TestCase):
    def test_seventh_slot_is_not_blocked_by_position_count(self):
        trader = make_trader([pos(i + 1) for i in range(6)])
        tick = SimpleNamespace(bid=110.0, ask=110.1)
        self.assertTrue(
            trader.slot_allowed(candidate(), 7, tick, dict(RISK_PROFILES["AGGRESSIVE"]))
        )

    def test_high_free_margin_allows_volume_after_many_slots(self):
        trader = make_trader([])
        trader.basket_risk_trades = lambda side, basket_id=None: []
        trader.all_active_risk_trades = lambda: []
        account = SimpleNamespace(
            balance=1000.0,
            equity=1000.0,
            margin=50.0,
            margin_free=950.0,
        )
        lot, meta = trader.choose_volume(
            candidate(), account, dict(RISK_PROFILES["AGGRESSIVE"]), price=100.0
        )
        self.assertGreater(lot, 0.0)
        self.assertEqual(meta["reason"], "OK")

    def test_low_free_margin_blocks_by_margin_not_position_count(self):
        trader = make_trader([], margin_per_lot=10000.0)
        trader.basket_risk_trades = lambda side, basket_id=None: []
        trader.all_active_risk_trades = lambda: []
        account = SimpleNamespace(
            balance=1000.0,
            equity=1000.0,
            margin=695.0,
            margin_free=305.0,
        )
        lot, meta = trader.choose_volume(
            candidate(), account, dict(RISK_PROFILES["AGGRESSIVE"]), price=100.0
        )
        self.assertEqual(lot, 0.0)
        self.assertEqual(meta["reason"], "NOT_ENOUGH_SAFE_MARGIN")

    def test_used_risk_blocks_by_budget_not_position_count(self):
        trader = make_trader([])
        existing = db_trade(lot=0.25)
        trader.basket_risk_trades = lambda side, basket_id=None: [existing]
        trader.all_active_risk_trades = lambda: [existing]
        account = SimpleNamespace(
            balance=1000.0,
            equity=1000.0,
            margin=100.0,
            margin_free=900.0,
        )
        lot, meta = trader.choose_volume(
            candidate(), account, dict(RISK_PROFILES["AGGRESSIVE"]), price=100.0
        )
        self.assertEqual(lot, 0.0)
        self.assertEqual(meta["reason"], "RISK_BUDGET_FULL")


if __name__ == "__main__":
    unittest.main()
