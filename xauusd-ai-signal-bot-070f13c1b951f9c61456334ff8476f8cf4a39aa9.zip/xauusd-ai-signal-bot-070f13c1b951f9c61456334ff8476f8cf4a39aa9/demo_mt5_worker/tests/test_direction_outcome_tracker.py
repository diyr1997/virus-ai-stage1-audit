from __future__ import annotations

import unittest
from types import SimpleNamespace
from unittest.mock import patch

from direction_outcome_tracker import DirectionOutcomeTracker


class FakeMt5:
    def __init__(self, mid=2600.0):
        self.mid = mid

    def symbol_info_tick(self, symbol):
        return SimpleNamespace(bid=self.mid - 0.1, ask=self.mid + 0.1)


class DirectionOutcomeTrackerTests(unittest.TestCase):
    def test_dimensions_are_frozen_at_observation_and_all_categories_are_supported(self):
        mt5 = FakeMt5()
        tracker = DirectionOutcomeTracker(mt5, "GOLD#")
        payload = {
            "direction_v2": "BUY",
            "legacy_direction": "SELL",
            "direction_confidence": 83.5,
            "regime_shadow": {"market_regime": "HIGH_VOL", "session": "LONDON"},
        }
        with patch("direction_outcome_tracker.time.time", side_effect=[1000.0, 1060.0]):
            self.assertEqual(tracker.observe(payload), [])
            mt5.mid = 2601.0
            outcomes = tracker.observe({})

        self.assertEqual(len(outcomes), 1)
        outcome = outcomes[0]
        self.assertEqual(outcome["horizon_seconds"], 60)
        self.assertEqual(outcome["comparison"], "V2_BETTER")
        self.assertEqual(outcome["confidence_bucket"], "80-89")
        self.assertEqual(outcome["market_regime"], "HIGH_VOL")
        self.assertEqual(outcome["trading_session"], "LONDON")
        self.assertTrue(outcome["shadow_only"])
        self.assertEqual(outcome["execution_impact"], "NONE")

    def test_confidence_bucket_boundaries(self):
        values = [(0, "<50"), (49.99, "<50"), (50, "50-59"), (60, "60-69"),
                  (70, "70-79"), (80, "80-89"), (90, "90+"), (100, "90+")]
        for value, expected in values:
            with self.subTest(value=value):
                self.assertEqual(DirectionOutcomeTracker.confidence_bucket(value), expected)


if __name__ == "__main__":
    unittest.main()
