import os
import unittest
import uuid
from pathlib import Path

try:
    import psycopg2
    from psycopg2 import errors
except Exception:  # pragma: no cover - CI installs psycopg2-binary
    psycopg2 = None
    errors = None


DATABASE_URL = os.getenv("V9_TEST_DATABASE_URL", "").strip()


@unittest.skipUnless(psycopg2 is not None and DATABASE_URL, "V9_TEST_DATABASE_URL/psycopg2 required")
class V9MigrationPostgresTests(unittest.TestCase):
    def setUp(self):
        self.conn = psycopg2.connect(DATABASE_URL)
        self.conn.autocommit = True
        self.schema = "v9_" + uuid.uuid4().hex[:12]
        with self.conn.cursor() as cur:
            cur.execute(f'CREATE SCHEMA "{self.schema}"')
            cur.execute(f'SET search_path TO "{self.schema}"')
            cur.execute(
                """
                CREATE TABLE demo_trades (
                    id BIGSERIAL PRIMARY KEY,
                    candidate_id BIGINT,
                    analysis_id BIGINT,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    opened_at TIMESTAMPTZ,
                    closed_at TIMESTAMPTZ,
                    symbol TEXT NOT NULL,
                    timeframe TEXT,
                    side TEXT NOT NULL,
                    lot DOUBLE PRECISION,
                    planned_price DOUBLE PRECISION,
                    entry_price DOUBLE PRECISION,
                    sl DOUBLE PRECISION,
                    status TEXT NOT NULL,
                    mt5_ticket TEXT,
                    payload JSONB NOT NULL DEFAULT '{}'::jsonb
                )
                """
            )
            cur.execute(
                """
                INSERT INTO demo_trades(symbol,timeframe,side,lot,status,opened_at)
                VALUES
                  ('GOLD#','M1','BUY',0.01,'OPEN',NOW() - INTERVAL '2 minute'),
                  ('GOLD#','M5','BUY',0.02,'PENDING',NOW() - INTERVAL '1 minute'),
                  ('GOLD#','M15','BUY',0.03,'CLOSED',NOW() - INTERVAL '3 minute')
                """
            )

    def tearDown(self):
        try:
            self.conn.rollback()
        except Exception:
            pass
        self.conn.autocommit = True
        with self.conn.cursor() as cur:
            cur.execute('SET search_path TO public')
            cur.execute(f'DROP SCHEMA IF EXISTS "{self.schema}" CASCADE')
        self.conn.close()

    def _run_migration(self):
        root = Path(__file__).resolve().parents[1]
        sql = (root / "migrations" / "v9_safety_backfill.sql").read_text(encoding="utf-8")
        with self.conn.cursor() as cur:
            cur.execute(f'SET search_path TO "{self.schema}"')
            cur.execute(sql)

    def test_legacy_active_null_fields_are_backfilled_and_unique(self):
        self._run_migration()
        with self.conn.cursor() as cur:
            cur.execute(
                """
                SELECT id,status,basket_id,basket_slot,order_claim_key,fence_token
                FROM demo_trades
                ORDER BY id
                """
            )
            rows = cur.fetchall()

        active = [row for row in rows if row[1] in {"OPEN", "PENDING", "UNRESOLVED"}]
        self.assertEqual(len(active), 2)
        self.assertTrue(all(row[2] for row in active))
        self.assertEqual(len({row[2] for row in active}), 1)
        self.assertEqual({row[3] for row in active}, {1, 2})
        self.assertTrue(all(row[4] for row in active))
        self.assertEqual(len({row[4] for row in active}), 2)
        self.assertTrue(all(row[5] == 0 for row in active))

        closed = next(row for row in rows if row[1] == "CLOSED")
        self.assertIsNone(closed[2])
        self.assertIsNone(closed[3])
        self.assertIsNone(closed[4])
        self.assertIsNone(closed[5])

        duplicate_key = active[0][4]
        with self.assertRaises(errors.UniqueViolation):
            with self.conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO demo_trades(
                        symbol,timeframe,side,lot,status,basket_id,basket_slot,order_claim_key,fence_token
                    ) VALUES('GOLD#','M30','BUY',0.01,'OPEN','B999',99,%s,99)
                    """,
                    (duplicate_key,),
                )
        self.conn.rollback()
        self.conn.autocommit = True
        with self.conn.cursor() as cur:
            cur.execute(f'SET search_path TO "{self.schema}"')

    def test_unique_index_allows_multiple_historical_null_claim_keys(self):
        self._run_migration()
        with self.conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO demo_trades(symbol,timeframe,side,lot,status)
                VALUES('GOLD#','H1','SELL',0.01,'CLOSED'),
                      ('GOLD#','H1','SELL',0.01,'REJECTED')
                """
            )
            cur.execute(
                """
                SELECT COUNT(*)
                FROM demo_trades
                WHERE status IN('CLOSED','REJECTED') AND order_claim_key IS NULL
                """
            )
            null_count = cur.fetchone()[0]
        self.assertGreaterEqual(null_count, 3)


if __name__ == "__main__":
    unittest.main()
