from __future__ import annotations

import math
from typing import Any


def _num(value: Any, default: float = 0.0) -> float:
    try:
        value = float(value)
        return value if math.isfinite(value) else default
    except (TypeError, ValueError):
        return default


class FastEntryShadowGate:
    """SHADOW ONLY: evaluates hypothetical FAST entry quality without execution."""

    def evaluate(self, snapshot: dict) -> dict:
        state = str(snapshot.get("state") or "UNKNOWN")
        side = str(snapshot.get("direction") or "FLAT")
        impulse = _num(snapshot.get("impulse_score"))
        late = _num(snapshot.get("late_penalty"))
        persistence = _num(snapshot.get("tick_persistence"))
        efficiency = _num(snapshot.get("tick_efficiency"))
        spread_z = _num(snapshot.get("spread_z"))
        chop = _num(snapshot.get("chop_score"))
        weakening = _num(snapshot.get("weakening_score"))
        reversal = _num(snapshot.get("reversal_score"))
        velocity_decay = _num(snapshot.get("velocity_decay"))
        extension_atr = _num(snapshot.get("extension_atr"))
        age_sec = _num(snapshot.get("impulse_age_sec"))

        reasons: list[str] = []
        quality = 100.0

        # These are calibration starting points, not execution thresholds.
        if impulse < 80.0:
            reasons.append("IMPULSE_BELOW_FAST80")
            quality -= min(45.0, (80.0 - impulse) * 1.5)
        if side not in {"BUY", "SELL"}:
            reasons.append("NO_DIRECTION")
            quality -= 40.0
        if late >= 45.0:
            reasons.append("LATE_ENTRY")
            quality -= min(35.0, (late - 35.0) * 0.7)
        if extension_atr >= 1.5:
            reasons.append("OVEREXTENDED_ATR")
            quality -= min(25.0, (extension_atr - 1.2) * 18.0)
        if age_sec >= 180.0:
            reasons.append("IMPULSE_OLD")
            quality -= min(18.0, (age_sec - 150.0) / 15.0)
        if state == "CHOP" or chop >= 70.0:
            reasons.append("CHOP")
            quality -= 35.0
        if persistence < 0.62:
            reasons.append("LOW_PERSISTENCE")
            quality -= min(22.0, (0.62 - persistence) * 70.0)
        if efficiency < 0.28:
            reasons.append("LOW_EFFICIENCY")
            quality -= min(20.0, (0.28 - efficiency) * 65.0)
        if spread_z >= 2.0:
            reasons.append("WIDE_SPREAD")
            quality -= min(30.0, (spread_z - 1.5) * 12.0)
        if weakening >= 65.0 or velocity_decay >= 0.65:
            reasons.append("IMPULSE_WEAKENING")
            quality -= 20.0
        if reversal >= 60.0 and state == "TRUE_REVERSAL_CANDIDATE":
            reasons.append("REVERSAL_CONFLICT")
            quality -= 25.0

        quality = max(0.0, min(100.0, quality))
        hard_block = any(
            r in reasons
            for r in (
                "NO_DIRECTION", "LATE_ENTRY", "CHOP", "WIDE_SPREAD",
                "OVEREXTENDED_ATR", "IMPULSE_WEAKENING", "REVERSAL_CONFLICT",
            )
        )
        allow = bool(impulse >= 80.0 and not hard_block and persistence >= 0.62 and efficiency >= 0.28)

        if allow:
            recommendation = "WOULD_ALLOW_FAST_ENTRY"
            primary_reason = "QUALITY_OK"
        else:
            recommendation = "WOULD_BLOCK_FAST_ENTRY"
            primary_reason = reasons[0] if reasons else "QUALITY_NOT_CONFIRMED"

        return {
            "recommendation": recommendation,
            "primary_reason": primary_reason,
            "reasons": reasons,
            "quality_score": round(quality, 2),
            "side": side,
            "impulse_score": round(impulse, 2),
            "late_penalty": round(late, 2),
            "extension_atr": round(extension_atr, 4),
            "impulse_age_sec": round(age_sec, 1),
            "tick_persistence": round(persistence, 4),
            "tick_efficiency": round(efficiency, 4),
            "spread_z": round(spread_z, 3),
            "chop_score": round(chop, 2),
            "weakening_score": round(weakening, 2),
            "reversal_score": round(reversal, 2),
            "shadow_only": True,
            "execution_impact": "NONE",
        }
