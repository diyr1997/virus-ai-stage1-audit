from __future__ import annotations

import json
import os
import time

from impulse_shadow import ImpulseShadowEngine
from trader_legacy import integer, num
from trader_v9_hardened_v3 import V9HardenedV3DemoTrader


class V9HardenedV4DemoTrader(V9HardenedV3DemoTrader):
    """V9 final entry policy: strong impulse may bypass ordinary confirmation only.

    FAST80 bypasses only ordinary confirmation / transient fresh WAIT after arming.
    It never bypasses DEMO-only, expiry, true direction flip, structural invalidation,
    ownership/fencing, no-hedge, basket, SL/TP, margin, reconciliation or final MT5 guards.
    """

    FAST_ENTRY_MIN_STRENGTH = max(80, min(100, int(os.getenv("FAST_ENTRY_MIN_STRENGTH", "80"))))

    PIPELINE_EVENTS = {
        "FAST_ENTRY_ARMED", "FAST_ENTRY_BLOCKED", "FAST_ENTRY_WAIT_IGNORED",
        "FAST_ENTRY_SLOT_BLOCKED", "ENTRY_SKIPPED", "DIRECTION_BLOCKED",
        "ADD_BLOCKED", "ORDER_CLAIM_BLOCKED", "ORDER_SEND_BLOCKED", "ORDER_SEND_AMBIGUOUS",
        "ORDER_REJECTED", "TRADE_OPENED", "SCENARIO_CANCELLED", "REVERSAL_SHADOW",
        "REVERSAL_NOT_IMPLEMENTED_SAFE_BLOCK", "SHADOW_FAST_SIGNAL", "SHADOW_FAST_OUTCOME",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.impulse_shadow_enabled = str(os.getenv("IMPULSE_SHADOW_ENABLED", "1")).strip().lower() in {"1", "true", "yes", "on"}
        self.impulse_shadow = ImpulseShadowEngine(self.mt5, self.symbol) if self.impulse_shadow_enabled else None
        if self.impulse_shadow is not None:
            tracker = getattr(self.impulse_shadow, "shadow_outcome_tracker", None)
            if tracker is not None:
                tracker.event_sink = self.event
        self._shadow_last_log_at = 0.0
        self._shadow_last_event_at = 0.0
        self._shadow_last_state = ""
        self._shadow_log_seconds = max(2.0, float(os.getenv("IMPULSE_SHADOW_LOG_SECONDS", "10")))
        self._shadow_event_seconds = max(10.0, float(os.getenv("IMPULSE_SHADOW_EVENT_SECONDS", "30")))
        self._fast_wait_log_at = {}
        if self.impulse_shadow_enabled:
            print("[V9 SHADOW] impulse microstructure observer ACTIVE | execution impact=NONE", flush=True)

    def event(self, event_type, candidate_id=None, trade_id=None, payload=None):
        super().event(event_type, candidate_id, trade_id, payload)
        et = str(event_type or "").upper()
        if et not in self.PIPELINE_EVENTS:
            return
        data = payload or {}
        try:
            details = json.dumps(data, ensure_ascii=False, default=str, sort_keys=True)
        except Exception:
            details = str(data)
        print(f"[V9 PIPELINE] {et} | candidate={candidate_id} | trade={trade_id} | {details}", flush=True)

    def _shadow_observe(self, tick):
        if self.impulse_shadow is None:
            return
        try:
            snapshot = self.impulse_shadow.observe(tick, min_interval=1.0)
        except Exception as exc:
            now = time.monotonic()
            if now - self._shadow_last_log_at >= 30.0:
                print(f"[V9 SHADOW] observer error | {exc}", flush=True)
                self._shadow_last_log_at = now
            return
        if not snapshot:
            return
        state = str(snapshot.get("state") or "UNKNOWN")
        now = time.monotonic()
        state_changed = state != self._shadow_last_state
        if state_changed or now - self._shadow_last_log_at >= self._shadow_log_seconds:
            print(
                "[V9 SHADOW] "
                f"state={state} | dir={snapshot.get('direction', '-')} | impulse={snapshot.get('impulse_score', '-')} | "
                f"pullback={snapshot.get('pullback_score', '-')} | weakening={snapshot.get('weakening_score', '-')} | "
                f"reversal={snapshot.get('reversal_score', '-')} | chop={snapshot.get('chop_score', '-')} | "
                f"late={snapshot.get('late_penalty', '-')} | persist={snapshot.get('tick_persistence', '-')} | "
                f"eff={snapshot.get('tick_efficiency', '-')} | spread_z={snapshot.get('spread_z', '-')}",
                flush=True,
            )
            self._shadow_last_log_at = now
        if (state_changed or now - self._shadow_last_event_at >= self._shadow_event_seconds) and state != "WARMUP":
            try:
                self.event("SHADOW_IMPULSE_STATE", payload=snapshot)
            except Exception:
                pass
            self._shadow_last_event_at = now
        self._shadow_last_state = state

    def step(self, tick, account):
        self._shadow_observe(tick)
        return super().step(tick, account)

    def _is_fast_armed(self, candidate):
        return (
            integer(candidate.get("strength"), 0) >= self.FAST_ENTRY_MIN_STRENGTH
            and str(candidate.get("status") or "").upper() in {"CONFIRMED", "ACTIVE"}
        )

    def _log_fast_wait_ignored(self, candidate, latest, stage):
        cid = integer(candidate.get("id"), 0)
        now = time.monotonic()
        if now - self._fast_wait_log_at.get(cid, 0.0) < 15.0:
            return
        self._fast_wait_log_at[cid] = now
        self.event("FAST_ENTRY_WAIT_IGNORED", cid, payload={
            "stage": stage,
            "reason": "TRANSIENT_FRESH_WAIT_AFTER_FAST_ARMED",
            "candidate_strength": integer(candidate.get("strength"), 0),
            "latest_action": str((latest or {}).get("action") or "").upper(),
            "latest_direction": str((latest or {}).get("direction") or "").upper(),
            "latest_strength": integer((latest or {}).get("strength"), 0),
            "timeframe": candidate.get("timeframe"),
            "side": candidate.get("side"),
        })

    def scenario_cancellation_reason(self, candidate, latest):
        reason = super().scenario_cancellation_reason(candidate, latest)
        if reason != "FRESH_WAIT_OR_BELOW_60" or not self._is_fast_armed(candidate):
            return reason
        # FAST80 has already been armed. A single fresh WAIT/<60 is treated as a
        # possible micro-pullback, not a structural cancellation. True direction
        # flips, expiry and structural invalidation are still handled normally.
        self._log_fast_wait_ignored(candidate, latest, "scenario_cancellation")
        return None

    def latest_analysis_allows_add(self, candidate, latest=None):
        allowed, reason = super().latest_analysis_allows_add(candidate, latest)
        if allowed or not self._is_fast_armed(candidate):
            return allowed, reason
        if reason != "STRENGTH_BELOW_60_OR_WAIT":
            return allowed, reason
        if latest is None:
            return allowed, reason
        # Same protection as cancellation: do not send a FAST80 candidate back to
        # ordinary WAIT after it has armed. A real DIRECTION_CHANGED still blocks.
        self._log_fast_wait_ignored(candidate, latest, "latest_analysis_guard")
        return True, "FAST_ARMED_TRANSIENT_WAIT_IGNORED"

    def slot_allowed(self, candidate, slot_no, tick, profile):
        allowed = super().slot_allowed(candidate, slot_no, tick, profile)
        if allowed:
            return True
        if self._is_fast_armed(candidate):
            side = str(candidate.get("side") or "").upper()
            live_sides = sorted(self.live_sides())
            self.event("FAST_ENTRY_SLOT_BLOCKED", candidate.get("id"), payload={
                "reason": "SLOT_ALLOWED_FALSE",
                "slot_no": int(slot_no),
                "side": side,
                "live_sides": live_sides,
                "candidate_strength": integer(candidate.get("strength"), 0),
                "candidate_status": candidate.get("status"),
                "db_active_rows": len(self._active_trade_rows()),
            })
        return False

    def risk_money(self, side, lot, entry, sl):
        primary = super().risk_money(side, lot, entry, sl)
        if primary > 0:
            return primary
        lot, entry, sl = num(lot), num(entry), num(sl)
        if lot <= 0 or entry <= 0 or sl <= 0:
            return 0.0
        try:
            info = self.mt5.symbol_info(self.symbol)
        except Exception:
            info = None
        if info is None:
            return 0.0
        tick_size = abs(num(getattr(info, "trade_tick_size", 0.0))) or abs(num(getattr(info, "point", 0.0)))
        tick_value = max([
            abs(num(getattr(info, "trade_tick_value_loss", 0.0))),
            abs(num(getattr(info, "trade_tick_value_profit", 0.0))),
            abs(num(getattr(info, "trade_tick_value", 0.0))),
        ])
        distance = abs(entry - sl)
        if tick_size <= 0 or tick_value <= 0 or distance <= 0:
            return 0.0
        fallback = abs((distance / tick_size) * tick_value * lot)
        if fallback <= 0:
            return 0.0
        print(
            "[V9 RISK] MT5 order_calc_profit unavailable; "
            f"tick fallback used | symbol={self.symbol} | side={str(side).upper()} | lot={lot:.4f} | "
            f"entry={entry:.5f} | sl={sl:.5f} | tick_size={tick_size:.8f} | tick_value={tick_value:.8f} | risk={fallback:.4f}",
            flush=True,
        )
        return fallback

    def choose_volume(self, candidate, account, profile, price):
        lot, meta = super().choose_volume(candidate, account, profile, price)
        if lot > 0:
            return lot, meta
        meta = dict(meta or {})
        if str(meta.get("reason") or "").upper() != "RISK_TOO_SMALL_FOR_MIN_LOT":
            return lot, meta
        self.assert_demo(account)
        side = str(candidate.get("side") or "").upper()
        sl = num(candidate.get("sl"))
        if side not in {"BUY", "SELL"} or price <= 0 or sl <= 0:
            return 0.0, {**meta, "reason": "DEMO_MIN_LOT_INVALID_INPUT"}
        vmin, vmax, vstep = self.volume_rules()
        min_lot = self.floor_volume(vmin, vmin, vmax, vstep)
        if min_lot <= 0:
            return 0.0, {**meta, "reason": "DEMO_MIN_LOT_INVALID_BROKER_RULES"}
        risk_amount = self.risk_money(side, min_lot, price, sl)
        if risk_amount <= 0:
            return 0.0, {**meta, "reason": "SL_RISK_CALC_FAILED"}
        try:
            margin_required = self.mt5.order_calc_margin(self.order_type(side), self.symbol, float(min_lot), float(price))
        except Exception:
            margin_required = None
        margin_required = num(margin_required)
        free_margin = max(0.0, num(getattr(account, "margin_free", 0.0)))
        if margin_required <= 0 or free_margin <= 0 or margin_required > free_margin:
            return 0.0, {**meta, "reason": "DEMO_MIN_LOT_MARGIN_BLOCK", "min_lot": min_lot, "margin_required": margin_required, "free_margin": free_margin}
        result_meta = {**meta, "reason": "DEMO_MIN_LOT_OVERRIDE", "demo_min_lot_override": True, "min_lot": min_lot, "risk_amount": risk_amount, "margin_required": margin_required, "free_margin": free_margin}
        print(
            "[V9 RISK] DEMO minimum-lot override | "
            f"candidate={candidate.get('id')} | side={side} | lot={min_lot:.4f} | risk={risk_amount:.4f} | margin={margin_required:.4f} | free_margin={free_margin:.4f}",
            flush=True,
        )
        return min_lot, result_meta

    def _fast_entry_price_safe(self, candidate, tick):
        side = str(candidate.get("side") or "").upper()
        if side not in {"BUY", "SELL"}:
            return False, "INVALID_SIDE"
        price = self.current_price(side, tick)
        sl = num(candidate.get("sl"))
        tp1 = num(candidate.get("tp1")) or num(candidate.get("tp2")) or num(candidate.get("tp3"))
        if price <= 0 or sl <= 0 or tp1 <= 0:
            return False, "INVALID_PRICE_SL_TP"
        if side == "BUY":
            if price <= sl:
                return False, "CURRENT_PRICE_AT_OR_BELOW_SL"
            if price >= tp1:
                return False, "CURRENT_PRICE_ALREADY_AT_OR_ABOVE_TP1"
        else:
            if price >= sl:
                return False, "CURRENT_PRICE_AT_OR_ABOVE_SL"
            if price <= tp1:
                return False, "CURRENT_PRICE_ALREADY_AT_OR_BELOW_TP1"
        return True, "OK"

    def confirmation_hit(self, candidate, tick):
        strength = integer(candidate.get("strength"), 0)
        if strength < self.FAST_ENTRY_MIN_STRENGTH:
            return super().confirmation_hit(candidate, tick)
        safe, reason = self._fast_entry_price_safe(candidate, tick)
        if not safe:
            self.event("FAST_ENTRY_BLOCKED", candidate.get("id"), payload={"reason": reason, "strength": strength, "threshold": self.FAST_ENTRY_MIN_STRENGTH, "timeframe": candidate.get("timeframe"), "side": candidate.get("side")})
            return False
        self.event("FAST_ENTRY_ARMED", candidate.get("id"), payload={
            "reason": "STRONG_IMPULSE_BYPASS_CONFIRMATION_ONLY", "strength": strength,
            "threshold": self.FAST_ENTRY_MIN_STRENGTH, "timeframe": candidate.get("timeframe"),
            "side": candidate.get("side"), "confirmation_price": num(candidate.get("confirmation_price")),
            "current_price": self.current_price(candidate.get("side"), tick),
        })
        return True


DemoTraderV9Final = V9HardenedV4DemoTrader
