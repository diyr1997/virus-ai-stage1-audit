from __future__ import annotations

import math
import time
from typing import Any, Iterable


def _num(value: Any, default: float = 0.0) -> float:
    try:
        value = float(value)
        return value if math.isfinite(value) else default
    except (TypeError, ValueError):
        return default


class ReverseShadowStateMachine:
    """SHADOW ONLY close-and-reverse state machine.

    This module never opens, closes or modifies positions. It only observes the
    live MT5 position list plus impulse/profit-lock snapshots and emits what the
    safe state transition WOULD be. Real execution remains disabled.
    """

    def __init__(self):
        self.state = "FLAT"
        self.pending_from_side = None
        self.pending_to_side = None
        self.pending_since = 0.0
        self.last_transition = "INIT"

    @staticmethod
    def _position_side(position) -> str:
        ptype = int(_num(getattr(position, "type", -1), -1))
        return "BUY" if ptype == 0 else "SELL" if ptype == 1 else "UNKNOWN"

    def observe(self, positions: Iterable[Any], snapshot: dict, profit_results: list[dict]) -> dict:
        positions = list(positions or [])
        sides = {self._position_side(p) for p in positions}
        sides.discard("UNKNOWN")
        now = time.time()

        direction = str(snapshot.get("direction") or "FLAT")
        impulse = _num(snapshot.get("impulse_score"))
        reversal = _num(snapshot.get("reversal_score"))
        late = _num(snapshot.get("late_penalty"))
        state_name = str(snapshot.get("state") or "UNKNOWN")
        persist = _num(snapshot.get("tick_persistence"))

        close_candidates = [
            r for r in (profit_results or [])
            if str(r.get("recommendation") or "") == "CLOSE_CANDIDATE"
        ]

        if len(sides) > 1:
            self.state = "OVERLAP_DETECTED"
            self.last_transition = "OVERLAP_DETECTED"
            return {
                "state": self.state,
                "recommendation": "SAFETY_ALERT_ONLY",
                "reason": "BUY_AND_SELL_VISIBLE_SIMULTANEOUSLY",
                "sides": sorted(sides),
                "shadow_only": True,
            }

        if sides:
            current_side = next(iter(sides))
            self.state = f"IN_{current_side}"
            opposite = "SELL" if current_side == "BUY" else "BUY"
            opposite_pressure = direction == opposite
            reverse_candidate = bool(
                opposite_pressure
                and reversal >= 60.0
                and impulse >= 60.0
                and persist >= 0.60
                and late < 60.0
                and state_name in {"TRUE_REVERSAL_CANDIDATE", "WEAKENING_IMPULSE", "NORMAL_PULLBACK"}
            )
            if close_candidates and reverse_candidate:
                self.state = f"CLOSE_CANDIDATE_{current_side}"
                self.pending_from_side = current_side
                self.pending_to_side = opposite
                self.pending_since = now
                self.last_transition = "CLOSE_THEN_WAIT_FLAT"
                recommendation = "CLOSE_THEN_WAIT_FLAT"
                reason = "PROFIT_LOCK_PLUS_OPPOSITE_REVERSAL"
            elif reverse_candidate:
                self.state = f"REVERSAL_WATCH_{current_side}_TO_{opposite}"
                recommendation = "WATCH_REVERSAL"
                reason = "OPPOSITE_REVERSAL_NOT_YET_CLOSE_CANDIDATE"
            elif close_candidates:
                self.state = f"CLOSE_CANDIDATE_{current_side}"
                recommendation = "CLOSE_ONLY_CANDIDATE"
                reason = "PROFIT_LOCK_WITHOUT_CONFIRMED_REVERSE"
            else:
                recommendation = "HOLD"
                reason = "NO_SAFE_REVERSE_TRANSITION"

            return {
                "state": self.state,
                "current_side": current_side,
                "target_side": opposite if opposite_pressure else None,
                "recommendation": recommendation,
                "reason": reason,
                "impulse_score": round(impulse, 2),
                "reversal_score": round(reversal, 2),
                "late_penalty": round(late, 2),
                "tick_persistence": round(persist, 4),
                "shadow_only": True,
            }

        # We are actually FLAT in MT5. If a prior shadow close/reverse candidate
        # existed, re-check the CURRENT signal now instead of reusing stale data.
        if self.pending_to_side:
            target = self.pending_to_side
            signal_still_valid = bool(
                direction == target
                and impulse >= 60.0
                and reversal >= 55.0
                and persist >= 0.60
                and late < 60.0
                and state_name not in {"CHOP", "NOISE", "WARMUP"}
            )
            if signal_still_valid:
                self.state = f"REVERSE_CANDIDATE_{target}"
                recommendation = "REVERSE_CANDIDATE_AFTER_FLAT_RECHECK"
                reason = "FLAT_CONFIRMED_SIGNAL_STILL_VALID"
            else:
                self.state = "FLAT"
                recommendation = "ABORT_REVERSE"
                reason = "FLAT_CONFIRMED_SIGNAL_NO_LONGER_VALID"

            result = {
                "state": self.state,
                "from_side": self.pending_from_side,
                "target_side": target,
                "recommendation": recommendation,
                "reason": reason,
                "flat_wait_sec": round(max(0.0, now - self.pending_since), 2),
                "impulse_score": round(impulse, 2),
                "reversal_score": round(reversal, 2),
                "late_penalty": round(late, 2),
                "tick_persistence": round(persist, 4),
                "shadow_only": True,
            }
            self.pending_from_side = None
            self.pending_to_side = None
            self.pending_since = 0.0
            self.last_transition = recommendation
            return result

        self.state = "FLAT"
        return {
            "state": "FLAT",
            "recommendation": "WAIT_FOR_QUALITY_SIGNAL",
            "reason": "NO_OPEN_POSITION",
            "shadow_only": True,
        }
