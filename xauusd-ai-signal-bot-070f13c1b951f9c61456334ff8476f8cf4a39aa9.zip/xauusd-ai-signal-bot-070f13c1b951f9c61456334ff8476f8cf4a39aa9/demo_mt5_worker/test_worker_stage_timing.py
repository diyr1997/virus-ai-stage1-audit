from __future__ import annotations

import traceback
import types

import pytest

from worker_stage_timing import (
    WorkerStageTimingObserver,
    _percentile,
    install_worker_timing,
)


class FakeClock:
    def __init__(self):
        self.ns = 0

    def __call__(self):
        return self.ns

    def advance_ms(self, value):
        self.ns += int(float(value) * 1_000_000)


class FakeCore:
    pass


def make_auto(clock, calls):
    core = FakeCore()

    def stage(name, result=None, advance_ms=1):
        def fn(*args, **kwargs):
            calls.append(name)
            clock.advance_ms(advance_ms)
            return result
        return fn

    core.ensure_mt5_connection = stage("ensure", result="account", advance_ms=2)
    core.get_tick = stage("tick", result="tick", advance_ms=3)
    core.save_quote = stage("quote", advance_ms=4)
    core.save_closed_m1_rates = stage("candle", result=(1, None), advance_ms=5)
    core.cleanup_old_quotes = stage("cleanup", advance_ms=6)
    core.db_connect = stage("worker_db_connect", result="conn", advance_ms=7)

    def save_worker_state(key, value):
        calls.append(f"state:{key}")
        clock.advance_ms(8)
        return None

    core.save_worker_state = save_worker_state

    class Trader:
        def connect(self):
            calls.append("trader_connect")
            clock.advance_ms(9)
            return "conn"

        def step(self, tick, account):
            calls.append("trader_step")
            clock.advance_ms(10)
            return "step-result"

        def sync_closed_trades(self):
            calls.append("sync")
            clock.advance_ms(11)
            return "sync-result"

    core.DemoTrader = Trader
    core.mt5 = types.SimpleNamespace(order_send=lambda request: "ORDER_SENT")

    auto = types.SimpleNamespace()
    auto.core = core
    auto.classify_market_state = stage("classify", result={"state": "OPEN"}, advance_ms=12)
    return auto


def test_percentile_is_deterministic():
    values = [1.0, 4.0, 2.0, 3.0]
    assert _percentile(values, 0.0) == 1.0
    assert _percentile(values, 0.5) == pytest.approx(2.5)
    assert _percentile(values, 1.0) == 4.0


def test_stage_records_duration_and_preserves_return_value():
    clock = FakeClock()
    output = []
    observer = WorkerStageTimingObserver(clock_ns=clock, emit=output.append)

    def work():
        clock.advance_ms(7.5)
        return 42

    assert observer.timed_call("work", work) == 42
    stats = observer.stats("work")
    assert stats.count == 1
    assert stats.p50_ms == pytest.approx(7.5)
    assert stats.max_ms == pytest.approx(7.5)


def test_stage_does_not_swallow_original_exception_and_keeps_origin_frame():
    clock = FakeClock()
    observer = WorkerStageTimingObserver(clock_ns=clock, emit=lambda _: None)

    def boom():
        clock.advance_ms(2)
        raise RuntimeError("original failure")

    with pytest.raises(RuntimeError, match="original failure") as exc_info:
        observer.timed_call("boom", boom)
    frames = [frame.name for frame in traceback.extract_tb(exc_info.value.__traceback__)]
    assert "boom" in frames
    assert observer.stats("boom").count == 1
    assert observer.stats("boom").p50_ms == pytest.approx(2.0)


def test_loop_start_records_start_to_start_cycle_without_sleep_patch():
    clock = FakeClock()
    observer = WorkerStageTimingObserver(clock_ns=clock, emit=lambda _: None)
    observer.mark_loop_start()
    clock.advance_ms(21_750)
    observer.mark_loop_start()
    stats = observer.stats("loop_cycle_start_to_start")
    assert stats.count == 1
    assert stats.p50_ms == pytest.approx(21_750.0)


def test_loop_cycle_survives_error_then_reconnect_boundary():
    clock = FakeClock()
    calls = []
    auto = make_auto(clock, calls)
    attempts = {"n": 0}

    def flaky_ensure():
        attempts["n"] += 1
        clock.advance_ms(5)
        if attempts["n"] == 1:
            raise ConnectionError("mt5 reconnect")
        return "account"

    auto.core.ensure_mt5_connection = flaky_ensure
    observer = WorkerStageTimingObserver(clock_ns=clock, emit=lambda _: None)
    install_worker_timing(auto, enabled=True, observer=observer)

    with pytest.raises(ConnectionError, match="mt5 reconnect"):
        auto.core.ensure_mt5_connection()
    clock.advance_ms(20_000)
    assert auto.core.ensure_mt5_connection() == "account"

    cycle = observer.stats("loop_cycle_start_to_start")
    assert cycle.count == 1
    assert cycle.p50_ms == pytest.approx(20_005.0)


def test_summary_has_p50_p95_and_max():
    clock = FakeClock()
    output = []
    observer = WorkerStageTimingObserver(
        clock_ns=clock,
        summary_interval_seconds=5,
        emit=output.append,
    )
    observer.record_ms("a", 1)
    observer.record_ms("a", 10)
    observer.maybe_emit_summary(now_ns=clock())
    clock.advance_ms(5_001)
    assert observer.maybe_emit_summary(now_ns=clock()) is True
    assert any("a:n=2" in line and "p50=" in line and "p95=" in line and "max=" in line for line in output)


def test_install_is_idempotent_and_preserves_values_and_call_order():
    clock = FakeClock()
    calls = []
    output = []
    auto = make_auto(clock, calls)
    observer = WorkerStageTimingObserver(
        clock_ns=clock,
        emit=output.append,
        slow_stage_ms=1000,
        slow_cycle_ms=5000,
    )

    installed = install_worker_timing(auto, enabled=True, observer=observer)
    assert installed is observer
    assert install_worker_timing(auto, enabled=True, observer=observer) is observer

    assert auto.core.ensure_mt5_connection() == "account"
    assert auto.core.get_tick() == "tick"
    auto.core.save_quote("tick")
    assert auto.core.save_closed_m1_rates(10) == (1, None)
    assert auto.classify_market_state(None, "tick") == {"state": "OPEN"}
    auto.core.save_worker_state("heartbeat", {"alive": True})

    trader = auto.core.DemoTrader()
    assert trader.connect() == "conn"
    assert trader.step("tick", "account") == "step-result"
    assert trader.sync_closed_trades() == "sync-result"

    assert calls == [
        "ensure",
        "tick",
        "quote",
        "candle",
        "classify",
        "state:heartbeat",
        "trader_connect",
        "trader_step",
        "sync",
    ]
    assert observer.stats("ensure_mt5_connection").p50_ms == pytest.approx(2)
    assert observer.stats("get_tick").p50_ms == pytest.approx(3)
    assert observer.stats("save_quote").p50_ms == pytest.approx(4)
    assert observer.stats("candle_sync").p50_ms == pytest.approx(5)
    assert observer.stats("classify_market_state").p50_ms == pytest.approx(12)
    assert observer.stats("save_worker_state.heartbeat").p50_ms == pytest.approx(8)
    assert observer.stats("trader_db_connect").p50_ms == pytest.approx(9)
    assert observer.stats("trader_step").p50_ms == pytest.approx(10)
    assert observer.stats("sync_closed_trades").p50_ms == pytest.approx(11)
    assert any("diagnostics_only=YES" in line for line in output)


def test_class_level_wrapper_preserves_normal_bound_method_self_binding():
    clock = FakeClock()
    calls = []
    auto = make_auto(clock, calls)
    seen = []

    class BoundTrader:
        def connect(self):
            seen.append(self)
            clock.advance_ms(3)
            return id(self)

        def step(self, tick, account):
            seen.append(self)
            clock.advance_ms(4)
            return id(self)

        def sync_closed_trades(self):
            seen.append(self)
            clock.advance_ms(5)
            return id(self)

    auto.core.DemoTrader = BoundTrader
    observer = WorkerStageTimingObserver(clock_ns=clock, emit=lambda _: None)
    install_worker_timing(auto, enabled=True, observer=observer)

    trader = BoundTrader()
    assert trader.connect() == id(trader)
    assert trader.step("tick", "account") == id(trader)
    assert trader.sync_closed_trades() == id(trader)
    assert seen == [trader, trader, trader]


def test_nested_trader_step_and_connect_are_both_visible_not_additive_contract():
    clock = FakeClock()
    calls = []
    auto = make_auto(clock, calls)

    class NestedTrader:
        def connect(self):
            clock.advance_ms(6)
            return "conn"

        def step(self, tick, account):
            self.connect()
            clock.advance_ms(4)
            return "ok"

        def sync_closed_trades(self):
            return None

    auto.core.DemoTrader = NestedTrader
    observer = WorkerStageTimingObserver(clock_ns=clock, emit=lambda _: None)
    install_worker_timing(auto, enabled=True, observer=observer)
    assert NestedTrader().step("tick", "account") == "ok"
    assert observer.stats("trader_db_connect").p50_ms == pytest.approx(6)
    assert observer.stats("trader_step").p50_ms == pytest.approx(10)


def test_install_after_watchdog_guard_times_final_guarded_callable():
    clock = FakeClock()
    calls = []
    auto = make_auto(clock, calls)
    original_quote = auto.core.save_quote

    def guarded_quote(tick):
        calls.append("watchdog_guard")
        return original_quote(tick)

    auto.core.save_quote = guarded_quote
    observer = WorkerStageTimingObserver(clock_ns=clock, emit=lambda _: None)
    install_worker_timing(auto, enabled=True, observer=observer)
    auto.core.save_quote("tick")
    assert calls == ["watchdog_guard", "quote"]
    assert observer.stats("save_quote").p50_ms == pytest.approx(4)


def test_order_api_is_not_wrapped_or_called_by_installation():
    clock = FakeClock()
    calls = []
    auto = make_auto(clock, calls)
    original_order_send = auto.core.mt5.order_send
    observer = WorkerStageTimingObserver(clock_ns=clock, emit=lambda _: None)
    install_worker_timing(auto, enabled=True, observer=observer)
    assert auto.core.mt5.order_send is original_order_send
    assert calls == []


def test_disabled_install_changes_nothing():
    clock = FakeClock()
    calls = []
    auto = make_auto(clock, calls)
    original = auto.core.get_tick
    assert install_worker_timing(auto, enabled=False) is None
    assert auto.core.get_tick is original


def test_environment_gate_defaults_off_and_can_enable(monkeypatch):
    clock = FakeClock()
    calls = []
    auto = make_auto(clock, calls)
    monkeypatch.delenv("WORKER_TIMING_ENABLED", raising=False)
    assert install_worker_timing(auto) is None

    auto2 = make_auto(clock, [])
    monkeypatch.setenv("WORKER_TIMING_ENABLED", "1")
    assert install_worker_timing(
        auto2,
        observer=WorkerStageTimingObserver(clock_ns=clock, emit=lambda _: None),
    ) is not None


def test_slow_stage_logging_is_rate_limited_per_stage():
    clock = FakeClock()
    output = []
    observer = WorkerStageTimingObserver(
        clock_ns=clock,
        emit=output.append,
        slow_stage_ms=10,
        slow_cycle_ms=20,
        slow_log_interval_seconds=30,
    )
    observer.record_ms("trader_step", 10.1)
    clock.advance_ms(1_000)
    observer.record_ms("trader_step", 20.0)
    clock.advance_ms(29_000)
    observer.record_ms("trader_step", 30.0)

    slow = [line for line in output if "[WORKER TIMING] SLOW" in line]
    assert len(slow) == 2
    assert "suppressed_since_last=0" in slow[0]
    assert "suppressed_since_last=1" in slow[1]


def test_slow_cycle_and_slow_stage_have_independent_rate_limits():
    clock = FakeClock()
    output = []
    observer = WorkerStageTimingObserver(
        clock_ns=clock,
        emit=output.append,
        slow_stage_ms=10,
        slow_cycle_ms=20,
        slow_log_interval_seconds=30,
    )
    observer.record_ms("trader_step", 10.1)
    observer.record_ms("loop_cycle_start_to_start", 20.1)
    slow = [line for line in output if "[WORKER TIMING] SLOW" in line]
    assert len(slow) == 2
    assert any("stage=trader_step" in line for line in slow)
    assert any("stage=loop_cycle_start_to_start" in line for line in slow)
