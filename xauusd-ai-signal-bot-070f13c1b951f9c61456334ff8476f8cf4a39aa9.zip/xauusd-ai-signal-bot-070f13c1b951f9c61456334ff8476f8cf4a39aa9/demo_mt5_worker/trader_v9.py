from __future__ import annotations

import json
import os
import time
import uuid
from datetime import datetime, timedelta, timezone

from psycopg2.extras import Json

from trader_legacy import DemoTrader as LegacyDemoTrader
from trader_legacy import integer, num, strength_lot_cap, utcnow
from worker_ownership import WorkerOwnershipLock


class BasketStateMachine:
    STATES = {"FLAT", "LONG", "SHORT", "CONFIRMING", "CLOSING", "RECONCILING", "ERROR"}
    ALLOWED = {
        "FLAT": {"LONG", "SHORT", "ERROR"},
        "LONG": {"CONFIRMING", "CLOSING", "ERROR"},
        "SHORT": {"CONFIRMING", "CLOSING", "ERROR"},
        "CONFIRMING": {"LONG", "SHORT", "CLOSING", "ERROR"},
        "CLOSING": {"RECONCILING", "ERROR"},
        "RECONCILING": {"FLAT", "LONG", "SHORT", "ERROR"},
        "ERROR": {"RECONCILING", "FLAT"},
    }

    @classmethod
    def can_transition(cls, current, target):
        current = str(current or "").upper()
        target = str(target or "").upper()
        return current in cls.STATES and target in cls.ALLOWED.get(current, set())

    @staticmethod
    def from_sides(sides):
        sides = {str(x).upper() for x in (sides or []) if str(x).upper() in {"BUY", "SELL"}}
        if not sides:
            return "FLAT"
        if sides == {"BUY"}:
            return "LONG"
        if sides == {"SELL"}:
            return "SHORT"
        return "ERROR"


class V9DemoTrader(LegacyDemoTrader):
    """Canonical DEMO trader V9 with fenced ownership and global basket risk."""

    CLAIM_GRACE_SECONDS = max(3.0, float(os.getenv("V9_CLAIM_GRACE_SECONDS", "5")))
    HISTORY_LOOKBACK_MINUTES = max(5, int(os.getenv("V9_RECONCILE_HISTORY_MINUTES", "15")))

    def ensure_schema(self):
        super().ensure_schema()
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute("ALTER TABLE demo_trades ADD COLUMN IF NOT EXISTS basket_id TEXT")
                cur.execute("ALTER TABLE demo_trades ADD COLUMN IF NOT EXISTS order_claim_key TEXT")
                cur.execute("ALTER TABLE demo_trades ADD COLUMN IF NOT EXISTS fence_token BIGINT")
                cur.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_demo_trades_order_claim_key ON demo_trades(order_claim_key) WHERE order_claim_key IS NOT NULL")
                cur.execute("CREATE INDEX IF NOT EXISTS ix_demo_trades_basket_active ON demo_trades(symbol,basket_id,status)")
        finally:
            conn.close()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.ownership = WorkerOwnershipLock(self.database_url)
        self._last_ownership_block_event = 0.0
        self._last_reconcile_block_event = 0.0
        self.reversal_enabled = str(os.getenv("DEMO_REVERSAL_ENABLED", "0")).strip().lower() in {"1", "true", "yes", "on"}

    def risk_mode(self):
        mode, base_profile = super().risk_mode()
        profile = dict(base_profile)
        profile.pop("max_positions", None)
        profile["initial_slots"] = 1
        return mode, profile

    def bot_mt5_positions(self):
        positions = self.mt5.positions_get(symbol=self.symbol)
        if positions is None:
            return []
        return [p for p in positions if integer(getattr(p, "magic", 0), 0) == self.magic]

    def mt5_position_side(self, position):
        ptype = integer(getattr(position, "type", -1), -1)
        if ptype == integer(getattr(self.mt5, "POSITION_TYPE_BUY", -10), -10):
            return "BUY"
        if ptype == integer(getattr(self.mt5, "POSITION_TYPE_SELL", -11), -11):
            return "SELL"
        return ""

    def live_sides(self):
        sides = {self.mt5_position_side(p) for p in self.bot_mt5_positions()}
        sides.discard("")
        return sides

    def direction_guard(self, requested_side):
        requested_side = str(requested_side or "").upper()
        if requested_side not in {"BUY", "SELL"}:
            return False, "INVALID_SIDE", []
        sides = self.live_sides()
        if len(sides) > 1:
            return False, "HEDGE_ALREADY_PRESENT", sorted(sides)
        if sides and requested_side not in sides:
            active = next(iter(sides))
            return False, f"ACTIVE_{active}_BLOCKS_{requested_side}", sorted(sides)
        return True, "OK", sorted(sides)

    def current_state(self):
        return BasketStateMachine.from_sides(self.live_sides())

    def _active_trade_rows(self):
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT id,candidate_id,side,lot,COALESCE(entry_price,planned_price) AS entry_price,
                           sl,payload,status,created_at,opened_at,mt5_ticket,basket_id,order_claim_key,fence_token
                    FROM demo_trades
                    WHERE symbol=%s AND status IN('PENDING','OPEN')
                    ORDER BY id ASC
                    """,
                    (self.symbol,),
                )
                names = [d[0] for d in cur.description]
                return [dict(zip(names, row)) for row in cur.fetchall()]
        finally:
            conn.close()

    def _db_open_ticket_map(self):
        result = {}
        for row in self._active_trade_rows():
            if row.get("status") != "OPEN":
                continue
            ticket = integer(row.get("mt5_ticket"), 0)
            if ticket:
                result[ticket] = row
        return result

    @staticmethod
    def _position_comment(position):
        return str(getattr(position, "comment", "") or "")

    def _position_for_trade_id(self, trade_id):
        needle = f"t{int(trade_id)}"
        matches = [p for p in self.bot_mt5_positions() if needle in self._position_comment(p)]
        return matches[0] if len(matches) == 1 else None

    def _history_deal_for_trade_id(self, trade_id):
        getter = getattr(self.mt5, "history_deals_get", None)
        if not callable(getter):
            return None
        now = datetime.now(timezone.utc)
        try:
            deals = getter(now - timedelta(minutes=self.HISTORY_LOOKBACK_MINUTES), now + timedelta(seconds=5)) or []
        except Exception:
            return None
        needle = f"t{int(trade_id)}"
        matches = [d for d in deals if integer(getattr(d, "magic", 0), 0) == self.magic and needle in str(getattr(d, "comment", "") or "")]
        return matches[-1] if matches else None

    def _mark_reconciled_history(self, trade_id, deal):
        ticket = integer(getattr(deal, "order", 0), 0) or integer(getattr(deal, "ticket", 0), 0)
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE demo_trades
                    SET status='CLOSED', closed_at=COALESCE(closed_at,NOW()), mt5_ticket=COALESCE(mt5_ticket,%s),
                        close_reason=COALESCE(close_reason,'RECONCILED_HISTORY'),
                        payload=COALESCE(payload,'{}'::jsonb) || %s::jsonb
                    WHERE id=%s AND status='PENDING'
                    """,
                    (str(ticket) if ticket else None, json.dumps({"reconciled_from_history": True}), int(trade_id)),
                )
        finally:
            conn.close()

    def reconcile_pending_claims(self):
        rows = [r for r in self._active_trade_rows() if r.get("status") == "PENDING"]
        for row in rows:
            trade_id = int(row["id"])
            live = self._position_for_trade_id(trade_id)
            if live is not None:
                entry = num(getattr(live, "price_open", 0.0)) or num(row.get("entry_price"))
                self.mark_open(trade_id, integer(getattr(live, "ticket", 0), 0), entry, num(row.get("entry_price")) or entry, {"reconciled_after_restart": True})
                continue
            created = row.get("created_at")
            if created is None:
                continue
            if created.tzinfo is None:
                created = created.replace(tzinfo=timezone.utc)
            age = max(0.0, (utcnow() - created).total_seconds())
            if age < self.CLAIM_GRACE_SECONDS:
                continue
            deal = self._history_deal_for_trade_id(trade_id)
            if deal is not None:
                self._mark_reconciled_history(trade_id, deal)
                continue
            payload = row.get("payload") or {}
            if isinstance(payload, str):
                try:
                    payload = json.loads(payload)
                except Exception:
                    payload = {}
            self.reject_trade(trade_id, "STALE_CLAIM_NO_MT5_EVIDENCE", {"age_sec": age, "send_attempted": bool(payload.get("send_attempted"))})

    def unknown_live_positions(self):
        known = self._db_open_ticket_map()
        return [p for p in self.bot_mt5_positions() if integer(getattr(p, "ticket", 0), 0) not in known]

    def reconcile_or_fail_closed(self):
        self.reconcile_pending_claims()
        unknown = self.unknown_live_positions()
        if not unknown:
            return True
        now = time.monotonic()
        if now - self._last_reconcile_block_event >= 15.0:
            self.event("RECONCILE_BLOCKED", payload={"reason": "UNKNOWN_LIVE_MT5_POSITION", "tickets": [str(integer(getattr(p, "ticket", 0), 0)) for p in unknown]})
            self._last_reconcile_block_event = now
        return False

    def active_basket_id(self, side, create_if_flat=False):
        side = str(side or "").upper()
        rows = [r for r in self._active_trade_rows() if str(r.get("side") or "").upper() == side]
        basket_ids = {str(r.get("basket_id")) for r in rows if r.get("basket_id")}
        if len(basket_ids) > 1:
            return None
        if basket_ids:
            basket_id = next(iter(basket_ids))
            if any(not r.get("basket_id") for r in rows):
                conn = self.connect()
                try:
                    with conn.cursor() as cur:
                        cur.execute("UPDATE demo_trades SET basket_id=%s WHERE symbol=%s AND UPPER(side)=%s AND status IN('PENDING','OPEN') AND basket_id IS NULL", (basket_id, self.symbol, side))
                finally:
                    conn.close()
            return basket_id
        if rows:
            basket_id = f"{self.symbol}:{side}:{uuid.uuid4().hex}"
            conn = self.connect()
            try:
                with conn.cursor() as cur:
                    cur.execute("UPDATE demo_trades SET basket_id=%s WHERE symbol=%s AND UPPER(side)=%s AND status IN('PENDING','OPEN') AND basket_id IS NULL", (basket_id, self.symbol, side))
            finally:
                conn.close()
            return basket_id
        return f"{self.symbol}:{side}:{uuid.uuid4().hex}" if create_if_flat else None

    def basket_risk_trades(self, side, basket_id=None):
        side = str(side or "").upper()
        basket_id = basket_id or self.active_basket_id(side, create_if_flat=False)
        if not basket_id:
            return []
        return [r for r in self._active_trade_rows() if str(r.get("side") or "").upper() == side and str(r.get("basket_id") or "") == str(basket_id)]

    def all_active_risk_trades(self):
        return self._active_trade_rows()

    def next_basket_slot(self, side, basket_id):
        db_count = len(self.basket_risk_trades(side, basket_id))
        live_count = sum(1 for p in self.bot_mt5_positions() if self.mt5_position_side(p) == str(side).upper())
        return max(db_count, live_count) + 1

    def last_symbol_entry_age(self):
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT MAX(opened_at) FROM demo_trades WHERE symbol=%s AND status='OPEN'", (self.symbol,))
                row = cur.fetchone()
        finally:
            conn.close()
        opened_at = row[0] if row else None
        if not opened_at:
            return float("inf")
        if opened_at.tzinfo is None:
            opened_at = opened_at.replace(tzinfo=timezone.utc)
        return max(0.0, (utcnow() - opened_at).total_seconds())

    def executable_basket_profit(self, side, positions, tick):
        side = str(side or "").upper()
        exit_price = num(getattr(tick, "bid", 0.0)) if side == "BUY" else num(getattr(tick, "ask", 0.0))
        if exit_price <= 0:
            return 0.0
        total = 0.0
        for position in positions:
            lot = max(0.0, num(getattr(position, "volume", 0.0)))
            entry = num(getattr(position, "price_open", 0.0))
            if lot <= 0 or entry <= 0:
                continue
            calc = self.mt5.order_calc_profit(self.order_type(side), float(lot), float(entry), float(exit_price))
            total += num(calc if calc is not None else getattr(position, "profit", 0.0))
        return total

    def choose_volume(self, candidate, account, profile, price):
        strength = integer(candidate["strength"])
        side = str(candidate["side"]).upper()
        sl = num(candidate["sl"])
        cap = strength_lot_cap(strength)
        if strength < 60 or cap <= 0 or sl <= 0:
            return 0.0, {"reason": "NO_SAFE_SIGNAL_OR_SL", "strength": strength, "strength_cap": cap}
        if not self.reconcile_or_fail_closed():
            return 0.0, {"reason": "LIVE_DB_RECONCILIATION_REQUIRED"}
        balance = max(0.0, num(getattr(account, "balance", 0.0)))
        equity = max(0.0, num(getattr(account, "equity", 0.0)))
        margin = max(0.0, num(getattr(account, "margin", 0.0)))
        free_margin = max(0.0, num(getattr(account, "margin_free", 0.0)))
        if balance <= 0 or equity <= 0:
            return 0.0, {"reason": "NO_BALANCE_OR_EQUITY"}
        risk_base = min(balance, equity)
        basket_id = candidate.get("_v9_basket_id") or self.active_basket_id(side, create_if_flat=True)
        basket_open = self.basket_risk_trades(side, basket_id)
        all_open = self.all_active_risk_trades()
        scenario_budget = risk_base * profile["scenario_risk_pct"] / 100.0
        portfolio_budget = risk_base * profile["portfolio_risk_pct"] / 100.0
        scenario_used = self.used_risk(basket_open)
        portfolio_used = self.used_risk(all_open)
        available_risk = min(max(0.0, scenario_budget - scenario_used), max(0.0, portfolio_budget - portfolio_used))
        risk_one_lot = self.risk_money(side, 1.0, price, sl)
        if available_risk <= 0:
            return 0.0, {"reason": "RISK_BUDGET_FULL", "basket_id": basket_id, "scenario_budget": scenario_budget, "scenario_used": scenario_used, "portfolio_budget": portfolio_budget, "portfolio_used": portfolio_used}
        if risk_one_lot <= 0:
            return 0.0, {"reason": "SL_RISK_CALC_FAILED"}
        lot_by_risk = available_risk / risk_one_lot
        vmin, vmax, vstep = self.volume_rules()
        lot = self.floor_volume(min(cap, lot_by_risk), vmin, vmax, vstep)
        if lot <= 0:
            return 0.0, {"reason": "RISK_TOO_SMALL_FOR_MIN_LOT", "lot_by_risk": lot_by_risk, "min_lot": vmin}
        reserve = risk_base * profile["free_margin_reserve_pct"] / 100.0
        spendable = max(0.0, free_margin - reserve)
        while lot >= vmin:
            required_margin = self.mt5.order_calc_margin(self.order_type(side), float(lot), float(price))
            required_margin_value = num(required_margin) if required_margin is not None else 0.0
            if required_margin is not None and required_margin_value > 0 and required_margin_value <= spendable:
                return lot, {"reason": "OK", "basket_id": basket_id, "risk_amount": self.risk_money(side, lot, price, sl), "scenario_budget": scenario_budget, "scenario_used": scenario_used, "portfolio_budget": portfolio_budget, "portfolio_used": portfolio_used, "balance_before": balance, "equity_before": equity, "risk_base": risk_base, "margin_before": margin, "free_margin_before": free_margin, "required_margin": required_margin_value, "projected_free_margin": max(0.0, free_margin - required_margin_value), "reserve_required": reserve, "strength": strength, "strength_cap": cap}
            lot = self.floor_volume(lot - vstep, vmin, vmax, vstep)
            if lot <= 0:
                break
        return 0.0, {"reason": "NOT_ENOUGH_SAFE_MARGIN", "free_margin_before": free_margin, "reserve_required": reserve}

    def slot_allowed(self, candidate, slot_no, tick, profile):
        side = str(candidate.get("side") or "").upper()
        ok, reason, live_sides = self.direction_guard(side)
        if not ok:
            self.event("ADD_BLOCKED", candidate.get("id"), payload={"reason": reason, "live_sides": live_sides})
            return False
        same_side = [p for p in self.bot_mt5_positions() if self.mt5_position_side(p) == side]
        if not same_side:
            return int(slot_no) == 1
        basket_profit = self.executable_basket_profit(side, same_side, tick)
        min_profit = num(os.getenv("IMPULSE_ADD_MIN_BASKET_PROFIT", "0.0"), 0.0)
        if basket_profit <= min_profit:
            self.event("ADD_BLOCKED", candidate.get("id"), payload={"reason": "BASKET_NOT_PROFITABLE", "basket_profit": basket_profit})
            return False
        gap = int(profile["min_entry_gap_sec"])
        age = self.last_symbol_entry_age()
        if age < gap:
            self.event("ADD_BLOCKED", candidate.get("id"), payload={"reason": "GLOBAL_ENTRY_GAP", "age_sec": age, "required_sec": gap})
            return False
        total_volume = sum(max(0.0, num(getattr(p, "volume", 0.0))) for p in same_side)
        if total_volume <= 0:
            return False
        weighted_entry = sum(num(getattr(p, "price_open", 0.0)) * max(0.0, num(getattr(p, "volume", 0.0))) for p in same_side) / total_volume
        live_exit = num(getattr(tick, "bid", 0.0)) if side == "BUY" else num(getattr(tick, "ask", 0.0))
        progress = live_exit - weighted_entry if side == "BUY" else weighted_entry - live_exit
        if live_exit <= 0 or progress <= 0:
            return False
        confirm = num(candidate.get("confirmation_price"))
        tp1 = num(candidate.get("tp1"))
        sl = num(candidate.get("sl"))
        reference = abs(tp1 - confirm)
        if reference <= 0:
            reference = abs(confirm - sl) * 0.5
        reference = max(reference, 0.01)
        add_number = max(1, int(slot_no) - 1)
        required = reference * num(profile.get("add_step_ratio"), 0.15) * add_number
        required = max(required, max(0.0, num(os.getenv("IMPULSE_ADD_MIN_PRICE_PROGRESS", "0.0"), 0.0)))
        if progress < required:
            self.event("ADD_BLOCKED", candidate.get("id"), payload={"reason": "PRICE_PROGRESS_TOO_SMALL", "progress": progress, "required": required, "basket_slot": slot_no})
            return False
        return True

    def _claim_key(self, basket_id, slot_no):
        return f"{self.symbol}|{basket_id}|slot:{int(slot_no)}"

    def claim_pending_trade(self, candidate, lot, price, tp, account, mode, slot_no, risk_meta, basket_id, fence_token):
        claim_key = self._claim_key(basket_id, slot_no)
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO demo_trades(candidate_id,analysis_id,symbol,timeframe,side,lot,planned_price,sl,tp,tp1,tp2,tp3,status,demo_account,payload,basket_id,order_claim_key,fence_token)
                    VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,'PENDING',%s,%s,%s,%s,%s)
                    ON CONFLICT(order_claim_key) DO NOTHING
                    RETURNING id
                    """,
                    (int(candidate["id"]), int(candidate["analysis_id"]), self.symbol, str(candidate["timeframe"]), str(candidate["side"]).upper(), float(lot), float(price), num(candidate["sl"]) or None, tp or None, num(candidate["tp1"]) or None, num(candidate["tp2"]) or None, num(candidate["tp3"]) or None, str(getattr(account, "login", "")), Json({"risk_mode": mode, "slot_no": slot_no, **risk_meta}), str(basket_id), claim_key, int(fence_token)),
                )
                row = cur.fetchone()
                return int(row[0]) if row else None
        finally:
            conn.close()

    def _set_pending_payload(self, trade_id, patch):
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute("UPDATE demo_trades SET payload=COALESCE(payload,'{}'::jsonb) || %s::jsonb WHERE id=%s AND status='PENDING'", (json.dumps(patch or {}), int(trade_id)))
        finally:
            conn.close()

    def _final_send_guard(self, side, fence_token):
        if not self.ownership.is_current(fence_token, force=True):
            return False, "STALE_OR_LOST_FENCE"
        ok, reason, _ = self.direction_guard(side)
        if not ok:
            return False, reason
        if self.unknown_live_positions():
            return False, "UNKNOWN_LIVE_MT5_POSITION"
        return True, "OK"

    def send_order(self, candidate, tick, account, lot, mode, slot_no, risk_meta):
        self.assert_demo(account)
        side = str(candidate["side"]).upper()
        price = self.current_price(side, tick)
        sl = num(candidate["sl"])
        tp = self.tp_for_slot(candidate, slot_no)
        basket_id = str(candidate.get("_v9_basket_id") or "")
        fence_token = self.ownership.current_token()
        if side not in {"BUY", "SELL"} or lot <= 0 or price <= 0 or sl <= 0 or tp <= 0 or not basket_id or fence_token is None:
            return False
        trade_id = self.claim_pending_trade(candidate, lot, price, tp, account, mode, slot_no, risk_meta, basket_id, fence_token)
        if trade_id is None:
            self.event("ORDER_CLAIM_BLOCKED", candidate.get("id"), payload={"basket_id": basket_id, "slot_no": slot_no})
            return False
        before = self.matching_position_tickets(side)
        accepted = {integer(getattr(self.mt5, "TRADE_RETCODE_DONE", 10009)), integer(getattr(self.mt5, "TRADE_RETCODE_DONE_PARTIAL", 10010)), integer(getattr(self.mt5, "TRADE_RETCODE_PLACED", 10008))}
        last_details = {"stage": "not_sent"}
        ambiguous_send = False
        for filling in self.fill_modes():
            request = {"action": self.mt5.TRADE_ACTION_DEAL, "symbol": self.symbol, "volume": float(lot), "type": self.order_type(side), "price": float(price), "sl": float(sl), "tp": float(tp), "deviation": int(self.deviation), "magic": int(self.magic), "comment": f"XDV9 t{trade_id} f{fence_token}"[:31], "type_time": self.mt5.ORDER_TIME_GTC, "type_filling": filling}
            check = self.mt5.order_check(request)
            if check is None:
                last_details = {"stage": "order_check", "error": str(self.mt5.last_error()), "filling": filling}
                continue
            check_retcode = integer(getattr(check, "retcode", -1), -1)
            check_ok = {0, integer(getattr(self.mt5, "TRADE_RETCODE_DONE", 10009))}
            if check_retcode not in check_ok:
                last_details = {"stage": "order_check", "retcode": check_retcode, "comment": str(getattr(check, "comment", "")), "filling": filling}
                continue
            guard_ok, guard_reason = self._final_send_guard(side, fence_token)
            if not guard_ok:
                self.reject_trade(trade_id, "FINAL_SEND_GUARD_BLOCKED", {"reason": guard_reason, "fence_token": fence_token})
                self.event("ORDER_SEND_BLOCKED", candidate.get("id"), trade_id, {"reason": guard_reason})
                return False
            self._set_pending_payload(trade_id, {"send_attempted": True, "send_attempted_at": utcnow().isoformat(), "fence_token": fence_token})
            result = self.mt5.order_send(request)
            if result is None:
                ambiguous_send = True
                last_details = {"stage": "order_send_ambiguous", "error": str(self.mt5.last_error()), "filling": filling}
                break
            retcode = integer(getattr(result, "retcode", -1), -1)
            if retcode not in accepted:
                last_details = {"stage": "order_send", "retcode": retcode, "comment": str(getattr(result, "comment", "")), "filling": filling}
                continue
            time.sleep(0.2)
            after = self.matching_position_tickets(side)
            new_tickets = list(after - before)
            ticket = new_tickets[0] if new_tickets else integer(getattr(result, "order", 0) or getattr(result, "deal", 0))
            entry = num(getattr(result, "price", 0.0), price) or price
            self.mark_open(trade_id, ticket, entry, price, {"order_id": str(getattr(result, "order", "")), "deal_id": str(getattr(result, "deal", "")), "retcode": retcode, "filling": filling, "basket_id": basket_id, "fence_token": fence_token})
            self.update_candidate_status(candidate["id"], "ACTIVE")
            self.event("TRADE_OPENED", candidate["id"], trade_id, {"side": side, "lot": lot, "slot_no": slot_no, "risk_mode": mode, "entry": entry, "sl": sl, "tp": tp, "risk_amount": risk_meta.get("risk_amount"), "ticket": str(ticket), "basket_id": basket_id, "fence_token": fence_token})
            return True
        if ambiguous_send:
            self._set_pending_payload(trade_id, {"ambiguous_send": True, **last_details})
            self.event("ORDER_SEND_AMBIGUOUS", candidate["id"], trade_id, last_details)
            return False
        self.reject_trade(trade_id, "ORDER_REJECTED", last_details)
        self.event("ORDER_REJECTED", candidate["id"], trade_id, last_details)
        return False

    def _ownership_ok(self):
        return bool(self.ownership.ensure_owned())

    def _opposite_signal_shadow(self, candidate):
        side = str(candidate.get("side") or "").upper()
        live = self.live_sides()
        if not live or side in live:
            return False
        self.event("REVERSAL_SHADOW" if not self.reversal_enabled else "REVERSAL_NOT_IMPLEMENTED_SAFE_BLOCK", candidate.get("id"), payload={"requested_side": side, "live_sides": sorted(live), "state": self.current_state(), "reversal_enabled": self.reversal_enabled})
        return True

    def step(self, tick, account):
        self.assert_demo(account)
        if not self._ownership_ok():
            now = time.monotonic()
            if now - self._last_ownership_block_event >= 15.0:
                self.event("WORKER_OWNERSHIP_BLOCKED", payload={"reason": "FENCED_POSTGRES_OWNER_NOT_HELD"})
                self._last_ownership_block_event = now
            return
        if not self.reconcile_or_fail_closed():
            return
        mode, profile = self.risk_mode()
        safe, reason = self.account_allows_new_trade(account, profile)
        if not safe:
            if time.monotonic() - self.last_status_write >= 30:
                self.set_setting("demo_trader_status", f"PAUSED|{mode}|{reason}")
                self.last_status_write = time.monotonic()
            return
        candidates = self.load_candidates()
        latest_analyses = self.load_latest_analyses() if candidates else {}
        for candidate in candidates:
            cid = int(candidate["id"])
            strength = integer(candidate["strength"])
            if strength < 60:
                self.update_candidate_status(cid, "NO_ENTRY")
                continue
            expires_at = candidate.get("expires_at")
            if expires_at:
                if expires_at.tzinfo is None:
                    expires_at = expires_at.replace(tzinfo=timezone.utc)
                if utcnow() >= expires_at:
                    if not self.candidate_trades(cid, open_only=True):
                        self.update_candidate_status(cid, "EXPIRED")
                    continue
            candidate_open = self.candidate_trades(cid, open_only=True)
            latest = latest_analyses.get(str(candidate["timeframe"]).upper())
            cancel_reason = None if candidate_open else self.scenario_cancellation_reason(candidate, latest)
            if cancel_reason:
                self.update_candidate_status(cid, "CANCELLED")
                self.event("SCENARIO_CANCELLED", cid, payload={"reason": cancel_reason, "timeframe": candidate["timeframe"], "side": candidate["side"]})
                continue
            if candidate["status"] == "WAIT_CONFIRMATION":
                if not self.confirmation_hit(candidate, tick):
                    continue
                self.update_candidate_status(cid, "CONFIRMED")
                candidate["status"] = "CONFIRMED"
            allowed, guard_reason = self.latest_analysis_allows_add(candidate, latest)
            if not allowed:
                self.event("ADD_BLOCKED", cid, payload={"reason": guard_reason})
                continue
            if self._opposite_signal_shadow(candidate):
                continue
            side = str(candidate["side"]).upper()
            direction_ok, direction_reason, live_sides = self.direction_guard(side)
            if not direction_ok:
                self.event("DIRECTION_BLOCKED", cid, payload={"requested_side": side, "reason": direction_reason, "live_sides": live_sides})
                continue
            basket_id = self.active_basket_id(side, create_if_flat=True)
            if not basket_id:
                self.event("ENTRY_SKIPPED", cid, payload={"reason": "AMBIGUOUS_ACTIVE_BASKET"})
                continue
            candidate["_v9_basket_id"] = basket_id
            slot_no = self.next_basket_slot(side, basket_id)
            if not self.slot_allowed(candidate, slot_no, tick, profile):
                continue
            price = self.current_price(side, tick)
            lot, risk_meta = self.choose_volume(candidate, account, profile, price)
            if lot <= 0:
                self.event("ENTRY_SKIPPED", cid, payload={"slot_no": slot_no, "risk_mode": mode, **risk_meta})
                continue
            if self.send_order(candidate, tick, account, lot, mode, slot_no, risk_meta):
                break
        if time.monotonic() - self.last_status_write >= 30:
            token = self.ownership.current_token()
            self.set_setting("demo_trader_status", f"READY|{mode}|v9_fenced_dynamic_basket|fence={token}|equity={num(account.equity):.2f}|free_margin={num(account.margin_free):.2f}")
            self.last_status_write = time.monotonic()
