from __future__ import annotations

import json
import os
import time
from datetime import timezone

from trader_legacy import integer, num, utcnow
from trader_v9_hardened import V9HardenedDemoTrader


class Mt5StateUnavailable(RuntimeError):
    pass


class V9HardenedV2DemoTrader(V9HardenedDemoTrader):
    """Final V9 hardening pass after Council review.

    Important safety invariant for the unavoidable external-side-effect window:
    `send_attempted=true` is committed to PostgreSQL BEFORE the final forced fence
    check and before MT5 order_send. If the DB ownership session dies after the
    fence check, a replacement worker sees the unresolved claim and is fail-closed,
    so it cannot duplicate the external send.
    """

    UNRESOLVED_AFTER_SECONDS = max(
        15.0, float(os.getenv("V9_UNRESOLVED_AFTER_SECONDS", "60"))
    )

    def ensure_schema(self):
        super().ensure_schema()
        conn = self.connect()
        old_autocommit = getattr(conn, "autocommit", True)
        try:
            conn.autocommit = False
            with conn.cursor() as cur:
                cur.execute("CREATE SEQUENCE IF NOT EXISTS demo_basket_id_seq")
                cur.execute(
                    """
                    WITH groups AS (
                        SELECT symbol, UPPER(side) AS side,
                               'B' || nextval('demo_basket_id_seq')::text AS basket_id
                        FROM demo_trades
                        WHERE status IN('PENDING','OPEN','UNRESOLVED')
                          AND basket_id IS NULL
                        GROUP BY symbol, UPPER(side)
                    )
                    UPDATE demo_trades d
                    SET basket_id = g.basket_id
                    FROM groups g
                    WHERE d.symbol = g.symbol
                      AND UPPER(d.side) = g.side
                      AND d.status IN('PENDING','OPEN','UNRESOLVED')
                      AND d.basket_id IS NULL
                    """
                )
                cur.execute(
                    """
                    WITH ranked AS (
                        SELECT id,
                               ROW_NUMBER() OVER (
                                   PARTITION BY basket_id
                                   ORDER BY COALESCE(opened_at, created_at), id
                               ) AS rn
                        FROM demo_trades
                        WHERE status IN('PENDING','OPEN','UNRESOLVED')
                          AND basket_id IS NOT NULL
                          AND basket_slot IS NULL
                    )
                    UPDATE demo_trades d
                    SET basket_slot = ranked.rn
                    FROM ranked
                    WHERE d.id = ranked.id
                    """
                )
                cur.execute(
                    """
                    UPDATE demo_trades
                    SET order_claim_key = 'LEGACY|' || basket_id || '|trade:' || id::text
                    WHERE status IN('PENDING','OPEN','UNRESOLVED')
                      AND basket_id IS NOT NULL
                      AND order_claim_key IS NULL
                    """
                )
                cur.execute(
                    """
                    UPDATE demo_trades
                    SET fence_token = 0
                    WHERE status IN('PENDING','OPEN','UNRESOLVED')
                      AND fence_token IS NULL
                    """
                )
                cur.execute(
                    """
                    SELECT COUNT(*)
                    FROM demo_trades
                    WHERE status IN('PENDING','OPEN','UNRESOLVED')
                      AND (basket_id IS NULL OR basket_slot IS NULL OR order_claim_key IS NULL OR fence_token IS NULL)
                    """
                )
                missing = integer(cur.fetchone()[0], 0)
                if missing:
                    raise RuntimeError(
                        f"V9 migration validation failed: {missing} active rows incomplete"
                    )
            conn.commit()
        except Exception:
            try:
                conn.rollback()
            except Exception:
                pass
            raise
        finally:
            try:
                conn.autocommit = old_autocommit
            except Exception:
                pass
            conn.close()

    def _new_basket_id(self):
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT 'B' || nextval('demo_basket_id_seq')::text")
                row = cur.fetchone()
            return str(row[0])
        finally:
            conn.close()

    def active_basket_id(self, side, create_if_flat=False):
        side = str(side or "").upper()
        rows = [
            r for r in self._active_trade_rows()
            if str(r.get("side") or "").upper() == side
        ]
        ids = {str(r.get("basket_id")) for r in rows if r.get("basket_id")}
        if len(ids) > 1:
            return None
        if ids:
            return next(iter(ids))
        if rows:
            basket_id = self._new_basket_id()
            conn = self.connect()
            try:
                with conn.cursor() as cur:
                    cur.execute(
                        """
                        UPDATE demo_trades
                        SET basket_id=%s
                        WHERE symbol=%s AND UPPER(side)=%s
                          AND status IN('PENDING','OPEN','UNRESOLVED')
                          AND basket_id IS NULL
                        """,
                        (basket_id, self.symbol, side),
                    )
            finally:
                conn.close()
            return basket_id
        return self._new_basket_id() if create_if_flat else None

    def _active_trade_rows(self):
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT id,candidate_id,side,lot,COALESCE(entry_price,planned_price) AS entry_price,
                           sl,payload,status,created_at,opened_at,mt5_ticket,basket_id,
                           order_claim_key,fence_token,basket_slot
                    FROM demo_trades
                    WHERE symbol=%s AND status IN('PENDING','OPEN','UNRESOLVED')
                    ORDER BY id ASC
                    """,
                    (self.symbol,),
                )
                names = [d[0] for d in cur.description]
                return [dict(zip(names, row)) for row in cur.fetchall()]
        finally:
            conn.close()

    def bot_mt5_positions(self):
        positions = self.mt5.positions_get(symbol=self.symbol)
        if positions is None:
            error = None
            try:
                error = self.mt5.last_error()
            except Exception:
                pass
            raise Mt5StateUnavailable(f"positions_get returned None: {error}")
        return [
            p for p in positions
            if integer(getattr(p, "magic", 0), 0) == self.magic
        ]

    def step(self, tick, account):
        try:
            return super().step(tick, account)
        except Mt5StateUnavailable as exc:
            now = time.monotonic()
            if now - self._last_reconcile_block_event >= 15.0:
                self.event(
                    "MT5_STATE_UNAVAILABLE",
                    payload={"reason": str(exc)},
                )
                self._last_reconcile_block_event = now
            return None

    def reconcile_open_ticket_comments(self):
        rows = {int(r["id"]): r for r in self._active_trade_rows()}
        for position in self.bot_mt5_positions():
            ticket = integer(getattr(position, "ticket", 0), 0)
            trade_id = self._trade_id_from_comment(position)
            if not ticket or not trade_id or trade_id not in rows:
                continue
            row = rows[trade_id]
            entry = num(getattr(position, "price_open", 0.0)) or num(row.get("entry_price"))
            live_lot = max(0.0, num(getattr(position, "volume", 0.0)))
            if row.get("status") in {"PENDING", "UNRESOLVED"}:
                self.mark_open(
                    trade_id,
                    ticket,
                    entry,
                    num(row.get("entry_price")) or entry,
                    {"reconciled_from_comment": True, "live_lot": live_lot},
                )
            conn = self.connect()
            try:
                with conn.cursor() as cur:
                    cur.execute(
                        """
                        UPDATE demo_trades
                        SET mt5_ticket=%s,
                            lot=CASE WHEN %s > 0 THEN %s ELSE lot END,
                            payload=COALESCE(payload,'{}'::jsonb) || %s::jsonb
                        WHERE id=%s AND status='OPEN'
                        """,
                        (
                            str(ticket),
                            live_lot,
                            live_lot,
                            json.dumps({"live_position_reconciled": True}),
                            trade_id,
                        ),
                    )
            finally:
                conn.close()

    def _mark_unresolved(self, trade_id, age):
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE demo_trades
                    SET status='UNRESOLVED',
                        payload=COALESCE(payload,'{}'::jsonb) || %s::jsonb
                    WHERE id=%s AND status='PENDING'
                    """,
                    (
                        json.dumps(
                            {
                                "reconcile_required": True,
                                "unresolved_at": utcnow().isoformat(),
                                "age_sec": age,
                                "auto_retry": False,
                            }
                        ),
                        int(trade_id),
                    ),
                )
        finally:
            conn.close()

    def reconcile_pending_claims(self):
        rows = [
            r for r in self._active_trade_rows()
            if r.get("status") in {"PENDING", "UNRESOLVED"}
        ]
        unresolved = []
        for row in rows:
            trade_id = int(row["id"])
            live = self._position_for_trade_id(trade_id)
            if live is not None:
                entry = num(getattr(live, "price_open", 0.0)) or num(row.get("entry_price"))
                self.mark_open(
                    trade_id,
                    integer(getattr(live, "ticket", 0), 0),
                    entry,
                    num(row.get("entry_price")) or entry,
                    {"reconciled_after_restart": True},
                )
                continue

            if row.get("status") == "UNRESOLVED":
                unresolved.append(trade_id)
                continue

            created = row.get("created_at")
            if created is None:
                unresolved.append(trade_id)
                continue
            if created.tzinfo is None:
                created = created.replace(tzinfo=timezone.utc)
            age = max(0.0, (utcnow() - created).total_seconds())
            payload = row.get("payload") or {}
            if isinstance(payload, str):
                try:
                    payload = json.loads(payload)
                except Exception:
                    payload = {}

            if age < self.CLAIM_GRACE_SECONDS:
                unresolved.append(trade_id)
                continue

            if not bool(payload.get("send_attempted")):
                self.reject_trade(
                    trade_id,
                    "STALE_UNSENT_CLAIM",
                    {"age_sec": age, "send_attempted": False},
                )
                continue

            self._set_pending_payload(
                trade_id,
                {
                    "reconcile_required": True,
                    "reconcile_checked_at": utcnow().isoformat(),
                    "age_sec": age,
                    "auto_retry": False,
                },
            )
            if age >= self.UNRESOLVED_AFTER_SECONDS:
                self._mark_unresolved(trade_id, age)
            unresolved.append(trade_id)
        return not unresolved

    def unknown_live_positions(self):
        try:
            return super().unknown_live_positions()
        except Mt5StateUnavailable:
            raise

    def reconcile_or_fail_closed(self):
        try:
            return super().reconcile_or_fail_closed()
        except Mt5StateUnavailable as exc:
            now = time.monotonic()
            if now - self._last_reconcile_block_event >= 15.0:
                self.event("MT5_STATE_UNAVAILABLE", payload={"reason": str(exc)})
                self._last_reconcile_block_event = now
            return False

    def _final_send_guard(self, side, fence_token):
        try:
            return super()._final_send_guard(side, fence_token)
        except Mt5StateUnavailable:
            return False, "MT5_STATE_UNAVAILABLE"


DemoTraderV9Final = V9HardenedV2DemoTrader
