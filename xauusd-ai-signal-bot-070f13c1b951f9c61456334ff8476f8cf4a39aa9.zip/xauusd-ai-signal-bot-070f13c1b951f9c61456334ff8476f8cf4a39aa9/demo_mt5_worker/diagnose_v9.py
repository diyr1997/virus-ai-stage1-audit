from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

import worker as core
import worker_auto as auto


DIAGNOSTIC_VERSION = "xauusd-v9-preflight-2026-08-25"
ROOT = Path(__file__).resolve().parent
REQUIRED_PACKAGE_FEATURES = {
    "DEMO_ONLY",
    "FAST80_WAIT_FIX",
    "FAST80_DIAGNOSTICS",
    "NO_HEDGE",
    "SAFE_CONFIG_MIGRATION",
}


def _now_utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def _short_error(exc: Exception, limit: int = 500) -> str:
    return str(exc).replace("\r", " ").replace("\n", " ")[:limit]


def _save_preflight(payload: dict) -> None:
    try:
        core.save_worker_state("preflight", payload)
    except Exception as exc:
        payload["state_write_error"] = _short_error(exc)


def _print(label: str, ok: bool, detail: str) -> None:
    prefix = "OK" if ok else "FAIL"
    print(f"[{prefix}] {label}: {detail}")


def _package_preflight(payload: dict) -> bool:
    manifest_path = ROOT / "BUILD_MANIFEST.json"
    helper_path = ROOT / "prepare_update_from_old_worker.bat"
    launcher_path = ROOT / "windows_launcher.py"
    payload["package_ok"] = False
    try:
        if not manifest_path.is_file():
            raise RuntimeError("BUILD_MANIFEST.json missing; old or incomplete package")
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        features = {str(x) for x in (manifest.get("features") or [])}
        missing = sorted(REQUIRED_PACKAGE_FEATURES - features)
        if manifest.get("execution_scope") != "DEMO_ONLY":
            raise RuntimeError("manifest execution_scope is not DEMO_ONLY")
        build_id = str(manifest.get("build_id") or "").strip()
        if not build_id:
            raise RuntimeError("manifest build_id missing")
        if missing:
            raise RuntimeError("manifest missing features: " + ", ".join(missing))
        if not helper_path.is_file():
            raise RuntimeError("prepare_update_from_old_worker.bat missing")
        launcher = launcher_path.read_text(encoding="utf-8-sig")
        for marker in ("FAST80 WAIT-FIX ACTIVE", "FAST80 DIAGNOSTICS ACTIVE", "PACKAGE BUILD_ID:"):
            if marker not in launcher:
                raise RuntimeError(f"launcher marker missing: {marker}")
        payload["package_ok"] = True
        payload["package_build_id"] = build_id
        payload["package_version"] = str(manifest.get("version") or "")[:160]
        payload["package_generated_at_utc"] = str(manifest.get("generated_at_utc") or "")[:160]
        payload["package_source_sha256"] = str(manifest.get("source_sha256") or "")[:128]
        _print("Package", True, f"build_id={build_id} DEMO_ONLY FAST80-fix diagnostics OK")
        return True
    except Exception as exc:
        payload["package_error"] = _short_error(exc)
        _print("Package", False, payload["package_error"])
        return False


def main() -> int:
    checked_at = _now_utc()
    planned_closed, planned_kind = auto.planned_market_closed_now()

    payload = {
        "version": DIAGNOSTIC_VERSION,
        "checked_at_utc": checked_at,
        "demo_only": True,
        "symbol": core.MT5_SYMBOL,
        "planned_market_closed": bool(planned_closed),
        "planned_market_state": planned_kind or None,
        "package_ok": False,
        "database_ok": False,
        "mt5_demo_ok": False,
        "time_trusted": False,
        "tick_fresh": False,
        "closed_m1_fresh": False,
        "overall": "FAIL",
    }

    print("==========================================")
    print("XAUUSD DEMO WORKER V9 - READ-ONLY PREFLIGHT")
    print("No orders are sent by this diagnostic.")
    print("==========================================")

    # 0) Package identity and safety markers. Read-only; no ownership lock is acquired.
    _package_preflight(payload)

    # 1) PostgreSQL connectivity. No credentials are printed or stored.
    try:
        conn = core.db_connect()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT NOW()")
                cur.fetchone()
            payload["database_ok"] = True
            _print("PostgreSQL", True, "connection OK")
        finally:
            conn.close()
    except Exception as exc:
        payload["database_error"] = _short_error(exc)
        _print("PostgreSQL", False, payload["database_error"])

    account = None
    tick = None
    latest_closed_m1 = None

    try:
        # 2) MT5 initialization includes the hard DEMO account-mode guard.
        try:
            account = core.mt5_initialize()
            payload["mt5_demo_ok"] = True
            payload["mt5_server"] = str(getattr(account, "server", "") or "")[:120]
            _print(
                "MT5 DEMO",
                True,
                f"server={payload['mt5_server'] or '?'} symbol={core.MT5_SYMBOL}",
            )
        except Exception as exc:
            payload["mt5_error"] = _short_error(exc)
            _print("MT5 DEMO", False, payload["mt5_error"])
            _save_preflight(payload)
            return 2

        # 3) UTC policy must be trusted before any live entry can be safe.
        try:
            core.detect_mt5_time_offset(force=True)
            payload["time_trusted"] = bool(core.MT5_TIME_OFFSET_CONFIDENT)
            payload["mt5_offset_seconds"] = int(core.MT5_TIME_OFFSET_SECONDS)
            time_ok_for_preflight = payload["time_trusted"] or planned_closed
            if planned_closed and not payload["time_trusted"]:
                payload["time_unverified_market_closed"] = True
            _print(
                "MT5 time",
                time_ok_for_preflight,
                f"trusted={payload['time_trusted']} offset={payload['mt5_offset_seconds']}s"
                + (f" planned={planned_kind}" if planned_closed else ""),
            )
        except Exception as exc:
            payload["time_error"] = _short_error(exc)
            if planned_closed:
                payload["time_unverified_market_closed"] = True
                _print("MT5 time", True, payload["time_error"] + f"; unverified during {planned_kind}")
            else:
                _print("MT5 time", False, payload["time_error"])

        # 4) Live tick freshness.
        try:
            tick = core.get_tick()
            tick_age = auto.tick_age_seconds(tick)
            payload["tick_age_seconds"] = None if tick_age == float("inf") else round(tick_age, 1)
            payload["tick_fresh"] = -core.MAX_FUTURE_SECONDS <= tick_age <= auto.MARKET_TICK_STALE_SECONDS
            _print(
                "GOLD tick",
                payload["tick_fresh"] or planned_closed,
                f"age={payload['tick_age_seconds']}s" + (f" planned={planned_kind}" if planned_closed else ""),
            )
        except Exception as exc:
            payload["tick_error"] = _short_error(exc)
            _print("GOLD tick", bool(planned_closed), payload["tick_error"] + (f"; planned={planned_kind}" if planned_closed else ""))

        # 5) Only closed M1 is inspected. get_closed_m1_rates() explicitly skips bar 0.
        try:
            rows = core.get_closed_m1_rates(3)
            if rows:
                latest_closed_m1 = rows[-1][1]
            m1_ok, m1_reason = core.validate_closed_m1_time(latest_closed_m1)
            payload["closed_m1_fresh"] = bool(m1_ok)
            payload["closed_m1_reason"] = str(m1_reason)
            payload["last_closed_m1_utc"] = latest_closed_m1.isoformat() if latest_closed_m1 else None
            _print(
                "Closed M1",
                payload["closed_m1_fresh"] or planned_closed,
                f"{payload['last_closed_m1_utc']} | {m1_reason}" + (f" | planned={planned_kind}" if planned_closed else ""),
            )
        except Exception as exc:
            payload["closed_m1_error"] = _short_error(exc)
            _print("Closed M1", bool(planned_closed), payload["closed_m1_error"] + (f"; planned={planned_kind}" if planned_closed else ""))

        if tick is not None and latest_closed_m1 is not None:
            try:
                snapshot = auto.classify_market_state(latest_closed_m1, tick)
                payload["market_state"] = snapshot.get("state")
                payload["market_reason"] = snapshot.get("reason")
            except Exception as exc:
                payload["market_state_error"] = _short_error(exc)

        time_ok_for_preflight = payload["time_trusted"] or planned_closed
        base_ok = payload["package_ok"] and payload["database_ok"] and payload["mt5_demo_ok"] and time_ok_for_preflight
        live_ok = payload["tick_fresh"] and payload["closed_m1_fresh"]

        if planned_closed and base_ok:
            payload["overall"] = "PASS_MARKET_CLOSED"
        elif base_ok and live_ok:
            payload["overall"] = "PASS"
        else:
            payload["overall"] = "FAIL"

        _save_preflight(payload)

        print("------------------------------------------")
        print("PREFLIGHT_RESULT: " + json.dumps(payload, ensure_ascii=False, sort_keys=True))
        print("------------------------------------------")
        if payload["overall"].startswith("PASS"):
            print("[OK] Package + DEMO environment preflight passed. Trading guards still decide each entry.")
            return 0

        print("[WARNING] Preflight found a problem. Worker may still start for automatic reconnect,")
        print("but new DEMO entries stay fail-closed until package/MT5 tick/M1/time are valid.")
        return 2
    finally:
        try:
            core.mt5.shutdown()
        except Exception:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
