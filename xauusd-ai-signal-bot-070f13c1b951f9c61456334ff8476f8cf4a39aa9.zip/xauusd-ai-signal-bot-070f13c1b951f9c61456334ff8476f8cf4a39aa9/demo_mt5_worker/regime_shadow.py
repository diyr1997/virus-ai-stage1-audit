from __future__ import annotations

import math
from datetime import datetime, timezone
from typing import Any


def _num(value: Any, default: float = 0.0) -> float:
    try:
        value = float(value)
        return value if math.isfinite(value) else default
    except (TypeError, ValueError):
        return default


class RegimeShadow:
    """SHADOW ONLY: classifies session/volatility regime and suggests calibration bands.

    The output is observability only. It never opens, closes, modifies, confirms,
    blocks or resizes a trade.
    """

    @staticmethod
    def _session(ts: float) -> str:
        hour = datetime.fromtimestamp(ts, tz=timezone.utc).hour
        if 12 <= hour < 16:
            return "LONDON_NEW_YORK_OVERLAP"
        if 7 <= hour < 12:
            return "LONDON"
        if 16 <= hour < 21:
            return "NEW_YORK"
        return "ASIA_OFF_HOURS"

    def evaluate(self, snapshot: dict) -> dict:
        ts = _num(snapshot.get("tick_ts"))
        session = self._session(ts) if ts > 0 else "UNKNOWN"
        atr = _num(snapshot.get("atr_m1"))
        velocity = _num(snapshot.get("velocity_atr_per_min"))
        spread_z = _num(snapshot.get("spread_z"))
        chop = _num(snapshot.get("chop_score"))
        persistence = _num(snapshot.get("tick_persistence"))
        efficiency = _num(snapshot.get("tick_efficiency"))

        if chop >= 70.0 or efficiency < 0.18:
            market_regime = "CHOP"
        elif velocity >= 1.20:
            market_regime = "HIGH_VOL"
        elif velocity <= 0.25:
            market_regime = "LOW_VOL"
        else:
            market_regime = "NORMAL_VOL"

        # Calibration suggestions only. FAST80 execution threshold is NOT changed.
        suggested_fast = 80.0
        if market_regime == "CHOP":
            suggested_fast += 10.0
        elif market_regime == "LOW_VOL":
            suggested_fast += 4.0
        elif market_regime == "HIGH_VOL":
            suggested_fast += 2.0

        if spread_z >= 2.0:
            suggested_fast += 5.0
        if persistence >= 0.72 and efficiency >= 0.45 and spread_z < 1.0:
            suggested_fast -= 2.0

        suggested_fast = max(78.0, min(95.0, suggested_fast))

        return {
            "session": session,
            "market_regime": market_regime,
            "suggested_fast_threshold": round(suggested_fast, 1),
            "atr_m1": round(atr, 6),
            "velocity_atr_per_min": round(velocity, 4),
            "spread_z": round(spread_z, 3),
            "chop_score": round(chop, 2),
            "tick_persistence": round(persistence, 4),
            "tick_efficiency": round(efficiency, 4),
            "shadow_only": True,
            "execution_impact": "NONE",
        }
