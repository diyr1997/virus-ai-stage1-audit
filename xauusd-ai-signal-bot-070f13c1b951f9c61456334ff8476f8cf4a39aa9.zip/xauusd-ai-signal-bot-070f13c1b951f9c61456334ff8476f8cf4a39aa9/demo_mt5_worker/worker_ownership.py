from __future__ import annotations

import os
import socket
import time
import uuid

import psycopg2


DEFAULT_LOCK_ID = 26081720260821


class WorkerOwnershipLock:
    """PostgreSQL advisory ownership with a monotonic fencing generation.

    The advisory lock ensures one owner while the DB session is alive. The fencing
    generation closes the stale-owner window: every successful acquisition gets a
    larger token, and final order-send checks force a DB round trip immediately
    before MT5 order_send.
    """

    def __init__(self, database_url, lock_id=None, retry_seconds=None, health_seconds=None):
        self.database_url = str(database_url or "").strip()
        if not self.database_url:
            raise RuntimeError("DATABASE_URL не найден для worker ownership lock")
        self.lock_id = int(lock_id if lock_id is not None else os.getenv("DEMO_WORKER_ADVISORY_LOCK_ID", str(DEFAULT_LOCK_ID)))
        self.retry_seconds = max(2.0, float(retry_seconds if retry_seconds is not None else os.getenv("DEMO_WORKER_LOCK_RETRY_SECONDS", "10")))
        self.health_seconds = max(0.25, float(health_seconds if health_seconds is not None else os.getenv("DEMO_WORKER_LOCK_HEALTH_SECONDS", "2")))
        self.owner_id = f"{socket.gethostname()}:{os.getpid()}:{uuid.uuid4().hex[:10]}"
        self.conn = None
        self.acquired = False
        self.token = None
        self.last_attempt_at = 0.0
        self.last_health_at = 0.0

    def _connect(self):
        kwargs = {"connect_timeout": 10, "application_name": "xauusd_demo_worker_owner_v9"}
        sslmode = os.getenv("DB_SSLMODE", "").strip()
        if sslmode:
            kwargs["sslmode"] = sslmode
        conn = psycopg2.connect(self.database_url, **kwargs)
        conn.autocommit = True
        return conn

    def _drop_connection(self):
        conn = self.conn
        self.conn = None
        self.acquired = False
        self.token = None
        self.last_health_at = 0.0
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass

    @staticmethod
    def _ensure_schema_on(conn):
        with conn.cursor() as cur:
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS demo_worker_fence (
                    lock_id BIGINT PRIMARY KEY,
                    generation BIGINT NOT NULL DEFAULT 0,
                    owner_id TEXT,
                    acquired_at TIMESTAMPTZ,
                    heartbeat_at TIMESTAMPTZ
                )
                """
            )

    def try_acquire(self, force=False):
        now = time.monotonic()
        if self.acquired and self.conn is not None:
            return self.is_current(force=True)
        if not force and now - self.last_attempt_at < self.retry_seconds:
            return False
        self.last_attempt_at = now
        self._drop_connection()

        conn = None
        try:
            conn = self._connect()
            self._ensure_schema_on(conn)
            with conn.cursor() as cur:
                cur.execute("SELECT pg_try_advisory_lock(%s)", (self.lock_id,))
                row = cur.fetchone()
                if not row or not bool(row[0]):
                    conn.close()
                    return False
                cur.execute(
                    """
                    INSERT INTO demo_worker_fence(lock_id,generation,owner_id,acquired_at,heartbeat_at)
                    VALUES(%s,1,%s,NOW(),NOW())
                    ON CONFLICT(lock_id) DO UPDATE SET
                        generation = demo_worker_fence.generation + 1,
                        owner_id = EXCLUDED.owner_id,
                        acquired_at = NOW(),
                        heartbeat_at = NOW()
                    RETURNING generation
                    """,
                    (self.lock_id, self.owner_id),
                )
                generation = int(cur.fetchone()[0])
            self.conn = conn
            self.acquired = True
            self.token = generation
            self.last_health_at = now
            return True
        except Exception:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass
            self._drop_connection()
            return False

    def is_current(self, token=None, force=False):
        if not self.acquired or self.conn is None or self.token is None:
            return False
        expected = int(self.token if token is None else token)
        if expected != int(self.token):
            return False
        now = time.monotonic()
        if not force and now - self.last_health_at < self.health_seconds:
            return True
        try:
            with self.conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE demo_worker_fence
                    SET heartbeat_at=NOW()
                    WHERE lock_id=%s AND generation=%s AND owner_id=%s
                    RETURNING generation
                    """,
                    (self.lock_id, expected, self.owner_id),
                )
                row = cur.fetchone()
            if not row or int(row[0]) != expected:
                self._drop_connection()
                return False
            self.last_health_at = now
            return True
        except Exception:
            self._drop_connection()
            return False

    def ensure_owned(self):
        if self.is_current():
            return True
        return self.try_acquire()

    def current_token(self):
        return int(self.token) if self.token is not None else None

    def release(self):
        conn = self.conn
        was_acquired = self.acquired
        self.conn = None
        self.acquired = False
        self.token = None
        self.last_health_at = 0.0
        if conn is None:
            return
        try:
            if was_acquired:
                with conn.cursor() as cur:
                    cur.execute("SELECT pg_advisory_unlock(%s)", (self.lock_id,))
        except Exception:
            pass
        finally:
            try:
                conn.close()
            except Exception:
                pass
