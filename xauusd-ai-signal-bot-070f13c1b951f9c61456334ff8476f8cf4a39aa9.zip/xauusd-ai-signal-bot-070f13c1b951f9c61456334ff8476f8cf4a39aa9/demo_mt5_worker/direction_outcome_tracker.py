from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass


@dataclass
class DirectionObservation:
    ts: float
    side: str
    legacy_side: str
    score: float
    confidence: float
    confidence_bucket: str
    state: str
    market_regime: str
    trading_session: str
    price: float
    done: set[int]


class DirectionOutcomeTracker:
    """SHADOW ONLY outcome tracker for Direction Engine V2.

    It never opens, closes, modifies, confirms or blocks trades. It only measures
    whether V2 and the legacy direction at the same observation point were followed
    by favorable price movement.
    """

    HORIZONS = (60, 180, 300)

    def __init__(self, mt5_module, symbol: str):
        self.mt5 = mt5_module
        self.symbol = str(symbol)
        self.pending = deque(maxlen=5000)

    def _mid(self) -> float:
        try:
            tick = self.mt5.symbol_info_tick(self.symbol)
        except Exception:
            tick = None
        if tick is None:
            return 0.0
        try:
            bid = float(getattr(tick, "bid", 0.0) or 0.0)
            ask = float(getattr(tick, "ask", 0.0) or 0.0)
        except Exception:
            return 0.0
        if bid <= 0 or ask <= 0 or ask < bid:
            return 0.0
        return (bid + ask) / 2.0

    @staticmethod
    def _is_correct(side: str, delta: float):
        side = str(side or "NEUTRAL").upper()
        if side == "BUY":
            return delta > 0
        if side == "SELL":
            return delta < 0
        return None

    @staticmethod
    def confidence_bucket(confidence: float) -> str:
        value = max(0.0, min(100.0, float(confidence)))
        if value < 50.0:
            return "<50"
        if value < 60.0:
            return "50-59"
        if value < 70.0:
            return "60-69"
        if value < 80.0:
            return "70-79"
        if value < 90.0:
            return "80-89"
        return "90+"

    @staticmethod
    def _dimension(payload: dict, key: str, nested_key: str | None = None) -> str:
        value = payload.get(key)
        if not value and nested_key:
            regime = payload.get("regime_shadow")
            if isinstance(regime, dict):
                value = regime.get(nested_key)
        return str(value or "UNKNOWN").upper()

    def observe(self, payload: dict) -> list[dict]:
        now = time.time()
        price = self._mid()
        side = str(payload.get("direction_v2") or "NEUTRAL").upper()
        legacy_side = str(payload.get("legacy_direction") or "NEUTRAL").upper()
        confidence = float(payload.get("direction_confidence") or 0.0)
        if side in {"BUY", "SELL"} and price > 0:
            self.pending.append(DirectionObservation(
                ts=now,
                side=side,
                legacy_side=legacy_side,
                score=float(payload.get("direction_score") or 0.0),
                confidence=confidence,
                confidence_bucket=self.confidence_bucket(confidence),
                state=str(payload.get("direction_state") or "UNKNOWN"),
                market_regime=self._dimension(payload, "market_regime", "market_regime"),
                trading_session=self._dimension(payload, "trading_session", "session"),
                price=price,
                done=set(),
            ))

        outcomes = []
        if price <= 0:
            return outcomes

        for obs in list(self.pending):
            age = now - obs.ts
            for horizon in self.HORIZONS:
                if horizon in obs.done or age < horizon:
                    continue
                delta = price - obs.price
                signed_move = delta if obs.side == "BUY" else -delta
                v2_correct = bool(signed_move > 0)
                legacy_correct = self._is_correct(obs.legacy_side, delta)
                if legacy_correct is None:
                    comparison = "V2_ONLY"
                elif v2_correct and legacy_correct:
                    comparison = "BOTH_CORRECT"
                elif v2_correct and not legacy_correct:
                    comparison = "V2_BETTER"
                elif (not v2_correct) and legacy_correct:
                    comparison = "LEGACY_BETTER"
                else:
                    comparison = "BOTH_WRONG"

                outcomes.append({
                    "direction_v2": obs.side,
                    "legacy_direction": obs.legacy_side,
                    "direction_score": round(obs.score, 2),
                    "direction_confidence": round(obs.confidence, 2),
                    "confidence_bucket": obs.confidence_bucket,
                    "direction_state": obs.state,
                    "market_regime": obs.market_regime,
                    "trading_session": obs.trading_session,
                    "horizon_seconds": horizon,
                    "origin_price": round(obs.price, 6),
                    "outcome_price": round(price, 6),
                    "signed_move": round(signed_move, 6),
                    "correct_direction": v2_correct,
                    "legacy_correct_direction": legacy_correct,
                    "comparison": comparison,
                    "flat_direction": bool(abs(delta) < 1e-9),
                    "execution_impact": "NONE",
                    "shadow_only": True,
                })
                obs.done.add(horizon)

        while self.pending and all(h in self.pending[0].done for h in self.HORIZONS):
            self.pending.popleft()
        return outcomes
