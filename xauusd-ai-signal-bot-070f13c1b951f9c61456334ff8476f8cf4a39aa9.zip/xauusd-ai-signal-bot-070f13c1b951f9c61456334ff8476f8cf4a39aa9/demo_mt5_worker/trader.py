"""Canonical DEMO trader entry point for final V9 safety hardening."""

from trader_legacy import *  # noqa: F401,F403
from trader_legacy import DemoTrader as LegacyDemoTrader
from trader_v9 import BasketStateMachine, V9DemoTrader
from trader_v9_hardened import V9HardenedDemoTrader
from trader_v9_hardened_v2 import Mt5StateUnavailable, V9HardenedV2DemoTrader
from trader_v9_hardened_v3 import V9HardenedV3DemoTrader

# Read-only SHADOW integrations. Import side effects patch only observers.
import reverse_shadow_integration  # noqa: F401,E402
import fast_entry_shadow_integration  # noqa: F401,E402
import regime_shadow_integration  # noqa: F401,E402

from trader_v9_hardened_v4 import V9HardenedV4DemoTrader
from trader_v9_hardened_v5 import V9HardenedV5DemoTrader
from trader_v9_hardened_v6 import V9HardenedV6DemoTrader
from trader_v9_hardened_v7 import V9HardenedV7DemoTrader

# Direction V2 runs only in SHADOW and never changes entry/exit/order decisions.
import direction_shadow_integration  # noqa: F401,E402

# Read-only DB calibration runs after V6 exists; it never changes trade decisions.
import shadow_calibration_integration  # noqa: F401,E402

# V7 is canonical: it inherits all V6 behavior and re-reads MT5 account_info()
# immediately before every broker-facing order_send. REAL remains blocked.
DemoTrader = V9HardenedV7DemoTrader

__all__ = [
    "DemoTrader", "LegacyDemoTrader", "V9DemoTrader", "V9HardenedDemoTrader",
    "V9HardenedV2DemoTrader", "V9HardenedV3DemoTrader", "V9HardenedV4DemoTrader",
    "V9HardenedV5DemoTrader", "V9HardenedV6DemoTrader", "V9HardenedV7DemoTrader",
    "Mt5StateUnavailable", "BasketStateMachine",
]
