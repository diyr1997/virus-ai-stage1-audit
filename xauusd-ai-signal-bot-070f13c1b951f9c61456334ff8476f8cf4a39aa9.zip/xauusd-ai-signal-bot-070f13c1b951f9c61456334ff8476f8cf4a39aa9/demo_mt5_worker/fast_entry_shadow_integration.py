from __future__ import annotations

import time

from fast_entry_shadow import FastEntryShadowGate
from impulse_shadow import ImpulseShadowEngine
from shadow_outcome_tracker import ShadowOutcomeTracker


_ORIGINAL_OBSERVE = ImpulseShadowEngine.observe


def _install() -> None:
    if getattr(ImpulseShadowEngine, "_fast_entry_shadow_integration_installed", False):
        return

    original_init = ImpulseShadowEngine.__init__

    def patched_init(self, *args, **kwargs):
        original_init(self, *args, **kwargs)
        self.fast_entry_shadow_gate = FastEntryShadowGate()
        self.shadow_outcome_tracker = ShadowOutcomeTracker()
        self._fast_shadow_last_key = ""
        self._fast_shadow_last_log_at = 0.0

    def patched_observe(self, tick, min_interval: float = 1.0):
        snapshot = _ORIGINAL_OBSERVE(self, tick, min_interval=min_interval)
        if not snapshot or str(snapshot.get("state") or "") == "WARMUP":
            return snapshot

        snapshot["tick_ts"] = float(getattr(tick, "time_msc", 0) or 0) / 1000.0 or float(getattr(tick, "time", 0) or 0)
        snapshot["bid"] = float(getattr(tick, "bid", 0) or 0)
        snapshot["ask"] = float(getattr(tick, "ask", 0) or 0)

        result = self.fast_entry_shadow_gate.evaluate(snapshot)
        snapshot["fast_entry_shadow"] = result

        # Outcome tracking is read-only. DB event sink is attached by the trader
        # after construction; until then it simply keeps in-memory observations.
        completed = self.shadow_outcome_tracker.observe(snapshot)
        if completed:
            snapshot["fast_entry_outcomes"] = completed

        key = f"{result.get('recommendation')}:{result.get('primary_reason')}:{result.get('side')}"
        now = time.monotonic()
        changed = key != self._fast_shadow_last_key
        urgent = result.get("recommendation") == "WOULD_BLOCK_FAST_ENTRY" and float(result.get("impulse_score") or 0) >= 80.0
        if changed or urgent or now - self._fast_shadow_last_log_at >= 15.0:
            print(
                "[V9 FAST SHADOW] "
                f"rec={result.get('recommendation')} | reason={result.get('primary_reason')} | "
                f"side={result.get('side')} | quality={result.get('quality_score')} | "
                f"impulse={result.get('impulse_score')} | late={result.get('late_penalty')} | "
                f"ext_atr={result.get('extension_atr')} | persist={result.get('tick_persistence')} | "
                f"eff={result.get('tick_efficiency')} | spread_z={result.get('spread_z')} | "
                f"chop={result.get('chop_score')} | execution impact=NONE",
                flush=True,
            )
            self._fast_shadow_last_log_at = now
        for outcome in completed:
            print(
                "[V9 FAST OUTCOME] "
                f"h={outcome.get('horizon_sec')}s | side={outcome.get('side')} | "
                f"decision={outcome.get('shadow_recommendation')} | reason={outcome.get('shadow_reason')} | "
                f"net_atr={outcome.get('net_atr')} | mfe_atr={outcome.get('mfe_atr')} | "
                f"mae_atr={outcome.get('mae_atr')} | helped={outcome.get('would_have_helped')} | "
                "execution impact=NONE",
                flush=True,
            )
        self._fast_shadow_last_key = key
        return snapshot

    ImpulseShadowEngine.__init__ = patched_init
    ImpulseShadowEngine.observe = patched_observe
    ImpulseShadowEngine._fast_entry_shadow_integration_installed = True


_install()
