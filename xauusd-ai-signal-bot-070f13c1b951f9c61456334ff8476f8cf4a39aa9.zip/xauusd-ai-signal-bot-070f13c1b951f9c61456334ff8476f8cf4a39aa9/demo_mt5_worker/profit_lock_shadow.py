from __future__ import annotations

import math
import time
from dataclasses import dataclass
from typing import Any, Dict, Iterable, Optional


def _num(value: Any, default: float = 0.0) -> float:
    try:
        value = float(value)
        return value if math.isfinite(value) else default
    except (TypeError, ValueError):
        return default


def _clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))


@dataclass
class PositionTrack:
    ticket: int
    side: str
    entry: float
    volume: float
    opened_at: float
    mfe_price: float
    mae_price: float
    last_seen_at: float


class ProfitLockShadow:
    """SHADOW ONLY: evaluates profit-lock opportunities without execution calls."""

    def __init__(self):
        self.tracks: Dict[int, PositionTrack] = {}

    @staticmethod
    def _side(position) -> str:
        # MT5 POSITION_TYPE_BUY is normally 0 and SELL is normally 1.
        ptype = int(_num(getattr(position, "type", -1), -1))
        return "BUY" if ptype == 0 else "SELL" if ptype == 1 else "UNKNOWN"

    def _sync_track(self, position, current_price: float, now: float) -> Optional[PositionTrack]:
        ticket = int(_num(getattr(position, "ticket", 0)))
        side = self._side(position)
        entry = _num(getattr(position, "price_open", 0.0))
        volume = _num(getattr(position, "volume", 0.0))
        opened_at = _num(getattr(position, "time", 0.0), now)
        if ticket <= 0 or side not in {"BUY", "SELL"} or entry <= 0 or current_price <= 0:
            return None

        track = self.tracks.get(ticket)
        if track is None:
            track = PositionTrack(
                ticket=ticket,
                side=side,
                entry=entry,
                volume=volume,
                opened_at=opened_at,
                mfe_price=current_price,
                mae_price=current_price,
                last_seen_at=now,
            )
            self.tracks[ticket] = track
        else:
            track.side = side
            track.entry = entry
            track.volume = volume
            track.last_seen_at = now

        if side == "BUY":
            track.mfe_price = max(track.mfe_price, current_price)
            track.mae_price = min(track.mae_price, current_price)
        else:
            track.mfe_price = min(track.mfe_price, current_price)
            track.mae_price = max(track.mae_price, current_price)
        return track

    def evaluate(self, positions: Iterable[Any], snapshot: dict, bid: float, ask: float) -> list[dict]:
        now = time.time()
        positions = list(positions or [])
        live_tickets = set()
        results = []

        atr = max(0.0, _num(snapshot.get("atr_m1")))
        state = str(snapshot.get("state") or "UNKNOWN")
        weakening = _num(snapshot.get("weakening_score"))
        reversal = _num(snapshot.get("reversal_score"))
        impulse = _num(snapshot.get("impulse_score"))
        shadow_direction = str(snapshot.get("direction") or "FLAT")

        for position in positions:
            side = self._side(position)
            current_price = bid if side == "BUY" else ask if side == "SELL" else 0.0
            track = self._sync_track(position, current_price, now)
            if track is None:
                continue
            live_tickets.add(track.ticket)

            if side == "BUY":
                favorable = max(0.0, track.mfe_price - track.entry)
                current_gain = current_price - track.entry
                adverse = max(0.0, track.entry - track.mae_price)
            else:
                favorable = max(0.0, track.entry - track.mfe_price)
                current_gain = track.entry - current_price
                adverse = max(0.0, track.mae_price - track.entry)

            giveback = max(0.0, favorable - current_gain)
            giveback_ratio = giveback / favorable if favorable > 1e-9 else 0.0
            age_sec = max(0.0, now - track.opened_at)

            # Dynamic activation: enough favorable excursion to exceed ordinary noise/spread.
            spread = max(0.0, ask - bid)
            activation = max(0.35 * atr, 3.0 * spread)
            activated = favorable >= activation > 0

            # Start permissive, tighten as the observed impulse weakens or reversal grows.
            allowed_giveback = 0.42
            if weakening >= 55 or state == "WEAKENING_IMPULSE":
                allowed_giveback = min(allowed_giveback, 0.30)
            if reversal >= 55 or state == "TRUE_REVERSAL_CANDIDATE":
                allowed_giveback = min(allowed_giveback, 0.22)
            if impulse >= 80 and weakening < 40 and reversal < 35:
                allowed_giveback = max(allowed_giveback, 0.48)

            opposite_pressure = shadow_direction in {"BUY", "SELL"} and shadow_direction != side
            close_candidate = bool(
                activated
                and current_gain > 0
                and (
                    giveback_ratio >= allowed_giveback
                    or (opposite_pressure and reversal >= 60)
                    or (weakening >= 70 and giveback_ratio >= 0.18)
                )
            )

            if not activated:
                recommendation = "HOLD_WARMUP"
                reason = "MFE_BELOW_DYNAMIC_ACTIVATION"
            elif close_candidate:
                recommendation = "CLOSE_CANDIDATE"
                if opposite_pressure and reversal >= 60:
                    reason = "OPPOSITE_REVERSAL_PRESSURE"
                elif weakening >= 70 and giveback_ratio >= 0.18:
                    reason = "IMPULSE_WEAKENING_GIVEBACK"
                else:
                    reason = "MFE_GIVEBACK_LIMIT"
            else:
                recommendation = "HOLD"
                reason = "IMPULSE_PROFIT_LOCK_NOT_TRIGGERED"

            results.append({
                "ticket": track.ticket,
                "side": side,
                "volume": round(track.volume, 4),
                "entry": round(track.entry, 6),
                "current_price": round(current_price, 6),
                "mfe_price": round(track.mfe_price, 6),
                "mae_price": round(track.mae_price, 6),
                "mfe_distance": round(favorable, 6),
                "mae_distance": round(adverse, 6),
                "current_gain_distance": round(current_gain, 6),
                "giveback_distance": round(giveback, 6),
                "giveback_ratio": round(giveback_ratio, 4),
                "activation_distance": round(activation, 6),
                "allowed_giveback_ratio": round(allowed_giveback, 4),
                "position_age_sec": round(age_sec, 1),
                "impulse_state": state,
                "impulse_score": round(impulse, 2),
                "weakening_score": round(weakening, 2),
                "reversal_score": round(reversal, 2),
                "opposite_pressure": opposite_pressure,
                "recommendation": recommendation,
                "reason": reason,
                "shadow_only": True,
            })

        for ticket in list(self.tracks):
            if ticket not in live_tickets:
                self.tracks.pop(ticket, None)

        return results
