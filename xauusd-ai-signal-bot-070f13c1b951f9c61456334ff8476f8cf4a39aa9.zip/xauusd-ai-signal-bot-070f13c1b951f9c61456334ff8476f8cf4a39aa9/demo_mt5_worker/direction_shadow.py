from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any


def _num(value: Any, default: float = 0.0) -> float:
    try:
        value = float(value)
        return value if math.isfinite(value) else default
    except (TypeError, ValueError):
        return default


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, float(value)))


@dataclass
class DirectionMemory:
    side: int = 0
    score: float = 0.0
    state: str = "NEUTRAL"
    flips: int = 0


class DirectionShadowEngine:
    """SHADOW ONLY Direction Engine V2.

    Separates direction from impulse strength. It never opens, closes, modifies,
    confirms or blocks a trade. It only compares tick persistence + closed-TF
    structure/context and emits a stable BUY/SELL/NEUTRAL opinion for calibration.
    """

    TF_WEIGHTS = {"M1": 0.22, "M5": 0.28, "M15": 0.20, "M30": 0.16, "H1": 0.14}

    def __init__(self, mt5_module, symbol: str):
        self.mt5 = mt5_module
        self.symbol = str(symbol)
        self.memory = DirectionMemory()

    def _rates(self, timeframe_name: str, count: int = 32):
        tf = getattr(self.mt5, f"TIMEFRAME_{timeframe_name}", None)
        getter = getattr(self.mt5, "copy_rates_from_pos", None)
        if tf is None or not callable(getter):
            return None
        try:
            return getter(self.symbol, tf, 1, int(count))  # closed candles only
        except Exception:
            return None

    @staticmethod
    def _atr(rows, period: int = 14) -> float:
        if rows is None or len(rows) < 3:
            return 0.0
        seq = list(rows)
        prev = _num(seq[0]["close"])
        trs = []
        for row in seq[1:]:
            h, l, c = _num(row["high"]), _num(row["low"]), _num(row["close"])
            tr = max(h - l, abs(h - prev), abs(l - prev))
            if tr > 0:
                trs.append(tr)
            prev = c
        return sum(trs[-period:]) / min(period, len(trs)) if trs else 0.0

    def _tf_direction(self, name: str) -> dict:
        rows = self._rates(name, 40)
        if rows is None or len(rows) < 8:
            return {"side": 0, "strength": 0.0, "slope_atr": 0.0, "structure": 0.0}
        seq = list(rows)
        atr = self._atr(seq, 14)
        if atr <= 0:
            return {"side": 0, "strength": 0.0, "slope_atr": 0.0, "structure": 0.0}
        closes = [_num(r["close"]) for r in seq]
        lookback = min(6, len(closes) - 1)
        slope = (closes[-1] - closes[-1 - lookback]) / atr
        recent = seq[-6:]
        highs = [_num(r["high"]) for r in recent]
        lows = [_num(r["low"]) for r in recent]
        up_structure = sum(1 for a, b in zip(highs, highs[1:]) if b >= a) + sum(1 for a, b in zip(lows, lows[1:]) if b >= a)
        down_structure = sum(1 for a, b in zip(highs, highs[1:]) if b <= a) + sum(1 for a, b in zip(lows, lows[1:]) if b <= a)
        structure = (up_structure - down_structure) / max(1.0, up_structure + down_structure)
        raw = 0.72 * _clamp(slope / 1.8, -1.0, 1.0) + 0.28 * _clamp(structure, -1.0, 1.0)
        strength = abs(raw) * 100.0
        side = 1 if raw > 0.12 else -1 if raw < -0.12 else 0
        return {"side": side, "strength": round(strength, 2), "slope_atr": round(slope, 4), "structure": round(structure, 4)}

    @staticmethod
    def _signed_tick_component(impulse_snapshot: dict) -> float:
        side = str(impulse_snapshot.get("direction") or "FLAT").upper()
        sign = 1.0 if side == "BUY" else -1.0 if side == "SELL" else 0.0
        persistence = _clamp(_num(impulse_snapshot.get("tick_persistence"), 0.0), 0.0, 1.0)
        efficiency = _clamp(_num(impulse_snapshot.get("tick_efficiency"), 0.0), 0.0, 1.0)
        impulse = _clamp(_num(impulse_snapshot.get("impulse_score"), 0.0) / 100.0, 0.0, 1.0)
        return sign * _clamp(0.45 * persistence + 0.30 * efficiency + 0.25 * impulse, 0.0, 1.0)

    def observe(self, impulse_snapshot: dict) -> dict:
        tf = {name: self._tf_direction(name) for name in self.TF_WEIGHTS}
        tf_signed = 0.0
        supportive_weight = 0.0
        opposing_weight = 0.0
        for name, weight in self.TF_WEIGHTS.items():
            side = int(tf[name]["side"])
            strength = _num(tf[name]["strength"]) / 100.0
            tf_signed += weight * side * strength

        tick_signed = self._signed_tick_component(impulse_snapshot)
        raw = _clamp(0.44 * tick_signed + 0.56 * tf_signed, -1.0, 1.0)

        proposed = 1 if raw >= 0.18 else -1 if raw <= -0.18 else 0
        confidence = abs(raw) * 100.0

        # Hysteresis: a brief counter-tick burst cannot flip an established direction.
        current = self.memory.side
        if current and proposed == -current:
            reversal = _num(impulse_snapshot.get("reversal_score"), 0.0)
            weakening = _num(impulse_snapshot.get("weakening_score"), 0.0)
            opposite_tf = sum(
                weight for name, weight in self.TF_WEIGHTS.items()
                if int(tf[name]["side"]) == proposed and _num(tf[name]["strength"]) >= 45.0
            )
            if confidence < 62.0 or reversal < 55.0 or opposite_tf < 0.28:
                proposed = current
                confidence = min(confidence, 59.0)
            else:
                self.memory.flips += 1

        pullback = _num(impulse_snapshot.get("pullback_score"), 0.0)
        weakening = _num(impulse_snapshot.get("weakening_score"), 0.0)
        reversal = _num(impulse_snapshot.get("reversal_score"), 0.0)
        chop = _num(impulse_snapshot.get("chop_score"), 0.0)

        if chop >= 70.0 and confidence < 65.0:
            state = "CHOP"
        elif proposed == 0 or confidence < 28.0:
            state = "NEUTRAL"
        elif current and proposed == -current and reversal >= 60.0:
            state = "REVERSAL_BUILDING"
        elif weakening >= 60.0:
            state = "BUY_WEAKENING" if proposed > 0 else "SELL_WEAKENING"
        elif pullback >= reversal + 12.0 and pullback >= 55.0:
            state = "BUY_PULLBACK" if proposed > 0 else "SELL_PULLBACK"
        else:
            state = "BUY_ACTIVE" if proposed > 0 else "SELL_ACTIVE"

        # WAIT/neutral higher TF should not count as opposition; only explicit opposite TF does.
        for name, weight in self.TF_WEIGHTS.items():
            side = int(tf[name]["side"])
            if proposed and side == proposed:
                supportive_weight += weight
            elif proposed and side == -proposed:
                opposing_weight += weight

        self.memory.side = proposed
        self.memory.score = raw * 100.0
        self.memory.state = state

        return {
            "direction_v2": "BUY" if proposed > 0 else "SELL" if proposed < 0 else "NEUTRAL",
            "direction_score": round(raw * 100.0, 2),
            "direction_confidence": round(confidence, 2),
            "direction_state": state,
            "supportive_tf_weight": round(supportive_weight, 3),
            "opposing_tf_weight": round(opposing_weight, 3),
            "tick_component": round(tick_signed * 100.0, 2),
            "tf_component": round(tf_signed * 100.0, 2),
            "direction_flips": self.memory.flips,
            "tf": tf,
            "execution_impact": "NONE",
            "shadow_only": True,
        }
