from __future__ import annotations

import os
import time
from datetime import datetime, time as dt_time, timezone
from typing import Optional
from zoneinfo import ZoneInfo

import worker as core


# ============================================================
# AUTOMATIC MARKET STATE — V7
# ============================================================
# No manual switch. The worker decides on its own whether GOLD is:
# OPEN, DAILY_BREAK, WEEKEND_CLOSED, OPENING_SYNC, PAUSED,
# or CONNECTION_PROBLEM. Closed-market states are normal states,
# not worker errors.

MARKET_STATE_VERSION = os.getenv(
    "MARKET_STATE_VERSION",
    "xauusd-market-state-v7-auto-2026-08-20",
).strip() or "xauusd-market-state-v7-auto-2026-08-20"

# Observed daily GOLD maintenance window in the display timezone.
# A small safety buffer is intentional around the normal ~02:00-03:00 pause.
DAILY_BREAK_START = os.getenv("GOLD_DAILY_BREAK_START", "01:55").strip()
DAILY_BREAK_END = os.getenv("GOLD_DAILY_BREAK_END", "03:10").strip()

MARKET_TICK_STALE_SECONDS = max(
    60,
    int(os.getenv("MARKET_TICK_STALE_SECONDS", "180")),
)

MARKET_STATE_HEARTBEAT_SECONDS = max(
    10,
    int(os.getenv("MARKET_STATE_HEARTBEAT_SECONDS", "30")),
)

# A persistent unexpected loop/MT5 failure must not leave a zombie process
# that looks running on Windows while quotes, M1 and heartbeat are frozen.
# The BAT launcher already restarts non-zero exits, so after a bounded number
# of consecutive failures we deliberately exit non-zero and let it relaunch.
WORKER_FATAL_ERROR_LIMIT = max(
    3,
    int(os.getenv("WORKER_FATAL_ERROR_LIMIT", "6")),
)

WORKER_FATAL_EXIT_CODE = min(
    255,
    max(1, int(os.getenv("WORKER_FATAL_EXIT_CODE", "75"))),
)


def _parse_hhmm(value: str, fallback: str) -> dt_time:
    raw = (value or fallback).strip()
    try:
        hour_s, minute_s = raw.split(":", 1)
        hour = int(hour_s)
        minute = int(minute_s)
        if not (0 <= hour <= 23 and 0 <= minute <= 59):
            raise ValueError
        return dt_time(hour=hour, minute=minute)
    except Exception:
        fh, fm = fallback.split(":", 1)
        return dt_time(hour=int(fh), minute=int(fm))


_BREAK_START = _parse_hhmm(DAILY_BREAK_START, "01:55")
_BREAK_END = _parse_hhmm(DAILY_BREAK_END, "03:10")


def _display_zone() -> ZoneInfo:
    try:
        return ZoneInfo(core.DISPLAY_TIMEZONE)
    except Exception:
        return ZoneInfo("Asia/Tashkent")


def _inside_clock_window(now_t: dt_time, start: dt_time, end: dt_time) -> bool:
    if start <= end:
        return start <= now_t < end
    return now_t >= start or now_t < end


def planned_market_closed_now(
    now_local: Optional[datetime] = None,
) -> tuple[bool, str]:
    local = now_local or datetime.now(_display_zone())

    if local.weekday() in (5, 6):
        return True, "WEEKEND_CLOSED"

    local_clock = local.timetz().replace(tzinfo=None)
    if _inside_clock_window(local_clock, _BREAK_START, _BREAK_END):
        return True, "DAILY_BREAK"

    return False, ""


def tick_age_seconds(tick) -> float:
    raw = int(getattr(tick, "time", 0) or 0)
    if raw <= 0:
        return float("inf")

    corrected = core.normalize_mt5_epoch(raw)
    tick_dt = datetime.fromtimestamp(corrected, tz=timezone.utc)
    return (datetime.now(timezone.utc) - tick_dt).total_seconds()


def classify_market_state(
    latest_closed_m1: Optional[datetime],
    tick,
) -> dict:
    now_utc = datetime.now(timezone.utc)
    now_local = now_utc.astimezone(_display_zone())

    m1_ok, m1_reason = core.validate_closed_m1_time(latest_closed_m1)
    m1_age = core.candle_age_seconds(latest_closed_m1)
    t_age = tick_age_seconds(tick)
    tick_fresh = (
        -core.MAX_FUTURE_SECONDS
        <= t_age
        <= MARKET_TICK_STALE_SECONDS
    )

    planned_closed, planned_kind = planned_market_closed_now(now_local)

    if core.MT5_TIME_OFFSET_CONFIDENT and tick_fresh and m1_ok:
        state = "OPEN"
        reason = "fresh tick + fresh closed M1"
        trade_allowed = True
        training_allowed = False
    elif planned_closed and not tick_fresh and not m1_ok:
        state = planned_kind
        reason = "planned market closure; stale quotes/candles are expected"
        trade_allowed = False
        training_allowed = True
    elif tick_fresh and not m1_ok:
        state = "OPENING_SYNC"
        reason = f"quotes resumed; waiting for fresh closed M1 ({m1_reason})"
        trade_allowed = False
        training_allowed = False
    elif not tick_fresh and not m1_ok:
        state = "PAUSED"
        reason = (
            "MT5 connected, but GOLD quotes and closed M1 are stale; "
            "new entries stay paused"
        )
        trade_allowed = False
        training_allowed = False
    else:
        state = "TIME_GUARD"
        reason = m1_reason
        trade_allowed = False
        training_allowed = False

    return {
        "state": state,
        "reason": reason,
        "trade_allowed": trade_allowed,
        "training_allowed": training_allowed,
        "tick_age_seconds": (
            None if t_age == float("inf") else round(t_age, 1)
        ),
        "m1_age_seconds": (
            None if m1_age == float("inf") else round(m1_age, 1)
        ),
        "last_closed_m1_utc": (
            latest_closed_m1.isoformat() if latest_closed_m1 else None
        ),
        "display_timezone": core.DISPLAY_TIMEZONE,
        "local_time": now_local.isoformat(),
        "daily_break_start": DAILY_BREAK_START,
        "daily_break_end": DAILY_BREAK_END,
        "version": MARKET_STATE_VERSION,
        "updated_at_utc": now_utc.isoformat(),
    }


def save_market_state(snapshot: dict):
    core.save_worker_state("market_state", snapshot)


def log_market_transition(previous: Optional[str], snapshot: dict):
    state = snapshot["state"]
    if previous == state:
        return

    if state == "OPEN":
        core.log.info(
            "MARKET | OPEN | свежие GOLD котировки + M1 | "
            "новые DEMO-входы разрешены"
        )
    elif state == "DAILY_BREAK":
        core.log.info(
            "MARKET | DAILY BREAK | плановый перерыв GOLD | "
            "новые входы на паузе | обучение разрешено"
        )
    elif state == "WEEKEND_CLOSED":
        core.log.info(
            "MARKET | WEEKEND CLOSED | GOLD закрыт | "
            "новые входы на паузе | расширенное обучение разрешено"
        )
    elif state == "OPENING_SYNC":
        core.log.info(
            "MARKET | OPENING SYNC | котировки вернулись, "
            "ждём свежую закрытую M1"
        )
    elif state == "PAUSED":
        core.log.info(
            "MARKET | PAUSED | MT5 подключён, но GOLD пока не обновляется | %s",
            snapshot.get("reason", ""),
        )
    else:
        core.log.warning(
            "MARKET | %s | новые DEMO-входы на паузе | %s",
            state,
            snapshot.get("reason", ""),
        )


def _connection_problem(message: str):
    snapshot = {
        "state": "CONNECTION_PROBLEM",
        "reason": str(message),
        "trade_allowed": False,
        "training_allowed": False,
        "display_timezone": core.DISPLAY_TIMEZONE,
        "version": MARKET_STATE_VERSION,
        "updated_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    save_market_state(snapshot)
    core.log.warning("MARKET | CONNECTION PROBLEM | %s", message)


def _force_launcher_restart(reason: str, failures: int) -> None:
    """Exit non-zero so start_demo_bot.bat can restart a stuck worker."""
    now_utc = datetime.now(timezone.utc).isoformat()
    message = str(reason)

    core.log.error(
        "WATCHDOG | persistent worker failure %s/%s | launcher restart requested | %s",
        failures,
        WORKER_FATAL_ERROR_LIMIT,
        message,
    )

    core.save_worker_state(
        "worker_watchdog",
        {
            "restart_requested": True,
            "reason": message,
            "consecutive_failures": int(failures),
            "limit": WORKER_FATAL_ERROR_LIMIT,
            "exit_code": WORKER_FATAL_EXIT_CODE,
            "version": core.WORKER_VERSION,
            "updated_at_utc": now_utc,
        },
    )

    core.save_worker_state(
        "heartbeat",
        {
            "alive": False,
            "demo": True,
            "version": core.WORKER_VERSION,
            "symbol": core.MT5_SYMBOL,
            "restart_requested": True,
            "time": now_utc,
        },
    )

    try:
        core.mt5.shutdown()
    except Exception:
        pass

    raise SystemExit(WORKER_FATAL_EXIT_CODE)


def main():
    if core.sys.platform != "win32":
        core.log.warning(
            "MetaTrader5 Python обычно запускается на Windows рядом "
            "с установленным терминалом MT5."
        )

    core.ensure_db_schema()
    account = core.mt5_initialize()
    core.detect_mt5_time_offset(force=True)

    if not core.MT5_TIME_OFFSET_CONFIDENT:
        core.log.warning(
            "TIME | Время MT5 не удалось однозначно сопоставить с UTC. "
            "Новые DEMO-входы заблокированы до нормальной синхронизации."
        )

    core.clear_mt5_m1_for_rebuild()
    core.initial_candle_backfill()

    trader = core.DemoTrader(
        database_url=core.DATABASE_URL,
        mt5_module=core.mt5,
        symbol=core.MT5_SYMBOL,
        magic=core.MAGIC,
    )

    last_quote_write = 0.0
    last_candle_sync = 0.0
    last_closed_sync = 0.0
    last_cleanup = 0.0
    last_heartbeat = 0.0
    last_market_state_write = 0.0
    latest_closed_m1 = None
    previous_market_state = None
    consecutive_runtime_errors = 0
    consecutive_connection_errors = 0

    core.log.info(
        "DEMO worker AUTO %s + %s запущен. Реальный счёт заблокирован.",
        core.WORKER_VERSION,
        MARKET_STATE_VERSION,
    )

    while not core.STOP:
        try:
            now = time.monotonic()

            try:
                account = core.ensure_mt5_connection()
            except Exception as exc:
                consecutive_connection_errors += 1
                _connection_problem(str(exc))
                try:
                    core.mt5.shutdown()
                except Exception:
                    pass
                time.sleep(core.RECONNECT_SECONDS)
                try:
                    account = core.mt5_initialize()
                    core.initial_candle_backfill()
                except Exception as reconnect_exc:
                    core.log.error(
                        "Повторное подключение MT5 не удалось: %s",
                        reconnect_exc,
                    )

                if consecutive_connection_errors >= WORKER_FATAL_ERROR_LIMIT:
                    _force_launcher_restart(
                        f"MT5 connection loop: {exc}",
                        consecutive_connection_errors,
                    )
                continue

            try:
                tick = core.get_tick()
            except Exception as exc:
                planned, kind = planned_market_closed_now()
                if planned:
                    snapshot = {
                        "state": kind,
                        "reason": "planned market closure; live tick unavailable",
                        "trade_allowed": False,
                        "training_allowed": True,
                        "display_timezone": core.DISPLAY_TIMEZONE,
                        "daily_break_start": DAILY_BREAK_START,
                        "daily_break_end": DAILY_BREAK_END,
                        "version": MARKET_STATE_VERSION,
                        "updated_at_utc": datetime.now(timezone.utc).isoformat(),
                    }
                    log_market_transition(previous_market_state, snapshot)
                    previous_market_state = snapshot["state"]

                    if (
                        last_market_state_write == 0.0
                        or now - last_market_state_write
                        >= MARKET_STATE_HEARTBEAT_SECONDS
                    ):
                        save_market_state(snapshot)
                        last_market_state_write = now

                    if now - last_closed_sync >= core.SYNC_CLOSED_SECONDS:
                        trader.sync_closed_trades()
                        last_closed_sync = now

                    time.sleep(core.POLL_SECONDS)
                    continue

                consecutive_connection_errors += 1
                _connection_problem(str(exc))

                try:
                    core.mt5.shutdown()
                except Exception:
                    pass

                try:
                    account = core.mt5_initialize()
                    core.initial_candle_backfill()
                except Exception as reconnect_exc:
                    core.log.error(
                        "Повторное подключение после ошибки тика не удалось: %s",
                        reconnect_exc,
                    )

                if consecutive_connection_errors >= WORKER_FATAL_ERROR_LIMIT:
                    _force_launcher_restart(
                        f"MT5 tick loop: {exc}",
                        consecutive_connection_errors,
                    )

                time.sleep(core.RECONNECT_SECONDS)
                continue

            # A genuinely fresh tick means the connection recovered.
            consecutive_connection_errors = 0

            if now - last_quote_write >= core.QUOTE_WRITE_SECONDS:
                core.save_quote(tick)
                last_quote_write = now

            if now - last_candle_sync >= core.CANDLE_SYNC_SECONDS:
                synced, latest = core.save_closed_m1_rates(
                    core.CANDLE_REFRESH_COUNT
                )
                if latest is not None:
                    latest_closed_m1 = latest

                if latest is not None and (
                    last_candle_sync == 0.0
                    or int(now) % 30 < int(core.CANDLE_SYNC_SECONDS)
                ):
                    core.log.info(
                        "MT5 M1 | synced=%s | last_closed=%s",
                        synced,
                        latest.isoformat(),
                    )
                last_candle_sync = now

            snapshot = classify_market_state(latest_closed_m1, tick)
            log_market_transition(previous_market_state, snapshot)
            previous_market_state = snapshot["state"]

            if (
                last_market_state_write == 0.0
                or now - last_market_state_write
                >= MARKET_STATE_HEARTBEAT_SECONDS
            ):
                save_market_state(snapshot)
                last_market_state_write = now

            if snapshot["trade_allowed"]:
                trader.step(tick=tick, account=account)

            # Reconciliation stays active even while the market is closed.
            if now - last_closed_sync >= core.SYNC_CLOSED_SECONDS:
                trader.sync_closed_trades()
                last_closed_sync = now

            if now - last_cleanup >= 6 * 60 * 60:
                core.cleanup_old_quotes()
                last_cleanup = now

            if now - last_heartbeat >= 30.0:
                bid = float(tick.bid)
                ask = float(tick.ask)

                core.log.info(
                    "LIVE %s | bid=%.2f ask=%.2f | account=%s | market=%s",
                    core.MT5_SYMBOL,
                    bid,
                    ask,
                    getattr(account, "login", "?"),
                    snapshot["state"],
                )

                core.save_worker_state(
                    "heartbeat",
                    {
                        "alive": True,
                        "demo": True,
                        "version": core.WORKER_VERSION,
                        "market_state_version": MARKET_STATE_VERSION,
                        "market_state": snapshot["state"],
                        "symbol": core.MT5_SYMBOL,
                        "bid": bid,
                        "ask": ask,
                        "account": str(getattr(account, "login", "")),
                        "server": str(getattr(account, "server", "")),
                        "time": datetime.now(timezone.utc).isoformat(),
                    },
                )
                last_heartbeat = now

            # The whole loop completed successfully; clear the runtime streak.
            consecutive_runtime_errors = 0
            time.sleep(core.POLL_SECONDS)

        except KeyboardInterrupt:
            break
        except Exception as exc:
            consecutive_runtime_errors += 1
            core.log.exception("Ошибка AUTO worker: %s", exc)
            core.save_worker_state(
                "last_error",
                {
                    "message": str(exc),
                    "consecutive_failures": consecutive_runtime_errors,
                    "restart_limit": WORKER_FATAL_ERROR_LIMIT,
                    "time": datetime.now(timezone.utc).isoformat(),
                },
            )

            if consecutive_runtime_errors >= WORKER_FATAL_ERROR_LIMIT:
                _force_launcher_restart(
                    f"AUTO main loop: {exc}",
                    consecutive_runtime_errors,
                )

            time.sleep(core.RECONNECT_SECONDS)

    core.log.info("Останавливаю DEMO AUTO worker...")

    try:
        trader.close()
    except Exception:
        pass

    try:
        core.mt5.shutdown()
    except Exception:
        pass

    core.log.info("DEMO AUTO worker остановлен.")


if __name__ == "__main__":
    main()
