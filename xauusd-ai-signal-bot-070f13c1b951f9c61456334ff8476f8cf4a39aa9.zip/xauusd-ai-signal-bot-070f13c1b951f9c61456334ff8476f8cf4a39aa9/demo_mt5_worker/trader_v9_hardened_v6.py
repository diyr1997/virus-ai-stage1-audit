from __future__ import annotations

import os
import time

from trader_legacy import integer, num, utcnow
from trader_v9_hardened_v5 import V9HardenedV5DemoTrader


class V9HardenedV6DemoTrader(V9HardenedV5DemoTrader):
    """DEMO strong-impulse profit protection without nervous early exits.

    V5 extends FAST80 take-profit targets. V6 adds one-way protective SL management
    after the market has already proved the move by reaching TP1/TP2 progress.

    Rules for FAST80 positions only:
      * before TP1: do not tighten the original SL;
      * during the first minute after opening: do not tighten the original SL;
      * after TP1: move SL no farther than breakeven plus a small protected fraction;
      * after TP2: lock at least the TP1 zone while allowing the position to run;
      * never loosen an existing SL;
      * never move SL across the executable market price;
      * never touch non-bot positions or non-DEMO execution guards.
    """

    FAST_PROTECT_ENABLED = str(os.getenv("FAST_PROTECT_ENABLED", "1")).strip().lower() in {
        "1", "true", "yes", "on"
    }
    FAST_PROTECT_TP1_FRACTION = max(
        0.0, min(0.50, float(os.getenv("FAST_PROTECT_TP1_FRACTION", "0.10")))
    )
    FAST_PROTECT_MIN_INTERVAL = max(
        1.0, float(os.getenv("FAST_PROTECT_MIN_INTERVAL", "2.0"))
    )
    FAST_PROTECT_MIN_HOLD_SECONDS = max(
        0.0, float(os.getenv("FAST_PROTECT_MIN_HOLD_SECONDS", "60"))
    )

    PIPELINE_EVENTS = V9HardenedV5DemoTrader.PIPELINE_EVENTS | {
        "FAST_PROTECT_SL_MOVED",
        "FAST_PROTECT_SL_BLOCKED",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._fast_protect_last_at = {}

    def _strong_open_contexts(self):
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT d.id AS trade_id,
                           d.candidate_id,
                           d.mt5_ticket,
                           d.side,
                           d.opened_at,
                           COALESCE(d.entry_price,d.planned_price) AS entry_price,
                           d.sl AS db_sl,
                           d.tp AS db_tp,
                           tc.strength,
                           tc.tp1,
                           tc.tp2,
                           tc.tp3
                    FROM demo_trades d
                    JOIN trade_candidates tc ON tc.id=d.candidate_id
                    WHERE d.symbol=%s
                      AND d.status='OPEN'
                      AND tc.strength >= %s
                    ORDER BY d.id ASC
                    """,
                    (self.symbol, int(self.FAST_ENTRY_MIN_STRENGTH)),
                )
                names = [d[0] for d in cur.description]
                return [dict(zip(names, row)) for row in cur.fetchall()]
        finally:
            conn.close()

    def _position_by_ticket(self, ticket):
        ticket = integer(ticket, 0)
        if ticket <= 0:
            return None
        for position in self.bot_mt5_positions():
            if integer(getattr(position, "ticket", 0), 0) == ticket:
                return position
        return None

    @staticmethod
    def _reached(side, price, level):
        side = str(side or "").upper()
        price = num(price)
        level = num(level)
        if price <= 0 or level <= 0:
            return False
        return price >= level if side == "BUY" else price <= level

    def _protective_sl(self, row, position, tick):
        side = str(row.get("side") or "").upper()
        entry = num(getattr(position, "price_open", 0.0)) or num(row.get("entry_price"))
        current_sl = num(getattr(position, "sl", 0.0)) or num(row.get("db_sl"))
        tp1 = num(row.get("tp1"))
        tp2 = num(row.get("tp2"))
        if side == "BUY":
            executable = num(getattr(tick, "bid", 0.0))
        else:
            executable = num(getattr(tick, "ask", 0.0))
        if side not in {"BUY", "SELL"} or entry <= 0 or executable <= 0 or tp1 <= 0:
            return None, "INVALID_INPUT"

        target_sl = None
        stage = None

        if tp2 > 0 and self._reached(side, executable, tp2):
            target_sl = tp1
            stage = "TP2_REACHED_LOCK_TP1"
        elif self._reached(side, executable, tp1):
            distance = abs(tp1 - entry)
            if distance <= 0:
                return None, "INVALID_TP1_DISTANCE"
            protected = distance * self.FAST_PROTECT_TP1_FRACTION
            target_sl = entry + protected if side == "BUY" else entry - protected
            stage = "TP1_REACHED_PROTECT_ENTRY"
        else:
            return None, "BEFORE_TP1_NO_TIGHTEN"

        # One-way tightening only.
        if side == "BUY":
            if current_sl > 0 and target_sl <= current_sl:
                return None, "NO_IMPROVEMENT"
            if target_sl >= executable:
                return None, "TARGET_SL_AT_OR_ABOVE_MARKET"
        else:
            if current_sl > 0 and target_sl >= current_sl:
                return None, "NO_IMPROVEMENT"
            if target_sl <= executable:
                return None, "TARGET_SL_AT_OR_BELOW_MARKET"

        return float(target_sl), stage

    def _modify_position_sl(self, row, position, new_sl, stage):
        ticket = integer(getattr(position, "ticket", 0), 0)
        if ticket <= 0 or new_sl is None:
            return False
        current_tp = num(getattr(position, "tp", 0.0)) or num(row.get("db_tp"))
        request = {
            "action": self.mt5.TRADE_ACTION_SLTP,
            "symbol": self.symbol,
            "position": ticket,
            "sl": float(new_sl),
            "tp": float(current_tp),
            "magic": int(self.magic),
        }
        try:
            result = self.mt5.order_send(request)
        except Exception as exc:
            self.event(
                "FAST_PROTECT_SL_BLOCKED",
                row.get("candidate_id"),
                row.get("trade_id"),
                {"reason": "SLTP_EXCEPTION", "error": str(exc), "ticket": str(ticket)},
            )
            return False
        if result is None:
            self.event(
                "FAST_PROTECT_SL_BLOCKED",
                row.get("candidate_id"),
                row.get("trade_id"),
                {"reason": "SLTP_NONE", "ticket": str(ticket), "error": str(self.mt5.last_error())},
            )
            return False
        retcode = integer(getattr(result, "retcode", -1), -1)
        accepted = {
            integer(getattr(self.mt5, "TRADE_RETCODE_DONE", 10009), 10009),
            integer(getattr(self.mt5, "TRADE_RETCODE_NO_CHANGES", 10025), 10025),
        }
        if retcode not in accepted:
            self.event(
                "FAST_PROTECT_SL_BLOCKED",
                row.get("candidate_id"),
                row.get("trade_id"),
                {
                    "reason": "SLTP_REJECTED",
                    "retcode": retcode,
                    "comment": str(getattr(result, "comment", "")),
                    "ticket": str(ticket),
                    "requested_sl": float(new_sl),
                },
            )
            return False

        self.event(
            "FAST_PROTECT_SL_MOVED",
            row.get("candidate_id"),
            row.get("trade_id"),
            {
                "reason": stage,
                "strength": integer(row.get("strength"), 0),
                "side": str(row.get("side") or "").upper(),
                "ticket": str(ticket),
                "entry": num(getattr(position, "price_open", 0.0)) or num(row.get("entry_price")),
                "old_sl": num(getattr(position, "sl", 0.0)) or num(row.get("db_sl")),
                "new_sl": float(new_sl),
                "tp": current_tp,
                "tp1": num(row.get("tp1")),
                "tp2": num(row.get("tp2")),
                "tp3": num(row.get("tp3")),
            },
        )
        return True

    def _protect_fast_positions(self, tick, account):
        if not self.FAST_PROTECT_ENABLED:
            return
        self.assert_demo(account)
        now = time.monotonic()
        now_utc = utcnow()
        for row in self._strong_open_contexts():
            trade_id = integer(row.get("trade_id"), 0)
            if trade_id <= 0:
                continue

            opened_at = row.get("opened_at")
            if opened_at is not None:
                try:
                    if opened_at.tzinfo is None:
                        opened_at = opened_at.replace(tzinfo=now_utc.tzinfo)
                    age_seconds = max(0.0, (now_utc - opened_at).total_seconds())
                except Exception:
                    age_seconds = 0.0
                if age_seconds < self.FAST_PROTECT_MIN_HOLD_SECONDS:
                    continue

            if now - self._fast_protect_last_at.get(trade_id, 0.0) < self.FAST_PROTECT_MIN_INTERVAL:
                continue
            self._fast_protect_last_at[trade_id] = now
            position = self._position_by_ticket(row.get("mt5_ticket"))
            if position is None:
                continue
            new_sl, stage = self._protective_sl(row, position, tick)
            if new_sl is None:
                continue
            self._modify_position_sl(row, position, new_sl, stage)

    def step(self, tick, account):
        # Manage already-open FAST80 positions first. This never opens a new order
        # and preserves the original protective SL until TP1 has actually been reached.
        try:
            self._protect_fast_positions(tick, account)
        except Exception as exc:
            # Exit protection must fail open with respect to the existing broker SL/TP:
            # a protection-management bug must never remove or weaken those safeguards.
            print(f"[V9 FAST PROTECT] observer error | {exc}", flush=True)
        return super().step(tick, account)


DemoTraderV9Final = V9HardenedV6DemoTrader
