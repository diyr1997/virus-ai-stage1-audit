from __future__ import annotations

import math
import time
from collections import deque
from typing import Any, Callable, Deque, Optional


def _num(value: Any, default: float = 0.0) -> float:
    try:
        value = float(value)
        return value if math.isfinite(value) else default
    except (TypeError, ValueError):
        return default


class ShadowOutcomeTracker:
    """SHADOW ONLY: scores hypothetical FAST decisions against later live prices.

    No order APIs are used. The tracker records MFE/MAE and mark-to-market outcome
    at fixed horizons so FAST/LATE/NOISE thresholds can be calibrated from evidence.
    """

    HORIZONS = (30, 60, 180, 300)

    def __init__(self, event_sink: Optional[Callable[..., None]] = None, max_pending: int = 256):
        self.event_sink = event_sink
        self.pending: Deque[dict] = deque(maxlen=max(32, int(max_pending)))
        self._last_signal_key = ""
        self._last_signal_at = 0.0

    def _emit(self, event_type: str, payload: dict) -> None:
        if not callable(self.event_sink):
            return
        try:
            self.event_sink(event_type, payload=payload)
        except Exception:
            pass

    @staticmethod
    def _signed_move(side: str, entry: float, price: float) -> float:
        return price - entry if side == "BUY" else entry - price

    def observe(self, snapshot: dict) -> list[dict]:
        if not snapshot or str(snapshot.get("state") or "") == "WARMUP":
            return []

        now = _num(snapshot.get("tick_ts"), time.time())
        bid = _num(snapshot.get("bid"))
        ask = _num(snapshot.get("ask"))
        mid = _num(snapshot.get("current_price")) or ((bid + ask) / 2.0 if bid > 0 and ask > 0 else 0.0)
        if mid <= 0:
            return []

        completed: list[dict] = []
        for item in list(self.pending):
            side = item["side"]
            move = self._signed_move(side, item["entry_mid"], mid)
            item["mfe"] = max(item["mfe"], move)
            item["mae"] = min(item["mae"], move)
            age = max(0.0, now - item["started_at"])

            for horizon in self.HORIZONS:
                key = str(horizon)
                if key in item["horizons"] or age < horizon:
                    continue
                result = {
                    "signal_id": item["signal_id"],
                    "horizon_sec": horizon,
                    "side": side,
                    "shadow_recommendation": item["recommendation"],
                    "shadow_reason": item["reason"],
                    "quality_score": item["quality_score"],
                    "impulse_score": item["impulse_score"],
                    "late_penalty": item["late_penalty"],
                    "entry_mid": round(item["entry_mid"], 6),
                    "mark_mid": round(mid, 6),
                    "signed_move": round(move, 6),
                    "mfe": round(item["mfe"], 6),
                    "mae": round(abs(min(0.0, item["mae"])), 6),
                    "mfe_atr": round(item["mfe"] / item["atr"], 4) if item["atr"] > 0 else None,
                    "mae_atr": round(abs(min(0.0, item["mae"])) / item["atr"], 4) if item["atr"] > 0 else None,
                    "net_atr": round(move / item["atr"], 4) if item["atr"] > 0 else None,
                    "would_have_helped": (
                        move > 0 if item["recommendation"] == "WOULD_ALLOW_FAST_ENTRY" else move <= 0
                    ),
                    "shadow_only": True,
                    "execution_impact": "NONE",
                }
                item["horizons"][key] = result
                completed.append(result)
                self._emit("SHADOW_FAST_OUTCOME", result)

            if age >= max(self.HORIZONS):
                try:
                    self.pending.remove(item)
                except ValueError:
                    pass

        fast = dict(snapshot.get("fast_entry_shadow") or {})
        impulse = _num(fast.get("impulse_score", snapshot.get("impulse_score")))
        side = str(fast.get("side") or snapshot.get("direction") or "FLAT").upper()
        recommendation = str(fast.get("recommendation") or "")
        reason = str(fast.get("primary_reason") or "")

        # Track only genuine FAST80 opportunities. This captures both hypothetical
        # ALLOW and BLOCK decisions, which is required to measure false positives
        # and false negatives of the shadow gate.
        if impulse >= 80.0 and side in {"BUY", "SELL"} and recommendation:
            key = f"{side}:{recommendation}:{reason}:{round(mid, 2)}"
            if key != self._last_signal_key or now - self._last_signal_at >= 30.0:
                signal_id = f"{int(now * 1000)}:{side}:{len(self.pending)}"
                item = {
                    "signal_id": signal_id,
                    "started_at": now,
                    "entry_mid": mid,
                    "side": side,
                    "recommendation": recommendation,
                    "reason": reason,
                    "quality_score": _num(fast.get("quality_score")),
                    "impulse_score": impulse,
                    "late_penalty": _num(fast.get("late_penalty", snapshot.get("late_penalty"))),
                    "atr": _num(snapshot.get("atr_m1")),
                    "mfe": 0.0,
                    "mae": 0.0,
                    "horizons": {},
                }
                self.pending.append(item)
                start_payload = {
                    "signal_id": signal_id,
                    "side": side,
                    "recommendation": recommendation,
                    "reason": reason,
                    "quality_score": item["quality_score"],
                    "impulse_score": impulse,
                    "late_penalty": item["late_penalty"],
                    "entry_mid": round(mid, 6),
                    "atr_m1": round(item["atr"], 6),
                    "shadow_only": True,
                    "execution_impact": "NONE",
                }
                self._emit("SHADOW_FAST_SIGNAL", start_payload)
                self._last_signal_key = key
                self._last_signal_at = now

        return completed
