@echo off
chcp 65001 >nul
setlocal
title XAUUSD DEMO WORKER - V9 DIAGNOSTIC

set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
cd /d "%~dp0"

if not exist "config_private.bat" (
    echo [ERROR] Не найден config_private.bat
    echo Скопируй config_private.example.bat в config_private.bat и заполни локальные данные.
    pause
    exit /b 1
)
call "config_private.bat"

set "DEMO_WORKER_VERSION=xauusd-demo-worker-v9-fenced-basket-v3-2026-08-21"
if "%GOLD_DAILY_BREAK_START%"=="" set "GOLD_DAILY_BREAK_START=01:55"
if "%GOLD_DAILY_BREAK_END%"=="" set "GOLD_DAILY_BREAK_END=03:10"
if "%DEMO_REVERSAL_ENABLED%"=="" set "DEMO_REVERSAL_ENABLED=0"

where py >nul 2>nul
if not errorlevel 1 (
    set "PYTHON_CMD=py"
) else (
    where python >nul 2>nul
    if not errorlevel 1 (
        set "PYTHON_CMD=python"
    ) else (
        echo [ERROR] Python не найден.
        pause
        exit /b 1
    )
)

%PYTHON_CMD% -m pip install -r requirements.txt
if errorlevel 1 (
    echo [ERROR] Не удалось установить библиотеки.
    pause
    exit /b 1
)

echo ==========================================
echo READ-ONLY V9 DIAGNOSTIC
echo Ордеры этим скриптом НЕ отправляются.
echo ==========================================
%PYTHON_CMD% diagnose_v9.py
set "DIAG_EXIT=%errorlevel%"

echo.
if "%DIAG_EXIT%"=="0" (
    echo [OK] Диагностика пройдена.
) else (
    echo [WARNING] Диагностика нашла проблему. Код: %DIAG_EXIT%
    echo Посмотри строки FAIL выше - там точная причина DB / MT5 / GOLD / M1 / TIME.
)

pause
endlocal
exit /b %DIAG_EXIT%
