from __future__ import annotations

import os
import time

import worker_auto as auto
from worker_stage_timing import install_worker_timing


# A live Python process is not enough to prove that MT5 data is live.
# Some MT5 failure modes keep returning the last tick forever. In that case
# worker_auto used to remain in PAUSED indefinitely and the BAT launcher never
# got a non-zero exit to restart it.
STALE_FEED_RESTART_SECONDS = max(
    120.0,
    float(os.getenv("STALE_FEED_RESTART_SECONDS", "180")),
)

_original_classify_market_state = auto.classify_market_state
_original_save_quote = auto.core.save_quote
_stale_feed_since: float | None = None
_last_stale_quote_log = 0.0


def guarded_save_quote(tick):
    """Never refresh mt5_quotes.received_at with an old broker tick."""
    global _last_stale_quote_log

    age = auto.tick_age_seconds(tick)
    if not (-auto.core.MAX_FUTURE_SECONDS <= age <= auto.MARKET_TICK_STALE_SECONDS):
        now = time.monotonic()
        if _last_stale_quote_log == 0.0 or now - _last_stale_quote_log >= 30.0:
            auto.core.log.warning(
                "STALE FEED | quote write skipped | tick_age=%.1fs | max=%.1fs",
                age,
                float(auto.MARKET_TICK_STALE_SECONDS),
            )
            _last_stale_quote_log = now
        return None

    return _original_save_quote(tick)


def guarded_classify_market_state(latest_closed_m1, tick):
    """Restart the worker when stale MT5 data persists while market should be open."""
    global _stale_feed_since

    snapshot = _original_classify_market_state(latest_closed_m1, tick)
    planned_closed, planned_kind = auto.planned_market_closed_now()
    stale_state = snapshot.get("state") in {"PAUSED", "TIME_GUARD", "OPENING_SYNC"}

    if planned_closed:
        _stale_feed_since = None
        return snapshot

    if snapshot.get("state") == "OPEN":
        _stale_feed_since = None
        return snapshot

    if not stale_state:
        _stale_feed_since = None
        return snapshot

    now = time.monotonic()
    if _stale_feed_since is None:
        _stale_feed_since = now

    stale_for = max(0.0, now - _stale_feed_since)
    snapshot["stale_feed_seconds"] = round(stale_for, 1)
    snapshot["stale_feed_restart_seconds"] = STALE_FEED_RESTART_SECONDS
    snapshot["planned_market_closed"] = False
    snapshot["planned_market_state"] = planned_kind or None

    if stale_for >= STALE_FEED_RESTART_SECONDS:
        reason = (
            f"stale MT5 feed persisted {stale_for:.0f}s while market is expected open; "
            f"state={snapshot.get('state')}; "
            f"tick_age={snapshot.get('tick_age_seconds')}s; "
            f"m1_age={snapshot.get('m1_age_seconds')}s"
        )
        auto.save_market_state(snapshot)
        auto._force_launcher_restart(reason, auto.WORKER_FATAL_ERROR_LIMIT)

    return snapshot


# Install stale-feed guards first. Timing wraps the final guarded callables so
# measurements reflect the path that the actual watchdog worker executes.
auto.core.save_quote = guarded_save_quote
auto.classify_market_state = guarded_classify_market_state

# Timing is opt-in even on this research branch. Set WORKER_TIMING_ENABLED=1 for
# the dedicated Windows diagnostic run; setting it back to 0 disables timing
# without changing code or touching the trading path.
WORKER_TIMING_OBSERVER = install_worker_timing(auto)


def main():
    auto.core.log.info(
        "WATCHDOG V2 active | stale-feed restart after %.0fs | stale quote DB writes blocked",
        STALE_FEED_RESTART_SECONDS,
    )
    auto.core.log.info(
        "WORKER TIMING diagnostic | enabled=%s | stdout/in-memory | trade logic unchanged",
        "YES" if WORKER_TIMING_OBSERVER is not None else "NO",
    )
    auto.main()


if __name__ == "__main__":
    main()
