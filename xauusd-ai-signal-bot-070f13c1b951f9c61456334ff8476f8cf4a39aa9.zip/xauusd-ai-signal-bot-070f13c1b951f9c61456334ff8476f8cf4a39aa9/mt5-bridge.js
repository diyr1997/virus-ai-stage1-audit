"use strict";

const http = require("http");
const { URL } = require("url");
const qs = require("querystring");
const { Pool } = require("pg");

const PORT = Number(process.env.PORT || 3000);
const DATABASE_URL = process.env.DATABASE_URL || "";
const SECRET = process.env.MT5_BRIDGE_SECRET || "";

const SYMBOL = String(
  process.env.MT5_SYMBOL || "XAUUSD"
).toUpperCase();

const MIN_STRENGTH = Math.max(
  1,
  Math.min(
    100,
    Number(
      process.env.TRADE_MIN_STRENGTH || 70
    )
  )
);

const TFS = String(
  process.env.TRADE_TIMEFRAMES || "M5,M15"
)
  .split(",")
  .map(x => x.trim().toUpperCase())
  .filter(Boolean);

const LOT_PER_LEG = 0.01;
const LEGS = 3;
const TOTAL_LOT = LOT_PER_LEG * LEGS;

const PENDING_TIMEOUT_SEC = Math.max(
  30,
  Number(
    process.env.MT5_PENDING_TIMEOUT_SECONDS || 180
  )
);

const QUOTE_SAVE_INTERVAL_MS = Math.max(
  1000,
  Number(
    process.env.MT5_QUOTE_SAVE_INTERVAL_MS || 5000
  )
);

if (!DATABASE_URL) {
  throw new Error("DATABASE_URL не найден");
}

if (!SECRET) {
  throw new Error("MT5_BRIDGE_SECRET не найден");
}

const db = new Pool({
  connectionString: DATABASE_URL,
  max: 5,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000,
});

let lastQuoteSavedAt = 0;

function n(v, fallback = null) {
  const x = Number(v);

  return Number.isFinite(x)
    ? x
    : fallback;
}

function clean(v) {
  return String(v ?? "")
    .replace(/[\r\n=]/g, " ")
    .trim();
}

function send(res, code, obj) {
  const body =
    Object.entries(obj)
      .map(
        ([k, v]) =>
          `${k}=${clean(v)}`
      )
      .join("\n") + "\n";

  res.writeHead(code, {
    "Content-Type":
      "text/plain; charset=utf-8",

    "Cache-Control":
      "no-store",
  });

  res.end(body);
}

async function readBody(req) {
  const chunks = [];
  let size = 0;

  for await (const chunk of req) {
    size += chunk.length;

    if (size > 65536) {
      throw new Error(
        "BODY_TOO_LARGE"
      );
    }

    chunks.push(chunk);
  }

  const raw =
    Buffer.concat(chunks)
      .toString("utf8")
      .trim();

  if (!raw) {
    return {};
  }

  if (
    String(
      req.headers["content-type"] || ""
    ).includes("application/json")
  ) {
    return JSON.parse(raw);
  }

  return qs.parse(raw);
}

function authorized(
  req,
  url,
  body
) {
  return (
    String(
      req.headers["x-bridge-token"] || ""
    ) === SECRET ||

    String(
      url.searchParams.get("token") || ""
    ) === SECRET ||

    String(
      body.token || ""
    ) === SECRET
  );
}

function brokerDate(v) {
  const x = n(v);

  if (!x) {
    return null;
  }

  const d =
    new Date(
      x > 10000000000
        ? x
        : x * 1000
    );

  return Number.isNaN(
    d.getTime()
  )
    ? null
    : d;
}

async function initDb() {
  await db.query("SELECT 1");

  for (
    const table of [
      "mt5_quotes",
      "trade_candidates",
      "demo_trades",
    ]
  ) {
    const r =
      await db.query(
        "SELECT to_regclass($1) AS name",
        [table]
      );

    if (!r.rows[0].name) {
      throw new Error(
        `Таблица ${table} не найдена. Сначала должен быть запущен index.js V3.`
      );
    }
  }

  await db.query(`
    ALTER TABLE demo_trades
    ADD COLUMN IF NOT EXISTS
    bundle_id VARCHAR(80)
  `);

  await db.query(`
    ALTER TABLE demo_trades
    ADD COLUMN IF NOT EXISTS
    leg_no SMALLINT
  `);

  await db.query(`
    ALTER TABLE demo_trades
    ADD COLUMN IF NOT EXISTS
    target_name VARCHAR(12)
  `);

  await db.query(`
    CREATE INDEX IF NOT EXISTS
    idx_demo_trades_active
    ON demo_trades(symbol, status)
  `);

  await db.query(`
    CREATE INDEX IF NOT EXISTS
    idx_demo_trades_bundle
    ON demo_trades(bundle_id)
  `);

  console.log(
    "✅ MT5 Bridge DB готова"
  );
}

async function saveQuote(body) {
  const now = Date.now();

  if (
    now - lastQuoteSavedAt <
    QUOTE_SAVE_INTERVAL_MS
  ) {
    return;
  }

  lastQuoteSavedAt = now;

  const bid = n(body.bid);
  const ask = n(body.ask);

  const digits =
    Math.max(
      0,
      Math.min(
        8,
        Math.trunc(
          n(body.digits, 2)
        )
      )
    );

  await db.query(
    `
      INSERT INTO mt5_quotes(
        broker_time,
        symbol,
        bid,
        ask,
        spread,
        digits,
        source
      )

      VALUES(
        $1,$2,$3,$4,$5,$6,'MT5'
      )
    `,
    [
      brokerDate(
        body.broker_time ||
        body.time
      ),

      String(
        body.symbol || SYMBOL
      ).toUpperCase(),

      bid,
      ask,
      ask - bid,
      digits,
    ]
  );
}

async function refreshCandidateStatus(
  candidateId
) {
  if (!candidateId) {
    return;
  }

  const r =
    await db.query(
      `
        SELECT
          COUNT(*) FILTER(
            WHERE status IN (
              'PENDING',
              'OPEN'
            )
          )::int AS active,

          COUNT(*) FILTER(
            WHERE status='CLOSED'
          )::int AS closed,

          COUNT(*) FILTER(
            WHERE status='FAILED'
          )::int AS failed,

          COUNT(*)::int AS total

        FROM demo_trades

        WHERE candidate_id=$1
      `,
      [candidateId]
    );

  const row =
    r.rows[0];

  let status =
    "CLAIMED";

  if (
    Number(row.active) > 0
  ) {
    status = "OPEN";
  } else if (
    Number(row.total) > 0 &&
    Number(row.closed) +
      Number(row.failed) ===
      Number(row.total)
  ) {
    status =
      Number(row.closed) > 0
        ? "CLOSED"
        : "FAILED";
  }

  await db.query(
    `
      UPDATE trade_candidates
      SET status=$2
      WHERE id=$1
    `,
    [
      candidateId,
      status,
    ]
  );
}

async function tick(body) {
  const symbol =
    String(
      body.symbol || SYMBOL
    ).toUpperCase();

  const bid = n(body.bid);
  const ask = n(body.ask);

  const account =
    clean(
      body.account || ""
    );

  const positionCount =
    Math.max(
      0,
      Math.trunc(
        n(
          body.position_count,

          String(
            body.has_position || "0"
          ) === "1"
            ? 1
            : 0
        )
      )
    );

  if (
    !bid ||
    !ask ||
    bid <= 0 ||
    ask <= 0 ||
    ask < bid
  ) {
    return {
      action: "ERROR",
      reason: "BAD_QUOTE",
    };
  }

  await saveQuote({
    ...body,
    symbol,
    bid,
    ask,
  });

  const client =
    await db.connect();

  try {
    await client.query(
      "BEGIN"
    );

    await client.query(`
      UPDATE trade_candidates

      SET status='EXPIRED'

      WHERE status IN (
        'WAIT_CONFIRMATION',
        'CONFIRMED'
      )

      AND expires_at IS NOT NULL

      AND expires_at <= NOW()
    `);

    await client.query(
      `
        UPDATE demo_trades

        SET
          status='FAILED',
          closed_at=NOW(),
          close_reason='PENDING_TIMEOUT'

        WHERE status='PENDING'

        AND created_at <
          NOW() -
          $1 * INTERVAL '1 second'
      `,
      [
        PENDING_TIMEOUT_SEC,
      ]
    );

    if (
      positionCount > 0
    ) {
      await client.query(
        "COMMIT"
      );

      return {
        action: "NONE",

        reason:
          "MT5_ALREADY_HAS_POSITION",

        position_count:
          positionCount,
      };
    }

    const active =
      await client.query(
        `
          SELECT
            bundle_id,

            COUNT(*)::int
              AS legs

          FROM demo_trades

          WHERE symbol=$1

          AND status IN (
            'PENDING',
            'OPEN'
          )

          GROUP BY bundle_id

          ORDER BY MAX(id) DESC

          LIMIT 1
        `,
        [symbol]
      );

    if (
      active.rows.length
    ) {
      await client.query(
        "COMMIT"
      );

      return {
        action: "NONE",

        reason:
          "BUNDLE_ALREADY_ACTIVE",

        bundle_id:
          active.rows[0]
            .bundle_id,

        legs:
          active.rows[0]
            .legs,
      };
    }

    const candidates =
      await client.query(
        `
          SELECT *

          FROM trade_candidates

          WHERE symbol=$1

          AND status IN (
            'WAIT_CONFIRMATION',
            'CONFIRMED'
          )

          AND strength >= $2

          AND timeframe =
            ANY($3::text[])

          AND (
            expires_at IS NULL
            OR expires_at > NOW()
          )

          ORDER BY
            strength DESC,
            created_at DESC

          FOR UPDATE
          SKIP LOCKED

          LIMIT 20
        `,
        [
          symbol,
          MIN_STRENGTH,
          TFS,
        ]
      );

    let selected = null;
    let waiting = null;

    for (
      const c
      of candidates.rows
    ) {
      const side =
        String(
          c.side
        ).toUpperCase();

      const confirm =
        Number(
          c.confirmation_price
        );

      const invalid =
        n(
          c.invalidation_price
        );

      const invalidated =
        (
          side === "BUY" &&
          invalid !== null &&
          bid <= invalid
        )
        ||
        (
          side === "SELL" &&
          invalid !== null &&
          ask >= invalid
        );

      if (invalidated) {
        await client.query(
          `
            UPDATE trade_candidates
            SET status='INVALIDATED'
            WHERE id=$1
          `,
          [c.id]
        );

        continue;
      }

      const confirmed =
        (
          side === "BUY" &&
          ask >= confirm
        )
        ||
        (
          side === "SELL" &&
          bid <= confirm
        );

      if (confirmed) {
        selected = c;
        break;
      }

      if (!waiting) {
        waiting = c;
      }
    }

    if (!selected) {
      await client.query(
        "COMMIT"
      );

      if (!waiting) {
        return {
          action: "NONE",

          reason:
            "NO_ELIGIBLE_CANDIDATE",
        };
      }

      return {
        action: "NONE",

        reason:
          "WAIT_CONFIRMATION",

        candidate_id:
          waiting.id,

        side:
          waiting.side,

        timeframe:
          waiting.timeframe,

        strength:
          waiting.strength,

        confirmation_price:
          waiting.confirmation_price,
      };
    }

    const side =
      String(
        selected.side
      ).toUpperCase();

    const bundleId =
      `${selected.id}-${Date.now()}`;

    const targets = [
      {
        leg: 1,
        name: "TP1",
        tp:
          Number(
            selected.tp1
          ),
      },

      {
        leg: 2,
        name: "TP2",
        tp:
          Number(
            selected.tp2
          ),
      },

      {
        leg: 3,
        name: "TP3",
        tp:
          Number(
            selected.tp3
          ),
      },
    ];

    const tradeIds = [];

    for (
      const t
      of targets
    ) {
      const r =
        await client.query(
          `
            INSERT INTO demo_trades(
              candidate_id,
              analysis_id,

              bundle_id,
              leg_no,
              target_name,

              symbol,
              timeframe,
              side,

              lot,

              planned_price,

              sl,
              tp,

              tp1,
              tp2,
              tp3,

              status,

              demo_account,

              payload
            )

            VALUES(
              $1,$2,$3,$4,$5,
              $6,$7,$8,$9,$10,
              $11,$12,$13,$14,$15,
              'PENDING',
              $16,
              $17::jsonb
            )

            RETURNING id
          `,
          [
            selected.id,

            selected.analysis_id,

            bundleId,

            t.leg,

            t.name,

            symbol,

            selected.timeframe,

            side,

            LOT_PER_LEG,

            selected.confirmation_price,

            selected.sl,

            t.tp,

            selected.tp1,
            selected.tp2,
            selected.tp3,

            account || null,

            JSON.stringify({
              strength:
                Number(
                  selected.strength
                ),

              bid,
              ask,

              spread:
                ask - bid,

              bundleLot:
                TOTAL_LOT,
            }),
          ]
        );

      tradeIds.push(
        r.rows[0].id
      );
    }

    await client.query(
      `
        UPDATE trade_candidates

        SET status='CLAIMED'

        WHERE id=$1
      `,
      [
        selected.id,
      ]
    );

    await client.query(
      `
        UPDATE trade_candidates

        SET status='SUPERSEDED'

        WHERE symbol=$1

        AND status IN (
          'WAIT_CONFIRMATION',
          'CONFIRMED'
        )

        AND id <> $2

        AND created_at <= $3
      `,
      [
        symbol,
        selected.id,
        selected.created_at,
      ]
    );

    await client.query(
      "COMMIT"
    );

    return {
      action:
        "TRADE_BUNDLE",

      bundle_id:
        bundleId,

      candidate_id:
        selected.id,

      symbol,

      side,

      timeframe:
        selected.timeframe,

      strength:
        selected.strength,

      confirmation_price:
        selected.confirmation_price,

      sl:
        selected.sl,

      leg_count:
        3,

      lot_each:
        LOT_PER_LEG.toFixed(2),

      total_lot:
        TOTAL_LOT.toFixed(2),

      trade_id_1:
        tradeIds[0],

      tp_1:
        selected.tp1,

      trade_id_2:
        tradeIds[1],

      tp_2:
        selected.tp2,

      trade_id_3:
        tradeIds[2],

      tp_3:
        selected.tp3,
    };
  } catch (error) {
    await client
      .query("ROLLBACK")
      .catch(() => {});

    throw error;
  } finally {
    client.release();
  }
}

async function reportOpen(
  body
) {
  const id =
    Math.trunc(
      n(
        body.trade_id,
        0
      )
    );

  const ticket =
    clean(
      body.ticket || ""
    );

  const entry =
    n(
      body.entry_price
    );

  const lot =
    n(
      body.lot
    );

  if (
    !id ||
    !ticket ||
    !entry ||
    !lot ||
    lot <= 0
  ) {
    return {
      ok: 0,

      reason:
        "BAD_OPEN_REPORT",
    };
  }

  const client =
    await db.connect();

  try {
    await client.query(
      "BEGIN"
    );

    const r =
      await client.query(
        `
          SELECT *

          FROM demo_trades

          WHERE id=$1

          FOR UPDATE
        `,
        [id]
      );

    if (!r.rows.length) {
      await client.query(
        "ROLLBACK"
      );

      return {
        ok: 0,

        reason:
          "TRADE_NOT_FOUND",
      };
    }

    const trade =
      r.rows[0];

    const planned =
      n(
        trade.planned_price,
        entry
      );

    const slippage =
      String(
        trade.side
      ).toUpperCase() ===
      "SELL"

        ? planned - entry

        : entry - planned;

    await client.query(
      `
        UPDATE demo_trades

        SET
          status='OPEN',

          opened_at=
            COALESCE(
              opened_at,
              NOW()
            ),

          mt5_ticket=$2,

          entry_price=$3,

          lot=$4,

          demo_account=
            COALESCE(
              NULLIF($5,''),
              demo_account
            ),

          slippage=$6

        WHERE id=$1
      `,
      [
        id,
        ticket,
        entry,
        lot,

        clean(
          body.account || ""
        ),

        slippage,
      ]
    );

    await client.query(
      "COMMIT"
    );

    await refreshCandidateStatus(
      trade.candidate_id
    );

    return {
      ok: 1,

      trade_id:
        id,

      status:
        "OPEN",

      leg_no:
        trade.leg_no,

      target:
        trade.target_name,
    };
  } catch (error) {
    await client
      .query("ROLLBACK")
      .catch(() => {});

    throw error;
  } finally {
    client.release();
  }
}

async function reportFail(
  body
) {
  const id =
    Math.trunc(
      n(
        body.trade_id,
        0
      )
    );

  if (!id) {
    return {
      ok: 0,

      reason:
        "BAD_TRADE_ID",
    };
  }

  const reason =
    clean(
      body.reason ||
      "ORDER_FAILED"
    ).slice(
      0,
      80
    );

  const r =
    await db.query(
      `
        UPDATE demo_trades

        SET
          status='FAILED',

          closed_at=NOW(),

          close_reason=$2

        WHERE id=$1

        AND status <> 'CLOSED'

        RETURNING
          candidate_id,
          leg_no,
          target_name
      `,
      [
        id,
        reason,
      ]
    );

  if (!r.rows.length) {
    return {
      ok: 0,

      reason:
        "TRADE_NOT_FOUND",
    };
  }

  await refreshCandidateStatus(
    r.rows[0]
      .candidate_id
  );

  return {
    ok: 1,

    trade_id:
      id,

    status:
      "FAILED",

    leg_no:
      r.rows[0].leg_no,

    target:
      r.rows[0]
        .target_name,
  };
}

async function reportClose(
  body
) {
  const id =
    Math.trunc(
      n(
        body.trade_id,
        0
      )
    );

  const ticket =
    clean(
      body.ticket || ""
    );

  const exit =
    n(
      body.exit_price
    );

  const profit =
    n(
      body.profit,
      0
    );

  if (
    (!id && !ticket) ||
    !exit
  ) {
    return {
      ok: 0,

      reason:
        "BAD_CLOSE_REPORT",
    };
  }

  const client =
    await db.connect();

  try {
    await client.query(
      "BEGIN"
    );

    const r =
      id

        ? await client.query(
            `
              SELECT *

              FROM demo_trades

              WHERE id=$1

              FOR UPDATE
            `,
            [id]
          )

        : await client.query(
            `
              SELECT *

              FROM demo_trades

              WHERE mt5_ticket=$1

              ORDER BY id DESC

              LIMIT 1

              FOR UPDATE
            `,
            [ticket]
          );

    if (!r.rows.length) {
      await client.query(
        "ROLLBACK"
      );

      return {
        ok: 0,

        reason:
          "TRADE_NOT_FOUND",
      };
    }

    const trade =
      r.rows[0];

    if (
      trade.status ===
      "CLOSED"
    ) {
      await client.query(
        "ROLLBACK"
      );

      return {
        ok: 1,

        trade_id:
          trade.id,

        status:
          "ALREADY_CLOSED",
      };
    }

    await client.query(
      `
        UPDATE demo_trades

        SET
          status='CLOSED',

          closed_at=NOW(),

          exit_price=$2,

          profit=$3,

          close_reason=$4

        WHERE id=$1
      `,
      [
        trade.id,

        exit,

        profit,

        clean(
          body.reason ||
          "CLOSED"
        ).slice(
          0,
          80
        ),
      ]
    );

    await client.query(
      "COMMIT"
    );

    await refreshCandidateStatus(
      trade.candidate_id
    );

    return {
      ok: 1,

      trade_id:
        trade.id,

      status:
        "CLOSED",

      leg_no:
        trade.leg_no,

      target:
        trade.target_name,

      profit,
    };
  } catch (error) {
    await client
      .query("ROLLBACK")
      .catch(() => {});

    throw error;
  } finally {
    client.release();
  }
}

async function stats() {
  const r =
    await db.query(`
      SELECT
        COUNT(*)::int
          AS positions,

        COUNT(
          DISTINCT bundle_id
        )::int
          AS bundles,

        COUNT(*) FILTER(
          WHERE status='OPEN'
        )::int
          AS open,

        COUNT(*) FILTER(
          WHERE status='CLOSED'
        )::int
          AS closed,

        COUNT(*) FILTER(
          WHERE status='FAILED'
        )::int
          AS failed,

        COUNT(*) FILTER(
          WHERE profit>0
        )::int
          AS wins,

        COUNT(*) FILTER(
          WHERE profit<0
        )::int
          AS losses,

        COUNT(*) FILTER(
          WHERE
            target_name='TP1'
            AND status='CLOSED'
        )::int
          AS tp1_closed,

        COUNT(*) FILTER(
          WHERE
            target_name='TP2'
            AND status='CLOSED'
        )::int
          AS tp2_closed,

        COUNT(*) FILTER(
          WHERE
            target_name='TP3'
            AND status='CLOSED'
        )::int
          AS tp3_closed,

        COALESCE(
          SUM(profit),
          0
        )::numeric
          AS net

      FROM demo_trades
    `);

  const x =
    r.rows[0];

  const decided =
    Number(x.wins) +
    Number(x.losses);

  return {
    ok: 1,

    bundles:
      x.bundles,

    positions:
      x.positions,

    open:
      x.open,

    closed:
      x.closed,

    failed:
      x.failed,

    wins:
      x.wins,

    losses:
      x.losses,

    win_rate:
      decided
        ? (
            Number(x.wins) /
            decided *
            100
          ).toFixed(1)
        : "0.0",

    tp1_closed:
      x.tp1_closed,

    tp2_closed:
      x.tp2_closed,

    tp3_closed:
      x.tp3_closed,

    net:
      Number(
        x.net
      ).toFixed(2),
  };
}

const server =
  http.createServer(
    async (
      req,
      res
    ) => {
      const url =
        new URL(
          req.url,

          `http://${
            req.headers.host ||
            "localhost"
          }`
        );

      try {
        if (
          req.method === "GET" &&
          url.pathname === "/health"
        ) {
          send(
            res,
            200,
            {
              ok: 1,

              service:
                "xauusd-mt5-bridge",

              symbol:
                SYMBOL,

              min_strength:
                MIN_STRENGTH,

              timeframes:
                TFS.join(","),

              legs:
                LEGS,

              lot_each:
                LOT_PER_LEG.toFixed(2),

              total_lot:
                TOTAL_LOT.toFixed(2),
            }
          );

          return;
        }

        const body =
          req.method === "POST"
            ? await readBody(req)
            : {};

        if (
          !authorized(
            req,
            url,
            body
          )
        ) {
          send(
            res,
            401,
            {
              ok: 0,

              reason:
                "UNAUTHORIZED",
            }
          );

          return;
        }

        if (
          req.method === "POST" &&
          url.pathname ===
            "/api/v1/tick"
        ) {
          const result =
            await tick(body);

          send(
            res,

            result.action ===
            "ERROR"
              ? 400
              : 200,

            result
          );

          return;
        }

        if (
          req.method === "POST" &&
          url.pathname ===
            "/api/v1/trade/open"
        ) {
          const result =
            await reportOpen(
              body
            );

          send(
            res,
            result.ok
              ? 200
              : 400,
            result
          );

          return;
        }

        if (
          req.method === "POST" &&
          url.pathname ===
            "/api/v1/trade/fail"
        ) {
          const result =
            await reportFail(
              body
            );

          send(
            res,
            result.ok
              ? 200
              : 400,
            result
          );

          return;
        }

        if (
          req.method === "POST" &&
          url.pathname ===
            "/api/v1/trade/close"
        ) {
          const result =
            await reportClose(
              body
            );

          send(
            res,
            result.ok
              ? 200
              : 400,
            result
          );

          return;
        }

        if (
          req.method === "GET" &&
          url.pathname ===
            "/api/v1/stats"
        ) {
          send(
            res,
            200,
            await stats()
          );

          return;
        }

        send(
          res,
          404,
          {
            ok: 0,

            reason:
              "NOT_FOUND",
          }
        );
      } catch (error) {
        console.error(
          "❌ Bridge HTTP:",
          error
        );

        send(
          res,
          500,
          {
            ok: 0,

            reason:
              "SERVER_ERROR",

            message:
              error.message,
          }
        );
      }
    }
  );

initDb()
  .then(() => {
    server.listen(
      PORT,
      "0.0.0.0",

      () => {
        console.log(
          `✅ MT5 Bridge: port ${PORT}`
        );

        console.log(
          `✅ ${SYMBOL} | TF ${TFS.join(",")} | min ${MIN_STRENGTH}/100`
        );

        console.log(
          "✅ Пакет: 3 позиции × 0.01 = 0.03"
        );

        console.log(
          "✅ Позиция 1 → TP1"
        );

        console.log(
          "✅ Позиция 2 → TP2"
        );

        console.log(
          "✅ Позиция 3 → TP3"
        );

        console.log(
          "✅ Один общий SL"
        );

        console.log(
          "✅ Новый пакет не открывается, пока старый активен"
        );

        console.log(
          "✅ BUY подтверждается по ASK"
        );

        console.log(
          "✅ SELL подтверждается по BID"
        );
      }
    );
  })
  .catch(
    (
      error
    ) => {
      console.error(
        "❌ MT5 Bridge не запущен:",
        error.message
      );

      process.exit(1);
    }
  );

async function shutdown() {
  server.close(
    () => {}
  );

  await db
    .end()
    .catch(
      () => {}
    );

  process.exit(0);
}

process.once(
  "SIGTERM",
  shutdown
);

process.once(
  "SIGINT",
  shutdown
);

process.on(
  "unhandledRejection",

  error =>
    console.error(
      "❌ UNHANDLED:",
      error
    )
);

process.on(
  "uncaughtException",

  error =>
    console.error(
      "❌ UNCAUGHT:",
      error
    )
);
