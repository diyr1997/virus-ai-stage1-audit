"use strict";

const { randomUUID } = require("crypto");

const DEFAULT_TIMEZONE = "Asia/Tashkent";
const DEFAULT_SCAN_MS = 5_000;
const CLAIM_STALE_MINUTES = 2;

function number(value, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function digits(value) {
  return Math.max(0, Math.min(8, Math.trunc(number(value, 2))));
}

function formatPrice(value, precision = 2) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed.toFixed(digits(precision)) : "—";
}

function formatLot(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed.toFixed(2) : "—";
}

function formatDateTime(value, timeZone = DEFAULT_TIMEZONE) {
  const date = new Date(value);

  if (!Number.isFinite(date.getTime())) {
    return "—";
  }

  return date.toLocaleString("ru-RU", {
    timeZone,
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
}

function riskModeText(value) {
  const mode = String(value || "").trim().toUpperCase();
  const modes = {
    CAUTIOUS: "🛡 Осторожный",
    MEDIUM: "⚖️ Средний",
    ACTIVE: "🔥 Активный",
    AGGRESSIVE: "🚀 Агрессивный",
  };

  return modes[mode] || (mode ? mode : "не указан");
}

function closeReasonText(value) {
  const reason = String(value || "UNKNOWN").trim().toUpperCase();
  const reasons = {
    TP: "TP — цель достигнута",
    SL: "SL — защитная остановка",
    MANUAL: "ручное закрытие",
    REVERSAL: "смена направления",
    EMERGENCY: "аварийное закрытие",
    MT5_CLOSED: "закрыто в MT5 (ручное или другое)",
  };

  return reasons[reason] || reason;
}

function calculateTradePoints(trade) {
  const entry = Number(trade?.entry_price);
  const exit = Number(trade?.exit_price);

  if (!Number.isFinite(entry) || !Number.isFinite(exit)) {
    return null;
  }

  const side = String(trade?.side || "").toUpperCase();
  const movement = side === "SELL" ? entry - exit : exit - entry;
  const point = 10 ** -digits(trade?.digits);

  if (!Number.isFinite(point) || point <= 0) {
    return null;
  }

  return Math.round(movement / point);
}

function signedMoney(value) {
  const parsed = Number(value);

  if (!Number.isFinite(parsed)) {
    return "—";
  }

  return `${parsed > 0 ? "+" : ""}${parsed.toFixed(2)} USD`;
}

function formatDemoTradeAlert(
  trade,
  eventType,
  { timeZone = DEFAULT_TIMEZONE } = {}
) {
  const event = String(eventType || "").toUpperCase();
  const side = String(trade?.side || "—").toUpperCase();
  const sideIcon = side === "BUY" ? "🟢" : side === "SELL" ? "🔴" : "⚪";
  const precision = digits(trade?.digits);
  const payload = trade?.payload && typeof trade.payload === "object"
    ? trade.payload
    : {};
  const slot = payload.slot_no ? ` • позиция ${payload.slot_no}` : "";
  const symbol = String(trade?.symbol || "XAUUSD");
  const timeframe = String(trade?.timeframe || "—").toUpperCase();

  if (event === "OPENED") {
    return `✅ DEMO-СДЕЛКА ОТКРЫТА

🧪 Только MT5 DEMO

${sideIcon} ${side} • XAU/USD (${symbol}) • ${timeframe}

📦 Фактический лот: ${formatLot(trade?.lot)}${slot}
💰 Фактический вход: ${formatPrice(trade?.entry_price, precision)}
🛡 SL: ${formatPrice(trade?.sl, precision)}
🎯 TP: ${formatPrice(trade?.tp, precision)}
🎫 Ticket: ${trade?.mt5_ticket || "—"}
⚙️ Режим риска: ${riskModeText(payload.risk_mode)}
🕒 Исполнено: ${formatDateTime(trade?.opened_at, timeZone)}

Это фактически открытая позиция второго DEMO-бота, а не аналитический сигнал.`;
  }

  const profit = number(trade?.profit, 0);
  const resultIcon = profit > 0 ? "✅" : profit < 0 ? "❌" : "⚪";
  const points = calculateTradePoints(trade);

  return `${resultIcon} DEMO-СДЕЛКА ЗАКРЫТА

🧪 Только MT5 DEMO

${sideIcon} ${side} • XAU/USD (${symbol}) • ${timeframe}

📦 Фактический лот: ${formatLot(trade?.lot)}${slot}
💰 Вход: ${formatPrice(trade?.entry_price, precision)}
🏁 Выход: ${formatPrice(trade?.exit_price, precision)}
🛡 SL: ${formatPrice(trade?.sl, precision)}
🎯 TP: ${formatPrice(trade?.tp, precision)}
🎫 Ticket: ${trade?.mt5_ticket || "—"}
${resultIcon} Результат: ${signedMoney(trade?.profit)}
📏 Движение: ${points === null ? "—" : `${points > 0 ? "+" : ""}${points} пунктов`}
📌 Причина: ${closeReasonText(trade?.close_reason)}
⚙️ Режим риска: ${riskModeText(payload.risk_mode)}
🕒 Закрыто: ${formatDateTime(trade?.closed_at, timeZone)}

Результат сохранён в PostgreSQL для DEMO-статистики.`;
}

async function ensureDemoTradeAlertSchema(client) {
  await client.query(`
    CREATE TABLE IF NOT EXISTS demo_trade_alerts (
      trade_id BIGINT NOT NULL
        REFERENCES demo_trades(id)
        ON DELETE CASCADE,
      event_type VARCHAR(12) NOT NULL
        CHECK(event_type IN('OPENED', 'CLOSED')),
      event_at TIMESTAMPTZ NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      claimed_at TIMESTAMPTZ,
      claim_token VARCHAR(80),
      sent_at TIMESTAMPTZ,
      attempts INTEGER NOT NULL DEFAULT 0,
      last_error TEXT,
      PRIMARY KEY(trade_id, event_type)
    )
  `);

  await client.query(`
    CREATE INDEX IF NOT EXISTS idx_demo_trade_alerts_unsent
    ON demo_trade_alerts(event_at, trade_id)
    WHERE sent_at IS NULL
  `);

  // Первый запуск начинается с текущего момента: старые сделки не рассылаем.
  await client.query(`
    INSERT INTO bot_settings(key, value, updated_at)
    VALUES(
      'demo_trade_alerts_started_at',
      NOW()::text,
      NOW()
    )
    ON CONFLICT(key) DO NOTHING
  `);
}

function createDemoTradeAlertService({
  pool,
  bot,
  ensureReady,
  getOwnerChatId,
  timeZone = DEFAULT_TIMEZONE,
  scanMs = DEFAULT_SCAN_MS,
  logger = console,
}) {
  if (!pool || !bot || !ensureReady || !getOwnerChatId) {
    throw new Error("demo trade alerts: missing dependency");
  }

  let running = false;
  let timer = null;
  let firstTimer = null;

  async function startedAt() {
    const result = await pool.query(`
      SELECT value
      FROM bot_settings
      WHERE key = 'demo_trade_alerts_started_at'
      LIMIT 1
    `);

    const value = result.rows?.[0]?.value;
    const date = new Date(value);
    return Number.isFinite(date.getTime()) ? date : null;
  }

  async function enqueue(since) {
    if (!since) {
      return 0;
    }

    const result = await pool.query(
      `
        INSERT INTO demo_trade_alerts(
          trade_id,
          event_type,
          event_at
        )
        SELECT
          event.trade_id,
          event.event_type,
          event.event_at
        FROM (
          SELECT
            id AS trade_id,
            'OPENED'::varchar AS event_type,
            opened_at AS event_at
          FROM demo_trades
          WHERE opened_at IS NOT NULL
            AND status IN('OPEN', 'CLOSED')
            AND opened_at >= $1

          UNION ALL

          SELECT
            id AS trade_id,
            'CLOSED'::varchar AS event_type,
            closed_at AS event_at
          FROM demo_trades
          WHERE closed_at IS NOT NULL
            AND status = 'CLOSED'
            AND closed_at >= $1
        ) AS event
        ON CONFLICT(trade_id, event_type) DO NOTHING
      `,
      [since]
    );

    return result.rowCount || 0;
  }

  async function claim(limit = 6) {
    const token = randomUUID();
    const result = await pool.query(
      `
        WITH next_alerts AS (
          SELECT trade_id, event_type
          FROM demo_trade_alerts
          WHERE sent_at IS NULL
            AND (
              claimed_at IS NULL
              OR claimed_at < NOW() - INTERVAL '${CLAIM_STALE_MINUTES} minutes'
            )
          ORDER BY event_at ASC, trade_id ASC
          FOR UPDATE SKIP LOCKED
          LIMIT $1
        )
        UPDATE demo_trade_alerts AS alert
        SET
          claimed_at = NOW(),
          claim_token = $2,
          attempts = alert.attempts + 1,
          last_error = NULL
        FROM next_alerts
        WHERE alert.trade_id = next_alerts.trade_id
          AND alert.event_type = next_alerts.event_type
        RETURNING
          alert.trade_id,
          alert.event_type,
          alert.event_at,
          alert.claim_token
      `,
      [Math.max(1, Math.min(20, Number(limit) || 6)), token]
    );

    return result.rows || [];
  }

  async function loadTrade(tradeId) {
    const result = await pool.query(
      `
        SELECT
          trade.*,
          COALESCE(
            (
              SELECT quote.digits
              FROM mt5_quotes AS quote
              WHERE quote.symbol = trade.symbol
              ORDER BY quote.received_at DESC
              LIMIT 1
            ),
            2
          ) AS digits
        FROM demo_trades AS trade
        WHERE trade.id = $1
        LIMIT 1
      `,
      [tradeId]
    );

    return result.rows?.[0] || null;
  }

  async function markSent(alert) {
    await pool.query(
      `
        UPDATE demo_trade_alerts
        SET
          sent_at = NOW(),
          claim_token = NULL,
          last_error = NULL
        WHERE trade_id = $1
          AND event_type = $2
          AND claim_token = $3
      `,
      [alert.trade_id, alert.event_type, alert.claim_token]
    );
  }

  async function markFailed(alert, error) {
    await pool.query(
      `
        UPDATE demo_trade_alerts
        SET
          claim_token = NULL,
          last_error = $4
        WHERE trade_id = $1
          AND event_type = $2
          AND claim_token = $3
      `,
      [
        alert.trade_id,
        alert.event_type,
        alert.claim_token,
        String(error?.message || error || "unknown").slice(0, 1000),
      ]
    );
  }

  async function scan() {
    if (running) {
      return;
    }

    running = true;

    try {
      if (!(await ensureReady())) {
        return;
      }

      const owner = await getOwnerChatId();
      if (!owner) {
        return;
      }

      const since = await startedAt();
      if (!since) {
        return;
      }

      await enqueue(since);
      const alerts = await claim();

      for (const alert of alerts) {
        try {
          const trade = await loadTrade(alert.trade_id);

          if (!trade) {
            await markSent(alert);
            continue;
          }

          await bot.sendMessage(
            owner,
            formatDemoTradeAlert(trade, alert.event_type, { timeZone })
          );

          await markSent(alert);
          logger.log(
            `📨 DEMO ${alert.event_type}: trade=${alert.trade_id} отправлено`
          );
        } catch (error) {
          await markFailed(alert, error).catch(() => {});
          logger.warn(
            `⚠️ DEMO ${alert.event_type}: trade=${alert.trade_id}: ${error.message}`
          );
        }
      }
    } finally {
      running = false;
    }
  }

  function start() {
    if (timer) {
      return;
    }

    firstTimer = setTimeout(() => {
      scan().catch((error) =>
        logger.warn(`⚠️ DEMO ALERT SCAN: ${error.message}`)
      );
    }, Math.min(15_000, Math.max(1_000, scanMs)));

    timer = setInterval(() => {
      scan().catch((error) =>
        logger.warn(`⚠️ DEMO ALERT SCAN: ${error.message}`)
      );
    }, Math.max(2_000, scanMs));

    firstTimer.unref?.();
    timer.unref?.();
    logger.log("✅ Telegram DEMO trade alerts: ON");
  }

  function stop() {
    if (firstTimer) {
      clearTimeout(firstTimer);
      firstTimer = null;
    }

    if (timer) {
      clearInterval(timer);
      timer = null;
    }
  }

  return { scan, start, stop };
}

module.exports = {
  calculateTradePoints,
  closeReasonText,
  createDemoTradeAlertService,
  ensureDemoTradeAlertSchema,
  formatDemoTradeAlert,
  riskModeText,
};
