# Graph V7 — concrete shadow specification — 2026-08-21

Status: SHADOW ONLY. Graph V6 remains production fallback until chronological OOS promotion gates pass.

## Problem being fixed
Graph V6 is visually almost a straight directional line because its path shape is hand-authored with fixed Gaussian pullback/continuation bumps. V7 must derive path shape from actual closed-candle behavior rather than decorative fixed geometry.

## Inputs already available to buildTradePlan
- selected timeframe
- current analysis price/direction/strength
- analysis momentum/trend/ATR
- closed candles for that timeframe
- fresh MT5 bid/ask when available
- existing MTF/news/model context may be added later only after measurable shadow benefit

V7 must never use an unclosed candle.

## V7 path algorithm v1 — deterministic historical analog envelope

1. Use only finite closed candles, ordered oldest -> newest.
2. Convert closes to one-step log returns.
3. Estimate robust realized volatility from the last min(40, available) returns using MAD first, RMS fallback.
4. Define the current state vector from the latest 3 normalized returns.
5. Search earlier history for analog windows with 3-return normalized vectors. Exclude any analog whose future window overlaps the current state.
6. Score analog distance with weighted squared error, newest state component highest weight: [0.2, 0.3, 0.5].
7. Keep up to 24 nearest analogs, but require at least 6 for analog mode.
8. For every retained analog, build its actual future cumulative close-return path for the requested forecast steps.
9. Convert each analog future path from return space to price space anchored at current analysis price.
10. At every future step compute empirical quantiles: p20, p50, p80. p50 is the PRIMARY median path. p20/p80 form the uncertainty envelope.
11. Determine ALTERNATIVE path from analogs whose terminal return sign differs from the primary median terminal sign. If at least 3 exist, use their median path. Otherwise use the wider adverse quantile edge as the alternative path, clearly labelled low-evidence.
12. WAIT/UNCERTAIN: if analysis action is WAIT, strength < 60, data are stale, or the p20/p80 interval contains both material up and down terminal outcomes with weak median displacement, do not draw a directional primary arrow. Show neutral median + widened band and label UNCERTAIN.
13. No random sampling and no Monte Carlo in v1. Same input must produce exactly the same output.

## Deterministic fallback when analog evidence is insufficient
- EWMA return drift over last 12 returns with lambda=0.78.
- Drift is capped to +/-0.45 ATR over the total horizon.
- Residual empirical volatility expands with sqrt(step).
- Median path is cumulative capped EWMA drift.
- p20/p80 use empirical residual quantiles scaled by sqrt(step).
- No fixed pullback locations, no sine waves, no Gaussian bumps.

## TF-aware visual horizons
For Telegram readability V7 v1 initially keeps a bounded point count while using TF-aware future bars:
- M1: 15 bars = 15 minutes
- M5: 12 bars = 60 minutes
- M15: 8 bars = 120 minutes
- M30: 8 bars = 240 minutes
- H1: 8 bars = 480 minutes

Longer research horizons may be evaluated offline, but production image density remains phone-first.

## Scenario output contract
- mode: ANALOG | EWMA_FALLBACK | UNCERTAIN
- primary: [{minute, median, low, high}]
- alternative: [{minute, center}] or []
- scenarioMarkers: CURRENT, PRIMARY_END, ALT_END, UNCERTAINTY_EXPANSION; later add model/news markers only if validated
- evidence: analogCount, volatility, terminalMedianMove, terminalBandWidth
- modelName: GRAPH_V7_ANALOG_ENVELOPE_V1

## Rendering rules
- Historical candles remain exactly real closed candles.
- Future boundary is explicit.
- PRIMARY path: solid median line inside translucent p20-p80 band.
- ALTERNATIVE path: dashed line, never presented as equal-confidence unless evidence count supports it.
- WAIT/UNCERTAIN: no green/red directional ghost arrow; use neutral band and label WAIT / UNCERTAIN.
- Direction strength is not labelled as win probability.
- Existing entry/confirmation/invalidation/SL/TP levels stay separate from statistical forecast envelope.

## Promotion metrics — chronological OOS only
Compare V7 with V6 on three chronological blocks, never shuffled.
Metrics:
1. median-path MAE
2. terminal direction accuracy
3. p20-p80 empirical coverage
4. interval width normalized by ATR
5. false reversal rate

Promotion requires ALL:
- V7 beats V6 on at least 3/5 metrics overall;
- at least 5% relative improvement on MAE or direction accuracy in at least 2 chronological test blocks;
- false reversal rate is not worse by more than 1 percentage point overall;
- interval coverage is between 50% and 85% and not worse than V6 by >3 pp;
- no test block has >10% MAE degradation;
- deterministic unit/render tests all pass;
- Telegram generation latency p95 is not >20% slower than V6;
- no trade execution code is changed.

If gates fail, Graph V6 remains active.

## Required tests
- BUY, SELL, WAIT inputs
- M1/M5/M15/M30/H1
- finite ordered p20 <= p50 <= p80 at every step
- no NaN/Infinity
- identical input => identical output
- analog mode on adequate history
- EWMA fallback on insufficient analog history
- WAIT does not masquerade as BUY/SELL
- alternative path exists only with evidence or explicit low-evidence fallback
- historical candles are not modified
- stale/missing data fail safely to UNCERTAIN/V6 fallback
