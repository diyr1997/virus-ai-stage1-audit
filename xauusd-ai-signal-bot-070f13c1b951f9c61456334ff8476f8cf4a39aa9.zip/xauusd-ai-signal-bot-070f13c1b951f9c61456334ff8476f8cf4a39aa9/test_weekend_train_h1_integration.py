from __future__ import annotations

import inspect
import unittest

import weekend_train_h1


class WeekendTrainerIntegrationTests(unittest.TestCase):
    def test_real_trainer_uses_purged_split(self):
        source = inspect.getsource(weekend_train_h1.train)
        self.assertIn("purged_chronological_split", source)
        self.assertIn("purge_rows=60", source)
        self.assertIn('Temporal leakage detected in integrated trainer', source)
        self.assertNotIn("train_df = data.iloc[:split]", source)
        self.assertNotIn("valid_df = data.iloc[split:]", source)

    def test_real_trainer_persists_and_reloads_actual_challenger(self):
        source = inspect.getsource(weekend_train_h1.train)
        self.assertIn("dump_reload_verify", source)
        self.assertIn("reloaded = joblib.load(output_path)", source)
        self.assertIn("_require_same_metrics", source)
        self.assertIn("_require_same_blocks", source)

    def test_dataset_retains_forward_timestamp_for_boundary_assertion(self):
        source = inspect.getsource(weekend_train_h1._build_dataset)
        self.assertIn('"future_ts_60"', source)
        self.assertIn('astype("int64")', source)


if __name__ == "__main__":
    unittest.main()
