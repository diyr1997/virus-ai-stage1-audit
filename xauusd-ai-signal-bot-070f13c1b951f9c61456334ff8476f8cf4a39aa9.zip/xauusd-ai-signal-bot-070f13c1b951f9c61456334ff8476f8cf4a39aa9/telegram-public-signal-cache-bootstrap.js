"use strict";

const { AsyncLocalStorage } = require("async_hooks");
const TelegramBot = require("node-telegram-bot-api");

const OWNER_CHAT_ID = Number(process.env.TELEGRAM_OWNER_CHAT_ID || 0);
const CACHE_SAFETY_MS = Math.max(
  2_000,
  Number(process.env.PUBLIC_SIGNAL_CACHE_SAFETY_MS || 5_000)
);

const TF_MS = {
  M1: 60_000,
  M5: 5 * 60_000,
  M15: 15 * 60_000,
  M30: 30 * 60_000,
  H1: 60 * 60_000,
};

const signalCache = new Map();
const inFlight = new Map();
const cacheContext = new AsyncLocalStorage();

function numericChatId(value) {
  const n = Number(value || 0);
  return Number.isFinite(n) ? n : 0;
}

function isPublic(chatId) {
  const id = numericChatId(chatId);
  if (!OWNER_CHAT_ID) return true;
  return id !== OWNER_CHAT_ID;
}

function bucketFor(timeframe, now = Date.now()) {
  const span = TF_MS[timeframe];
  if (!span) return null;
  return Math.floor((now - CACHE_SAFETY_MS) / span);
}

function cachedSignal(timeframe) {
  const entry = signalCache.get(timeframe);
  if (!entry) return null;
  const bucket = bucketFor(timeframe);
  if (bucket === null || entry.bucket !== bucket) return null;
  return entry;
}

function signalFromMessage(message) {
  const text = String(message?.text || "").trim();
  const match = /^\/signal(?:@\w+)?\s+(M1|M5|M15|M30|H1)$/i.exec(text);
  return match ? match[1].toUpperCase() : null;
}

function signalFromCallback(query) {
  const match = /^signal_(M1|M5|M15|M30|H1)$/.exec(
    String(query?.data || "")
  );
  return match ? match[1] : null;
}

function cloneOptions(options) {
  if (!options || typeof options !== "object") return options;
  return { ...options };
}

const previousSendMessage = TelegramBot.prototype.sendMessage;
const previousSendPhoto = TelegramBot.prototype.sendPhoto;

async function replayCached(bot, chatId, entry) {
  for (const item of entry.items) {
    if (item.type === "photo") {
      await previousSendPhoto.call(
        bot,
        chatId,
        item.photo,
        cloneOptions(item.options),
        cloneOptions(item.fileOptions)
      );
      continue;
    }

    if (item.type === "message") {
      await previousSendMessage.call(
        bot,
        chatId,
        item.text,
        cloneOptions(item.options)
      );
    }
  }
}

TelegramBot.prototype.sendPhoto = async function cachedSendPhoto(
  chatId,
  photo,
  options,
  fileOptions
) {
  const result = await previousSendPhoto.call(
    this,
    chatId,
    photo,
    options,
    fileOptions
  );

  const store = cacheContext.getStore();
  if (
    store?.capture &&
    store.public === true &&
    numericChatId(chatId) === store.chatId
  ) {
    store.capture.sawPhoto = true;
    store.capture.items.push({
      type: "photo",
      photo,
      options: cloneOptions(options),
      fileOptions: cloneOptions(fileOptions),
    });
  }

  return result;
};

TelegramBot.prototype.sendMessage = async function cachedSendMessage(
  chatId,
  text,
  options
) {
  const result = await previousSendMessage.call(
    this,
    chatId,
    text,
    options
  );

  const store = cacheContext.getStore();
  if (
    store?.capture &&
    store.public === true &&
    store.capture.sawPhoto &&
    numericChatId(chatId) === store.chatId
  ) {
    store.capture.items.push({
      type: "message",
      text,
      options: cloneOptions(options),
    });
  }

  return result;
};

async function serveOrBuild({
  bot,
  chatId,
  timeframe,
  run,
}) {
  const hit = cachedSignal(timeframe);
  if (hit) {
    await replayCached(bot, chatId, hit);
    return true;
  }

  const bucket = bucketFor(timeframe);
  const key = `${timeframe}:${bucket}`;

  if (inFlight.has(key)) {
    await inFlight.get(key).catch(() => {});
    const after = cachedSignal(timeframe);
    if (after) {
      await replayCached(bot, chatId, after);
      return true;
    }
    await previousSendMessage.call(
      bot,
      chatId,
      "⏳ Свежий общий сигнал ещё обновляется. Попробуй ещё раз через несколько секунд.",
      { reply_markup: { inline_keyboard: [] } }
    );
    return true;
  }

  let resolveJob;
  const job = new Promise((resolve) => {
    resolveJob = resolve;
  });
  inFlight.set(key, job);

  const capture = { sawPhoto: false, items: [] };

  try {
    await cacheContext.run(
      {
        public: true,
        chatId: numericChatId(chatId),
        timeframe,
        bucket,
        capture,
      },
      run
    );

    if (capture.sawPhoto && capture.items.length) {
      signalCache.set(timeframe, {
        timeframe,
        bucket,
        createdAt: Date.now(),
        items: capture.items,
      });
    }

    return false;
  } finally {
    resolveJob();
    inFlight.delete(key);
  }
}

const previousOnText = TelegramBot.prototype.onText;
TelegramBot.prototype.onText = function cachedOnText(regexp, callback) {
  return previousOnText.call(
    this,
    regexp,
    async (message, match) => {
      const chatId = numericChatId(message?.chat?.id);
      const timeframe = signalFromMessage(message);

      if (!timeframe || !isPublic(chatId)) {
        return callback.call(this, message, match);
      }

      return serveOrBuild({
        bot: this,
        chatId,
        timeframe,
        run: () => callback.call(this, message, match),
      });
    }
  );
};

const previousOn = TelegramBot.prototype.on;
TelegramBot.prototype.on = function cachedOn(event, callback) {
  if (event !== "callback_query") {
    return previousOn.call(this, event, callback);
  }

  return previousOn.call(this, event, async (query) => {
    const chatId = numericChatId(query?.message?.chat?.id);
    const timeframe = signalFromCallback(query);

    if (!timeframe || !isPublic(chatId)) {
      return callback.call(this, query);
    }

    const hit = cachedSignal(timeframe);
    if (hit) {
      await this
        .answerCallbackQuery(query.id, {
          text: `${timeframe}: свежий общий сигнал`,
        })
        .catch(() => {});
      await replayCached(this, chatId, hit);
      return;
    }

    return serveOrBuild({
      bot: this,
      chatId,
      timeframe,
      run: () => callback.call(this, query),
    });
  });
};

console.log(
  "✅ Public signal cache: shared per closed timeframe candle; repeated user clicks do not recalculate"
);
