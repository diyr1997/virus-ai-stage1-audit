"use strict";

const fs = require("fs");
const path = require("path");
const Module = require("module");

const target = path.resolve(__dirname, "index.js");
const originalLoader = Module._extensions[".js"];
const V7_ENABLED = /^(1|true|yes|on)$/i.test(String(process.env.GRAPH_V7_ENABLED || "0"));

function replaceRequired(source, oldText, newText, label) {
  if (!source.includes(oldText)) {
    throw new Error(`GRAPH ${V7_ENABLED ? "V7" : "V6"}: patch target missing: ${label}`);
  }
  return source.replace(oldText, newText);
}

function applyPatch(source) {
  const start = source.indexOf("function buildTradePlan(");
  const marker =
    "// ======================================================\n" +
    "// POSTGRES — SAVE ANALYSIS / CANDIDATE";
  const end = source.indexOf(marker, start);

  if (start < 0 || end < 0) {
    throw new Error("GRAPH: buildTradePlan block not found");
  }

  const engine = V7_ENABLED ? "buildTradePlanV7" : "buildTradePlanV6";
  const file = V7_ENABLED ? "./forecast-v7-engine" : "./forecast-v6-engine";
  const replacement = `function buildTradePlan(\n  analysis,\n  timeframe,\n  mt5Quote = null,\n  candles = []\n) {\n  const { ${engine} } = require(\"${file}\");\n  return ${engine}({\n    analysis,\n    timeframe,\n    mt5Quote,\n    candles,\n    lotCap: strengthLotCap(analysis.strength),\n  });\n}\n\n`;

  let patched = source.slice(0, start) + replacement + source.slice(end);
  patched = patched.replace(
    "GOLD • ${escapeSvg(timeframe)} • PRO CHART",
    V7_ENABLED
      ? "GOLD • ${escapeSvg(timeframe)} • GRAPH V7 SHADOW"
      : "GOLD • ${escapeSvg(timeframe)} • SCENARIO V6"
  );

  if (!V7_ENABLED) return patched;

  patched = replaceRequired(
    patched,
    [
      "  const forecast = Array.isArray(plan.forecast) ? plan.forecast : [];",
      "  const finite = (value) => Number.isFinite(Number(value));",
    ].join("\n"),
    [
      "  const forecast = Array.isArray(plan.forecast) ? plan.forecast : [];",
      "  const alternativeForecast = Array.isArray(plan.alternativeForecast) ? plan.alternativeForecast : [];",
      "  const finite = (value) => Number.isFinite(Number(value));",
    ].join("\n"),
    "alternative forecast declaration"
  );

  patched = replaceRequired(
    patched,
    [
      "  for (const p of forecast) {",
      "    if (finite(p.high) && finite(p.low)) prices.push(Number(p.high), Number(p.low));",
      "  }",
      "",
      "  for (const value of [",
    ].join("\n"),
    [
      "  for (const p of forecast) {",
      "    if (finite(p.high) && finite(p.low)) prices.push(Number(p.high), Number(p.low));",
      "  }",
      "  for (const p of alternativeForecast) {",
      "    if (finite(p.center)) prices.push(Number(p.center));",
      "  }",
      "",
      "  for (const value of [",
    ].join("\n"),
    "alternative forecast price range"
  );

  patched = replaceRequired(
    patched,
    [
      "  const signalColor =",
      "    analysis.action === \"BUY\"",
      "      ? \"#26a69a\"",
      "      : analysis.action === \"SELL\"",
      "      ? \"#ef5350\"",
      "      : \"#b2b5be\";",
      "  const signalFill =",
      "    analysis.action === \"BUY\"",
      "      ? \"#123f3c\"",
      "      : analysis.action === \"SELL\"",
      "      ? \"#4a2428\"",
      "      : \"#2a2e39\";",
    ].join("\n"),
    [
      "  const visualAction = plan.v7State === \"UNCERTAIN\" ? \"WAIT\" : (plan.v7PrimaryDirection || analysis.action);",
      "  const signalColor =",
      "    visualAction === \"BUY\"",
      "      ? \"#26a69a\"",
      "      : visualAction === \"SELL\"",
      "      ? \"#ef5350\"",
      "      : \"#b2b5be\";",
      "  const signalFill =",
      "    visualAction === \"BUY\"",
      "      ? \"#123f3c\"",
      "      : visualAction === \"SELL\"",
      "      ? \"#4a2428\"",
      "      : \"#2a2e39\";",
    ].join("\n"),
    "V7 visual action colors"
  );

  patched = replaceRequired(
    patched,
    [
      "  const directionText =",
      "    analysis.action === \"BUY\"",
      "      ? \"ПОКУПКА\"",
      "      : analysis.action === \"SELL\"",
      "      ? \"ПРОДАЖА\"",
      "      : \"ОЖИДАНИЕ\";",
    ].join("\n"),
    [
      "  const directionText =",
      "    visualAction === \"BUY\"",
      "      ? \"ОСНОВНОЙ: ВВЕРХ\"",
      "      : visualAction === \"SELL\"",
      "      ? \"ОСНОВНОЙ: ВНИЗ\"",
      "      : \"WAIT / UNCERTAIN\";",
    ].join("\n"),
    "V7 direction label"
  );

  patched = replaceRequired(
    patched,
    [
      "    svg += `",
      "<polygon points=\"${highPoints} ${lowPoints}\" fill=\"url(#forecastFade)\"/>",
      "<polyline points=\"${centerPoints}\" fill=\"none\" stroke=\"${signalColor}\" stroke-width=\"3.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" filter=\"url(#softGlow)\"/>`;",
      "",
      "    const milestones = [",
      "      { label: \"5м\", point: plan.p5 },",
      "      { label: \"10м\", point: plan.p10 },",
      "      { label: \"15м\", point: plan.p15 },",
      "    ];",
    ].join("\n"),
    [
      "    const alternativePoints = alternativeForecast",
      "      .map((p) => {",
      "        const horizon = Math.max(1, Number(plan.horizon || 15));",
      "        const progress = Math.max(0, Math.min(1, Number(p.minute || 0) / horizon));",
      "        const x = REAL_RIGHT + 14 + progress * (RIGHT - REAL_RIGHT - 30);",
      "        return `${x},${clampY(priceY(p.center))}`;",
      "      })",
      "      .join(\" \" );",
      "    svg += `",
      "<polygon points=\"${highPoints} ${lowPoints}\" fill=\"url(#forecastFade)\"/>",
      "<polyline points=\"${centerPoints}\" fill=\"none\" stroke=\"${signalColor}\" stroke-width=\"3.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" filter=\"url(#softGlow)\"/>`;",
      "    if (alternativePoints) {",
      "      svg += `<polyline points=\"${alternativePoints}\" fill=\"none\" stroke=\"#f2c94c\" stroke-width=\"2.2\" stroke-dasharray=\"7 6\" stroke-linecap=\"round\" opacity=\"0.86\"/>`;",
      "    }",
      "    svg += `<text x=\"${REAL_RIGHT + 18}\" y=\"${TOP + 58}\" fill=\"${signalColor}\" font-family=\"${FONT}\" font-size=\"12\" font-weight=\"700\">PRIMARY ${escapeSvg(plan.v7Mode || \"V7\")}</text>`;",
      "    svg += `<text x=\"${REAL_RIGHT + 18}\" y=\"${TOP + 77}\" fill=\"#f2c94c\" font-family=\"${FONT}\" font-size=\"11\">ALT ${escapeSvg(plan.v7AlternativeEvidence || \"—\")}</text>`;",
      "",
      "    const milestones = Array.isArray(plan.v7Milestones) && plan.v7Milestones.length",
      "      ? plan.v7Milestones",
      "      : [",
      "          { label: \"5м\", point: plan.p5 },",
      "          { label: \"10м\", point: plan.p10 },",
      "          { label: \"15м\", point: plan.p15 },",
      "        ];",
    ].join("\n"),
    "V7 primary/alternative rendering"
  );

  return patched;
}

module.exports = { applyPatch };

if (process.env.GRAPH_V6_VERIFY_ONLY !== "1") {
  Module._extensions[".js"] = function graphLoader(module, filename) {
    if (path.resolve(filename) !== target) {
      return originalLoader(module, filename);
    }

    const raw = fs.readFileSync(filename, "utf8");
    const patched = applyPatch(raw);
    Module._extensions[".js"] = originalLoader;
    console.log(
      V7_ENABLED
        ? "✅ GRAPH V7 SHADOW: ANALOG ENVELOPE + ALT PATH ACTIVE"
        : "✅ GRAPH SCENARIO V6: SAFE FORECAST ENGINE ACTIVE"
    );
    module._compile(patched, filename);
  };

  // Railway uses a custom start command that always preloads this graph bootstrap.
  // Chaining the compact UI here makes the UI patch active regardless of whether
  // Railway, package.json, or a local launcher owns the final start command.
  require("./signal-ui-compact-bootstrap");
}
