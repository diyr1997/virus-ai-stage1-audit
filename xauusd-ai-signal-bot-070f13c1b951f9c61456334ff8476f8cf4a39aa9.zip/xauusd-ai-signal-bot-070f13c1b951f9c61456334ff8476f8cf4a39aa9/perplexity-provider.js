"use strict";

/** Official Perplexity advisor. Advisory only; no trading/write authority. */
let PerplexityClass = null;

async function getClientClass() {
  if (PerplexityClass) return PerplexityClass;
  const mod = await import("@perplexity-ai/perplexity_ai");
  PerplexityClass = mod.default || mod.Perplexity || mod;
  return PerplexityClass;
}

function requireKey() {
  const key = String(process.env.PERPLEXITY_API_KEY || "").trim();
  if (!key) {
    const error = new Error("PERPLEXITY_API_KEY is not configured");
    error.code = "NOT_CONFIGURED";
    throw error;
  }
  return key;
}

function normalizeSources(response) {
  const sources = [];
  const seen = new Set();
  for (const value of Array.isArray(response?.citations) ? response.citations : []) {
    const url = String(value || "").trim();
    if (!url || seen.has(url)) continue;
    seen.add(url);
    sources.push({ title: "Perplexity citation", url });
  }
  for (const item of Array.isArray(response?.search_results) ? response.search_results : []) {
    const url = String(item?.url || "").trim();
    if (!url || seen.has(url)) continue;
    seen.add(url);
    sources.push({ title: String(item?.title || "Perplexity search result").trim(), url, date: item?.date || null });
  }
  return sources;
}

async function callPerplexityResearch(prompt) {
  const apiKey = requireKey();
  const Perplexity = await getClientClass();
  const timeout = Math.max(20_000, Number(process.env.PERPLEXITY_TIMEOUT_MS || 120_000));
  const model = String(process.env.PERPLEXITY_MODEL || "sonar").trim() || "sonar";
  const client = new Perplexity({ apiKey, timeout, maxRetries: 2 });
  const response = await client.chat.completions.create({ model, messages: [{ role: "user", content: String(prompt || "") }] });
  const text = String(response?.choices?.[0]?.message?.content || "").trim();
  if (!text) throw new Error("Perplexity returned empty research response");
  return { text, sources: normalizeSources(response), model };
}

function researchToText(result) {
  const text = String(result?.text || "").trim();
  if (!text) throw new Error("Perplexity returned empty research response");
  const sources = Array.isArray(result?.sources) ? result.sources : [];
  if (!sources.length) return text;
  return `${text}\n\nVERIFIABLE SOURCES:\n${sources.map((s, i) => `${i + 1}. ${s.title || "Source"} — ${s.url}`).join("\n")}`;
}

async function callPerplexity(prompt) {
  return researchToText(await callPerplexityResearch(prompt));
}

module.exports = { callPerplexity, callPerplexityResearch, normalizeSources, researchToText };
