"use strict";

// MANUAL SIGNAL CLOUD FALLBACK V1
// ------------------------------------------------------
// Purpose:
// - Keep AUTOPILOT / DEMO trading on strict MT5/PostgreSQL/Dukascopy data.
// - Allow only a user-triggered Telegram signal request to fall back to
//   Twelve Data XAU/USD 1-minute candles when strict sources are stale.
// - When cloud fallback is used, do NOT persist those candles into the live
//   candle table and do NOT create a DEMO trade candidate.

const { AsyncLocalStorage } = require("async_hooks");
const TelegramBot = require("node-telegram-bot-api");
const { Pool } = require("pg");

const context = new AsyncLocalStorage();
const API_KEY = String(process.env.TWELVE_DATA_API_KEY || "").trim();
const MAX_AGE_MS = Math.max(
  2 * 60_000,
  Number(process.env.MANUAL_CLOUD_M1_MAX_AGE_MS || 5 * 60_000)
);
const CACHE_MS = Math.max(
  10_000,
  Number(process.env.MANUAL_CLOUD_CACHE_MS || 30_000)
);
const OUTPUT_SIZE = Math.max(
  2400,
  Math.min(5000, Number(process.env.MANUAL_CLOUD_OUTPUT_SIZE || 5000))
);

let cloudCache = {
  candles: null,
  updatedAt: 0,
};

function isManualSignalUpdate(update) {
  const callbackData = String(update?.callback_query?.data || "");
  if (/^signal_(M1|M5|M15|M30|H1)$/.test(callbackData)) {
    return true;
  }

  const text = String(update?.message?.text || "").trim();
  return /^\/signal(?:@\w+)?(?:\s+(M1|M5|M15|M30|H1))?$/i.test(text);
}

function parseUtcDatetime(value) {
  const text = String(value || "").trim();
  if (!text) return NaN;

  // Twelve Data returns `YYYY-MM-DD HH:mm:ss` when timezone=UTC.
  const normalized = /Z$|[+-]\d\d:\d\d$/.test(text)
    ? text
    : `${text.replace(" ", "T")}Z`;

  return new Date(normalized).getTime();
}

function sanitizeTwelveValues(values) {
  const now = Date.now();
  const map = new Map();

  for (const row of Array.isArray(values) ? values : []) {
    const time = parseUtcDatetime(row?.datetime);
    const open = Number(row?.open);
    const high = Number(row?.high);
    const low = Number(row?.low);
    const close = Number(row?.close);
    const volume = Number(row?.volume || 0);

    if (
      Number.isFinite(time) &&
      Number.isFinite(open) &&
      Number.isFinite(high) &&
      Number.isFinite(low) &&
      Number.isFinite(close) &&
      open > 0 && high > 0 && low > 0 && close > 0 &&
      high >= low &&
      time + 60_000 <= now - 2_500
    ) {
      map.set(time, { time, open, high, low, close, volume });
    }
  }

  return [...map.values()].sort((a, b) => a.time - b.time);
}

function assertFresh(candles) {
  if (!Array.isArray(candles) || candles.length < 60) {
    throw new Error(
      `Twelve Data: недостаточно закрытых M1 (${candles?.length || 0})`
    );
  }

  const last = candles[candles.length - 1];
  const ageMs = Math.max(0, Date.now() - (last.time + 60_000));

  if (ageMs > MAX_AGE_MS) {
    throw new Error(
      `Twelve Data: M1 устарели на ${Math.round(ageMs / 60_000)} мин`
    );
  }

  return candles;
}

async function fetchTwelveM1({ outputsize = OUTPUT_SIZE } = {}) {
  if (!API_KEY) {
    throw new Error("TWELVE_DATA_API_KEY не настроен");
  }

  if (
    outputsize === OUTPUT_SIZE &&
    cloudCache.candles?.length &&
    Date.now() - cloudCache.updatedAt < CACHE_MS
  ) {
    return assertFresh(cloudCache.candles);
  }

  const url = new URL("https://api.twelvedata.com/time_series");
  url.searchParams.set("symbol", "XAU/USD");
  url.searchParams.set("interval", "1min");
  url.searchParams.set("outputsize", String(outputsize));
  url.searchParams.set("timezone", "UTC");
  url.searchParams.set("order", "asc");
  url.searchParams.set("format", "JSON");
  url.searchParams.set("apikey", API_KEY);

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12_000);

  let response;
  try {
    response = await fetch(url, {
      headers: { "User-Agent": "xauusd-ai-signal-bot/manual-cloud-v1" },
      signal: controller.signal,
    });
  } finally {
    clearTimeout(timeout);
  }

  const payload = await response.json().catch(() => ({}));

  if (!response.ok || payload?.status === "error") {
    throw new Error(
      `Twelve Data: ${payload?.message || `HTTP ${response.status}`}`
    );
  }

  const candles = sanitizeTwelveValues(payload?.values);
  assertFresh(candles);

  if (outputsize === OUTPUT_SIZE) {
    cloudCache = {
      candles,
      updatedAt: Date.now(),
    };
  }

  return candles;
}

// Mark the complete async chain of a Telegram manual signal request.
const originalProcessUpdate = TelegramBot.prototype.processUpdate;
TelegramBot.prototype.processUpdate = function patchedProcessUpdate(update) {
  if (!isManualSignalUpdate(update)) {
    return originalProcessUpdate.call(this, update);
  }

  const store = {
    manualSignal: true,
    cloudFallbackUsed: false,
    cloudSource: null,
  };

  return context.run(store, () => originalProcessUpdate.call(this, update));
};

// Patch strict market loader before index.js destructures it.
const autopilot = require("./autopilot");
const originalLoadLiveM1 = autopilot.loadLiveM1.bind(autopilot);

autopilot.loadLiveM1 = async function manualAwareLoadLiveM1(...args) {
  try {
    return await originalLoadLiveM1(...args);
  } catch (strictError) {
    const store = context.getStore();
    if (!store?.manualSignal) {
      throw strictError;
    }

    try {
      const candles = await fetchTwelveM1();
      store.cloudFallbackUsed = true;
      store.cloudSource = "TWELVE_DATA";

      const last = candles[candles.length - 1];
      const ageSec = Math.max(
        0,
        Math.round((Date.now() - (last.time + 60_000)) / 1000)
      );

      console.log(
        `☁️ MANUAL M1 fallback: Twelve Data | ${candles.length} candles | age ${ageSec}s`
      );

      return candles;
    } catch (cloudError) {
      throw new Error(
        `${strictError.message} Облачный резерв Twelve Data тоже недоступен: ${cloudError.message}`
      );
    }
  }
};

// Prevent cloud-fallback manual analysis from becoming trading input.
const originalPoolQuery = Pool.prototype.query;
Pool.prototype.query = function patchedPoolQuery(...args) {
  const store = context.getStore();
  const first = args[0];
  const sql =
    typeof first === "string"
      ? first
      : typeof first?.text === "string"
      ? first.text
      : "";

  const blockCloudTradingWrite =
    store?.manualSignal &&
    store?.cloudFallbackUsed &&
    (/INSERT\s+INTO\s+xauusd_candles/i.test(sql) ||
      /INSERT\s+INTO\s+trade_candidates/i.test(sql));

  if (!blockCloudTradingWrite) {
    return originalPoolQuery.apply(this, args);
  }

  const fakeResult = {
    command: "INSERT",
    rowCount: 0,
    oid: 0,
    rows: [],
    fields: [],
  };

  const callback = args.find((arg) => typeof arg === "function");
  if (callback) {
    queueMicrotask(() => callback(null, fakeResult));
    return;
  }

  console.log(
    /trade_candidates/i.test(sql)
      ? "🔒 CLOUD MANUAL: DEMO candidate blocked"
      : "🔒 CLOUD MANUAL: candle DB write blocked"
  );

  return Promise.resolve(fakeResult);
};

// Make the source visible to the user without changing index.js.
const originalSendPhoto = TelegramBot.prototype.sendPhoto;
TelegramBot.prototype.sendPhoto = function patchedSendPhoto(
  chatId,
  photo,
  options = {},
  fileOptions
) {
  const store = context.getStore();

  if (store?.manualSignal && store?.cloudFallbackUsed) {
    const note = "☁️ M1: Twelve Data • только ручной сигнал • DEMO-вход заблокирован\n\n";
    const nextOptions = {
      ...options,
      caption: `${note}${String(options?.caption || "")}`.slice(0, 1024),
    };
    return originalSendPhoto.call(this, chatId, photo, nextOptions, fileOptions);
  }

  return originalSendPhoto.call(this, chatId, photo, options, fileOptions);
};

async function probeTwelveData() {
  if (!API_KEY) {
    console.warn("⚠️ MANUAL CLOUD M1: TWELVE_DATA_API_KEY отсутствует");
    return;
  }

  try {
    const url = new URL("https://api.twelvedata.com/time_series");
    url.searchParams.set("symbol", "XAU/USD");
    url.searchParams.set("interval", "1min");
    url.searchParams.set("outputsize", "2");
    url.searchParams.set("timezone", "UTC");
    url.searchParams.set("apikey", API_KEY);

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8_000);
    let response;
    try {
      response = await fetch(url, { signal: controller.signal });
    } finally {
      clearTimeout(timeout);
    }

    const payload = await response.json().catch(() => ({}));
    if (!response.ok || payload?.status === "error") {
      throw new Error(payload?.message || `HTTP ${response.status}`);
    }

    console.log(
      `✅ MANUAL CLOUD M1: Twelve Data XAU/USD ready | latest ${payload?.values?.[0]?.datetime || "ok"}`
    );
  } catch (error) {
    console.warn(`⚠️ MANUAL CLOUD M1 probe: ${error.message}`);
  }
}

console.log("✅ MANUAL SIGNAL CLOUD FALLBACK V1: ON");
probeTwelveData().catch(() => {});
