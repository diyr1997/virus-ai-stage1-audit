from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd


@dataclass(frozen=True)
class PurgedSplit:
    train_df: pd.DataFrame
    valid_df: pd.DataFrame
    purge_rows: int
    train_end_future_ts: int
    valid_start_ts: int


def purged_chronological_split(
    data: pd.DataFrame,
    *,
    train_fraction: float = 0.70,
    min_train_rows: int = 5_000,
    min_valid_rows: int = 1_500,
    purge_rows: int = 60,
) -> PurgedSplit:
    """Chronological train/validation split with label-horizon purge.

    The source trainer builds a 60-minute forward target using future_ts_60.
    Rows immediately before validation must therefore be excluded from training
    so no training label can reference prices inside validation.
    """
    if len(data) < min_train_rows + min_valid_rows + purge_rows:
        raise RuntimeError(
            "Not enough usable rows for purged split: "
            f"need >= {min_train_rows + min_valid_rows + purge_rows}, got {len(data)}"
        )
    required = {"timestamp", "future_ts_60"}
    missing = required - set(data.columns)
    if missing:
        raise RuntimeError(f"Purged split missing columns: {sorted(missing)}")

    raw_split = int(len(data) * float(train_fraction))
    valid_start = max(min_train_rows + purge_rows, raw_split)
    valid_start = min(valid_start, len(data) - min_valid_rows)
    train_end = valid_start - purge_rows

    train_df = data.iloc[:train_end].copy()
    valid_df = data.iloc[valid_start:].copy()
    if len(train_df) < min_train_rows or len(valid_df) < min_valid_rows:
        raise RuntimeError(
            f"Purged split sizes invalid: train={len(train_df)} valid={len(valid_df)} purge={purge_rows}"
        )

    train_end_future_ts = int(pd.to_numeric(train_df["future_ts_60"], errors="raise").max())
    valid_start_ts = int(pd.to_numeric(valid_df["timestamp"], errors="raise").min())
    if train_end_future_ts >= valid_start_ts:
        raise RuntimeError(
            "Temporal leakage detected after purge: "
            f"max(train.future_ts_60)={train_end_future_ts} >= min(valid.timestamp)={valid_start_ts}"
        )

    return PurgedSplit(
        train_df=train_df,
        valid_df=valid_df,
        purge_rows=int(purge_rows),
        train_end_future_ts=train_end_future_ts,
        valid_start_ts=valid_start_ts,
    )


def bundle_predictions(bundle: dict[str, Any], frame: pd.DataFrame, features: list[str]) -> dict[str, np.ndarray]:
    X = frame[features].to_numpy(dtype=np.float32)
    dmodel = bundle["direction_models"][60]
    rmodel = bundle["return_models"][60]
    return {
        "direction": np.asarray(dmodel.predict(X)),
        "probability": np.asarray(dmodel.predict_proba(X)),
        "return": np.asarray(rmodel.predict(X), dtype=float),
    }


def assert_prediction_equivalence(before: dict[str, np.ndarray], after: dict[str, np.ndarray]) -> None:
    if not np.array_equal(before["direction"], after["direction"]):
        raise RuntimeError("Reloaded challenger direction predictions differ from in-memory model")
    if not np.allclose(before["probability"], after["probability"], rtol=1e-12, atol=1e-12, equal_nan=True):
        raise RuntimeError("Reloaded challenger direction probabilities differ from in-memory model")
    if not np.allclose(before["return"], after["return"], rtol=1e-12, atol=1e-12, equal_nan=True):
        raise RuntimeError("Reloaded challenger return predictions differ from in-memory model")


def dump_reload_verify(
    bundle: dict[str, Any],
    output_path: str | Path,
    valid_df: pd.DataFrame,
    features: list[str],
    *,
    compress: int = 3,
) -> dict[str, Any]:
    """Persist challenger, reload it, and require identical OOS predictions."""
    before = bundle_predictions(bundle, valid_df, features)
    joblib.dump(bundle, output_path, compress=compress)
    reloaded = joblib.load(output_path)
    after = bundle_predictions(reloaded, valid_df, features)
    assert_prediction_equivalence(before, after)
    return {
        "reload_verified": True,
        "reload_validation_rows": int(len(valid_df)),
        "output": str(output_path),
    }
