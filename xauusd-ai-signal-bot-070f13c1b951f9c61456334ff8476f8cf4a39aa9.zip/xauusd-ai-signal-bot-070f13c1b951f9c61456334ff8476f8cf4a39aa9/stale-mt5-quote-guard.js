"use strict";

const path = require("path");
const Module = require("module");

const target = path.resolve(__dirname, "index.js");
const previousLoader = Module._extensions[".js"];
const ENGINE_PATCHED = Symbol.for("xauusd.graph.v7.stale.mt5.guard.v2");

function installV7QuoteGuard() {
  const enginePath = require.resolve("./forecast-v7-engine");
  const engine = require(enginePath);

  if (!engine || typeof engine.buildTradePlanV7 !== "function" || engine[ENGINE_PATCHED]) {
    return;
  }

  const original = engine.buildTradePlanV7.bind(engine);
  const wrapped = {
    ...engine,
    buildTradePlanV7(args) {
      const quote = args?.mt5Quote;
      const safeQuote = quote?.fresh === true ? quote : undefined;
      return original({ ...args, mt5Quote: safeQuote });
    },
  };

  Object.defineProperty(wrapped, ENGINE_PATCHED, {
    value: true,
    enumerable: false,
  });
  require.cache[enginePath].exports = wrapped;
}

function replaceRequired(source, oldText, newText, label) {
  if (!source.includes(oldText)) {
    throw new Error(`STALE MT5 QUOTE GUARD: patch target missing: ${label}`);
  }
  return source.replace(oldText, newText);
}

function patchIndex(source) {
  let patched = source;

  patched = replaceRequired(
    patched,
    [
      "    analysis.price,",
      "    mt5Quote?.bid,",
      "    mt5Quote?.ask,",
      "    plan.confirmation,",
    ].join("\n"),
    [
      "    analysis.price,",
      "    mt5Quote?.fresh ? mt5Quote?.bid : undefined,",
      "    mt5Quote?.fresh ? mt5Quote?.ask : undefined,",
      "    plan.confirmation,",
    ].join("\n"),
    "chart price range"
  );

  patched = replaceRequired(
    patched,
    [
      "  const currentPrice = finite(mt5Quote?.bid)",
      "    ? Number(mt5Quote.bid)",
      "    : Number(analysis.price);",
    ].join("\n"),
    [
      "  const currentPrice =",
      "    mt5Quote?.fresh && finite(mt5Quote?.bid)",
      "      ? Number(mt5Quote.bid)",
      "      : Number(analysis.price);",
    ].join("\n"),
    "current chart price"
  );

  patched = replaceRequired(
    patched,
    [
      "  const askText = finite(mt5Quote?.ask) ? Number(mt5Quote.ask).toFixed(quoteDigits) : \"—\";",
      "  const spreadText = finite(mt5Quote?.spread) ? Number(mt5Quote.spread).toFixed(quoteDigits) : \"—\";",
    ].join("\n"),
    [
      "  const askText =",
      "    mt5Quote?.fresh && finite(mt5Quote?.ask)",
      "      ? Number(mt5Quote.ask).toFixed(quoteDigits)",
      "      : \"—\";",
      "  const spreadText =",
      "    mt5Quote?.fresh && finite(mt5Quote?.spread)",
      "      ? Number(mt5Quote.spread).toFixed(quoteDigits)",
      "      : \"—\";",
    ].join("\n"),
    "footer ask/spread"
  );

  patched = patched.replace(
    'MT5 ${escapeSvg(mt5Quote?.symbol || "GOLD#")} • BID',
    '${mt5Quote?.fresh ? " • MT5 " + escapeSvg(mt5Quote?.symbol || "GOLD#") + " • BID" : " • CLOUD • ANALYSIS PRICE"}'
  );

  patched = patched.replace(
    'MT5 LIVE • ${escapeSvg(mt5Quote?.symbol || "GOLD#")}',
    '${mt5Quote?.fresh ? "MT5 LIVE • " + escapeSvg(mt5Quote?.symbol || "GOLD#") : "CLOUD • ANALYSIS PRICE"}'
  );

  return patched;
}

installV7QuoteGuard();

Module._extensions[".js"] = function staleMt5QuoteLoader(module, filename) {
  if (path.resolve(filename) !== target) {
    return previousLoader(module, filename);
  }

  const originalCompile = module._compile.bind(module);
  module._compile = function staleMt5QuoteCompile(code, compileFilename) {
    module._compile = originalCompile;
    const patched = patchIndex(code);
    console.log("✅ STALE MT5 QUOTE GUARD V2: stale quote excluded without zero-scale distortion");
    return originalCompile(patched, compileFilename);
  };

  return previousLoader(module, filename);
};

module.exports = { patchIndex, installV7QuoteGuard };
