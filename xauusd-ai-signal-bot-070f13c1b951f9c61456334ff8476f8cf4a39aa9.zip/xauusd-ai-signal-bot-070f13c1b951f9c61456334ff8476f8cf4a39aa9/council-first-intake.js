"use strict";

const crypto = require("crypto");
const { Pool } = require("pg");
const {
  buildMasterContextSnapshot,
  ensureCouncilSchema,
  enqueueCouncilTask,
} = require("./ai-council-persistent");
const { processCouncilTask, getCouncilSnapshot } = require("./ai-council-dynamic");

const DATABASE_URL = String(process.env.DATABASE_URL || "").trim();
const AUTH_SECRET = String(process.env.COUNCIL_FIRST_AUTH_SECRET || "").trim();
const pool = DATABASE_URL ? new Pool({ connectionString: DATABASE_URL }) : null;

const STATES = Object.freeze({
  RECEIVED: "RECEIVED",
  COUNCIL_PENDING: "COUNCIL_PENDING",
  PROVISIONAL_REVIEW: "PROVISIONAL_REVIEW",
  REVIEWED: "REVIEWED",
  AUTHORIZED_FOR_DRAFT: "AUTHORIZED_FOR_DRAFT",
  DRAFT_REVIEW_PENDING: "DRAFT_REVIEW_PENDING",
  AUTHORIZED_FOR_MERGE: "AUTHORIZED_FOR_MERGE",
  BLOCKED: "BLOCKED",
  FAILED: "FAILED",
});

const READ_ONLY_KINDS = new Set([
  "status", "read_only", "diagnostic_read", "health_check",
  "metrics_read", "logs_read", "explain",
]);
const COUNCIL_INTERNAL_KINDS = new Set([
  "council_task_persist", "council_run_persist", "council_audit_persist",
]);

const ALLOWED_TRANSITIONS = Object.freeze({
  [STATES.RECEIVED]: new Set([STATES.COUNCIL_PENDING, STATES.BLOCKED, STATES.FAILED]),
  [STATES.COUNCIL_PENDING]: new Set([
    STATES.COUNCIL_PENDING, STATES.PROVISIONAL_REVIEW, STATES.REVIEWED,
    STATES.BLOCKED, STATES.FAILED,
  ]),
  [STATES.PROVISIONAL_REVIEW]: new Set([
    STATES.PROVISIONAL_REVIEW, STATES.REVIEWED, STATES.AUTHORIZED_FOR_DRAFT,
    STATES.BLOCKED, STATES.FAILED,
  ]),
  [STATES.REVIEWED]: new Set([
    STATES.REVIEWED, STATES.AUTHORIZED_FOR_DRAFT, STATES.BLOCKED, STATES.FAILED,
  ]),
  [STATES.AUTHORIZED_FOR_DRAFT]: new Set([
    STATES.AUTHORIZED_FOR_DRAFT, STATES.COUNCIL_PENDING, STATES.PROVISIONAL_REVIEW,
    STATES.REVIEWED, STATES.DRAFT_REVIEW_PENDING, STATES.BLOCKED, STATES.FAILED,
  ]),
  [STATES.DRAFT_REVIEW_PENDING]: new Set([
    STATES.DRAFT_REVIEW_PENDING, STATES.AUTHORIZED_FOR_MERGE, STATES.BLOCKED, STATES.FAILED,
  ]),
  [STATES.AUTHORIZED_FOR_MERGE]: new Set([
    STATES.AUTHORIZED_FOR_MERGE, STATES.DRAFT_REVIEW_PENDING, STATES.BLOCKED, STATES.FAILED,
  ]),
  [STATES.BLOCKED]: new Set([STATES.COUNCIL_PENDING, STATES.FAILED]),
  [STATES.FAILED]: new Set([STATES.COUNCIL_PENDING]),
});

function requirePool() {
  if (!pool) throw new Error("DATABASE_URL is not configured");
  return pool;
}

function normalizeKind(value) {
  return String(value || "material_change")
    .trim().toLowerCase().replace(/[^a-z0-9_:-]+/g, "_");
}

function actionNeedsCouncil(kind) {
  const value = normalizeKind(kind);
  return !READ_ONLY_KINDS.has(value) && !COUNCIL_INTERNAL_KINDS.has(value);
}

function sha256(value) {
  return crypto.createHash("sha256").update(String(value ?? ""), "utf8").digest("hex");
}

function canonicalJson(value, seen = new WeakSet()) {
  if (value === null) return "null";
  if (typeof value === "string") return JSON.stringify(value);
  if (typeof value === "boolean") return value ? "true" : "false";
  if (typeof value === "number") {
    if (!Number.isFinite(value)) throw new Error("Frozen context contains non-finite number");
    return JSON.stringify(value);
  }
  if (typeof value !== "object") throw new Error("Frozen context contains unsupported value");
  if (seen.has(value)) throw new Error("Frozen context contains a cycle");
  seen.add(value);
  let out;
  if (Array.isArray(value)) {
    out = `[${value.map((item) => canonicalJson(item, seen)).join(",")}]`;
  } else {
    out = `{${Object.keys(value).sort()
      .filter((key) => value[key] !== undefined)
      .map((key) => `${JSON.stringify(key)}:${canonicalJson(value[key], seen)}`)
      .join(",")}}`;
  }
  seen.delete(value);
  return out;
}

function hashFrozenContext(context) {
  if (typeof context === "string") return sha256(context);
  if (!context || typeof context !== "object") {
    throw new Error("Frozen context must be a non-empty string or object");
  }
  return sha256(canonicalJson(context));
}

function timingSafeHashEqual(left, right) {
  const a = Buffer.from(String(left || ""), "hex");
  const b = Buffer.from(String(right || ""), "hex");
  return Boolean(a.length && a.length === b.length && crypto.timingSafeEqual(a, b));
}

function verifyFrozenContext(context, expectedHash) {
  return timingSafeHashEqual(hashFrozenContext(context), expectedHash);
}

function requireAuthSecret(secret = AUTH_SECRET) {
  const value = String(secret || "");
  if (value.length < 32) {
    const error = new Error("COUNCIL_FIRST_AUTH_SECRET is missing or too short");
    error.code = "AUTH_SECRET_NOT_CONFIGURED";
    throw error;
  }
  return value;
}

function makeAuthorizationHash(intakeId, stage, token, secret = AUTH_SECRET) {
  return crypto.createHmac("sha256", requireAuthSecret(secret))
    .update(`${intakeId}\0${stage}\0${token}`, "utf8")
    .digest("hex");
}

function safeToken(value, max = 72) {
  return String(value || "").trim().toUpperCase()
    .replace(/[^A-Z0-9_.:-]+/g, "_").replace(/^_+|_+$/g, "")
    .slice(0, max) || "UNKNOWN";
}

function makeIds({ source, rawRequest, now = Date.now(), intakeId, taskId }) {
  const requestHash = sha256(rawRequest);
  const stamp = new Date(now).toISOString().replace(/[-:.TZ]/g, "").slice(0, 17);
  const suffix = requestHash.slice(0, 12).toUpperCase();
  const src = safeToken(source || "unknown", 24);
  return {
    intakeId: intakeId || `CFI_${stamp}_${src}_${suffix}`,
    taskId: taskId || `COUNCIL_INTAKE_${stamp}_${src}_${suffix}`,
    requestHash,
  };
}

function canTransition(from, to) {
  return Boolean(ALLOWED_TRANSITIONS[from]?.has(to));
}

function assertTransition(from, to) {
  if (!canTransition(from, to)) {
    const error = new Error(`INVALID_COUNCIL_FIRST_TRANSITION: ${from} -> ${to}`);
    error.code = "INVALID_COUNCIL_FIRST_TRANSITION";
    throw error;
  }
}

function deriveReviewState(snapshot) {
  const finalPlan = String(snapshot?.task?.final_plan || "").trim();
  const ready = Array.isArray(snapshot?.readyAdvisors) ? snapshot.readyAdvisors.length : 0;
  const configured = Array.isArray(snapshot?.configuredAdvisors)
    ? snapshot.configuredAdvisors.length : 0;
  const quorum = Math.max(1, Number(snapshot?.quorum || 1));
  if (!finalPlan || ready < quorum) return STATES.COUNCIL_PENDING;
  return configured > 0 && ready >= configured ? STATES.REVIEWED : STATES.PROVISIONAL_REVIEW;
}

function parseMergeDecision(finalPlan) {
  const lines = String(finalPlan || "").split(/\r?\n/).map((line) => line.trim());
  const decisions = lines.filter((line) => line.startsWith("MERGE_DECISION:"));
  if (decisions.length !== 1) {
    const error = new Error(`INVALID_MERGE_DECISION_COUNT: ${decisions.length}`);
    error.code = "INVALID_MERGE_DECISION";
    throw error;
  }
  const match = /^MERGE_DECISION: (APPROVE|BLOCK)$/.exec(decisions[0]);
  if (!match) {
    const error = new Error(`INVALID_MERGE_DECISION_FORMAT: ${decisions[0]}`);
    error.code = "INVALID_MERGE_DECISION";
    throw error;
  }
  return match[1];
}

function assertMutationPayloadSafety(mutation = {}) {
  const type = String(mutation.type || mutation.action || "").toUpperCase();
  const mode = String(mutation.accountMode || mutation.account_mode || "").toUpperCase();
  if (mode === "REAL" || /ENABLE_REAL|REAL_TRADING|LIVE_ACCOUNT/.test(type)) {
    const error = new Error("DEMO_ONLY");
    error.code = "DEMO_ONLY";
    throw error;
  }
  const sourceBot = String(mutation.sourceBot || mutation.source_bot || "").toLowerCase();
  const targetBot = String(mutation.targetBot || mutation.target_bot || "").toLowerCase();
  if (sourceBot && targetBot && sourceBot !== targetBot && mutation.allowCrossBot !== true) {
    const error = new Error("BOT_SCOPE_ISOLATION");
    error.code = "BOT_SCOPE_ISOLATION";
    throw error;
  }
  return true;
}

function checkMutationPolicy({ mutationKind = "material_change", mutation = {} } = {}) {
  const kind = normalizeKind(mutationKind);
  if (!actionNeedsCouncil(kind)) {
    return {
      mutationKind: kind,
      requiresCouncil: false,
      allowed: true,
      bypassReason: COUNCIL_INTERNAL_KINDS.has(kind) ? "COUNCIL_INTERNAL" : "READ_ONLY",
    };
  }
  assertMutationPayloadSafety(mutation);
  return { mutationKind: kind, requiresCouncil: true, allowed: false, bypassReason: null };
}

function buildCouncilTaskText({ intakeId, source, mutationKind, rawRequest }) {
  return [
    "COUNCIL_FIRST OWNER REQUEST",
    `INTAKE_ID: ${intakeId}`,
    `SOURCE: ${source}`,
    `MUTATION_KIND: ${mutationKind}`,
    "",
    "Review before any material implementation begins.",
    "Use the same frozen project context for every advisor.",
    "Unavailable configured advisors remain pending/retry; never claim they participated.",
    "Preserve DEMO-only execution and Bot #1/Bot #2 state isolation.",
    "Identify owner-intent mismatches, bypass paths, tests and rollback.",
    "",
    "RAW OWNER REQUEST:",
    rawRequest,
  ].join("\n");
}

function buildDraftReviewTaskText({ intake, draftRef, draftHash, draftSummary }) {
  return [
    "COUNCIL_FIRST POST-DRAFT IMPLEMENTATION REVIEW",
    `PARENT_INTAKE_ID: ${intake.id}`,
    `ORIGINAL_TASK_ID: ${intake.task_id}`,
    `DRAFT_REF: ${draftRef || "UNSPECIFIED"}`,
    `DRAFT_HASH: ${draftHash || "UNSPECIFIED"}`,
    "",
    "Review the concrete draft/diff against the original owner request and prior Council plan.",
    "Block on safety regressions, bypasses, owner-intent mismatches, missing tests or scope expansion.",
    "At the very end output exactly one plain-text line, with no Markdown decoration:",
    "MERGE_DECISION: APPROVE",
    "or",
    "MERGE_DECISION: BLOCK",
    "Do not output another MERGE_DECISION line. If evidence is insufficient, choose BLOCK.",
    "",
    "DRAFT SUMMARY / DIFF CONTEXT:",
    String(draftSummary || "No draft summary supplied."),
  ].join("\n");
}

async function ensureIntakeSchema(db = requirePool()) {
  await ensureCouncilSchema();
  await db.query(`
    CREATE TABLE IF NOT EXISTS council_intake_requests (
      id TEXT PRIMARY KEY,
      task_id TEXT NOT NULL UNIQUE,
      draft_task_id TEXT UNIQUE,
      source TEXT NOT NULL,
      mutation_kind TEXT NOT NULL,
      raw_request TEXT NOT NULL,
      request_hash TEXT NOT NULL,
      context_hash TEXT NOT NULL,
      status TEXT NOT NULL CHECK (status IN (
        'RECEIVED','COUNCIL_PENDING','PROVISIONAL_REVIEW','REVIEWED',
        'AUTHORIZED_FOR_DRAFT','DRAFT_REVIEW_PENDING','AUTHORIZED_FOR_MERGE',
        'BLOCKED','FAILED'
      )),
      provisional BOOLEAN NOT NULL DEFAULT FALSE,
      council_revision INTEGER,
      draft_ref TEXT,
      draft_hash TEXT,
      draft_authorization_hash TEXT,
      merge_authorization_hash TEXT,
      merge_council_revision INTEGER,
      last_error TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await db.query(`
    CREATE TABLE IF NOT EXISTS council_intake_audit (
      id BIGSERIAL PRIMARY KEY,
      intake_id TEXT NOT NULL,
      event_type TEXT NOT NULL,
      from_state TEXT,
      to_state TEXT,
      metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await db.query("CREATE INDEX IF NOT EXISTS council_intake_status_idx ON council_intake_requests(status, updated_at)");
  await db.query("CREATE INDEX IF NOT EXISTS council_intake_audit_intake_idx ON council_intake_audit(intake_id, created_at)");
}

async function getIntake(intakeId, db = requirePool()) {
  const { rows } = await db.query("SELECT * FROM council_intake_requests WHERE id=$1", [intakeId]);
  return rows[0] || null;
}

async function appendAudit(db, intakeId, eventType, fromState, toState, metadata = {}) {
  await db.query(
    `INSERT INTO council_intake_audit(intake_id,event_type,from_state,to_state,metadata)
     VALUES($1,$2,$3,$4,$5::jsonb)`,
    [intakeId, eventType, fromState || null, toState || null, JSON.stringify(metadata)]
  );
}

async function transitionIntake(db, intakeId, toState, patch = {}, eventType = "STATE_CHANGE") {
  const current = await getIntake(intakeId, db);
  if (!current) throw new Error(`UNKNOWN_COUNCIL_INTAKE: ${intakeId}`);
  assertTransition(current.status, toState);
  const fields = {
    provisional: patch.provisional,
    council_revision: patch.councilRevision,
    draft_task_id: patch.draftTaskId,
    draft_ref: patch.draftRef,
    draft_hash: patch.draftHash,
    draft_authorization_hash: patch.draftAuthorizationHash,
    merge_authorization_hash: patch.mergeAuthorizationHash,
    merge_council_revision: patch.mergeCouncilRevision,
    last_error: patch.lastError,
  };
  const values = [intakeId, toState];
  const sets = ["status=$2", "updated_at=NOW()"];
  for (const [field, value] of Object.entries(fields)) {
    if (value === undefined) continue;
    values.push(value);
    sets.push(`${field}=$${values.length}`);
  }
  await db.query(`UPDATE council_intake_requests SET ${sets.join(",")} WHERE id=$1`, values);
  await appendAudit(db, intakeId, eventType, current.status, toState, patch.audit || {});
  return getIntake(intakeId, db);
}

async function verifyCouncilTaskRecord(db, taskId, expectedTask, expectedContextHash) {
  const { rows } = await db.query(
    "SELECT task, context_snapshot FROM ai_council_tasks WHERE id=$1",
    [taskId]
  );
  if (rows.length !== 1) throw new Error("COUNCIL_TASK_PERSIST_FAILED");
  const row = rows[0];
  if (String(row.task || "") !== expectedTask || hashFrozenContext(String(row.context_snapshot || "")) !== expectedContextHash) {
    const error = new Error("COUNCIL_TASK_ID_CONFLICT_CONTEXT_MISMATCH");
    error.code = "COUNCIL_TASK_ID_CONFLICT_CONTEXT_MISMATCH";
    throw error;
  }
}

async function createIntake({
  source = "unknown",
  mutationKind = "material_change",
  rawRequest,
  contextSnapshot,
  intakeId,
  taskId,
} = {}) {
  const kind = normalizeKind(mutationKind);
  if (!actionNeedsCouncil(kind)) {
    return {
      bypass: true,
      reason: COUNCIL_INTERNAL_KINDS.has(kind) ? "COUNCIL_INTERNAL" : "READ_ONLY",
      mutationKind: kind,
    };
  }
  const request = String(rawRequest || "").trim();
  if (!request) throw new Error("rawRequest is required for material changes");
  const db = requirePool();
  await ensureIntakeSchema(db);

  const ids = makeIds({ source, rawRequest: request, intakeId, taskId });
  const frozenContext = String(contextSnapshot || buildMasterContextSnapshot()).trim();
  const contextHash = hashFrozenContext(frozenContext);
  const councilTask = buildCouncilTaskText({
    intakeId: ids.intakeId,
    source: String(source || "unknown"),
    mutationKind: kind,
    rawRequest: request,
  });

  await enqueueCouncilTask({
    taskId: ids.taskId,
    taskType: "council_first_intake",
    task: councilTask,
    contextSnapshot: frozenContext,
  });
  await verifyCouncilTaskRecord(db, ids.taskId, councilTask, contextHash);

  const persisted = await db.query(
    `INSERT INTO council_intake_requests(
       id,task_id,source,mutation_kind,raw_request,request_hash,context_hash,status
     ) VALUES($1,$2,$3,$4,$5,$6,$7,$8)
     ON CONFLICT(id) DO UPDATE SET updated_at=NOW()
     WHERE council_intake_requests.task_id=EXCLUDED.task_id
       AND council_intake_requests.request_hash=EXCLUDED.request_hash
       AND council_intake_requests.context_hash=EXCLUDED.context_hash
     RETURNING id`,
    [ids.intakeId, ids.taskId, String(source || "unknown"), kind, request,
      ids.requestHash, contextHash, STATES.RECEIVED]
  );
  if (!persisted.rows.length) {
    const error = new Error("INTAKE_ID_CONFLICT_CONTEXT_MISMATCH");
    error.code = "INTAKE_ID_CONFLICT_CONTEXT_MISMATCH";
    throw error;
  }

  const current = await getIntake(ids.intakeId, db);
  if (current.status === STATES.RECEIVED) {
    return transitionIntake(db, ids.intakeId, STATES.COUNCIL_PENDING,
      { audit: { taskId: ids.taskId, contextHash } }, "COUNCIL_DISPATCHED");
  }
  return current;
}

async function reviewIntake(intakeId) {
  const db = requirePool();
  await ensureIntakeSchema(db);
  const intake = await getIntake(intakeId, db);
  if (!intake) throw new Error(`UNKNOWN_COUNCIL_INTAKE: ${intakeId}`);
  await processCouncilTask(intake.task_id);
  const snapshot = await getCouncilSnapshot(intake.task_id);
  const state = deriveReviewState(snapshot);
  if (state === STATES.COUNCIL_PENDING) return { intake, snapshot };
  const next = await transitionIntake(db, intakeId, state, {
    provisional: state === STATES.PROVISIONAL_REVIEW,
    councilRevision: Number(snapshot?.task?.revision || 0),
    draftAuthorizationHash: null,
    mergeAuthorizationHash: null,
    audit: {
      readyAdvisors: snapshot?.readyAdvisors || [],
      configuredAdvisors: snapshot?.configuredAdvisors || [],
    },
  }, "COUNCIL_REVIEW_PERSISTED");
  return { intake: next, snapshot };
}

async function authorizeDraft(intakeId, { allowProvisional = true } = {}) {
  const db = requirePool();
  const intake = await getIntake(intakeId, db);
  if (!intake) throw new Error(`UNKNOWN_COUNCIL_INTAKE: ${intakeId}`);
  if (intake.status === STATES.PROVISIONAL_REVIEW && !allowProvisional) {
    throw new Error("PROVISIONAL_REVIEW_NOT_AUTHORIZED");
  }
  if (![STATES.PROVISIONAL_REVIEW, STATES.REVIEWED].includes(intake.status)) {
    throw new Error(`DRAFT_AUTHORIZATION_BLOCKED: ${intake.status}`);
  }
  const snapshot = await getCouncilSnapshot(intake.task_id);
  const state = deriveReviewState(snapshot);
  if (![STATES.PROVISIONAL_REVIEW, STATES.REVIEWED].includes(state)) {
    throw new Error("COUNCIL_REVIEW_NOT_READY");
  }
  const token = crypto.randomBytes(32).toString("hex");
  const hash = makeAuthorizationHash(intakeId, "draft", token);
  const next = await transitionIntake(db, intakeId, STATES.AUTHORIZED_FOR_DRAFT, {
    provisional: state === STATES.PROVISIONAL_REVIEW,
    councilRevision: Number(snapshot?.task?.revision || 0),
    draftAuthorizationHash: hash,
    audit: { provisional: state === STATES.PROVISIONAL_REVIEW },
  }, "DRAFT_AUTHORIZED");
  return { intake: next, token };
}

async function assertAuthorization(intakeId, token, stage = "draft") {
  const db = requirePool();
  const intake = await getIntake(intakeId, db);
  if (!intake) throw new Error(`UNKNOWN_COUNCIL_INTAKE: ${intakeId}`);
  const merge = stage === "merge";
  const required = merge ? STATES.AUTHORIZED_FOR_MERGE : STATES.AUTHORIZED_FOR_DRAFT;
  if (intake.status !== required) {
    const error = new Error(`MUTATION_BLOCKED: ${intake.status}`);
    error.code = "MUTATION_BLOCKED";
    throw error;
  }
  const stored = merge ? intake.merge_authorization_hash : intake.draft_authorization_hash;
  const expected = makeAuthorizationHash(intakeId, merge ? "merge" : "draft", token);
  if (!timingSafeHashEqual(stored, expected)) {
    const error = new Error("UNAUTHORIZED_WRITE");
    error.code = "UNAUTHORIZED_WRITE";
    throw error;
  }

  const taskId = merge ? intake.draft_task_id : intake.task_id;
  if (!taskId) throw new Error("STALE_COUNCIL_AUTHORIZATION");
  const authorizedRevision = Number(merge ? intake.merge_council_revision : intake.council_revision);
  const snapshot = await getCouncilSnapshot(taskId);
  const currentRevision = Number(snapshot?.task?.revision || 0);
  if (authorizedRevision !== currentRevision) {
    if (merge) {
      await transitionIntake(db, intakeId, STATES.DRAFT_REVIEW_PENDING, {
        mergeAuthorizationHash: null,
        audit: { authorizedRevision, currentRevision },
      }, "STALE_MERGE_AUTHORIZATION_REVOKED");
    } else {
      const refreshed = deriveReviewState(snapshot);
      const target = [STATES.PROVISIONAL_REVIEW, STATES.REVIEWED].includes(refreshed)
        ? refreshed : STATES.COUNCIL_PENDING;
      await transitionIntake(db, intakeId, target, {
        draftAuthorizationHash: null,
        audit: { authorizedRevision, currentRevision },
      }, "STALE_DRAFT_AUTHORIZATION_REVOKED");
    }
    const error = new Error("STALE_COUNCIL_AUTHORIZATION");
    error.code = "STALE_COUNCIL_AUTHORIZATION";
    throw error;
  }
  return intake;
}

async function withAuthorizedMutation({ intakeId, token, stage = "draft", mutation = {} }, fn) {
  if (typeof fn !== "function") throw new Error("mutation callback is required");
  assertMutationPayloadSafety(mutation);
  await assertAuthorization(intakeId, token, stage);
  return fn();
}

async function submitDraft(intakeId, token, { draftRef, draftSummary, draftHash } = {}) {
  const db = requirePool();
  const intake = await assertAuthorization(intakeId, token, "draft");
  const hash = draftHash || sha256(String(draftSummary || draftRef || ""));
  const draftTaskId = `${safeToken(intake.task_id, 150)}_DRAFT_${hash.slice(0, 12).toUpperCase()}`;
  const frozenContext = buildMasterContextSnapshot();
  const task = buildDraftReviewTaskText({ intake, draftRef: String(draftRef || ""), draftHash: hash,
    draftSummary: String(draftSummary || "") });
  await enqueueCouncilTask({ taskId: draftTaskId, taskType: "implementation_diff_review",
    task, contextSnapshot: frozenContext });
  await verifyCouncilTaskRecord(db, draftTaskId, task, hashFrozenContext(frozenContext));
  return transitionIntake(db, intakeId, STATES.DRAFT_REVIEW_PENDING, {
    draftTaskId,
    draftRef: String(draftRef || ""),
    draftHash: hash,
    draftAuthorizationHash: null,
    mergeAuthorizationHash: null,
    mergeCouncilRevision: null,
    audit: { draftTaskId, draftRef: String(draftRef || ""), draftHash: hash },
  }, "DRAFT_SUBMITTED_FOR_COUNCIL_REVIEW");
}

async function reviewDraft(intakeId) {
  const db = requirePool();
  const intake = await getIntake(intakeId, db);
  if (!intake || intake.status !== STATES.DRAFT_REVIEW_PENDING || !intake.draft_task_id) {
    throw new Error(`DRAFT_REVIEW_BLOCKED: ${intake?.status || "UNKNOWN"}`);
  }
  await processCouncilTask(intake.draft_task_id);
  const snapshot = await getCouncilSnapshot(intake.draft_task_id);
  if (deriveReviewState(snapshot) === STATES.COUNCIL_PENDING) {
    return { intake, snapshot, decision: "PENDING" };
  }
  const decision = parseMergeDecision(snapshot?.task?.final_plan);
  if (decision === "BLOCK") {
    const blocked = await transitionIntake(db, intakeId, STATES.BLOCKED, {
      lastError: "DRAFT_COUNCIL_BLOCKED",
      audit: { draftTaskId: intake.draft_task_id },
    }, "DRAFT_BLOCKED_BY_COUNCIL");
    return { intake: blocked, snapshot, decision };
  }
  const token = crypto.randomBytes(32).toString("hex");
  const hash = makeAuthorizationHash(intakeId, "merge", token);
  const state = deriveReviewState(snapshot);
  const next = await transitionIntake(db, intakeId, STATES.AUTHORIZED_FOR_MERGE, {
    mergeAuthorizationHash: hash,
    mergeCouncilRevision: Number(snapshot?.task?.revision || 0),
    provisional: state === STATES.PROVISIONAL_REVIEW,
    audit: { draftTaskId: intake.draft_task_id, provisional: state === STATES.PROVISIONAL_REVIEW },
  }, "MERGE_AUTHORIZED_BY_COUNCIL");
  return { intake: next, snapshot, decision, token };
}

async function blockIntake(intakeId, reason = "MANUAL_BLOCK") {
  const db = requirePool();
  const intake = await getIntake(intakeId, db);
  if (!intake) throw new Error(`UNKNOWN_COUNCIL_INTAKE: ${intakeId}`);
  if (intake.status === STATES.BLOCKED) return intake;
  return transitionIntake(db, intakeId, STATES.BLOCKED, {
    lastError: String(reason).slice(0, 1600),
    draftAuthorizationHash: null,
    mergeAuthorizationHash: null,
    audit: { reason },
  }, "INTAKE_BLOCKED");
}

module.exports = {
  STATES, READ_ONLY_KINDS, COUNCIL_INTERNAL_KINDS,
  normalizeKind, actionNeedsCouncil, checkMutationPolicy, assertMutationPayloadSafety,
  sha256, canonicalJson, hashFrozenContext, verifyFrozenContext,
  requireAuthSecret, makeAuthorizationHash, timingSafeHashEqual,
  makeIds, canTransition, assertTransition, deriveReviewState, parseMergeDecision,
  buildCouncilTaskText, buildDraftReviewTaskText,
  ensureIntakeSchema, getIntake, createIntake, reviewIntake, authorizeDraft,
  assertAuthorization, withAuthorizedMutation, submitDraft, reviewDraft, blockIntake,
};
