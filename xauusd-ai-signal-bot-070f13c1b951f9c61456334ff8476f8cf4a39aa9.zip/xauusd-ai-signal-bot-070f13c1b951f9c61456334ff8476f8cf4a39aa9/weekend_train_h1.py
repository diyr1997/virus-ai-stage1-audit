#!/usr/bin/env python3
import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.metrics import accuracy_score, mean_absolute_error

from ai_predict_h1 import add_all_features, load_bundle
from cost_aware_backtest import evaluate_bundle, net_verdict
from final_holdout import seal as seal_final_holdout
from trading_school.features_v1 import SCHOOL_FEATURES
from weekend_train_h1_safe import dump_reload_verify, purged_chronological_split

TRIAL_PROFILES = [
    {"name": "balanced", "learning_rate": 0.05, "max_iter": 160, "max_leaf_nodes": 31, "min_samples_leaf": 40, "l2_regularization": 1.5},
    {"name": "slow_deep", "learning_rate": 0.035, "max_iter": 220, "max_leaf_nodes": 31, "min_samples_leaf": 45, "l2_regularization": 2.0},
    {"name": "compact", "learning_rate": 0.055, "max_iter": 150, "max_leaf_nodes": 15, "min_samples_leaf": 35, "l2_regularization": 1.2},
    {"name": "wide_regularized", "learning_rate": 0.04, "max_iter": 190, "max_leaf_nodes": 63, "min_samples_leaf": 55, "l2_regularization": 2.5},
    {"name": "conservative", "learning_rate": 0.03, "max_iter": 240, "max_leaf_nodes": 31, "min_samples_leaf": 65, "l2_regularization": 3.0},
    {"name": "responsive", "learning_rate": 0.065, "max_iter": 135, "max_leaf_nodes": 31, "min_samples_leaf": 30, "l2_regularization": 1.8},
    {"name": "wide_balanced", "learning_rate": 0.045, "max_iter": 175, "max_leaf_nodes": 63, "min_samples_leaf": 45, "l2_regularization": 2.2},
    {"name": "small_leaf", "learning_rate": 0.04, "max_iter": 205, "max_leaf_nodes": 15, "min_samples_leaf": 28, "l2_regularization": 2.0},
]


def _clean_input(path: str) -> pd.DataFrame:
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(raw, list):
        raise RuntimeError("Candles payload must be a list")
    df = pd.DataFrame(raw)
    required = ["timestamp", "open", "high", "low", "close"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise RuntimeError("Missing candle fields: " + ", ".join(missing))
    for col in required:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = (
        df.dropna(subset=required)
        .sort_values("timestamp")
        .drop_duplicates("timestamp")
        .reset_index(drop=True)
    )
    df["timestamp"] = df["timestamp"].astype("int64")
    for col in ["open", "high", "low", "close"]:
        df[col] = df[col].astype("float64")
    return df


def _build_dataset(df: pd.DataFrame, required_features: list[str]) -> pd.DataFrame:
    if len(df) < 8_000:
        raise RuntimeError(
            f"Need >=8000 M1 candles for challenger training, got {len(df)}"
        )

    x = add_all_features(df.copy())
    x["future_close_60"] = x["close"].shift(-60)
    x["future_ts_60"] = x["timestamp"].shift(-60)
    x["future_delta_min"] = (x["future_ts_60"] - x["timestamp"]) / 60_000.0
    x["target_return_bps"] = (x["future_close_60"] / x["close"] - 1.0) * 10_000.0
    x["target_direction"] = np.where(x["target_return_bps"] >= 0.0, 1, -1)

    required = list(required_features) + [
        "target_return_bps",
        "target_direction",
        "future_delta_min",
        "future_ts_60",
    ]
    x = x.replace([np.inf, -np.inf], np.nan).dropna(subset=required)
    x = x[(x["future_delta_min"] >= 55.0) & (x["future_delta_min"] <= 70.0)].copy()
    x["future_ts_60"] = x["future_ts_60"].astype("int64")
    return x


def _evaluate(bundle, X: np.ndarray, y_dir: np.ndarray, y_ret: np.ndarray) -> dict:
    dmodel = bundle["direction_models"][60]
    rmodel = bundle["return_models"][60]
    thr = bundle["thresholds"][60]

    pred = dmodel.predict(X).astype(int)
    probs = dmodel.predict_proba(X)
    conf = probs.max(axis=1)
    ret_pred = rmodel.predict(X).astype(float)
    confidence_threshold = float(thr.get("direction_confidence", 0.60))
    high = conf >= confidence_threshold

    return {
        "direction_accuracy": float(accuracy_score(y_dir, pred)),
        "high_conf_accuracy": float(accuracy_score(y_dir[high], pred[high])) if high.any() else None,
        "high_conf_coverage": float(high.mean()),
        "return_mae_bps": float(mean_absolute_error(y_ret, ret_pred)),
        "samples": int(len(y_dir)),
        "high_conf_samples": int(high.sum()),
    }


def _evaluate_frame(bundle, frame: pd.DataFrame, features: list[str]) -> dict:
    X = frame[features].to_numpy(dtype=np.float32)
    y_dir = frame["target_direction"].to_numpy(dtype=np.int8)
    y_ret = frame["target_return_bps"].to_numpy(dtype=np.float32)
    return _evaluate(bundle, X, y_dir, y_ret)


def _evaluate_blocks(bundle, frame: pd.DataFrame, features: list[str], blocks: int = 3) -> list[dict]:
    if len(frame) < blocks * 300:
        return []
    boundaries = np.linspace(0, len(frame), blocks + 1, dtype=int)
    results = []
    for i in range(blocks):
        part = frame.iloc[boundaries[i] : boundaries[i + 1]]
        if len(part) < 250:
            continue
        metrics = _evaluate_frame(bundle, part, features)
        metrics["block"] = i + 1
        results.append(metrics)
    return results


def _should_accept(champion, challenger, champion_blocks, challenger_blocks, mode):
    reasons = []
    min_gain = 0.003 if mode == "daily" else 0.005
    max_dir_degrade = 0.006 if mode == "daily" else 0.010

    c_dir = float(champion["direction_accuracy"])
    n_dir = float(challenger["direction_accuracy"])
    c_hi = champion.get("high_conf_accuracy")
    n_hi = challenger.get("high_conf_accuracy")
    c_mae = max(float(champion["return_mae_bps"]), 1e-9)
    n_mae = float(challenger["return_mae_bps"])

    dir_gain = n_dir - c_dir
    high_gain = None if c_hi is None or n_hi is None else float(n_hi) - float(c_hi)
    mae_ratio = n_mae / c_mae

    if challenger["samples"] < 1_000:
        reasons.append("validation_samples_below_1000")
    if challenger["high_conf_coverage"] < 0.03:
        reasons.append("high_conf_coverage_below_3pct")
    if mae_ratio > 1.08:
        reasons.append(f"return_mae_degraded_ratio={mae_ratio:.4f}")

    improved = dir_gain >= min_gain
    if high_gain is not None and high_gain >= 0.01 and dir_gain >= -max_dir_degrade:
        improved = True
    if not improved:
        reasons.append(
            f"no_clear_improvement_dir_gain={dir_gain:+.4f}_high_gain={high_gain if high_gain is not None else 'n/a'}"
        )

    if len(champion_blocks) == len(challenger_blocks) and len(champion_blocks) >= 3:
        block_gains = [
            float(n["direction_accuracy"]) - float(c["direction_accuracy"])
            for c, n in zip(champion_blocks, challenger_blocks)
        ]
        positive_blocks = sum(g > 0.0 for g in block_gains)
        worst_block = min(block_gains)
        median_block = float(np.median(block_gains))
        if positive_blocks < 2:
            reasons.append(f"robustness_positive_blocks={positive_blocks}_of_{len(block_gains)}")
        if worst_block < -0.015:
            reasons.append(f"robustness_worst_block_gain={worst_block:+.4f}")
        if median_block < -0.002:
            reasons.append(f"robustness_median_block_gain={median_block:+.4f}")

        for c, n in zip(champion_blocks, challenger_blocks):
            c_block_mae = max(float(c["return_mae_bps"]), 1e-9)
            block_mae_ratio = float(n["return_mae_bps"]) / c_block_mae
            if block_mae_ratio > 1.15:
                reasons.append(f"block_{n['block']}_return_mae_ratio={block_mae_ratio:.4f}")

    return len(reasons) == 0, reasons


def _profile_for(mode: str, trial: int) -> dict:
    if mode == "daily":
        return {
            "name": "daily_trading_school_v1",
            "learning_rate": 0.05,
            "max_iter": 120,
            "max_leaf_nodes": 31,
            "min_samples_leaf": 40,
            "l2_regularization": 1.8,
        }
    return dict(TRIAL_PROFILES[int(trial) % len(TRIAL_PROFILES)])


def _require_same_metrics(before: dict, after: dict, label: str) -> None:
    if before.keys() != after.keys():
        raise RuntimeError(f"Reloaded challenger {label} metric keys differ")
    for key in before:
        a = before[key]
        b = after[key]
        if a is None or b is None:
            if a is not b:
                raise RuntimeError(f"Reloaded challenger {label}.{key} differs")
            continue
        if isinstance(a, (int, np.integer)) and isinstance(b, (int, np.integer)):
            if int(a) != int(b):
                raise RuntimeError(f"Reloaded challenger {label}.{key} differs")
            continue
        if not np.isclose(float(a), float(b), rtol=1e-12, atol=1e-12, equal_nan=True):
            raise RuntimeError(f"Reloaded challenger {label}.{key} differs")


def _require_same_blocks(before: list[dict], after: list[dict]) -> None:
    if len(before) != len(after):
        raise RuntimeError("Reloaded challenger block metric count differs")
    for idx, (a, b) in enumerate(zip(before, after), start=1):
        _require_same_metrics(a, b, f"block_{idx}")


def train(champion_path: str, candles_path: str, output_path: str, mode: str, trial: int = 0) -> dict:
    champion = load_bundle(champion_path)
    champion_features = list(champion.get("features", []))
    if not champion_features:
        raise RuntimeError("Champion bundle has no feature list")

    challenger_features = champion_features + [
        f for f in SCHOOL_FEATURES if f not in champion_features
    ]

    df = _clean_input(candles_path)
    data = _build_dataset(df, challenger_features)

    # Remove the sealed block before anything else touches the frame, so no
    # training path can reach it by accident. The boundary is pinned in
    # final_holdout.json; a missing or broken config raises rather than
    # quietly handing the whole history to the trainer.
    data, holdout_df, holdout_report = seal_final_holdout(data)

    if len(data) < 7_000:
        raise RuntimeError(
            f"Only {len(data)} usable labeled rows after feature engineering "
            f"and sealing {holdout_report['holdout_rows']} final-holdout rows"
        )

    split = purged_chronological_split(
        data,
        train_fraction=0.70,
        min_train_rows=5_000,
        min_valid_rows=1_500,
        purge_rows=60,
    )
    train_df = split.train_df
    valid_df = split.valid_df
    if int(train_df["future_ts_60"].max()) >= int(valid_df["timestamp"].min()):
        raise RuntimeError("Temporal leakage detected in integrated trainer after 60-row purge")

    X_train = train_df[challenger_features].to_numpy(dtype=np.float32)
    y_train_dir = train_df["target_direction"].to_numpy(dtype=np.int8)
    y_train_ret = train_df["target_return_bps"].to_numpy(dtype=np.float32)

    profile = _profile_for(mode, trial)
    seed = 42 + int(trial)

    clf = HistGradientBoostingClassifier(
        learning_rate=profile["learning_rate"],
        max_iter=profile["max_iter"],
        max_leaf_nodes=profile["max_leaf_nodes"],
        min_samples_leaf=profile["min_samples_leaf"],
        l2_regularization=profile["l2_regularization"],
        random_state=seed,
    )
    reg = HistGradientBoostingRegressor(
        learning_rate=profile["learning_rate"],
        max_iter=profile["max_iter"],
        max_leaf_nodes=profile["max_leaf_nodes"],
        min_samples_leaf=profile["min_samples_leaf"],
        l2_regularization=profile["l2_regularization"],
        loss="absolute_error",
        random_state=seed,
    )

    clf.fit(X_train, y_train_dir)
    reg.fit(X_train, y_train_ret)

    challenger = dict(champion)
    challenger["direction_models"] = dict(champion["direction_models"])
    challenger["return_models"] = dict(champion["return_models"])
    challenger["direction_models"][60] = clf
    challenger["return_models"][60] = reg
    challenger["features"] = challenger_features

    now = datetime.now(timezone.utc)
    version = f"school-v1-h1-{mode}-t{int(trial):02d}-{now.strftime('%Y%m%dT%H%M%SZ')}"
    challenger["version"] = version

    champion_metrics = _evaluate_frame(champion, valid_df, champion_features)
    challenger_metrics = _evaluate_frame(challenger, valid_df, challenger_features)
    champion_blocks = _evaluate_blocks(champion, valid_df, champion_features, blocks=3)
    challenger_blocks = _evaluate_blocks(challenger, valid_df, challenger_features, blocks=3)

    # Price both models the way the live bot would have traded them: only the
    # rows that pass the production emit rule, one position at a time, exiting
    # where the label exits, with spread, slippage and commission taken out.
    # Direction accuracy alone cannot tell a profitable model from one that
    # trades more often for smaller wins.
    champion_net = evaluate_bundle(champion, valid_df, champion_features)
    challenger_net = evaluate_bundle(challenger, valid_df, challenger_features)
    net_ok, net_reasons = net_verdict(champion_net, challenger_net)

    accepted, reject_reasons = _should_accept(
        champion_metrics,
        challenger_metrics,
        champion_blocks,
        challenger_blocks,
        mode,
    )
    if not net_ok:
        accepted = False
        reject_reasons = list(reject_reasons) + net_reasons

    metadata = dict(champion.get("metadata", {}))
    metadata["auto_training"] = {
        "mode": mode,
        "trial": int(trial),
        "profile": profile,
        "trained_at": now.isoformat(),
        "source_rows": int(len(df)),
        "usable_rows": int(len(data)),
        "train_rows": int(len(train_df)),
        "validation_rows": int(len(valid_df)),
        "purge_rows": int(split.purge_rows),
        "train_end_future_ts": int(split.train_end_future_ts),
        "validation_start_ts": int(split.valid_start_ts),
        "temporal_leakage_check": "PASSED",
        "final_holdout": holdout_report,
        "reload_verified": True,
        "champion_version": champion.get("version"),
        "champion_metrics": champion_metrics,
        "challenger_metrics": challenger_metrics,
        "champion_blocks": champion_blocks,
        "challenger_blocks": challenger_blocks,
        "champion_net": champion_net,
        "challenger_net": challenger_net,
        "net_accepted": net_ok,
        "net_reasons": net_reasons,
        "accepted": accepted,
        "reject_reasons": reject_reasons,
    }
    metadata["trading_school_v1"] = {
        "enabled": True,
        "source_catalog": "trading_school/FREE_SOURCES_V1.md",
        "rule_catalog": "trading_school/RULE_SEEDS_V1.md",
        "feature_count_added": len(challenger_features) - len(champion_features),
        "features": [f for f in challenger_features if f.startswith("school_")],
        "copyright_mode": "derived measurable features only; no copied book text",
        "promotion_policy": "champion/challenger + out-of-sample robustness",
    }
    challenger["metadata"] = metadata

    reload_result = dump_reload_verify(
        challenger,
        output_path,
        valid_df,
        challenger_features,
        compress=3,
    )
    reloaded = joblib.load(output_path)
    reloaded_metrics = _evaluate_frame(reloaded, valid_df, challenger_features)
    reloaded_blocks = _evaluate_blocks(reloaded, valid_df, challenger_features, blocks=3)
    _require_same_metrics(challenger_metrics, reloaded_metrics, "validation")
    _require_same_blocks(challenger_blocks, reloaded_blocks)

    return {
        "ok": True,
        "mode": mode,
        "trial": int(trial),
        "profile": profile,
        "version": version,
        "champion_version": champion.get("version"),
        "accepted": accepted,
        "reject_reasons": reject_reasons,
        "source_rows": int(len(df)),
        "usable_rows": int(len(data)),
        "train_rows": int(len(train_df)),
        "validation_rows": int(len(valid_df)),
        "purge_rows": int(split.purge_rows),
        "train_end_future_ts": int(split.train_end_future_ts),
        "validation_start_ts": int(split.valid_start_ts),
        "temporal_leakage_check": "PASSED",
        "final_holdout": holdout_report,
        "reload_verified": bool(reload_result.get("reload_verified")),
        "reload_validation_rows": int(reload_result.get("reload_validation_rows", 0)),
        "champion_feature_count": len(champion_features),
        "challenger_feature_count": len(challenger_features),
        "school_features_added": [f for f in challenger_features if f not in champion_features],
        "champion_metrics": champion_metrics,
        "challenger_metrics": challenger_metrics,
        "champion_blocks": champion_blocks,
        "challenger_blocks": challenger_blocks,
        "champion_net": champion_net,
        "challenger_net": challenger_net,
        "net_accepted": net_ok,
        "net_reasons": net_reasons,
        "output": str(output_path),
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--champion", required=True)
    p.add_argument("--candles", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--mode", choices=["daily", "weekend"], default="daily")
    p.add_argument("--trial", type=int, default=0)
    args = p.parse_args()

    try:
        result = train(args.champion, args.candles, args.output, args.mode, args.trial)
        print(json.dumps(result, ensure_ascii=False, allow_nan=False))
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, allow_nan=False))
        raise SystemExit(2)


if __name__ == "__main__":
    main()
