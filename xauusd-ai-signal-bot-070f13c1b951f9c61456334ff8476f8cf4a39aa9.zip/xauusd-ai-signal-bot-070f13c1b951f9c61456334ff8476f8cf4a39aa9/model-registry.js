"use strict";

const fs = require("fs");
const os = require("os");
const path = require("path");
const { Pool } = require("pg");

const DATABASE_URL = String(
  process.env.DATABASE_URL || process.env.DATABASE_PUBLIC_URL || ""
).trim();
const REFRESH_MS = Math.max(30_000, Number(process.env.MODEL_REGISTRY_REFRESH_MS || 5 * 60_000));
const ACTIVE_H1_PATH = path.join(os.tmpdir(), "xauusd_ai_h1_active.joblib");

const pool = DATABASE_URL
  ? new Pool({ connectionString: DATABASE_URL, max: 1, idleTimeoutMillis: 30_000 })
  : null;

let cache = { checkedAt: 0, version: null, path: null };

async function resolveActiveH1ModelPath(fallbackPath) {
  if (!pool) return fallbackPath;
  const now = Date.now();
  if (cache.path && now - cache.checkedAt < REFRESH_MS && fs.existsSync(cache.path)) {
    return cache.path;
  }

  try {
    const result = await pool.query(
      `SELECT version, model_bytes FROM model_registry
       WHERE model_key='H1' AND active=TRUE
       ORDER BY created_at DESC LIMIT 1`
    );
    const row = result.rows[0];
    if (!row?.model_bytes) {
      cache = { checkedAt: now, version: null, path: fallbackPath };
      return fallbackPath;
    }

    if (cache.version !== row.version || !fs.existsSync(ACTIVE_H1_PATH)) {
      const temp = `${ACTIVE_H1_PATH}.${process.pid}.tmp`;
      fs.writeFileSync(temp, row.model_bytes);
      fs.renameSync(temp, ACTIVE_H1_PATH);
      console.log(`🧠 MODEL REGISTRY: active H1 ${row.version}`);
    }

    cache = { checkedAt: now, version: row.version, path: ACTIVE_H1_PATH };
    return ACTIVE_H1_PATH;
  } catch (error) {
    // First deployments may start before the registry table exists.
    cache = { checkedAt: now, version: null, path: fallbackPath };
    console.warn(`⚠️ MODEL REGISTRY fallback: ${String(error?.message || error).slice(0, 400)}`);
    return fallbackPath;
  }
}

function currentRegistryVersion() {
  return cache.version;
}

module.exports = {
  ACTIVE_H1_PATH,
  resolveActiveH1ModelPath,
  currentRegistryVersion,
};
