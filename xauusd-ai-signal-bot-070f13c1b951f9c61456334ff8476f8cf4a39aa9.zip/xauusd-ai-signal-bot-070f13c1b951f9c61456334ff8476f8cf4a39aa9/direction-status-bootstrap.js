"use strict";

const TelegramBot = require("node-telegram-bot-api");
const { Pool } = require("pg");

const ENABLED = String(process.env.DIRECTION_STATUS_BOOTSTRAP_ENABLED || "1") !== "0";
const DATABASE_URL = process.env.DATABASE_URL || process.env.DATABASE_PUBLIC_URL || "";
const MAX_TELEGRAM_TEXT = 4000;
const HORIZONS = [60, 180, 300];
const CATEGORIES = ["BOTH_CORRECT", "V2_BETTER", "LEGACY_BETTER", "BOTH_WRONG"];

let pool = null;
let installed = false;

function getPool() {
  if (!DATABASE_URL) return null;
  if (!pool) {
    pool = new Pool({
      connectionString: DATABASE_URL,
      max: 1,
      idleTimeoutMillis: 10_000,
      connectionTimeoutMillis: 3_000,
      query_timeout: 3_000,
    });
  }
  return pool;
}

function normalizePayload(value) {
  if (!value) return {};
  if (typeof value === "object" && !Array.isArray(value)) return value;
  try {
    const parsed = JSON.parse(String(value));
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
  } catch (_) {
    return {};
  }
}

function appendWithinLimit(baseText, suffix) {
  const base = String(baseText || "");
  if (base.length >= MAX_TELEGRAM_TEXT) return base;
  const room = MAX_TELEGRAM_TEXT - base.length;
  if (room < 48) return base;
  return base + String(suffix || "").slice(0, room);
}

function confidenceBucket(value) {
  const n = Math.max(0, Math.min(100, Number(value) || 0));
  if (n < 50) return "<50";
  if (n < 60) return "50-59";
  if (n < 70) return "60-69";
  if (n < 80) return "70-79";
  if (n < 90) return "80-89";
  return "90+";
}

function comparisonCategory(payload) {
  const explicit = String(payload.comparison || "").toUpperCase();
  if (CATEGORIES.includes(explicit)) return explicit;
  if (typeof payload.correct_direction !== "boolean" || typeof payload.legacy_correct_direction !== "boolean") {
    return null;
  }
  if (payload.correct_direction && payload.legacy_correct_direction) return "BOTH_CORRECT";
  if (payload.correct_direction) return "V2_BETTER";
  if (payload.legacy_correct_direction) return "LEGACY_BETTER";
  return "BOTH_WRONG";
}

function emptyCounts() {
  return { total: 0, BOTH_CORRECT: 0, V2_BETTER: 0, LEGACY_BETTER: 0, BOTH_WRONG: 0 };
}

function rowFromCounts(dimension, value, horizon, counts) {
  const v2Correct = counts.BOTH_CORRECT + counts.V2_BETTER;
  const legacyCorrect = counts.BOTH_CORRECT + counts.LEGACY_BETTER;
  const total = counts.total;
  const v2Accuracy = total ? (100 * v2Correct) / total : null;
  const legacyAccuracy = total ? (100 * legacyCorrect) / total : null;
  return {
    dimension,
    value,
    horizon,
    ...counts,
    v2Correct,
    legacyCorrect,
    v2Accuracy,
    legacyAccuracy,
    deltaPp: total ? v2Accuracy - legacyAccuracy : null,
  };
}

function aggregateDirectionComparisons(values) {
  const groups = new Map();
  const excluded = { flat: 0, noLegacyComparison: 0, invalidHorizon: 0 };
  const add = (dimension, value, horizon, category) => {
    const normalized = String(value || "UNKNOWN").toUpperCase();
    const key = `${dimension}\u0000${normalized}\u0000${horizon}`;
    if (!groups.has(key)) groups.set(key, { dimension, value: normalized, horizon, counts: emptyCounts() });
    const group = groups.get(key);
    group.counts.total += 1;
    group.counts[category] += 1;
  };

  for (const value of values || []) {
    const p = normalizePayload(value && Object.prototype.hasOwnProperty.call(value, "payload") ? value.payload : value);
    const horizon = Number(p.horizon_seconds);
    if (!HORIZONS.includes(horizon)) {
      excluded.invalidHorizon += 1;
      continue;
    }
    if (p.flat_direction === true) {
      excluded.flat += 1;
      continue;
    }
    const category = comparisonCategory(p);
    if (!category) {
      excluded.noLegacyComparison += 1;
      continue;
    }
    add("horizon", "ALL", horizon, category);
    add("confidence", p.confidence_bucket || confidenceBucket(p.direction_confidence), horizon, category);
    add("regime", p.market_regime || "UNKNOWN", horizon, category);
    add("session", p.trading_session || p.session || "UNKNOWN", horizon, category);
  }

  const rows = [...groups.values()].map((x) => rowFromCounts(x.dimension, x.value, x.horizon, x.counts));
  rows.sort((a, b) => HORIZONS.indexOf(a.horizon) - HORIZONS.indexOf(b.horizon)
    || a.dimension.localeCompare(b.dimension) || a.value.localeCompare(b.value));
  return {
    horizons: rows.filter((x) => x.dimension === "horizon"),
    confidence: rows.filter((x) => x.dimension === "confidence"),
    regimes: rows.filter((x) => x.dimension === "regime"),
    sessions: rows.filter((x) => x.dimension === "session"),
    excluded,
  };
}

async function loadDirectionComparisons() {
  const db = getPool();
  if (!db) return aggregateDirectionComparisons([]);
  const result = await db.query(`
    SELECT payload
    FROM demo_trader_events
    WHERE event_type = 'SHADOW_DIRECTION_OUTCOME'
    ORDER BY id DESC
    LIMIT 10000
  `);
  return aggregateDirectionComparisons(result.rows || []);
}

function formatRow(row, prefix) {
  const delta = row.deltaPp >= 0 ? `+${row.deltaPp.toFixed(1)}` : row.deltaPp.toFixed(1);
  return `${prefix} n=${row.total} • V2 ${row.v2Accuracy.toFixed(1)}% / OLD ${row.legacyAccuracy.toFixed(1)}% • Δ${delta}pp • `
    + `${row.BOTH_CORRECT}/${row.V2_BETTER}/${row.LEGACY_BETTER}/${row.BOTH_WRONG}`;
}

function formatDirectionComparisons(report) {
  const labels = { 60: "1м", 180: "3м", 300: "5м" };
  const lines = ["", "🧠 DIRECTION OLD vs V2 SHADOW", "Формат: BOTH_CORRECT/V2_BETTER/LEGACY_BETTER/BOTH_WRONG"];
  if (!report.horizons.length) {
    lines.push("⏳ сопоставимых данных пока нет");
  } else {
    for (const row of report.horizons) lines.push(formatRow(row, labels[row.horizon] || `${row.horizon}с`));
    for (const [title, rows] of [
      ["Confidence", report.confidence],
      ["Regime", report.regimes],
      ["Session", report.sessions],
    ]) {
      if (!rows.length) continue;
      lines.push(`${title}:`);
      for (const row of rows) lines.push(formatRow(row, `${labels[row.horizon] || row.horizon} ${row.value}`));
    }
  }
  const skipped = report.excluded.flat + report.excluded.noLegacyComparison;
  if (skipped) lines.push(`Исключено: flat=${report.excluded.flat}, без OLD-сравнения=${report.excluded.noLegacyComparison}`);
  lines.push("Read-only • SHADOW ONLY • на entry/exit/order execution не влияет");
  return lines.join("\n");
}

async function augment(text) {
  if (typeof text !== "string" || !text.startsWith("🗄 PostgreSQL")) return text;
  if (text.includes("🧠 DIRECTION OLD vs V2 SHADOW")) return text;
  try {
    return appendWithinLimit(text, formatDirectionComparisons(await loadDirectionComparisons()));
  } catch (error) {
    return appendWithinLimit(text, "\n\n🧠 DIRECTION OLD vs V2 SHADOW\n⚠️ статистика временно недоступна");
  }
}

function install() {
  if (!ENABLED || installed) return false;
  if (!TelegramBot?.prototype || typeof TelegramBot.prototype.sendMessage !== "function") return false;
  const original = TelegramBot.prototype.sendMessage;
  TelegramBot.prototype.sendMessage = async function patchedDirectionStatus(chatId, text, options) {
    return original.call(this, chatId, await augment(text), options);
  };
  installed = true;
  console.log("✅ DIRECTION STATUS: /db_status OLD-vs-V2 segmented SHADOW comparison enabled");
  return true;
}

if (ENABLED) {
  const installedAtStartup = install();
  if (!installedAtStartup) {
    console.warn(
      "⚠️ DIRECTION STATUS: preload skipped | "
      + `telegram_prototype=${Boolean(TelegramBot && TelegramBot.prototype)} | `
      + `sendMessage_type=${typeof TelegramBot?.prototype?.sendMessage}`,
    );
  }
} else {
  console.log("ℹ️ DIRECTION STATUS: disabled by DIRECTION_STATUS_BOOTSTRAP_ENABLED=0");
}

module.exports = {
  aggregateDirectionComparisons,
  appendWithinLimit,
  augment,
  comparisonCategory,
  confidenceBucket,
  formatDirectionAccuracy: formatDirectionComparisons,
  formatDirectionComparisons,
  install,
  loadDirectionAccuracy: loadDirectionComparisons,
  loadDirectionComparisons,
  normalizePayload,
};
