"use strict";

/*
  GRAPH V7 SHADOW TELEMETRY
  - wraps forecast-v7-engine without changing its forecast output;
  - stores the latest V7 plan per timeframe in memory;
  - enriches analysis_runs.payload with the exact V7 shadow forecast;
  - never changes trade_candidates, order execution, signal direction or risk.
*/

const { Pool } = require("pg");

const ENABLED = /^(1|true|yes|on)$/i.test(String(process.env.GRAPH_V7_ENABLED || "0"));
const ENGINE_PATCHED = Symbol.for("xauusd.graph.v7.telemetry.engine.v1");
const POOL_PATCHED = Symbol.for("xauusd.graph.v7.telemetry.pool.v1");
const STORE = Symbol.for("xauusd.graph.v7.telemetry.store.v1");
const MAX_MATCH_AGE_MS = Math.max(5_000, Number(process.env.GRAPH_V7_TELEMETRY_MATCH_MS || 60_000));

globalThis[STORE] = globalThis[STORE] || new Map();

function finite(value) {
  return Number.isFinite(Number(value));
}

function compactPoint(point) {
  if (!point || !finite(point.minute)) return null;
  const out = { minute: Number(point.minute) };
  if (finite(point.center)) out.center = Number(point.center);
  if (finite(point.low)) out.low = Number(point.low);
  if (finite(point.high)) out.high = Number(point.high);
  return out;
}

function snapshotPlan(plan, timeframe) {
  if (!plan || plan.forecastModel !== "GRAPH_V7_ANALOG_ENVELOPE_V1") return null;
  const primary = (Array.isArray(plan.forecast) ? plan.forecast : []).map(compactPoint).filter(Boolean);
  const alternative = (Array.isArray(plan.alternativeForecast) ? plan.alternativeForecast : [])
    .map(compactPoint)
    .filter(Boolean);
  return {
    recorded_at: new Date().toISOString(),
    timeframe: String(timeframe || "").toUpperCase(),
    model: plan.forecastModel,
    mode: plan.v7Mode || null,
    state: plan.v7State || null,
    primary_direction: plan.v7PrimaryDirection || null,
    alternative_evidence: plan.v7AlternativeEvidence || null,
    horizon_minutes: Number(plan.horizon || 0),
    evidence: plan.v7Evidence || null,
    primary,
    alternative,
  };
}

function mergePayload(rawPayload, snapshot) {
  if (!snapshot) return rawPayload;
  let payload = {};
  try {
    payload = rawPayload && typeof rawPayload === "object"
      ? { ...rawPayload }
      : JSON.parse(String(rawPayload || "{}"));
  } catch {
    payload = {};
  }
  payload.graph_v7_shadow = snapshot;
  return JSON.stringify(payload);
}

function installEngineWrapper() {
  const enginePath = require.resolve("./forecast-v7-engine");
  const engine = require(enginePath);
  if (!engine || typeof engine.buildTradePlanV7 !== "function" || engine[ENGINE_PATCHED]) return;

  const original = engine.buildTradePlanV7.bind(engine);
  const wrapped = {
    ...engine,
    buildTradePlanV7(args) {
      const plan = original(args);
      const tf = String(args?.timeframe || "").toUpperCase();
      const snapshot = snapshotPlan(plan, tf);
      if (snapshot && tf) {
        globalThis[STORE].set(tf, { snapshot, storedAt: Date.now() });
      }
      return plan;
    },
  };
  Object.defineProperty(wrapped, ENGINE_PATCHED, { value: true, enumerable: false });
  require.cache[enginePath].exports = wrapped;
}

function installPoolWrapper() {
  if (Pool.prototype[POOL_PATCHED]) return;
  const originalQuery = Pool.prototype.query;

  Pool.prototype.query = function graphV7TelemetryQuery(text, values, ...rest) {
    const sql = typeof text === "string" ? text : String(text?.text || "");
    if (!/INSERT\s+INTO\s+analysis_runs/i.test(sql) || !Array.isArray(values) || values.length < 24) {
      return originalQuery.call(this, text, values, ...rest);
    }

    const tf = String(values[1] || "").toUpperCase();
    const stored = globalThis[STORE].get(tf);
    if (!stored || Date.now() - stored.storedAt > MAX_MATCH_AGE_MS) {
      return originalQuery.call(this, text, values, ...rest);
    }

    const nextValues = [...values];
    nextValues[23] = mergePayload(nextValues[23], stored.snapshot);
    return originalQuery.call(this, text, nextValues, ...rest);
  };

  Object.defineProperty(Pool.prototype, POOL_PATCHED, { value: true, enumerable: false });
}

if (ENABLED) {
  installEngineWrapper();
  installPoolWrapper();
  console.log("📈 GRAPH V7 TELEMETRY: analysis_runs payload capture ON");
} else {
  console.log("📈 GRAPH V7 TELEMETRY: OFF (GRAPH_V7_ENABLED=0)");
}

module.exports = { snapshotPlan, mergePayload, STORE };
