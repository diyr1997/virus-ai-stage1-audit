"use strict";

/*
 * FAST NEWS WATCHER — research/shadow only.
 *
 * Two lanes:
 *  1) Trading Economics WebSocket calendar/news when key:secret is configured.
 *  2) Official RSS fallback (BLS/Fed) with conditional GET.
 *
 * It never creates trade candidates or orders. It sends an outbound Telegram
 * alert to the existing bot owner chat and records measured processing latency.
 */

const crypto = require("crypto");
const WebSocket = require("ws");
const { Pool } = require("pg");

const ENABLED = /^(1|true|yes|enabled)$/i.test(String(process.env.FAST_NEWS_WATCHER_ENABLED || "0"));
const TOKEN = String(process.env.TELEGRAM_BOT_TOKEN || "").trim();
const CHAT_ID = String(process.env.TELEGRAM_OWNER_CHAT_ID || "").trim();
const DATABASE_URL = String(process.env.DATABASE_URL || "").trim();
const TE_KEY = String(process.env.TRADING_ECONOMICS_API_KEY || process.env.TRADING_ECONOMICS_STREAM_KEY || "").trim();
const RSS_POLL_MS = Math.max(5_000, Number(process.env.FAST_NEWS_RSS_POLL_MS || 15_000));
const AI_MAX_AGE_MS = Math.max(15_000, Number(process.env.FAST_NEWS_AI_MAX_AGE_MS || 120_000));
const RECONNECT_MS = Math.max(5_000, Number(process.env.FAST_NEWS_RECONNECT_MS || 15_000));

const OFFICIAL_FAST_FEEDS = Object.freeze([
  { name: "BLS PPI", url: "https://www.bls.gov/feed/ppi.rss", impact: 95 },
  { name: "BLS CPI", url: "https://www.bls.gov/feed/cpi.rss", impact: 98 },
  { name: "BLS Employment/NFP", url: "https://www.bls.gov/feed/empsit.rss", impact: 98 },
  { name: "BLS JOLTS", url: "https://www.bls.gov/feed/jolts.rss", impact: 86 },
  { name: "Federal Reserve", url: "https://www.federalreserve.gov/feeds/press_monetary.xml", impact: 98 },
]);

const pool = DATABASE_URL
  ? new Pool({ connectionString: DATABASE_URL, max: 2, idleTimeoutMillis: 30_000, connectionTimeoutMillis: 5_000 })
  : null;

const seen = new Map();
const feedState = new Map();
let rssPrimed = false;
let rssTimer = null;
let teSocket = null;
let reconnectTimer = null;
let started = false;

function clamp100(v) {
  return Math.max(0, Math.min(100, Math.round(Number(v) || 0)));
}

function esc(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function decodeXml(value) {
  return String(value || "")
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function tag(block, names) {
  for (const name of names) {
    const match = String(block).match(new RegExp(`<${name}[^>]*>([\\s\\S]*?)<\\/${name}>`, "i"));
    if (match) return decodeXml(match[1]);
  }
  return "";
}

function attrLink(block) {
  const match = String(block).match(/<link[^>]+href=["']([^"']+)["'][^>]*>/i);
  return match ? decodeXml(match[1]) : "";
}

function parseRss(xml, source) {
  const blocks = String(xml || "").match(/<item\b[\s\S]*?<\/item>|<entry\b[\s\S]*?<\/entry>/gi) || [];
  return blocks.map((block) => {
    const title = tag(block, ["title"]);
    const description = tag(block, ["description", "summary", "content"]);
    const link = tag(block, ["link"]) || attrLink(block);
    const published = tag(block, ["pubDate", "published", "updated"]);
    const guid = tag(block, ["guid", "id"]);
    const key = crypto.createHash("sha256").update([source.name, guid, link, title, published].join("|")).digest("hex");
    return {
      key,
      transport: "OFFICIAL_RSS",
      source: source.name,
      title,
      description,
      url: link,
      publishedAt: published || null,
      impact: source.impact,
      receivedAt: Date.now(),
    };
  }).filter((x) => x.title);
}

function parseNumber(value) {
  if (value === null || value === undefined || value === "") return null;
  const raw = String(value).trim().replace(/,/g, "");
  const match = raw.match(/[-+]?\d+(?:\.\d+)?/);
  if (!match) return null;
  let n = Number(match[0]);
  if (!Number.isFinite(n)) return null;
  if (/k\b/i.test(raw)) n *= 1e3;
  else if (/m\b/i.test(raw)) n *= 1e6;
  else if (/b\b/i.test(raw)) n *= 1e9;
  return n;
}

function normalizeTeMessage(message) {
  const root = message && typeof message === "object" ? message : {};
  const data = root.data && typeof root.data === "object" ? root.data : root;
  const actual = data.Actual ?? data.actual ?? null;
  const forecast = data.Forecast ?? data.forecast ?? data.TEForecast ?? data.teForecast ?? null;
  const previous = data.Previous ?? data.previous ?? null;
  const title = String(data.Event ?? data.event ?? data.Title ?? data.title ?? data.Category ?? data.category ?? "Trading Economics event").trim();
  const category = String(data.Category ?? data.category ?? title).trim();
  const country = String(data.Country ?? data.country ?? "").trim();
  const date = data.Date ?? data.date ?? data.LastUpdate ?? data.lastUpdate ?? null;
  const id = data.CalendarId ?? data.calendarId ?? data.Id ?? data.id ?? "";
  const key = crypto.createHash("sha256").update([root.topic, id, country, category, title, date, actual, forecast].join("|")).digest("hex");
  return {
    key,
    transport: `TE_WEBSOCKET:${String(root.topic || "unknown")}`,
    source: "Trading Economics",
    title,
    description: String(data.Description ?? data.description ?? "").trim(),
    country,
    category,
    actual,
    forecast,
    previous,
    impact: clamp100((Number(data.Importance ?? data.importance ?? 2) || 2) * 32),
    publishedAt: date ? String(date) : null,
    receivedAt: Date.now(),
  };
}

function inferDirection(event) {
  const text = `${event.category || ""} ${event.title || ""} ${event.description || ""}`.toLowerCase();
  const actual = parseNumber(event.actual);
  const forecast = parseNumber(event.forecast);
  const hasSurprise = actual !== null && forecast !== null && actual !== forecast;

  let family = "OTHER";
  let positiveSurpriseGoldDirection = null;
  if (/consumer price|\bcpi\b|producer price|\bppi\b|pce|inflation/.test(text)) {
    family = "INFLATION"; positiveSurpriseGoldDirection = "SELL";
  } else if (/unemployment rate|jobless claim|unemployment claim/.test(text)) {
    family = "LABOR_WEAKNESS"; positiveSurpriseGoldDirection = "BUY";
  } else if (/nonfarm|payroll|employment change|jobs added|retail sales|gdp|ism/.test(text)) {
    family = "GROWTH_LABOR"; positiveSurpriseGoldDirection = "SELL";
  } else if (/interest rate|fed funds|rate decision|policy rate/.test(text)) {
    family = "RATES"; positiveSurpriseGoldDirection = "SELL";
  }

  if (hasSurprise && positiveSurpriseGoldDirection) {
    const positive = actual > forecast;
    const direction = positive
      ? positiveSurpriseGoldDirection
      : (positiveSurpriseGoldDirection === "BUY" ? "SELL" : "BUY");
    return {
      direction,
      confidence: 74,
      family,
      reason: `structured surprise: actual ${event.actual} vs forecast ${event.forecast}`,
      surprise: actual - forecast,
    };
  }

  if (/missile|airstrike|attack|war escalation|invasion|sanction|strait of hormuz|red sea/.test(text)) {
    return { direction: "BUY", confidence: 60, family: "GEOPOLITICS", reason: "risk-off escalation headline", surprise: null };
  }
  if (/ceasefire|peace deal|de-escalat/.test(text)) {
    return { direction: "SELL", confidence: 57, family: "GEOPOLITICS", reason: "risk premium easing headline", surprise: null };
  }

  if (family === "INFLATION") {
    if (/declin|fell|falls|decreas|cool/.test(text)) return { direction: "BUY", confidence: 56, family, reason: "inflation headline lower; forecast surprise unavailable", surprise: null };
    if (/rose|rises|increas|accelerat|hotter/.test(text)) return { direction: "SELL", confidence: 56, family, reason: "inflation headline higher; forecast surprise unavailable", surprise: null };
  }

  return { direction: "WAIT", confidence: 45, family, reason: "no verified structured surprise; do not guess", surprise: null };
}

async function latestInternalAi() {
  if (!pool) return { fresh: false, reason: "DATABASE_NOT_CONFIGURED" };
  try {
    const { rows } = await pool.query(
      `SELECT analyzed_at, timeframe, action, direction, strength, analysis_price
       FROM analysis_runs
       WHERE analyzed_at >= NOW() - ($1::bigint * INTERVAL '1 millisecond')
       ORDER BY analyzed_at DESC LIMIT 1`,
      [AI_MAX_AGE_MS]
    );
    if (!rows.length) return { fresh: false, reason: "NO_FRESH_INTERNAL_AI" };
    const row = rows[0];
    return {
      fresh: true,
      analyzedAt: row.analyzed_at,
      timeframe: String(row.timeframe || ""),
      direction: String(row.action || row.direction || "WAIT").toUpperCase(),
      strength: clamp100(row.strength),
      price: row.analysis_price === null ? null : Number(row.analysis_price),
    };
  } catch (error) {
    return { fresh: false, reason: `AI_DB_ERROR:${error.message}` };
  }
}

function combine(newsSignal, ai) {
  const nd = newsSignal.direction;
  if (!ai?.fresh) return { direction: nd, confidence: newsSignal.confidence, reason: "news-only; internal AI context unavailable" };
  const ad = ["BUY", "SELL"].includes(ai.direction) ? ai.direction : "WAIT";
  if (nd === "WAIT") return { direction: "WAIT", confidence: Math.max(45, Math.min(59, ai.strength)), reason: `news unresolved; internal AI=${ad} ${ai.strength}/100` };
  if (ad === nd) return { direction: nd, confidence: Math.min(92, Math.max(newsSignal.confidence, ai.strength) + 7), reason: `news + internal AI agree (${ad} ${ai.strength}/100)` };
  if (ad === "WAIT") return { direction: nd, confidence: Math.min(78, newsSignal.confidence), reason: "structured news signal; internal AI neutral" };
  return { direction: "WAIT", confidence: Math.max(50, Math.min(65, Math.round((newsSignal.confidence + ai.strength) / 2))), reason: `conflict: news=${nd}, internal AI=${ad}` };
}

async function sendTelegram(text) {
  if (!TOKEN || !CHAT_ID) throw new Error("TELEGRAM_NOT_CONFIGURED");
  const startedAt = Date.now();
  const response = await fetch(`https://api.telegram.org/bot${TOKEN}/sendMessage`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ chat_id: CHAT_ID, text, parse_mode: "HTML", disable_web_page_preview: true }),
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok || body?.ok === false) throw new Error(`TELEGRAM_HTTP_${response.status}:${body?.description || "unknown"}`);
  return Date.now() - startedAt;
}

function remember(key) {
  seen.set(key, Date.now());
  const cutoff = Date.now() - 24 * 60 * 60_000;
  for (const [k, ts] of seen) if (ts < cutoff) seen.delete(k);
}

async function processEvent(event, { notify = true } = {}) {
  if (!event?.key || seen.has(event.key)) return false;
  remember(event.key);
  if (!notify) return false;

  const start = Date.now();
  const news = inferDirection(event);
  const ai = await latestInternalAi();
  const final = combine(news, ai);
  const decisionMs = Date.now() - start;
  const icon = final.direction === "BUY" ? "🟢" : final.direction === "SELL" ? "🔴" : "⚪";
  const values = event.actual !== null && event.actual !== undefined
    ? `\nActual: <b>${esc(event.actual)}</b>${event.forecast !== null && event.forecast !== undefined ? ` | Forecast: <b>${esc(event.forecast)}</b>` : ""}${event.previous !== null && event.previous !== undefined ? ` | Previous: ${esc(event.previous)}` : ""}`
    : "";
  const aiLine = ai?.fresh
    ? `${esc(ai.timeframe)} ${esc(ai.direction)} ${ai.strength}/100${Number.isFinite(ai.price) ? ` @ ${ai.price}` : ""}`
    : `нет свежего контекста (${esc(ai?.reason || "unknown")})`;
  const ageMs = event.receivedAt ? Math.max(0, Date.now() - event.receivedAt) : null;
  const text = [
    `⚡ <b>FAST NEWS — XAU/USD</b>`,
    `<b>${esc(event.title)}</b>`,
    `Источник: ${esc(event.source)} | канал: ${esc(event.transport)}`,
    values,
    `${icon} <b>${final.direction} ${clamp100(final.confidence)}/100</b>`,
    `News logic: ${esc(news.reason)}`,
    `Наш AI до/на момент события: ${aiLine}`,
    `Итог: ${esc(final.reason)}`,
    `⏱ decision=${decisionMs} ms${ageMs !== null ? ` | event→decision≈${ageMs} ms` : ""}`,
    `🛡 RESEARCH/SHADOW — автоматический REAL-вход выключен`,
  ].filter(Boolean).join("\n");

  const telegramMs = await sendTelegram(text);
  console.log(`FAST_NEWS_SENT key=${event.key.slice(0, 10)} direction=${final.direction} confidence=${final.confidence} decision_ms=${decisionMs} telegram_http_ms=${telegramMs}`);
  return true;
}

async function fetchFeed(source) {
  const state = feedState.get(source.url) || {};
  const headers = { "user-agent": "VIRUS-AI-FastNews/1.0 (research RSS reader)" };
  if (state.etag) headers["if-none-match"] = state.etag;
  if (state.lastModified) headers["if-modified-since"] = state.lastModified;
  const response = await fetch(source.url, { headers, signal: AbortSignal.timeout(8_000) });
  if (response.status === 304) return [];
  if (!response.ok) throw new Error(`${source.name}_HTTP_${response.status}`);
  feedState.set(source.url, {
    etag: response.headers.get("etag") || state.etag || null,
    lastModified: response.headers.get("last-modified") || state.lastModified || null,
  });
  return parseRss(await response.text(), source);
}

async function pollRssOnce() {
  const batches = await Promise.allSettled(OFFICIAL_FAST_FEEDS.map(fetchFeed));
  const events = [];
  for (const batch of batches) {
    if (batch.status === "fulfilled") events.push(...batch.value);
    else console.warn(`FAST_NEWS_RSS_ERROR ${batch.reason?.message || batch.reason}`);
  }
  events.sort((a, b) => String(a.publishedAt || "").localeCompare(String(b.publishedAt || "")));
  if (!rssPrimed) {
    for (const event of events) remember(event.key);
    rssPrimed = true;
    console.log(`FAST_NEWS_RSS_PRIMED items=${events.length} poll_ms=${RSS_POLL_MS}`);
    return;
  }
  for (const event of events) await processEvent(event, { notify: true });
}

function startRssFallback() {
  pollRssOnce().catch((e) => console.warn(`FAST_NEWS_RSS_PRIME_ERROR ${e.message}`));
  rssTimer = setInterval(() => pollRssOnce().catch((e) => console.warn(`FAST_NEWS_RSS_POLL_ERROR ${e.message}`)), RSS_POLL_MS);
  rssTimer.unref?.();
}

function scheduleTeReconnect() {
  if (reconnectTimer || !TE_KEY) return;
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    startTradingEconomicsStream();
  }, RECONNECT_MS);
  reconnectTimer.unref?.();
}

function startTradingEconomicsStream() {
  if (!TE_KEY) {
    console.log("FAST_NEWS_TE_STREAM NOT_CONFIGURED (set key:secret)");
    return false;
  }
  if (teSocket && [WebSocket.OPEN, WebSocket.CONNECTING].includes(teSocket.readyState)) return true;
  const url = `wss://stream.tradingeconomics.com/?client=${encodeURIComponent(TE_KEY)}`;
  teSocket = new WebSocket(url, { perMessageDeflate: false, handshakeTimeout: 10_000 });
  teSocket.on("open", () => {
    console.log("FAST_NEWS_TE_STREAM CONNECTED");
    teSocket.send(JSON.stringify({ topic: "subscribe", to: "calendar" }));
    teSocket.send(JSON.stringify({ topic: "subscribe", to: "news" }));
  });
  teSocket.on("message", (raw) => {
    try {
      const msg = JSON.parse(raw.toString());
      if (!msg?.topic || msg.topic === "keepalive") return;
      processEvent(normalizeTeMessage(msg), { notify: true }).catch((e) => console.warn(`FAST_NEWS_TE_EVENT_ERROR ${e.message}`));
    } catch (error) {
      console.warn(`FAST_NEWS_TE_PARSE_ERROR ${error.message}`);
    }
  });
  teSocket.on("error", (error) => console.warn(`FAST_NEWS_TE_STREAM_ERROR ${error.message}`));
  teSocket.on("close", () => {
    console.warn("FAST_NEWS_TE_STREAM CLOSED");
    scheduleTeReconnect();
  });
  return true;
}

function startFastNewsWatcher() {
  if (started) return true;
  if (!ENABLED) {
    console.log("FAST_NEWS_WATCHER DISABLED");
    return false;
  }
  if (!TOKEN || !CHAT_ID) {
    console.warn("FAST_NEWS_WATCHER NOT_CONFIGURED telegram token/chat missing");
    return false;
  }
  started = true;
  console.log(`FAST_NEWS_WATCHER START rss_poll_ms=${RSS_POLL_MS} te_stream=${TE_KEY ? "configured" : "not_configured"} real_trading=false`);
  startRssFallback();
  startTradingEconomicsStream();
  return true;
}

function stopFastNewsWatcher() {
  if (rssTimer) clearInterval(rssTimer);
  if (reconnectTimer) clearTimeout(reconnectTimer);
  if (teSocket) teSocket.close();
  rssTimer = reconnectTimer = teSocket = null;
  started = false;
}

module.exports = {
  OFFICIAL_FAST_FEEDS,
  parseRss,
  parseNumber,
  normalizeTeMessage,
  inferDirection,
  combine,
  processEvent,
  startFastNewsWatcher,
  stopFastNewsWatcher,
};
