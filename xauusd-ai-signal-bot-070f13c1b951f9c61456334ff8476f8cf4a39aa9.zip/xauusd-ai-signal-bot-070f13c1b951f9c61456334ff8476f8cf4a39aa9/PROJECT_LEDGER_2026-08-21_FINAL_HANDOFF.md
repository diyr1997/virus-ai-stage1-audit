# XAU/USD FINAL HANDOFF LEDGER — updated 2026-08-25

This file supersedes older V8/V9-V3 handoff wording for the current Windows DEMO worker handoff. Historical notes remain background only.

## Current Windows DEMO worker

- Canonical handoff version: `xauusd-demo-worker-v9-fenced-basket-v5-fast80-watchdog-2026-08-25`.
- Canonical clean download branch: `handoff/v9-clean-download-2026-08-21` (branch name retained for compatibility; contents are refreshed to the current V5 handoff).
- Canonical download archive: `xauusd-demo-worker-v9.zip`; versioned archive: `xauusd-demo-worker-v9-v5-fast80-watchdog.zip`.
- `trader.py` resolves `DemoTrader` to `V9HardenedV4DemoTrader`.
- Strong impulse fast-entry threshold is 80/100 across M1/M5/M15/M30/H1. It bypasses ordinary confirmation only; it never bypasses DEMO-only, MT5 freshness/market state, SL/TP validity, ownership/fencing, no-hedge direction guard, basket rules, risk, margin, reconciliation, or the final pre-`order_send` guard.
- Automatic execution remains DEMO-only; REAL accounts are blocked in `worker.py`.
- `worker_watchdog_v2.py` prevents stale broker ticks from being written as fresh DB quotes and requests launcher restart after a persistent unexpected stale live feed. Planned daily break/weekend does not trigger this restart.
- PostgreSQL advisory ownership/fencing prevents a stale or second worker from sending new orders.
- Basket identity/risk is global across M1/M5/M15/M30/H1.
- V9 deliberately removes an arbitrary fixed position-count ceiling. New additions are constrained by risk budget, margin reserve, profitable-basket requirement, entry gap and favorable price progress.
- Simultaneous bot BUY and SELL exposure is blocked. Reversal close-and-flip remains SHADOW/OFF and is not enabled for this handoff.
- Ambiguous MT5 sends are never automatically retried. They enter reconciliation/fail-closed handling.
- `positions_get(None)` is an unavailable-MT5-state error, never interpreted as a flat account.
- The launcher compiles the full runtime, runs `verify_v9_package.py`, runs the read-only preflight, then starts `worker_watchdog_v2.py`.

## Current cloud architecture

- Existing `xauusd-ai-signal-bot` remains the production Telegram analytics service.
- `xauusd-ai-signal-bot-next` remains SHADOW/read-only architecture work and is not a production Telegram replacement.
- Shared PostgreSQL is allowed only while the next service remains non-trading/non-Telegram and its market-data probe does not create automatic trade candidates.
- `/db_status` includes worker freshness/watchdog diagnostics plus the newest candidate and recent V9 entry-pipeline blocker/order events.

## Safe-to-ship policy

- Closed candles only for automatic signal/candidate decisions.
- Baseline candidate threshold remains 60/100.
- Fast-entry threshold remains 80/100 and bypasses confirmation only.
- Stale/future market data blocks new entries; it does not force-close existing positions.
- Automatic candidates require fresh MT5 M1 and fresh MT5 quote; cloud fallback data remains manual-analysis only.
- Graph V6 remains the production visualization layer. Graph V7 predictive changes stay research/shadow until validated.
- Reversal close-and-flip V4 stays research/shadow until chronological robustness is demonstrated.
- Model promotion is controlled by numerical OOS/chronological acceptance, never by AI opinion alone.
- New news-source confidence weights cannot affect trading before freshness/relevance/deduplication tests.

## Final home procedure target

Preserve the existing private `config_private.bat`, download the current clean V5 package, place `config_private.bat` beside the runtime files, open MT5 on the intended DEMO account, and run `start_demo_bot.bat`. The launcher refuses mixed/incomplete runtime versions through compilation and `verify_v9_package.py`. Do not upload `config_private.bat` to GitHub or chat.
