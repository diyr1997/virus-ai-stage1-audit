"use strict";

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, Number(value)));
}

function gaussian(progress, center, width) {
  const z = (progress - center) / width;
  return Math.exp(-0.5 * z * z);
}

function buildTradePlanV6({ analysis, timeframe, mt5Quote = null, candles = [], lotCap = 0 }) {
  const price = Number(analysis?.price);
  if (!Number.isFinite(price) || price <= 0) throw new Error("FORECAST V6: invalid analysis price");

  const atr = Math.max(Number(analysis?.atr || 0), price * 0.00015);
  const side = String(analysis?.direction || "BUY").toUpperCase() === "SELL" ? "SELL" : "BUY";
  const direction = side === "BUY" ? 1 : -1;
  const brokerPrice = mt5Quote?.fresh ? (side === "BUY" ? Number(mt5Quote.ask) : Number(mt5Quote.bid)) : price;
  const basePrice = Number.isFinite(brokerPrice) && brokerPrice > 0 ? brokerPrice : price;

  const confirmation = basePrice + direction * atr * 0.18;
  const sl = basePrice - direction * atr * 0.72;
  const invalidation = sl;
  const tp1 = basePrice + direction * atr * 0.5;
  const tp2 = basePrice + direction * atr * 0.9;
  const tp3 = basePrice + direction * atr * 1.35;

  const recent = Array.isArray(candles) ? candles.slice(-30) : [];
  const deltas = [];
  for (let i = 1; i < recent.length; i++) {
    const previous = Number(recent[i - 1]?.close);
    const current = Number(recent[i]?.close);
    if (Number.isFinite(previous) && Number.isFinite(current)) deltas.push(current - previous);
  }

  const rmsDelta = deltas.length ? Math.sqrt(deltas.reduce((sum, delta) => sum + delta * delta, 0) / deltas.length) : atr * 0.15;
  const recentDirection = deltas.slice(-12);
  const alignment = recentDirection.length ? recentDirection.reduce((sum, delta) => sum + Math.sign(delta || 0) * direction, 0) / recentDirection.length : 0;
  const strengthFactor = clamp(Number(analysis?.strength || 0) / 100, 0, 1);
  const momentumFactor = clamp((direction * Number(analysis?.momentum || 0)) / Math.max(atr, 1e-9), -1, 1);
  const trendFactor = clamp((direction * Number(analysis?.trend || 0)) / Math.max(atr, 1e-9), -1, 1);
  const volatilityFactor = clamp(rmsDelta / Math.max(atr, 1e-9), 0, 1.5);
  const isWait = String(analysis?.action || "WAIT").toUpperCase() === "WAIT";
  const actionMultiplier = isWait ? 0.16 : 1;

  const driftAtr = clamp(0.24 + 0.39 * strengthFactor + 0.09 * momentumFactor + 0.07 * trendFactor + 0.05 * alignment, 0.18, 0.86);
  const pullbackScale = clamp(0.15 + 0.10 * volatilityFactor + 0.05 * (1 - strengthFactor), 0.13, 0.30);
  const horizon = timeframe === "H1" ? 60 : 15;
  const pointCount = 41;
  const forecast = [];

  for (let i = 0; i < pointCount; i++) {
    const progress = i / (pointCount - 1);
    const minute = progress * horizon;
    const eased = Math.pow(progress, 0.86);
    const directionalMove = direction * atr * driftAtr * eased * actionMultiplier;
    const firstPullback = -direction * atr * pullbackScale * gaussian(progress, 0.34, 0.06) * actionMultiplier;
    const firstContinuation = direction * atr * (0.055 + 0.035 * strengthFactor) * gaussian(progress, 0.49, 0.07) * actionMultiplier;
    const secondPullback = -direction * atr * pullbackScale * 0.70 * gaussian(progress, 0.67, 0.05) * actionMultiplier;
    const secondContinuation = direction * atr * (0.035 + 0.020 * strengthFactor) * gaussian(progress, 0.78, 0.06) * actionMultiplier;
    const microRhythm = atr * (0.012 + 0.018 * volatilityFactor) * Math.sin(Math.PI * progress) * Math.sin(progress * Math.PI * 8);
    const center = price + directionalMove + firstPullback + firstContinuation + secondPullback + secondContinuation + microRhythm;
    const uncertainty = atr * (0.05 + (0.13 + 0.09 * (1 - strengthFactor) + 0.06 * volatilityFactor) * Math.sqrt(progress));
    forecast.push({ minute, center, low: center - uncertainty, high: center + uncertainty });
  }

  function forecastAt(minute) {
    return forecast.reduce((best, point) => Math.abs(point.minute - minute) < Math.abs(best.minute - minute) ? point : best, forecast[0]);
  }

  return {
    entry: basePrice,
    confirmation,
    invalidation,
    sl,
    tp1,
    tp2,
    tp3,
    lotCap: Number(lotCap || 0),
    forecast,
    scenarioMarkers: [],
    horizon,
    forecastModel: "SCENARIO_V6_STABLE",
    p5: forecastAt(Math.min(5, horizon)),
    p10: forecastAt(Math.min(10, horizon)),
    p15: forecastAt(Math.min(15, horizon)),
  };
}

module.exports = { buildTradePlanV6 };
