#!/usr/bin/env python3
"""Root launcher so project modules are importable by the Trading School trainer."""

from trading_school.bootstrap_train_h1 import main


if __name__ == "__main__":
    main()
