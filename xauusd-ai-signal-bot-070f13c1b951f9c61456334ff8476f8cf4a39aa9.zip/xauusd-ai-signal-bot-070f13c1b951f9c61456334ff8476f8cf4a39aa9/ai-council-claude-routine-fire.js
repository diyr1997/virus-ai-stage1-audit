"use strict";

const crypto = require("crypto");

const DEFAULT_TASKS_DIR = ".ai-council-queue/claude-tasks";
const TASK_TRANSPORT = "AI_COUNCIL_CLAUDE_TASK_V1";
const ALLOWED_PHASES = new Set(["independent", "peer_review"]);
const ROUTINE_API_HOST = "api.anthropic.com";
const ROUTINE_PATH_RE = /^\/v1\/claude_code\/routines\/trig_[A-Za-z0-9_-]+\/fire$/;

function safeSegment(value) {
  return String(value || "")
    .trim()
    .replace(/[^A-Za-z0-9_.:-]+/g, "_")
    .slice(0, 160);
}

function configuredTasksDir() {
  return String(process.env.CLAUDE_BRIDGE_TASKS_DIR || DEFAULT_TASKS_DIR)
    .trim()
    .replace(/^\/+|\/+$/g, "");
}

function validateRoutineFireUrl(value = process.env.CLAUDE_ROUTINE_URL || "") {
  let parsed;
  try {
    parsed = new URL(String(value || "").trim());
  } catch {
    return { ok: false, reason: "INVALID_ROUTINE_URL" };
  }
  if (
    parsed.protocol !== "https:" ||
    parsed.hostname !== ROUTINE_API_HOST ||
    parsed.port ||
    parsed.username ||
    parsed.password ||
    parsed.search ||
    parsed.hash ||
    !ROUTINE_PATH_RE.test(parsed.pathname)
  ) {
    return { ok: false, reason: "UNTRUSTED_ROUTINE_URL" };
  }
  return { ok: true, url: parsed.toString() };
}

function routineAutofireConfigured() {
  return (
    /^1$/.test(String(process.env.CLAUDE_ROUTINE_AUTOFIRE_ENABLED || "").trim()) &&
    validateRoutineFireUrl().ok &&
    Boolean(String(process.env.CLAUDE_ROUTINE_TOKEN || "").trim())
  );
}

function initialRoutineFireStatus() {
  return routineAutofireConfigured() ? "PENDING" : "DISABLED";
}

function routineFireTimeoutMs() {
  const raw = Number(process.env.CLAUDE_ROUTINE_FIRE_TIMEOUT_MS || 8_000);
  if (!Number.isFinite(raw)) return 8_000;
  return Math.max(2_000, Math.min(30_000, Math.trunc(raw)));
}

function retryAfterDelayMs(value, nowMs = Date.now()) {
  const text = String(value || "").trim();
  if (!text) return 0;
  if (/^\d+$/.test(text)) {
    return Math.max(0, Math.min(600_000, Number(text) * 1000));
  }
  const when = Date.parse(text);
  if (!Number.isFinite(when)) return 0;
  return Math.max(0, Math.min(600_000, when - Number(nowMs || Date.now())));
}

function taskPayloadSha256(payload) {
  const canonical = {
    task_id: payload?.task_id,
    phase: payload?.phase,
    task: payload?.task,
    context_snapshot: payload?.context_snapshot,
    peer_responses: payload?.peer_responses,
  };
  return crypto.createHash("sha256").update(JSON.stringify(canonical), "utf8").digest("hex");
}

function validateRoutineFireTarget({
  taskId,
  phase,
  taskPath,
  rawTaskText,
  expectedTaskSha256 = null,
}) {
  const tasksDir = configuredTasksDir();
  const expectedPath = `${tasksDir}/${safeSegment(taskId)}__${safeSegment(phase)}.json`;

  if (!taskId || !ALLOWED_PHASES.has(String(phase || ""))) {
    return { ok: false, reason: "INVALID_TASK_ID_OR_PHASE" };
  }
  if (!taskPath || taskPath.startsWith("/") || taskPath.includes("\0") || taskPath.split("/").includes("..")) {
    return { ok: false, reason: "PATH_OUTSIDE_TASKS_DIR" };
  }
  if (!taskPath.startsWith(`${tasksDir}/`) || taskPath !== expectedPath) {
    return { ok: false, reason: "TASK_ID_PHASE_MISMATCH" };
  }

  let payload;
  try {
    payload = JSON.parse(String(rawTaskText || ""));
  } catch {
    return { ok: false, reason: "MALFORMED_TASK_JSON" };
  }

  if (String(payload?.transport || "") !== TASK_TRANSPORT) {
    return { ok: false, reason: "WRONG_TASK_TRANSPORT" };
  }
  if (String(payload?.task_id || "") !== String(taskId)) {
    return { ok: false, reason: "TASK_ID_CONTENT_MISMATCH" };
  }
  if (String(payload?.phase || "") !== String(phase)) {
    return { ok: false, reason: "PHASE_CONTENT_MISMATCH" };
  }

  if (expectedTaskSha256) {
    if (String(payload?.task_sha256 || "") !== String(expectedTaskSha256)) {
      return { ok: false, reason: "TASK_SHA_FIELD_MISMATCH" };
    }
    if (taskPayloadSha256(payload) !== String(expectedTaskSha256)) {
      return { ok: false, reason: "TASK_CONTENT_SHA_MISMATCH" };
    }
  }

  return { ok: true, payload };
}

function selectorText({ taskId, phase, taskPath, taskSha256 }) {
  return [
    `task_id=${String(taskId)}`,
    `phase=${String(phase)}`,
    `task_path=${String(taskPath)}`,
    `task_sha256=${String(taskSha256 || "")}`,
  ].join("\n");
}

function makeFireError(message, details = {}) {
  const error = new Error(String(message || "Claude Routine fire failed").slice(0, 240));
  Object.assign(error, details);
  return error;
}

function classifyRoutineFireFailure(error) {
  const statusCode = Number(error?.statusCode || 0);
  if (statusCode === 429) return { status: "FAILED_HTTP_SAFE", retryable: true };
  if (statusCode >= 500) return { status: "FAILED_HTTP_AMBIGUOUS", retryable: false };
  if (statusCode >= 400) return { status: "FAILED_VALIDATION", retryable: false };

  if (error?.name === "AbortError" || error?.code === "ABORT_ERR") {
    return { status: "FAILED_HTTP_AMBIGUOUS", retryable: false };
  }

  const networkCode = String(error?.cause?.code || error?.code || "").toUpperCase();
  if (["ENOTFOUND", "EAI_AGAIN"].includes(networkCode)) {
    return { status: "FAILED_HTTP_SAFE", retryable: true };
  }
  return { status: "FAILED_HTTP_AMBIGUOUS", retryable: false };
}

async function fireClaudeRoutine({
  taskId,
  phase,
  taskPath,
  taskSha256,
  fetchImpl = global.fetch,
}) {
  const urlCheck = validateRoutineFireUrl();
  const token = String(process.env.CLAUDE_ROUTINE_TOKEN || "").trim();
  if (!urlCheck.ok || !token) {
    throw makeFireError("Claude Routine configuration invalid", { statusCode: 400 });
  }
  if (typeof fetchImpl !== "function") {
    throw makeFireError("fetch is unavailable", { code: "NO_FETCH" });
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), routineFireTimeoutMs());
  if (typeof timeout.unref === "function") timeout.unref();

  let response;
  let raw = "";
  try {
    response = await fetchImpl(urlCheck.url, {
      method: "POST",
      headers: {
        authorization: `Bearer ${token}`,
        "anthropic-beta": "experimental-cc-routine-2026-04-01",
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
      },
      body: JSON.stringify({
        text: selectorText({ taskId, phase, taskPath, taskSha256 }),
      }),
      signal: controller.signal,
    });
    raw = await response.text();
  } finally {
    clearTimeout(timeout);
  }

  let data = null;
  if (raw) {
    try {
      data = JSON.parse(raw);
    } catch {
      data = null;
    }
  }

  if (!response.ok) {
    throw makeFireError(`Claude Routine API HTTP ${response.status}`, {
      statusCode: response.status,
      retryAfter: response.headers?.get?.("retry-after") || null,
    });
  }

  return {
    ok: true,
    status: response.status,
    sessionId: String(data?.claude_code_session_id || "").trim() || null,
    sessionUrl: String(data?.claude_code_session_url || "").trim() || null,
  };
}

module.exports = {
  DEFAULT_TASKS_DIR,
  TASK_TRANSPORT,
  ALLOWED_PHASES,
  ROUTINE_API_HOST,
  ROUTINE_PATH_RE,
  safeSegment,
  configuredTasksDir,
  validateRoutineFireUrl,
  routineAutofireConfigured,
  initialRoutineFireStatus,
  routineFireTimeoutMs,
  retryAfterDelayMs,
  taskPayloadSha256,
  validateRoutineFireTarget,
  selectorText,
  classifyRoutineFireFailure,
  fireClaudeRoutine,
};
