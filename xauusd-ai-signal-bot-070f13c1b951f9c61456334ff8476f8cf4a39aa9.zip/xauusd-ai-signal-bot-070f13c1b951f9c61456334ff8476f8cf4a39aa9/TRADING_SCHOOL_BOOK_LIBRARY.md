# Trading School — Curated Book Library

Updated: 2026-08-20

Purpose: keep a stable shortlist of widely respected, practically useful sources for the XAU/USD analytical system. Books do **not** directly control trades. Ideas must be converted into explicit features/rules and validated on historical XAU/USD data, out-of-sample, before any DEMO influence.

## Priority A — Paid books to acquire later

These are the highest-priority books for this project, selected for broad recognition, practical usefulness, and fit with M1/M5/M15/M30/H1, system design, risk, and model validation.

| Priority | Book | Edition/year | Main project use | Current price reference (USD, 2026-08-20) |
|---|---|---:|---|---:|
| A1 | Brian Shannon — *Technical Analysis Using Multiple Timeframes* | 2008 | Multi-timeframe structure, trend alignment, entries/exits, risk; especially M5/M15/M30/H1 | Exact current author-controlled print price to verify before purchase; no legitimate Kindle edition |
| A2 | Adam Grimes — *The Art and Science of Technical Analysis* | 2012 | Market structure, price action, trend/range regimes, statistically testable setups | eBook $59; hardcover about $98.95 |
| A3 | Al Brooks — *Trading Price Action Trends* | 2011 | M1/M5 price action, trends, breakouts, pullbacks, live impulse reading | eBook $24; hardcover about $76.99 |
| A4 | Al Brooks — *Trading Price Action Reversals* | 2011 | Reversal logic, failed trends, BUY↔SELL transition confirmation | starts about $46 |
| A5 | John J. Murphy — *Technical Analysis of the Financial Markets* | 1999 updated edition | Core TA reference: trends, patterns, indicators, intermarket context, futures/commodities | eBook $67.99; hardcover about $120 |
| A6 | Ernest P. Chan — *Quantitative Trading*, Revised 2nd Ed. | 2026 | Fresh quant/systematic framework, research workflow, strategy design | eBook starts $17 |
| A7 | Ernest P. Chan — *Algorithmic Trading: Winning Strategies and Their Rationale* | 2013 | Momentum/mean reversion, implementation logic, practical algo examples | eBook $47; hardcover about $79 |
| A8 | Perry J. Kaufman — *Trading Systems and Methods*, 6th Ed. | 2019 | Indicators, systems, algorithms, robustness, systematic trading methods | eBook starts $79; hardcover about $132 |
| A9 | Marcos López de Prado — *Advances in Financial Machine Learning* | 2018 | Financial ML, labeling, validation, leakage/overfitting control | eBook $33 |
| A10 | Stefan Jansen — *Machine Learning for Algorithmic Trading*, 2nd Ed. | 2020 | Python ML pipeline, predictive signals, feature research, backtesting | eBook about $64.79; hardcover about $79.99; paperback about $89.99 |
| A11 | Robert Pardo — *The Evaluation and Optimization of Trading Strategies*, 2nd Ed. | 2008 | Walk-forward analysis, optimization, robustness and strategy validation | starts about $66 |
| A12 | Thomas Bulkowski — *Encyclopedia of Chart Patterns*, 3rd Ed. | 2021 | Statistical chart-pattern reference; mainly M15/M30/H1 | eBook $105; hardcover about $131 |
| A13 | Alexander Elder — *The New Trading for a Living* | 2014 | Risk control, trade management, systems, disciplined execution | eBook $50 |

### Optional next-tier paid books

- Andreas F. Clenow — *Following the Trend*, 2nd Ed. (2023): systematic trend following; starts about $45.
- Jack D. Schwager & Mark Etzkorn — *A Complete Guide to the Futures Market*, 2nd Ed. (2017): broad futures/technical/system reference; starts about $111.
- Michael W. Covel — *Trend Following*, 5th Ed. (2017): trend-following philosophy and system thinking; starts about $27.
- Brian Shannon — *Maximum Trading Gains with Anchored VWAP* (2023): AVWAP for entries/exits and support/resistance; eBook about $39.

## Priority F — Legal free/open materials to use now

| Priority | Resource | Year/update | Main use | Cost |
|---|---|---:|---|---:|
| F1 | QuantInsti — *A Rough and Ready Guide to Algorithmic Trading*, 2026 Edition | 2026 | Current algo/quant overview, AI/ML/LLMs, data, momentum/mean reversion, sizing, strategy decay | FREE |
| F2 | Zerodha Varsity — *Technical Analysis* module + downloadable PDF | current | Candles, timeframes, S/R, RSI, MACD, Bollinger, ADX, Dow Theory, risk/reward | FREE |
| F3 | Hyndman & Athanasopoulos — *Forecasting: Principles and Practice*, 3rd Ed. | 2021, online updated 2026 | Time-series forecasting, model evaluation, features, disciplined forecasting workflow | FREE online |
| F4 | CME Group — *A Trader’s Guide to Futures* + metals education | current | Futures mechanics, COMEX context, execution/margin understanding for gold | FREE |
| F5 | MetaQuotes — *MQL5 Programming for Traders* | current PDF | MT5 execution/EA engineering for Bot #2; not a BUY/SELL knowledge source | FREE |
| F6 | López de Prado et al. — selected SSRN papers on backtest overfitting | 2013–2014 and later research | Prevent false discoveries and backtest overfitting | FREE to read/download where permitted by source |

## How the library should be used

### Analytical Bot #1
- Price Action School: Brooks + Grimes.
- Multi-Timeframe School: Shannon + Murphy.
- Pattern School: Bulkowski.
- System/Quant School: Chan + Kaufman.
- Validation School: Pardo + López de Prado.
- ML School: López de Prado + Jansen + Hyndman/Athanasopoulos.
- Gold/Futures context: CME.

### MT5 DEMO Worker #2
- Do not train its trade direction directly from books.
- Use only validated outputs/rules from Bot #1.
- MQL5/MT5 materials are for execution reliability, position management, logging and safeguards.

## Acceptance rule for any book-derived idea

A book-derived idea is only eligible for DEMO influence after:
1. translating it into explicit measurable features/rules;
2. testing it on XAU/USD history;
3. out-of-sample / walk-forward validation;
4. measuring win rate, profit factor, drawdown, false entries, trade count and stability across regimes;
5. comparing champion vs challenger;
6. activating only if improvement is robust and not due to overfitting.

## Copyright rule

Do not add pirated copies. Use legal purchases, author/publisher-provided samples, open textbooks, and public research. Store extracted project rules and summaries, not redistributed copyrighted full texts.
