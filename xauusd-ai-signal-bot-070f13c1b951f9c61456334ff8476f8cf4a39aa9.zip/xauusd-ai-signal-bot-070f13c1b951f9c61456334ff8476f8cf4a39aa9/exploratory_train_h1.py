#!/usr/bin/env python3
import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.metrics import accuracy_score, mean_absolute_error

from ai_predict_h1 import add_all_features, load_bundle
from trading_school.features_v1 import SCHOOL_FEATURES

TARGET_HORIZON_BARS = 60
# Largest causal feature context is H1 x 20 bars = 1,200 M1 bars.
# Purge must cover both that lookback and the 60-minute forward label horizon.
MAX_FEATURE_LOOKBACK_BARS = 1200
PURGE_BARS = TARGET_HORIZON_BARS + MAX_FEATURE_LOOKBACK_BARS


def clean_input(path: str) -> pd.DataFrame:
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(raw, list):
        raise RuntimeError("Candles payload must be a list")
    frame = pd.DataFrame(raw)
    required = ["timestamp", "open", "high", "low", "close"]
    missing = [c for c in required if c not in frame.columns]
    if missing:
        raise RuntimeError("Missing candle fields: " + ", ".join(missing))
    for col in required + (["volume"] if "volume" in frame.columns else []):
        frame[col] = pd.to_numeric(frame[col], errors="coerce")
    frame = (
        frame.dropna(subset=required)
        .sort_values("timestamp")
        .drop_duplicates("timestamp")
        .reset_index(drop=True)
    )
    if len(frame) < 1000:
        raise RuntimeError(f"Need >=1000 verified M1 candles for exploratory training, got {len(frame)}")
    frame["timestamp"] = frame["timestamp"].astype("int64")
    return frame


def build_dataset(frame: pd.DataFrame, features: list[str]) -> pd.DataFrame:
    data = add_all_features(frame.copy())
    data["future_close_60"] = data["close"].shift(-TARGET_HORIZON_BARS)
    data["future_ts_60"] = data["timestamp"].shift(-TARGET_HORIZON_BARS)
    data["future_delta_min"] = (data["future_ts_60"] - data["timestamp"]) / 60000.0
    data["target_return_bps"] = (data["future_close_60"] / data["close"] - 1.0) * 10000.0
    data["target_direction"] = np.where(data["target_return_bps"] >= 0.0, 1, -1)
    required = list(features) + ["target_return_bps", "target_direction", "future_delta_min"]
    data = data.replace([np.inf, -np.inf], np.nan).dropna(subset=required)
    data = data[(data["future_delta_min"] >= 55.0) & (data["future_delta_min"] <= 70.0)]
    data = data.reset_index(drop=True)
    if len(data) < 700:
        raise RuntimeError(f"Only {len(data)} usable labeled rows after feature engineering")
    return data


def metrics(bundle, frame: pd.DataFrame, features: list[str]) -> dict:
    x = frame[features].to_numpy(dtype=np.float32)
    y_dir = frame["target_direction"].to_numpy(dtype=np.int8)
    y_ret = frame["target_return_bps"].to_numpy(dtype=np.float32)
    dmodel = bundle["direction_models"][60]
    rmodel = bundle["return_models"][60]
    threshold = float(bundle["thresholds"][60].get("direction_confidence", 0.60))
    pred = dmodel.predict(x).astype(int)
    probs = dmodel.predict_proba(x)
    conf = probs.max(axis=1)
    high = conf >= threshold
    ret_pred = rmodel.predict(x).astype(float)
    return {
        "direction_accuracy": float(accuracy_score(y_dir, pred)),
        "high_conf_accuracy": float(accuracy_score(y_dir[high], pred[high])) if high.any() else None,
        "high_conf_coverage": float(high.mean()),
        "return_mae_bps": float(mean_absolute_error(y_ret, ret_pred)),
        "samples": int(len(frame)),
        "high_conf_samples": int(high.sum()),
        "predictions": pred,
        "truth": y_dir,
    }


def block_bootstrap_accuracy_ci(
    truth: np.ndarray, pred: np.ndarray, seed: int, rounds: int = 400, block_size: int = 60
) -> list[float]:
    """Exploratory uncertainty only; never used as a promotion criterion."""
    n = len(truth)
    if n < max(200, block_size * 3):
        return [None, None]
    rng = np.random.default_rng(seed)
    scores = []
    starts_max = max(1, n - block_size + 1)
    blocks_needed = int(np.ceil(n / block_size))
    for _ in range(rounds):
        pieces = []
        for _ in range(blocks_needed):
            start = int(rng.integers(0, starts_max))
            pieces.append(np.arange(start, min(start + block_size, n)))
        idx = np.concatenate(pieces)[:n]
        scores.append(float((truth[idx] == pred[idx]).mean()))
    lo, hi = np.quantile(np.asarray(scores), [0.025, 0.975])
    return [float(lo), float(hi)]


def strip_arrays(result: dict) -> dict:
    return {k: v for k, v in result.items() if k not in {"predictions", "truth"}}


def run(champion_path: str, candles_path: str, trial: int = 0) -> dict:
    if PURGE_BARS < TARGET_HORIZON_BARS + MAX_FEATURE_LOOKBACK_BARS:
        raise RuntimeError("PURGE_BARS is smaller than target horizon + max feature lookback")

    champion = load_bundle(champion_path)
    champion_features = list(champion.get("features", []))
    if not champion_features:
        raise RuntimeError("Champion bundle has no feature list")
    challenger_features = champion_features + [f for f in SCHOOL_FEATURES if f not in champion_features]

    source = clean_input(candles_path)
    data = build_dataset(source, challenger_features)

    raw_split = int(len(data) * 0.70)
    train_end = raw_split - PURGE_BARS
    valid_start = raw_split
    if train_end < 450 or len(data) - valid_start < 200:
        raise RuntimeError(
            f"Insufficient purged chronological split: train={train_end}, valid={len(data)-valid_start}, purge={PURGE_BARS}"
        )
    train_df = data.iloc[:train_end].copy()
    valid_df = data.iloc[valid_start:].copy()

    seed = 4200 + int(trial)
    min_leaf = max(10, min(40, len(train_df) // 80))
    max_leaf_nodes = 15 if len(train_df) < 2500 else 31
    learning_rate = [0.035, 0.045, 0.055, 0.065][int(trial) % 4]
    max_iter = [100, 130, 160, 190][int(trial) % 4]

    x_train = train_df[challenger_features].to_numpy(dtype=np.float32)
    y_train_dir = train_df["target_direction"].to_numpy(dtype=np.int8)
    y_train_ret = train_df["target_return_bps"].to_numpy(dtype=np.float32)

    classifier = HistGradientBoostingClassifier(
        learning_rate=learning_rate,
        max_iter=max_iter,
        max_leaf_nodes=max_leaf_nodes,
        min_samples_leaf=min_leaf,
        l2_regularization=2.0,
        random_state=seed,
    )
    regressor = HistGradientBoostingRegressor(
        learning_rate=learning_rate,
        max_iter=max_iter,
        max_leaf_nodes=max_leaf_nodes,
        min_samples_leaf=min_leaf,
        l2_regularization=2.0,
        loss="absolute_error",
        random_state=seed,
    )
    classifier.fit(x_train, y_train_dir)
    regressor.fit(x_train, y_train_ret)

    challenger = dict(champion)
    challenger["direction_models"] = dict(champion["direction_models"])
    challenger["return_models"] = dict(champion["return_models"])
    challenger["direction_models"][60] = classifier
    challenger["return_models"][60] = regressor
    challenger["features"] = challenger_features

    champion_result = metrics(champion, valid_df, champion_features)
    challenger_result = metrics(challenger, valid_df, challenger_features)
    challenger_ci = block_bootstrap_accuracy_ci(
        challenger_result["truth"], challenger_result["predictions"], seed
    )
    champion_ci = block_bootstrap_accuracy_ci(
        champion_result["truth"], champion_result["predictions"], seed + 1
    )

    first_ts = int(source.iloc[0]["timestamp"])
    last_ts = int(source.iloc[-1]["timestamp"])
    trading_days = int(pd.to_datetime(source["timestamp"], unit="ms", utc=True).dt.date.nunique())
    now = datetime.now(timezone.utc)

    return {
        "ok": True,
        "experiment_tier": "EXPLORATORY",
        "promotion_eligible": False,
        "promoted": False,
        "trial": int(trial),
        "profile": {
            "name": f"small_data_exploratory_t{int(trial)%4}",
            "learning_rate": learning_rate,
            "max_iter": max_iter,
            "max_leaf_nodes": max_leaf_nodes,
            "min_samples_leaf": min_leaf,
            "purge_rows": PURGE_BARS,
            "target_horizon_bars": TARGET_HORIZON_BARS,
            "max_feature_lookback_bars": MAX_FEATURE_LOOKBACK_BARS,
        },
        "trained_at": now.isoformat(),
        "champion_version": champion.get("version", "unknown"),
        "source_rows": int(len(source)),
        "usable_rows": int(len(data)),
        "trading_days": trading_days,
        "train_rows": int(len(train_df)),
        "validation_rows": int(len(valid_df)),
        "first_timestamp": first_ts,
        "last_timestamp": last_ts,
        "champion_metrics": strip_arrays(champion_result),
        "challenger_metrics": strip_arrays(challenger_result),
        "champion_accuracy_ci95_block_bootstrap": champion_ci,
        "challenger_accuracy_ci95_block_bootstrap": challenger_ci,
        "direction_accuracy_gain": float(
            challenger_result["direction_accuracy"] - champion_result["direction_accuracy"]
        ),
        "promotion_block_reason": "exploratory_small_data_requires_15000_rows_and_10_trading_days",
        "validation_protocol": "chronological_70_30_with_1260_row_purge_plus_block_bootstrap_ci_exploratory_only",
        "school_features_added": [f for f in challenger_features if f not in champion_features],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--champion", required=True)
    parser.add_argument("--candles", required=True)
    parser.add_argument("--trial", type=int, default=0)
    args = parser.parse_args()
    try:
        result = run(args.champion, args.candles, args.trial)
        print(json.dumps(result, ensure_ascii=False, allow_nan=False))
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, allow_nan=False))
        raise


if __name__ == "__main__":
    main()
