"use strict";

const crypto = require("crypto");
const TelegramBot = require("node-telegram-bot-api");

const TTL_MS = Math.max(5_000, Number(process.env.AUTOSIGNAL_SEND_DEDUP_MS || 30_000));
const recent = new Map();

const VISIBLE_COMMANDS = new Set([
  "start",
  "signal",
  "news",
  "stats",
  "demo_stats",
  "risk",
  "autopilot",
]);

function cleanup(now) {
  for (const [key, expires] of recent) {
    if (expires <= now) recent.delete(key);
  }
}

function digest(parts) {
  const hash = crypto.createHash("sha256");
  for (const part of parts) {
    if (Buffer.isBuffer(part)) hash.update(part);
    else hash.update(String(part ?? ""));
    hash.update("\0");
  }
  return hash.digest("hex");
}

function isAutoSignal(text) {
  return String(text || "").includes("🚨 АВТОСИГНАЛ");
}

function claim(key) {
  const now = Date.now();
  cleanup(now);
  if (recent.has(key)) return false;
  recent.set(key, now + TTL_MS);
  return true;
}

function duplicateResult(chatId) {
  return Promise.resolve({
    message_id: 0,
    chat: { id: chatId },
    date: Math.floor(Date.now() / 1000),
    text: "AUTOSIGNAL_DUPLICATE_SUPPRESSED",
  });
}

const proto = TelegramBot.prototype;

if (!proto.__xauAutoSignalDedupInstalled) {
  const originalSendMessage = proto.sendMessage;
  const originalSendPhoto = proto.sendPhoto;
  const originalSetMyCommands = proto.setMyCommands;

  proto.sendMessage = function patchedSendMessage(chatId, text, options) {
    if (isAutoSignal(text)) {
      const key = digest(["message", chatId, text]);
      if (!claim(key)) {
        console.warn(`TELEGRAM DEDUP | suppressed duplicate autosignal text chat=${chatId}`);
        return duplicateResult(chatId);
      }
    }
    return originalSendMessage.call(this, chatId, text, options);
  };

  proto.sendPhoto = function patchedSendPhoto(chatId, photo, options, fileOptions) {
    const caption = options && options.caption;
    if (isAutoSignal(caption)) {
      const photoIdentity = Buffer.isBuffer(photo)
        ? photo
        : String(photo || "");
      const key = digest(["photo", chatId, caption, photoIdentity]);
      if (!claim(key)) {
        console.warn(`TELEGRAM DEDUP | suppressed duplicate autosignal photo chat=${chatId}`);
        return duplicateResult(chatId);
      }
    }
    return originalSendPhoto.call(this, chatId, photo, options, fileOptions);
  };

  if (typeof originalSetMyCommands === "function") {
    proto.setMyCommands = function patchedSetMyCommands(commands, options) {
      const input = Array.isArray(commands) ? commands : [];
      const compact = input.filter((item) => VISIBLE_COMMANDS.has(String(item?.command || "")));
      console.log(
        `TELEGRAM MENU | visible commands=${compact.map((item) => `/${item.command}`).join(",")}; hidden handlers remain backward-compatible`
      );
      return originalSetMyCommands.call(this, compact, options);
    };
  }

  Object.defineProperty(proto, "__xauAutoSignalDedupInstalled", {
    value: true,
    enumerable: false,
    configurable: false,
  });

  console.log(`TELEGRAM DEDUP | autosignal guard enabled ttl_ms=${TTL_MS}`);
}
