"use strict";

/**
 * Regime Router V1 SHADOW audit.
 *
 * Splits the current active H1 champion's held-out XAU/USD performance into
 * causal market regimes and evaluates simple route hypotheses. It NEVER
 * promotes a model and NEVER changes live signals/trading rules.
 */

const fs = require("fs");
const os = require("os");
const path = require("path");
const { promisify } = require("util");
const { execFile } = require("child_process");
const { Pool } = require("pg");
const { resolveActiveH1ModelPath } = require("./model-registry");

const execFileAsync = promisify(execFile);
const DATABASE_URL = String(process.env.DATABASE_URL || process.env.DATABASE_PUBLIC_URL || "").trim();
const PYTHON = process.env.PYTHON_BIN || path.join(__dirname, ".venv", "bin", "python");
const BUILTIN_MODEL = path.join(__dirname, "xauusd_ai_final_h1_full_period.joblib");
const RUN_KEY = "TRADING_SCHOOL_REGIME_ROUTER_V1B_SHADOW_2026_08_20";
const FOLLOWUP_KEY = "TRADING_SCHOOL_REVERSAL_REGIME_ROBUSTNESS_V1_2026_08_20";

const pool = DATABASE_URL ? new Pool({ connectionString: DATABASE_URL, max: 1, idleTimeoutMillis: 30_000 }) : null;

async function ensureSchema() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS trading_school_bootstrap_runs (
      run_key VARCHAR(100) PRIMARY KEY,
      status VARCHAR(24) NOT NULL,
      started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      finished_at TIMESTAMPTZ,
      report JSONB NOT NULL DEFAULT '{}'::jsonb,
      error TEXT
    )
  `);
}

async function claim() {
  const r = await pool.query(
    `INSERT INTO trading_school_bootstrap_runs(run_key,status)
     VALUES($1,'RUNNING') ON CONFLICT(run_key) DO NOTHING RETURNING run_key`,
    [RUN_KEY]
  );
  return r.rowCount === 1;
}

async function finish(status, report = {}, error = null) {
  await pool.query(
    `UPDATE trading_school_bootstrap_runs
     SET status=$2,finished_at=NOW(),report=$3::jsonb,error=$4
     WHERE run_key=$1`,
    [RUN_KEY, status, JSON.stringify(report), error]
  );
}

async function loadStoredReport() {
  const r = await pool.query(
    `SELECT report FROM trading_school_bootstrap_runs
     WHERE run_key=$1 AND status='SUCCESS' LIMIT 1`,
    [RUN_KEY]
  );
  return r.rows[0]?.report || null;
}

async function auditReversalRobustness(reportInput = null) {
  const existing = await pool.query(
    `SELECT status FROM trading_school_bootstrap_runs WHERE run_key=$1 LIMIT 1`,
    [FOLLOWUP_KEY]
  );
  if (existing.rows[0]?.status === "SUCCESS") {
    console.log("🧭 REVERSAL ROBUSTNESS V1: already completed");
    return;
  }

  const report = reportInput || await loadStoredReport();
  if (!report?.blocks?.length) {
    console.log("🧭 REVERSAL ROBUSTNESS V1: no completed Regime Router report yet");
    return;
  }

  const overall = report.by_regime?.REVERSAL_ATTEMPT || {};
  const blocks = report.blocks.map((block) => {
    const m = block?.regimes?.REVERSAL_ATTEMPT || {};
    const champion = Number.isFinite(Number(m.direction_accuracy)) ? Number(m.direction_accuracy) : null;
    const route = Number.isFinite(Number(m.route_direction_accuracy)) ? Number(m.route_direction_accuracy) : null;
    return {
      block: block.block,
      samples: Number(m.samples || 0),
      champion,
      route,
      gain: champion !== null && route !== null ? route - champion : null,
    };
  });

  const valid = blocks.filter((b) => b.samples >= 10 && b.gain !== null);
  const positiveBlocks = valid.filter((b) => b.gain > 0).length;
  const worstGain = valid.length ? Math.min(...valid.map((b) => b.gain)) : null;
  const totalSamples = Number(overall.samples || 0);
  const championOverall = Number(overall.direction_accuracy);
  const routeOverall = Number(overall.route_direction_accuracy);
  const overallGain = Number.isFinite(championOverall) && Number.isFinite(routeOverall)
    ? routeOverall - championOverall
    : null;

  // This is NOT a promotion gate. It only decides whether the reversal idea is
  // worth a stricter next SHADOW experiment. Small samples and one lucky block
  // must not be enough.
  const eligibleForNextShadow = Boolean(
    totalSamples >= 60 &&
    valid.length >= 2 &&
    positiveBlocks >= 2 &&
    overallGain !== null && overallGain >= 0.05 &&
    worstGain !== null && worstGain >= -0.05
  );

  const robustness = {
    shadow_only: true,
    promoted: false,
    active_model_changed: false,
    regime: "REVERSAL_ATTEMPT",
    total_samples: totalSamples,
    champion_direction_accuracy: Number.isFinite(championOverall) ? championOverall : null,
    route_direction_accuracy: Number.isFinite(routeOverall) ? routeOverall : null,
    overall_gain: overallGain,
    blocks,
    positive_blocks: positiveBlocks,
    worst_block_gain: worstGain,
    eligible_for_next_shadow: eligibleForNextShadow,
    note: eligibleForNextShadow
      ? "Promising enough for a stricter reversal-only shadow test; still not connected to trading."
      : "Not robust enough across chronological blocks; do not connect to trading.",
  };

  await pool.query(
    `INSERT INTO trading_school_bootstrap_runs(run_key,status,finished_at,report,error)
     VALUES($1,'SUCCESS',NOW(),$2::jsonb,NULL)
     ON CONFLICT(run_key) DO UPDATE SET
       status='SUCCESS',finished_at=NOW(),report=EXCLUDED.report,error=NULL`,
    [FOLLOWUP_KEY, JSON.stringify(robustness)]
  );

  console.log(`🧭 REVERSAL ROBUSTNESS V1 COMPLETE | ${JSON.stringify(robustness)}`);
}

async function exportCandles() {
  const r = await pool.query(`
    SELECT (EXTRACT(EPOCH FROM candle_time)*1000)::bigint AS timestamp,
           open::float8,high::float8,low::float8,close::float8,volume::float8
    FROM xauusd_candles
    WHERE timeframe='M1'
    ORDER BY candle_time DESC
    LIMIT 7000
  `);
  return r.rows.reverse();
}

async function run() {
  if (!pool) {
    console.warn("🧭 REGIME ROUTER V1B: PostgreSQL unavailable; skipped");
    return;
  }
  await ensureSchema();
  if (!(await claim())) {
    console.log("🧭 REGIME ROUTER V1B: shadow audit already completed/claimed");
    await auditReversalRobustness();
    return;
  }

  const candles = await exportCandles();
  if (candles.length < 5000) {
    await finish("FAILED", { shadow_only: true, source_rows: candles.length }, "Need >=5000 M1 candles");
    return;
  }

  const modelPath = await resolveActiveH1ModelPath(BUILTIN_MODEL);
  const candlesPath = path.join(os.tmpdir(), `regime_router_${Date.now()}.json`);
  fs.writeFileSync(candlesPath, JSON.stringify(candles), "utf8");
  console.log(`🧭 REGIME ROUTER V1B START | candles=${candles.length} | shadow-only`);

  try {
    // Run as a module so repository root stays on sys.path and ai_predict_h1 is importable.
    const { stdout, stderr } = await execFileAsync(
      PYTHON,
      ["-m", "trading_school.regime_router_v1", "--model", modelPath, "--candles", candlesPath],
      { timeout: 20 * 60_000, maxBuffer: 8 * 1024 * 1024, cwd: __dirname }
    );
    if (stderr?.trim()) console.log("🧭 REGIME ROUTER stderr:", stderr.trim().slice(0, 1200));
    const line = String(stdout || "").trim().split(/\r?\n/).filter(Boolean).pop();
    const report = JSON.parse(line || "{}");
    if (!report.ok) throw new Error(report.error || "Regime Router evaluation failed");

    report.shadow_only = true;
    report.promoted = false;
    report.active_model_changed = false;
    await finish("SUCCESS", report);

    const compact = Object.entries(report.by_regime || {}).map(([regime, m]) => ({
      regime,
      n: m.samples,
      share: m.share,
      champion: m.direction_accuracy,
      signal: m.signal_direction_accuracy,
      signalCoverage: m.signal_coverage,
      route: m.route_direction_accuracy,
      routeCoverage: m.route_coverage,
    }));
    console.log(`🧭 REGIME ROUTER V1B COMPLETE | overall=${JSON.stringify(report.overall)} | regimes=${JSON.stringify(compact)}`);
    console.log(`🧭 REGIME ROUTER ROUTE RANKING | ${JSON.stringify(report.ranked_route_hypotheses || [])}`);
    await auditReversalRobustness(report);
  } catch (error) {
    const message = String(error?.message || error).slice(0, 4000);
    await finish("FAILED", { shadow_only: true, promoted: false, active_model_changed: false }, message).catch(() => {});
    console.error("❌ REGIME ROUTER V1B:", message);
  } finally {
    fs.unlink(candlesPath, () => {});
  }
}

console.log("🧭 REGIME ROUTER V1B shadow audit armed; starts in 35 sec");
setTimeout(() => run().catch((e) => console.error("❌ REGIME ROUTER V1B:", e)), 35_000).unref();

module.exports = { run, auditReversalRobustness };
