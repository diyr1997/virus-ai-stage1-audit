"""The sealed evaluation block: rows training is never allowed to see.

Everything else in the pipeline already guards against leakage *inside* one
training run -- the chronological split, the 60-bar purge, the two boundary
asserts. None of that helps with the slower failure, where a model is tuned
again and again against the same validation window until the reported number
describes the tuning rather than the market.

The defence is a block of history that no training run may touch, scored once
at the end. Its boundaries live in final_holdout.json as absolute UTC
timestamps, under version control, so widening the training set is a reviewable
commit and not a side effect of new candles arriving.

Two details carry the guarantee:

* Membership is decided by ``future_ts_60``, the real timestamp of the sixtieth
  future bar, which _build_dataset has already validated to sit 55-70 minutes
  ahead. A row is trainable only when its label has fully resolved before the
  sealed block opens. Deriving that boundary from wall-clock arithmetic instead
  (``timestamp + 60 minutes``) would under-purge across weekends and gaps,
  where an hour of clock time can contain three bars.
* The embargo widens the gap beyond the label horizon, so short-lived
  autocorrelation either side of the boundary cannot carry information across
  it. Rows falling in the embargo are discarded, never reassigned.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

import pandas as pd

DEFAULT_PATH = Path(__file__).with_name("final_holdout.json")

MINUTE_MS = 60_000


@dataclass(frozen=True)
class HoldoutBoundary:
    label: str
    start_ms: int
    end_ms: int
    embargo_minutes: int

    @property
    def embargo_ms(self) -> int:
        return int(self.embargo_minutes) * MINUTE_MS

    def describe(self) -> dict:
        return {
            "label": self.label,
            "holdout_start_ms": int(self.start_ms),
            "holdout_end_ms": int(self.end_ms),
            "embargo_minutes": int(self.embargo_minutes),
        }


def _parse_utc_ms(value: str, field: str) -> int:
    text = str(value or "").strip()
    if not text:
        raise RuntimeError(f"final holdout config: {field} is empty")
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError as exc:
        raise RuntimeError(f"final holdout config: {field} is not ISO-8601: {value}") from exc
    if parsed.tzinfo is None:
        raise RuntimeError(f"final holdout config: {field} needs an explicit UTC offset")
    return int(parsed.timestamp() * 1000)


def load_boundary(path: str | Path = DEFAULT_PATH) -> HoldoutBoundary:
    """Read the pinned boundary. Fail-closed: a missing or broken config raises.

    Silently training on everything because a config could not be read is the
    exact accident this module exists to prevent.
    """
    config_path = Path(path)
    if not config_path.exists():
        raise RuntimeError(f"final holdout config missing: {config_path}")

    try:
        raw = json.loads(config_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"final holdout config is not valid JSON: {exc}") from exc

    start_ms = _parse_utc_ms(raw.get("holdout_start_utc"), "holdout_start_utc")
    end_ms = _parse_utc_ms(raw.get("holdout_end_utc"), "holdout_end_utc")
    if end_ms <= start_ms:
        raise RuntimeError("final holdout config: holdout_end_utc must follow holdout_start_utc")

    embargo = raw.get("embargo_minutes", 0)
    try:
        embargo_minutes = int(embargo)
    except (TypeError, ValueError) as exc:
        raise RuntimeError(f"final holdout config: embargo_minutes must be an integer, got {embargo!r}") from exc
    if embargo_minutes < 0:
        raise RuntimeError("final holdout config: embargo_minutes cannot be negative")

    label = str(raw.get("label") or "").strip()
    if not label:
        raise RuntimeError("final holdout config: label is required")

    return HoldoutBoundary(
        label=label,
        start_ms=start_ms,
        end_ms=end_ms,
        embargo_minutes=embargo_minutes,
    )


def split_off_holdout(
    data: pd.DataFrame,
    boundary: HoldoutBoundary,
    *,
    time_col: str = "timestamp",
    label_end_col: str = "future_ts_60",
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return ``(trainable, holdout)``.

    A row is trainable when its label resolves a full embargo before the sealed
    block opens, or when the row itself starts a full embargo after it closes.
    Anything in between is dropped rather than handed to either side.
    """
    for column in (time_col, label_end_col):
        if column not in data.columns:
            raise RuntimeError(f"final holdout split needs column {column!r}")

    ts = pd.to_numeric(data[time_col], errors="raise").astype("int64")
    label_end = pd.to_numeric(data[label_end_col], errors="raise").astype("int64")

    opens = int(boundary.start_ms)
    closes = int(boundary.end_ms)
    embargo = boundary.embargo_ms

    before = label_end < (opens - embargo)
    after = ts > (closes + embargo)
    inside = (ts >= opens) & (ts <= closes)

    trainable = data.loc[before | after].copy()
    holdout = data.loc[inside].copy()
    return trainable, holdout


def assert_sealed(
    trainable: pd.DataFrame,
    holdout: pd.DataFrame,
    boundary: HoldoutBoundary,
    *,
    time_col: str = "timestamp",
    label_end_col: str = "future_ts_60",
) -> dict:
    """Prove the split actually holds, and raise loudly when it does not."""
    opens = int(boundary.start_ms)
    closes = int(boundary.end_ms)

    if not holdout.empty:
        holdout_ts = pd.to_numeric(holdout[time_col], errors="raise").astype("int64")
        if int(holdout_ts.min()) < opens or int(holdout_ts.max()) > closes:
            raise RuntimeError("holdout rows fall outside the sealed window")

    if not trainable.empty:
        train_ts = pd.to_numeric(trainable[time_col], errors="raise").astype("int64")
        train_label_end = pd.to_numeric(trainable[label_end_col], errors="raise").astype("int64")

        entered = train_ts[(train_ts >= opens) & (train_ts <= closes)]
        if len(entered):
            raise RuntimeError(
                f"{len(entered)} training rows start inside the sealed holdout window"
            )

        # A label that resolves inside the window leaks the answer even though
        # the row itself sits before it.
        reaching = train_label_end[
            (train_label_end >= opens) & (train_ts < opens)
        ]
        if len(reaching):
            raise RuntimeError(
                f"{len(reaching)} training labels resolve inside the sealed holdout window"
            )

        overlap = set(train_ts.tolist()) & set(
            pd.to_numeric(holdout[time_col], errors="raise").astype("int64").tolist()
            if not holdout.empty
            else []
        )
        if overlap:
            raise RuntimeError(f"{len(overlap)} rows appear in both training and holdout")

    return {
        "holdout_label": boundary.label,
        "holdout_rows": int(len(holdout)),
        "trainable_rows": int(len(trainable)),
        "embargo_minutes": int(boundary.embargo_minutes),
        "sealed": True,
    }


def seal(
    data: pd.DataFrame,
    *,
    path: str | Path = DEFAULT_PATH,
    time_col: str = "timestamp",
    label_end_col: str = "future_ts_60",
) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    """Load the boundary, split, verify, and hand back both sides plus a report."""
    boundary = load_boundary(path)
    trainable, holdout = split_off_holdout(
        data, boundary, time_col=time_col, label_end_col=label_end_col
    )
    report = assert_sealed(
        trainable, holdout, boundary, time_col=time_col, label_end_col=label_end_col
    )
    report.update(boundary.describe())
    report["dropped_to_embargo"] = int(len(data) - len(trainable) - len(holdout))
    return trainable, holdout, report
