"use strict";

/*
  Central fail-closed guard for automatic trade-candidate writes.
  Loaded after news-xau-bootstrap and before index.js.

  saveTradeCandidate() parameter contract in index.js:
    0 analysis_id
    1 expires_at
    2 timeframe
    3 side
    4 strength
    5 confirmation_price
    6 invalidation_price
    7 sl
    8 tp1
    9 tp2
   10 tp3
   11 payload

  Guarantees:
  - cloud/Dukascopy fallback may serve manual analysis but cannot create a DEMO candidate;
  - a new candidate requires fresh MT5 M1 + fresh MT5 quote;
  - high-impact releases temporarily block new candidates;
  - old fixed-position metadata is stripped from candidate payloads;
  - M1/M5 candidates are forcibly short-lived without touching TP prices;
  - news impact decays with age; PREVIEW remains informational.
*/

const { Pool } = require("pg");

const GUARD = Symbol.for("xauusd.news.trade.guard.v1");
const PATCHED = Symbol.for("xauusd.candidate.write.guard.v1");
const NEWS_PATCHED = Symbol.for("xauusd.news.decay.guard.v1");

const MT5_M1_MAX_AGE_MS = Math.max(
  90_000,
  Number(process.env.AUTO_CANDIDATE_MT5_M1_MAX_AGE_MS || 120_000)
);
const MT5_QUOTE_MAX_AGE_MS = Math.max(
  15_000,
  Number(process.env.AUTO_CANDIDATE_MT5_QUOTE_MAX_AGE_MS || 60_000)
);
const NO_TRADE_WINDOW_MS = Math.max(
  60_000,
  Number(process.env.HIGH_IMPACT_NO_TRADE_WINDOW_MS || 5 * 60_000)
);
const HIGH_IMPACT_MIN = Math.max(
  75,
  Math.min(100, Number(process.env.HIGH_IMPACT_NO_TRADE_MIN || 90))
);
const MAX_CANDIDATE_AGE_MS = Object.freeze({
  M1: Math.max(60_000, Number(process.env.M1_CANDIDATE_MAX_AGE_MS || 2 * 60_000)),
  M5: Math.max(2 * 60_000, Number(process.env.M5_CANDIDATE_MAX_AGE_MS || 10 * 60_000)),
});

// xauusd_candles.candle_time stores the M1 candle OPEN timestamp.
// Candidate freshness must therefore be measured from the candle CLOSE
// (open + 1 minute), otherwise every healthy closed M1 looks ~60s older
// and is falsely rejected by the 120s fail-closed freshness guard.
const MT5_M1_FRESHNESS_SQL = `SELECT EXTRACT(EPOCH FROM (NOW() - (MAX(candle_time) + INTERVAL '1 minute'))) * 1000 AS m1_age_ms
       FROM xauusd_candles
       WHERE timeframe='M1' AND UPPER(source) LIKE 'MT5%'`;

function clamp100(value) {
  return Math.max(0, Math.min(100, Math.round(Number(value) || 0)));
}

function eventTimestamp(item) {
  const values = [item?.scheduledAt, item?.releaseAt, item?.eventTime, item?.timestamp];
  for (const value of values) {
    const n = typeof value === "number" ? value : Date.parse(value || "");
    if (Number.isFinite(n) && n > 0) return n < 10_000_000_000 ? n * 1000 : n;
  }
  return 0;
}

function decayImpact(item, now = Date.now()) {
  const raw = clamp100(item?.impact);
  const ts = Number(item?.timestamp) || 0;
  if (!ts || ts > now) return raw;
  const ageMinutes = Math.max(0, (now - ts) / 60_000);
  const kind = String(item?.eventKind || "").toUpperCase();
  const halfLifeMinutes =
    kind === "OFFICIAL_RELEASE" ? 90 :
    kind === "REAL_EVENT" || kind === "MARKET_REACTION" ? 75 :
    kind === "PREVIEW" ? 30 : 180;
  const factor = Math.pow(0.5, ageMinutes / halfLifeMinutes);
  const floor = kind === "PREVIEW" ? 0 : Math.min(raw, 20);
  return clamp100(Math.max(floor, raw * factor));
}

function highImpactGuard(items, now = Date.now()) {
  const matches = [];
  for (const item of items || []) {
    const kind = String(item?.eventKind || "").toUpperCase();
    const impact = clamp100(item?.impact);
    if (impact < HIGH_IMPACT_MIN) continue;
    if (!["OFFICIAL_RELEASE", "REAL_EVENT"].includes(kind)) continue;
    const ts = eventTimestamp(item);
    if (!ts) continue;
    const delta = now - ts;
    const hasSchedule = Boolean(item?.scheduledAt || item?.releaseAt || item?.eventTime);
    const inside = hasSchedule
      ? Math.abs(delta) <= NO_TRADE_WINDOW_MS
      : delta >= 0 && delta <= NO_TRADE_WINDOW_MS;
    if (inside) matches.push(item);
  }
  if (!matches.length) return { active: false, reason: "OK", until: null };
  matches.sort((a, b) => clamp100(b?.impact) - clamp100(a?.impact));
  const top = matches[0];
  const ts = eventTimestamp(top);
  return {
    active: true,
    reason: `HIGH_IMPACT_NEWS:${String(top.eventKind || "EVENT")}:${String(top.relevanceReason || top.originalTitle || top.title || "")}`.slice(0, 500),
    until: new Date(ts + NO_TRADE_WINDOW_MS).toISOString(),
    impact: clamp100(top.impact),
  };
}

function clampCandidateExpiry(tf, proposedExpiry, now = Date.now()) {
  const maxAge = MAX_CANDIDATE_AGE_MS[String(tf || "").toUpperCase()];
  if (!maxAge) return proposedExpiry;
  const hardExpiry = now + maxAge;
  const proposed = Date.parse(proposedExpiry || "");
  const finalTs = Number.isFinite(proposed) && proposed > now
    ? Math.min(proposed, hardExpiry)
    : hardExpiry;
  return new Date(finalTs).toISOString();
}

function normalizeCandidateValues(values, m1Age, quoteAge, now = Date.now()) {
  if (!Array.isArray(values) || values.length < 12) return values;
  const nextValues = [...values];
  const tf = String(nextValues[2] || "").toUpperCase();
  const tp3Before = nextValues[10];

  // expires_at is parameter $2 => JS array index 1.
  nextValues[1] = clampCandidateExpiry(tf, nextValues[1], now);

  try {
    const payload = JSON.parse(String(nextValues[11] || "{}"));
    delete payload.max_positions;
    delete payload.initial_positions;
    delete payload.max_additions;
    payload.position_policy = "V9_DYNAMIC_RISK_MARGIN_PROFIT_PROGRESS_GAP";
    payload.fixed_position_count_cap = false;
    payload.candidate_max_age_ms = MAX_CANDIDATE_AGE_MS[tf] || null;
    payload.mt5_freshness_at_candidate = {
      m1_age_ms: Math.round(m1Age),
      quote_age_ms: Math.round(quoteAge),
    };
    nextValues[11] = JSON.stringify(payload);
  } catch (error) {
    console.warn(`⚠️ Candidate payload normalization skipped: ${error.message}`);
  }

  // Deterministic invariant: expiry normalization must never modify TP3.
  if (nextValues[10] !== tp3Before) {
    throw new Error("CANDIDATE_PARAMETER_MAPPING_BROKE_TP3");
  }

  return nextValues;
}

globalThis[GUARD] = globalThis[GUARD] || {
  active: false,
  reason: "NEWS_NOT_LOADED_YET",
  until: null,
  updatedAt: null,
};

try {
  const newsPath = require.resolve("./news");
  const current = require(newsPath);
  if (current && typeof current.getGoldNewsSnapshot === "function" && !current[NEWS_PATCHED]) {
    const original = current.getGoldNewsSnapshot.bind(current);
    const wrapped = {
      ...current,
      async getGoldNewsSnapshot(...args) {
        const now = Date.now();
        const raw = await original(...args);
        const decayed = (Array.isArray(raw) ? raw : []).map((item) => {
          const impact = decayImpact(item, now);
          return {
            ...item,
            rawImpact: clamp100(item?.impact),
            impact,
            relevanceScore: impact,
            level: impact >= 90 ? "EXTREME" : impact >= 75 ? "HIGH" : impact >= 55 ? "MEDIUM" : "LOW",
            impactDecayVersion: "NEWS_DECAY_V1",
          };
        });
        globalThis[GUARD] = {
          ...highImpactGuard(decayed, now),
          updatedAt: new Date(now).toISOString(),
        };
        return decayed;
      },
    };
    Object.defineProperty(wrapped, NEWS_PATCHED, { value: true, enumerable: false });
    require.cache[newsPath].exports = wrapped;
  }
} catch (error) {
  console.warn(`⚠️ NEWS TRADE SAFETY bootstrap: news wrapper unavailable: ${error.message}`);
}

if (!Pool.prototype[PATCHED]) {
  const originalQuery = Pool.prototype.query;

  Pool.prototype.query = async function guardedQuery(text, values, ...rest) {
    const sql = typeof text === "string" ? text : String(text?.text || "");
    if (!/INSERT\s+INTO\s+trade_candidates/i.test(sql)) {
      return originalQuery.call(this, text, values, ...rest);
    }

    const newsGuard = globalThis[GUARD] || {};
    if (newsGuard.active) {
      console.warn(`⛔ CANDIDATE BLOCKED | ${newsGuard.reason}`);
      return { rows: [], rowCount: 0, command: "INSERT" };
    }

    const freshness = await originalQuery.call(
      this,
      MT5_M1_FRESHNESS_SQL
    );
    const quoteFreshness = await originalQuery.call(
      this,
      `SELECT EXTRACT(EPOCH FROM (NOW() - MAX(received_at))) * 1000 AS quote_age_ms
       FROM mt5_quotes
       WHERE UPPER(source) LIKE 'MT5%' OR UPPER(source) LIKE 'DEMO_WORKER%'`
    );

    const m1Age = Number(freshness?.rows?.[0]?.m1_age_ms);
    const quoteAge = Number(quoteFreshness?.rows?.[0]?.quote_age_ms);
    const m1Fresh = Number.isFinite(m1Age) && m1Age >= -120_000 && m1Age <= MT5_M1_MAX_AGE_MS;
    const quoteFresh = Number.isFinite(quoteAge) && quoteAge >= -120_000 && quoteAge <= MT5_QUOTE_MAX_AGE_MS;

    if (!m1Fresh || !quoteFresh) {
      console.warn(`⛔ CANDIDATE BLOCKED | MT5_FRESHNESS | m1AgeMs=${m1Age} quoteAgeMs=${quoteAge}`);
      return { rows: [], rowCount: 0, command: "INSERT" };
    }

    const nextValues = normalizeCandidateValues(values, m1Age, quoteAge);
    return originalQuery.call(this, text, nextValues, ...rest);
  };

  Object.defineProperty(Pool.prototype, PATCHED, { value: true, enumerable: false });
  console.log("✅ NEWS/CANDIDATE SAFETY V1: MT5 freshness + news guard + short M1/M5 expiry + TP-safe dynamic V9 payload active");
}

module.exports = {
  decayImpact,
  highImpactGuard,
  clampCandidateExpiry,
  normalizeCandidateValues,
  MT5_M1_FRESHNESS_SQL,
  GUARD,
};
