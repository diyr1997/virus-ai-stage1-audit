# VIRUS AI — Continuous Learning, Capability Discovery & Absorption

Updated: 2026-09-12

## Purpose

VIRUS AI must evolve as ONE native intelligence, not as a runtime committee of external AI providers or named models.

External AI systems, open-source projects, research papers, SDKs, libraries, model weights, public APIs and AI Council advisors are teachers/donors/research inputs. Their useful, lawful capabilities may be studied, tested, adapted, reimplemented or integrated into VIRUS AI. The final runtime intelligence remains VIRUS AI.

The production-facing trading contract is always:

`VIRUS AI -> BUY / SELL / WAIT + forecast + uncertainty + reasons -> Risk -> Safety -> Execution`

There must be no runtime majority vote such as `GPT=BUY, Gemini=SELL, Claude=WAIT`.

## Core absorption loop

`DISCOVER -> VERIFY -> UNDERSTAND -> EXTRACT CAPABILITY -> ADAPT -> TRAIN -> TEST -> SELF-EVALUATE -> PROMOTE/REJECT -> MONITOR`

### 1. DISCOVER
Search for meaningful new or updated capabilities from lawful public sources, including:
- official open-source repositories and releases;
- official SDKs and APIs;
- research code and papers;
- agent/tool-use frameworks;
- memory and retrieval systems;
- planning/reasoning support tools;
- self-evaluation/evals/guardrails;
- time-series and forecasting methods;
- market microstructure/order-flow methods;
- news/event intelligence;
- optimization/backtesting/validation;
- observability/reliability/safety;
- data connectors and infrastructure.

Discovery sources should prioritize official maintainers, universities, exchanges, regulators, major engineering/research teams and reputable open-source projects.

### 2. VERIFY
Before VIRUS can learn from a candidate, record:
- exact source/repository;
- version/release/commit when applicable;
- code license;
- model-weights license separately when applicable;
- API/terms constraints;
- maintenance status;
- dependencies and compute cost;
- security/supply-chain risk;
- overlap with existing VIRUS capability;
- XAU/USD relevance;
- future Binance relevance;
- leakage/look-ahead/overfit risk;
- whether commercial use/redistribution is allowed.

No bypassing authentication, paywalls, rate limits, commercial controls, proprietary internals or closed model weights.

### 3. UNDERSTAND
AI Council advisors and VIRUS research tooling should explain what the candidate actually adds:
- what problem it solves;
- what information it uses;
- what assumptions it makes;
- where it fails;
- when it should be active;
- what existing VIRUS capability it duplicates;
- what measurable hypothesis can falsify its value.

### 4. EXTRACT CAPABILITY
Do not blindly merge whole repositories.

Preferred forms of absorption:
- use a compatible open library through a narrow adapter;
- extract an open algorithm/formula into a VIRUS-native implementation;
- implement an architecture idea from lawful public research;
- use compatible open weights only under their license;
- distill/teach a VIRUS-native model only where the source/license permits it;
- use external software as a research oracle when direct integration is unnecessary;
- reject candidates that add duplication, unsafe dependencies or no measurable value.

Technical provenance must remain in the audit/registry even when the runtime no longer exposes the donor's brand/name.

## ONE BRAIN rule

VIRUS AI should learn to combine capabilities internally, not ask separate donor models to vote.

A capability may become:
- an internal feature encoder;
- a shared representation;
- a regime detector;
- a memory/retrieval mechanism;
- a tool-use/planning skill;
- a news understanding module;
- a forecasting head;
- an uncertainty/calibration head;
- a safety/verification mechanism;
- a training/validation mechanism;
- a data/infrastructure component.

Only one VIRUS decision core produces the trading decision.

Correlated or duplicated information must never be counted as multiple independent confirmations.

## INTERNAL HELPER AGENTS — "SOLDIERS" UNDER ONE VIRUS BRAIN

VIRUS AI may create or invoke temporary/internal specialist agents to perform bounded tasks. These helpers are workers, not independent trading brains.

The hierarchy is:

`VIRUS MAIN BRAIN -> Task Planner/Dispatcher -> Specialist Helper Agents -> Evidence/Artifacts -> Verifier -> VIRUS MAIN BRAIN -> Final Decision`

The final BUY/SELL/WAIT, forecast, risk intent and execution authorization remain owned by the single VIRUS decision core.

### What helper agents may do

Examples:
- `Research Scout` — find new repositories, papers, releases, APIs and datasets.
- `License & Provenance Agent` — verify source, license, weights terms, version/commit and attribution requirements.
- `Security Agent` — inspect dependency/supply-chain/security risks before code enters the research environment.
- `Code Reader` — map unfamiliar repositories, extract interfaces/algorithms and identify reusable parts.
- `Integration Builder` — create narrow VIRUS-native adapters or clean-room implementations where lawful.
- `Test Engineer` — build deterministic unit/smoke/parity tests.
- `Backtest Agent` — run chronological/purged/embargoed research experiments on frozen data.
- `Ablation/Redundancy Agent` — measure whether a candidate adds non-duplicated OOS information.
- `News Scout` — collect/canonicalize current lawful news and economic-event evidence.
- `Macro Agent` — fetch/normalize official macro/CFTC/rates/yields data with point-in-time provenance.
- `Market Data Agent` — validate price/tick/order-flow data freshness/completeness.
- `Diagnostics Agent` — inspect logs, failed candidates, stale data and runtime anomalies.
- `Documentation/Memory Agent` — update the candidate registry, experiments, decisions, sources and lessons learned.

Future Binance specialists may include L2/order-book ingestion, exchange-event monitoring, listing research and microstructure analysis.

### Dynamic agent discovery

VIRUS should be allowed to discover new useful agent skills/frameworks from lawful open sources. A newly discovered agent/tool does not become trusted automatically.

The flow is:

`need detected -> search candidate helper capability -> verify license/security -> isolated test -> register skill -> assign narrow permissions -> monitor quality -> retain/disable`

VIRUS may also compose a temporary helper from already-approved tools when no permanent specialist exists.

### Permission model

Every helper agent must have a declared scope:
- allowed tools/data sources;
- read/write permissions;
- network access if any;
- maximum compute/time/token budget;
- files/tables it may modify;
- whether it may create code or only propose a diff;
- whether human/Council review is required;
- explicit prohibition on REAL trading unless a future separately audited execution policy ever authorizes it.

Default is least privilege and fail-closed.

### Helper-agent output contract

Every worker returns structured evidence, not a trading vote. Minimum fields:
- `task_id`
- `agent_role`
- `as_of_timestamp`
- `inputs/provenance`
- `findings`
- `artifacts_or_diff`
- `confidence`
- `uncertainty`
- `failure_flags`
- `sources`
- `tests_run`
- `recommendation_to_main_brain`

A helper's recommendation is advisory evidence. It cannot directly call the final order decision path.

### Anti-chaos rules

- No majority voting among helpers.
- No agent may silently spawn unlimited descendants.
- No duplicated agents should be treated as independent evidence.
- One canonical task graph prevents duplicate work.
- Shared memory/provenance must distinguish facts, hypotheses and failed experiments.
- Conflicting helper outputs trigger verification or more data, not automatic voting.
- The main brain may reject every helper result and return WAIT/NO-CHANGE.
- Expensive or low-value agents are disabled if measured contribution is poor.

### Teacher/Council role for agent design

ChatGPT, Claude, Gemini, DeepSeek, Grok, Kimi, Perplexity and future advisors should help VIRUS design, teach and audit these helper agents. They may propose:
- task decomposition;
- tool selection;
- prompts/contracts;
- memory schemas;
- evaluator/verifier design;
- permission boundaries;
- recovery/retry logic;
- new agent skills from open-source frameworks;
- better ways to fuse the resulting knowledge into the single VIRUS brain.

The Council itself remains development/research infrastructure. Its members do not become runtime voters inside VIRUS.

## NEWS INTELLIGENCE — AI-linked function

News is not a simple keyword score and must not become a separate voting AI.

Create a unified `News Intelligence` capability inside VIRUS with these responsibilities:

1. **Ingestion**
   - ingest lawful official/verified news and economic-event sources;
   - preserve `source_id`, `event_id`, publication time, event time, first-seen time and `as_of_timestamp`;
   - never allow future revisions/late articles to leak into historical decisions.

2. **Canonical event building**
   - deduplicate multiple articles about the same event;
   - one underlying event must not be counted several times because Reuters/AP/official release/secondary media all mention it;
   - retain confirmations/enrichment as provenance, not extra votes.

3. **AI understanding**
   - classify event type;
   - extract entities, actual/forecast/previous where available;
   - estimate relevance to gold/USD/rates/risk sentiment/liquidity;
   - distinguish fact from commentary;
   - generate structured scenario hypotheses, not a direct order.

4. **Time-decay and horizon**
   - learn/measure how impact changes across M1/M5/M15/M30/H1 and longer horizons;
   - high-impact scheduled events may activate embargo/no-trade safety windows;
   - source/event impact must be validated by replay, not hard-coded because an AI said so.

5. **Market interaction**
   News representation is fused with price/volatility/session/regime/liquidity/order-flow context. The same event may matter differently in different regimes.

6. **Output to VIRUS brain**
   Produce structured evidence such as:
   - event embedding/representation;
   - directional pressure distribution;
   - uncertainty;
   - expected horizon;
   - event novelty;
   - source confidence;
   - regime interaction;
   - safety flags.

The News Intelligence layer does NOT send BUY/SELL orders itself.

## SKILL & CAPABILITY DISCOVERY — GitHub/research function

Create a persistent research capability that searches for useful new skills/capabilities and updates, rather than relying only on manual discoveries.

### Candidate categories
- AI/agent orchestration;
- tool use/function calling;
- memory/RAG/retrieval;
- coding/static analysis/code graphs;
- evals/self-check/verification;
- model routing/compression where lawful and useful;
- time-series/TSFM;
- regime/change-point detection;
- uncertainty/conformal/calibration;
- optimization/hyperparameter search;
- purged/embargoed temporal validation;
- market microstructure/order flow;
- event/news/macro ingestion;
- feature stores/data quality;
- backtesting/replay/execution simulation;
- security/supply-chain scanning;
- observability/monitoring/recovery;
- Binance data/order-book/WebSocket capabilities for future use.

### Discovery record
Each candidate must have:
- `candidate_id`
- `discovered_at`
- `source_url`
- `source_type`
- `project_name`
- `version_or_commit`
- `license_code`
- `license_weights`
- `maintenance_status`
- `capability_summary`
- `why_relevant`
- `xauusd_relevance`
- `binance_relevance`
- `dependencies`
- `security_notes`
- `legal_notes`
- `overlap_with_existing`
- `proposed_absorption_mode`
- `test_plan`
- `status = WATCH | ISOLATED_TEST | ADOPTED | REJECTED`
- `evidence`

### Important rule
A new GitHub star count, marketing claim, benchmark or AI recommendation is NOT enough to adopt anything.

## AI Council as teachers

ChatGPT, Claude, Gemini, DeepSeek, Grok, Kimi, Perplexity and future advisors may:
- discover new lawful capabilities;
- explain code/research;
- propose VIRUS-native implementations;
- create deterministic tests;
- challenge leakage/overfitting;
- compare candidate vs baseline;
- teach/update documentation;
- review security/licenses;
- propose new combinations of already-known ideas;
- design and audit internal helper-agent roles and their permission boundaries.

They are research teachers, not runtime trading voters.

Advisor output must be converted into a measurable candidate/hypothesis before it can affect the VIRUS brain.

## VIRUS self-learning boundary

VIRUS may learn which capability is useful under which regime/timeframe/session/context, but it must not silently rewrite production or self-deploy unreviewed code.

Self-improvement creates a challenger generation. Promotion requires an explicit gate.

`current champion -> new knowledge -> challenger -> validation -> shadow/DEMO -> promotion or rejection`

## Acceptance gates before promotion

At minimum:
1. deterministic unit/smoke tests;
2. exact point-in-time/as-of compliance;
3. closed-candle contract where candle data is used;
4. no future leakage;
5. purged/embargoed walk-forward validation where applicable;
6. untouched final holdout;
7. spread/slippage/commission/latency-aware evaluation for trading effects;
8. calibration and uncertainty checks;
9. redundancy/ablation test against current VIRUS;
10. regime/session/timeframe stability;
11. safety/fail-closed tests;
12. shadow/DEMO forward test before any execution promotion;
13. rollback path;
14. provenance/license record.

A candidate is promoted only if it improves useful out-of-sample information, calibration, safety, robustness or net after-cost utility without unacceptable regressions.

## Runtime safety

- Research discoveries do not change live trading behavior automatically.
- No REAL trading activation from this pipeline.
- Stale/missing/inconsistent data -> fail closed / WAIT.
- News/model/tool provider outage must not produce fabricated evidence.
- External AI availability must not be required for an already-trained VIRUS trading decision.
- Helper agents cannot directly authorize orders.
- Secrets remain in Railway/environment secrets, never in GitHub or prompts.

## Future implementation modules

Suggested native modules/interfaces:

```text
virus_ai/
  discovery/
    github_scanner/
    release_monitor/
    research_scanner/
    candidate_registry/
    license_verifier/
    security_gate/
  agents/
    planner_dispatcher/
    registry/
    permissions/
    workers/
      research_scout/
      license_provenance/
      security/
      code_reader/
      integration_builder/
      test_engineer/
      backtest/
      ablation/
      news_scout/
      macro/
      market_data/
      diagnostics/
      documentation_memory/
    verifier/
    budget_manager/
  learning/
    capability_parser/
    absorption_planner/
    challenger_builder/
    teacher_feedback/
    ablation/
    promotion_gate/
  intelligence/
    news/
      ingestion/
      canonical_events/
      event_understanding/
      impact_decay/
      regime_interaction/
    market/
    macro/
    microstructure/
  brain/
    representations/
    regime/
    uncertainty/
    decision/
  research/
  safety/
  observability/
```

These are conceptual module boundaries. Do not create dozens of deployable services by default. Prefer one VIRUS AI platform with modular internal components.

## Success definition

The goal is not to accumulate the most libraries, agents or external AI brands.

The goal is for each validated discovery and each well-scoped helper agent to make one VIRUS AI measurably better at understanding, forecasting, deciding, explaining, operating safely and learning from new lawful knowledge.