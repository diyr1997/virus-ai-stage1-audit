# XAU/USD PROJECT LEDGER — through 2026-08-20

Purpose: one canonical checklist so local laptop work, Railway cloud work, experiments, errors, and future ideas are not mixed up.

## Architecture — never mix these two bots

### Bot #1 — Telegram analytics / Railway cloud
- Runs in Railway.
- Builds M1/M5/M15/M30/H1 analysis and BUY/SELL/WAIT signals.
- Uses PostgreSQL as the shared store for candles, quotes, analyses, candidates, trade records, model registry, training runs, news state, and Trading School state.
- Uses only closed candles for signal decisions.
- Signal/candidate baseline threshold: 60/100.
- Current production graph layer: Graph Scenario V6.
- Manual Telegram analysis can use a cloud M1 fallback when MT5 is offline, but cloud fallback must never become an automatic MT5 trade candidate.

### Bot #2 — Windows MT5 DEMO worker / home laptop
- Executes DEMO trades only. REAL accounts are blocked by code.
- Broker symbol currently expected as GOLD# while analytical candidate symbol remains XAUUSD.
- This worker is local and is NOT automatically replaced when cloud files change.
- As of 2026-08-20 the user has NOT installed the local changes prepared during the day. Laptop still needs the final consolidated package.

## What was built and fixed since the project began

### Core analytics and data
- PostgreSQL connected as the central database.
- MT5 quotes and closed M1 candles are synced to PostgreSQL.
- M1/M5/M15/M30/H1 analysis exists with separate timeframe logic; timeframes are not converted into each other.
- Only closed candles are allowed to drive automatic candidates.
- UTC is canonical internally; Asia/Tashkent is display timezone.
- MT5 timestamp offset detection/freshness protection was added after stale/future candle problems.
- Manual signal cloud fallback was added for Telegram requests when local MT5 worker is offline. It is intentionally isolated from AUTOPILOT/DEMO execution.

### Signal and candidate safety
- Candidate threshold standardized at >=60/100.
- Autopilot cooldown retained for duplicate alerts.
- Scenario cancellation was moved away from overly fragile immediate cancellation: candidate invalidation uses confirmed closed-timeframe context / planned invalidation rules rather than reacting to every tick.
- Candidate freshness/expiry diagnostics were added during worker iterations.
- Telegram live status exposes heartbeat, latest M1/quote freshness, worker version, symbol, trader state and risk mode.

### Dynamic DEMO risk manager
- Uses account balance, equity, margin, free margin and already-open positions.
- Lot is capped by signal strength and can be reduced when safe margin/risk budget is insufficient.
- Risk profiles: CAUTIOUS / MEDIUM / ACTIVE / AGGRESSIVE.
- REAL account guard remains mandatory.

### Entry-logic bug found on 2026-08-20
Old trader logic could create too many same-direction entries because:
- several profiles had initial_slots=2;
- each new timeframe/candidate could effectively obtain another fresh slot;
- stale confirmation context could add while current M1 was already moving against the basket.

### Impulse Entry Guard V3 — prepared for final laptop package
- First entry is one starting position only.
- A second/subsequent same-side order is an ADD, not a new free initial slot.
- ADD requires the existing bot basket to be profitable.
- Price must have progressed favorably before adding.
- A new candidate/timeframe does not reset the global symbol entry logic.
- Simultaneous BUY and SELL self-hedging is blocked.
- Direction is checked again immediately before order_send().
- Existing lot ladder, risk profiles, maximum-position limits and base SL/TP are not increased by this guard.
- Startup refuses to run with old entry logic if the mandatory V3 apply step fails.

### Automatic market-state worker
- No manual market OPEN/CLOSED switch.
- Recognizes planned daily GOLD maintenance window and weekends as normal closed states, not errors.
- New entries are blocked while market is closed.
- Existing trades are not force-closed by the market-state module.
- After quotes return, worker waits for a fresh closed M1 before resuming entries.
- Reconnect/self-recovery logic remains active.

### Windows startup problems fixed/prepared
- UTF-8/BOM problem in BAT/config template addressed.
- Launcher now stays visible on errors rather than silently disappearing.
- Mandatory V3 guard check occurs before worker launch.
- Crash restart after a delay is included.
- Final intended heartbeat version: xauusd-demo-worker-v8-home-final-2026-08-20.

### Final home package
Artifact target: XAUUSD_DEMO_WORKER_HOME_FINAL_2026-08-20
It contains worker.py, worker_auto.py, patched trader.py, V3 patch/apply scripts, requirements, clean launcher, config template, README and installation notes.
Do not install intermediate 2026-08-20 files one-by-one. At home preserve the old working config_private.bat, unpack the final package, copy config_private.bat into it, start it, verify V8 heartbeat, and only then retire the old folder.

## Graph work
- Earlier graph versions had straight/unrealistic forecasts, slow generation and occasional missing/duplicate chart messages.
- Chart path was hardened and Graph Scenario V6 became the current safe cloud forecast layer.
- V6 verification checks forecast length, valid high/low ranges, non-straight path with turns, and final directional consistency.
- Graph remains a forecast visualization, not proof of future price.

## News engine
Current architecture:
- Core Global News Engine V14.
- XAU relevance wrapper V15.
- Separate CFTC module; CFTC should not be mixed into normal headline news.

Official feeds currently included:
- Federal Reserve Monetary Policy
- Federal Reserve Speeches & Testimony
- BLS CPI
- BLS Employment / NFP
- BLS JOLTS
- ECB
- Bank of England News
- Bank of England Speeches
- Bank of Japan

Google News query families currently included:
- gold market
- USA macro / Fed / CPI / NFP / PCE / Treasury yields / DXY
- China / PBOC
- Japan / BOJ
- Europe / ECB
- UK / BoE
- Middle East
- Africa
- Latin America
- Asia / India / RBI
- central-bank gold purchases/reserves
- geopolitics
- systemic crypto only when linked to liquidity/risk/gold

GDELT is supplemental only and has rate-limit/backoff protection.

V15 filters out common noise such as chart/tool pages, pure FX forecasts, CBDC-only noise, weak regional background and unrelated gold/retail content. It upgrades genuine XAU reactions to dollar/yields and meaningful geopolitical escalation/de-escalation.

### News additions to evaluate next
Priority candidates, subject to stable parsing and duplicate tests:
1. U.S. BEA — Personal Income & Outlays / PCE and GDP release pages/schedule.
2. U.S. Treasury — official press/auction/economic/interest-rate/TIC information where it creates a real XAU bridge.
3. PBoC official reserve / monetary-policy material if a stable machine-readable source is available.
4. World Gold Council data/research for central-bank buying, ETF flows and structural gold demand; treat as market-structure context, not official U.S. macro.
5. LBMA market data/context where licensing and automated access permit it.
6. Keep Reuters/AP/Bloomberg-class reporting as corroboration/discovery via lawful feeds/search rather than copying paywalled article text.

Every new source must pass: freshness, XAU relevance, duplicate/corroboration, preview-vs-release classification, and no-trade-window tests before it can affect signal strength.

## Trading School / model learning
Goal is NOT to copy books into the model. Pipeline:
source -> sequential understanding -> original distilled principles/exceptions -> measurable causal feature/hypothesis -> OOS/backtest -> chronological blocks -> shadow/demo -> promotion only if objectively better.

Already created:
- Trading School source manifest and legal/open source library.
- Full-reader infrastructure for HTML/PDF sources.
- 12 causal School features covering price action, efficiency, breakout location, MTF alignment, lower-vs-higher disagreement, pullback, trend/range context.
- Unified Trading Intelligence Core composite features.
- Small shadow trainer and normal daily/weekend challenger trainer.
- Model registry where a challenger can replace champion only after acceptance checks.

Important lesson from 2026-08-20 tests:
- Multiple raw School feature sets looked more confident but reduced OOS directional accuracy and/or worsened MAE. They were rejected and did not replace the active model.
- Regime Router V1B found an interesting REVERSAL_ATTEMPT subgroup, but chronological robustness failed: it improved two blocks and failed badly on the third. Therefore it is NOT connected to live/demo trading.

## Reversal / close-and-flip — still open
Desired behavior:
- If a genuine opposite M1/M5 impulse appears while an old basket is profitable: close old side, verify it is gone, then allow opposite entry.
- If old basket is losing: block the opposite entry and leave old basket under existing SL/TP.
- Never maintain BUY and SELL together for the bot.

Status: NOT enabled yet. V3 only blocks conflicting direction and unsafe additions. V4 close-and-flip must wait for more robust reversal detection/shadow evidence.

## Trading School source status / known issues
- Zerodha TA / Trading Systems / Risk modules are ingested, but semantic understanding is incomplete.
- CME Futures guide and MQL5 book are stored; large engineering/manual material is deferred so scarce AI quota is not wasted before core analytical material.
- Stefan Jansen open MIT companion: cached in PostgreSQL; repeated GitHub refresh failures no longer erase the cached source.
- FPP3 previously showed INGESTED with zero text; this was corrected and reset for retry instead of pretending it was learned.
- Gemini semantic reading is slowed by API quota/rate limits. Numeric shadow/backtest work does not depend on Gemini and continues independently.

## Brian Shannon book supplied by the user
Title verified: Technical Analysis Using Multiple Timeframes (2008).
The currently supplied scan is PARTIAL, not a complete book.
- PDF has 150 pages.
- It reaches printed page 136, in Chapter 14 News & Fundamentals.
- TOC says Chapters 15–18 should follow: Short Squeezes, Risk Management/Exit Strategies, Rules & Insight, Putting It All Together.
- Therefore do not label current scan as whole-book understanding.

Safe handling:
- May analyze the user-provided copy for the project.
- Do not mirror the copyrighted scan into GitHub or redistribute it.
- Store only original distilled notes, rules, hypotheses and test results.
- Once a complete legal copy is available, verify final chapters before calling it FULL.

## AI Council
Existing provider layer supports Gemini, DeepSeek and Claude plus a coordinator.
Current Railway configuration has Gemini credentials but no DeepSeek or Anthropic key, so only Gemini can currently participate from the cloud. Missing providers must fail safely and never block the bot.

Existing Weekend Council already asks Gemini+Google Search to find current high-quality macro/XAU information streams and then asks available advisors for measurable improvements. Council output is a proposal only; it does not directly edit production trading rules.

### Council tasks to add/maintain
- NEWS REVIEW: identify new legal/current primary sources, stale/duplicate problems, source-quality weights, high-impact event windows and XAU direction logic.
- CODE REVIEW: inspect architecture/diagnostics/test results and propose patches; patches remain proposals until deterministic tests pass.
- BOOK REVIEW: when a legal/user-supplied source has been converted to private chapter notes, ask each configured advisor independently for principles, exceptions, contradictions, timeframe mapping and measurable XAU hypotheses. Compare answers instead of trusting one AI.
- MODEL REVIEW: advisors may suggest experiments; numerical acceptance remains controlled by OOS/chronological tests, not AI opinion.

## Current AI/provider limitations
- Gemini exists but is currently prone to 429 RESOURCE_EXHAUSTED; automatic backoff is enabled.
- DeepSeek code exists but Railway has no DEEPSEEK_API_KEY yet.
- Claude code exists but Railway has no ANTHROPIC_API_KEY yet.
- Do not claim DeepSeek/Claude reviewed anything until keys are configured and a successful response is logged.

## Remaining high-priority work
1. Install and verify the final V8 home worker package on the home laptop.
2. Confirm heartbeat, GOLD# quote freshness, closed M1 freshness and DEMO-only guard after installation.
3. Watch V3 behavior in DEMO: first entry, profitable add, progress gate, no hedge, no duplicate candidate slot.
4. Continue reversal-regime research; do not enable V4 close-and-flip until robust across chronological blocks.
5. Add/test official BEA PCE/GDP and carefully selected Treasury/physical-gold sources.
6. Improve candidate confirmation/invalidation diagnostics and log exactly why every candidate opened, waited, expired, cancelled or was blocked.
7. Continue Graph V6 latency/deduplication monitoring.
8. Continue Trading School full-source synthesis as quota allows; do not confuse INGESTED with UNDERSTOOD.
9. Obtain/verify complete Shannon copy before whole-book claim; current copy can still produce PARTIAL chapter hypotheses.
10. Add DeepSeek key later if the user wants a second independent cloud coding/math reviewer; add Claude only if desired.

## Non-negotiable safety rules
- DEMO only for automatic execution.
- No raw copyrighted commercial books committed to the repository.
- No active-model promotion merely because an AI recommends it.
- No new news source can directly increase trade confidence before freshness/relevance/duplicate tests.
- Never mix cloud analytics-bot state with local MT5-worker state.
