"use strict";

const path = require("path");
const Module = require("module");

const target = path.resolve(__dirname, "index.js");
const previousLoader = Module._extensions[".js"];

function replaceRequired(source, oldText, newText, label) {
  if (!source.includes(oldText)) {
    throw new Error(`SIGNAL UI READABLE: patch target missing: ${label}`);
  }
  return source.replace(oldText, newText);
}

function replaceBetween(source, startToken, endToken, replacement, label) {
  const start = source.indexOf(startToken);
  const end = source.indexOf(endToken, start);
  if (start < 0 || end < 0) {
    throw new Error(`SIGNAL UI READABLE: block missing: ${label}`);
  }
  return source.slice(0, start) + replacement + source.slice(end);
}

function readableSignalFunction() {
  return `function buildSignalText({
  timeframe,
  analyses,
  analysis,
  plan,
  analyzedAt,
  candle,
  mt5Quote,
}) {
  const side =
    analysis.action === "WAIT"
      ? "WAIT"
      : String(analysis.direction || analysis.action || "WAIT").toUpperCase();

  const icon = side === "BUY" ? "🟢" : side === "SELL" ? "🔴" : "⚪";
  const status =
    analysis.action === "WAIT"
      ? "⚪ НЕ ВХОДИТЬ"
      : "🟡 ЖДАТЬ ПОДТВЕРЖДЕНИЯ";

  const digits = Math.max(2, Math.min(5, Number(mt5Quote?.digits || 2)));
  const mt5Line = mt5Quote?.fresh
    ? \`📡 MT5 LIVE: BID \${Number(mt5Quote.bid).toFixed(digits)} • ASK \${Number(mt5Quote.ask).toFixed(digits)} • Spread \${Number(mt5Quote.spread || 0).toFixed(digits)}\`
    : "📡 MT5 LIVE: свежей котировки пока нет";

  const condition =
    side === "BUY"
      ? \`ASK > \${plan.confirmation.toFixed(2)}\`
      : side === "SELL"
      ? \`BID < \${plan.confirmation.toFixed(2)}\`
      : null;

  const invalidation = Number.isFinite(Number(plan.invalidation))
    ? Number(plan.invalidation)
    : Number(plan.sl);

  const invalidationRule =
    side === "BUY"
      ? \`Закрытая \${timeframe} < \${invalidation.toFixed(2)}\`
      : side === "SELL"
      ? \`Закрытая \${timeframe} > \${invalidation.toFixed(2)}\`
      : null;

  const levels =
    analysis.action === "WAIT"
      ? "🚫 Вход: нет"
      : \`✅ УСЛОВИЕ ВХОДА
\${condition}

❌ ОТМЕНА СЦЕНАРИЯ
\${invalidationRule}
или смена направления → противоположное / WAIT

🛡 SL
\${plan.sl.toFixed(2)}

🎯 ЦЕЛИ
TP1: \${plan.tp1.toFixed(2)}
TP2: \${plan.tp2.toFixed(2)}
TP3: \${plan.tp3.toFixed(2)}\`;

  const mtf = TF_ORDER.map((tf) => {
    const item = analyses?.[tf];
    if (!item) return \`\${tf}: —\`;
    const tfIcon = item.action === "BUY" ? "🟢" : item.action === "SELL" ? "🔴" : "⚪";
    const tfSide = item.action === "BUY" ? "BUY" : item.action === "SELL" ? "SELL" : "WAIT";
    return \`\${tf}: \${tfIcon} \${tfSide} | \${item.strength}/100\`;
  }).join("\\n");

  const news = analysis.newsPressure || {};
  const newsIcon =
    news.direction === "UP" ? "🟢⬆️" : news.direction === "DOWN" ? "🔴⬇️" : "⚪↔️";

  return \`\${icon} XAU/USD — \${side} • \${timeframe}
\${status}

🕒 Анализ: \${fmtTime(analyzedAt)}
🕯 Закрытая \${timeframe}: \${fmtTime(candle.time)}
💰 Цена анализа: \${analysis.price.toFixed(2)}
\${mt5Line}

📊 Сила направления: \${analysis.strength}/100
\${mtf}

🌍 Новости: \${newsIcon} \${news.direction || "NEUTRAL"} • \${news.strength || 0}/100
📊 CFTC: \${analysis.cftcDirection || "NEUTRAL"}

\${levels}

ℹ️ \${analysis.strength}/100 — сила направления, не вероятность выигрыша.\`;
}

`;
}

function applyCompactPatch(source) {
  let patched = source;

  const signalStart = "function buildSignalText({";
  const graphMarker =
    "// ======================================================\n" +
    "// GRAPH";
  patched = replaceBetween(
    patched,
    signalStart,
    graphMarker,
    readableSignalFunction(),
    "buildSignalText"
  );

  // Keep the original 1440x900 graph geometry. The previous 720px compression
  // made candles, footer and V7 labels collide. Only wording is adjusted here.
  const directionStart = "  const directionText =";
  const directionEnd = "  const closedText = fmtDateTime(candle.time);";
  const directionReplacement = `  const directionText =
    analysis.action === "BUY"
      ? "BUY"
      : analysis.action === "SELL"
      ? "SELL"
      : "WAIT";
  const statusText =
    analysis.action === "WAIT"
      ? "НЕ ВХОДИТЬ"
      : "ЖДАТЬ ПОДТВЕРЖДЕНИЯ";
`;
  patched = replaceBetween(
    patched,
    directionStart,
    directionEnd,
    directionReplacement,
    "chart direction/status"
  );

  patched = replaceRequired(
    patched,
    '<text x="1141" y="75" fill="#d1d4dc" font-family="${FONT}" font-size="14">Сила ${analysis.strength}/100</text>',
    '<text x="1141" y="75" fill="#d1d4dc" font-family="${FONT}" font-size="14">${statusText} • Сила ${analysis.strength}/100</text>',
    "header status line"
  );

  const oldV7Visual =
    '  const visualAction = plan.v7State === "UNCERTAIN" ? "WAIT" : (plan.v7PrimaryDirection || analysis.action);';
  if (patched.includes(oldV7Visual)) {
    patched = patched.replace(
      oldV7Visual,
      '  const visualAction = analysis.action === "WAIT" ? "WAIT" : (analysis.direction || analysis.action);'
    );
  }

  // WAIT must never draw a directional future path. Keep real candles visible,
  // but remove the forecast overlay so the chart cannot imply a BUY/SELL path.
  patched = replaceRequired(
    patched,
    "  if (forecast.length) {",
    "  if (forecast.length && analysis.action !== \"WAIT\") {",
    "WAIT forecast overlay guard"
  );

  return patched;
}

module.exports = { applyCompactPatch, readableSignalFunction };

if (process.env.SIGNAL_UI_COMPACT_VERIFY_ONLY !== "1") {
  Module._extensions[".js"] = function readableSignalLoader(module, filename) {
    if (path.resolve(filename) !== target) {
      return previousLoader(module, filename);
    }

    const originalCompile = module._compile.bind(module);
    module._compile = function readableSignalCompile(code, compileFilename) {
      module._compile = originalCompile;
      const patched = applyCompactPatch(code);
      console.log("✅ SIGNAL UI READABLE: OLD-STYLE TEXT + ORIGINAL GRAPH GEOMETRY ACTIVE");
      return originalCompile(patched, compileFilename);
    };

    return previousLoader(module, filename);
  };
}
