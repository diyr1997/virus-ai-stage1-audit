"use strict";

/**
 * Why a closed bar did not become a trade candidate.
 *
 * The bot has gone whole sessions without producing a single candidate, and
 * nothing anywhere records why. The verdict funnel has at least five places a
 * bar can die -- the model's own emit rule, the score threshold, the trade
 * strength floor, an untraded timeframe, an already-open candidate for that
 * direction -- and from outside they all look identical: silence.
 *
 * This module writes one row per evaluated bar naming the first gate that
 * stopped it, and also records the ones that passed. That turns "the bot is
 * quiet" into a number: how many bars died at each gate over a day.
 *
 * Two rules it must never break:
 *
 *   - It observes, it never decides. classifyCandidateOutcome() is a pure
 *     description of a decision the caller has already made. Nothing here can
 *     change whether a candidate is created.
 *   - It never throws into the signal path. recordCandidateOutcome() swallows
 *     its own errors, because losing a diagnostic row must never cost a trade.
 *
 * Order matters. Gates are evaluated cheapest-first and the FIRST match is
 * reported, so the reason is the binding constraint rather than a list of
 * everything that happened to be true.
 */

const OUTCOMES = Object.freeze({
  ACCEPTED: "ACCEPTED",
  DUPLICATE_ACTIVE_CANDIDATE: "DUPLICATE_ACTIVE_CANDIDATE",
  DB_NOT_READY: "DB_NOT_READY",
  NO_ANALYSIS_ID: "NO_ANALYSIS_ID",
  TIMEFRAME_NOT_TRADED: "TIMEFRAME_NOT_TRADED",
  AI_MODELS_DISAGREE: "AI_MODELS_DISAGREE",
  AI_CONFIDENCE_BELOW_THRESHOLD: "AI_CONFIDENCE_BELOW_THRESHOLD",
  AI_MOVE_BELOW_THRESHOLD: "AI_MOVE_BELOW_THRESHOLD",
  AI_WAIT_OTHER: "AI_WAIT_OTHER",
  SCORE_BELOW_SIGNAL_THRESHOLD: "SCORE_BELOW_SIGNAL_THRESHOLD",
  STRENGTH_BELOW_TRADE_MIN: "STRENGTH_BELOW_TRADE_MIN",
});

// ai_predict_h1.py returns these in its `reason` field when it declines.
const AI_REASONS = Object.freeze({
  models_disagree: OUTCOMES.AI_MODELS_DISAGREE,
  confidence_below_threshold: OUTCOMES.AI_CONFIDENCE_BELOW_THRESHOLD,
  move_below_threshold: OUTCOMES.AI_MOVE_BELOW_THRESHOLD,
});

const SCHEMA_SQL = `
  CREATE TABLE IF NOT EXISTS candidate_rejections (
    id BIGSERIAL PRIMARY KEY,
    observed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    candle_time TIMESTAMPTZ,
    timeframe VARCHAR(8) NOT NULL,
    outcome VARCHAR(48) NOT NULL,
    accepted BOOLEAN NOT NULL DEFAULT FALSE,
    direction VARCHAR(8),
    score NUMERIC(10,4),
    strength SMALLINT,
    signal_threshold SMALLINT,
    trade_min_strength SMALLINT,
    ai_reason VARCHAR(48),
    ai_confidence NUMERIC(8,6),
    ai_predicted_bps NUMERIC(12,4),
    detail JSONB NOT NULL DEFAULT '{}'::jsonb
  )
`;

function num(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

/**
 * Describe, in one word, why this bar did or did not become a candidate.
 *
 * Pure: no I/O, no clock, no randomness. Everything it reports comes from the
 * arguments, so a test can drive every branch without a database.
 */
function classifyCandidateOutcome({
  dbReady = true,
  analysisId = null,
  timeframe = null,
  tradedTimeframes = null,
  analysis = null,
  minStrength = 0,
  signalThreshold = null,
  hasExistingCandidate = false,
} = {}) {
  const verdict = analysis || {};
  const action = String(verdict.action || "").toUpperCase();
  const strength = num(verdict.strength);
  const ai = verdict.aiPrediction || null;
  const aiReason = String(ai?.reason || "").toLowerCase();

  const base = {
    timeframe: timeframe == null ? null : String(timeframe),
    direction: verdict.direction ? String(verdict.direction) : null,
    score: num(verdict.score),
    strength,
    signalThreshold: num(signalThreshold),
    minStrength: num(minStrength),
    aiReason: aiReason || null,
    aiConfidence: num(ai?.confidence),
    aiPredictedBps: num(ai?.predicted_return_bps),
  };

  const out = (outcome, accepted = false) => ({ ...base, outcome, accepted });

  // Infrastructure first: these say nothing about the market.
  if (!dbReady) return out(OUTCOMES.DB_NOT_READY);
  if (!analysisId) return out(OUTCOMES.NO_ANALYSIS_ID);

  const traded =
    tradedTimeframes == null
      ? true
      : typeof tradedTimeframes.has === "function"
        ? tradedTimeframes.has(timeframe)
        : Array.isArray(tradedTimeframes)
          ? tradedTimeframes.includes(timeframe)
          : true;
  if (!traded) return out(OUTCOMES.TIMEFRAME_NOT_TRADED);

  // Then the model's own refusal, which is more specific than "WAIT" and is
  // the only place that distinguishes a disagreement from a small move.
  if (action === "WAIT") {
    if (AI_REASONS[aiReason]) return out(AI_REASONS[aiReason]);
    if (aiReason && aiReason !== "signal") return out(OUTCOMES.AI_WAIT_OTHER);
    return out(OUTCOMES.SCORE_BELOW_SIGNAL_THRESHOLD);
  }

  if (strength != null && num(minStrength) != null && strength < num(minStrength)) {
    return out(OUTCOMES.STRENGTH_BELOW_TRADE_MIN);
  }

  // Passing every gate and then finding an open candidate for the same
  // direction is not a rejection of the signal. Recorded separately so it
  // cannot be mistaken for one.
  if (hasExistingCandidate) return out(OUTCOMES.DUPLICATE_ACTIVE_CANDIDATE);

  return out(OUTCOMES.ACCEPTED, true);
}

async function ensureRejectionSchema(pool) {
  if (!pool) return false;
  await pool.query(SCHEMA_SQL);
  await pool.query(
    "CREATE INDEX IF NOT EXISTS idx_candidate_rejections_time ON candidate_rejections(observed_at DESC)"
  );
  await pool.query(
    "CREATE INDEX IF NOT EXISTS idx_candidate_rejections_outcome ON candidate_rejections(outcome, observed_at DESC)"
  );
  return true;
}

/**
 * Write one row. Never throws: a lost diagnostic row must not cost a trade.
 * Returns true only when a row was actually written.
 */
async function recordCandidateOutcome(pool, classification, extra = {}) {
  if (!pool || !classification) return false;
  try {
    await pool.query(
      `INSERT INTO candidate_rejections(
         candle_time, timeframe, outcome, accepted, direction, score, strength,
         signal_threshold, trade_min_strength, ai_reason, ai_confidence,
         ai_predicted_bps, detail
       ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13::jsonb)`,
      [
        extra.candleTime || null,
        classification.timeframe,
        classification.outcome,
        Boolean(classification.accepted),
        classification.direction,
        classification.score,
        classification.strength,
        classification.signalThreshold,
        classification.minStrength,
        classification.aiReason,
        classification.aiConfidence,
        classification.aiPredictedBps,
        JSON.stringify(extra.detail || {}),
      ]
    );
    return true;
  } catch (error) {
    console.warn(
      `⚠️ candidate outcome not logged: ${String(error?.message || error).slice(0, 200)}`
    );
    return false;
  }
}

/**
 * Keep the table bounded. At one row per evaluated bar per traded timeframe
 * this grows by a few thousand rows a day, which is cheap, but not forever.
 */
async function pruneRejections(pool, retentionDays = 45) {
  if (!pool) return 0;
  const days = Math.max(1, Math.floor(Number(retentionDays) || 45));
  try {
    const result = await pool.query(
      `DELETE FROM candidate_rejections WHERE observed_at < NOW() - ($1 || ' days')::interval`,
      [String(days)]
    );
    return Number(result?.rowCount || 0);
  } catch (error) {
    console.warn(
      `⚠️ candidate outcome prune skipped: ${String(error?.message || error).slice(0, 200)}`
    );
    return 0;
  }
}

/** One line per outcome over the window, most frequent first. */
async function outcomeBreakdown(pool, hours = 24) {
  if (!pool) return [];
  const window = Math.max(1, Math.floor(Number(hours) || 24));
  const result = await pool.query(
    `SELECT outcome, COUNT(*)::int AS bars, MAX(observed_at) AS last_seen
       FROM candidate_rejections
      WHERE observed_at >= NOW() - ($1 || ' hours')::interval
      GROUP BY outcome
      ORDER BY bars DESC`,
    [String(window)]
  );
  return result.rows || [];
}

/**
 * The breakdown as one greppable log line.
 *
 * One line because that is what survives a log search months later, and
 * because the question it answers -- "where do the bars die?" -- is answered
 * by the shape of the whole list, not by any single number in it.
 */
function formatBreakdown(rows, hours = 24) {
  const window = Math.max(1, Math.floor(Number(hours) || 24));
  const counted = (Array.isArray(rows) ? rows : [])
    .map((row) => ({
      outcome: String(row?.outcome || "UNKNOWN"),
      bars: Math.max(0, Math.floor(Number(row?.bars) || 0)),
    }))
    .filter((row) => row.bars > 0)
    .sort((a, b) => b.bars - a.bars || a.outcome.localeCompare(b.outcome));

  const total = counted.reduce((sum, row) => sum + row.bars, 0);
  if (!total) return `📊 CANDIDATE FUNNEL ${window}h | no bars evaluated`;

  const parts = counted.map(
    (row) => `${row.outcome} ${row.bars} (${((row.bars / total) * 100).toFixed(1)}%)`
  );
  return `📊 CANDIDATE FUNNEL ${window}h | ${total} bars | ${parts.join(" | ")}`;
}

/**
 * Read the breakdown and hand back the line to print. Never throws: this is a
 * report about the bot, not a part of it.
 */
async function reportBreakdown(pool, hours = 24) {
  if (!pool) return null;
  try {
    return formatBreakdown(await outcomeBreakdown(pool, hours), hours);
  } catch (error) {
    return `⚠️ CANDIDATE FUNNEL unavailable: ${String(error?.message || error).slice(0, 200)}`;
  }
}

module.exports = {
  OUTCOMES,
  AI_REASONS,
  classifyCandidateOutcome,
  ensureRejectionSchema,
  recordCandidateOutcome,
  pruneRejections,
  outcomeBreakdown,
  formatBreakdown,
  reportBreakdown,
};
