# First bot compact UI — 2026-08-21

This change only affects the analytical Telegram bot UI.

- Signal text is shortened to fit one Telegram photo caption.
- Direction and entry status are separated (`BUY/SELL SETUP` vs `WAIT CONFIRMATION`).
- `UNCERTAIN / NO TRADE` is reserved for non-actionable WAIT signals.
- A strong BUY/SELL setup is no longer painted as neutral only because Graph V7 forecast uncertainty is elevated.
- Chart aspect is changed from 1440x900 to 1440x720 and footer blocks are compressed.
- Trading thresholds, SL/TP math, candidate creation, risk manager and MT5 worker code are unchanged.
