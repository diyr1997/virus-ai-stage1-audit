"use strict";

const crypto = require("crypto");
const { enqueueCouncilTask } = require("../ai-council-persistent");
const { processCouncilTask, getCouncilSnapshot } = require("../ai-council-dynamic");
const {
  promoteReady,
  activeItem,
  nextItem,
  canCloseAudit,
  nextWaitState,
  phaseZeroDone,
  parseImplementationGate,
  readyAdvisorCount,
  requiredAdvisorsReady,
} = require("./roadmap-coordinator-core");
const {
  publishExecutorTask,
  verifyExecutorResult,
  mergeVerifiedBranch,
} = require("./claude-executor");

const ENABLED = /^(1|true|yes|on)$/i.test(String(process.env.AUTONOMY_COORDINATOR_ENABLED || "0"));
const REPO = String(process.env.GITHUB_COUNCIL_REPO || "diyr1997/xauusd-ai-signal-bot").trim();
const TOKEN = String(process.env.GITHUB_REVIEW_TOKEN || "").trim();
const STATE_BRANCH = String(process.env.AUTONOMY_STATE_BRANCH || "ai-council-queue").trim();
const STATE_PATH = String(process.env.AUTONOMY_STATE_PATH || ".ai-council-queue/autonomy/roadmap-state.json").trim();
const POLL_MS = Math.max(30_000, Number(process.env.AUTONOMY_POLL_MS || 60_000));
const MIN_COUNCIL_READY = Math.max(2, Number(process.env.AUTONOMY_MIN_COUNCIL_READY || 2));
const EVIDENCE_MAX_CHARS = Math.max(1000, Math.min(20_000, Number(process.env.AUTONOMY_EVIDENCE_MAX_CHARS || 8000)));
const MAX_EXECUTOR_ATTEMPTS = Math.max(1, Math.min(3, Number(process.env.AUTONOMY_EXECUTOR_MAX_ATTEMPTS || 3)));
const MAX_CONSECUTIVE_WAITS = Math.max(1, Number(process.env.AUTONOMY_MAX_CONSECUTIVE_WAITS || 60));
// item id -> { reason, count }. Deliberately in memory: runPass() reloads the
// state file from GitHub every tick, so persisting the streak would require the
// per-poll commit this fuse exists to stop.
const waitStreaks = new Map();
const REQUIRED_PHASE0_ADVISORS = String(
  process.env.AUTONOMY_REQUIRED_PHASE0_ADVISORS || "deepseek,claude"
)
  .split(",")
  .map((x) => x.trim().toLowerCase())
  .filter(Boolean);
const REQUIRED_EXECUTOR_REVIEW_ADVISORS = String(
  process.env.AUTONOMY_REQUIRED_EXECUTOR_REVIEW_ADVISORS || "deepseek,claude"
)
  .split(",")
  .map((x) => x.trim().toLowerCase())
  .filter(Boolean);

function nowIso() {
  return new Date().toISOString();
}

function repoParts() {
  const [owner, repo] = REPO.split("/");
  if (!owner || !repo) throw new Error("GITHUB_COUNCIL_REPO must be owner/repo");
  return { owner, repo };
}

async function gh(path, options = {}) {
  if (!TOKEN) throw new Error("GITHUB_REVIEW_TOKEN is not configured");
  const response = await fetch(`https://api.github.com${path}`, {
    ...options,
    headers: {
      accept: "application/vnd.github+json",
      authorization: `Bearer ${TOKEN}`,
      "x-github-api-version": "2022-11-28",
      "user-agent": "virus-ai-roadmap-coordinator",
      ...(options.headers || {}),
    },
  });
  const raw = await response.text();
  let data = null;
  if (raw) {
    try { data = JSON.parse(raw); } catch { data = raw; }
  }
  if (!response.ok) {
    const error = new Error(`GitHub API ${response.status}: ${String(data?.message || raw).slice(0, 500)}`);
    error.statusCode = response.status;
    throw error;
  }
  return data;
}

async function loadState() {
  const { owner, repo } = repoParts();
  const encodedPath = STATE_PATH.split("/").map(encodeURIComponent).join("/");
  const data = await gh(`/repos/${owner}/${repo}/contents/${encodedPath}?ref=${encodeURIComponent(STATE_BRANCH)}`);
  if (String(data?.encoding || "").toLowerCase() !== "base64") throw new Error("Roadmap state is not base64 encoded");
  const text = Buffer.from(String(data.content || "").replace(/\s+/g, ""), "base64").toString("utf8");
  return { sha: data.sha, state: JSON.parse(text) };
}

async function saveState(sha, state, message) {
  const { owner, repo } = repoParts();
  const encodedPath = STATE_PATH.split("/").map(encodeURIComponent).join("/");
  const body = {
    message,
    branch: STATE_BRANCH,
    sha,
    content: Buffer.from(JSON.stringify(state, null, 2) + "\n", "utf8").toString("base64"),
  };
  return gh(`/repos/${owner}/${repo}/contents/${encodedPath}`, {
    method: "PUT",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
}

async function persist(loaded, message) {
  const saved = await saveState(loaded.sha, loaded.state, message);
  loaded.sha = saved?.content?.sha || loaded.sha;
  return loaded;
}

function councilTaskId(item) {
  const safe = String(item.id).replace(/[^A-Za-z0-9_.-]+/g, "_");
  const attempt = Math.max(1, Number(item.attempt || 1));
  return `AUTONOMY_${safe}_A${attempt}`.toUpperCase();
}

function reviewTaskId(item) {
  const safe = String(item.id).replace(/[^A-Za-z0-9_.-]+/g, "_");
  const attempt = Math.max(1, Number(item.executor_attempt || 1));
  return `AUTONOMY_REVIEW_${safe}_A${attempt}`.toUpperCase();
}

function taskPrompt(item, state) {
  const source = state?.source || {};
  const strictGate = item.requires_final_gate
    ? "At the very end include exactly one line: FINAL_GATE: PASS or FINAL_GATE: BLOCKED. PASS is allowed only if no unresolved CRITICAL/HIGH blocker remains for starting the roadmap."
    : "This task is complete when the requested audit evidence is produced. Findings may remain open and must be listed explicitly.";

  return [
    "VIRUS AI autonomous Phase-0 audit task.",
    "Do not enable REAL trading. Do not expose secrets. Do not make irreversible destructive changes.",
    "Use current repository/runtime evidence; distinguish VERIFIED from UNVERIFIED.",
    `Canonical Drive tracker: ${source.title || "VIRUS AI — CURRENT WORK ORDER & COMPLETION TRACKER"} (${source.drive_document_id || "unknown id"}).`,
    `ITEM ${item.id}: ${item.title}`,
    "",
    String(item.task || "").trim(),
    "",
    "Return: verified_evidence, findings_by_severity, exact_files_services_or_tables, proposed_fixes, tests_needed, unresolved_blockers, confidence.",
    strictGate,
  ].join("\n");
}

function implementationReviewPrompt(item, executorEvidence) {
  return [
    "VIRUS AI autonomous implementation review.",
    "Review the VERIFIED GitHub diff and executor test evidence in the frozen context. Do not trust the executor summary when it conflicts with the actual diff.",
    "This review is advisory/safety gating only. Do not edit code, deploy, trade, expose secrets, or enable REAL trading.",
    `ITEM ${item.id}: ${item.title}`,
    `BASE_SHA: ${executorEvidence.base_sha}`,
    `HEAD_SHA: ${executorEvidence.head_sha}`,
    `BRANCH: ${executorEvidence.branch}`,
    "",
    "Check correctness, regressions, causality/leakage where relevant, test adequacy, DEMO/fail-closed safety, secret/workflow safety, scope creep, and whether the implementation actually satisfies the item.",
    "A PASS requires no unresolved CRITICAL/HIGH defect in this implementation. A lower-severity issue may remain only if explicitly documented and safe to defer.",
    "Return exact findings and tests. At the very end include exactly one line: IMPLEMENTATION_GATE: PASS or IMPLEMENTATION_GATE: BLOCKED.",
  ].join("\n");
}

function evidenceFrom(snapshot) {
  const plan = String(snapshot?.task?.final_plan || "");
  return {
    captured_at: nowIso(),
    council_status: String(snapshot?.task?.status || ""),
    council_revision: Number(snapshot?.task?.revision || 0),
    ready_advisors: [...new Set((snapshot?.readyAdvisors || []).map(String))],
    synthesis_excerpt: plan.slice(0, EVIDENCE_MAX_CHARS),
    synthesis_sha256: crypto.createHash("sha256").update(plan).digest("hex"),
  };
}

function resetExecutorForRetry(item, reason, feedback = null) {
  item.executor_attempt = Math.max(1, Number(item.executor_attempt || 1)) + 1;
  item.executor_task_id = null;
  item.executor_branch = null;
  item.executor_base_sha = null;
  item.executor_phase = null;
  item.executor_evidence = null;
  item.review_task_id = null;
  item.review_evidence = null;
  item.last_executor_reason = reason;
  item.checklist = {
    CHECKED: false,
    IMPLEMENTED: false,
    TESTS_PASSED: false,
    COUNCIL_PASSED: false,
  };
  const history = Array.isArray(item.executor_feedback) ? item.executor_feedback : [];
  history.push({ at: nowIso(), reason, feedback: feedback ? String(feedback).slice(0, 8000) : null });
  item.executor_feedback = history.slice(-MAX_EXECUTOR_ATTEMPTS);
}

async function publishExecutorForItem(loaded, item) {
  const descriptor = await publishExecutorTask(item, loaded.state);
  item.executor_task_id = descriptor.taskId;
  item.executor_branch = descriptor.branch;
  item.executor_base_sha = descriptor.baseSha;
  item.executor_phase = descriptor.phase;
  item.executor_attempt = descriptor.attempt;
  item.updated_at = nowIso();
  loaded.state.updated_at = item.updated_at;
  await persist(loaded, `autonomy: publish executor ${item.id} attempt ${item.executor_attempt}`);
  console.log(`[AUTONOMY] executor published ${item.id} -> ${item.executor_task_id} branch=${item.executor_branch}`);
}

async function startExecutorItem(loaded, item) {
  item.status = "IN_PROGRESS";
  item.attempt = Math.max(1, Number(item.attempt || 0) + 1);
  item.executor_attempt = 1;
  item.started_at = nowIso();
  item.updated_at = item.started_at;
  item.checklist = {
    CHECKED: false,
    IMPLEMENTED: false,
    TESTS_PASSED: false,
    COUNCIL_PASSED: false,
  };
  loaded.state.updated_at = item.updated_at;
  await persist(loaded, `autonomy: claim executor item ${item.id} ${item.title}`);
  await publishExecutorForItem(loaded, item);
}

async function startAuditItem(loaded, item) {
  item.status = "IN_PROGRESS";
  item.attempt = Math.max(1, Number(item.attempt || 0) + 1);
  item.started_at = nowIso();
  item.updated_at = item.started_at;
  item.council_task_id = councilTaskId(item);
  loaded.state.updated_at = item.updated_at;

  await persist(loaded, `autonomy: claim ${item.id} ${item.title}`);

  await enqueueCouncilTask({
    taskId: item.council_task_id,
    taskType: String(item.phase) === "0" ? "autonomy_phase0_audit" : "autonomy_roadmap_review",
    task: taskPrompt(item, loaded.state),
  });
  await processCouncilTask(item.council_task_id);
  console.log(`[AUTONOMY] started ${item.id} -> ${item.council_task_id}`);
}

async function startItem(loaded, item) {
  if (item.requires_executor) return startExecutorItem(loaded, item);
  return startAuditItem(loaded, item);
}

async function retryOrBlockExecutor(loaded, item, reason, feedback = null) {
  if (Number(item.executor_attempt || 1) < MAX_EXECUTOR_ATTEMPTS) {
    resetExecutorForRetry(item, reason, feedback);
    item.status = "IN_PROGRESS";
    item.updated_at = nowIso();
    loaded.state.updated_at = item.updated_at;
    await persist(loaded, `autonomy: retry executor ${item.id} reason=${reason}`);
    await publishExecutorForItem(loaded, item);
    return;
  }
  item.status = "BLOCKED";
  item.blocked_reason = reason;
  item.updated_at = nowIso();
  if (feedback) item.blocked_feedback = String(feedback).slice(0, EVIDENCE_MAX_CHARS);
  loaded.state.updated_at = item.updated_at;
  await persist(loaded, `autonomy: block executor ${item.id} reason=${reason}`);
  console.log(`[AUTONOMY] executor blocked ${item.id}: ${reason}`);
}

async function refreshExecutorActive(loaded, item) {
  if (!item.executor_task_id || !item.executor_branch || !item.executor_base_sha) {
    await publishExecutorForItem(loaded, item);
    return;
  }

  if (!item.executor_evidence) {
    const verified = await verifyExecutorResult({
      item,
      taskId: item.executor_task_id,
      branch: item.executor_branch,
      baseSha: item.executor_base_sha,
    });
    item.last_executor_reason = verified.reason || null;
    item.updated_at = nowIso();
    loaded.state.updated_at = item.updated_at;

    if (!verified.ready) {
      if (verified.invalid) {
        await retryOrBlockExecutor(loaded, item, verified.reason || "INVALID_EXECUTOR_RESULT", JSON.stringify(verified));
        return;
      }
      item.status = "IN_PROGRESS";
      await persist(loaded, `autonomy: wait executor ${item.id} ${verified.reason || "WAITING"}`);
      console.log(`[AUTONOMY] waiting executor ${item.id}: ${verified.reason || "WAITING"}`);
      return;
    }

    item.executor_evidence = verified.evidence;
    item.checklist.CHECKED = true;
    item.checklist.IMPLEMENTED = true;
    item.checklist.TESTS_PASSED = true;
    item.status = "REVIEW";
    item.review_task_id = reviewTaskId(item);
    item.review_context_sha256 = crypto.createHash("sha256").update(verified.reviewContext).digest("hex");

    await enqueueCouncilTask({
      taskId: item.review_task_id,
      taskType: "autonomy_implementation_review",
      task: implementationReviewPrompt(item, verified.evidence),
      contextSnapshot: verified.reviewContext,
    });
    await processCouncilTask(item.review_task_id);
    await persist(loaded, `autonomy: executor verified ${item.id}; council review started`);
    console.log(`[AUTONOMY] executor verified ${item.id}; review=${item.review_task_id}`);
    return;
  }

  if (!item.review_task_id) {
    await retryOrBlockExecutor(loaded, item, "MISSING_REVIEW_TASK_ID");
    return;
  }

  await processCouncilTask(item.review_task_id);
  const snapshot = await getCouncilSnapshot(item.review_task_id);
  if (!snapshot) {
    item.status = "REVIEW";
    await persist(loaded, `autonomy: wait missing review snapshot ${item.id}`);
    return;
  }

  const reviewGateItem = {
    ...item,
    required_advisors: REQUIRED_EXECUTOR_REVIEW_ADVISORS,
  };
  const hasEnough = readyAdvisorCount(snapshot) >= MIN_COUNCIL_READY;
  const hasRequired = requiredAdvisorsReady(reviewGateItem, snapshot);
  const finalPlan = String(snapshot?.task?.final_plan || "");
  const gate = parseImplementationGate(finalPlan);
  item.review_ready_advisors = snapshot?.readyAdvisors || [];
  item.required_review_advisors = REQUIRED_EXECUTOR_REVIEW_ADVISORS;
  item.last_review_gate = gate;
  item.updated_at = nowIso();
  loaded.state.updated_at = item.updated_at;

  if (!finalPlan || !hasEnough || !hasRequired || gate === "UNKNOWN") {
    item.status = "REVIEW";
    await persist(
      loaded,
      `autonomy: wait implementation review ${item.id} gate=${gate} ready=${item.review_ready_advisors.join(",")}`
    );
    console.log(`[AUTONOMY] waiting implementation review ${item.id}: gate=${gate} ready=${item.review_ready_advisors.join(",")}`);
    return;
  }

  item.review_evidence = evidenceFrom(snapshot);
  if (gate === "BLOCKED") {
    await retryOrBlockExecutor(loaded, item, "IMPLEMENTATION_GATE_BLOCKED", finalPlan);
    return;
  }

  item.checklist.COUNCIL_PASSED = true;
  const merge = await mergeVerifiedBranch({
    branch: item.executor_evidence.branch,
    baseSha: item.executor_evidence.base_sha,
    headSha: item.executor_evidence.head_sha,
    itemId: item.id,
  });

  if (!merge.merged) {
    if (merge.retryable) {
      await retryOrBlockExecutor(loaded, item, merge.reason || "MERGE_RETRY_REQUIRED", JSON.stringify(merge));
      return;
    }
    item.status = "BLOCKED";
    item.blocked_reason = merge.reason || "MERGE_FAILED";
    item.merge_evidence = merge;
    await persist(loaded, `autonomy: block merge ${item.id} ${item.blocked_reason}`);
    return;
  }

  item.status = "DONE";
  item.completed_at = nowIso();
  item.blocked_reason = null;
  item.merge_evidence = merge;
  item.evidence = {
    captured_at: item.completed_at,
    executor: item.executor_evidence,
    review: item.review_evidence,
    merge,
  };
  loaded.state.updated_at = item.completed_at;
  promoteReady(loaded.state);
  if (phaseZeroDone(loaded.state)) loaded.state.phase0_status = "DONE";
  await persist(loaded, `autonomy: complete executor item ${item.id}`);
  console.log(`[AUTONOMY] completed executor item ${item.id} merge=${merge.mergeSha}`);
}

async function refreshAuditActive(loaded, item) {
  if (!item.council_task_id) {
    item.status = "BLOCKED";
    item.blocked_reason = "MISSING_COUNCIL_TASK_ID";
    item.updated_at = nowIso();
    loaded.state.updated_at = item.updated_at;
    await persist(loaded, `autonomy: block ${item.id} missing council task id`);
    return;
  }

  await processCouncilTask(item.council_task_id);
  const snapshot = await getCouncilSnapshot(item.council_task_id);
  if (!snapshot) return;

  const gateItem = String(item.phase) === "0"
    ? {
        ...item,
        required_advisors:
          Array.isArray(item.required_advisors) && item.required_advisors.length
            ? item.required_advisors
            : REQUIRED_PHASE0_ADVISORS,
      }
    : item;
  const close = canCloseAudit(gateItem, snapshot, MIN_COUNCIL_READY);
  item.last_council_status = snapshot?.task?.status || null;
  item.ready_advisors = snapshot?.readyAdvisors || [];
  item.required_advisors = gateItem.required_advisors || [];
  item.updated_at = nowIso();

  if (close.blocked) {
    waitStreaks.delete(item.id);
    item.status = "BLOCKED";
    item.blocked_reason = close.reason;
    item.evidence = evidenceFrom(snapshot);
    loaded.state.updated_at = item.updated_at;
    await persist(loaded, `autonomy: block ${item.id} after council gate`);
    console.log(`[AUTONOMY] blocked ${item.id}: ${close.reason}`);
    return;
  }

  if (!close.ok) {
    const wait = nextWaitState(waitStreaks.get(item.id), close.reason, MAX_CONSECUTIVE_WAITS);
    waitStreaks.set(item.id, { reason: wait.reason, count: wait.count });

    if (wait.action === "block") {
      waitStreaks.delete(item.id);
      item.status = "BLOCKED";
      item.blocked_reason = `STUCK_${close.reason}`;
      item.evidence = evidenceFrom(snapshot);
      loaded.state.updated_at = item.updated_at;
      await persist(loaded, `autonomy: block ${item.id} stuck on ${close.reason} after ${wait.count} polls`);
      console.warn(`[AUTONOMY] blocked ${item.id}: stuck on ${close.reason} after ${wait.count} polls`);
      return;
    }

    item.status = snapshot?.task?.final_plan ? "REVIEW" : "IN_PROGRESS";
    if (wait.action === "persist") {
      loaded.state.updated_at = item.updated_at;
      await persist(loaded, `autonomy: refresh ${item.id} ${close.reason}`);
    }
    console.log(`[AUTONOMY] waiting ${item.id}: ${close.reason} | poll=${wait.count}/${MAX_CONSECUTIVE_WAITS}`);
    return;
  }

  waitStreaks.delete(item.id);

  item.status = "DONE";
  item.completed_at = nowIso();
  item.blocked_reason = null;
  item.evidence = evidenceFrom(snapshot);
  loaded.state.updated_at = item.completed_at;
  promoteReady(loaded.state);
  if (phaseZeroDone(loaded.state)) loaded.state.phase0_status = "DONE";
  await persist(loaded, `autonomy: complete ${item.id}`);
  console.log(`[AUTONOMY] completed ${item.id} with advisers=${item.evidence.ready_advisors.join(",")}`);
}

async function refreshActive(loaded, item) {
  if (item.requires_executor) return refreshExecutorActive(loaded, item);
  return refreshAuditActive(loaded, item);
}

async function runPass() {
  const loaded = await loadState();
  promoteReady(loaded.state);

  const active = activeItem(loaded.state);
  if (active) {
    await refreshActive(loaded, active);
    return;
  }

  const next = nextItem(loaded.state);
  if (!next) {
    const phase0 = phaseZeroDone(loaded.state) ? "DONE" : "WAITING/BLOCKED";
    console.log(`[AUTONOMY] no runnable item | phase0=${phase0}`);
    return;
  }
  await startItem(loaded, next);
}

async function main() {
  if (!ENABLED) {
    console.log("[AUTONOMY] coordinator disabled (AUTONOMY_COORDINATOR_ENABLED!=1)");
    return;
  }
  if (!TOKEN) throw new Error("GITHUB_REVIEW_TOKEN required");

  let busy = false;
  const tick = async () => {
    if (busy) return;
    busy = true;
    try { await runPass(); }
    catch (error) { console.error(`[AUTONOMY] pass failed: ${error.stack || error.message}`); }
    finally { busy = false; }
  };

  await tick();
  setInterval(tick, POLL_MS).unref();
  console.log(
    `[AUTONOMY] coordinator online | poll=${POLL_MS}ms | minCouncil=${MIN_COUNCIL_READY} | phase0Required=${REQUIRED_PHASE0_ADVISORS.join(",")} | executorReviewRequired=${REQUIRED_EXECUTOR_REVIEW_ADVISORS.join(",")} | executorMaxAttempts=${MAX_EXECUTOR_ATTEMPTS}`
  );
  await new Promise(() => {});
}

if (require.main === module) {
  main().catch((error) => {
    console.error(`[AUTONOMY] fatal: ${error.stack || error.message}`);
    process.exit(1);
  });
}

module.exports = {
  runPass,
  loadState,
  saveState,
  persist,
  taskPrompt,
  implementationReviewPrompt,
  councilTaskId,
  reviewTaskId,
  resetExecutorForRetry,
};
