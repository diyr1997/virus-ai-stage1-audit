"use strict";

const EXECUTOR_MARKER = "AUTONOMY_EXECUTOR_RESULT_V1";
const FORBIDDEN_PATH_PATTERNS = [
  /^\.github\/workflows\//i,
  /^\.github\/actions\//i,
  /^\.gitmodules$/i,
  /(^|\/)\.env($|\.)/i,
  /(^|\/)(id_rsa|id_ed25519|.*\.pem|.*\.p12|.*\.pfx|.*\.key)$/i,
];
const REAL_TRADING_ENABLE_PATTERN = /\b(?:REAL_TRADING|LIVE_TRADING|ALLOW_REAL|ENABLE_REAL|VIRUS_AI_REAL_TRADING_ENABLED)\b[^\n]{0,80}(?:=|:)\s*(?:1|true|yes|on)\b/i;

function safeId(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9._-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

function executorBranch(itemId, attempt = 1) {
  const id = safeId(itemId);
  if (!id) throw new Error("itemId is required");
  const n = Math.max(1, Number(attempt) || 1);
  return `autonomy/${id}-a${n}`;
}

function isForbiddenPath(path) {
  const clean = String(path || "").replace(/^\/+/, "");
  return FORBIDDEN_PATH_PATTERNS.some((pattern) => pattern.test(clean));
}

function dangerousAddedLines(patch) {
  return String(patch || "")
    .split("\n")
    .filter((line) => line.startsWith("+") && !line.startsWith("+++"))
    .map((line) => line.slice(1))
    .filter((line) => REAL_TRADING_ENABLE_PATTERN.test(line));
}

function parseJsonAfterMarker(text) {
  const raw = String(text || "");
  const markerIndex = raw.indexOf(EXECUTOR_MARKER);
  if (markerIndex < 0) return { ok: false, reason: "MISSING_EXECUTOR_MARKER" };
  const after = raw.slice(markerIndex + EXECUTOR_MARKER.length).trim();
  const first = after.indexOf("{");
  const last = after.lastIndexOf("}");
  if (first < 0 || last < first) return { ok: false, reason: "MISSING_EXECUTOR_JSON" };
  let data;
  try {
    data = JSON.parse(after.slice(first, last + 1));
  } catch {
    return { ok: false, reason: "MALFORMED_EXECUTOR_JSON" };
  }
  return { ok: true, data };
}

function normalizeTest(test) {
  return {
    command: String(test?.command || "").trim().slice(0, 1000),
    exit_code: Number(test?.exit_code),
    summary: String(test?.summary || "").trim().slice(0, 4000),
  };
}

function validateExecutorResult({
  text,
  itemId,
  expectedBranch,
  expectedBaseSha,
}) {
  const parsed = parseJsonAfterMarker(text);
  if (!parsed.ok) return parsed;
  const data = parsed.data || {};

  if (String(data.version || "") !== EXECUTOR_MARKER) {
    return { ok: false, reason: "WRONG_EXECUTOR_VERSION" };
  }
  if (String(data.item_id || "") !== String(itemId || "")) {
    return { ok: false, reason: "WRONG_ITEM_ID" };
  }
  if (String(data.branch || "") !== String(expectedBranch || "")) {
    return { ok: false, reason: "WRONG_BRANCH" };
  }
  if (String(data.base_sha || "") !== String(expectedBaseSha || "")) {
    return { ok: false, reason: "WRONG_BASE_SHA" };
  }
  if (!/^[0-9a-f]{40}$/i.test(String(data.head_sha || ""))) {
    return { ok: false, reason: "INVALID_HEAD_SHA" };
  }
  if (String(data.status || "").toUpperCase() !== "CHANGES_READY") {
    return { ok: false, reason: "CHANGES_NOT_READY" };
  }

  const files = Array.isArray(data.changed_files)
    ? [...new Set(data.changed_files.map((x) => String(x || "").trim()).filter(Boolean))]
    : [];
  if (!files.length) return { ok: false, reason: "NO_CHANGED_FILES" };
  const forbidden = files.filter(isForbiddenPath);
  if (forbidden.length) {
    return { ok: false, reason: "FORBIDDEN_CHANGED_PATH", forbidden };
  }

  const tests = Array.isArray(data.tests) ? data.tests.map(normalizeTest) : [];
  if (!tests.length) return { ok: false, reason: "NO_TEST_EVIDENCE" };
  if (tests.some((test) => !test.command || !Number.isInteger(test.exit_code))) {
    return { ok: false, reason: "INVALID_TEST_EVIDENCE" };
  }
  if (tests.some((test) => test.exit_code !== 0)) {
    return { ok: false, reason: "TESTS_FAILED", tests };
  }

  return {
    ok: true,
    result: {
      version: EXECUTOR_MARKER,
      item_id: String(data.item_id),
      status: "CHANGES_READY",
      branch: String(data.branch),
      base_sha: String(data.base_sha),
      head_sha: String(data.head_sha).toLowerCase(),
      changed_files: files,
      tests,
      summary: String(data.summary || "").trim().slice(0, 12_000),
      rollback: String(data.rollback || "").trim().slice(0, 4000),
    },
  };
}

function buildExecutorPrompt({ item, branch, baseSha, findings = [] }) {
  return [
    "You are the isolated implementation executor for VIRUS AI autonomous work.",
    "This is NOT a trading decision and NOT permission for REAL trading.",
    "Work only in the repository already attached to this Claude Code Cloud session.",
    `ITEM_ID: ${item.id}`,
    `ITEM_TITLE: ${item.title}`,
    `BASE_SHA: ${baseSha}`,
    `REQUIRED_BRANCH: ${branch}`,
    "",
    "HARD SAFETY CONTRACT:",
    "1. Start from the exact BASE_SHA and create/use exactly REQUIRED_BRANCH. Never commit or push directly to main.",
    "2. Never enable REAL trading, never weaken DEMO/fail-closed guards, never expose or rotate secrets, never delete production data/services.",
    "3. Do not modify .github/workflows/**, .github/actions/**, .gitmodules, .env*, private keys/certificates, or credential files.",
    "4. Make the minimum implementation needed for this item. Do not opportunistically refactor unrelated code.",
    "5. Run deterministic relevant tests. If tests fail, fix safely or return BLOCKED; do not claim success.",
    "6. Commit and push the REQUIRED_BRANCH only. Do not open/merge a PR unless the task explicitly requests it.",
    "7. Before reporting success, verify git HEAD and list changed files against BASE_SHA.",
    "",
    "ITEM TASK:",
    String(item.task || item.title || "").trim(),
    "",
    "AUDIT FINDINGS / EVIDENCE TO REMEDIATE:",
    JSON.stringify(findings, null, 2).slice(0, 45_000),
    "",
    "FINAL RESPONSE CONTRACT:",
    `On success, end with the literal marker ${EXECUTOR_MARKER} followed by one JSON object with:`,
    `{\"version\":\"${EXECUTOR_MARKER}\",\"item_id\":\"${String(item.id)}\",\"status\":\"CHANGES_READY\",\"branch\":\"${branch}\",\"base_sha\":\"${baseSha}\",\"head_sha\":\"<40 hex>\",\"changed_files\":[\"path\"],\"tests\":[{\"command\":\"...\",\"exit_code\":0,\"summary\":\"...\"}],\"summary\":\"...\",\"rollback\":\"...\"}`,
    "If safe implementation is impossible, do not invent a commit. Explain BLOCKED and do not emit CHANGES_READY.",
  ].join("\n");
}

module.exports = {
  EXECUTOR_MARKER,
  FORBIDDEN_PATH_PATTERNS,
  REAL_TRADING_ENABLE_PATTERN,
  safeId,
  executorBranch,
  isForbiddenPath,
  dangerousAddedLines,
  parseJsonAfterMarker,
  validateExecutorResult,
  buildExecutorPrompt,
};
