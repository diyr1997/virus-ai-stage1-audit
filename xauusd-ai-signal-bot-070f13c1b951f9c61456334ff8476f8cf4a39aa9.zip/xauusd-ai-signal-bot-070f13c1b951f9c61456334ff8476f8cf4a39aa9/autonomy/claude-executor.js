"use strict";

const { publishClaudeTask, importClaudeResult } = require("../ai-council-claude-bridge");
const {
  executorBranch,
  isForbiddenPath,
  dangerousAddedLines,
  validateExecutorResult,
  buildExecutorPrompt,
} = require("./claude-executor-core");

const GITHUB_TOKEN = String(process.env.GITHUB_REVIEW_TOKEN || "").trim();
const GITHUB_REPO = String(
  process.env.GITHUB_COUNCIL_REPO || "diyr1997/xauusd-ai-signal-bot"
).trim();
const DEFAULT_BRANCH = String(process.env.AUTONOMY_EXECUTOR_BASE_BRANCH || "main").trim();
const EXECUTOR_PHASE = "executor";
const REVIEW_CONTEXT_MAX_CHARS = Math.max(
  10_000,
  Math.min(60_000, Number(process.env.AUTONOMY_REVIEW_CONTEXT_MAX_CHARS || 55_000))
);

function repoParts() {
  const [owner, repo] = GITHUB_REPO.split("/");
  if (!owner || !repo) throw new Error("GITHUB_COUNCIL_REPO must be owner/repo");
  return { owner, repo };
}

async function gh(path, options = {}) {
  if (!GITHUB_TOKEN) throw new Error("GITHUB_REVIEW_TOKEN is not configured");
  const response = await fetch(`https://api.github.com${path}`, {
    ...options,
    headers: {
      accept: "application/vnd.github+json",
      authorization: `Bearer ${GITHUB_TOKEN}`,
      "x-github-api-version": "2022-11-28",
      "user-agent": "virus-ai-autonomy-executor",
      ...(options.headers || {}),
    },
  });
  const raw = await response.text();
  let data = null;
  if (raw) {
    try { data = JSON.parse(raw); } catch { data = raw; }
  }
  if (!response.ok) {
    const error = new Error(`GitHub API ${response.status}: ${String(data?.message || raw).slice(0, 500)}`);
    error.statusCode = response.status;
    error.responseData = data;
    throw error;
  }
  return data;
}

async function branchHead(branch = DEFAULT_BRANCH) {
  const { owner, repo } = repoParts();
  const data = await gh(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/branches/${encodeURIComponent(branch)}`
  );
  const sha = String(data?.commit?.sha || "");
  if (!/^[0-9a-f]{40}$/i.test(sha)) throw new Error(`Invalid head SHA for branch ${branch}`);
  return sha.toLowerCase();
}

async function compareRefs(baseSha, headSha) {
  const { owner, repo } = repoParts();
  return gh(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/compare/${encodeURIComponent(baseSha)}...${encodeURIComponent(headSha)}`
  );
}

function findingEvidence(state) {
  return (state?.items || [])
    .filter((entry) => entry?.evidence && String(entry.phase) === "0")
    .map((entry) => ({
      item_id: entry.id,
      title: entry.title,
      status: entry.status,
      evidence: entry.evidence,
    }));
}

function executorTaskId(item) {
  const attempt = Math.max(1, Number(item?.executor_attempt || item?.attempt || 1));
  return `AUTONOMY_EXEC_${String(item?.id || "ITEM").replace(/[^A-Za-z0-9_.-]+/g, "_")}_A${attempt}`.toUpperCase();
}

async function publishExecutorTask(item, state) {
  const baseSha = await branchHead(DEFAULT_BRANCH);
  const attempt = Math.max(1, Number(item?.executor_attempt || item?.attempt || 1));
  const branch = executorBranch(item.id, attempt);
  const taskId = executorTaskId({ ...item, executor_attempt: attempt });
  const prompt = buildExecutorPrompt({
    item,
    branch,
    baseSha,
    findings: findingEvidence(state),
  });

  await publishClaudeTask({
    taskId,
    phase: EXECUTOR_PHASE,
    taskType: "autonomy_executor",
    task: prompt,
    contextSnapshot: JSON.stringify({
      item_id: item.id,
      phase: item.phase,
      source_tracker: state?.source || {},
      policy: state?.policy || {},
      executor_attempt: attempt,
    }),
    peerResponses: [],
  });

  return { taskId, branch, baseSha, phase: EXECUTOR_PHASE, attempt };
}

function actualChangedFiles(compare) {
  return Array.isArray(compare?.files)
    ? [...new Set(compare.files.map((file) => String(file?.filename || "").trim()).filter(Boolean))]
    : [];
}

function diffSafety(compare) {
  const files = Array.isArray(compare?.files) ? compare.files : [];
  const forbidden = files
    .map((file) => String(file?.filename || "").trim())
    .filter((path) => path && isForbiddenPath(path));
  if (forbidden.length) return { ok: false, reason: "ACTUAL_FORBIDDEN_CHANGED_PATH", forbidden };

  const dangerous = [];
  for (const file of files) {
    const hits = dangerousAddedLines(file?.patch || "");
    if (hits.length) {
      dangerous.push({ filename: String(file?.filename || ""), lines: hits.slice(0, 20) });
    }
  }
  if (dangerous.length) {
    return { ok: false, reason: "REAL_TRADING_ENABLEMENT_IN_DIFF", dangerous };
  }
  return { ok: true };
}

function buildVerifiedDiffContext(compare, evidence) {
  const files = Array.isArray(compare?.files) ? compare.files : [];
  const compact = files.map((file) => ({
    filename: String(file?.filename || ""),
    status: String(file?.status || ""),
    additions: Number(file?.additions || 0),
    deletions: Number(file?.deletions || 0),
    changes: Number(file?.changes || 0),
    patch: String(file?.patch || "").slice(0, 14_000),
  }));
  return JSON.stringify(
    {
      verified_executor_evidence: evidence,
      github_compare: {
        status: String(compare?.status || ""),
        ahead_by: Number(compare?.ahead_by || 0),
        behind_by: Number(compare?.behind_by || 0),
        total_commits: Number(compare?.total_commits || 0),
        files: compact,
      },
    },
    null,
    2
  ).slice(0, REVIEW_CONTEXT_MAX_CHARS);
}

async function verifyExecutorResult({ item, taskId, branch, baseSha }) {
  const imported = await importClaudeResult({ taskId, phase: EXECUTOR_PHASE });
  if (!imported.success) return { ready: false, reason: imported.reason };

  const parsed = validateExecutorResult({
    text: imported.response,
    itemId: item.id,
    expectedBranch: branch,
    expectedBaseSha: baseSha,
  });
  if (!parsed.ok) return { ready: false, invalid: true, reason: parsed.reason, detail: parsed };

  const actualHead = await branchHead(branch);
  if (actualHead !== parsed.result.head_sha) {
    return { ready: false, invalid: true, reason: "BRANCH_HEAD_MISMATCH" };
  }

  const compare = await compareRefs(baseSha, actualHead);
  const status = String(compare?.status || "").toLowerCase();
  if (!['ahead', 'identical'].includes(status)) {
    return { ready: false, invalid: true, reason: `UNSAFE_COMPARE_STATUS:${status || 'unknown'}` };
  }
  if (status === "identical") {
    return { ready: false, invalid: true, reason: "NO_ACTUAL_DIFF" };
  }

  const files = actualChangedFiles(compare);
  if (!files.length) return { ready: false, invalid: true, reason: "NO_ACTUAL_CHANGED_FILES" };
  const safety = diffSafety(compare);
  if (!safety.ok) return { ready: false, invalid: true, ...safety };

  const reported = new Set(parsed.result.changed_files);
  const unreported = files.filter((path) => !reported.has(path));
  if (unreported.length) {
    return { ready: false, invalid: true, reason: "UNREPORTED_ACTUAL_CHANGED_FILES", unreported };
  }

  const evidence = {
    task_id: taskId,
    phase: EXECUTOR_PHASE,
    branch,
    base_sha: baseSha,
    head_sha: actualHead,
    compare_status: status,
    changed_files: files,
    tests: parsed.result.tests,
    summary: parsed.result.summary,
    rollback: parsed.result.rollback,
  };
  return {
    ready: true,
    evidence,
    reviewContext: buildVerifiedDiffContext(compare, evidence),
  };
}

async function mergeVerifiedBranch({ branch, baseSha, headSha, itemId }) {
  const currentMain = await branchHead(DEFAULT_BRANCH);
  if (currentMain !== String(baseSha).toLowerCase()) {
    return { merged: false, retryable: true, reason: "BASE_BRANCH_ADVANCED", currentMain };
  }
  const actualBranchHead = await branchHead(branch);
  if (actualBranchHead !== String(headSha).toLowerCase()) {
    return { merged: false, retryable: true, reason: "EXECUTOR_BRANCH_ADVANCED" };
  }

  const compare = await compareRefs(baseSha, headSha);
  const safety = diffSafety(compare);
  if (!safety.ok) return { merged: false, retryable: false, ...safety };
  if (String(compare?.status || "").toLowerCase() !== "ahead") {
    return { merged: false, retryable: true, reason: "BRANCH_NOT_AHEAD_AT_MERGE" };
  }

  const { owner, repo } = repoParts();
  const merged = await gh(`/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/merges`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      base: DEFAULT_BRANCH,
      head: branch,
      commit_message: `autonomy: merge ${String(itemId)} after tests and Council gate`,
    }),
  });
  const mergeSha = String(merged?.sha || "").toLowerCase();
  if (!/^[0-9a-f]{40}$/i.test(mergeSha)) {
    return { merged: false, retryable: false, reason: "INVALID_MERGE_RESPONSE" };
  }
  const verifiedMain = await branchHead(DEFAULT_BRANCH);
  if (verifiedMain !== mergeSha) {
    return { merged: false, retryable: false, reason: "POST_MERGE_MAIN_MISMATCH", mergeSha, verifiedMain };
  }
  return { merged: true, mergeSha, mainSha: verifiedMain };
}

module.exports = {
  EXECUTOR_PHASE,
  DEFAULT_BRANCH,
  branchHead,
  compareRefs,
  findingEvidence,
  executorTaskId,
  publishExecutorTask,
  actualChangedFiles,
  diffSafety,
  buildVerifiedDiffContext,
  verifyExecutorResult,
  mergeVerifiedBranch,
};
