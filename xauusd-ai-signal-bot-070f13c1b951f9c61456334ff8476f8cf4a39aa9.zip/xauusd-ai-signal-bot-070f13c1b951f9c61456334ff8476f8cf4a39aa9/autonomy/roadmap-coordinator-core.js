"use strict";

const TERMINAL = new Set(["DONE", "BLOCKED"]);
const ACTIVE = new Set(["IN_PROGRESS", "REVIEW"]);
const EXECUTOR_CHECKS = ["CHECKED", "IMPLEMENTED", "TESTS_PASSED", "COUNCIL_PASSED"];

function normalizeStatus(value) {
  return String(value || "WAITING").trim().toUpperCase();
}

function itemMap(state) {
  return new Map((state?.items || []).map((item) => [String(item.id), item]));
}

function dependenciesDone(item, state) {
  const map = itemMap(state);
  return (item.dependencies || []).every((id) => normalizeStatus(map.get(String(id))?.status) === "DONE");
}

function phaseZeroDone(state) {
  const phase0 = (state?.items || []).filter((item) => String(item.phase) === "0");
  return phase0.length > 0 && phase0.every((item) => normalizeStatus(item.status) === "DONE");
}

function eligible(item, state) {
  const status = normalizeStatus(item.status);
  if (!["WAITING", "READY"].includes(status)) return false;
  if (!dependenciesDone(item, state)) return false;
  if (String(item.phase) !== "0" && !phaseZeroDone(state)) return false;
  return true;
}

function activeItem(state) {
  return (state?.items || []).find((item) => ACTIVE.has(normalizeStatus(item.status))) || null;
}

function nextItem(state) {
  if (activeItem(state)) return null;
  return [...(state?.items || [])]
    .sort((a, b) => Number(a.order || 0) - Number(b.order || 0))
    .find((item) => eligible(item, state)) || null;
}

function promoteReady(state) {
  for (const item of state?.items || []) {
    if (normalizeStatus(item.status) === "WAITING" && eligible(item, state)) {
      item.status = "READY";
    }
  }
  return state;
}

function parseExclusiveGate(text, marker) {
  const value = String(text || "");
  const safe = String(marker || "").replace(/[^A-Z0-9_]/gi, "");
  if (!safe) return "UNKNOWN";
  const pass = new RegExp(`${safe}\\s*[:=]\\s*PASS\\b`, "i").test(value);
  const blocked = new RegExp(`${safe}\\s*[:=]\\s*BLOCKED\\b`, "i").test(value);
  if (pass && !blocked) return "PASS";
  if (blocked && !pass) return "BLOCKED";
  return "UNKNOWN";
}

function parseFinalGate(text) {
  return parseExclusiveGate(text, "FINAL_GATE");
}

function parseImplementationGate(text) {
  return parseExclusiveGate(text, "IMPLEMENTATION_GATE");
}

function parseAuditGate(text) {
  const explicit = parseExclusiveGate(text, "AUDIT_GATE");
  if (explicit !== "UNKNOWN") return explicit;

  const value = String(text || "");
  const blockingPatterns = [
    /\bstatus\s*:\s*(?:partial|blocked|open|incomplete|not\s+complete)\b/i,
    /\btask\s+(?:is\s+)?not\s+complete\b/i,
    /\bcannot\s+be\s+marked\s+complete\b/i,
    /\b(?:item|audit|task)\b[^\n.]{0,80}\bremains?\s+open\b/i,
    /\bunresolved\s+(?:critical|high)(?:\s+severity)?\s+(?:issue|issues|blocker|blockers|defect|defects)\b/i,
    /\b(?:critical|high)\b[^\n.]{0,120}\bblock(?:s|ed|er|ers)?\b[^\n.]{0,80}\b(?:closure|completion|complete)\b/i,
    /\bblock(?:s|ed|er|ers)?\b[^\n.]{0,120}\b(?:closure|completion)\b/i,
  ];
  if (blockingPatterns.some((pattern) => pattern.test(value))) return "BLOCKED";
  return "LEGACY_PASS";
}

function readyAdvisorSet(snapshot) {
  return new Set((snapshot?.readyAdvisors || []).map((x) => String(x).trim().toLowerCase()).filter(Boolean));
}

function readyAdvisorCount(snapshot) {
  return readyAdvisorSet(snapshot).size;
}

function requiredAdvisorsReady(item, snapshot) {
  const required = (item?.required_advisors || [])
    .map((x) => String(x).trim().toLowerCase())
    .filter(Boolean);
  if (!required.length) return true;
  const ready = readyAdvisorSet(snapshot);
  return required.every((advisor) => ready.has(advisor));
}

function executorChecklistComplete(item) {
  if (!item?.requires_executor) return true;
  const checklist = item?.checklist || {};
  return EXECUTOR_CHECKS.every((key) => checklist[key] === true);
}

function canCloseAudit(item, snapshot, minReadyAdvisors = 2) {
  if (!snapshot?.task?.final_plan) return { ok: false, reason: "NO_SYNTHESIS" };
  if (readyAdvisorCount(snapshot) < Math.max(2, Number(minReadyAdvisors) || 2)) {
    return { ok: false, reason: "INSUFFICIENT_INDEPENDENT_ADVISORS" };
  }
  if (!requiredAdvisorsReady(item, snapshot)) {
    return { ok: false, reason: "REQUIRED_ADVISORS_NOT_READY" };
  }
  if (item?.requires_executor && !executorChecklistComplete(item)) {
    return { ok: false, reason: "EXECUTOR_EVIDENCE_INCOMPLETE" };
  }
  if (!item.requires_final_gate) {
    const auditGate = parseAuditGate(snapshot.task.final_plan);
    if (auditGate === "BLOCKED") {
      return { ok: false, blocked: true, reason: "AUDIT_SYNTHESIS_BLOCKED" };
    }
    return {
      ok: true,
      reason: auditGate === "PASS"
        ? "AUDIT_GATE_PASS"
        : item?.requires_executor
          ? "EXECUTOR_AND_COUNCIL_COMPLETE"
          : "AUDIT_EVIDENCE_COMPLETE",
    };
  }
  const gate = parseFinalGate(snapshot.task.final_plan);
  if (gate === "PASS") return { ok: true, reason: "FINAL_GATE_PASS" };
  if (gate === "BLOCKED") return { ok: false, blocked: true, reason: "FINAL_GATE_BLOCKED" };
  return { ok: false, reason: "FINAL_GATE_MISSING" };
}

// How many consecutive identical waits to tolerate before giving up and
// asking a human. At the default one-minute poll this is one hour.
const DEFAULT_MAX_CONSECUTIVE_WAITS = 60;

// A wait that repeats unchanged is not news. The coordinator used to write a
// state commit on every poll while a gate stayed unsatisfied, which pushed one
// commit per minute for as long as the condition held and fired a CI run for
// each. Track consecutive identical waits so a repeat stays silent, and so an
// unsatisfiable gate ends in BLOCKED instead of spinning forever.
//
//   "persist" - first time this reason appears; worth recording once
//   "quiet"   - same reason as last poll; nothing new to say, write nothing
//   "block"   - waited long enough; mark it blocked so a human sees it
function nextWaitState(previous, reason, maxWaits = DEFAULT_MAX_CONSECUTIVE_WAITS) {
  // A junk bound (0, negative, NaN) falls back to the default rather than to 1:
  // a typo in the env var must not block every item on its first poll.
  const parsed = Number(maxWaits);
  const limit =
    Number.isFinite(parsed) && parsed >= 1
      ? Math.floor(parsed)
      : DEFAULT_MAX_CONSECUTIVE_WAITS;
  const same = Boolean(previous) && previous.reason === reason;
  const count = same ? Math.max(0, Number(previous.count) || 0) + 1 : 1;
  const action = count >= limit ? "block" : same ? "quiet" : "persist";
  return { reason, count, action };
}

function allDone(state) {
  return (state?.items || []).length > 0 && (state.items || []).every((item) => normalizeStatus(item.status) === "DONE");
}

module.exports = {
  DEFAULT_MAX_CONSECUTIVE_WAITS,
  nextWaitState,
  TERMINAL,
  ACTIVE,
  EXECUTOR_CHECKS,
  normalizeStatus,
  dependenciesDone,
  phaseZeroDone,
  eligible,
  activeItem,
  nextItem,
  promoteReady,
  parseExclusiveGate,
  parseFinalGate,
  parseImplementationGate,
  parseAuditGate,
  readyAdvisorSet,
  readyAdvisorCount,
  requiredAdvisorsReady,
  executorChecklistComplete,
  canCloseAudit,
  allDone,
};
