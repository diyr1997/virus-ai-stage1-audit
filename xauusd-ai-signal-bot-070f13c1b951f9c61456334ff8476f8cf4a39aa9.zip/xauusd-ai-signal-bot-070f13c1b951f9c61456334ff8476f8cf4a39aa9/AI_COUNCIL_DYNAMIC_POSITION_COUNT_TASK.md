# AI Council Task — Remove Fixed Position Count Cap Safely

## User intent
The user wants the fixed maximum number of entries/positions removed across ALL DEMO risk profiles. The current hard cap of 5 positions must not remain as the primary limiter.

This is DEMO-only. Do not enable REAL trading.

## Desired behavior
- One initial entry for the active XAU/USD / GOLD# directional basket.
- Every later same-side order is an ADD, even when it comes from another timeframe/candidate.
- There is no fixed count such as 2, 3, 4, or 5 that stops further additions.
- A 6th, 7th, 10th, etc. add may be allowed only when the dynamic safety/risk conditions still permit it.
- Never maintain bot BUY and SELL positions simultaneously.
- Existing strength lot ladder remains a per-new-order maximum unless the council finds a strong reason to redesign it separately.

## Dynamic conditions that MUST remain or become stronger
The absence of a fixed position-count cap must NOT mean uncontrolled order spam. New adds should still require, at minimum:
1. DEMO account guard.
2. Same-side basket only.
3. Existing basket genuinely profitable using executable exit side (BID for BUY, ASK for SELL), spread included.
4. Favorable price progress before every add.
5. Global symbol entry gap / anti-burst protection.
6. Balance/equity/margin/free-margin checks.
7. Portfolio risk limit.
8. Basket/scenario risk limit that cannot be reset by creating a new candidate or timeframe.
9. Fresh closed-M1 / market-state guards.
10. Broker volume/margin/order constraints.

## Known architecture findings that must be reviewed together
Do not simply delete `min(5, ...)` and call the task complete.

A. `RISK_PROFILES` currently contains `max_positions`, and old code also has hard `min(5, profile["max_positions"])` behavior.

B. Impulse Entry Guard V3 correctly turns a new TF/candidate into an ADD when a same-side basket already exists, but parts of the underlying trader still use candidate-local accounting.

C. `slot_no` / TP selection is currently candidate-local. A later global basket add from a new candidate can appear as slot 1 for that candidate and receive first-slot TP semantics. Propose a global basket position/add index.

D. Scenario risk currently uses `candidate_id` via `candidate_trades(...)`. A new same-direction candidate can therefore obtain another scenario budget even though V3 treats it as an ADD to the same impulse basket. Propose a basket-level risk identity/accounting model before removing the count cap.

E. `worker_auto.py` currently has no explicit single-instance / distributed ownership lock. Two workers started from different folders/computers can race. Propose a robust single-active-worker mechanism, preferably PostgreSQL advisory lock/lease with heartbeat, that works across machines and releases safely after crash.

F. There are two V3 patch implementations (`patch_impulse_entry_guard_v3.py` and `apply_impulse_entry_guard_v3.py`). Propose one source of truth to prevent drift.

G. Existing CI mostly proves the V3 patch compiles/contains markers. Add behavioral tests for the actual trading invariants.

## Required council workflow
Each available advisor must first review independently, then peer-review the others.

Before any trading-code change, answer:
- Is removing the fixed position-count cap compatible with current risk architecture?
- What must be fixed FIRST so a new candidate/TF cannot reset risk or slot numbering?
- What exact basket identity should be used: symbol+side, active impulse id, parent scenario id, or another design?
- How should dynamic add progression scale when position count becomes large without relying on a numeric cap?
- Should required price progress increase linearly, nonlinearly, volatility-adjusted, or via risk usage? Give measurable rules to test, not intuition only.
- How do we prevent two worker processes from creating the same first/add order?
- Which files should change and which should remain untouched?
- What database/schema migration is needed, if any?
- What tests must pass before DEMO rollout?
- What telemetry/events should prove that unlimited-count mode is behaving safely?
- What is the rollback plan?

## Mandatory behavioral tests
At least cover:
1. Two fresh same-side candidates on different TFs at the same moment -> only one initial order.
2. Same-side second candidate while basket is losing -> no add.
3. Same-side second candidate while basket is profitable but price progress too small -> no add.
4. Same-side second candidate with enough profit/progress -> treated as global ADD #2, not candidate slot #1.
5. Sixth and later adds are not blocked merely because count >5.
6. Sixth/later add is blocked when basket/portfolio risk is exhausted.
7. New candidate cannot reset basket scenario-risk budget.
8. Opposite signal while same-side basket exists -> blocked under current V3 policy.
9. Two worker processes race for first entry -> exactly one wins ownership/order claim.
10. Crash/restart -> ownership lock recovers and no duplicate order is emitted.
11. DEMO guard remains absolute.
12. Margin/free-margin reserve remains enforced.

## Output format
Return:
- recommendation
- architecture
- exact_files_to_change
- schema_changes
- dynamic_add_rule
- risks
- behavioral_tests
- telemetry
- rollout_plan
- rollback
- disagreements/unknowns

Do not modify production trading logic automatically. Produce the joint design/review first; implementation follows only after reconciliation and tests.
