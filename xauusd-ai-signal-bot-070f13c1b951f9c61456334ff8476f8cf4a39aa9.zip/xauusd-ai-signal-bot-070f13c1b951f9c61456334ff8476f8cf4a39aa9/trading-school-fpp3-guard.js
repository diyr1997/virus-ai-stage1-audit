"use strict";

/**
 * FPP3 crawler recovery guard.
 *
 * Scope is intentionally narrow: only https://otexts.com/fpp3/* requests and
 * only Trading School rows with book_key='fpp3'. It never touches signal,
 * trading, risk, model or live-news code.
 */

const { Pool } = require("pg");
const {
  DEFAULT_FPP3_FETCH_GAP_MS,
  canonicalizeFpp3Url,
  isTextualContentType,
  visibleTextLength,
  fpp3WaitMs,
} = require("./trading-school-fpp3-policy");

const DATABASE_URL = String(
  process.env.DATABASE_URL || process.env.DATABASE_PUBLIC_URL || ""
).trim();
const FETCH_GAP_MS = Math.max(
  1000,
  Number(process.env.TRADING_SCHOOL_FPP3_FETCH_GAP_MS || DEFAULT_FPP3_FETCH_GAP_MS)
);
const RECONCILE_MS = Math.max(
  10_000,
  Number(process.env.TRADING_SCHOOL_FPP3_RECONCILE_MS || 30_000)
);
const START_DELAY_MS = Math.max(
  5_000,
  Number(process.env.TRADING_SCHOOL_FPP3_GUARD_START_DELAY_MS || 20_000)
);
const RETRY_STATE_KEY = "fpp3_recovery_v1";
const MAX_RECOVERY_RETRIES_PER_PAGE = 1;

const pool = DATABASE_URL
  ? new Pool({ connectionString: DATABASE_URL, max: 1, idleTimeoutMillis: 30_000 })
  : null;

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function inputUrl(input) {
  if (typeof input === "string" || input instanceof URL) return String(input);
  if (input && typeof input.url === "string") return input.url;
  return String(input || "");
}

function isFpp3Candidate(raw) {
  try {
    const u = new URL(raw);
    return u.hostname.toLowerCase() === "otexts.com" && u.pathname.startsWith("/fpp3");
  } catch {
    return false;
  }
}

function classifyFpp3Pages(rows, retriedPageIds = []) {
  const retried = new Set((retriedPageIds || []).map((x) => Number(x)));
  const nonContent = [];
  const retryableErrors = [];
  const blockedErrors = [];
  const canonicalPending = [];
  const canonicalIngested = [];

  for (const row of rows || []) {
    const id = Number(row.id);
    const canonical = canonicalizeFpp3Url(row.url);
    if (!canonical) {
      if (String(row.status) !== "INGESTED") nonContent.push(id);
      continue;
    }
    const status = String(row.status || "").toUpperCase();
    if (status === "ERROR") {
      if (retried.has(id)) blockedErrors.push(id);
      else retryableErrors.push(id);
    } else if (status === "PENDING") {
      canonicalPending.push(id);
    } else if (status === "INGESTED") {
      canonicalIngested.push(id);
    }
  }

  return {
    nonContent,
    retryableErrors,
    blockedErrors,
    canonicalPending,
    canonicalIngested,
    complete:
      retryableErrors.length === 0 &&
      blockedErrors.length === 0 &&
      canonicalPending.length === 0 &&
      canonicalIngested.length > 0,
  };
}

let lastFpp3FetchAt = 0;
let fpp3FetchChain = Promise.resolve();
let fetchPatched = false;

function installFetchGuard() {
  if (fetchPatched || typeof global.fetch !== "function") return;
  const originalFetch = global.fetch.bind(global);

  global.fetch = function guardedFetch(input, init) {
    const raw = inputUrl(input);
    if (!isFpp3Candidate(raw)) return originalFetch(input, init);

    const task = fpp3FetchChain.then(async () => {
      const canonical = canonicalizeFpp3Url(raw);
      if (!canonical) {
        throw new Error(`FPP3_NON_CONTENT_URL url=${raw.slice(0, 500)}`);
      }

      const waitMs = fpp3WaitMs(lastFpp3FetchAt, Date.now(), FETCH_GAP_MS);
      if (waitMs > 0) await sleep(waitMs);
      lastFpp3FetchAt = Date.now();

      const response = await originalFetch(canonical, init);
      const contentType = String(response.headers?.get?.("content-type") || "");
      const finalUrl = String(response.url || canonical);
      const finalCanonical = canonicalizeFpp3Url(finalUrl);
      if (!finalCanonical || finalCanonical !== canonical) {
        throw new Error(
          `FPP3_REDIRECT_BLOCKED url=${canonical} final_url=${finalUrl.slice(0, 500)} status=${response.status}`
        );
      }
      if (!response.ok) {
        throw new Error(
          `FPP3_HTTP_ERROR url=${canonical} status=${response.status} content_type=${contentType.slice(0, 120)}`
        );
      }
      if (!isTextualContentType(contentType)) {
        throw new Error(
          `FPP3_NON_TEXT_RESPONSE url=${canonical} status=${response.status} content_type=${contentType.slice(0, 120)}`
        );
      }

      const body = await response.text();
      const rawChars = String(body || "").length;
      const visibleChars = visibleTextLength(body);
      if (rawChars < 300 || visibleChars < 300) {
        throw new Error(
          `FPP3_SHORT_VISIBLE_RESPONSE url=${canonical} status=${response.status} content_type=${contentType.slice(0, 120)} raw_chars=${rawChars} visible_chars=${visibleChars}`
        );
      }

      return new Response(body, {
        status: response.status,
        statusText: response.statusText,
        headers: response.headers,
      });
    });

    fpp3FetchChain = task.catch(() => {});
    return task;
  };

  fetchPatched = true;
  console.log(`📚 FPP3 GUARD: fetch policy active | gap_ms=${FETCH_GAP_MS}`);
}

function retryIdsFromMeta(meta) {
  const state = meta?.[RETRY_STATE_KEY] || {};
  return Array.isArray(state.retried_page_ids) ? state.retried_page_ids : [];
}

async function reconcileFpp3() {
  if (!pool) return null;
  const bookResult = await pool.query(
    `SELECT meta FROM trading_school_books WHERE book_key='fpp3' LIMIT 1`
  );
  if (!bookResult.rows[0]) return null;

  const meta = bookResult.rows[0].meta || {};
  const previousRetried = retryIdsFromMeta(meta).map(Number);
  const pagesResult = await pool.query(
    `SELECT id,url,status,char_count,error
     FROM trading_school_pages
     WHERE book_key='fpp3'
     ORDER BY seq,id`
  );
  const plan = classifyFpp3Pages(pagesResult.rows, previousRetried);

  if (plan.nonContent.length) {
    await pool.query(
      `UPDATE trading_school_pages
       SET status='SKIPPED',error='FPP3_NON_CONTENT_URL',updated_at=NOW()
       WHERE book_key='fpp3' AND id = ANY($1::bigint[]) AND status<>'INGESTED'`,
      [plan.nonContent]
    );
  }

  // A page that already spent its single recovery retry and still fails is
  // permanently unreachable. Leaving it in ERROR kept `complete` false on
  // every pass, which re-DEFERRED all fpp3 chunks each reconcile and held the
  // whole 171-page book hostage to a handful of dead URLs. Retire them to a
  // terminal state (SKIPPED + explicit reason) so the rest of the book can
  // finish; the reason string keeps the loss visible instead of silent.
  if (plan.blockedErrors.length) {
    await pool.query(
      `UPDATE trading_school_pages
       SET status='SKIPPED',error='FPP3_RETRY_EXHAUSTED',updated_at=NOW()
       WHERE book_key='fpp3' AND id = ANY($1::bigint[]) AND status='ERROR'`,
      [plan.blockedErrors]
    );
  }

  const newlyRetried = plan.retryableErrors.slice();
  if (newlyRetried.length) {
    await pool.query(
      `UPDATE trading_school_pages
       SET status='PENDING',error=NULL,updated_at=NOW()
       WHERE book_key='fpp3' AND id = ANY($1::bigint[]) AND status='ERROR'`,
      [newlyRetried]
    );
  }

  const retried = [...new Set([...previousRetried, ...newlyRetried])].sort((a, b) => a - b);
  const state = {
    max_recovery_retries_per_page: MAX_RECOVERY_RETRIES_PER_PAGE,
    retried_page_ids: retried,
    last_reconciled_at: new Date().toISOString(),
  };
  await pool.query(
    `UPDATE trading_school_books
     SET meta=jsonb_set(meta,$1::text[],$2::jsonb,true),updated_at=NOW()
     WHERE book_key='fpp3'`,
    [[RETRY_STATE_KEY], JSON.stringify(state)]
  );

  const afterRows = pagesResult.rows.map((row) => {
    if (newlyRetried.includes(Number(row.id))) return { ...row, status: "PENDING", error: null };
    if (plan.nonContent.includes(Number(row.id)) && String(row.status) !== "INGESTED") {
      return { ...row, status: "SKIPPED", error: "FPP3_NON_CONTENT_URL" };
    }
    if (plan.blockedErrors.includes(Number(row.id))) {
      return { ...row, status: "SKIPPED", error: "FPP3_RETRY_EXHAUSTED" };
    }
    return row;
  });
  const after = classifyFpp3Pages(afterRows, retried);

  if (!after.complete) {
    await pool.query(
      `UPDATE trading_school_chunks
       SET ai_status='DEFERRED',updated_at=NOW()
       WHERE book_key='fpp3' AND ai_status IN('PENDING','RETRY')`
    );
    await pool.query(
      `UPDATE trading_school_books SET status='READING',updated_at=NOW() WHERE book_key='fpp3'`
    );
  } else {
    await pool.query(
      `UPDATE trading_school_chunks
       SET ai_status='PENDING',updated_at=NOW()
       WHERE book_key='fpp3' AND ai_status='DEFERRED'`
    );
    // The guard is what forced READING above, so the guard must release it.
    // Without this the book stays READING forever and the reader's whole-book
    // synthesis (which only looks at INGESTED books) never runs.
    await pool.query(
      `UPDATE trading_school_books
       SET status='INGESTED',updated_at=NOW()
       WHERE book_key='fpp3' AND status='READING'`
    );
  }

  if (plan.nonContent.length || newlyRetried.length || plan.blockedErrors.length) {
    console.log(
      `📚 FPP3 GUARD: non_content=${plan.nonContent.length} retried=${newlyRetried.length} retired=${plan.blockedErrors.length} blocked_errors=${after.blockedErrors.length} pending=${after.canonicalPending.length} complete=${after.complete}`
    );
  }
  return after;
}

async function reconcileSafe() {
  try {
    await reconcileFpp3();
  } catch (error) {
    console.warn(`📚 FPP3 GUARD RECONCILE: ${String(error?.message || error).slice(0, 700)}`);
  }
}

installFetchGuard();
if (pool) {
  const timer = setTimeout(() => {
    reconcileSafe();
    setInterval(reconcileSafe, RECONCILE_MS).unref();
  }, START_DELAY_MS);
  timer.unref();
}

module.exports = {
  installFetchGuard,
  classifyFpp3Pages,
  reconcileFpp3,
  retryIdsFromMeta,
};
