# VIRUS AI external AI toolbox — priority run order

> **Ported 2026-09-15 from `ai/integrate-agent-toolbox-2026-09-10` onto the PR
> branch `claude/toolbox-master-completion-2026-09-15` (PR #225). Not on `main`
> until that PR is merged.**
> The run order below is still the intended sequence, but stage 2 (OmniRoute)
> and stage 3 (AI System Architect) did **not** pass re-verification on
> 2026-09-15: OmniRoute's compression could not be confirmed in a fresh default
> install and no real completion was obtained, and the Architect has still never
> produced one real project review. Do not treat either as a completed stage.
> `bootstrap.sh` was reviewed on 2026-09-15 (no secrets, no `curl|bash`, no
> sudo; its single `rm -rf` is scoped to the clone target directory) but was
> **not executed** — the tools that matter were tested individually instead.
> Current status: `AI_TOOLBOX_MASTER_INVENTORY_2026-09-15.json`.

This is the current usefulness order chosen for the isolated VIRUS AI agent lab. The original 13-link submission order remains unchanged in `manifest.json`. No selected repository is discarded.

## Boot guard — NVIDIA SkillSpector

SkillSpector may run before the numbered stages as a non-LLM security preflight. It is not part of the usefulness ranking and receives no trading authority.

## 1. Ponytail — reduce unnecessary work first

Activate Ponytail before model-driven engineering work. Its role is to reuse existing code, avoid unnecessary dependencies/abstractions and produce the smallest correct verified change without removing validation, security, error handling or other required safeguards. Token/cost reduction is an observed side effect in its own benchmark, not a guaranteed compression ratio for every model.

## 2. OmniRoute — compression + free/cheap routing

Start OmniRoute locally in the isolated lab and verify stacked compression through the authenticated REST API. For the architect, intersect free-tier eligibility and no-credential metadata with the live `prefix=dual` model catalog. Match `owned_by` and `root`, then call the exact advertised provider-prefixed ID. Do not assume an `auto` combo is free or that a catalog budget is accessible quota. This layer is for AI-provider cost/quota efficiency only; it is not a trading-decision engine and cannot place orders.

UncloseAI's hosted model changes independently of OmniRoute's curated catalog. When that provider is already eligible and enabled, refresh its single hosted model from its public `/v1/models`, import it through the authenticated local model API, and require it to appear in the gateway catalog. This provider-specific free-access rule is grounded in [UncloseAI's service description](https://uncloseai.com/) and [model-discovery instructions](https://uncloseai.com/inference.html), checked 2026-09-10. The gateway credential is never sent to the public discovery endpoint. This rule grants no access or free allowance to other providers.

For a Qwen3.6 model on that vLLM endpoint, bounded text requests use the [model author's documented non-thinking option](https://huggingface.co/Qwen/Qwen3.6-27B#using-qwen36-via-the-chat-completions-api), `chat_template_kwargs.enable_thinking=false`. Truncation, refusal and incomplete responses remain distinct failures, never a successful report.

## 3. AI System Architect — project direction

Use the `AI System Architect Advisor` component from `Shubhamsaboo/awesome-llm-apps` as the architecture reference. Its upstream application is DeepSeek+Anthropic credential-specific, so when those separate credentials are unavailable in the isolated lab, keep the upstream file unchanged, compile-check it, and run the project architecture prompt through the local OmniRoute OpenAI-compatible endpoint. The bridge must read `AGENTS.md`, `CONTEXT.md`, and Ponytail rules and save/print the architecture report. Model output is advisory and is never auto-executed.

The first architect task is:

> Read the operating contract and canonical VIRUS AI context. Determine the safest useful order for the remaining external tools. Identify the highest-value next changes for improving XAU/USD signal quality without look-ahead, fake accuracy or ignored execution costs. Preserve BUY/SELL/WAIT, as-of integrity, untouched holdout, calibration, fail-closed safety and Research -> Challenger -> Validation -> DEMO/Shadow -> Champion. For every step state dependencies, exact project area, executable test, measurable acceptance criterion, rollback boundary and what remains unverified. Do not enable REAL trading.

## Remaining tools after architect review

Keep the user-approved order below. A code-only Graphify extraction may collect deterministic repository evidence after the architect attempt while that review remains blocked; it does not complete or accept stage 3. Installation/import smoke checks in the inventory runner likewise do not count as functional acceptance of later stages.

1. Graphify — repository architecture map (use `--code-only` if no semantic-model key is present).
2. Matt Pocock Skills — wayfinding, diagnosis, TDD, code review and architecture improvement.
3. Google Skills — solution architecture, reliability, security, performance and cost review.
4. Andrej Karpathy Skills — assumptions, simplicity and goal-driven verification.
5. Strix — authorized app-security testing; full dynamic mode only on an approved Docker-capable runner.
6. DeepSeek Harness — disposable least-privilege orchestration experiments.
7. Anthropic Skills — reusable technical/document workflows.
8. AirLLM — package/import test now; meaningful large-model work only on suitable storage/hardware.
9. Humanizer — human-facing prose only; never rewrite numeric audit/trading evidence.
10. SkillSpector — ongoing scans of external skill payloads.

## Universal execution policy

- Integration branch only; `main` stays untouched.
- REAL trading disabled.
- No production secrets in prompts or logs.
- Missing credentials/hardware/runtime are explicit blockers, never fake PASS results.
- External advisors do not become a live-trade voting committee.
- No model-generated shell command is executed merely because an advisor suggested it; recommendations are reviewed and translated into bounded deterministic steps/tests first.
