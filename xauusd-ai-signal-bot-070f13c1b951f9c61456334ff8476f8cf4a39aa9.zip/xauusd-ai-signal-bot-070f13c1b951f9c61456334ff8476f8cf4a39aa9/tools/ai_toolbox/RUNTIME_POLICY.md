# AI Toolbox runtime policy

This integration branch is executed only in an isolated development/audit service.

- No production credentials are injected by default.
- No REAL trading is authorized.
- Third-party tools use dedicated Python virtual environments or local Node prefixes where possible.
- Dynamic security testing targets only project-owned/authorized assets.
- Missing Docker/GPU/model/API credentials are reported as explicit capability gates, not disguised as successful functional tests.
- The branch is not merged into `main` until the integration ledger has been reviewed.
