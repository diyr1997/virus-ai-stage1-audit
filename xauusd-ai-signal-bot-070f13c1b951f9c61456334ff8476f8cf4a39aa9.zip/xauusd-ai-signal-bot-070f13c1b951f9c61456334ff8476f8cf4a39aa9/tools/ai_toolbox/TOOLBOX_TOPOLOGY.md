# VIRUS AI GitHub toolbox topology

> **Ported 2026-09-15 from `ai/integrate-agent-toolbox-2026-09-10` onto the PR
> branch `claude/toolbox-master-completion-2026-09-15` (PR #225). Not on `main`
> until that PR is merged.**
> This file describes the *intended role map*. Several role assignments below
> were written before the tools were independently re-verified and are now
> contradicted by evidence — read `PROJECT_STATE.md` and
> `AI_TOOLBOX_MASTER_INVENTORY_2026-09-15.json` for current status. Specifically:
> **AI System Architect is BLOCKED** (it has never produced one real project
> review), **OmniRoute compression is unverified in a fresh default install**
> (`compression status` → HTTP 503, MCP server disabled) and it has never
> returned a real completion here, and **DeepSeek Harness remains an isolated
> candidate only**. Graphify is verified working (3841 nodes / 9160 edges on this
> repo, 2026-09-15). Treat the role map as design intent, not as current state.

This file defines **roles**, not a popularity ranking. It was derived from the upstream README/skill descriptions of every repository registered in `tools/ai_toolbox/manifest.json` and from the current VIRUS AI operating contract.

No external tool receives REAL-trading authority. Security findings remain fail-closed. A tool being installed does not mean it is trusted, promoted, or allowed to execute arbitrary actions.

## Control-plane decision

A single tool should not both plan, orchestrate, remember, inspect, and approve itself. VIRUS AI therefore uses a small control plane with separate responsibilities:

1. **Primary planning brain — AI System Architect (Awesome LLM Apps)**
   - Reads canonical project state and evidence.
   - Produces dependency-aware plans, role assignments, tests, rollback boundaries, and unresolved questions.
   - Does not execute its own recommendations and cannot approve itself.

2. **Execution-orchestrator candidate — DeepSeek Harness**
   - Best fit among the installed repositories for hosting many tools because its upstream architecture is explicitly `everything-is-a-plugin`.
   - Treat as an isolated **candidate**, not production authority: upstream labels it developer preview and warns that compatibility-breaking changes will occur.
   - It may dispatch approved development/audit jobs only after deterministic preflight and safety checks.

3. **Knowledge/dependency mesh — Graphify**
   - Builds a persistent graph over project files and code relationships.
   - `graph.json` is the structural web: modules, symbols, dependencies, paths, high-degree nodes, and cross-file relationships.
   - Refresh before architecture review and after meaningful code changes. Prefer code-only deterministic extraction when no semantic-model credential is available.

4. **Routing/backbone + optional conversational memory — OmniRoute**
   - One gateway for model/provider routing, fallback, quotas, compression, MCP/A2A/REST access, audit surfaces, and optional persistent memory.
   - Its memory is supplementary, not the canonical project record. Memory is opt-in upstream and may add context/token cost.

5. **Durable project memory — GitHub state artifacts**
   - `CONTEXT.md`: durable domain rules, architecture, terminology, and non-negotiable constraints.
   - `PROJECT_STATE.md`: current phase, last verified work, blockers, active experiment, next action, and resume cursor.
   - `Wayfinder` concept from Matt Pocock Skills: long-running work map for efforts larger than one agent session; decisions are stored in the issue tracker.
   - `handoff` concept from Matt Pocock Skills: compact session-to-session transfer artifact. Upstream writes it to a temporary directory, so VIRUS AI does **not** rely on that location for cloud durability; the durable equivalent is `PROJECT_STATE.md` plus GitHub issues/commits.

6. **Security gate — NVIDIA SkillSpector**
   - Scans external agent skills/MCP payloads and returns structured risk evidence.
   - Runs before activation and again after upstream changes.
   - Scanner findings require review; a clean exit code alone is not equivalent to full safety.

7. **Coding discipline — Ponytail + Andrej Karpathy Skills**
   - Ponytail: reuse before writing, minimum necessary implementation, no removal of safety/validation.
   - Karpathy-inspired rules: expose assumptions, keep code simple, make surgical changes, define measurable success criteria.
   - These are guardrails around work, not the project brain.

## Specialist roles

| Tool | Primary specialization | VIRUS AI role |
|---|---|---|
| Strix | Dynamic AI-assisted application pentesting, exploit validation, remediation | Authorized security testing only; agent-skill activation remains isolated until security review is acceptable |
| Andrej Karpathy Skills | Assumption management, simplicity, surgical edits, goal-driven verification | Always-on engineering discipline where safely available |
| AirLLM | Very-low-VRAM inference/training by streaming large-model layers | Hardware-specific model experiments; not orchestration or project memory |
| DeepSeek Harness | Plugin-based agent harness | Execution-orchestrator candidate in isolated development/audit environments |
| Google Skills | Large Google/Cloud/AI/infra/reliability/security skill catalog | Selective specialist workflows only; never load the whole pack blindly |
| Humanizer | Rewrite human-facing prose without changing meaning | Reports/docs only; never touch machine-readable trading evidence |
| NVIDIA SkillSpector | Security scanner for agent skills/MCP payloads | Pre-install and update security gate |
| Awesome LLM Apps | Library of agents/skills including System Architect, dependency/scope/self-improvement patterns | Source of the primary planning brain and selected specialist workflows |
| Anthropic Skills | Examples/specification for reusable task skills | Reference and selected workflows after security review; not control plane |
| Matt Pocock Skills | Engineering router, diagnosis, TDD, review, architecture improvement, handoff, Wayfinder | Multi-session planning/continuity and engineering workflows after safe activation/reimplementation |
| Graphify | Persistent multimodal/code knowledge graph | Structural dependency mesh and cross-session architecture map |
| OmniRoute | Multi-provider gateway, routing/fallback/compression/MCP/A2A/memory | Communications backbone and supplementary persistent memory |
| Ponytail | Minimal senior-engineering discipline | Guardrail before/around code generation and review |

## Required control flow

```text
USER INTENT
   |
   v
AGENTS.md + CONTEXT.md + PROJECT_STATE.md
   |
   v
SkillSpector gate / current trust state
   |
   v
Graphify refresh/query  ----> structural evidence
   |                              |
   +------------------------------+
   v
AI System Architect (planning brain)
   |
   v
bounded executable plan + acceptance checks
   |
   v
DeepSeek Harness candidate OR existing deterministic runner
   |
   +--> specialist tool(s) through isolated interfaces
   +--> OmniRoute only where an AI/provider call is actually required
   |
   v
TEST / MEASURE / COMPARE / FAIL-CLOSED
   |
   v
update PROJECT_STATE.md + issues/commits + Graphify
```

## Memory/resume protocol

Every engineering agent/session must begin with this sequence:

1. Read `AGENTS.md`.
2. Read `CONTEXT.md`.
3. Read `PROJECT_STATE.md`.
4. Read this topology file.
5. Verify the current Git branch/commit and live runtime facts instead of trusting old status prose.
6. Query/refresh Graphify when architecture or changed code matters.
7. Continue from `PROJECT_STATE.md -> Resume cursor`; do not restart completed work.
8. After a meaningful verified change, update the state artifact with evidence and the next cursor.

OmniRoute memory may supplement this protocol, but it must never override GitHub state artifacts, code, tests, current runtime evidence, or explicit user instructions.

## Promotion rule

A specialist may move from `source-only/isolate` to active use only when its relevant surface has passed the required security/compatibility checks. A tool may be useful even when only a subset of its capabilities is approved. Prefer narrow allowlists over activating an entire large skill pack.
