# QM — VIRUS AI toolbox evaluation

Repository: `https://github.com/yc-software/qm`

Status: `SERVICE_CREATED / START_NOT_VERIFIED / ISOLATED / NOT_PRODUCTION`

Reviewed: 2026-09-11

## Why it is useful

QM is a multi-agent work harness rather than a trading model. It can provide durable agent sessions/memory, isolated per-scope workspaces, background cron/watch/webhook work, and workflows that operate on repositories, tests, pull requests, CI and logs.

Potential VIRUS AI role:

`AI Council / developer request -> isolated QM worker -> repo task -> tests -> draft PR / report -> human/AI review`

## Verified from upstream source

- Open-source repository under MIT license.
- Supports multiple harnesses/models behind one core, including Claude Code, Codex and OpenCode.
- Uses Postgres for durable sessions/memory/queue when configured.
- Supports background cron/watch/webhook jobs.
- Supports repository workflows such as running tests, opening PRs, monitoring CI and checking logs.
- Upstream production deployment documentation expects a model-provider credential (Anthropic, OpenAI or OpenRouter) when a base model provider is configured.
- Upstream security documentation describes the software as early/experimental and lists known limitations, so it must remain outside the trading production perimeter until separately validated.

## Activation state

An isolated Railway toolbox service was created:

- Project: `virus-ai-agent-toolbox-20260910`
- Service: `qm-agent-harness`
- Service id: `2b250db7-1d13-4bc8-bcee-d8e509e6bd21`
- Base image: `node:24-slim`
- No MT5, Telegram, production Postgres, broker, or REAL-trading credentials were supplied.

The service configuration write succeeded. Follow-up Railway redeploy/status calls were rejected for the current connection with insufficient `member/viewer` role, so startup has not been verified and the service must not be labeled ACTIVE yet.

## Safety boundary

1. No MT5 credentials.
2. No REAL trading permissions.
3. No production Railway/Postgres/Telegram secrets.
4. Use disposable/test GitHub branches for first tasks.
5. First real task should be bounded: inspect code -> run tests -> create a draft PR/report -> verify audit trail.
6. Promote only after runtime boot and one real task are observed.

## Current verdict

Selected and added to the VIRUS AI toolbox. Activation has started in an isolated Railway service, but runtime startup remains unverified because of the current Railway permission blocker.
