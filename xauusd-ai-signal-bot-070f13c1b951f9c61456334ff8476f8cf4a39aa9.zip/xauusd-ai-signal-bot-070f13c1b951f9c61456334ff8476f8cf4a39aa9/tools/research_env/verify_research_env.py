#!/usr/bin/env python3
"""Deterministic verification of the pinned VIRUS AI research libraries.

Run after building the env from requirements.txt:

    python3 -m venv .venv-research
    .venv-research/bin/pip install -r tools/research_env/requirements.txt
    .venv-research/bin/python tools/research_env/verify_research_env.py

Exits non-zero if any library fails its test, so this can gate CI.

Every check below is deterministic (fixed seeds, known-answer inputs). Import
success alone is NOT treated as a pass -- each library must reproduce a known
result. This mirrors the project rule that "pip install" is not evidence a tool
works.

RESEARCH ONLY: none of these libraries may be wired into production trading,
execution, risk, or signal-emitting code paths.
"""
from __future__ import annotations

import json
import sys

results: dict[str, dict] = {}


def check_optuna() -> dict:
    """TPE must find the minimum of (x-2)^2 from a fixed seed."""
    import optuna

    optuna.logging.set_verbosity(optuna.logging.WARNING)
    study = optuna.create_study(
        direction="minimize", sampler=optuna.samplers.TPESampler(seed=42)
    )
    study.optimize(lambda t: (t.suggest_float("x", -10, 10) - 2) ** 2, n_trials=50)
    best = study.best_params["x"]
    return {
        "version": optuna.__version__,
        "best_x": best,
        "status": "PASS" if abs(best - 2) < 0.5 else "FAIL",
        "role": "research optimization inside purged/walk-forward only; "
                "the optimizer must never see the final holdout",
    }


def check_ruptures() -> dict:
    """PELT must recover known changepoints in a synthetic 4-segment signal."""
    import numpy as np
    import ruptures as rpt

    rng = np.random.RandomState(42)
    signal = np.concatenate([rng.normal(m, 0.5, 100) for m in (0, 5, -3, 8)])
    detected = rpt.Pelt(model="l2").fit(signal).predict(pen=5)
    expected = [100, 200, 300]
    ok = all(any(abs(d - e) <= 5 for d in detected) for e in expected)
    return {
        "version": rpt.__version__,
        "detected": detected,
        "expected_near": expected + [400],
        "status": "PASS" if ok else "FAIL",
        "role": "offline/rolling regime-change research detector; "
                "never a standalone trade signal",
    }


def check_purgedcv() -> dict:
    """PurgedKFold must leak zero overlapping labels across purge+embargo."""
    import numpy as np
    import pandas as pd
    import purgedcv
    from purgedcv import PurgedKFold

    n = 500
    idx = pd.date_range("2020-01-01", periods=n, freq="h")
    prediction_times = pd.Series(idx, index=idx)
    # each label resolves 3h later, so folds genuinely overlap without purging
    evaluation_times = pd.Series(idx + pd.Timedelta(hours=3), index=idx)

    splitter = PurgedKFold(
        n_splits=5,
        prediction_times=prediction_times,
        evaluation_times=evaluation_times,
        purge_horizon=pd.Timedelta(hours=3),
        embargo_fraction=0.01,
    )

    violations = 0
    checked = 0
    for train_idx, test_idx in splitter.split(np.zeros(n)):
        checked += len(test_idx)
        train_pred = prediction_times.iloc[train_idx]
        for start, end in zip(
            prediction_times.iloc[test_idx], evaluation_times.iloc[test_idx]
        ):
            violations += int(((train_pred >= start) & (train_pred <= end)).sum())

    return {
        "version": getattr(purgedcv, "__version__", "unknown"),
        "leakage_violations": violations,
        "test_rows_checked": checked,
        "status": "PASS" if violations == 0 else "FAIL",
        "role": "temporal leakage guard for optimizer/backtest/nested research; "
                "parity against the native validation stack still required before "
                "it replaces any existing purge/embargo implementation",
    }


CHECKS = {"optuna": check_optuna, "ruptures": check_ruptures, "purgedcv": check_purgedcv}

for name, fn in CHECKS.items():
    try:
        results[name] = fn()
    except Exception as exc:  # noqa: BLE001 - report, never mask, a failed check
        results[name] = {"status": "ERROR", "error": repr(exc)}

print(json.dumps(results, indent=2, default=str))

failed = [n for n, r in results.items() if r.get("status") != "PASS"]
if failed:
    print(f"\nFAILED: {', '.join(failed)}", file=sys.stderr)
    sys.exit(1)
print("\nAll research libraries reproduced their known-answer tests.")
