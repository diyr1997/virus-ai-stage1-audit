#!/usr/bin/env python3
"""Formula parity: orderflow-metrics (external) vs a hand-written canonical OFI.

IMPORTANT CONTEXT — there is deliberately NO native OFI in this project.
`trading_ai/sampled_quotes.py` documents "no forward fill, nearest-future lookup,
aggressor inference, OFI/CVD, or L2", and
`trading_ai/tests/test_sampled_quotes.py::test_names_do_not_claim_order_flow_or_realized_volatility`
actively asserts that no feature name may contain ofi / cvd / footprint /
aggressor / order_flow. That is a correct decision: the project only has sampled
L1 quotes, not true L2 or trade data, so it refuses to claim order-flow
semantics it cannot support.

So this is NOT "external vs native" — there is no native counterpart to compare
against. It is "external vs the canonical published formula", implemented here by
hand, to answer one narrower question: is the library's OFI arithmetic correct?

Canonical reference: Cont, Kukanov & Stoikov, "The Price Impact of Order Book
Events". For consecutive top-of-book snapshots (n-1, n):

    e_n = I{P_n^b >= P_{n-1}^b} * q_n^b  -  I{P_n^b <= P_{n-1}^b} * q_{n-1}^b
        - I{P_n^a <= P_{n-1}^a} * q_n^a  +  I{P_n^a >= P_{n-1}^a} * q_{n-1}^a

A passing formula test is NOT evidence of a trading edge, and adopting this
library would NOT license using order-flow feature names on sampled L1 data.

    .venv-research/bin/python tools/research_env/parity_orderflow_metrics.py

RESEARCH ONLY.
"""
from __future__ import annotations

import json
import random
import sys

from orderflow_metrics import L1Quote, depth_imbalance, ofi, ofi_contribution, ofi_series


def canonical_ofi(prev: L1Quote, curr: L1Quote) -> float:
    """Hand-written Cont-Kukanov-Stoikov top-of-book OFI. No library involved."""
    e = 0.0
    # bid side
    if curr.bid_price >= prev.bid_price:
        e += curr.bid_size
    if curr.bid_price <= prev.bid_price:
        e -= prev.bid_size
    # ask side
    if curr.ask_price <= prev.ask_price:
        e -= curr.ask_size
    if curr.ask_price >= prev.ask_price:
        e += prev.ask_size
    return e


def canonical_depth_imbalance(q: L1Quote) -> float:
    total = q.bid_size + q.ask_size
    return 0.0 if total == 0 else (q.bid_size - q.ask_size) / total


# ---- hand-checked fixtures: every book-event case the formula must distinguish
FIXTURES = [
    # (name, prev, curr)
    ("bid_up_ask_unchanged",   L1Quote(100.0, 5, 100.2, 7), L1Quote(100.1, 4, 100.2, 7)),
    ("bid_down",               L1Quote(100.0, 5, 100.2, 7), L1Quote(99.9, 6, 100.2, 7)),
    ("ask_down",               L1Quote(100.0, 5, 100.2, 7), L1Quote(100.0, 5, 100.1, 3)),
    ("ask_up",                 L1Quote(100.0, 5, 100.2, 7), L1Quote(100.0, 5, 100.3, 9)),
    ("both_unchanged_resize",  L1Quote(100.0, 5, 100.2, 7), L1Quote(100.0, 8, 100.2, 2)),
    ("spread_widens",          L1Quote(100.0, 5, 100.2, 7), L1Quote(99.8, 4, 100.4, 6)),
    ("spread_narrows",         L1Quote(100.0, 5, 100.4, 7), L1Quote(100.1, 4, 100.3, 6)),
    ("zero_sizes",             L1Quote(100.0, 0, 100.2, 0), L1Quote(100.0, 0, 100.2, 0)),
]

results = {"fixtures": [], "randomized": {}, "verdict": {}}
mismatches = 0

for name, prev, curr in FIXTURES:
    lib = ofi_contribution(prev, curr)
    ref = canonical_ofi(prev, curr)
    ok = abs(lib - ref) < 1e-9
    mismatches += 0 if ok else 1
    results["fixtures"].append(
        {"case": name, "library": lib, "canonical": ref, "match": ok}
    )

# randomized differential test
rng = random.Random(20260915)
rand_mismatch = 0
TRIALS = 5000
for _ in range(TRIALS):
    def q():
        bp = round(rng.uniform(99.0, 101.0), 2)
        return L1Quote(bp, rng.randint(0, 50), round(bp + rng.uniform(0.01, 0.5), 2), rng.randint(0, 50))
    a, b = q(), q()
    if abs(ofi_contribution(a, b) - canonical_ofi(a, b)) > 1e-9:
        rand_mismatch += 1

di_mismatch = 0
for _ in range(TRIALS):
    bp = round(rng.uniform(99.0, 101.0), 2)
    qq = L1Quote(bp, rng.randint(0, 50), round(bp + 0.02, 2), rng.randint(0, 50))
    if abs(depth_imbalance(qq) - canonical_depth_imbalance(qq)) > 1e-12:
        di_mismatch += 1

# cumulative check: ofi() over a sequence must equal the summed canonical steps
seq = [L1Quote(100.0, 5, 100.2, 7)]
for i in range(1, 60):
    bp = round(100.0 + rng.uniform(-0.3, 0.3), 2)
    seq.append(L1Quote(bp, rng.randint(1, 40), round(bp + rng.uniform(0.01, 0.3), 2), rng.randint(1, 40)))
cum_lib = ofi(seq)
cum_ref = sum(canonical_ofi(seq[i - 1], seq[i]) for i in range(1, len(seq)))
series_len_ok = len(ofi_series(seq)) == len(seq) - 1
cumulative_ok = abs(cum_lib - cum_ref) < 1e-9

results["cumulative"] = {
    "steps": len(seq) - 1,
    "library_cumulative_ofi": cum_lib,
    "canonical_cumulative_ofi": cum_ref,
    "match": cumulative_ok,
    "ofi_series_length_is_n_minus_1": series_len_ok,
}

results["randomized"] = {
    "trials": TRIALS,
    "ofi_mismatches": rand_mismatch,
    "depth_imbalance_mismatches": di_mismatch,
}

results["verdict"] = {
    "formula_matches_canonical": (
        mismatches == 0 and rand_mismatch == 0 and di_mismatch == 0
        and cumulative_ok and series_len_ok
    ),
    "native_counterpart_exists": False,
    "native_note": (
        "This project has no native OFI by design - sampled_quotes.py refuses aggressor "
        "inference/OFI/CVD/L2, and a test asserts feature names never claim them. Nothing here "
        "licenses relabelling sampled L1 features as order flow."
    ),
    "adoption": (
        "Formula reference only. Correct arithmetic is not a trading edge, and real OFI needs true "
        "L1/L2 depth we do not currently have for XAUUSD. Revisit for Binance, where real book data exists."
    ),
    "packaging_note": (
        "Installed as orderflow-metrics==0.29.0 but the module reports __version__ = 0.15.0 - "
        "a metadata discrepancy worth pinning carefully."
    ),
}

print(json.dumps(results, indent=2))
sys.exit(0 if results["verdict"]["formula_matches_canonical"] else 1)
