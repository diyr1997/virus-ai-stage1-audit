#!/usr/bin/env python3
"""Parity check: purgedcv (external) vs the native VIRUS AI validation stack.

Question this answers: does adopting purgedcv duplicate what
`trading_ai.pipeline.chronological_split` / `trading_ai.walk_forward` already do,
or does it cover a leakage case the native stack structurally cannot?

Run from the repo root with the pinned research env:

    .venv-research/bin/python tools/research_env/parity_purgedcv_vs_native.py

Both validators are driven with the SAME samples and the SAME label horizon, and
leakage is counted with one shared, independent rule applied in BOTH directions
(forward = what a purge prevents, backward = what an embargo prevents). Neither
library's own accounting is trusted.

Result as of 2026-09-15: the native expanding-window stack leaks 0, and so does
purgedcv - so purgedcv is a DUPLICATE for the project's current design. But the
native purge-only rule transplanted into a k-fold layout leaks 60 backward
violations, which is precisely the case purgedcv's embargo covers. Adopt it when
(and only when) the project moves to k-fold / CPCV.

RESEARCH ONLY. This script does not touch production paths.
"""
from __future__ import annotations

import json
import sys

sys.path.insert(0, ".")

import numpy as np
import pandas as pd

from trading_ai.pipeline import TrainingSample, chronological_split
from purgedcv import PurgedKFold

BAR_MS = 60_000          # M1
HORIZON = 15             # label looks 15 bars ahead
N = 600


def make_samples(n: int = N, horizon: int = HORIZON) -> list[TrainingSample]:
    """Samples whose labels genuinely overlap the next `horizon` bars."""
    rng = np.random.RandomState(7)
    out = []
    for i in range(n):
        out.append(
            TrainingSample(
                end_timestamp_ms=(i + 1) * BAR_MS,
                features={"f": float(rng.normal())},
                future_returns={horizon: float(rng.normal() * 1e-4)},
                max_favorable_move=0.0,
                max_adverse_move=0.0,
            )
        )
    return out


def count_violations(train_ts, test_ts, horizon_ms: int) -> dict[str, int]:
    """Shared, validator-agnostic leakage rule, counted in BOTH directions.

    forward  (what a purge prevents): a TRAIN sample whose label window
             [ts, ts+horizon] reaches into the test fold's time span.
    backward (what an EMBARGO prevents): a TEST sample whose label window
             [ts, ts+horizon] reaches forward onto a TRAIN sample that sits
             after the fold. This only exists when train data follows the test
             fold, i.e. in k-fold/CPCV layouts - never in an expanding window.
    """
    if len(train_ts) == 0 or len(test_ts) == 0:
        return {"forward": 0, "backward": 0, "total": 0}
    lo, hi = min(test_ts), max(test_ts)
    forward = sum(1 for ts in train_ts if ts + horizon_ms >= lo and ts <= hi)
    backward = sum(
        1
        for tr in train_ts
        if tr > hi and any(te + horizon_ms >= tr for te in test_ts)
    )
    return {"forward": forward, "backward": backward, "total": forward + backward}


def total(v: dict[str, int]) -> int:
    return v["total"]


results: dict[str, object] = {}
horizon_ms = HORIZON * BAR_MS
samples = make_samples()

# ---------------------------------------------------------------- native
# chronological_split: one-shot train/validation/test with a left-side purge.
train, validation, test = chronological_split(samples)
native_train_ts = [s.end_timestamp_ms for s in train]
native_val_ts = [s.end_timestamp_ms for s in validation]
native_test_ts = [s.end_timestamp_ms for s in test]

results["native_chronological_split"] = {
    "design": "one-shot chronological, purge only, no embargo (documented in its own docstring)",
    "sizes": {"train": len(train), "validation": len(validation), "test": len(test)},
    "violations_train_into_validation": count_violations(
        native_train_ts, native_val_ts, horizon_ms
    ),
    "violations_train_into_test": count_violations(native_train_ts, native_test_ts, horizon_ms),
    "train_after_test_exists": False,
}

# Native expanding-window walk-forward boundary rule, reproduced exactly:
#   train_stop = eval_start - max_horizon   (purge, no embargo)
native_wf_violations = 0
native_wf_folds = 0
n = len(samples)
initial = int(n * 0.60)
step = max(1, (n - initial) // 5)
for start in range(initial, n, step):
    stop = min(n, start + step)
    if stop <= start:
        continue
    train_stop = max(0, start - HORIZON)
    tr = [s.end_timestamp_ms for s in samples[:train_stop]]
    te = [s.end_timestamp_ms for s in samples[start:stop]]
    if not tr or not te:
        continue
    native_wf_folds += 1
    native_wf_violations += total(count_violations(tr, te, horizon_ms))

results["native_walk_forward_expanding"] = {
    "design": "expanding window, train always strictly before test, purge = max horizon, no embargo",
    "folds": native_wf_folds,
    "violations": native_wf_violations,
}

# ---------------------------------------------------------------- purgedcv
idx = pd.to_datetime([s.end_timestamp_ms for s in samples], unit="ms")
prediction_times = pd.Series(idx, index=idx)
evaluation_times = pd.Series(idx + pd.Timedelta(minutes=HORIZON), index=idx)

splitter = PurgedKFold(
    n_splits=5,
    prediction_times=prediction_times,
    evaluation_times=evaluation_times,
    purge_horizon=pd.Timedelta(minutes=HORIZON),
    embargo_fraction=0.01,
)

pcv_violations = 0
pcv_folds = 0
pcv_train_after_test = 0  # folds where train samples exist AFTER the test fold
for train_idx, test_idx in splitter.split(np.zeros(len(samples))):
    tr = [samples[i].end_timestamp_ms for i in train_idx]
    te = [samples[i].end_timestamp_ms for i in test_idx]
    if not tr or not te:
        continue
    pcv_folds += 1
    pcv_violations += total(count_violations(tr, te, horizon_ms))
    if max(tr) > max(te):
        pcv_train_after_test += 1

results["purgedcv_PurgedKFold"] = {
    "design": "k-fold, purge + embargo, train exists on BOTH sides of the test fold",
    "folds": pcv_folds,
    "violations": pcv_violations,
    "folds_with_train_after_test": pcv_train_after_test,
}

# ------------------------------------------------- the case that separates them
# Simulate the native purge-only rule applied to a k-fold layout, i.e. what would
# happen if the project moved to k-fold/CPCV while keeping its current logic.
# Left-side purge only; nothing removed after the test fold.
naive_violations = 0
naive_backward = 0
fold_size = len(samples) // 5
for k in range(5):
    lo, hi = k * fold_size, (k + 1) * fold_size
    te = [samples[i].end_timestamp_ms for i in range(lo, hi)]
    left = [samples[i].end_timestamp_ms for i in range(0, max(0, lo - HORIZON))]
    right = [samples[i].end_timestamp_ms for i in range(hi, len(samples))]  # NO embargo
    v = count_violations(left + right, te, horizon_ms)
    naive_violations += v["total"]
    naive_backward += v["backward"]

results["native_purge_rule_applied_to_kfold"] = {
    "design": "hypothetical: current purge-only rule used in a k-fold layout (no embargo)",
    "violations_total": naive_violations,
    "violations_backward_embargo_case": naive_backward,
    "note": "backward violations are exactly the leakage purgedcv's embargo prevents",
}

results["verdict"] = {
    "duplicate_for_current_design": (
        results["native_walk_forward_expanding"]["violations"] == 0
        and results["purgedcv_PurgedKFold"]["violations"] == 0
    ),
    "purgedcv_adds_value_if_project_moves_to_kfold_or_CPCV": naive_violations > 0,
    "summary": (
        "In the project's CURRENT expanding-window design, train always precedes test, so a "
        "left-side purge is structurally sufficient and purgedcv is NOT required. purgedcv becomes "
        "necessary the moment train samples exist AFTER a test fold (k-fold / CPCV), where a "
        "purge-only rule leaks."
    ),
}

print(json.dumps(results, indent=2, default=str))

# Fail loudly if either validator leaks under its own intended design.
bad = (
    results["native_walk_forward_expanding"]["violations"] > 0
    or results["purgedcv_PurgedKFold"]["violations"] > 0
)
sys.exit(1 if bad else 0)
