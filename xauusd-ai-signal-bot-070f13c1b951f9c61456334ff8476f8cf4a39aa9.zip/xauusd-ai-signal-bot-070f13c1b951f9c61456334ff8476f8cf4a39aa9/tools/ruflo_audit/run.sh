#!/usr/bin/env bash
set -u -o pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"
export VIRUS_AI_REAL_TRADING_ENABLED=0
export CI=1
export NO_COLOR=1

RUNTIME="$ROOT/.ruflo-audit-runtime"
PREFIX="$RUNTIME/npm"
OUT="$RUNTIME/out"
HOME_DIR="$RUNTIME/home"
RUFLO_VERSION="3.40.0"
rm -rf "$RUNTIME"
mkdir -p "$PREFIX" "$OUT" "$HOME_DIR"
export HOME="$HOME_DIR"

run() {
  local name="$1"; shift
  set +e
  "$@" >"$OUT/$name.log" 2>&1
  local rc=$?
  set -e
  printf 'RUFLO_STEP name=%s rc=%s\n' "$name" "$rc"
  return 0
}

if ! npm install --prefix "$PREFIX" --no-audit --no-fund "ruflo@${RUFLO_VERSION}" >"$OUT/install.log" 2>&1; then
  echo "RUFLO_AUDIT_INSTALL_FAILED"
  exit 2
fi
BIN="$PREFIX/node_modules/.bin/ruflo"
[ -x "$BIN" ] || { echo "RUFLO_AUDIT_BINARY_MISSING"; exit 2; }

run version "$BIN" --version
run doctor "$BIN" doctor
run verify "$BIN" verify
run help "$BIN" metaharness --help
run score "$BIN" metaharness score --path "$ROOT" --format json
run genome "$BIN" metaharness genome --path "$ROOT" --format json
run mcp_scan "$BIN" metaharness mcp-scan --path "$ROOT" --fail-on high --format json
run threat_model "$BIN" metaharness threat-model --path "$ROOT" --fail-on high --format json
run oia_audit "$BIN" metaharness oia-audit --path "$ROOT" --alert-on-worst high --format json
run audit_list "$BIN" metaharness audit-list --limit 5 --format json

python3 - "$OUT" <<'PY'
import hashlib, json, os, pathlib, subprocess, sys
out=pathlib.Path(sys.argv[1])
root=out.parents[1]

def parse(name):
    p=out/f"{name}.log"
    if not p.exists(): return None
    text=p.read_text(errors='replace')
    dec=json.JSONDecoder()
    for i,c in enumerate(text):
        if c in '[{':
            try:
                value,_=dec.raw_decode(text[i:])
                return value
            except Exception: pass
    return None
try:
    commit=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
except Exception:
    commit=os.getenv('RAILWAY_GIT_COMMIT_SHA')
summary={
 'schema_version':1,
 'tool':'Ruflo MetaHarness',
 'ruflo_version':'3.40.0',
 'audited_commit':commit,
 'real_trading_enabled':False,
 'review_accepted':False,
 'score':parse('score'),
 'genome':parse('genome'),
 'mcp_scan':parse('mcp_scan'),
 'threat_model':parse('threat_model'),
 'oia_audit':parse('oia_audit'),
 'audit_list':parse('audit_list'),
}
for n in ('version','doctor','verify','help','score','genome','mcp_scan','threat_model','oia_audit','audit_list'):
    p=out/f'{n}.log'
    if p.exists(): summary.setdefault('sha256',{})[n]=hashlib.sha256(p.read_bytes()).hexdigest()
p=out/'summary.json'; p.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print('RUFLO_MAIN_AUDIT '+json.dumps({
 'version':summary['ruflo_version'], 'commit':commit,
 'score_available':summary['score'] is not None,
 'genome_available':summary['genome'] is not None,
 'mcp_scan_available':summary['mcp_scan'] is not None,
 'threat_model_available':summary['threat_model'] is not None,
 'oia_audit_available':summary['oia_audit'] is not None,
 'audit_memory_available':summary['audit_list'] is not None,
 'summary_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
 'real_trading_enabled':False,'review_accepted':False},ensure_ascii=False),flush=True)
for key in ('score','mcp_scan','threat_model','oia_audit'):
    val=summary.get(key)
    if val is not None:
        text=json.dumps(val,ensure_ascii=False)
        print(f'RUFLO_RESULT {key} '+text[:12000],flush=True)
PY

echo "RUFLO_MAIN_AUDIT_COMPLETE_REVIEW_PENDING"
exit 0
