from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence

from .dataset import Candle, validate_candles


TIMEFRAME_MINUTES: dict[str, int] = {
    "M1": 1,
    "M5": 5,
    "M15": 15,
    "M30": 30,
    "H1": 60,
}


@dataclass(frozen=True)
class MTFContext:
    end_timestamp_ms: int
    candles_by_timeframe: Mapping[str, tuple[Candle, ...]]


def _bucket_start_ms(timestamp_ms: int, timeframe_minutes: int) -> int:
    width = int(timeframe_minutes) * 60_000
    if width <= 0:
        raise ValueError("timeframe_minutes must be positive")
    return (int(timestamp_ms) // width) * width


def aggregate_closed_candles(
    m1_candles: Sequence[Candle],
    *,
    timeframe_minutes: int,
    as_of_timestamp_ms: int | None = None,
) -> list[Candle]:
    """Aggregate M1 candles into fully closed higher-timeframe candles only.

    A bucket is emitted only when all of its required M1 candle slots are present
    and its closing boundary is <= as_of_timestamp_ms. This intentionally rejects
    partial higher-timeframe candles to prevent look-ahead leakage.
    """
    candles = tuple(m1_candles)
    validate_candles(candles)
    tf = int(timeframe_minutes)
    if tf <= 0:
        raise ValueError("timeframe_minutes must be positive")
    if tf == 1:
        if as_of_timestamp_ms is None:
            return list(candles)
        return [c for c in candles if c.timestamp_ms <= int(as_of_timestamp_ms)]

    as_of = int(as_of_timestamp_ms) if as_of_timestamp_ms is not None else candles[-1].timestamp_ms
    minute_ms = 60_000
    bucket_width_ms = tf * minute_ms

    grouped: dict[int, list[Candle]] = {}
    for candle in candles:
        if candle.timestamp_ms > as_of:
            break
        start = _bucket_start_ms(candle.timestamp_ms, tf)
        grouped.setdefault(start, []).append(candle)

    result: list[Candle] = []
    for start in sorted(grouped):
        bucket = grouped[start]
        close_boundary = start + bucket_width_ms - minute_ms
        if close_boundary > as_of:
            continue
        expected = [start + i * minute_ms for i in range(tf)]
        actual = [c.timestamp_ms for c in bucket]
        if actual != expected:
            continue
        result.append(
            Candle(
                timestamp_ms=close_boundary,
                open=bucket[0].open,
                high=max(c.high for c in bucket),
                low=min(c.low for c in bucket),
                close=bucket[-1].close,
                volume=sum(c.volume for c in bucket),
            )
        )
    return result


def build_mtf_context(
    m1_candles: Sequence[Candle],
    *,
    end_timestamp_ms: int,
    lookbacks: Mapping[str, int] | None = None,
) -> MTFContext:
    """Build a strictly causal M1/M5/M15/M30/H1 snapshot for one decision time."""
    lookbacks = dict(lookbacks or {"M1": 120, "M5": 96, "M15": 64, "M30": 48, "H1": 48})
    unknown = set(lookbacks) - set(TIMEFRAME_MINUTES)
    if unknown:
        raise ValueError(f"unsupported timeframes: {sorted(unknown)}")

    by_tf: dict[str, tuple[Candle, ...]] = {}
    for timeframe, size in lookbacks.items():
        size = int(size)
        if size <= 0:
            raise ValueError(f"lookback for {timeframe} must be positive")
        aggregated = aggregate_closed_candles(
            m1_candles,
            timeframe_minutes=TIMEFRAME_MINUTES[timeframe],
            as_of_timestamp_ms=int(end_timestamp_ms),
        )
        by_tf[timeframe] = tuple(aggregated[-size:])

    if not by_tf.get("M1"):
        raise ValueError("no closed M1 candle available at end_timestamp_ms")
    if by_tf["M1"][-1].timestamp_ms != int(end_timestamp_ms):
        raise ValueError("end_timestamp_ms must match a closed M1 candle")

    for timeframe, candles in by_tf.items():
        if any(c.timestamp_ms > int(end_timestamp_ms) for c in candles):
            raise ValueError(f"future {timeframe} candle leaked into context")

    return MTFContext(end_timestamp_ms=int(end_timestamp_ms), candles_by_timeframe=by_tf)
