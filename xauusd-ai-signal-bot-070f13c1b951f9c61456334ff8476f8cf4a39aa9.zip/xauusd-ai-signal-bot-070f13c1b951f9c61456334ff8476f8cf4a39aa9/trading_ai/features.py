from __future__ import annotations

from dataclasses import dataclass
from math import sqrt
from statistics import mean
from typing import Mapping, Sequence

from .anchored_price import (
    DEFAULT_ANCHORED_PRICE_CONFIG,
    AnchoredPriceConfig,
    anchored_price_feature_block,
)
from .dataset import Candle
from .market_structure import (
    DEFAULT_MARKET_STRUCTURE_CONFIG,
    MarketStructureConfig,
    atr_structure_features,
    wilder_atr,
)
from .mtf import MTFContext
from .session_context import session_features


# Versioned separately from the frozen verified-core feature contract used by
# PR #166. That frozen path has its own exact 111-feature manifest and does not
# import this module. Anchored-price research therefore evolves only this future/
# shadow Trading AI feature vector.
FEATURE_VECTOR_VERSION = "TRADING_AI_FEATURE_VECTOR_V4_ANCHORED_PRICE"


@dataclass(frozen=True)
class FeatureVector:
    end_timestamp_ms: int
    values: Mapping[str, float]


def _safe_div(a: float, b: float) -> float:
    return float(a) / float(b) if abs(float(b)) > 1e-12 else 0.0


def _returns(candles: Sequence[Candle]) -> list[float]:
    return [_safe_div(cur.close - prev.close, prev.close) for prev, cur in zip(candles, candles[1:])]


def _std(values: Sequence[float]) -> float:
    if len(values) < 2:
        return 0.0
    m = mean(values)
    return sqrt(sum((x - m) ** 2 for x in values) / (len(values) - 1))


def timeframe_features(
    candles: Sequence[Candle],
    *,
    prefix: str,
    market_structure_config: MarketStructureConfig = DEFAULT_MARKET_STRUCTURE_CONFIG,
    anchored_price_config: AnchoredPriceConfig = DEFAULT_ANCHORED_PRICE_CONFIG,
) -> dict[str, float]:
    """Pure market-derived causal features.

    No feature in this module is copied from the legacy trading bot or its
    decision rules. The new Trading AI learns directly from observed market
    structure and realized future outcomes. ATR, structure, and anchored-price
    fields are numerical context features, never hardcoded BUY/SELL rules.

    Both configs are explicit so research parameters remain versioned hypotheses
    that can be ablated. The default anchored-price mode is TIME_WEIGHTED and its
    features are named anchored_mean; it is deliberately not called VWAP.
    """
    if not candles:
        return {}
    config = market_structure_config.validate()
    anchor_config = anchored_price_config.validate()
    last = candles[-1]
    close = max(abs(last.close), 1e-12)
    spread = max(last.high - last.low, 0.0)
    body = last.close - last.open
    upper = last.high - max(last.open, last.close)
    lower = min(last.open, last.close) - last.low
    rets = _returns(candles)
    values: dict[str, float] = {
        f"{prefix}_body_pct": _safe_div(body, close),
        f"{prefix}_range_pct": _safe_div(spread, close),
        f"{prefix}_upper_wick_pct": _safe_div(max(upper, 0.0), close),
        f"{prefix}_lower_wick_pct": _safe_div(max(lower, 0.0), close),
        f"{prefix}_volume": float(last.volume),
    }
    for n in (1, 3, 5, 10, 20):
        values[f"{prefix}_ret_{n}"] = (
            _safe_div(last.close - candles[-n - 1].close, candles[-n - 1].close)
            if len(candles) > n
            else 0.0
        )
    for n in (5, 10, 20):
        sample = rets[-n:] if rets else []
        values[f"{prefix}_vol_{n}"] = _std(sample)
        values[f"{prefix}_mean_ret_{n}"] = mean(sample) if sample else 0.0
    recent = candles[-20:]
    hi = max(c.high for c in recent)
    lo = min(c.low for c in recent)
    values[f"{prefix}_position_20"] = _safe_div(last.close - lo, hi - lo)
    values[f"{prefix}_range_20_pct"] = _safe_div(hi - lo, close)
    if len(candles) >= 6:
        up = sum(1 for a, b in zip(candles[-6:-1], candles[-5:]) if b.close > a.close)
        down = sum(1 for a, b in zip(candles[-6:-1], candles[-5:]) if b.close < a.close)
        values[f"{prefix}_direction_balance_5"] = (up - down) / 5.0
    else:
        values[f"{prefix}_direction_balance_5"] = 0.0

    # Additive causal ATR/structure block from V3.
    values.update(atr_structure_features(candles, prefix=prefix, config=config))

    # V4 anchored-price block. The same causal ATR period is reused as the
    # normalizer. Raw anchored price is intentionally not exposed as a model
    # feature; only readiness, signed ATR distance, one-bar slope, and anchor age
    # are emitted. Volume-weighted modes remain fail-closed until semantics are
    # explicitly declared by the research caller.
    atr_value = wilder_atr(candles, period=config.atr_period)
    values.update(
        anchored_price_feature_block(
            candles,
            prefix=prefix,
            atr_value=atr_value,
            config=anchor_config,
        )
    )
    return values


def build_feature_vector(
    context: MTFContext,
    *,
    market_structure_config: MarketStructureConfig = DEFAULT_MARKET_STRUCTURE_CONFIG,
    anchored_price_config: AnchoredPriceConfig = DEFAULT_ANCHORED_PRICE_CONFIG,
) -> FeatureVector:
    config = market_structure_config.validate()
    anchor_config = anchored_price_config.validate()
    values: dict[str, float] = {}
    for timeframe, candles in context.candles_by_timeframe.items():
        values.update(
            timeframe_features(
                candles,
                prefix=timeframe.lower(),
                market_structure_config=config,
                anchored_price_config=anchor_config,
            )
        )

    directional = []
    for tf in ("M1", "M5", "M15", "M30", "H1"):
        key = f"{tf.lower()}_ret_3"
        if key in values:
            directional.append(1.0 if values[key] > 0 else -1.0 if values[key] < 0 else 0.0)
    values["mtf_direction_agreement"] = sum(directional) / len(directional) if directional else 0.0

    # Timestamp-only context is causal and lets the model learn distinct behavior
    # in Asia, London, New York and the regional overlap periods.
    values.update(session_features(context.end_timestamp_ms))
    return FeatureVector(end_timestamp_ms=context.end_timestamp_ms, values=values)
