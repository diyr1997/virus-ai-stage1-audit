from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from math import isfinite
from numbers import Real
from typing import Sequence

from .dataset import Candle, validate_candles


class WeightingMode(str, Enum):
    """How bar-representative prices are weighted inside the causal interval."""

    TIME_WEIGHTED = "TIME_WEIGHTED"
    CANDLE_VOLUME = "CANDLE_VOLUME"


class VolumeSemantics(str, Enum):
    """Explicit meaning of Candle.volume for a given research dataset.

    UNKNOWN is intentionally the default. Positive numbers alone never prove
    whether a broker field is quote/tick count or actual traded volume.
    """

    UNKNOWN = "UNKNOWN"
    TICK_COUNT = "TICK_COUNT"
    TRADE_VOLUME = "TRADE_VOLUME"


class PriceBasis(str, Enum):
    TYPICAL_HLC3 = "TYPICAL_HLC3"
    CLOSE = "CLOSE"
    OHLC4 = "OHLC4"


class AnchoredPriceStatus(str, Enum):
    READY = "READY"
    NOT_READY = "NOT_READY"


@dataclass(frozen=True)
class AnchoredPriceConfig:
    """Versioned research hypotheses for anchored-price context.

    TIME_WEIGHTED is the safe default and is deliberately named anchored_mean,
    not VWAP. CANDLE_VOLUME requires an explicit non-UNKNOWN VolumeSemantics at
    computation time and never silently falls back to time weighting.
    """

    weighting: WeightingMode = WeightingMode.TIME_WEIGHTED
    volume_semantics: VolumeSemantics = VolumeSemantics.UNKNOWN
    price_basis: PriceBasis = PriceBasis.TYPICAL_HLC3
    window_bars: int = 20

    def validate(self) -> "AnchoredPriceConfig":
        if not isinstance(self.weighting, WeightingMode):
            raise TypeError("weighting must be a WeightingMode")
        if not isinstance(self.volume_semantics, VolumeSemantics):
            raise TypeError("volume_semantics must be a VolumeSemantics")
        if not isinstance(self.price_basis, PriceBasis):
            raise TypeError("price_basis must be a PriceBasis")
        if isinstance(self.window_bars, bool) or not isinstance(self.window_bars, int):
            raise TypeError("window_bars must be an integer")
        if self.window_bars < 2:
            raise ValueError("window_bars must be >= 2")
        if self.weighting is WeightingMode.TIME_WEIGHTED and self.volume_semantics is not VolumeSemantics.UNKNOWN:
            raise ValueError("time-weighted mode must use UNKNOWN volume semantics")
        return self


DEFAULT_ANCHORED_PRICE_CONFIG = AnchoredPriceConfig()

# V4 always emits every semantic group below. The active group carries values;
# inactive groups remain finite zeros with ready=0. This makes the model feature
# key set invariant to weighting/volume-semantics configuration.
MODEL_FEATURE_BASES: tuple[str, ...] = (
    "anchored_mean",
    "tick_weighted_price",
    "trade_volume_weighted_bar_price",
)


@dataclass(frozen=True)
class AnchoredPriceResult:
    status: AnchoredPriceStatus
    feature_base: str
    weighted_price: float
    previous_weighted_price: float
    distance_atr: float
    slope_atr_per_bar: float
    anchor_age_bars: int
    cumulative_weight: float
    bars_used: int
    reason: str = ""


def _feature_base(config: AnchoredPriceConfig) -> str:
    if config.weighting is WeightingMode.TIME_WEIGHTED:
        return "anchored_mean"
    if config.volume_semantics is VolumeSemantics.TICK_COUNT:
        return "tick_weighted_price"
    if config.volume_semantics is VolumeSemantics.TRADE_VOLUME:
        # This is a bar-level proxy: HLC3/CLOSE/OHLC4 is weighted by each bar's
        # explicitly declared traded volume. It is not transaction-level VWAP.
        return "trade_volume_weighted_bar_price"
    return "volume_weighted_price_unknown"


def _not_ready(config: AnchoredPriceConfig, reason: str) -> AnchoredPriceResult:
    return AnchoredPriceResult(
        status=AnchoredPriceStatus.NOT_READY,
        feature_base=_feature_base(config),
        weighted_price=0.0,
        previous_weighted_price=0.0,
        distance_atr=0.0,
        slope_atr_per_bar=0.0,
        anchor_age_bars=0,
        cumulative_weight=0.0,
        bars_used=0,
        reason=reason,
    )


def _finite_real(value: object) -> float | None:
    if isinstance(value, bool) or not isinstance(value, Real):
        return None
    result = float(value)
    return result if isfinite(result) else None


def _bar_price(candle: Candle, basis: PriceBasis) -> float | None:
    if basis is PriceBasis.CLOSE:
        return _finite_real(candle.close)
    if basis is PriceBasis.TYPICAL_HLC3:
        high = _finite_real(candle.high)
        low = _finite_real(candle.low)
        close = _finite_real(candle.close)
        if high is None or low is None or close is None:
            return None
        return (high + low + close) / 3.0
    open_ = _finite_real(candle.open)
    high = _finite_real(candle.high)
    low = _finite_real(candle.low)
    close = _finite_real(candle.close)
    if open_ is None or high is None or low is None or close is None:
        return None
    return (open_ + high + low + close) / 4.0


def _slice_to_decision(
    candles: Sequence[Candle],
    decision_timestamp_ms: int | None,
) -> tuple[tuple[Candle, ...], int] | None:
    if not candles:
        return None
    if decision_timestamp_ms is None:
        used = tuple(candles)
    else:
        if isinstance(decision_timestamp_ms, bool) or not isinstance(decision_timestamp_ms, int):
            raise TypeError("decision_timestamp_ms must be an integer timestamp")
        used_list: list[Candle] = []
        found = False
        for candle in candles:
            used_list.append(candle)
            if int(candle.timestamp_ms) == decision_timestamp_ms:
                found = True
                break
            if int(candle.timestamp_ms) > decision_timestamp_ms:
                break
        if not found:
            return None
        used = tuple(used_list)
    try:
        validate_candles(used)
    except (TypeError, ValueError):
        return None
    return used, len(used) - 1


def _resolve_anchor_index(
    used: Sequence[Candle],
    decision_index: int,
    config: AnchoredPriceConfig,
    *,
    anchor_timestamp_ms: int | None,
    anchor_index: int | None,
) -> int | None:
    if anchor_timestamp_ms is not None and anchor_index is not None:
        raise ValueError("provide anchor_timestamp_ms or anchor_index, not both")

    if anchor_index is not None:
        if isinstance(anchor_index, bool) or not isinstance(anchor_index, int):
            raise TypeError("anchor_index must be an integer")
        if anchor_index < 0 or anchor_index >= decision_index:
            return None
        return anchor_index

    if anchor_timestamp_ms is not None:
        if isinstance(anchor_timestamp_ms, bool) or not isinstance(anchor_timestamp_ms, int):
            raise TypeError("anchor_timestamp_ms must be an integer timestamp")
        decision_ts = int(used[decision_index].timestamp_ms)
        # Bar-close anchors must already exist strictly before the decision bar.
        if anchor_timestamp_ms >= decision_ts:
            return None
        for i, candle in enumerate(used[:decision_index]):
            if int(candle.timestamp_ms) == anchor_timestamp_ms:
                return i
        return None

    return max(0, len(used) - config.window_bars)


def _weights(segment: Sequence[Candle], config: AnchoredPriceConfig) -> list[float] | None:
    if config.weighting is WeightingMode.TIME_WEIGHTED:
        return [1.0] * len(segment)

    if config.volume_semantics is VolumeSemantics.UNKNOWN:
        return None

    result: list[float] = []
    for candle in segment:
        value = _finite_real(candle.volume)
        if value is None or value < 0.0:
            return None
        result.append(value)
    return result


def _weighted_mean(prices: Sequence[float], weights: Sequence[float]) -> float | None:
    if len(prices) != len(weights) or not prices:
        return None
    denominator = sum(weights)
    if not isfinite(denominator) or denominator <= 0.0:
        return None
    numerator = sum(price * weight for price, weight in zip(prices, weights))
    if not isfinite(numerator):
        return None
    return numerator / denominator


def _segment_mean(segment: Sequence[Candle], config: AnchoredPriceConfig) -> tuple[float, float] | None:
    prices: list[float] = []
    for candle in segment:
        price = _bar_price(candle, config.price_basis)
        if price is None:
            return None
        prices.append(price)
    weights = _weights(segment, config)
    if weights is None:
        return None
    value = _weighted_mean(prices, weights)
    if value is None:
        return None
    return float(value), float(sum(weights))


def anchored_price_result(
    candles: Sequence[Candle],
    *,
    atr_value: float,
    config: AnchoredPriceConfig = DEFAULT_ANCHORED_PRICE_CONFIG,
    decision_timestamp_ms: int | None = None,
    anchor_timestamp_ms: int | None = None,
    anchor_index: int | None = None,
) -> AnchoredPriceResult:
    """Return causal anchored weighted-bar-price context for one decision bar.

    Future candles after decision_timestamp_ms are ignored entirely. If no
    explicit anchor is supplied, the anchor is the start of the configured
    trailing closed-bar window. An explicit bar-close anchor must be strictly
    before the decision bar. Invalid weighting semantics or data are NOT_READY;
    there is never a silent weighting-mode fallback.

    Slope is a genuine one-decision-bar change. With an explicit anchor, both
    current and previous values use that same anchor. With the implicit rolling
    window, the previous value uses the previous decision's own trailing window.
    For decision index d and width W, the previous decision is d-1, so its W-bar
    start is (d-1)-W+1 == d-W. This is intentionally `decision_index-window_bars`.
    """

    cfg = config.validate()
    atr = _finite_real(atr_value)
    if atr is None or atr <= 0.0:
        return _not_ready(cfg, "atr_not_ready")

    sliced = _slice_to_decision(candles, decision_timestamp_ms)
    if sliced is None:
        return _not_ready(cfg, "decision_not_available")
    used, decision_index = sliced
    if decision_index < 1:
        return _not_ready(cfg, "insufficient_history")

    start = _resolve_anchor_index(
        used,
        decision_index,
        cfg,
        anchor_timestamp_ms=anchor_timestamp_ms,
        anchor_index=anchor_index,
    )
    if start is None or start >= decision_index:
        return _not_ready(cfg, "anchor_not_available_before_decision")

    segment = tuple(used[start : decision_index + 1])
    if len(segment) < 2:
        return _not_ready(cfg, "insufficient_anchor_history")

    explicit_anchor = anchor_timestamp_ms is not None or anchor_index is not None
    if explicit_anchor:
        previous_segment = tuple(used[start:decision_index])
    else:
        previous_start = max(0, decision_index - cfg.window_bars)
        previous_segment = tuple(used[previous_start:decision_index])

    if not previous_segment:
        return _not_ready(cfg, "insufficient_previous_history")

    current_stats = _segment_mean(segment, cfg)
    previous_stats = _segment_mean(previous_segment, cfg)
    if current_stats is None or previous_stats is None:
        if cfg.weighting is WeightingMode.CANDLE_VOLUME and cfg.volume_semantics is VolumeSemantics.UNKNOWN:
            return _not_ready(cfg, "missing_volume_semantics")
        # Distinguish non-finite/negative weights from an all-zero effective sum.
        current_weights = _weights(segment, cfg)
        previous_weights = _weights(previous_segment, cfg)
        if current_weights is None or previous_weights is None:
            return _not_ready(cfg, "invalid_weights")
        return _not_ready(cfg, "non_positive_effective_weight")

    weighted, cumulative_weight = current_stats
    previous, _ = previous_stats

    close = _finite_real(segment[-1].close)
    if close is None:
        return _not_ready(cfg, "invalid_close")

    return AnchoredPriceResult(
        status=AnchoredPriceStatus.READY,
        feature_base=_feature_base(cfg),
        weighted_price=weighted,
        previous_weighted_price=previous,
        distance_atr=(close - weighted) / atr,
        slope_atr_per_bar=(weighted - previous) / atr,
        anchor_age_bars=len(segment) - 1,
        cumulative_weight=cumulative_weight,
        bars_used=len(segment),
        reason="",
    )


def anchored_price_feature_block(
    candles: Sequence[Candle],
    *,
    prefix: str,
    atr_value: float,
    config: AnchoredPriceConfig = DEFAULT_ANCHORED_PRICE_CONFIG,
) -> dict[str, float]:
    """Return a stable V4 numeric schema for anchored-price research features.

    Every supported semantic group is always present. Only the configured group
    can become ready; inactive groups remain zero. Raw price and cumulative
    weight stay diagnostic-only and are not emitted into the model vector.
    """

    result = anchored_price_result(candles, atr_value=atr_value, config=config)
    values: dict[str, float] = {}
    for feature_base in MODEL_FEATURE_BASES:
        base = f"{prefix}_{feature_base}"
        values.update(
            {
                f"{base}_ready": 0.0,
                f"{base}_dist_atr": 0.0,
                f"{base}_slope_atr_per_bar": 0.0,
                f"{base}_anchor_age_bars": 0.0,
            }
        )

    if result.status is AnchoredPriceStatus.READY and result.feature_base in MODEL_FEATURE_BASES:
        base = f"{prefix}_{result.feature_base}"
        values[f"{base}_ready"] = 1.0
        values[f"{base}_dist_atr"] = result.distance_atr
        values[f"{base}_slope_atr_per_bar"] = result.slope_atr_per_bar
        values[f"{base}_anchor_age_bars"] = float(result.anchor_age_bars)
    return values
