"""Stage 1 Unified Brain: one reasoning-and-learning core (research/shadow only).

Closed loop (one cycle, then resolution):

    INPUT (perception, normalization)
      -> MEMORY (append-only, hash-chained persistent store + bounded working memory)
      -> STATE (point-in-time world state with uncertainty)
      -> REASONING (causal links supplied as data)
      -> HYPOTHESIS (competing, explicit direction)
      -> EVIDENCE (aggregated once per observation, weighted by policy reliability)
      -> DECISION (trace with contradictions, uncertainty, recalled lessons)
      -> OUTCOME (journal; only after the decision horizon, PIT-checked)
      -> ERROR (classified and attributed to evidence sources)
      -> LEARNING (quarantined challenger policy; never applied automatically)
      -> MEMORY (lessons recalled by later decisions; accepted policies versioned)

Invariants enforced here (see trading_ai/tests/test_unified_brain.py):
- nothing with available_at > as_of can enter a state, an evidence item or an
  outcome, and no lesson or policy learned later can reach an earlier
  decision (``LeakageError`` / as-of filtering);
- persistent memory is append-only and hash-chained: a key can never be
  rewritten, and edits, reorders, gaps and corrupt records are refused on start;
- confidence is always computed by the brain from evidence on a world state
  the brain itself perceived; a caller can make a decision stricter, never looser;
- the active policy changes only through challenger -> validation ->
  explicit acceptance with an approver; a lesson never changes behaviour;
- decisions never authorize execution (``execution_allowed`` is always False);
- every decision is reproducible from memory (``replay_decision``) and every
  lesson/challenger must re-derive from the recorded decision and outcome.

The reasoning core is domain-neutral: it reasons about a target moving UP or
DOWN and abstains otherwise. What the target is called and which action label
a direction maps to live in a ``DecisionDomain`` (the XAU/USD trading adapter
is at the end of this module). The brain holds no economic rules of its own:
causal links arrive as data (the global causal graph is the intended
provider) so there is one causal model in the project, not two.
"""

from __future__ import annotations

import bisect
import hashlib
import json
import math
import sqlite3
from dataclasses import asdict, dataclass, field, replace
from enum import Enum
from typing import Any, Iterable, Mapping, Protocol, Sequence

from .core import AnalystContext, MarketSnapshot  # used only by the trading adapter at the end
from .dataset import LeakageError


def _hash(payload: Any) -> str:
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode()
    return hashlib.sha256(raw).hexdigest()[:20]


def _canon(payload: Any) -> str:
    return json.dumps(payload, sort_keys=True, default=str)


def _label(value: Any) -> str:
    return value.value if isinstance(value, Enum) else str(value)


DIRECTIONS = ("UP", "DOWN")
NO_DIRECTION = "NONE"
NEUTRAL_PRIOR = 0.5  # a caller may be more sceptical than this, never more confident
DEFAULT_HORIZON_MS = 3600_000


# --------------------------------------------------------------------- domain

@dataclass(frozen=True)
class DecisionDomain:
    """Everything domain-specific about a decision. The core only reasons about
    UP / DOWN / abstain; the domain names the target and the action labels."""

    name: str
    target: str
    actions: Mapping[str, Any]  # {"UP": label, "DOWN": label}
    abstain: Any = "WAIT"

    def validate(self) -> None:
        if not self.name or not self.target:
            raise ValueError("a domain needs a name and a target")
        if set(self.actions) != set(DIRECTIONS):
            raise ValueError("a domain maps exactly UP and DOWN to actions")
        labels = [_label(self.abstain), *(_label(v) for v in self.actions.values())]
        if len(set(labels)) != len(labels):
            raise ValueError("action labels must be distinct")

    def action(self, direction: str) -> Any:
        return self.abstain if direction == NO_DIRECTION else self.actions[direction]

    def parse(self, label: str) -> Any:
        for value in (self.abstain, *self.actions.values()):
            if _label(value) == label:
                return value
        raise MemoryConflict(f"stored action {label!r} is not an action of domain {self.name}")


# ----------------------------------------------------------------- perception

@dataclass(frozen=True)
class Observation:
    """A normalized, point-in-time input. ``values`` maps factor -> signed change
    (or a level; only signed changes create causal hypotheses)."""

    observation_id: str
    observed_at_ms: int
    available_at_ms: int
    source: str
    values: Mapping[str, Any]
    pit_safe: bool = True

    def validate(self) -> None:
        if not self.observation_id:
            raise ValueError("observation_id is required")
        if self.observed_at_ms <= 0 or self.available_at_ms <= 0:
            raise ValueError("timestamps must be positive")
        if self.available_at_ms < self.observed_at_ms:
            raise ValueError("available_at_ms cannot precede observed_at_ms")
        if not self.source:
            raise ValueError("source is required")
        for key, value in self.values.items():
            if isinstance(value, float) and not math.isfinite(value):
                raise ValueError(f"non-finite value for {key}: NaN/inf is missing data, not a signal")
        if not self.pit_safe:
            raise LeakageError("non-PIT-safe observations cannot enter the reasoning state")


def normalize_observation(raw: Mapping[str, Any]) -> Observation:
    """Perception boundary for dict inputs: types are coerced, nothing is filled."""
    values = raw.get("values")
    if not isinstance(values, Mapping):
        raise ValueError("values must be a mapping")
    obs = Observation(
        observation_id=str(raw.get("observation_id") or ""),
        observed_at_ms=int(raw.get("observed_at_ms") or 0),
        available_at_ms=int(raw.get("available_at_ms") or 0),
        source=str(raw.get("source") or ""),
        values={str(k): v for k, v in values.items()},
        pit_safe=bool(raw.get("pit_safe", False)),
    )
    obs.validate()
    return obs


# ------------------------------------------------------------------ reasoning

@dataclass(frozen=True)
class CausalLink:
    """One signed transmission path from an observed factor to the target."""

    path_id: str
    factor: str
    sign: int  # +1: factor up -> target up
    strength: float
    path: tuple[str, ...] = ()

    def validate(self) -> None:
        if self.sign not in (1, -1):
            raise ValueError("causal sign must be +1 or -1")
        if not 0.0 <= self.strength <= 1.0:
            raise ValueError("causal strength must be in [0,1]")


@dataclass(frozen=True)
class Evidence:
    evidence_id: str
    observation_id: str
    supports: str  # hypothesis_id this item bears on
    strength: float  # >0 supports, <0 contradicts
    reliability: float = 1.0
    note: str = ""
    source: str = ""

    def normalized(self) -> "Evidence":
        return Evidence(str(self.evidence_id), str(self.observation_id), str(self.supports),
                        max(-1.0, min(1.0, float(self.strength))), max(0.0, min(1.0, float(self.reliability))),
                        str(self.note), str(self.source))


@dataclass(frozen=True)
class Hypothesis:
    hypothesis_id: str
    statement: str
    prior: float
    confidence: float  # recomputed by the brain from evidence; an input value is never trusted
    evidence_ids: tuple[str, ...] = ()
    contradicting_evidence_ids: tuple[str, ...] = ()
    direction: str = "UNKNOWN"  # UP | DOWN | UNKNOWN — never parsed from text
    causal_path: tuple[str, ...] = ()

    def normalized(self) -> "Hypothesis":
        direction = str(self.direction).upper()
        return Hypothesis(str(self.hypothesis_id), str(self.statement), max(0.0, min(1.0, float(self.prior))),
                          max(0.0, min(1.0, float(self.confidence))), tuple(self.evidence_ids), tuple(self.contradicting_evidence_ids),
                          direction if direction in DIRECTIONS else "UNKNOWN", tuple(self.causal_path))


@dataclass(frozen=True)
class WorldState:
    as_of_ms: int
    observations: tuple[Observation, ...]
    regime: str = "UNKNOWN"
    uncertainty: float = 1.0
    stale_observation_ids: tuple[str, ...] = ()
    working_memory_complete: bool = True  # False: an evicted observation may still be fresh

    def validate(self) -> None:
        if self.as_of_ms <= 0:
            raise ValueError("as_of_ms must be positive")
        if not 0.0 <= self.uncertainty <= 1.0:
            raise ValueError("uncertainty must be in [0,1]")
        for observation in self.observations:
            observation.validate()
            if observation.available_at_ms > self.as_of_ms:
                raise LeakageError("future observation entered world state")

    def state_hash(self) -> str:
        # The identity must include every state component that can affect reasoning.
        # Otherwise a later stale/fresh transition could collide with an older state.
        return _hash({"as_of": self.as_of_ms,
                      "obs": [asdict(o) for o in self.observations],
                      "stale": sorted(self.stale_observation_ids),
                      "regime": self.regime,
                      "uncertainty": self.uncertainty,
                      "complete": self.working_memory_complete})


def _uncertainty(n_fresh: int, n_stale: int, complete: bool) -> float:
    """No information is maximal uncertainty; stale inputs raise it; a working
    memory that may have evicted a fresh input knows nothing reliably."""
    if not complete:
        return 1.0
    coverage = min(1.0, n_fresh / 3.0)
    return round(max(0.0, min(1.0, 1.0 - 0.7 * coverage + 0.3 * (n_stale / max(1, n_fresh + n_stale)))), 6)


# ------------------------------------------------------------------- policy

@dataclass(frozen=True)
class ReasoningPolicy:
    """Every tunable of the decision step. Changes only via an accepted challenger."""

    version: str = "policy-v1"
    parent: str | None = None
    minimum_confidence: float = 0.65
    max_uncertainty: float = 0.6
    conflict_margin: float = 0.1
    max_observation_age_ms: int = 24 * 3600 * 1000
    source_reliability: Mapping[str, float] = field(default_factory=dict)

    def reliability(self, source: str) -> float:
        return max(0.0, min(1.0, float(self.source_reliability.get(source, 1.0))))

    def policy_hash(self) -> str:
        return _hash(asdict(self))


# ---------------------------------------------------------- decision / outcome

@dataclass(frozen=True)
class DecisionTrace:
    trace_id: str
    as_of_ms: int
    action: Any  # the domain's label for ``direction`` (or its abstain label)
    confidence: float
    hypothesis_ids: tuple[str, ...]
    evidence_ids: tuple[str, ...]
    contradiction_ids: tuple[str, ...]
    uncertainty: float
    reason: str
    observation_ids: tuple[str, ...] = ()
    state_hash: str = ""
    policy_version: str = ""
    causal_path: tuple[str, ...] = ()
    recalled_lesson_ids: tuple[str, ...] = ()
    horizon_ms: int = 0
    supporting_observation_ids: tuple[str, ...] = ()  # observations behind the chosen hypothesis
    threshold: float = 0.0  # effective minimum confidence used for this decision
    direction: str = NO_DIRECTION  # domain-neutral: UP | DOWN | NONE (abstain)
    domain: str = ""
    execution_allowed: bool = False

    def __post_init__(self) -> None:
        if self.execution_allowed:
            raise ValueError("the unified brain never authorizes execution")
        if self.direction not in (*DIRECTIONS, NO_DIRECTION):
            raise ValueError("direction must be UP, DOWN or NONE")


@dataclass(frozen=True)
class Outcome:
    trace_id: str
    resolved_at_ms: int
    result: str
    realized_return: float | None = None  # signed change of the target; None = unresolved
    notes: str = ""
    observed_at_ms: int | None = None  # when the outcome event/data was observed
    available_at_ms: int | None = None  # when the outcome data became available (required by record_outcome)


@dataclass(frozen=True)
class Lesson:
    lesson_id: str
    trace_id: str
    error_type: str
    statement: str
    confidence_delta: float
    promoted: bool = False
    causal_path: tuple[str, ...] = ()
    blamed_sources: tuple[str, ...] = ()
    created_at_ms: int = 0
    move_threshold: float = 0.002


@dataclass(frozen=True)
class ChallengerProposal:
    lesson_id: str
    target: str
    change: str
    requires_validation: bool = True
    challenger_version: str = ""
    policy: Mapping[str, Any] = field(default_factory=dict)
    status: str = "QUARANTINED"  # QUARANTINED -> VALIDATED | REJECTED -> ACCEPTED
    created_at_ms: int = 0


@dataclass(frozen=True)
class ValidationReport:
    challenger_version: str
    cases: int
    champion_score: float
    challenger_score: float
    passed: bool
    reason: str
    case_trace_ids: tuple[str, ...] = ()
    knowledge_until_ms: int = 0  # latest time whose information the validation used


# --------------------------------------------------------------------- memory

class MemoryConflict(ValueError):
    pass


class MemoryStore(Protocol):
    """Minimal store contract. Stores may also offer ``put_many`` (atomic batch)
    and ``verify`` (integrity check on start); the brain uses them when present."""

    def put(self, kind: str, key: str, payload: Mapping[str, Any]) -> None: ...
    def get(self, kind: str, key: str) -> Mapping[str, Any] | None: ...
    def list_kind(self, kind: str) -> list[Mapping[str, Any]]: ...


class SQLiteMemoryStore:
    """Persistent, append-only reference store (SQLite; PostgreSQL can implement the same Protocol).

    - A (kind, key) is written once. Re-writing the identical payload is a no-op;
      a different payload raises ``MemoryConflict`` — history is never rewritten.
    - Writes run in ``BEGIN IMMEDIATE`` transactions, so check-and-insert is atomic
      across connections/processes and ``put_many`` is all-or-nothing.
    - Every row carries a hash chain over (previous link, seq, kind, key, payload);
      ``verify()`` refuses edited, reordered, missing-in-the-middle or corrupt rows.
      The chain is unkeyed: it detects corruption and naive edits, not an attacker
      who rewrites the whole tail (that needs signing / an external anchor).
    Mutable pointers (the active policy) are kept as an append-only sequence of
    events, not as an updated row.
    """

    def __init__(self, path: str = ":memory:", *, timeout: float = 30.0) -> None:
        self.db = sqlite3.connect(path, timeout=timeout, isolation_level=None)
        self.db.execute("CREATE TABLE IF NOT EXISTS brain_memory (kind TEXT NOT NULL, key TEXT NOT NULL, payload TEXT NOT NULL, "
                        "seq INTEGER NOT NULL UNIQUE, chain TEXT NOT NULL, PRIMARY KEY(kind, key))")
        columns = {row[1] for row in self.db.execute("PRAGMA table_info(brain_memory)")}
        if "chain" not in columns:
            raise MemoryConflict("memory store predates the integrity chain and cannot be trusted")

    @staticmethod
    def _link(previous: str, seq: int, kind: str, key: str, text: str) -> str:
        return hashlib.sha256(json.dumps([previous, seq, kind, key, text]).encode()).hexdigest()

    def put(self, kind: str, key: str, payload: Mapping[str, Any]) -> None:
        self.put_many([(kind, key, payload)])

    def put_many(self, items: Sequence[tuple[str, str, Mapping[str, Any]]]) -> None:
        rows = [(kind, key, json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)) for kind, key, payload in items]
        self.db.execute("BEGIN IMMEDIATE")
        try:
            last = self.db.execute("SELECT seq, chain FROM brain_memory ORDER BY seq DESC LIMIT 1").fetchone()
            seq, previous = last if last else (0, "")
            written: dict[tuple[str, str], str] = {}
            for kind, key, text in rows:
                existing = written.get((kind, key))
                if existing is None:
                    row = self.db.execute("SELECT payload FROM brain_memory WHERE kind=? AND key=?", (kind, key)).fetchone()
                    existing = None if row is None else row[0]
                if existing is not None:
                    if existing != text:
                        raise MemoryConflict(f"append-only memory: {kind}/{key} already holds a different record")
                    continue
                seq += 1
                previous = self._link(previous, seq, kind, key, text)
                self.db.execute("INSERT INTO brain_memory(kind,key,payload,seq,chain) VALUES(?,?,?,?,?)", (kind, key, text, seq, previous))
                written[(kind, key)] = text
            self.db.execute("COMMIT")
        except BaseException:
            self.db.execute("ROLLBACK")
            raise

    def get(self, kind: str, key: str) -> Mapping[str, Any] | None:
        row = self.db.execute("SELECT payload FROM brain_memory WHERE kind=? AND key=?", (kind, key)).fetchone()
        return None if row is None else json.loads(row[0])

    def list_kind(self, kind: str) -> list[Mapping[str, Any]]:
        rows = self.db.execute("SELECT payload FROM brain_memory WHERE kind=? ORDER BY seq", (kind,)).fetchall()
        return [json.loads(r[0]) for r in rows]

    def verify(self) -> None:
        previous, expected = "", 1
        for seq, kind, key, text, chain in self.db.execute("SELECT seq, kind, key, payload, chain FROM brain_memory ORDER BY seq"):
            if seq != expected:
                raise MemoryConflict(f"memory sequence is broken at seq {expected}")
            if chain != self._link(previous, seq, kind, key, text):
                raise MemoryConflict(f"memory integrity chain is broken at seq {seq} ({kind}/{key})")
            try:
                json.loads(text)
            except ValueError as exc:
                raise MemoryConflict(f"memory record {kind}/{key} is corrupt") from exc
            previous, expected = chain, expected + 1


class WorkingMemory:
    """Bounded short-term context for the current reasoning episode.

    Holds the ``capacity`` most recently available observations, ordered by
    (available_at_ms, observation_id). Eviction depends only on that order, so
    the retained set is the same before and after a restart (it does not depend
    on the order observations were perceived or re-perceived). Rebuilt from
    persistent memory on start; it never returns anything newer than the as_of
    it is asked about.
    """

    def __init__(self, capacity: int = 256) -> None:
        if capacity < 1:
            raise ValueError("working memory capacity must be positive")
        self.capacity = capacity
        self.observations: list[Observation] = []
        self._ids: set[str] = set()
        self.evicted_until: tuple[int, str] | None = None  # largest evicted (available_at_ms, id)
        self.open_decisions: dict[str, DecisionTrace] = {}

    def remember(self, observations: Iterable[Observation]) -> None:
        key = lambda o: (o.available_at_ms, o.observation_id)
        for o in observations:
            if o.observation_id in self._ids:
                continue
            bisect.insort(self.observations, o, key=key)
            self._ids.add(o.observation_id)
            while len(self.observations) > self.capacity:
                gone = self.observations.pop(0)
                self._ids.discard(gone.observation_id)
                self.evicted_until = max(self.evicted_until or key(gone), key(gone))

    def covers(self, as_of_ms: int, max_age_ms: int) -> bool:
        """False when an evicted observation could still be fresh at as_of (state would be incomplete)."""
        return self.evicted_until is None or self.evicted_until[0] < as_of_ms - max_age_ms

    def visible(self, as_of_ms: int, max_age_ms: int) -> tuple[list[Observation], list[str]]:
        fresh, stale = [], []
        for o in self.observations:
            if o.available_at_ms > as_of_ms:
                continue  # not yet knowable at this as_of
            (stale if as_of_ms - o.available_at_ms > max_age_ms else fresh).append(o)
        return fresh, [o.observation_id for o in stale]


def _hypothesis_from(raw: Mapping[str, Any]) -> Hypothesis:
    return Hypothesis(**{**raw, "evidence_ids": tuple(raw.get("evidence_ids", ())),
                         "contradicting_evidence_ids": tuple(raw.get("contradicting_evidence_ids", ())),
                         "causal_path": tuple(raw.get("causal_path", ()))})


def _lesson_from(raw: Mapping[str, Any]) -> Lesson:
    return Lesson(**{**raw, "causal_path": tuple(raw.get("causal_path", ())), "blamed_sources": tuple(raw.get("blamed_sources", ()))})


def _link_from(raw: Mapping[str, Any]) -> CausalLink:
    return CausalLink(**{**raw, "path": tuple(raw.get("path", ()))})


# ---------------------------------------------------------------------- brain

class UnifiedBrain:
    """The Stage 1 cognitive core. Reasoning infrastructure, not a trading model.

    Concurrency: one brain instance per thread/process. Several instances may
    share one SQLite file; their writes are serialized and conflict-checked, but
    each instance's working memory only sees other instances' observations after
    a restart.
    """

    VERSION = "unified-brain-v3-stage1"

    def __init__(self, memory: MemoryStore | None = None, *, working_capacity: int = 256,
                 initial_policy: ReasoningPolicy | None = None, domain: DecisionDomain | None = None) -> None:
        """``initial_policy`` is used only when the memory holds no policy history
        (sandbox validation); an existing history is never replaced. ``domain``
        defaults to the XAU/USD trading adapter defined at the end of this module."""
        self.memory = memory or SQLiteMemoryStore()
        self.domain = domain or XAUUSD_DOMAIN
        self.domain.validate()
        self.working = WorkingMemory(working_capacity)
        self._restore(initial_policy or ReasoningPolicy())

    # -- memory ---------------------------------------------------------------
    def _put_all(self, items: Sequence[tuple[str, str, Mapping[str, Any]]]) -> None:
        put_many = getattr(self.memory, "put_many", None)
        if callable(put_many):
            put_many(items)
        else:
            for kind, key, payload in items:
                self.memory.put(kind, key, payload)

    def _restore(self, initial_policy: ReasoningPolicy) -> None:
        verify = getattr(self.memory, "verify", None)
        if callable(verify):
            verify()
        for raw in self.memory.list_kind("observation"):
            self.working.remember([Observation(**{**raw, "values": raw["values"]})])
        resolved = {o["trace_id"] for o in self.memory.list_kind("outcome")}
        for raw in self.memory.list_kind("decision"):
            if raw["trace_id"] not in resolved:
                self.working.open_decisions[raw["trace_id"]] = self._trace_from(raw)
        if not self.memory.list_kind("policy_event"):
            self._put_all([("policy", initial_policy.version, asdict(initial_policy)),
                           ("policy_event", "0001", {"seq": 1, "active": initial_policy.version, "reason": "INITIAL",
                                                     "policy_hash": initial_policy.policy_hash(), "effective_from_ms": 0})])
        self._history()  # a corrupted, truncated or rolled-back policy history fails the start

    def _trace_from(self, raw: Mapping[str, Any]) -> DecisionTrace:
        d = dict(raw)
        d["action"] = self.domain.parse(d["action"])
        for k in ("hypothesis_ids", "evidence_ids", "contradiction_ids", "observation_ids", "causal_path", "recalled_lesson_ids", "supporting_observation_ids"):
            d[k] = tuple(d.get(k, ()))
        return DecisionTrace(**d)  # a stored execution_allowed=True is rejected here

    def _load_policy(self, version: Any) -> ReasoningPolicy:
        raw = self.memory.get("policy", str(version)) if version else None
        if raw is None:
            raise MemoryConflict("policy record is missing")
        raw = dict(raw)
        raw["source_reliability"] = dict(raw.get("source_reliability", {}))
        try:
            policy = ReasoningPolicy(**raw)
        except TypeError as exc:
            raise MemoryConflict("policy record is malformed") from exc
        if policy.version != version:
            raise MemoryConflict("active policy event and policy record disagree")
        return policy

    def _history(self) -> list[tuple[ReasoningPolicy, int]]:
        """The verified policy history as (policy, effective_from_ms): contiguous
        sequence, each record matching the hash recorded at activation, each
        policy the child of the previous one, no version activated twice,
        non-decreasing effective times, and no policy record without its event."""
        events = self.memory.list_kind("policy_event")
        if not events:
            raise MemoryConflict("active policy has no policy event")
        history: list[tuple[ReasoningPolicy, int]] = []
        seen: set[str] = set()
        for seq, event in enumerate(events, 1):
            if event.get("seq") != seq:
                raise MemoryConflict("policy history is not a contiguous sequence")
            if not event.get("active"):
                raise MemoryConflict("policy event has no active policy")
            policy = self._load_policy(event["active"])
            if event.get("policy_hash") != policy.policy_hash():
                raise MemoryConflict("policy record does not match the hash recorded at activation")
            if policy.version in seen:
                raise MemoryConflict("a policy version cannot be activated twice")
            if history and policy.parent != history[-1][0].version:
                raise MemoryConflict("policy history breaks the parent chain")
            effective = event.get("effective_from_ms")
            if not isinstance(effective, int) or isinstance(effective, bool) or (history and effective < history[-1][1]):
                raise MemoryConflict("policy effective times must be present and non-decreasing")
            seen.add(policy.version)
            history.append((policy, effective))
        if {p.get("version") for p in self.memory.list_kind("policy")} != seen:
            raise MemoryConflict("a policy record exists without its activation event (history truncated or rolled back)")
        return history

    @property
    def active_policy(self) -> ReasoningPolicy:
        """The latest accepted policy (champion for new challengers)."""
        return self._history()[-1][0]

    def policy_at(self, as_of_ms: int) -> ReasoningPolicy:
        """The policy in effect at as_of: a policy learned from later information never reaches an earlier decision."""
        eligible = [p for p, effective in self._history() if effective <= as_of_ms]
        if not eligible:
            raise LeakageError("no policy was in effect at this as_of")
        return eligible[-1]

    # -- INPUT -> MEMORY -> STATE ----------------------------------------------
    @staticmethod
    def _state_record(state: WorldState) -> dict[str, Any]:
        return {"as_of_ms": state.as_of_ms, "observation_ids": [o.observation_id for o in state.observations],
                "stale": list(state.stale_observation_ids), "uncertainty": state.uncertainty,
                "regime": state.regime, "working_memory_complete": state.working_memory_complete}

    def perceive(self, observations: Sequence[Observation], *, as_of_ms: int) -> WorldState:
        for o in observations:
            o.validate()
            if o.available_at_ms > as_of_ms:
                raise LeakageError("future observation entered world state")
        if observations:
            self._put_all([("observation", o.observation_id, asdict(o)) for o in observations])
        self.working.remember(observations)
        policy = self.policy_at(as_of_ms)
        fresh, stale = self.working.visible(as_of_ms, policy.max_observation_age_ms)
        complete = self.working.covers(as_of_ms, policy.max_observation_age_ms)
        state = WorldState(as_of_ms, tuple(sorted(fresh, key=lambda o: (o.available_at_ms, o.observation_id))), "UNKNOWN",
                           _uncertainty(len(fresh), len(stale), complete), tuple(sorted(stale)), complete)
        state.validate()
        self.memory.put("world_state", state.state_hash(), self._state_record(state))
        return state

    # -- REASONING -> HYPOTHESIS -> EVIDENCE ------------------------------------
    def generate_hypotheses(self, state: WorldState, links: Sequence[CausalLink], *,
                            policy: ReasoningPolicy | None = None) -> tuple[list[Hypothesis], list[Evidence]]:
        """Competing hypotheses from supplied causal links; one evidence item per (observation, link)."""
        state.validate()
        policy = policy or self.policy_at(state.as_of_ms)
        hyps: dict[str, Hypothesis] = {}
        evidence: list[Evidence] = []
        for link in links:
            link.validate()
            for o in state.observations:
                v = o.values.get(link.factor)
                if not isinstance(v, (int, float)) or isinstance(v, bool) or not math.isfinite(v) or v == 0:
                    continue  # a missing, non-finite or zero change is no evidence (never a default)
                direction = "UP" if (v > 0) == (link.sign > 0) else "DOWN"
                hid = f"H:{link.path_id}:{direction}"
                eid = f"E:{o.observation_id}:{link.path_id}"
                evidence.append(Evidence(eid, o.observation_id, hid, link.strength, policy.reliability(o.source), f"{link.factor}={v}", o.source))
                h = hyps.get(hid) or Hypothesis(hid, f"{link.factor} via {' -> '.join(link.path) or link.path_id} implies {self.domain.target} {direction}",
                                                NEUTRAL_PRIOR, NEUTRAL_PRIOR, (), (), direction, link.path)
                hyps[hid] = replace(h, evidence_ids=h.evidence_ids + (eid,))
        # Competing hypotheses contradict each other: evidence for UP is evidence against DOWN.
        by_dir = {d: [h for h in hyps.values() if h.direction == d] for d in DIRECTIONS}
        for d, other in (("UP", "DOWN"), ("DOWN", "UP")):
            against = tuple(e for h in by_dir[other] for e in h.evidence_ids)
            for h in by_dir[d]:
                hyps[h.hypothesis_id] = replace(h, contradicting_evidence_ids=tuple(sorted(set(against))))
        return sorted(hyps.values(), key=lambda h: h.hypothesis_id), evidence

    def evaluate(self, state: WorldState, hypotheses: Sequence[Hypothesis], evidence: Sequence[Evidence], *,
                 policy: ReasoningPolicy | None = None) -> tuple[list[Hypothesis], tuple[str, ...]]:
        """Confidence = min(prior, NEUTRAL_PRIOR) + 0.5 * support - 0.5 * opposition.

        Input ``confidence`` is ignored, a prior can only lower it, and reliability
        comes from the policy for the observation's source.
        """
        state.validate()
        policy = policy or self.policy_at(state.as_of_ms)
        source_of = {o.observation_id: o.source for o in state.observations}
        items = [e.normalized() for e in evidence]
        for e in items:
            if e.observation_id not in source_of:
                raise LeakageError("evidence references observation outside world state")
            if e.source and e.source != source_of[e.observation_id]:
                raise ValueError("evidence source does not match its observation")
        # The observation's source decides reliability; evidence cannot vouch for itself.
        items = [replace(e, source=source_of[e.observation_id], reliability=min(e.reliability, policy.reliability(source_of[e.observation_id])))
                 for e in items]
        by_id = {e.evidence_id: e for e in items}
        if len(by_id) != len(items):
            raise ValueError("duplicate evidence_id in one evaluation")
        normalized_hypotheses = [h.normalized() for h in hypotheses]
        direction_by_id = {h.hypothesis_id: h.direction for h in normalized_hypotheses}
        if len(direction_by_id) != len(normalized_hypotheses):
            raise ValueError("duplicate hypothesis_id in one evaluation")
        for h in normalized_hypotheses:
            for eid in h.evidence_ids:
                e = by_id.get(eid)
                if e is None:
                    raise ValueError("hypothesis cites evidence that was not supplied")
                if e.supports != h.hypothesis_id:
                    raise ValueError("evidence supports a different hypothesis")
            for eid in h.contradicting_evidence_ids:
                e = by_id.get(eid)
                if e is None:
                    raise ValueError("hypothesis cites contradicting evidence that was not supplied")
                if e.supports not in direction_by_id or e.supports == h.hypothesis_id:
                    raise ValueError("contradicting evidence must support a competing hypothesis")
                if direction_by_id.get(e.supports) == h.direction:
                    raise ValueError("contradicting evidence must point to the opposite direction")
        evaluated, contradictions = [], []
        for h in normalized_hypotheses:
            # Aggregate once per observation: repeated items from one observation are not independent.
            def total(ids: Iterable[str], signed: bool) -> float:
                best: dict[str, float] = {}
                for eid in ids:
                    e = by_id[eid]
                    w = (e.strength if signed else abs(e.strength)) * e.reliability
                    best[e.observation_id] = max(best.get(e.observation_id, float("-inf")), w)
                return sum(best.values())
            prior = min(h.prior, NEUTRAL_PRIOR)
            support, oppose = total(h.evidence_ids, True), total(h.contradicting_evidence_ids, False)
            confidence = max(0.0, min(1.0, prior + 0.5 * support - 0.5 * oppose))
            if oppose > 0:
                contradictions.extend(h.contradicting_evidence_ids)
            evaluated.append(replace(h, prior=prior, confidence=confidence))
        return evaluated, tuple(sorted(set(contradictions)))

    # -- DECISION ---------------------------------------------------------------
    def recall_lessons(self, causal_paths: Iterable[Sequence[str]], *, as_of_ms: int) -> list[Mapping[str, Any]]:
        """Lessons already learned at as_of on any causal path the current hypotheses use (advisory only)."""
        keys = {tuple(p) for p in causal_paths if p}
        return [l for l in self.memory.list_kind("lesson")
                if tuple(l.get("causal_path", ())) in keys and int(l.get("created_at_ms", 0)) <= as_of_ms]

    @staticmethod
    def _choose(policy: ReasoningPolicy, state: WorldState, hs: Sequence[Hypothesis], threshold: float,
                contradiction_ids: tuple[str, ...], evidence: Sequence[Evidence]) -> tuple[str, str, float, tuple[str, ...], tuple[str, ...]]:
        """Pure, domain-neutral decision rule (also used by replay): a direction or NONE. Any doubt is NONE."""
        if not hs:
            return NO_DIRECTION, "NO_HYPOTHESES", 0.0, (), ()
        top = hs[0]
        rival = next((h for h in hs[1:] if h.direction != top.direction and h.direction != "UNKNOWN"), None)
        backing = {e.evidence_id: e.observation_id for e in evidence if e.supports == top.hypothesis_id and e.strength > 0}
        supporting = tuple(sorted({backing[e] for e in top.evidence_ids if e in backing}))
        if top.direction == "UNKNOWN":
            reason = "NO_DIRECTIONAL_HYPOTHESIS"
        elif state.uncertainty > policy.max_uncertainty:
            reason = "UNCERTAINTY_TOO_HIGH"
        elif contradiction_ids:
            reason = "CONTRADICTORY_EVIDENCE"
        elif top.confidence < threshold:
            reason = "INSUFFICIENT_CONFIDENCE"
        elif rival is not None and top.confidence - rival.confidence < policy.conflict_margin:
            reason = "CONFLICTED_HYPOTHESES"
        elif not supporting:
            reason = "UNSUPPORTED_HYPOTHESIS"  # a confidence nobody can trace to evidence is not acted on
        else:
            return top.direction, "TOP_HYPOTHESIS", top.confidence, tuple(top.causal_path), supporting
        return NO_DIRECTION, reason, top.confidence, tuple(top.causal_path), ()

    def _reason(self, state: WorldState, policy: ReasoningPolicy, raw: Mapping[str, Any], *, threshold: float,
                horizon_ms: int, recalled: tuple[str, ...] | None) -> tuple[DecisionTrace, dict[str, Any]]:
        """REASONING -> HYPOTHESIS -> EVIDENCE -> DECISION from raw inputs only (shared by decide and replay)."""
        links = [_link_from(l) for l in raw["links"]]
        evidence = [Evidence(**e) for e in raw["evidence"]]
        gen_h, gen_e = self.generate_hypotheses(state, links, policy=policy) if links else ([], [])
        all_evidence = [*evidence, *gen_e]
        evaluated, contradicted = self.evaluate(state, [*(_hypothesis_from(h) for h in raw["hypotheses"]), *gen_h], all_evidence, policy=policy)
        contradictions = tuple(sorted(set(contradicted) | set(raw["contradiction_ids"])))
        hs = sorted(evaluated, key=lambda h: (-h.confidence, h.hypothesis_id))
        if recalled is None:
            recalled = tuple(sorted({l["lesson_id"] for l in self.recall_lessons((h.causal_path for h in hs), as_of_ms=state.as_of_ms)}))
        direction, reason, confidence, path, supporting = self._choose(policy, state, hs, threshold, contradictions,
                                                                       [e.normalized() for e in all_evidence])
        action = self.domain.action(direction)
        inputs = {"raw": dict(raw), "evaluated": [asdict(h) for h in hs]}
        trace = DecisionTrace("", state.as_of_ms, action, confidence, tuple(h.hypothesis_id for h in hs),
                              tuple(e for h in hs for e in h.evidence_ids), contradictions, state.uncertainty, reason,
                              tuple(o.observation_id for o in state.observations), state.state_hash(), policy.version, path,
                              recalled, horizon_ms, supporting, threshold, direction, self.domain.name)
        # The id covers every field and every input, so different decisions can never share an id.
        body = {**asdict(trace), "action": _label(action), "inputs": inputs}
        body.pop("trace_id")
        return replace(trace, trace_id=_hash(body)), inputs

    def _decide(self, state: WorldState, hypotheses: Sequence[Hypothesis], evidence: Sequence[Evidence], *, links: Sequence[CausalLink],
                minimum_confidence: float | None, contradiction_ids: Iterable[str], horizon_ms: int) -> DecisionTrace:
        state.validate()
        stored_state = self.memory.get("world_state", state.state_hash())
        if stored_state is None or _canon(stored_state) != _canon(self._state_record(state)):
            raise PermissionError("decisions are made only on a world state this brain perceived")
        if horizon_ms < 0:
            raise ValueError("horizon_ms cannot be negative")
        policy = self.policy_at(state.as_of_ms)
        # A caller may be stricter than the policy, never looser: behaviour changes only via an accepted challenger.
        threshold = policy.minimum_confidence if minimum_confidence is None else max(policy.minimum_confidence, float(minimum_confidence))
        raw = {"hypotheses": [asdict(h) for h in hypotheses], "evidence": [asdict(e) for e in evidence],
               "links": [asdict(l) for l in links], "contradiction_ids": sorted(set(contradiction_ids))}
        trace, inputs = self._reason(state, policy, raw, threshold=threshold, horizon_ms=horizon_ms, recalled=None)
        self._put_all([("decision_input", trace.trace_id, inputs),
                       ("decision", trace.trace_id, {**asdict(trace), "action": _label(trace.action)})])
        self.working.open_decisions[trace.trace_id] = trace
        return trace

    def decide(self, state: WorldState, hypotheses: Sequence[Hypothesis], *, minimum_confidence: float | None = None,
               contradiction_ids: tuple[str, ...] = (), horizon_ms: int = DEFAULT_HORIZON_MS, evidence: Sequence[Evidence] = ()) -> DecisionTrace:
        """Decision on a perceived state. Hypotheses are (re-)evaluated against ``evidence``;
        their input confidence is ignored. Extra ``contradiction_ids`` can only force WAIT."""
        return self._decide(state, hypotheses, evidence, links=(), minimum_confidence=minimum_confidence,
                            contradiction_ids=contradiction_ids, horizon_ms=horizon_ms)

    def think(self, observations: Sequence[Observation], hypotheses: Sequence[Hypothesis] = (), evidence: Sequence[Evidence] = (), *,
              as_of_ms: int, links: Sequence[CausalLink] = (), minimum_confidence: float | None = None, horizon_ms: int = DEFAULT_HORIZON_MS) -> DecisionTrace:
        """INPUT -> MEMORY -> STATE -> REASONING -> HYPOTHESIS -> EVIDENCE -> DECISION."""
        state = self.perceive(observations, as_of_ms=as_of_ms)
        return self._decide(state, hypotheses, evidence, links=links, minimum_confidence=minimum_confidence,
                            contradiction_ids=(), horizon_ms=horizon_ms)

    def replay_decision(self, trace_id: str) -> DecisionTrace:
        """Rebuild a stored decision from memory alone and prove it is the same decision.

        World state is rebuilt from the stored observations (hash and uncertainty
        must match), the policy must be a verified history entry in effect at the
        decision's as_of, and hypotheses and evidence are regenerated and
        re-evaluated from the raw inputs and causal links. Recalled lessons must
        exist and predate the decision. Any difference raises ``MemoryConflict``.
        """
        raw = self.memory.get("decision", trace_id)
        inputs = self.memory.get("decision_input", trace_id)
        if raw is None or inputs is None:
            raise MemoryConflict("decision or its inputs are missing from memory")
        stored = self._trace_from(raw)
        if stored.domain != self.domain.name:
            raise MemoryConflict("decision belongs to a different domain")
        ws = self.memory.get("world_state", stored.state_hash)
        if ws is None:
            raise MemoryConflict("world state of the decision is missing from memory")
        observations = []
        for oid in ws["observation_ids"]:
            o = self.memory.get("observation", oid)
            if o is None:
                raise MemoryConflict("an observation of the decision is missing from memory")
            observations.append(Observation(**o))
        state = WorldState(ws["as_of_ms"], tuple(observations), ws.get("regime", "UNKNOWN"), ws["uncertainty"],
                           tuple(ws["stale"]), ws.get("working_memory_complete", True))
        state.validate()
        if state.state_hash() != stored.state_hash or state.as_of_ms != stored.as_of_ms:
            raise MemoryConflict("stored world state does not reproduce the decision's state hash")
        if state.uncertainty != _uncertainty(len(state.observations), len(state.stale_observation_ids), state.working_memory_complete):
            raise MemoryConflict("stored world state uncertainty was not computed by the brain")
        if any(self.memory.get("observation", oid) is None for oid in state.stale_observation_ids):
            raise MemoryConflict("a stale observation of the decision is missing from memory")
        policy = next((p for p, effective in self._history() if p.version == stored.policy_version and effective <= stored.as_of_ms), None)
        if policy is None:
            raise MemoryConflict("decision policy is not a verified policy in effect at its as_of")
        if stored.threshold < policy.minimum_confidence:
            raise MemoryConflict("decision threshold is looser than its policy")
        rebuilt, rebuilt_inputs = self._reason(state, policy, inputs["raw"], threshold=stored.threshold,
                                               horizon_ms=stored.horizon_ms, recalled=stored.recalled_lesson_ids)
        paths = {tuple(h["causal_path"]) for h in rebuilt_inputs["evaluated"]}
        for lid in stored.recalled_lesson_ids:
            lesson = self.memory.get("lesson", lid)
            if lesson is None or int(lesson.get("created_at_ms", 0)) > stored.as_of_ms or tuple(lesson.get("causal_path", ())) not in paths:
                raise MemoryConflict("recalled lesson is missing, from the future, or on an unrelated path")
        if (rebuilt.trace_id != trace_id or _canon({**asdict(rebuilt), "action": _label(rebuilt.action)}) != _canon(raw)
                or _canon(rebuilt_inputs) != _canon(inputs)):
            raise MemoryConflict("decision trace is not reproducible from memory")
        return rebuilt

    # -- OUTCOME -> ERROR -> LEARNING -> MEMORY -----------------------------------
    def record_outcome(self, outcome: Outcome, *, move_threshold: float = 0.002) -> Lesson:
        """Journal the outcome of a decision and derive its lesson (idempotent for an identical outcome).

        Requires ``available_at_ms``; outcome data cannot exist before the decision
        horizon ended or be unavailable at resolution.
        """
        if self.memory.get("decision", outcome.trace_id) is None:
            raise ValueError("outcome references unknown decision trace")
        trace = self.replay_decision(outcome.trace_id)  # never learn from a decision memory cannot reproduce
        end = trace.as_of_ms + trace.horizon_ms
        if outcome.resolved_at_ms <= trace.as_of_ms:
            raise ValueError("outcome cannot resolve before decision")
        if outcome.resolved_at_ms < end:
            raise ValueError("outcome resolved before the decision horizon ended")
        if outcome.available_at_ms is None:
            raise LeakageError("outcome available_at_ms is required: an outcome of unknown availability cannot be learned from")
        if outcome.observed_at_ms is not None and outcome.observed_at_ms > outcome.resolved_at_ms:
            raise LeakageError("outcome uses data observed after its resolution time")
        if outcome.available_at_ms < (outcome.observed_at_ms or trace.as_of_ms):
            raise ValueError("outcome available_at_ms cannot precede its observation/as-of time")
        if outcome.available_at_ms > outcome.resolved_at_ms:
            raise LeakageError("outcome uses data that was unavailable at its resolution time")
        if outcome.available_at_ms < end or (outcome.observed_at_ms is not None and outcome.observed_at_ms < end):
            raise ValueError("outcome data cannot exist before the decision horizon ended")
        if outcome.realized_return is not None and not math.isfinite(float(outcome.realized_return)):
            raise ValueError("realized_return must be finite")
        stored = self.memory.get("outcome", outcome.trace_id)
        if stored is not None and _canon(stored) != _canon(asdict(outcome)):
            raise MemoryConflict("a decision has exactly one outcome")
        lesson = self._derive_lesson(trace, outcome, move_threshold)
        self._put_all([("outcome", outcome.trace_id, asdict(outcome)), ("lesson", lesson.lesson_id, asdict(lesson))])
        self.working.open_decisions.pop(outcome.trace_id, None)
        return lesson

    def _derive_lesson(self, trace: DecisionTrace, outcome: Outcome, move_threshold: float) -> Lesson:
        error_type, delta, blamed = self._classify(trace, outcome.realized_return, move_threshold)
        lid = _hash({"trace": outcome.trace_id, "result": outcome.result, "r": outcome.realized_return,
                     "resolved": outcome.resolved_at_ms, "threshold": move_threshold})
        return Lesson(lid, outcome.trace_id, error_type, f"Outcome={outcome.result}; error_type={error_type}", delta, False,
                      trace.causal_path, blamed, outcome.resolved_at_ms, move_threshold)

    def _classify(self, trace: DecisionTrace, realized: float | None, threshold: float) -> tuple[str, float, tuple[str, ...]]:
        if realized is None:
            return "UNRESOLVED", 0.0, ()
        # Blame only the sources whose evidence supported the chosen direction.
        blame_ids = trace.supporting_observation_ids or trace.observation_ids
        sources = tuple(sorted({(self.memory.get("observation", oid) or {}).get("source", "") for oid in blame_ids} - {""}))
        if trace.direction == NO_DIRECTION:
            if abs(realized) >= threshold and trace.reason not in ("NO_HYPOTHESES", "NO_DIRECTIONAL_HYPOTHESIS"):
                return "MISSED_MOVE", 0.0, ()
            return "CORRECT_ABSTENTION", 0.0, ()
        signed = (1.0 if trace.direction == "UP" else -1.0) * float(realized)
        if signed > 0:
            return "CORRECT_DIRECTION", 0.05, ()
        return ("OVERCONFIDENT_WRONG_DIRECTION" if trace.confidence >= 0.8 else "WRONG_DIRECTION"), -0.05, sources

    def _verify_lesson(self, lesson: Lesson) -> None:
        """A lesson is genuine only if it is the stored one AND re-derives from its stored decision and outcome."""
        stored = self.memory.get("lesson", lesson.lesson_id)
        if stored is None or _canon(stored) != _canon(asdict(lesson)):
            raise PermissionError("lesson is not the immutable lesson recorded by the brain")
        decision, outcome = self.memory.get("decision", lesson.trace_id), self.memory.get("outcome", lesson.trace_id)
        if decision is None or outcome is None:
            raise PermissionError("lesson is not tied to a recorded decision and outcome")
        derived = self._derive_lesson(self._trace_from(decision), Outcome(**outcome), lesson.move_threshold)
        if _canon(asdict(derived)) != _canon(asdict(lesson)):
            raise PermissionError("lesson does not follow from its decision and outcome")

    @staticmethod
    def _derive_challenger(lesson: Lesson, champion: ReasoningPolicy) -> ChallengerProposal | None:
        """The challenger a lesson implies for a champion, or None when the lesson implies no change."""
        if lesson.error_type in ("WRONG_DIRECTION", "OVERCONFIDENT_WRONG_DIRECTION") and lesson.blamed_sources:
            rel = dict(champion.source_reliability)
            for s in lesson.blamed_sources:
                rel[s] = round(max(0.0, champion.reliability(s) - 0.1), 6)
            candidate = replace(champion, source_reliability=rel)
            change = f"reduce reliability of {', '.join(lesson.blamed_sources)} by 0.1"
        elif lesson.error_type == "MISSED_MOVE":
            candidate = replace(champion, minimum_confidence=round(max(0.5, champion.minimum_confidence - 0.05), 6))
            change = "lower minimum_confidence by 0.05"
        else:
            return None
        if asdict(candidate) == asdict(champion):
            return None  # already at the bound: nothing would change
        version = f"challenger-{_hash({'parent': champion.policy_hash(), 'lesson': lesson.lesson_id, 'candidate': asdict(candidate)})}"
        candidate = replace(candidate, version=version, parent=champion.version)
        return ChallengerProposal(lesson.lesson_id, "reasoning_policy", change, True, version, asdict(candidate), "QUARANTINED", lesson.created_at_ms)

    def propose_challenger(self, lesson: Lesson) -> ChallengerProposal:
        """Controlled learning: a lesson can only produce a QUARANTINED challenger policy.

        Unresolved or correct outcomes teach nothing and are refused, and a lesson
        already applied to the policy cannot be applied again (no compounding).
        Re-proposing against the same champion returns the same proposal.
        """
        self._verify_lesson(lesson)
        if any(e.get("lesson_id") == lesson.lesson_id for e in self.memory.list_kind("policy_event")):
            raise MemoryConflict("lesson was already applied to the policy: one lesson, one learning step")
        proposal = self._derive_challenger(lesson, self.active_policy)
        if proposal is None:
            raise ValueError(f"a {lesson.error_type} lesson implies no policy change; nothing to learn")
        self.memory.put("challenger", proposal.challenger_version, asdict(proposal))
        return proposal

    def _verify_challenger(self, proposal: ChallengerProposal) -> None:
        """Genuine = stored, quarantined, and re-derivable from its genuine lesson and its parent policy."""
        stored = self.memory.get("challenger", proposal.challenger_version)
        if stored is None or _canon(stored) != _canon(asdict(proposal)):
            raise PermissionError("challenger proposal is not the quarantined proposal in memory")
        if proposal.status != "QUARANTINED" or not proposal.requires_validation:
            raise PermissionError("only a quarantined challenger requiring validation can be validated or accepted")
        raw_lesson = self.memory.get("lesson", proposal.lesson_id)
        if raw_lesson is None:
            raise PermissionError("challenger has no recorded lesson")
        self._verify_lesson(_lesson_from(raw_lesson))
        try:
            parent = self._load_policy(proposal.policy.get("parent"))
        except MemoryConflict as exc:
            raise PermissionError("challenger parent policy is not in memory") from exc
        derived = self._derive_challenger(_lesson_from(raw_lesson), parent)
        if derived is None or _canon(asdict(derived)) != _canon(asdict(proposal)):
            raise PermissionError("challenger does not follow from its lesson and parent policy")

    def validate_challenger(self, proposal: ChallengerProposal, cases: Sequence[tuple[Sequence[Observation], Sequence[CausalLink], int, float]], *, min_cases: int = 20) -> ValidationReport:
        """Replay held-out resolved cases under champion and challenger in a sandbox.

        cases: (observations, links, as_of_ms, realized_return). Only cases whose
        as_of is AFTER the lesson that created the challenger count (no validation
        on the data the lesson was learned from). Nothing is written to the live
        memory: both policies run in a throwaway in-memory brain. The report
        records the latest time whose information it used (latest case as_of plus
        the default horizon), which bounds when an accepted policy may take effect.
        """
        self._verify_challenger(proposal)
        champion = self.active_policy
        if proposal.policy.get("parent") != champion.version:
            raise PermissionError("challenger is based on a stale policy")
        challenger = ReasoningPolicy(**{**proposal.policy, "source_reliability": dict(proposal.policy.get("source_reliability", {}))})
        held_out = [c for c in cases if c[2] > proposal.created_at_ms]

        def score(policy: ReasoningPolicy) -> tuple[float, list[str]]:
            sandbox = UnifiedBrain(SQLiteMemoryStore(), initial_policy=policy, domain=self.domain)
            total, ids = 0.0, []
            for obs, links, as_of, realized in held_out:
                t = sandbox.think(list(obs), as_of_ms=as_of, links=list(links))
                ids.append(t.trace_id)
                if t.direction != NO_DIRECTION:
                    total += (1.0 if t.direction == "UP" else -1.0) * realized
            return total, ids

        champ, _ = score(champion)
        chall, ids = score(challenger)
        passed = len(held_out) >= min_cases and chall > champ
        reason = "INSUFFICIENT_HELD_OUT_CASES" if len(held_out) < min_cases else ("CHALLENGER_BETTER" if passed else "CHALLENGER_NOT_BETTER")
        knowledge = max((int(c[2]) + DEFAULT_HORIZON_MS for c in held_out), default=proposal.created_at_ms)
        report = ValidationReport(proposal.challenger_version, len(held_out), round(champ, 10), round(chall, 10), passed, reason, tuple(ids), knowledge)
        self.memory.put("validation", self._report_key(report), asdict(report))
        return report

    @staticmethod
    def _report_key(report: ValidationReport) -> str:
        return f"{report.challenger_version}:{_hash(asdict(report))}"

    def accept_challenger(self, proposal: ChallengerProposal, report: ValidationReport, *, approved_by: str,
                          effective_from_ms: int | None = None) -> ReasoningPolicy:
        """The only path that changes behaviour: validated AND explicitly approved.

        The policy governs decisions from ``effective_from_ms`` on, which can never be
        earlier than the lesson, the validation data or the previous policy.
        """
        if not approved_by:
            raise PermissionError("acceptance requires an explicit approver")
        self._verify_challenger(proposal)
        stored = self.memory.get("validation", self._report_key(report))
        if stored is None or not stored.get("passed") or _canon(stored) != _canon(asdict(report)) or report.challenger_version != proposal.challenger_version:
            raise PermissionError("challenger has no passing validation on record")
        events = self.memory.list_kind("policy_event")
        if any(e.get("active") == proposal.challenger_version for e in events):
            raise MemoryConflict("challenger policy was already accepted")
        history = self._history()
        if proposal.policy.get("parent") != history[-1][0].version:
            raise PermissionError("challenger is based on a stale policy")
        floor = max(proposal.created_at_ms, report.knowledge_until_ms, history[-1][1])
        effective = floor if effective_from_ms is None else int(effective_from_ms)
        if effective < floor:
            raise LeakageError("a policy cannot take effect before the information it was learned and validated on")
        policy = ReasoningPolicy(**{**proposal.policy, "source_reliability": dict(proposal.policy.get("source_reliability", {}))})
        seq = len(events) + 1
        self._put_all([("policy", policy.version, asdict(policy)),
                       ("policy_event", f"{seq:04d}", {"seq": seq, "active": policy.version, "reason": f"ACCEPTED_BY:{approved_by}",
                                                       "policy_hash": policy.policy_hash(), "lesson_id": proposal.lesson_id,
                                                       "effective_from_ms": effective, "validation": asdict(report)})])
        return policy


# ------------------------------------------- trading domain adapter (XAU/USD)
# Everything below is domain-specific. The reasoning core above never refers to it.

class DecisionAction(str, Enum):
    WAIT = "WAIT"
    BUY = "BUY"
    SELL = "SELL"


XAUUSD_DOMAIN = DecisionDomain("XAUUSD", "XAU", {"UP": DecisionAction.BUY, "DOWN": DecisionAction.SELL}, DecisionAction.WAIT)


def observation_from_market(snapshot: MarketSnapshot, *, available_at_ms: int, source: str) -> Observation:
    """Reuses the existing trading_ai.core.MarketSnapshot contract as an input."""
    snapshot.validate()
    values: dict[str, Any] = {"bid": float(snapshot.bid), "ask": float(snapshot.ask), "spread": float(snapshot.spread)}
    values.update({str(k): float(v) for k, v in snapshot.features.items()})
    obs = Observation(f"mkt:{snapshot.symbol}:{snapshot.timestamp_ms}", int(snapshot.timestamp_ms), int(available_at_ms), source, values, True)
    obs.validate()
    return obs


def observation_from_analyst(context: AnalystContext, *, observed_at_ms: int, available_at_ms: int, source: str) -> Observation:
    """Analyst context stays an independent input; it is not a BUY/SELL rule."""
    c = context.normalized()
    obs = Observation(f"analyst:{source}:{available_at_ms}", observed_at_ms, available_at_ms, source,
                      {"analyst_direction": c.direction, "analyst_confidence": c.confidence, "analyst_impact": c.impact}, True)
    obs.validate()
    return obs
