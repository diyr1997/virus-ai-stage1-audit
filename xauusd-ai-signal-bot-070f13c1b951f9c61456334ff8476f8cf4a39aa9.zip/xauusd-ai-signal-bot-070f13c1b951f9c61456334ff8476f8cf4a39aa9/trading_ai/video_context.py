from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import datetime, timezone
from statistics import fmean
from typing import Sequence

from .dataset import Candle, validate_candles
from .market_structure import ConfirmedSwing, confirmed_swings
from .session_context import (
    ASIA_START_MINUTE_UTC,
    LONDON_BST_START_MINUTE_UTC,
    LONDON_GMT_START_MINUTE_UTC,
    NEW_YORK_EDT_START_MINUTE_UTC,
    NEW_YORK_EST_START_MINUTE_UTC,
    session_context,
)


@dataclass(frozen=True)
class VideoContextConfig:
    """Frozen, causal research definitions for methods discussed in the videos.

    These are numerical context features, never trading commands.  The fixed
    2/4/5/6-hour ideas are encoded as distances from the age of the strongest
    recent 5-minute displacement so the hypothesis can be tested instead of
    hard-coded as a rule.
    """

    swing_left: int = 2
    swing_right: int = 2
    opening_ranges_minutes: tuple[int, ...] = (15, 30, 60)
    impulse_window_minutes: int = 5
    impulse_search_minutes: int = 360
    timing_targets_minutes: tuple[int, ...] = (120, 240, 300, 360)
    time_at_price_lookback: int = 120
    time_at_price_bins: int = 20

    def validate(self) -> "VideoContextConfig":
        for name in (
            "swing_left",
            "swing_right",
            "impulse_window_minutes",
            "impulse_search_minutes",
            "time_at_price_lookback",
            "time_at_price_bins",
        ):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
                raise ValueError(f"{name} must be a positive integer")
        if self.impulse_search_minutes <= self.impulse_window_minutes:
            raise ValueError("impulse_search_minutes must exceed impulse_window_minutes")
        for collection_name in ("opening_ranges_minutes", "timing_targets_minutes"):
            values = getattr(self, collection_name)
            if not values or any(isinstance(v, bool) or not isinstance(v, int) or v <= 0 for v in values):
                raise ValueError(f"{collection_name} must contain positive integers")
        if tuple(sorted(set(self.opening_ranges_minutes))) != self.opening_ranges_minutes:
            raise ValueError("opening_ranges_minutes must be sorted and unique")
        if tuple(sorted(set(self.timing_targets_minutes))) != self.timing_targets_minutes:
            raise ValueError("timing_targets_minutes must be sorted and unique")
        return self


DEFAULT_VIDEO_CONTEXT_CONFIG = VideoContextConfig()


def _atr_norm(value: float, atr_value: float) -> float:
    return float(value) / float(atr_value) if float(atr_value) > 1e-12 else 0.0


def _last_confirmed_leg(
    candles: Sequence[Candle],
    *,
    left: int,
    right: int,
) -> tuple[ConfirmedSwing, ConfirmedSwing] | None:
    """Return the latest two alternating swings known before the current bar."""

    current_index = len(candles) - 1
    known = [
        swing
        for swing in confirmed_swings(candles, left=left, right=right)
        if swing.confirmation_index < current_index
    ]
    if len(known) < 2:
        return None
    latest = known[-1]
    for previous in reversed(known[:-1]):
        if previous.kind != latest.kind and previous.index < latest.index:
            return previous, latest
    return None


def fibonacci_ote_features(
    candles: Sequence[Candle],
    *,
    atr_value: float,
    config: VideoContextConfig = DEFAULT_VIDEO_CONTEXT_CONFIG,
) -> dict[str, float]:
    """Causal Fibonacci/OTE geometry from the latest confirmed swing leg.

    This tests whether 0.50/0.618/0.786 retracement geometry adds information. It
    does not assume those ratios have predictive power and emits no BUY/SELL rule.
    """

    cfg = config.validate()
    rows = tuple(candles)
    if not rows:
        return {
            "fib_ready": 0.0,
            "fib_leg_direction": 0.0,
            "fib_leg_range_atr": 0.0,
            "fib_leg_age_bars": 0.0,
            "fib_dist_050_atr": 0.0,
            "fib_dist_0618_atr": 0.0,
            "fib_dist_0786_atr": 0.0,
            "fib_ote_zone": 0.0,
        }
    validate_candles(rows)
    if not math.isfinite(float(atr_value)) or float(atr_value) <= 1e-12:
        return {
            "fib_ready": 0.0,
            "fib_leg_direction": 0.0,
            "fib_leg_range_atr": 0.0,
            "fib_leg_age_bars": 0.0,
            "fib_dist_050_atr": 0.0,
            "fib_dist_0618_atr": 0.0,
            "fib_dist_0786_atr": 0.0,
            "fib_ote_zone": 0.0,
        }

    leg = _last_confirmed_leg(rows, left=cfg.swing_left, right=cfg.swing_right)
    if leg is None:
        return {
            "fib_ready": 0.0,
            "fib_leg_direction": 0.0,
            "fib_leg_range_atr": 0.0,
            "fib_leg_age_bars": 0.0,
            "fib_dist_050_atr": 0.0,
            "fib_dist_0618_atr": 0.0,
            "fib_dist_0786_atr": 0.0,
            "fib_ote_zone": 0.0,
        }

    first, last = leg
    if first.kind == "LOW" and last.kind == "HIGH":
        direction = 1.0
        low = float(first.price)
        high = float(last.price)
        level = lambda ratio: high - ratio * (high - low)
    elif first.kind == "HIGH" and last.kind == "LOW":
        direction = -1.0
        high = float(first.price)
        low = float(last.price)
        level = lambda ratio: low + ratio * (high - low)
    else:
        raise AssertionError("alternating swing contract violated")

    span = max(high - low, 0.0)
    close = float(rows[-1].close)
    l50 = level(0.50)
    l618 = level(0.618)
    l786 = level(0.786)
    ote_low, ote_high = sorted((l618, l786))
    return {
        "fib_ready": 1.0,
        "fib_leg_direction": direction,
        "fib_leg_range_atr": _atr_norm(span, atr_value),
        "fib_leg_age_bars": float((len(rows) - 1) - last.confirmation_index),
        "fib_dist_050_atr": _atr_norm(close - l50, atr_value),
        "fib_dist_0618_atr": _atr_norm(close - l618, atr_value),
        "fib_dist_0786_atr": _atr_norm(close - l786, atr_value),
        "fib_ote_zone": float(ote_low <= close <= ote_high),
    }


def _minute_of_day(timestamp_ms: int) -> int:
    dt = datetime.fromtimestamp(int(timestamp_ms) / 1000.0, tz=timezone.utc)
    return dt.hour * 60 + dt.minute


def opening_range_features(
    m1_candles: Sequence[Candle],
    *,
    end_timestamp_ms: int,
    atr_value: float,
    config: VideoContextConfig = DEFAULT_VIDEO_CONTEXT_CONFIG,
) -> dict[str, float]:
    """Numerical Asia/London/New-York opening-range context at 15/30/60m."""

    cfg = config.validate()
    rows = tuple(c for c in m1_candles if int(c.timestamp_ms) <= int(end_timestamp_ms))
    validate_candles(rows)
    ctx = session_context(int(end_timestamp_ms))
    decision_dt = datetime.fromtimestamp(int(end_timestamp_ms) / 1000.0, tz=timezone.utc)
    decision_date = decision_dt.date()
    london_start = LONDON_BST_START_MINUTE_UTC if ctx.london_dst else LONDON_GMT_START_MINUTE_UTC
    ny_start = NEW_YORK_EDT_START_MINUTE_UTC if ctx.new_york_dst else NEW_YORK_EST_START_MINUTE_UTC
    starts = {
        "asia": ASIA_START_MINUTE_UTC,
        "london": london_start,
        "new_york": ny_start,
    }
    close = float(rows[-1].close) if rows else 0.0
    values: dict[str, float] = {}

    for session_name, start_minute in starts.items():
        for width in cfg.opening_ranges_minutes:
            stem = f"opening_range_{session_name}_{width}m"
            range_end = start_minute + width
            decision_minute = _minute_of_day(end_timestamp_ms)
            ready_by_clock = decision_minute >= range_end
            selected = [
                row
                for row in rows
                if datetime.fromtimestamp(row.timestamp_ms / 1000.0, tz=timezone.utc).date() == decision_date
                and start_minute <= _minute_of_day(row.timestamp_ms) < range_end
            ]
            complete = ready_by_clock and len(selected) == width
            values[f"{stem}_ready"] = float(complete)
            if not complete or atr_value <= 1e-12:
                for suffix in (
                    "width_atr",
                    "dist_to_high_atr",
                    "dist_to_low_atr",
                    "position",
                    "break_above",
                    "break_below",
                ):
                    values[f"{stem}_{suffix}"] = 0.0
                continue
            high = max(float(row.high) for row in selected)
            low = min(float(row.low) for row in selected)
            width_price = high - low
            values[f"{stem}_width_atr"] = _atr_norm(width_price, atr_value)
            values[f"{stem}_dist_to_high_atr"] = _atr_norm(close - high, atr_value)
            values[f"{stem}_dist_to_low_atr"] = _atr_norm(close - low, atr_value)
            values[f"{stem}_position"] = (close - low) / width_price if width_price > 1e-12 else 0.5
            values[f"{stem}_break_above"] = float(close > high)
            values[f"{stem}_break_below"] = float(close < low)
    return values


def timed_pullback_hypothesis_features(
    m1_candles: Sequence[Candle],
    *,
    atr_value: float,
    config: VideoContextConfig = DEFAULT_VIDEO_CONTEXT_CONFIG,
) -> dict[str, float]:
    """Encode the 2/4/5/6h-after-impulse hypothesis without assuming it is true."""

    cfg = config.validate()
    rows = tuple(m1_candles)
    validate_candles(rows)
    targets = cfg.timing_targets_minutes
    values = {"timed_impulse_ready": 0.0, "timed_impulse_direction": 0.0, "timed_impulse_size_atr": 0.0,
              "timed_impulse_age_minutes": 0.0, "timed_impulse_pullback_atr": 0.0}
    for target in targets:
        values[f"timed_impulse_age_minus_{target}m_scaled"] = 0.0

    window = cfg.impulse_window_minutes
    search = cfg.impulse_search_minutes
    if len(rows) < search + window + 1 or not math.isfinite(float(atr_value)) or atr_value <= 1e-12:
        return values

    current_index = len(rows) - 1
    earliest = max(window, current_index - search)
    latest = current_index - 1
    candidates: list[tuple[float, int, float]] = []
    for endpoint in range(earliest, latest + 1):
        delta = float(rows[endpoint].close) - float(rows[endpoint - window].close)
        candidates.append((abs(delta), endpoint, delta))
    if not candidates:
        return values

    _, endpoint, delta = max(candidates, key=lambda item: (item[0], item[1]))
    direction = 1.0 if delta > 0 else -1.0 if delta < 0 else 0.0
    age = current_index - endpoint
    pullback_signed = direction * (float(rows[-1].close) - float(rows[endpoint].close))
    values.update({
        "timed_impulse_ready": 1.0,
        "timed_impulse_direction": direction,
        "timed_impulse_size_atr": _atr_norm(abs(delta), atr_value),
        "timed_impulse_age_minutes": float(age),
        "timed_impulse_pullback_atr": _atr_norm(pullback_signed, atr_value),
    })
    for target in targets:
        values[f"timed_impulse_age_minus_{target}m_scaled"] = (float(age) - float(target)) / float(target)
    return values


def time_at_price_proxy_features(
    m1_candles: Sequence[Candle],
    *,
    atr_value: float,
    config: VideoContextConfig = DEFAULT_VIDEO_CONTEXT_CONFIG,
) -> dict[str, float]:
    """Time-at-price close-density proxy; explicitly not true Market Profile/TPO."""

    cfg = config.validate()
    rows = tuple(m1_candles)
    validate_candles(rows)
    values = {
        "time_at_price_proxy_ready": 0.0,
        "time_at_price_proxy_modal_occupancy": 0.0,
        "time_at_price_proxy_modal_dist_atr": 0.0,
        "time_at_price_proxy_entropy": 0.0,
    }
    if len(rows) < cfg.time_at_price_lookback or atr_value <= 1e-12:
        return values
    recent = rows[-cfg.time_at_price_lookback :]
    lows = [float(row.low) for row in recent]
    highs = [float(row.high) for row in recent]
    lo = min(lows)
    hi = max(highs)
    span = hi - lo
    if span <= 1e-12:
        return values

    bins = cfg.time_at_price_bins
    counts = [0] * bins
    for row in recent:
        position = (float(row.close) - lo) / span
        index = min(bins - 1, max(0, int(position * bins)))
        counts[index] += 1
    modal_index = max(range(bins), key=lambda idx: (counts[idx], -idx))
    modal_center = lo + (modal_index + 0.5) * span / bins
    total = float(sum(counts))
    probabilities = [count / total for count in counts if count > 0]
    entropy = -sum(p * math.log(p) for p in probabilities) / math.log(bins) if bins > 1 else 0.0
    return {
        "time_at_price_proxy_ready": 1.0,
        "time_at_price_proxy_modal_occupancy": counts[modal_index] / total,
        "time_at_price_proxy_modal_dist_atr": _atr_norm(float(rows[-1].close) - modal_center, atr_value),
        "time_at_price_proxy_entropy": float(entropy),
    }


def video_method_feature_block(
    m1_candles: Sequence[Candle],
    *,
    atr_value: float,
    end_timestamp_ms: int,
    config: VideoContextConfig = DEFAULT_VIDEO_CONTEXT_CONFIG,
) -> dict[str, float]:
    """Combine all currently honest-to-compute video-method context features."""

    values: dict[str, float] = {}
    values.update(fibonacci_ote_features(m1_candles, atr_value=atr_value, config=config))
    values.update(opening_range_features(m1_candles, end_timestamp_ms=end_timestamp_ms, atr_value=atr_value, config=config))
    values.update(timed_pullback_hypothesis_features(m1_candles, atr_value=atr_value, config=config))
    values.update(time_at_price_proxy_features(m1_candles, atr_value=atr_value, config=config))
    return values


__all__ = [
    "VideoContextConfig",
    "DEFAULT_VIDEO_CONTEXT_CONFIG",
    "fibonacci_ote_features",
    "opening_range_features",
    "timed_pullback_hypothesis_features",
    "time_at_price_proxy_features",
    "video_method_feature_block",
]
