from __future__ import annotations

from dataclasses import dataclass
from math import isfinite
from numbers import Real
from statistics import mean
from typing import Sequence

from .dataset import Candle


@dataclass(frozen=True)
class MarketStructureConfig:
    """Versioned research parameters for the ATR/structure feature block.

    These defaults are hypotheses to ablate, not trading rules or claims of edge.
    The shadow/research registry uses this default object; research callers can
    pass a different frozen config explicitly for controlled experiments.
    """

    atr_period: int = 14
    swing_left: int = 2
    swing_right: int = 2
    retest_tolerance_atr: float = 0.15

    def validate(self) -> "MarketStructureConfig":
        for name in ("atr_period", "swing_left", "swing_right"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
                raise ValueError(f"{name} must be a positive integer")
        tolerance = self.retest_tolerance_atr
        if isinstance(tolerance, bool) or not isinstance(tolerance, Real):
            raise TypeError("retest_tolerance_atr must be a real numeric scalar")
        if not isfinite(float(tolerance)) or float(tolerance) < 0.0:
            raise ValueError("retest_tolerance_atr must be finite and non-negative")
        return self


DEFAULT_MARKET_STRUCTURE_CONFIG = MarketStructureConfig()


@dataclass(frozen=True)
class ConfirmedSwing:
    """A pivot that becomes usable only after its right-side bars have closed."""

    kind: str  # HIGH or LOW
    index: int
    confirmation_index: int
    price: float


def true_ranges(candles: Sequence[Candle]) -> list[float]:
    """Causal True Range sequence in price units."""

    result: list[float] = []
    previous_close: float | None = None
    for candle in candles:
        high = float(candle.high)
        low = float(candle.low)
        if previous_close is None:
            tr = high - low
        else:
            tr = max(high - low, abs(high - previous_close), abs(low - previous_close))
        result.append(max(float(tr), 0.0))
        previous_close = float(candle.close)
    return result


def wilder_atr(candles: Sequence[Candle], period: int = 14) -> float:
    """Return Wilder ATR available at the last closed candle.

    Returns 0 until a full initial period exists. Consumers must use the explicit
    atr_ready feature before interpreting ATR-normalized fields. Mature values use
    the standard initial arithmetic mean followed by Wilder smoothing.
    """

    if isinstance(period, bool) or not isinstance(period, int) or period <= 0:
        raise ValueError("period must be a positive integer")
    ranges = true_ranges(candles)
    if len(ranges) < period:
        return 0.0
    value = mean(ranges[:period])
    for tr in ranges[period:]:
        value = ((period - 1) * value + tr) / period
    return float(value)


def confirmed_swings(
    candles: Sequence[Candle],
    *,
    left: int = 2,
    right: int = 2,
) -> list[ConfirmedSwing]:
    """Find strictly confirmed swing highs/lows without future leakage.

    A pivot at index i is not emitted until i+right exists. Equal-height/low
    plateaus are intentionally not classified as pivots in v1; this gives one
    deterministic definition that can later be challenged in ablation tests.
    """

    if (
        isinstance(left, bool)
        or isinstance(right, bool)
        or not isinstance(left, int)
        or not isinstance(right, int)
        or left <= 0
        or right <= 0
    ):
        raise ValueError("left and right must be positive integers")
    n = len(candles)
    if n < left + right + 1:
        return []

    result: list[ConfirmedSwing] = []
    for i in range(left, n - right):
        high = float(candles[i].high)
        low = float(candles[i].low)
        neighbors = [candles[j] for j in range(i - left, i + right + 1) if j != i]
        if all(high > float(item.high) for item in neighbors):
            result.append(ConfirmedSwing("HIGH", i, i + right, high))
        if all(low < float(item.low) for item in neighbors):
            result.append(ConfirmedSwing("LOW", i, i + right, low))
    return result


def _latest_active_breakout_before_current(
    candles: Sequence[Candle],
    swing: ConfirmedSwing,
    *,
    direction: str,
) -> int | None:
    """Return the latest still-active prior breakout of a confirmed level.

    The scan starts strictly after confirmation and excludes the current bar.
    A close back through the level invalidates the active breakout. A later prior
    recross may start a new active breakout. This prevents a current re-breakout
    after an invalidation from being mislabeled as a retest of stale state.
    """

    current_index = len(candles) - 1
    if swing.confirmation_index >= current_index:
        return None
    if direction not in {"UP", "DOWN"}:
        raise ValueError("direction must be UP or DOWN")

    active_breakout: int | None = None
    start = max(int(swing.confirmation_index) + 1, 1)
    level = float(swing.price)
    for i in range(start, current_index):
        previous = float(candles[i - 1].close)
        current = float(candles[i].close)
        if direction == "UP":
            if previous <= level and current > level:
                active_breakout = i
            elif active_breakout is not None and current < level:
                active_breakout = None
        else:
            if previous >= level and current < level:
                active_breakout = i
            elif active_breakout is not None and current > level:
                active_breakout = None
    return active_breakout


def _latest_retest_candidate(
    candles: Sequence[Candle],
    swings: Sequence[ConfirmedSwing],
    *,
    kind: str,
) -> tuple[ConfirmedSwing, int] | None:
    """Return the confirmed level with the most recent active prior breakout.

    If multiple levels share the same breakout bar, the more recently confirmed
    swing wins as a deterministic tie-breaker.
    """

    if kind not in {"HIGH", "LOW"}:
        raise ValueError("kind must be HIGH or LOW")
    direction = "UP" if kind == "HIGH" else "DOWN"
    best: tuple[ConfirmedSwing, int] | None = None
    best_key: tuple[int, int, int] | None = None
    for swing in swings:
        if swing.kind != kind:
            continue
        breakout = _latest_active_breakout_before_current(candles, swing, direction=direction)
        if breakout is None:
            continue
        key = (breakout, int(swing.confirmation_index), int(swing.index))
        if best_key is None or key > best_key:
            best = (swing, breakout)
            best_key = key
    return best


def market_structure_features(
    candles: Sequence[Candle],
    *,
    atr_value: float,
    config: MarketStructureConfig = DEFAULT_MARKET_STRUCTURE_CONFIG,
) -> dict[str, float]:
    """Causal numerical structure features for the last closed candle.

    Event flags only use levels that were confirmed before the current candle.
    A retest additionally requires a still-active prior breakout that occurred
    after confirmation. No maximum retest age/distance is imposed in v1; instead
    bars_since_breakout is exposed so that staleness can be tested in ablation.
    """

    if not candles:
        return {}
    config = config.validate()
    if isinstance(atr_value, bool) or not isinstance(atr_value, Real):
        raise TypeError("atr_value must be a real numeric scalar")
    atr = float(atr_value)
    if not isfinite(atr) or atr < 0.0:
        raise ValueError("atr_value must be finite and non-negative")

    swings = confirmed_swings(
        candles,
        left=config.swing_left,
        right=config.swing_right,
    )
    highs = [item for item in swings if item.kind == "HIGH"]
    lows = [item for item in swings if item.kind == "LOW"]
    last_high = highs[-1] if highs else None
    last_low = lows[-1] if lows else None

    current_index = len(candles) - 1
    current = candles[-1]
    previous = candles[-2] if len(candles) >= 2 else None

    def norm(value: float) -> float:
        return float(value) / atr if atr > 1e-12 else 0.0

    values: dict[str, float] = {
        "structure_has_swing_high": float(last_high is not None),
        "structure_has_swing_low": float(last_low is not None),
        "structure_dist_to_swing_high_atr": 0.0,
        "structure_dist_to_swing_low_atr": 0.0,
        "structure_swing_high_age_since_confirmation_bars": 0.0,
        "structure_swing_low_age_since_confirmation_bars": 0.0,
        "structure_swing_high_age_since_pivot_bars": 0.0,
        "structure_swing_low_age_since_pivot_bars": 0.0,
        "structure_breakout_up_now": 0.0,
        "structure_breakout_down_now": 0.0,
        "structure_sweep_high_reject_now": 0.0,
        "structure_sweep_low_reject_now": 0.0,
        "structure_sweep_high_depth_atr": 0.0,
        "structure_sweep_low_depth_atr": 0.0,
        "structure_retest_up_now": 0.0,
        "structure_retest_down_now": 0.0,
        "structure_bars_since_breakout_up": 0.0,
        "structure_bars_since_breakout_down": 0.0,
    }

    if last_high is not None:
        values["structure_dist_to_swing_high_atr"] = norm(float(current.close) - last_high.price)
        values["structure_swing_high_age_since_confirmation_bars"] = float(
            current_index - last_high.confirmation_index
        )
        values["structure_swing_high_age_since_pivot_bars"] = float(current_index - last_high.index)
    if last_low is not None:
        values["structure_dist_to_swing_low_atr"] = norm(float(current.close) - last_low.price)
        values["structure_swing_low_age_since_confirmation_bars"] = float(
            current_index - last_low.confirmation_index
        )
        values["structure_swing_low_age_since_pivot_bars"] = float(current_index - last_low.index)

    # Current-bar event references must have been known before the current bar.
    known_highs = [item for item in highs if item.confirmation_index < current_index]
    known_lows = [item for item in lows if item.confirmation_index < current_index]
    event_high = known_highs[-1] if known_highs else None
    event_low = known_lows[-1] if known_lows else None

    if event_high is not None:
        level = float(event_high.price)
        if previous is not None and float(previous.close) <= level and float(current.close) > level:
            values["structure_breakout_up_now"] = 1.0
        if float(current.high) > level and float(current.close) <= level:
            values["structure_sweep_high_reject_now"] = 1.0
            values["structure_sweep_high_depth_atr"] = norm(float(current.high) - level)

    if event_low is not None:
        level = float(event_low.price)
        if previous is not None and float(previous.close) >= level and float(current.close) < level:
            values["structure_breakout_down_now"] = 1.0
        if float(current.low) < level and float(current.close) >= level:
            values["structure_sweep_low_reject_now"] = 1.0
            values["structure_sweep_low_depth_atr"] = norm(level - float(current.low))

    tolerance = float(config.retest_tolerance_atr) * atr
    up_candidate = _latest_retest_candidate(candles, known_highs, kind="HIGH")
    if up_candidate is not None and values["structure_breakout_up_now"] == 0.0:
        swing, breakout_index = up_candidate
        level = float(swing.price)
        zone_intersects = float(current.low) <= level + tolerance and float(current.high) >= level - tolerance
        # Strictly above means an exact close at/through the level is rejection,
        # not simultaneously a successful retest and a sweep.
        if zone_intersects and float(current.close) > level:
            values["structure_retest_up_now"] = 1.0
            values["structure_bars_since_breakout_up"] = float(current_index - breakout_index)

    down_candidate = _latest_retest_candidate(candles, known_lows, kind="LOW")
    if down_candidate is not None and values["structure_breakout_down_now"] == 0.0:
        swing, breakout_index = down_candidate
        level = float(swing.price)
        zone_intersects = float(current.high) >= level - tolerance and float(current.low) <= level + tolerance
        if zone_intersects and float(current.close) < level:
            values["structure_retest_down_now"] = 1.0
            values["structure_bars_since_breakout_down"] = float(current_index - breakout_index)

    return values


def atr_structure_features(
    candles: Sequence[Candle],
    *,
    prefix: str,
    config: MarketStructureConfig = DEFAULT_MARKET_STRUCTURE_CONFIG,
) -> dict[str, float]:
    """Prefixed ATR-normalized candle + structure feature block."""

    if not candles:
        return {}
    config = config.validate()
    current = candles[-1]
    atr = wilder_atr(candles, config.atr_period)
    close = max(abs(float(current.close)), 1e-12)
    candle_range = max(float(current.high) - float(current.low), 0.0)
    body = float(current.close) - float(current.open)
    upper = max(float(current.high) - max(float(current.open), float(current.close)), 0.0)
    lower = max(min(float(current.open), float(current.close)) - float(current.low), 0.0)
    atr_ready = len(candles) >= config.atr_period and atr > 1e-12

    def atr_norm(value: float) -> float:
        return float(value) / atr if atr_ready else 0.0

    close_location = (
        (float(current.close) - float(current.low)) / candle_range if candle_range > 1e-12 else 0.5
    )
    block = {
        "atr_ready": float(atr_ready),
        "atr_pct": atr / close if atr_ready else 0.0,
        "body_atr": atr_norm(body),
        "range_atr": atr_norm(candle_range),
        "upper_wick_atr": atr_norm(upper),
        "lower_wick_atr": atr_norm(lower),
        "close_location": float(close_location),
    }
    block.update(market_structure_features(candles, atr_value=atr, config=config))
    return {f"{prefix}_{name}": float(value) for name, value in block.items()}
