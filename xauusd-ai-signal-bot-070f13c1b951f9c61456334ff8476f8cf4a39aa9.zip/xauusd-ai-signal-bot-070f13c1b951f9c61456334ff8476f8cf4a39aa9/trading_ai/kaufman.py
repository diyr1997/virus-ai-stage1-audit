from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from math import isfinite
from numbers import Real
from statistics import mean
from typing import Sequence

from .dataset import Candle, validate_candles


class KaufmanStatus(str, Enum):
    READY = "READY"
    NOT_READY = "NOT_READY"


@dataclass(frozen=True)
class KaufmanConfig:
    """Versioned research hypotheses for Kaufman ER/KAMA.

    Defaults are conventional research starting values, not claims of edge.
    The block is deliberately standalone in v1: it is not added to the default
    Trading AI feature vector until an ablation shows incremental value.
    """

    er_period: int = 10
    fast_period: int = 2
    slow_period: int = 30

    def validate(self) -> "KaufmanConfig":
        for name in ("er_period", "fast_period", "slow_period"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
                raise ValueError(f"{name} must be a positive integer")
        if self.fast_period >= self.slow_period:
            raise ValueError("fast_period must be strictly less than slow_period")
        return self


DEFAULT_KAUFMAN_CONFIG = KaufmanConfig()


@dataclass(frozen=True)
class KaufmanResult:
    status: KaufmanStatus
    efficiency_ratio: float
    kama: float
    previous_kama: float
    distance_atr: float
    slope_atr_per_bar: float
    warmup: bool
    first_output_index: int
    reason: str = ""


def _not_ready(config: KaufmanConfig, reason: str, *, warmup: bool = True) -> KaufmanResult:
    return KaufmanResult(
        status=KaufmanStatus.NOT_READY,
        efficiency_ratio=0.0,
        kama=0.0,
        previous_kama=0.0,
        distance_atr=0.0,
        slope_atr_per_bar=0.0,
        warmup=warmup,
        first_output_index=config.er_period,
        reason=reason,
    )


def _validated_closes(candles: Sequence[Candle]) -> list[float] | None:
    try:
        validate_candles(candles)
    except (TypeError, ValueError):
        return None
    closes: list[float] = []
    for candle in candles:
        values = (candle.open, candle.high, candle.low, candle.close)
        if any(isinstance(value, bool) or not isinstance(value, Real) for value in values):
            return None
        numeric = tuple(float(value) for value in values)
        if any(not isfinite(value) or value <= 0.0 for value in numeric):
            return None
        closes.append(numeric[3])
    return closes


def _efficiency_ratio_at(closes: Sequence[float], index: int, period: int) -> float | None:
    """Return causal ER at index using exactly ``period`` price transitions.

    For n=10 and decision index t, numerator uses C[t] and C[t-10].
    Denominator uses the ten transitions C[t-10]->C[t-9] ... C[t-1]->C[t].
    No bar after t is referenced.
    """

    if index < period or index >= len(closes):
        return None
    change = abs(float(closes[index]) - float(closes[index - period]))
    volatility = sum(
        abs(float(closes[i]) - float(closes[i - 1]))
        for i in range(index - period + 1, index + 1)
    )
    if volatility <= 1e-15:
        # A flat path contains no directional efficiency. ER=1 would falsely
        # describe perfect trend efficiency, so the frozen v1 convention is 0.
        return 0.0
    ratio = change / volatility
    # Floating arithmetic can put a mathematically bounded ratio a few ulps out.
    return min(max(float(ratio), 0.0), 1.0)


def _kama_series(closes: Sequence[float], config: KaufmanConfig) -> list[float | None]:
    """Compute deterministic causal KAMA values with a frozen seed convention.

    Seed: at index n-1, SMA(C[0]..C[n-1]).
    First ER-based KAMA update: index n, requiring n+1 closed prices.
    This avoids using C[n] both inside the seed and again in the first update.
    """

    n = config.er_period
    result: list[float | None] = [None] * len(closes)
    if len(closes) < n:
        return result

    seed_index = n - 1
    result[seed_index] = float(mean(closes[:n]))
    fast_sc = 2.0 / (config.fast_period + 1.0)
    slow_sc = 2.0 / (config.slow_period + 1.0)

    for index in range(n, len(closes)):
        er = _efficiency_ratio_at(closes, index, n)
        previous = result[index - 1]
        if er is None or previous is None:
            return result
        smoothing = (er * (fast_sc - slow_sc) + slow_sc) ** 2
        result[index] = float(previous + smoothing * (closes[index] - previous))
    return result


def kaufman_result(
    candles: Sequence[Candle],
    *,
    atr_value: float | None,
    config: KaufmanConfig = DEFAULT_KAUFMAN_CONFIG,
    decision_timestamp_ms: int | None = None,
) -> KaufmanResult:
    """Return causal Kaufman ER/KAMA context for one closed decision bar.

    If ``decision_timestamp_ms`` is supplied, candles after that exact closed-bar
    timestamp are discarded. The function fails closed when price data or ATR is
    unusable. Seed-affected values are explicitly marked by ``warmup``; v1 uses
    ``t < er_period + slow_period`` as the frozen exclusion boundary.

    ``status=READY`` means the mathematical quantities are calculable. It does
    not mean they are eligible for a model during seed warmup. The exported
    feature block is stricter: warmup rows expose ``kaufman_ready=0`` and zero
    candidate values, so a consumer that obeys the readiness flag cannot train
    on seed-affected values by accident.
    """

    cfg = config.validate()
    if not candles:
        return _not_ready(cfg, "insufficient_history")

    if decision_timestamp_ms is not None:
        if isinstance(decision_timestamp_ms, bool) or not isinstance(decision_timestamp_ms, int):
            raise TypeError("decision_timestamp_ms must be an integer timestamp")
        used: list[Candle] = []
        found = False
        for candle in candles:
            timestamp = int(candle.timestamp_ms)
            if timestamp > decision_timestamp_ms:
                break
            used.append(candle)
            if timestamp == decision_timestamp_ms:
                found = True
        if not found:
            return _not_ready(cfg, "decision_not_available")
        candles = tuple(used)

    closes = _validated_closes(candles)
    if closes is None:
        return _not_ready(cfg, "invalid_price_input")

    current_index = len(closes) - 1
    if current_index < cfg.er_period:
        return _not_ready(cfg, "insufficient_er_history")

    er = _efficiency_ratio_at(closes, current_index, cfg.er_period)
    series = _kama_series(closes, cfg)
    current_kama = series[current_index]
    previous_kama = series[current_index - 1] if current_index > 0 else None
    if er is None or current_kama is None or previous_kama is None:
        return _not_ready(cfg, "kama_not_calculable")

    warmup = current_index < cfg.er_period + cfg.slow_period

    if atr_value is None or isinstance(atr_value, bool) or not isinstance(atr_value, Real):
        return _not_ready(cfg, "atr_not_ready", warmup=warmup)
    atr = float(atr_value)
    if not isfinite(atr) or atr <= 0.0:
        return _not_ready(cfg, "atr_not_ready", warmup=warmup)

    close = closes[current_index]
    return KaufmanResult(
        status=KaufmanStatus.READY,
        efficiency_ratio=float(er),
        kama=float(current_kama),
        previous_kama=float(previous_kama),
        distance_atr=(close - float(current_kama)) / atr,
        slope_atr_per_bar=(float(current_kama) - float(previous_kama)) / atr,
        warmup=warmup,
        first_output_index=cfg.er_period,
        reason="",
    )


def kaufman_feature_block(
    candles: Sequence[Candle],
    *,
    prefix: str,
    atr_value: float | None,
    config: KaufmanConfig = DEFAULT_KAUFMAN_CONFIG,
) -> dict[str, float]:
    """Stable numeric candidate block for controlled ablation experiments.

    Raw KAMA and its deterministic smoothing constant are intentionally omitted.
    Invalid/not-calculable rows and seed-warmup rows both export
    ``kaufman_ready=0`` with zero candidate values. ``kaufman_warmup`` remains
    explicit so research diagnostics can distinguish warmup from data failure.
    This fail-closed export contract prevents a downstream consumer that checks
    only readiness from accidentally using seed-affected KAMA values.
    """

    result = kaufman_result(candles, atr_value=atr_value, config=config)
    usable = result.status is KaufmanStatus.READY and not result.warmup
    return {
        f"{prefix}_kaufman_ready": float(usable),
        f"{prefix}_kaufman_warmup": float(result.warmup),
        f"{prefix}_kaufman_er": result.efficiency_ratio if usable else 0.0,
        f"{prefix}_kama_dist_atr": result.distance_atr if usable else 0.0,
        f"{prefix}_kama_slope_atr_per_bar": result.slope_atr_per_bar if usable else 0.0,
    }
