from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import datetime, timezone
from statistics import fmean, pstdev
from typing import Iterable, Sequence

from .dataset import Candle, validate_candles


INDICATOR_UNIVERSE_VERSION = "xau-top10-v1"
INDICATOR_WARMUP_BARS = 250
BROKER_TICK_VOLUME_PROVENANCE = "broker_tick_volume"

INDICATOR_FAMILY_IDS = (
    "F01_EMA_TREND_STRUCTURE",
    "F02_MACD_PPO",
    "F03_WILDER_RSI",
    "F04_STOCHASTIC",
    "F05_CCI",
    "F06_ADX_DMI",
    "F07_ATR_REALIZED_VOLATILITY",
    "F08_BOLLINGER_KELTNER",
    "F09_DONCHIAN",
    "F10_SESSION_VWAP_VOLUME_FLOW",
)
INDICATOR_FORMULA_CONTRACT = (
    "F01:EMA(close,8,21,55);price-distance,spreads,price-normalized-slopes",
    "F02:PPO(EMA12,EMA26);EMA9-signal;histogram",
    "F03:Wilder-RSI(7,14);RSI14-delta1",
    "F04:stochastic-percent-K14;SMA3-percent-D",
    "F05:CCI20;typical-price;0.015-mean-deviation",
    "F06:Wilder-ADX-DMI14",
    "F07:Wilder-ATR14-over-close;population-std-log-return20,60;vol-ratio",
    "F08:Bollinger-SMA20-2-popstd;Keltner-EMA20-2-WilderATR20",
    "F09:Donchian20,55;exclude-current;position;signed-breakout-distance",
    "F10:UTC-session-VWAP;OBV;CMF20;MFI20;broker-tick-volume-only",
)


@dataclass(frozen=True)
class IndicatorFamilyResult:
    family_id: str
    available: bool
    values: tuple[tuple[str, float], ...] = ()
    provenance: str = "closed_candle_ohlc"
    missing_reason: str | None = None
    warmup_bars: int = INDICATOR_WARMUP_BARS

    def as_dict(self) -> dict[str, float]:
        return dict(self.values)


@dataclass(frozen=True)
class IndicatorUniverseSnapshot:
    timestamp_ms: int
    families: tuple[IndicatorFamilyResult, ...]
    version: str = INDICATOR_UNIVERSE_VERSION
    research_only: bool = True
    execution_allowed: bool = False

    def by_family(self) -> dict[str, IndicatorFamilyResult]:
        return {family.family_id: family for family in self.families}


def _safe_ratio(numerator: float, denominator: float) -> float:
    if denominator == 0.0:
        return 0.0
    return float(numerator) / float(denominator)


def _ema(values: Sequence[float], period: int) -> list[float]:
    if not values:
        return []
    alpha = 2.0 / (int(period) + 1.0)
    result = [float(values[0])]
    for value in values[1:]:
        result.append(alpha * float(value) + (1.0 - alpha) * result[-1])
    return result


def _wilder(values: Sequence[float], period: int) -> list[float]:
    if not values:
        return []
    alpha = 1.0 / int(period)
    result = [float(values[0])]
    for value in values[1:]:
        result.append(alpha * float(value) + (1.0 - alpha) * result[-1])
    return result


def _true_ranges(candles: Sequence[Candle]) -> list[float]:
    values: list[float] = []
    for index, candle in enumerate(candles):
        if index == 0:
            values.append(float(candle.high) - float(candle.low))
            continue
        previous_close = float(candles[index - 1].close)
        values.append(
            max(
                float(candle.high) - float(candle.low),
                abs(float(candle.high) - previous_close),
                abs(float(candle.low) - previous_close),
            )
        )
    return values


def _rsi(closes: Sequence[float], period: int) -> list[float]:
    gains = [0.0]
    losses = [0.0]
    for previous, current in zip(closes, closes[1:]):
        change = float(current) - float(previous)
        gains.append(max(change, 0.0))
        losses.append(max(-change, 0.0))
    average_gain = _wilder(gains, period)
    average_loss = _wilder(losses, period)
    result: list[float] = []
    for gain, loss in zip(average_gain, average_loss):
        if loss == 0.0:
            result.append(100.0 if gain > 0.0 else 50.0)
        else:
            result.append(100.0 - (100.0 / (1.0 + gain / loss)))
    return result


def _stochastic_k(candles: Sequence[Candle], period: int) -> list[float]:
    result: list[float] = []
    for index, candle in enumerate(candles):
        start = max(0, index - period + 1)
        window = candles[start : index + 1]
        highest = max(float(row.high) for row in window)
        lowest = min(float(row.low) for row in window)
        result.append(
            50.0
            if highest == lowest
            else 100.0 * _safe_ratio(float(candle.close) - lowest, highest - lowest)
        )
    return result


def _signed_breakout_distance(close: float, prior_low: float, prior_high: float) -> float:
    width = prior_high - prior_low
    if width <= 0.0:
        return 0.0
    if close > prior_high:
        return (close - prior_high) / width
    if close < prior_low:
        return (close - prior_low) / width
    return 0.0


def _family(family_id: str, values: Iterable[tuple[str, float]], *, provenance: str = "closed_candle_ohlc") -> IndicatorFamilyResult:
    normalized = tuple((str(key), float(value)) for key, value in values)
    if any(not math.isfinite(value) for _, value in normalized):
        return IndicatorFamilyResult(
            family_id=family_id,
            available=False,
            provenance=provenance,
            missing_reason="NON_FINITE_INDICATOR_VALUE",
        )
    return IndicatorFamilyResult(
        family_id=family_id,
        available=True,
        values=normalized,
        provenance=provenance,
    )


def _missing(family_id: str, reason: str, *, provenance: str = "closed_candle_ohlc") -> IndicatorFamilyResult:
    return IndicatorFamilyResult(
        family_id=family_id,
        available=False,
        provenance=provenance,
        missing_reason=reason,
    )


def compute_indicator_universe_at(
    candles: Sequence[Candle],
    *,
    cutoff_timestamp_ms: int | None = None,
    volume_provenance: str | None = None,
    session_timezone: str = "UTC",
) -> IndicatorUniverseSnapshot:
    """Compute the frozen Top-10 universe from fully closed candles only.

    ``cutoff_timestamp_ms`` is inclusive and exists to make prefix-invariance
    testable. Session VWAP resets at the broker daily boundary. Version 1 freezes
    that boundary to 00:00 UTC for the Dukascopy research dataset.
    """
    if session_timezone != "UTC":
        raise ValueError("indicator universe v1 freezes the broker session timezone to UTC")
    rows = tuple(
        candle
        for candle in candles
        if cutoff_timestamp_ms is None or int(candle.timestamp_ms) <= int(cutoff_timestamp_ms)
    )
    validate_candles(rows)
    for candle in rows:
        prices = (candle.open, candle.high, candle.low, candle.close)
        if any(not math.isfinite(float(value)) or float(value) <= 0.0 for value in prices):
            raise ValueError("OHLC prices must be finite and positive")
        if not math.isfinite(float(candle.volume)) or float(candle.volume) < 0.0:
            raise ValueError("candle volume must be finite and non-negative")
    timestamp_ms = int(rows[-1].timestamp_ms) if rows else 0
    if len(rows) < INDICATOR_WARMUP_BARS:
        return IndicatorUniverseSnapshot(
            timestamp_ms=timestamp_ms,
            families=tuple(_missing(family_id, "INSUFFICIENT_250_BAR_WARMUP") for family_id in INDICATOR_FAMILY_IDS),
        )

    closes = [float(row.close) for row in rows]
    highs = [float(row.high) for row in rows]
    lows = [float(row.low) for row in rows]
    volumes = [float(row.volume) for row in rows]
    close = closes[-1]

    ema8 = _ema(closes, 8)
    ema21 = _ema(closes, 21)
    ema55 = _ema(closes, 55)
    f01 = _family(
        INDICATOR_FAMILY_IDS[0],
        (
            ("ema8_distance", _safe_ratio(close - ema8[-1], close)),
            ("ema21_distance", _safe_ratio(close - ema21[-1], close)),
            ("ema55_distance", _safe_ratio(close - ema55[-1], close)),
            ("ema8_21_spread", _safe_ratio(ema8[-1] - ema21[-1], close)),
            ("ema21_55_spread", _safe_ratio(ema21[-1] - ema55[-1], close)),
            ("ema8_slope", _safe_ratio(ema8[-1] - ema8[-2], close)),
            ("ema21_slope", _safe_ratio(ema21[-1] - ema21[-2], close)),
            ("ema55_slope", _safe_ratio(ema55[-1] - ema55[-2], close)),
        ),
    )

    ema12 = _ema(closes, 12)
    ema26 = _ema(closes, 26)
    ppo = [100.0 * _safe_ratio(fast - slow, slow) for fast, slow in zip(ema12, ema26)]
    ppo_signal = _ema(ppo, 9)
    f02 = _family(
        INDICATOR_FAMILY_IDS[1],
        (("ppo", ppo[-1]), ("ppo_signal", ppo_signal[-1]), ("ppo_histogram", ppo[-1] - ppo_signal[-1])),
    )

    rsi7 = _rsi(closes, 7)
    rsi14 = _rsi(closes, 14)
    f03 = _family(
        INDICATOR_FAMILY_IDS[2],
        (("rsi7", rsi7[-1]), ("rsi14", rsi14[-1]), ("rsi14_delta", rsi14[-1] - rsi14[-2])),
    )

    stochastic_k = _stochastic_k(rows, 14)
    f04 = _family(
        INDICATOR_FAMILY_IDS[3],
        (("stochastic_k14", stochastic_k[-1]), ("stochastic_d3", fmean(stochastic_k[-3:]))),
    )

    typical = [(high + low + value) / 3.0 for high, low, value in zip(highs, lows, closes)]
    typical20 = typical[-20:]
    typical_mean = fmean(typical20)
    mean_deviation = fmean(abs(value - typical_mean) for value in typical20)
    cci20 = _safe_ratio(typical[-1] - typical_mean, 0.015 * mean_deviation)
    f05 = _family(INDICATOR_FAMILY_IDS[4], (("cci20", cci20),))

    true_ranges = _true_ranges(rows)
    plus_dm = [0.0]
    minus_dm = [0.0]
    for index in range(1, len(rows)):
        up = highs[index] - highs[index - 1]
        down = lows[index - 1] - lows[index]
        plus_dm.append(up if up > down and up > 0.0 else 0.0)
        minus_dm.append(down if down > up and down > 0.0 else 0.0)
    atr14 = _wilder(true_ranges, 14)
    plus_di = [100.0 * _safe_ratio(value, atr) for value, atr in zip(_wilder(plus_dm, 14), atr14)]
    minus_di = [100.0 * _safe_ratio(value, atr) for value, atr in zip(_wilder(minus_dm, 14), atr14)]
    dx = [100.0 * _safe_ratio(abs(plus - minus), plus + minus) for plus, minus in zip(plus_di, minus_di)]
    adx = _wilder(dx, 14)
    f06 = _family(
        INDICATOR_FAMILY_IDS[5],
        (("adx14", adx[-1]), ("plus_di14", plus_di[-1]), ("minus_di14", minus_di[-1])),
    )

    log_returns = [math.log(current / previous) for previous, current in zip(closes, closes[1:])]
    realized_vol20 = pstdev(log_returns[-20:])
    realized_vol60 = pstdev(log_returns[-60:])
    f07 = _family(
        INDICATOR_FAMILY_IDS[6],
        (
            ("atr14_fraction", _safe_ratio(atr14[-1], close)),
            ("realized_vol20", realized_vol20),
            ("realized_vol60", realized_vol60),
            ("realized_vol_ratio20_60", _safe_ratio(realized_vol20, realized_vol60)),
        ),
    )

    close20 = closes[-20:]
    middle = fmean(close20)
    sigma = pstdev(close20)
    bb_upper = middle + 2.0 * sigma
    bb_lower = middle - 2.0 * sigma
    keltner_middle = _ema(closes, 20)[-1]
    atr20 = _wilder(true_ranges, 20)[-1]
    keltner_upper = keltner_middle + 2.0 * atr20
    keltner_lower = keltner_middle - 2.0 * atr20
    bb_width = _safe_ratio(bb_upper - bb_lower, middle)
    keltner_width = _safe_ratio(keltner_upper - keltner_lower, keltner_middle)
    f08 = _family(
        INDICATOR_FAMILY_IDS[7],
        (
            ("bollinger_z20", _safe_ratio(close - middle, sigma)),
            ("bollinger_width20", bb_width),
            ("keltner_width20", keltner_width),
            ("compression_ratio", _safe_ratio(bb_width, keltner_width)),
            ("squeeze_on", float(bb_upper < keltner_upper and bb_lower > keltner_lower)),
        ),
    )

    donchian_values: list[tuple[str, float]] = []
    for period in (20, 55):
        prior = rows[-period - 1 : -1]
        prior_high = max(float(row.high) for row in prior)
        prior_low = min(float(row.low) for row in prior)
        donchian_values.extend(
            (
                (f"prior_high{period}", prior_high),
                (f"prior_low{period}", prior_low),
                (f"channel_position{period}", _safe_ratio(close - prior_low, prior_high - prior_low)),
                (f"signed_breakout_distance{period}", _signed_breakout_distance(close, prior_low, prior_high)),
            )
        )
    f09 = _family(INDICATOR_FAMILY_IDS[8], donchian_values)

    if volume_provenance != BROKER_TICK_VOLUME_PROVENANCE:
        f10 = _missing(
            INDICATOR_FAMILY_IDS[9],
            "BROKER_TICK_VOLUME_PROVENANCE_REQUIRED",
            provenance=volume_provenance or "missing",
        )
    elif sum(volumes) <= 0.0:
        f10 = _missing(
            INDICATOR_FAMILY_IDS[9],
            "POSITIVE_BROKER_TICK_VOLUME_REQUIRED",
            provenance=BROKER_TICK_VOLUME_PROVENANCE,
        )
    else:
        current_date = datetime.fromtimestamp(timestamp_ms / 1000.0, tz=timezone.utc).date()
        session_rows = tuple(
            row
            for row in rows
            if datetime.fromtimestamp(row.timestamp_ms / 1000.0, tz=timezone.utc).date() == current_date
        )
        session_weight = sum(float(row.volume) for row in session_rows)
        rolling_weight = sum(float(row.volume) for row in rows[-20:])
        if session_weight <= 0.0 or rolling_weight <= 0.0:
            return IndicatorUniverseSnapshot(
                timestamp_ms=timestamp_ms,
                families=(
                    f01,
                    f02,
                    f03,
                    f04,
                    f05,
                    f06,
                    f07,
                    f08,
                    f09,
                    _missing(
                        INDICATOR_FAMILY_IDS[9],
                        "POSITIVE_SESSION_AND_ROLLING_TICK_VOLUME_REQUIRED",
                        provenance=BROKER_TICK_VOLUME_PROVENANCE,
                    ),
                ),
            )
        session_vwap = _safe_ratio(
            sum(((float(row.high) + float(row.low) + float(row.close)) / 3.0) * float(row.volume) for row in session_rows),
            session_weight,
        )
        obv = 0.0
        for previous, row in zip(rows, rows[1:]):
            if row.close > previous.close:
                obv += float(row.volume)
            elif row.close < previous.close:
                obv -= float(row.volume)
        window20 = rows[-20:]
        cmf_numerator = sum(
            _safe_ratio((2.0 * float(row.close)) - float(row.high) - float(row.low), float(row.high) - float(row.low))
            * float(row.volume)
            for row in window20
        )
        cmf20 = _safe_ratio(cmf_numerator, rolling_weight)
        positive_flow = 0.0
        negative_flow = 0.0
        for index in range(len(rows) - 20, len(rows)):
            flow = typical[index] * volumes[index]
            if typical[index] > typical[index - 1]:
                positive_flow += flow
            elif typical[index] < typical[index - 1]:
                negative_flow += flow
        if negative_flow == 0.0:
            mfi20 = 100.0 if positive_flow > 0.0 else 50.0
        else:
            mfi20 = 100.0 - (100.0 / (1.0 + positive_flow / negative_flow))
        f10 = _family(
            INDICATOR_FAMILY_IDS[9],
            (
                ("broker_tick_volume_session_vwap_distance", _safe_ratio(close - session_vwap, close)),
                ("broker_tick_volume_obv_normalized", _safe_ratio(obv, sum(volumes))),
                ("broker_tick_volume_cmf20", cmf20),
                ("broker_tick_volume_mfi20", mfi20),
            ),
            provenance=BROKER_TICK_VOLUME_PROVENANCE,
        )

    return IndicatorUniverseSnapshot(
        timestamp_ms=timestamp_ms,
        families=(f01, f02, f03, f04, f05, f06, f07, f08, f09, f10),
    )
