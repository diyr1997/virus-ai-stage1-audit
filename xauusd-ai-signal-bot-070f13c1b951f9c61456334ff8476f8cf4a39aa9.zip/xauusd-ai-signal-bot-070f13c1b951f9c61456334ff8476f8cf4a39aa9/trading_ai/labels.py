from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from statistics import mean
from typing import Mapping, Sequence

from .pipeline import TrainingSample


class DirectionLabel(str, Enum):
    SELL = "SELL"
    WAIT = "WAIT"
    BUY = "BUY"


@dataclass(frozen=True)
class LabeledSample:
    sample: TrainingSample
    labels: Mapping[int, DirectionLabel]
    thresholds: Mapping[int, float]


def _historical_volatility_scale(
    samples: Sequence[TrainingSample],
    index: int,
    horizon: int,
    lookback: int = 240,
) -> float:
    """Causal volatility estimate from outcomes already resolved at decision time.

    Horizons in ``TrainingSample`` are defined in *future candles*, not elapsed
    wall-clock minutes. Therefore a prior sample at index ``i`` is knowable at
    the current sample only after at least ``horizon`` subsequent samples exist:
    ``i + horizon <= index``.

    Using ``prior_timestamp + horizon * 60s`` is unsafe when M1 history contains
    market closures or missing candles because wall-clock time can advance while
    the required future candles have not occurred yet. Bar-index maturity keeps
    the WAIT threshold causal under weekends and data gaps.
    """
    prior: list[float] = []
    h = int(horizon)
    if h <= 0:
        return 0.0

    for i in range(index - 1, -1, -1):
        if i + h > index:
            continue
        sample = samples[i]
        if h not in sample.future_returns:
            continue
        prior.append(abs(float(sample.future_returns[h])))
        if len(prior) >= int(lookback):
            break

    return mean(prior) if prior else 0.0


def label_direction(
    samples: Sequence[TrainingSample],
    *,
    horizons: Sequence[int] = (1, 3, 5, 10, 15, 30, 60),
    volatility_multiplier: float = 0.60,
    minimum_return: float = 0.00002,
    volatility_lookback: int = 240,
) -> list[LabeledSample]:
    """Create BUY/SELL/WAIT targets from realized future movement.

    The WAIT band is adaptive: threshold = max(minimum_return,
    historical_abs_return_mean * volatility_multiplier). The threshold at sample i
    uses only prior outcomes that were already fully resolved by sample i's bar
    position. The sample's own future return is used only as its target label.

    NOTE: this close-return labeler is retained as a research comparison baseline.
    The executable BID/ASK net-utility contract lives in economic_labels.py and is
    the target contract for cost-aware BUY/SELL/WAIT experiments.
    """
    result: list[LabeledSample] = []
    hs = tuple(int(h) for h in horizons)
    for idx, sample in enumerate(samples):
        labels: dict[int, DirectionLabel] = {}
        thresholds: dict[int, float] = {}
        for h in hs:
            if h not in sample.future_returns:
                continue
            scale = _historical_volatility_scale(samples, idx, h, volatility_lookback)
            threshold = max(float(minimum_return), float(scale) * float(volatility_multiplier))
            realized = float(sample.future_returns[h])
            if realized > threshold:
                label = DirectionLabel.BUY
            elif realized < -threshold:
                label = DirectionLabel.SELL
            else:
                label = DirectionLabel.WAIT
            labels[h] = label
            thresholds[h] = threshold
        result.append(LabeledSample(sample=sample, labels=labels, thresholds=thresholds))
    return result
