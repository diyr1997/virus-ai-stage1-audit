# Anchored-price research contract v1

Research/shadow only. This block does not change production execution, DEMO/live trading, risk sizing, or the frozen verified-core 111-feature contract.

- Default `TIME_WEIGHTED` mode is named `anchored_mean`; it is not called VWAP.
- `CANDLE_VOLUME` requires explicit `VolumeSemantics` and never infers semantics from positive values.
- `TICK_COUNT` is named `tick_weighted_price`, not VWAP.
- Only explicit `TRADE_VOLUME` semantics may use the `trade_volume_vwap` name.
- Invalid/missing weights or semantics and ATR-not-ready return `NOT_READY`; there is no silent fallback.
- V1 anchors are explicit prior closed-bar timestamp/index or bounded trailing-window start.
- Explicit bar-close anchors must be strictly before the decision bar.
- Future bars after an explicit decision timestamp are ignored.
- Features are computed independently per timeframe from closed bars.
- Raw anchored price and redundant `price_above_anchor` are not model features in v1.
- Default HLC3 price basis and 20-bar window are research hypotheses to ablate, not claims of edge.
- Incremental cumulative computation, session anchors, swing anchors, and event/news anchors are deferred until separately reviewed.
