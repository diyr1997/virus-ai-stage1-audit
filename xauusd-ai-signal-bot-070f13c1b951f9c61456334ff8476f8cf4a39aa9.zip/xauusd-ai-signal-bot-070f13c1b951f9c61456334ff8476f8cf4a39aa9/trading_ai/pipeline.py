from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Mapping, Sequence

from .dataset import Candle
from .features import FeatureVector, build_feature_vector
from .mtf import build_mtf_context


DEFAULT_HORIZONS = (1, 3, 5, 10, 15, 30, 60)
DEFAULT_LOOKBACKS = {"M1": 120, "M5": 96, "M15": 64, "M30": 48, "H1": 48}


@dataclass(frozen=True)
class TrainingSample:
    end_timestamp_ms: int
    features: Mapping[str, float]
    future_returns: Mapping[int, float]
    max_favorable_move: Mapping[int, float]
    max_adverse_move: Mapping[int, float]


def _labels(candles: Sequence[Candle], end_idx: int, horizons: Sequence[int]) -> tuple[dict[int, float], dict[int, float], dict[int, float]]:
    entry = float(candles[end_idx].close)
    if entry <= 0:
        raise ValueError("entry close must be positive")
    future_returns: dict[int, float] = {}
    mfe: dict[int, float] = {}
    mae: dict[int, float] = {}
    for h in horizons:
        future = candles[end_idx + 1 : end_idx + h + 1]
        if len(future) != h:
            raise ValueError("insufficient future candles for label")
        if any(c.timestamp_ms <= candles[end_idx].timestamp_ms for c in future):
            raise ValueError("future data leaked into label boundary")
        future_returns[h] = (future[-1].close - entry) / entry
        highest = max(c.high for c in future)
        lowest = min(c.low for c in future)
        mfe[h] = max(0.0, (highest - entry) / entry)
        mae[h] = min(0.0, (lowest - entry) / entry)
    return future_returns, mfe, mae


def build_training_samples(
    m1_candles: Sequence[Candle],
    *,
    horizons: Iterable[int] = DEFAULT_HORIZONS,
    lookbacks: Mapping[str, int] | None = None,
    warmup_m1: int = 3000,
) -> list[TrainingSample]:
    """Build chronological, strictly causal MTF samples using the full past history.

    For each decision timestamp the feature builder receives every available M1
    candle from the beginning of the supplied history through that timestamp.
    No future candle is included. This intentionally prioritizes completeness of
    historical context over computational speed.
    """
    candles = tuple(m1_candles)
    hs = tuple(sorted({int(h) for h in horizons if int(h) > 0}))
    if not hs:
        raise ValueError("at least one horizon is required")
    max_h = max(hs)
    effective_lookbacks = dict(lookbacks or DEFAULT_LOOKBACKS)
    first_end = max(int(warmup_m1) - 1, 0)
    if len(candles) <= first_end + max_h:
        return []

    result: list[TrainingSample] = []
    last_end = len(candles) - max_h - 1
    for end_idx in range(first_end, last_end + 1):
        end_ts = candles[end_idx].timestamp_ms
        history = candles[: end_idx + 1]
        context = build_mtf_context(history, end_timestamp_ms=end_ts, lookbacks=effective_lookbacks)
        vector: FeatureVector = build_feature_vector(context)
        future_returns, mfe, mae = _labels(candles, end_idx, hs)
        result.append(
            TrainingSample(
                end_timestamp_ms=end_ts,
                features=dict(vector.values),
                future_returns=future_returns,
                max_favorable_move=mfe,
                max_adverse_move=mae,
            )
        )
    return result


def chronological_split(
    samples: Sequence[TrainingSample],
    *,
    train_fraction: float = 0.70,
    validation_fraction: float = 0.15,
    purge_bars: int | None = None,
):
    """Simple chronological split with a purge gap for label overlap.

    Each sample label uses future bars. Therefore the last training samples near a
    boundary can contain outcomes that occur inside validation/test. We remove at
    least max(label horizon) samples from the left side of each boundary.

    This helper implements the project's simple one-shot chronological baseline;
    it is NOT a full walk-forward/CPCV validator and it does not implement a
    separate post-test embargo. Before these labels are used for model-selection,
    repeated walk-forward or multiple-hypothesis evaluation, use the dedicated
    validation layer with an explicit embargo and untouched final holdout.
    """
    n = len(samples)
    if n < 3:
        return list(samples), [], []
    train_fraction = float(train_fraction)
    validation_fraction = float(validation_fraction)
    if not 0.0 < train_fraction < 1.0:
        raise ValueError("train_fraction must be between 0 and 1")
    if not 0.0 <= validation_fraction < 1.0 or train_fraction + validation_fraction >= 1.0:
        raise ValueError("invalid validation_fraction")

    inferred_horizon = max((max(s.future_returns) for s in samples if s.future_returns), default=0)
    purge = inferred_horizon if purge_bars is None else int(purge_bars)
    if purge < inferred_horizon:
        raise ValueError("purge_bars must be >= maximum label horizon")

    train_end = max(1, int(n * train_fraction))
    validation_end = max(train_end + 1, int(n * (train_fraction + validation_fraction)))
    validation_end = min(validation_end, n - 1)

    train_stop = max(0, train_end - purge)
    validation_start = train_end
    validation_stop = max(validation_start, validation_end - purge)
    test_start = validation_end

    train = list(samples[:train_stop])
    validation = list(samples[validation_start:validation_stop])
    test = list(samples[test_start:])

    if train and validation and train[-1].end_timestamp_ms >= validation[0].end_timestamp_ms:
        raise ValueError("chronological train/validation overlap")
    if validation and test and validation[-1].end_timestamp_ms >= test[0].end_timestamp_ms:
        raise ValueError("chronological validation/test overlap")
    return train, validation, test
