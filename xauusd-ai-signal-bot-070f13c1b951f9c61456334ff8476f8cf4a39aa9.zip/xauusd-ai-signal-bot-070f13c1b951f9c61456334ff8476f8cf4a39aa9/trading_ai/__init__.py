"""Trading AI package.

The new Trading AI is developed alongside the legacy bot and must remain
SHADOW/DEMO-only until objective promotion gates are passed.
"""

from .core import (
    Action,
    AnalystContext,
    MarketSnapshot,
    TraderDecision,
    TradingAIShadowTrader,
)

__all__ = [
    "Action",
    "AnalystContext",
    "MarketSnapshot",
    "TraderDecision",
    "TradingAIShadowTrader",
]
