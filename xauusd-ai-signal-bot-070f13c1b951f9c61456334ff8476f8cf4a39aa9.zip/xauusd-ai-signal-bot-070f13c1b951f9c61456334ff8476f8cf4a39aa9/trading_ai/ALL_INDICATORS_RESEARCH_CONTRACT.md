# ALL-at-once indicator research contract

## Purpose

Test the user's explicit hypothesis that multiple indicator families may be useful simultaneously because they describe different aspects of market state. The model receives the entire causally available feature set together; indicators are not converted into hard BUY/SELL rules.

## Current-data simultaneous stack

- candle geometry / returns / realized volatility
- Wilder ATR and ATR-normalized market structure
- confirmed swings, breakout, retest and sweep context
- anchored-price context
- Kaufman ER/KAMA
- EMA trend structure
- PPO/MACD
- Wilder RSI
- Stochastic
- CCI
- ADX/DMI
- Bollinger/Keltner compression
- Donchian 20/55
- broker tick-volume flow proxies only when exact provenance is declared
- confirmed-swing Fibonacci 0.50/0.618/0.786 and OTE-zone geometry
- Asia/London/New-York opening ranges 15/30/60 minutes
- weak 2/4/5/6-hour post-impulse timing hypotheses
- time-at-price close-density proxy (not true Market Profile/TPO)
- session/time context
- sampled BID/ASK predictors only when their separate quality gate is READY

## Explicitly not synthesized from current data

True exchange Volume Profile/POC/VAH/VAL, transaction VWAP, Footprint, CVD, classic OFI, aggressive print size, DOM/L2 liquidity heatmap and MBO require new trade/order-book data (future GC/Binance/L2 track). Broker tick volume or close-density proxies must never be renamed as those concepts.

## Model semantics

All groups are numerical evidence. Role groups (trend, momentum/mean reversion, volatility, structure/breakout, anchored levels, volume proxy, session/time, microstructure) are metadata for analysis and later expert routing only. No individual indicator has command or veto power.

## Causality and availability

- only closed bars may enter a decision snapshot;
- the all-indicator MTF context uses M1=400 and M5/M15/M30/H1=320 closed bars;
- Top-10 warmup can require >=250 closed bars per timeframe;
- confirmed-swing Fibonacci uses only swings confirmed before the decision bar;
- opening ranges require the complete requested window and use the project's deterministic London/New-York DST contract;
- unavailable families retain a stable schema with ready=0 and neutral numeric values;
- sampled BID/ASK quality fields remain gates, not disguised predictors.

## Evaluation contract

The all-at-once stack must be compared with the frozen/current baseline on identical chronological origins and labels. Required evaluation sequence:

1. ALL vs baseline under chronological OOS / walk-forward separation.
2. Leave-one-role/family-out ablations (`ALL - group`) to identify redundant, harmful or regime-specific evidence.
3. Keep the final holdout untouched until the experiment design is frozen.
4. Use purge/embargo at least as large as the maximum overlapping outcome horizon.
5. Report coverage/WAIT separately from active BUY/SELL accuracy.
6. Final economic evaluation must use executable BID/ASK and explicit slippage/commission through `economic_labels.py`; spread must not be double-counted.
7. Report results by horizon, year/regime/session and after costs; no single aggregate accuracy is sufficient.
8. No profitability claim, model promotion or REAL trading authorization follows merely from feature availability or unit-test success.

## Regression evidence

Source stack received DeepSeek `PASS_RESEARCH_MERGE` on source-equivalent exact head `6c272b46ef0372b52bb39b2d5921681e5e0a3400`. Additional regression-only delta added exact long-lookback, degenerate-Fibonacci, DST-transition opening-range and default/DEMO isolation tests. Railway on code/test head `470dd37d39a51b3bc8ea88a04b8d4d953b1e5f6f` completed **175 passed, 0 failed**. The following status-only documentation commit does not alter executable code.
