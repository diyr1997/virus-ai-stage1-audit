from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping


class Action(str, Enum):
    WAIT = "WAIT"
    OPEN_BUY = "OPEN_BUY"
    OPEN_SELL = "OPEN_SELL"
    HOLD = "HOLD"
    ADD = "ADD"
    MOVE_SL = "MOVE_SL"
    CLOSE = "CLOSE"
    REVERSE = "REVERSE"


@dataclass(frozen=True)
class AnalystContext:
    direction: str = "NEUTRAL"
    impact: float = 0.0
    confidence: float = 0.0
    freshness_seconds: float | None = None
    reasons: tuple[str, ...] = ()

    def normalized(self) -> "AnalystContext":
        direction = str(self.direction or "NEUTRAL").upper()
        if direction not in {"BUY", "SELL", "NEUTRAL", "UNKNOWN"}:
            direction = "UNKNOWN"
        return AnalystContext(
            direction=direction,
            impact=max(0.0, min(100.0, float(self.impact or 0.0))),
            confidence=max(0.0, min(1.0, float(self.confidence or 0.0))),
            freshness_seconds=(None if self.freshness_seconds is None else max(0.0, float(self.freshness_seconds))),
            reasons=tuple(str(x) for x in self.reasons if str(x).strip()),
        )


@dataclass(frozen=True)
class MarketSnapshot:
    symbol: str
    timestamp_ms: int
    bid: float
    ask: float
    spread: float
    timeframes: Mapping[str, Mapping[str, float]] = field(default_factory=dict)
    features: Mapping[str, float] = field(default_factory=dict)
    position_side: str | None = None
    position_pnl: float | None = None

    def validate(self) -> None:
        if not str(self.symbol).strip():
            raise ValueError("symbol is required")
        if int(self.timestamp_ms) <= 0:
            raise ValueError("timestamp_ms must be positive")
        if float(self.bid) <= 0 or float(self.ask) <= 0:
            raise ValueError("bid/ask must be positive")
        if float(self.ask) < float(self.bid):
            raise ValueError("ask cannot be below bid")
        if float(self.spread) < 0:
            raise ValueError("spread cannot be negative")


@dataclass(frozen=True)
class TraderDecision:
    action: Action
    confidence: float
    direction_score: float
    edge_score: float
    reason_codes: tuple[str, ...]
    metadata: Mapping[str, Any] = field(default_factory=dict)
    execution_allowed: bool = False

    def __post_init__(self) -> None:
        object.__setattr__(self, "confidence", max(0.0, min(1.0, float(self.confidence))))
        object.__setattr__(self, "direction_score", max(-1.0, min(1.0, float(self.direction_score))))
        object.__setattr__(self, "edge_score", max(0.0, min(1.0, float(self.edge_score))))
        if self.execution_allowed:
            raise ValueError("TradingAIShadowTrader decisions must never allow execution")


class TradingAIShadowTrader:
    """First safe runtime shell for the future AI Trader.

    This class intentionally does not contain a trained model yet. It provides the
    stable contracts that future sequence models will plug into. Until a validated
    model is attached, it returns WAIT and records enough structured metadata for
    offline comparison against the legacy bot.
    """

    VERSION = "trading-ai-shadow-core-v1-2026-08-26"

    def __init__(self, *, max_spread: float | None = None) -> None:
        self.max_spread = None if max_spread is None else max(0.0, float(max_spread))

    def decide(
        self,
        market: MarketSnapshot,
        analyst: AnalystContext | None = None,
    ) -> TraderDecision:
        market.validate()
        analyst_n = (analyst or AnalystContext()).normalized()

        reasons: list[str] = ["MODEL_NOT_YET_ATTACHED"]
        if self.max_spread is not None and market.spread > self.max_spread:
            reasons.append("SPREAD_ABOVE_SHADOW_LIMIT")

        # Analyst information is deliberately preserved as an independent input;
        # it must not be converted into a direct BUY/SELL rule.
        metadata = {
            "version": self.VERSION,
            "symbol": market.symbol,
            "timestamp_ms": int(market.timestamp_ms),
            "bid": float(market.bid),
            "ask": float(market.ask),
            "spread": float(market.spread),
            "timeframes_present": sorted(str(k).upper() for k in market.timeframes.keys()),
            "analyst_direction": analyst_n.direction,
            "analyst_impact": analyst_n.impact,
            "analyst_confidence": analyst_n.confidence,
            "position_side": market.position_side,
            "position_pnl": market.position_pnl,
            "mode": "SHADOW_ONLY",
        }

        return TraderDecision(
            action=Action.WAIT,
            confidence=0.0,
            direction_score=0.0,
            edge_score=0.0,
            reason_codes=tuple(reasons),
            metadata=metadata,
            execution_allowed=False,
        )
