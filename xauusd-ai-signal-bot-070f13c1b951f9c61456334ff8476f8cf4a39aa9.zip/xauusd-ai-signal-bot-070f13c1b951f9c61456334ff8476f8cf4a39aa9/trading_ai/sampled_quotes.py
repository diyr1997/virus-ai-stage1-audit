from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from math import isfinite
from numbers import Real
from statistics import pstdev
from typing import Sequence


class SampledQuoteStatus(str, Enum):
    READY = "READY"
    NOT_READY = "NOT_READY"


@dataclass(frozen=True)
class SampledQuote:
    """One persisted MT5 BID/ASK sample.

    ``received_at_ms`` is the causal availability clock. ``broker_time_ms`` is
    retained only for diagnostics and must never override server receipt time.
    """

    received_at_ms: int
    bid: float
    ask: float
    broker_time_ms: int | None = None


@dataclass(frozen=True)
class SampledQuoteConfig:
    """Initial research values, not claims of optimality.

    The current bridge persists roughly one quote every five seconds. These
    defaults are therefore provisional quality gates for a 60-second research
    window and must be re-validated if the persistence throttle changes.
    """

    window_ms: int = 60_000
    min_samples: int = 8
    max_latest_age_ms: int = 15_000
    max_gap_ms: int = 20_000
    expected_interval_ms: int = 5_000

    def validate(self) -> "SampledQuoteConfig":
        for name in (
            "window_ms",
            "min_samples",
            "max_latest_age_ms",
            "max_gap_ms",
            "expected_interval_ms",
        ):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
                raise ValueError(f"{name} must be a positive integer")
        if self.min_samples < 2:
            raise ValueError("min_samples must be at least 2")
        if self.expected_interval_ms > self.window_ms:
            raise ValueError("expected_interval_ms cannot exceed window_ms")
        return self


DEFAULT_SAMPLED_QUOTE_CONFIG = SampledQuoteConfig()


@dataclass(frozen=True)
class SampledQuoteResult:
    """Quote-quality result plus research metrics.

    Quote readiness and ATR readiness are deliberately separate. A missing ATR
    does not invalidate spread/mid metrics that do not depend on ATR.
    Predictor fields are ``None`` when quote data itself is not ready so a real
    zero cannot be confused with an unavailable observation.
    """

    status: SampledQuoteStatus
    reason: str
    samples_used: int
    coverage_ratio: float
    latest_age_ms: float
    max_gap_ms: float
    duplicate_received_at: bool
    atr_ready: bool
    spread_bps: float | None
    spread_atr_ratio: float | None
    spread_change_bps: float | None
    spread_change_dispersion_bps: float | None
    mid_return_bps: float | None
    mid_velocity_bps_per_sec: float | None
    mid_return_dispersion_bps: float | None
    mid_change_fraction: float | None
    quote_direction_sync: float | None


@dataclass(frozen=True)
class SampledQuoteFeatureBlock:
    """Explicit research envelope, not a flat model vector.

    ``predictors`` is empty whenever quote data is NOT_READY. Quality fields are
    kept in a separate dictionary so they cannot accidentally enter a model by
    unpacking a single flat feature dictionary. The ATR-dependent predictor is
    present only when ``atr_ready`` is true.
    """

    quote_ready: bool
    atr_ready: bool
    reason: str
    predictors: dict[str, float]
    quality: dict[str, float]


def _finite_nonnegative(value: float) -> float:
    return float(value) if isfinite(float(value)) and float(value) >= 0.0 else 0.0


def _not_ready(
    reason: str,
    *,
    samples_used: int = 0,
    coverage_ratio: float = 0.0,
    latest_age_ms: float = 0.0,
    max_gap_ms: float = 0.0,
    duplicate_received_at: bool = False,
) -> SampledQuoteResult:
    return SampledQuoteResult(
        status=SampledQuoteStatus.NOT_READY,
        reason=reason,
        samples_used=int(samples_used),
        coverage_ratio=min(max(_finite_nonnegative(coverage_ratio), 0.0), 1.0),
        latest_age_ms=_finite_nonnegative(latest_age_ms),
        max_gap_ms=_finite_nonnegative(max_gap_ms),
        duplicate_received_at=bool(duplicate_received_at),
        atr_ready=False,
        spread_bps=None,
        spread_atr_ratio=None,
        spread_change_bps=None,
        spread_change_dispersion_bps=None,
        mid_return_bps=None,
        mid_velocity_bps_per_sec=None,
        mid_return_dispersion_bps=None,
        mid_change_fraction=None,
        quote_direction_sync=None,
    )


def _valid_timestamp(value: object) -> bool:
    return not isinstance(value, bool) and isinstance(value, int) and value >= 0


def _valid_price(value: object) -> bool:
    return (
        not isinstance(value, bool)
        and isinstance(value, Real)
        and isfinite(float(value))
        and float(value) > 0.0
    )


def _usable_atr(value: object) -> float | None:
    if value is None or isinstance(value, bool) or not isinstance(value, Real):
        return None
    atr = float(value)
    if not isfinite(atr) or atr <= 0.0:
        return None
    return atr


def _sign(value: float) -> float:
    if value > 0.0:
        return 1.0
    if value < 0.0:
        return -1.0
    return 0.0


def sampled_quote_result(
    quotes: Sequence[SampledQuote],
    *,
    decision_available_at_ms: int,
    atr_value: float | None,
    config: SampledQuoteConfig = DEFAULT_SAMPLED_QUOTE_CONFIG,
) -> SampledQuoteResult:
    """Compute causal metrics from persisted sampled BID/ASK quotes.

    Contract:
    - use only ``received_at_ms <= decision_available_at_ms``;
    - use the inclusive trailing window ``[T-window, T]``;
    - ``broker_time_ms`` never controls availability;
    - duplicate receipt timestamps fail closed instead of being silently merged;
    - no forward fill, nearest-future lookup, aggressor inference, OFI/CVD, or L2
      semantics are present;
    - ATR availability affects only the ATR-normalized spread field.
    """

    cfg = config.validate()
    if not _valid_timestamp(decision_available_at_ms):
        raise TypeError("decision_available_at_ms must be a non-negative integer")

    lower_bound = decision_available_at_ms - cfg.window_ms
    usable: list[SampledQuote] = []

    for quote in quotes:
        if not isinstance(quote, SampledQuote):
            return _not_ready("invalid_quote_type")
        if not _valid_timestamp(quote.received_at_ms):
            return _not_ready("invalid_received_at")
        if quote.received_at_ms > decision_available_at_ms:
            continue
        if quote.received_at_ms < lower_bound:
            continue
        usable.append(quote)

    usable.sort(key=lambda row: row.received_at_ms)
    if len(usable) < cfg.min_samples:
        return _not_ready("insufficient_samples", samples_used=len(usable))

    timestamps = [row.received_at_ms for row in usable]
    duplicate = any(b == a for a, b in zip(timestamps, timestamps[1:]))
    if duplicate:
        return _not_ready(
            "duplicate_received_at",
            samples_used=len(usable),
            duplicate_received_at=True,
        )

    for row in usable:
        if not _valid_price(row.bid) or not _valid_price(row.ask):
            return _not_ready("invalid_quote_price", samples_used=len(usable))
        if float(row.ask) < float(row.bid):
            return _not_ready("crossed_quote", samples_used=len(usable))

    gaps = [b - a for a, b in zip(timestamps, timestamps[1:])]
    max_gap = float(max(gaps)) if gaps else 0.0
    latest_age = float(decision_available_at_ms - timestamps[-1])
    temporal_coverage = min(
        1.0,
        max(
            0.0,
            (timestamps[-1] - timestamps[0] + cfg.expected_interval_ms) / cfg.window_ms,
        ),
    )

    if latest_age > cfg.max_latest_age_ms:
        return _not_ready(
            "stale_latest_quote",
            samples_used=len(usable),
            coverage_ratio=temporal_coverage,
            latest_age_ms=latest_age,
            max_gap_ms=max_gap,
        )
    if max_gap > cfg.max_gap_ms:
        return _not_ready(
            "excessive_gap",
            samples_used=len(usable),
            coverage_ratio=temporal_coverage,
            latest_age_ms=latest_age,
            max_gap_ms=max_gap,
        )

    mids = [(float(row.bid) + float(row.ask)) / 2.0 for row in usable]
    spreads = [float(row.ask) - float(row.bid) for row in usable]
    if any(mid <= 0.0 or not isfinite(mid) for mid in mids):
        return _not_ready("invalid_mid", samples_used=len(usable))

    spread_bps_series = [spread / mid * 10_000.0 for spread, mid in zip(spreads, mids)]
    spread_changes = [b - a for a, b in zip(spread_bps_series, spread_bps_series[1:])]
    mid_returns = [(b / a - 1.0) * 10_000.0 for a, b in zip(mids, mids[1:])]

    elapsed_seconds = (timestamps[-1] - timestamps[0]) / 1000.0
    if elapsed_seconds <= 0.0:
        return _not_ready(
            "nonpositive_elapsed_time",
            samples_used=len(usable),
            coverage_ratio=temporal_coverage,
            latest_age_ms=latest_age,
            max_gap_ms=max_gap,
        )

    changed = sum(1 for a, b in zip(mids, mids[1:]) if b != a)
    transition_count = len(mids) - 1
    direction_scores = [
        (_sign(float(curr.bid) - float(prev.bid)) + _sign(float(curr.ask) - float(prev.ask))) / 2.0
        for prev, curr in zip(usable, usable[1:])
    ]

    atr = _usable_atr(atr_value)
    spread_atr_ratio = spreads[-1] / atr if atr is not None else None
    result = SampledQuoteResult(
        status=SampledQuoteStatus.READY,
        reason="",
        samples_used=len(usable),
        coverage_ratio=temporal_coverage,
        latest_age_ms=latest_age,
        max_gap_ms=max_gap,
        duplicate_received_at=False,
        atr_ready=atr is not None,
        spread_bps=spread_bps_series[-1],
        spread_atr_ratio=spread_atr_ratio,
        spread_change_bps=spread_bps_series[-1] - spread_bps_series[0],
        spread_change_dispersion_bps=pstdev(spread_changes) if len(spread_changes) > 1 else 0.0,
        mid_return_bps=(mids[-1] / mids[0] - 1.0) * 10_000.0,
        mid_velocity_bps_per_sec=((mids[-1] / mids[0] - 1.0) * 10_000.0) / elapsed_seconds,
        mid_return_dispersion_bps=pstdev(mid_returns) if len(mid_returns) > 1 else 0.0,
        mid_change_fraction=changed / transition_count if transition_count else 0.0,
        quote_direction_sync=(sum(direction_scores) / len(direction_scores)) if direction_scores else 0.0,
    )

    required_numeric = (
        result.coverage_ratio,
        result.latest_age_ms,
        result.max_gap_ms,
        result.spread_bps,
        result.spread_change_bps,
        result.spread_change_dispersion_bps,
        result.mid_return_bps,
        result.mid_velocity_bps_per_sec,
        result.mid_return_dispersion_bps,
        result.mid_change_fraction,
        result.quote_direction_sync,
    )
    if any(value is None or not isfinite(float(value)) for value in required_numeric):
        return _not_ready(
            "nonfinite_feature",
            samples_used=len(usable),
            coverage_ratio=temporal_coverage,
            latest_age_ms=latest_age,
            max_gap_ms=max_gap,
        )
    if result.spread_atr_ratio is not None and not isfinite(float(result.spread_atr_ratio)):
        return _not_ready(
            "nonfinite_atr_feature",
            samples_used=len(usable),
            coverage_ratio=temporal_coverage,
            latest_age_ms=latest_age,
            max_gap_ms=max_gap,
        )
    return result


def sampled_quote_feature_block(
    quotes: Sequence[SampledQuote],
    *,
    prefix: str,
    decision_available_at_ms: int,
    atr_value: float | None,
    config: SampledQuoteConfig = DEFAULT_SAMPLED_QUOTE_CONFIG,
) -> SampledQuoteFeatureBlock:
    """Return an explicit predictor/quality envelope for research ablation.

    This deliberately does not return one flat dictionary. Quote-quality fields
    remain outside ``predictors``. When quote data is NOT_READY, ``predictors`` is
    empty rather than filled with ambiguous zeros. If quote data is ready but ATR
    is unavailable, all non-ATR predictors remain present and the ATR-dependent
    field is omitted while ``atr_ready`` is false.
    """

    result = sampled_quote_result(
        quotes,
        decision_available_at_ms=decision_available_at_ms,
        atr_value=atr_value,
        config=config,
    )
    quote_ready = result.status is SampledQuoteStatus.READY

    quality = {
        f"{prefix}_sampled_quote_ready": float(quote_ready),
        f"{prefix}_sampled_atr_ready": float(result.atr_ready),
        f"{prefix}_sampled_quote_coverage_ratio": result.coverage_ratio,
        f"{prefix}_sampled_latest_age_ms": result.latest_age_ms,
        f"{prefix}_sampled_max_gap_ms": result.max_gap_ms,
        f"{prefix}_sampled_duplicate_received_at": float(result.duplicate_received_at),
        f"{prefix}_sampled_samples_used": float(result.samples_used),
    }

    predictors: dict[str, float] = {}
    if quote_ready:
        assert result.spread_bps is not None
        assert result.spread_change_bps is not None
        assert result.spread_change_dispersion_bps is not None
        assert result.mid_return_bps is not None
        assert result.mid_velocity_bps_per_sec is not None
        assert result.mid_return_dispersion_bps is not None
        assert result.mid_change_fraction is not None
        assert result.quote_direction_sync is not None
        predictors = {
            f"{prefix}_sampled_spread_bps": result.spread_bps,
            f"{prefix}_sampled_spread_change_bps": result.spread_change_bps,
            f"{prefix}_sampled_spread_change_dispersion_bps": result.spread_change_dispersion_bps,
            f"{prefix}_sampled_mid_return_bps": result.mid_return_bps,
            f"{prefix}_sampled_mid_velocity_bps_per_sec": result.mid_velocity_bps_per_sec,
            f"{prefix}_sampled_mid_return_dispersion_bps": result.mid_return_dispersion_bps,
            f"{prefix}_sampled_mid_change_fraction": result.mid_change_fraction,
            f"{prefix}_sampled_quote_direction_sync": result.quote_direction_sync,
        }
        if result.atr_ready:
            assert result.spread_atr_ratio is not None
            predictors[f"{prefix}_sampled_spread_atr_ratio"] = result.spread_atr_ratio

    return SampledQuoteFeatureBlock(
        quote_ready=quote_ready,
        atr_ready=result.atr_ready,
        reason=result.reason,
        predictors=predictors,
        quality=quality,
    )
