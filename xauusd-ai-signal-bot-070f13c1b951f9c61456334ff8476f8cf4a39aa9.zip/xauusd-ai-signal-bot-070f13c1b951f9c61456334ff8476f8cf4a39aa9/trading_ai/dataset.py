from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Sequence


@dataclass(frozen=True)
class Candle:
    timestamp_ms: int
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0


@dataclass(frozen=True)
class TrainingWindow:
    end_timestamp_ms: int
    candles: tuple[Candle, ...]
    future_returns: dict[int, float]
    max_favorable_move: dict[int, float]
    max_adverse_move: dict[int, float]


class LeakageError(ValueError):
    pass


def validate_candles(candles: Sequence[Candle]) -> None:
    previous = None
    for candle in candles:
        if candle.timestamp_ms <= 0:
            raise ValueError("candle timestamp must be positive")
        if candle.high < max(candle.open, candle.close) or candle.low > min(candle.open, candle.close):
            raise ValueError("invalid OHLC candle")
        if candle.high < candle.low:
            raise ValueError("high below low")
        if previous is not None and candle.timestamp_ms <= previous:
            raise ValueError("candles must be strictly increasing and deduplicated")
        previous = candle.timestamp_ms


def build_training_windows(
    candles: Sequence[Candle],
    *,
    lookback: int = 120,
    horizons: Iterable[int] = (1, 3, 5, 10, 15),
) -> list[TrainingWindow]:
    """Build strictly causal M1 windows.

    The feature window ends at index i and contains only candles <= i.
    Labels are calculated only from candles after i and are never included in the
    returned feature sequence. Horizon values are expressed in candles (M1 here).
    """
    candles = tuple(candles)
    validate_candles(candles)
    lookback = int(lookback)
    if lookback < 2:
        raise ValueError("lookback must be >= 2")

    hs = tuple(sorted({int(h) for h in horizons if int(h) > 0}))
    if not hs:
        raise ValueError("at least one positive horizon is required")
    max_h = max(hs)
    if len(candles) < lookback + max_h:
        return []

    result: list[TrainingWindow] = []
    first_end = lookback - 1
    last_end = len(candles) - max_h - 1

    for end_idx in range(first_end, last_end + 1):
        feature_slice = candles[end_idx - lookback + 1 : end_idx + 1]
        entry = feature_slice[-1].close
        if entry <= 0:
            continue

        future_returns: dict[int, float] = {}
        mfe: dict[int, float] = {}
        mae: dict[int, float] = {}

        for h in hs:
            future = candles[end_idx + 1 : end_idx + h + 1]
            if not future:
                raise LeakageError("future label slice unexpectedly empty")
            if any(c.timestamp_ms <= feature_slice[-1].timestamp_ms for c in future):
                raise LeakageError("future candle leaked into or before feature window")

            last = future[-1]
            future_returns[h] = (last.close - entry) / entry
            highest = max(c.high for c in future)
            lowest = min(c.low for c in future)
            mfe[h] = max(0.0, (highest - entry) / entry)
            mae[h] = min(0.0, (lowest - entry) / entry)

        result.append(
            TrainingWindow(
                end_timestamp_ms=feature_slice[-1].timestamp_ms,
                candles=tuple(feature_slice),
                future_returns=future_returns,
                max_favorable_move=mfe,
                max_adverse_move=mae,
            )
        )

    return result
