from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from math import isclose, isfinite
from numbers import Real


class EconomicLabel(str, Enum):
    SELL = "SELL"
    WAIT = "WAIT"
    BUY = "BUY"
    UNAVAILABLE = "UNAVAILABLE"


@dataclass(frozen=True)
class ExecutableQuote:
    """Executable top-of-book quote in price units.

    BUY crosses the ask. SELL crosses the bid. This object intentionally carries
    no midpoint-derived spread cost because crossing bid/ask already represents
    spread exactly once. Validation is performed at the economic boundary so an
    unusable external quote can be represented as UNAVAILABLE rather than WAIT.
    """

    bid: float
    ask: float


@dataclass(frozen=True)
class EconomicCostSpec:
    """Research-only round-trip cost contract.

    quantity is a fixed reference quantity for labels; runtime risk sizing must
    remain downstream and must not change the target class. Slippage values are
    adverse price units applied once per execution side. Commission is money per
    unit per side and therefore scales with quantity.

    Before broker integration, quantity/commission units must be mapped explicitly
    to the instrument contract (for example XAU ounces vs broker lots and account
    currency). This v1 contract deliberately does not guess that conversion.
    """

    quantity: float = 1.0
    entry_slippage_price: float = 0.0
    exit_slippage_price: float = 0.0
    commission_per_unit_per_side: float = 0.0
    min_net_utility: float = 0.0
    tie_epsilon: float = 0.0
    min_action_margin: float = 0.0


@dataclass(frozen=True)
class ActionUtilities:
    buy: float
    sell: float
    # Kept for backwards-compatible construction, but the decision contract
    # strictly requires WAIT utility == 0. A non-zero value is rejected below.
    wait: float = 0.0


@dataclass(frozen=True)
class EconomicDecision:
    label: EconomicLabel
    utilities: ActionUtilities | None
    reason: str


def _as_finite_real_scalar(name: str, value: object) -> float:
    """Strict scalar coercion: reject bool/containers, NaN and infinities."""

    if isinstance(value, bool) or not isinstance(value, Real):
        raise TypeError(f"{name} must be a real numeric scalar, not {type(value).__name__}")
    numeric = float(value)
    if not isfinite(numeric):
        raise ValueError(f"{name} must be finite")
    return numeric


def _at_or_below(value: float, boundary: float) -> bool:
    """Inclusive comparison that treats representation-only float noise as equal."""

    return value <= boundary or isclose(value, boundary, rel_tol=1e-12, abs_tol=1e-15)


def _valid_quote(quote: ExecutableQuote | None) -> bool:
    if quote is None:
        return False
    try:
        bid = _as_finite_real_scalar("bid", quote.bid)
        ask = _as_finite_real_scalar("ask", quote.ask)
    except (TypeError, ValueError):
        return False
    return bid > 0.0 and ask > 0.0 and ask >= bid


def _validate_costs(costs: EconomicCostSpec) -> None:
    values = {
        "quantity": costs.quantity,
        "entry_slippage_price": costs.entry_slippage_price,
        "exit_slippage_price": costs.exit_slippage_price,
        "commission_per_unit_per_side": costs.commission_per_unit_per_side,
        "min_net_utility": costs.min_net_utility,
        "tie_epsilon": costs.tie_epsilon,
        "min_action_margin": costs.min_action_margin,
    }
    numeric = {name: _as_finite_real_scalar(name, value) for name, value in values.items()}
    if numeric["quantity"] <= 0.0:
        raise ValueError("quantity must be positive")
    for name in (
        "entry_slippage_price",
        "exit_slippage_price",
        "commission_per_unit_per_side",
        "min_net_utility",
        "tie_epsilon",
        "min_action_margin",
    ):
        if numeric[name] < 0.0:
            raise ValueError(f"{name} must be non-negative")


def round_trip_utilities(
    entry: ExecutableQuote,
    exit_: ExecutableQuote,
    *,
    costs: EconomicCostSpec | None = None,
) -> ActionUtilities:
    """Return LONG/SHORT/WAIT utility from executable BID/ASK prices.

    LONG: buy ask (+ adverse entry slippage), later sell bid (- adverse exit
    slippage). SHORT: sell bid (- adverse entry slippage), later cover ask
    (+ adverse exit slippage). Spread is not subtracted separately because it is
    already represented by crossing the quoted sides.
    """

    if not _valid_quote(entry) or not _valid_quote(exit_):
        raise ValueError("entry and exit quotes must be finite real positive scalars and non-crossed")
    spec = costs or EconomicCostSpec()
    _validate_costs(spec)

    q = _as_finite_real_scalar("quantity", spec.quantity)
    entry_slip = _as_finite_real_scalar("entry_slippage_price", spec.entry_slippage_price)
    exit_slip = _as_finite_real_scalar("exit_slippage_price", spec.exit_slippage_price)
    commission_per_side = _as_finite_real_scalar(
        "commission_per_unit_per_side", spec.commission_per_unit_per_side
    )
    commission = 2.0 * commission_per_side * q

    long_entry = _as_finite_real_scalar("entry.ask", entry.ask) + entry_slip
    long_exit = _as_finite_real_scalar("exit.bid", exit_.bid) - exit_slip
    short_entry = _as_finite_real_scalar("entry.bid", entry.bid) - entry_slip
    short_exit = _as_finite_real_scalar("exit.ask", exit_.ask) + exit_slip

    buy = (long_exit - long_entry) * q - commission
    sell = (short_entry - short_exit) * q - commission
    return ActionUtilities(buy=buy, sell=sell, wait=0.0)


def choose_economic_label(
    utilities: ActionUtilities,
    *,
    min_net_utility: float = 0.0,
    tie_epsilon: float = 0.0,
    min_action_margin: float = 0.0,
) -> EconomicDecision:
    """Choose BUY/SELL/WAIT after comparing both actions with invariant WAIT=0.

    The best directional action must be strictly above min_net_utility. Near
    ties are WAIT. The chosen direction must beat the better alternative
    (opposite direction or WAIT) by strictly more than min_action_margin; exact
    threshold equality remains WAIT as the conservative boundary rule. Tiny
    representation-only floating error around a boundary is treated as equality.

    WAIT is not a caller-tunable utility. ``ActionUtilities.wait`` remains only
    for backwards-compatible construction and any non-zero value fails closed.
    Opportunity-cost style thresholds belong in ``min_action_margin``.
    """

    minimum = _as_finite_real_scalar("min_net_utility", min_net_utility)
    tie = _as_finite_real_scalar("tie_epsilon", tie_epsilon)
    margin = _as_finite_real_scalar("min_action_margin", min_action_margin)
    if minimum < 0.0 or tie < 0.0 or margin < 0.0:
        raise ValueError("decision thresholds must be non-negative")

    buy = _as_finite_real_scalar("utilities.buy", utilities.buy)
    sell = _as_finite_real_scalar("utilities.sell", utilities.sell)
    supplied_wait = _as_finite_real_scalar("utilities.wait", utilities.wait)
    if not isclose(supplied_wait, 0.0, rel_tol=0.0, abs_tol=1e-15):
        raise ValueError("WAIT utility is invariant and must equal 0")
    wait = 0.0

    best = max(buy, sell)
    if _at_or_below(best, minimum):
        return EconomicDecision(EconomicLabel.WAIT, utilities, "best_direction_not_above_min_net_utility")

    if _at_or_below(abs(buy - sell), tie):
        return EconomicDecision(EconomicLabel.WAIT, utilities, "directional_tie_within_epsilon")

    if buy > sell:
        alternative = max(sell, wait)
        if _at_or_below(buy - alternative, margin):
            return EconomicDecision(EconomicLabel.WAIT, utilities, "buy_margin_not_above_min_action_margin")
        return EconomicDecision(EconomicLabel.BUY, utilities, "buy_has_highest_admissible_net_utility")

    alternative = max(buy, wait)
    if _at_or_below(sell - alternative, margin):
        return EconomicDecision(EconomicLabel.WAIT, utilities, "sell_margin_not_above_min_action_margin")
    return EconomicDecision(EconomicLabel.SELL, utilities, "sell_has_highest_admissible_net_utility")


def label_from_executable_quotes(
    entry: ExecutableQuote | None,
    exit_: ExecutableQuote | None,
    *,
    costs: EconomicCostSpec | None = None,
) -> EconomicDecision:
    """Fail closed to UNAVAILABLE when the executable quote state is unusable."""

    if not _valid_quote(entry) or not _valid_quote(exit_):
        return EconomicDecision(EconomicLabel.UNAVAILABLE, None, "missing_invalid_or_crossed_quote")

    spec = costs or EconomicCostSpec()
    _validate_costs(spec)
    utilities = round_trip_utilities(entry, exit_, costs=spec)
    return choose_economic_label(
        utilities,
        min_net_utility=_as_finite_real_scalar("min_net_utility", spec.min_net_utility),
        tie_epsilon=_as_finite_real_scalar("tie_epsilon", spec.tie_epsilon),
        min_action_margin=_as_finite_real_scalar("min_action_margin", spec.min_action_margin),
    )
