from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import calendar
import math
from typing import Mapping


# Canonical XAU/USD regional activity windows, represented in UTC.
# Asia/Tokyo is fixed. London and New York shift with their local DST rules.
ASIA_START_MINUTE_UTC = 0
ASIA_END_MINUTE_UTC = 9 * 60

LONDON_GMT_START_MINUTE_UTC = 8 * 60
LONDON_GMT_END_MINUTE_UTC = 17 * 60
LONDON_BST_START_MINUTE_UTC = 7 * 60
LONDON_BST_END_MINUTE_UTC = 16 * 60

NEW_YORK_EST_START_MINUTE_UTC = 13 * 60
NEW_YORK_EST_END_MINUTE_UTC = 22 * 60
NEW_YORK_EDT_START_MINUTE_UTC = 12 * 60
NEW_YORK_EDT_END_MINUTE_UTC = 21 * 60


@dataclass(frozen=True)
class SessionContext:
    timestamp_ms: int
    active_sessions: tuple[str, ...]
    london_dst: bool
    new_york_dst: bool
    features: Mapping[str, float]


def _last_sunday(year: int, month: int) -> int:
    last_day = calendar.monthrange(year, month)[1]
    weekday = datetime(year, month, last_day, tzinfo=timezone.utc).weekday()
    return last_day - ((weekday + 1) % 7)


def _nth_sunday(year: int, month: int, n: int) -> int:
    if n <= 0:
        raise ValueError("n must be positive")
    first_weekday = datetime(year, month, 1, tzinfo=timezone.utc).weekday()
    first_sunday = 1 + ((6 - first_weekday) % 7)
    return first_sunday + 7 * (n - 1)


def _london_dst_active(dt_utc: datetime) -> bool:
    year = dt_utc.year
    start = datetime(year, 3, _last_sunday(year, 3), 1, tzinfo=timezone.utc)
    end = datetime(year, 10, _last_sunday(year, 10), 1, tzinfo=timezone.utc)
    return start <= dt_utc < end


def _new_york_dst_active(dt_utc: datetime) -> bool:
    year = dt_utc.year
    if year >= 2007:
        start_month = 3
        start_day = _nth_sunday(year, 3, 2)
        end_month = 11
        end_day = _nth_sunday(year, 11, 1)
    else:
        # Historical US rule used by the project data at 2003-2006.
        start_month = 4
        start_day = _nth_sunday(year, 4, 1)
        end_month = 10
        end_day = _last_sunday(year, 10)
    # US DST switches at 02:00 local:
    # start = 07:00 UTC while still EST; end = 06:00 UTC while still EDT.
    start = datetime(year, start_month, start_day, 7, tzinfo=timezone.utc)
    end = datetime(year, end_month, end_day, 6, tzinfo=timezone.utc)
    return start <= dt_utc < end


def _active(minute_of_day: int, start: int, end: int) -> bool:
    return start <= minute_of_day < end


def _progress(minute_of_day: int, start: int, end: int) -> float:
    if not _active(minute_of_day, start, end):
        return 0.0
    return (minute_of_day - start) / max(end - start, 1)


def session_context(timestamp_ms: int) -> SessionContext:
    """Return strictly timestamp-derived, causal trading-session context.

    No market future is used. DST is calculated deterministically from the UTC
    timestamp, avoiding dependence on the host's timezone database. These
    features let research models learn that the same price structure can behave
    differently during Asia, London, New York, and London/New-York overlap.
    """
    ts = int(timestamp_ms)
    if ts <= 0:
        raise ValueError("timestamp_ms must be positive")

    dt_utc = datetime.fromtimestamp(ts / 1000.0, tz=timezone.utc)
    minute = dt_utc.hour * 60 + dt_utc.minute

    london_dst = _london_dst_active(dt_utc)
    new_york_dst = _new_york_dst_active(dt_utc)
    london_start = LONDON_BST_START_MINUTE_UTC if london_dst else LONDON_GMT_START_MINUTE_UTC
    london_end = LONDON_BST_END_MINUTE_UTC if london_dst else LONDON_GMT_END_MINUTE_UTC
    ny_start = NEW_YORK_EDT_START_MINUTE_UTC if new_york_dst else NEW_YORK_EST_START_MINUTE_UTC
    ny_end = NEW_YORK_EDT_END_MINUTE_UTC if new_york_dst else NEW_YORK_EST_END_MINUTE_UTC

    asia = _active(minute, ASIA_START_MINUTE_UTC, ASIA_END_MINUTE_UTC)
    london = _active(minute, london_start, london_end)
    new_york = _active(minute, ny_start, ny_end)
    active_sessions = tuple(
        name
        for name, enabled in (("ASIA", asia), ("LONDON", london), ("NEW_YORK", new_york))
        if enabled
    )
    active_count = int(asia) + int(london) + int(new_york)

    hour_fraction = (minute + dt_utc.second / 60.0) / (24.0 * 60.0)
    weekday_fraction = dt_utc.weekday() / 7.0

    features = {
        "session_asia": float(asia),
        "session_london": float(london),
        "session_new_york": float(new_york),
        "session_asia_london_overlap": float(asia and london),
        "session_london_new_york_overlap": float(london and new_york),
        "session_active_count": float(active_count),
        "session_off_hours": float(active_count == 0),
        "session_asia_progress": _progress(minute, ASIA_START_MINUTE_UTC, ASIA_END_MINUTE_UTC),
        "session_london_progress": _progress(minute, london_start, london_end),
        "session_new_york_progress": _progress(minute, ny_start, ny_end),
        "session_london_dst": float(london_dst),
        "session_new_york_dst": float(new_york_dst),
        "session_utc_hour_sin": math.sin(2.0 * math.pi * hour_fraction),
        "session_utc_hour_cos": math.cos(2.0 * math.pi * hour_fraction),
        "session_weekday_sin": math.sin(2.0 * math.pi * weekday_fraction),
        "session_weekday_cos": math.cos(2.0 * math.pi * weekday_fraction),
    }
    return SessionContext(
        timestamp_ms=ts,
        active_sessions=active_sessions,
        london_dst=london_dst,
        new_york_dst=new_york_dst,
        features=features,
    )


def session_features(timestamp_ms: int) -> dict[str, float]:
    return dict(session_context(timestamp_ms).features)
