from __future__ import annotations

import math

from trading_ai.classic_indicators import classic_indicator_feature_block
from trading_ai.dataset import Candle


def candles(n: int, *, start: float = 2000.0):
    out = []
    price = start
    for i in range(n):
        drift = 0.8 + (0.15 if i % 5 == 0 else -0.05 if i % 7 == 0 else 0.0)
        open_ = price
        close = price + drift
        high = max(open_, close) + 0.4
        low = min(open_, close) - 0.35
        out.append(Candle(timestamp_ms=(i + 1) * 60_000, open=open_, high=high, low=low, close=close, volume=100 + i))
        price = close
    return out


def test_full_block_ready_and_finite_after_warmup():
    values = classic_indicator_feature_block(candles(120), prefix="m1", atr_value=2.0)
    assert values["m1_ema9_ready"] == 1.0
    assert values["m1_ema21_ready"] == 1.0
    assert values["m1_ema50_ready"] == 1.0
    assert values["m1_rsi14_ready"] == 1.0
    assert values["m1_macd_ready"] == 1.0
    assert values["m1_bb20_ready"] == 1.0
    assert values["m1_donchian20_ready"] == 1.0
    assert values["m1_donchian55_ready"] == 1.0
    assert values["m1_fib55_ready"] == 1.0
    assert all(math.isfinite(float(value)) for value in values.values())


def test_short_history_fails_closed_without_nans():
    values = classic_indicator_feature_block(candles(10), prefix="m1", atr_value=None)
    assert values["m1_ema50_ready"] == 0.0
    assert values["m1_rsi14_ready"] == 0.0
    assert values["m1_macd_ready"] == 0.0
    assert values["m1_bb20_ready"] == 0.0
    assert values["m1_donchian55_ready"] == 0.0
    assert values["m1_fib55_ready"] == 0.0
    assert all(math.isfinite(float(value)) for value in values.values())


def test_atr_dependent_features_fail_closed_when_atr_missing():
    values = classic_indicator_feature_block(candles(120), prefix="m1", atr_value=0.0)
    assert values["m1_rsi14_ready"] == 1.0
    assert values["m1_bb20_ready"] == 1.0
    assert values["m1_ema9_ready"] == 0.0
    assert values["m1_macd_ready"] == 0.0
    assert values["m1_donchian20_ready"] == 0.0
    assert values["m1_fib55_ready"] == 0.0


def test_causal_prefix_is_unchanged_by_future_bar():
    base = candles(120)
    before = classic_indicator_feature_block(base, prefix="m1", atr_value=2.0)
    future = Candle(timestamp_ms=121 * 60_000, open=5000.0, high=5200.0, low=4900.0, close=5100.0, volume=9999)
    after_full = classic_indicator_feature_block(base + [future], prefix="m1", atr_value=2.0)
    after_prefix = classic_indicator_feature_block((base + [future])[:-1], prefix="m1", atr_value=2.0)
    assert before == after_prefix
    assert before != after_full


def test_fibonacci_is_neutral_location_not_direction_rule():
    values = classic_indicator_feature_block(candles(120), prefix="m1", atr_value=2.0)
    assert "m1_fib55_0_5_dist_atr" in values
    assert "m1_fib55_0_618_dist_atr" in values
    assert "m1_fib55_0_786_dist_atr" in values
    assert not any("buy" in key.lower() or "sell" in key.lower() for key in values)
