from __future__ import annotations

import json
import os
from dataclasses import asdict
from datetime import datetime, timezone
from typing import Sequence

from .baseline import evaluate, evaluate_classification, fit_linear_baseline
from .labels import label_direction
from .pipeline import DEFAULT_HORIZONS, TrainingSample, build_training_samples
from .postgres_source import history_summary, load_m1_candles


def _parse_utc(value: str | None) -> datetime | None:
    text = (value or "").strip()
    if not text:
        return None
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    dt = datetime.fromisoformat(text)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _optional_positive_int(value: str | None) -> int | None:
    text = (value or "").strip()
    if not text:
        return None
    parsed = int(text)
    if parsed <= 0:
        raise ValueError("optional row limit must be positive when provided")
    return parsed


def _fold_boundaries(n: int, *, folds: int, initial_train_fraction: float) -> list[tuple[int, int]]:
    if n < 100:
        return []
    folds = max(1, int(folds))
    initial = max(1, min(n - 1, int(n * float(initial_train_fraction))))
    remaining = n - initial
    if remaining <= 0:
        return []
    step = max(1, remaining // folds)
    out: list[tuple[int, int]] = []
    start = initial
    while start < n and len(out) < folds:
        stop = n if len(out) == folds - 1 else min(n, start + step)
        if stop > start:
            out.append((start, stop))
        start = stop
    return out


def run_walk_forward(
    samples: Sequence[TrainingSample],
    *,
    horizons: Sequence[int] = DEFAULT_HORIZONS,
    folds: int = 5,
    initial_train_fraction: float = 0.60,
    volatility_multiplier: float = 0.60,
    minimum_return: float = 0.00002,
) -> dict[str, object]:
    """Expanding-window baseline evaluation with a purge gap before every test fold."""
    samples = list(samples)
    if not samples:
        return {"samples": 0, "folds": []}

    hs = tuple(sorted({int(h) for h in horizons if int(h) > 0}))
    max_h = max(hs)
    labeled = label_direction(
        samples,
        horizons=hs,
        volatility_multiplier=volatility_multiplier,
        minimum_return=minimum_return,
    )

    fold_results: list[dict[str, object]] = []
    for fold_no, (eval_start, eval_stop) in enumerate(
        _fold_boundaries(len(samples), folds=folds, initial_train_fraction=initial_train_fraction),
        start=1,
    ):
        train_stop = max(0, eval_start - max_h)
        train = samples[:train_stop]
        evaluation = samples[eval_start:eval_stop]
        labeled_evaluation = labeled[eval_start:eval_stop]
        if not train or not evaluation:
            continue

        horizons_result: dict[str, object] = {}
        for horizon in hs:
            model = fit_linear_baseline(train, horizon=horizon)
            regression = evaluate(model, evaluation)
            classification = evaluate_classification(model, labeled_evaluation)
            horizons_result[str(horizon)] = {
                "regression": asdict(regression),
                "classification": asdict(classification),
            }

        fold_results.append(
            {
                "fold": fold_no,
                "train_samples": len(train),
                "purge_bars": max_h,
                "evaluation_samples": len(evaluation),
                "train_last_timestamp_ms": train[-1].end_timestamp_ms,
                "evaluation_first_timestamp_ms": evaluation[0].end_timestamp_ms,
                "evaluation_last_timestamp_ms": evaluation[-1].end_timestamp_ms,
                "horizons": horizons_result,
            }
        )

    return {"samples": len(samples), "max_horizon": max_h, "folds": fold_results}


def main() -> None:
    start = _parse_utc(os.getenv("TRADING_AI_START_UTC"))
    end = _parse_utc(os.getenv("TRADING_AI_END_UTC"))
    max_rows = _optional_positive_int(os.getenv("TRADING_AI_MAX_M1_ROWS"))
    folds = int(os.getenv("TRADING_AI_WALK_FORWARD_FOLDS", "5"))
    initial_fraction = float(os.getenv("TRADING_AI_INITIAL_TRAIN_FRACTION", "0.60"))

    # Full available M1 history is the default. TRADING_AI_MAX_M1_ROWS is only an
    # explicit research/debug override and is never silently imposed.
    candles = load_m1_candles(start=start, end=end, limit=max_rows)
    samples = build_training_samples(candles)
    report = {
        "mode": "RESEARCH_ONLY_NO_ORDERS",
        "history": history_summary(candles),
        "config": {
            "start_utc": start.isoformat() if start else None,
            "end_utc": end.isoformat() if end else None,
            "max_m1_rows": max_rows,
            "full_history_default": max_rows is None,
            "folds": folds,
            "initial_train_fraction": initial_fraction,
            "horizons_minutes": list(DEFAULT_HORIZONS),
        },
        "walk_forward": run_walk_forward(
            samples,
            horizons=DEFAULT_HORIZONS,
            folds=folds,
            initial_train_fraction=initial_fraction,
        ),
    }
    print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
