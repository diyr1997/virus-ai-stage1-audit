# Worker loop latency diagnostics plan

Research/diagnostic plan only. This does not authorize REAL trading and does not change DEMO entry/exit/risk logic.

Empirical sampled-quote evidence shows persisted `received_at` gaps and broker-time gaps tracking each other at roughly 20–40 seconds while median saved-tick age is low. That rules against a simple PostgreSQL row-loss explanation, but it does not identify which synchronous worker stage dominates the loop.

DeepSeek root-cause review final recommendation: `INSTRUMENT_FIRST`, blocker `NONE`. Closure line: `DEEPSEEK WORKER QUOTE CADENCE ROOTCAUSE REVIEW COMPLETE`.

DeepSeek PR #193 V1 code review returned `PASS_WITH_REQUIRED_CHANGES`. The branch was tightened accordingly before any merge: timing is environment-gated, slow logs are rate-limited per stage, normal class-method binding is explicitly tested, watchdog-install order is tested, order APIs are asserted untouched, exception-origin frames are tested, reconnect-cycle timing is tested, and nested timing is documented as non-additive.

## Implemented diagnostic envelope

`demo_mt5_worker/worker_stage_timing.py` is installed only after existing stale-feed watchdog guards. It uses in-memory rolling samples plus structured stdout. It creates no timing table, opens no extra timing DB connection, adds no thread/process, and calls no order API.

Enable only for the diagnostic run with `WORKER_TIMING_ENABLED=1`. Default is OFF. Disable again with `WORKER_TIMING_ENABLED=0` without changing code.

Instrumented boundaries:

1. `ensure_mt5_connection` plus start-to-start loop cycle timing
2. `get_tick`
3. quote write when due
4. closed-M1 sync when due
5. market-state classification
6. `save_worker_state.<key>` persistence, including heartbeat/market-state diagnostics
7. worker `db_connect`
8. trader `connect`
9. `trader.step`
10. `sync_closed_trades`
11. quote cleanup when due

Start-to-start cycle time includes normal sleep and reconnect/error delays; it is a cadence metric, not pure work time. Nested measurements are intentional: for example `trader_step` can contain multiple `trader_db_connect` timings and `candle_sync` can contain DB/state-write timings. Nested durations must not be summed as disjoint costs; they reveal which child operation dominates a slow outer stage.

## Logging bounds

Slow-stage logging is rate-limited independently per stage (`WORKER_TIMING_SLOW_LOG_INTERVAL_SECONDS`, default 30s) and reports suppressed counts. Aggregate p50/p95/max summaries are emitted at a bounded interval. This avoids turning every slow DB call into additional stdout pressure while preserving diagnostic visibility.

## Safety contract

- Preserve exact stage order and existing guards.
- Do not change candidate selection, confirmation, risk, order send, SL/TP, fencing, reconciliation, or DEMO-only checks.
- Do not wrap or call MT5 order APIs.
- Do not treat timing data as a predictive trading feature.
- No default thread or second MT5 process is introduced.
- Any future pooling or separate sampler requires its own review/tests after stage-level Windows evidence exists.
- Original exceptions propagate; timing records in `finally` only.

## Evidence gate

A Windows DEMO run must produce stage-level p50/p95/max and slow-loop records before choosing connection reuse/pooling, reduced redundant DB work, or a separately isolated sampler experiment. Merely changing `QUOTE_WRITE_SECONDS`, `CANDLE_SYNC_SECONDS`, or sampled-feature thresholds is not an accepted root-cause fix.
