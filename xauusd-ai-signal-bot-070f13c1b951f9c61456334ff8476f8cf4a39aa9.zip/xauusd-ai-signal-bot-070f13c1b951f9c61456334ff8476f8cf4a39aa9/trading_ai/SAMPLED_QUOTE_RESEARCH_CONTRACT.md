# Sampled BID/ASK research contract v1

Research/shadow only. This block does **not** modify production execution, DEMO/live trading, risk sizing, or the default Trading AI feature vector.

Review history:

- DeepSeek design pre-review: `PASS_WITH_REQUIRED_CHANGES`; causal clock, explicit sampled semantics, duplicate fail-closed rule, quality gates, dual spread normalization, and semantic exclusions were incorporated before the first implementation.
- DeepSeek post-review V1 on head `83a61e0a3ec28b9a6e484dece9b9164a986d7007`: `PASS_WITH_REQUIRED_CHANGES`. The implementation was then tightened to separate quote readiness from ATR readiness, eliminate ambiguous zero-filled NOT_READY predictors, isolate quality metadata from predictors, and rename metrics that could overclaim volatility/order-flow semantics.

A new exact-head test run and delta review are required before merge.

## Data semantics

- Source is the persisted `mt5_quotes` BID/ASK stream.
- Current bridge persistence is throttled to roughly one saved row per 5 seconds by default; therefore this is **sampled quote context**, not a complete tick stream.
- The block must never be described as Footprint, CVD, OFI, aggressor flow, L2/DOM, trade prints, or exchange order flow.
- `received_at` is the causal availability clock. `broker_time` is diagnostic only and never overrides server receipt time.
- A decision at time `T` may use only rows with `received_at <= T` and the inclusive trailing window `[T-window, T]`; no nearest-future lookup, backfill, or forward-fill across gaps is allowed.

## Initial quality gates

The defaults below are starting hypotheses requiring empirical validation, not proven optimal values:

- trailing window: 60 seconds;
- expected persistence interval: 5 seconds;
- minimum samples: 8;
- maximum latest-sample age: 15 seconds;
- maximum consecutive persisted-sample gap: 20 seconds;
- duplicate `received_at` timestamps: fail closed, regardless of whether prices match; do not silently deduplicate.

If the persistence throttle changes, these gates and feature comparability must be re-validated.

## Candidate predictors

All predictive names explicitly contain `sampled`:

- `sampled_spread_bps`;
- `sampled_spread_atr_ratio` when ATR is independently ready;
- `sampled_spread_change_bps`, defined as last spread-bps minus first spread-bps over the selected window and therefore explicitly window-dependent;
- `sampled_spread_change_dispersion_bps`, population standard deviation of consecutive spread-bps changes;
- `sampled_mid_return_bps`, first-to-last simple mid return over the selected window;
- `sampled_mid_velocity_bps_per_sec`, using actual `received_at` elapsed time;
- `sampled_mid_return_dispersion_bps`, population standard deviation of consecutive sampled mid returns;
- `sampled_mid_change_fraction`;
- `sampled_quote_direction_sync`.

`sampled_mid_return_dispersion_bps` is deliberately **not** called realized volatility. Consecutive returns may span unequal sampling intervals, so the value is a sampling-dependent dispersion statistic pending explicit normalization research.

`sampled_quote_direction_sync` is only the average of `(sign(ΔBID) + sign(ΔASK)) / 2` across consecutive persisted samples. It is a quote co-movement score, **not** aggressor-side inference, OFI, volume delta, order-flow imbalance, or size imbalance.

## Readiness and quality isolation

Quote readiness and ATR readiness are separate:

- quote-quality failure makes the result `NOT_READY` and all predictor fields unavailable (`None` in the result; empty predictor dictionary in the feature envelope);
- ATR failure does **not** invalidate non-ATR quote predictors;
- if ATR is unavailable, only `sampled_spread_atr_ratio` is unavailable and `sampled_atr_ready=0` is reported in quality metadata.

The research feature API returns an explicit envelope with separate `predictors` and `quality` dictionaries rather than one flat vector. This prevents quality metadata from silently becoming model predictors and removes the ambiguity between a true numeric zero and an unavailable observation.

Quality-only fields include:

- `sampled_quote_ready`;
- `sampled_atr_ready`;
- `sampled_quote_coverage_ratio`;
- `sampled_latest_age_ms`;
- `sampled_max_gap_ms`;
- `sampled_duplicate_received_at`;
- `sampled_samples_used`.

Raw BID/ASK prices and quality fields are not approved predictive features in this block.

## Fail-closed rules

Quote predictors are unavailable when quote data fails validation because of insufficient samples, stale latest quote, excessive gap, duplicate receipt timestamp, invalid/non-positive price, crossed quote, nonpositive elapsed time, or non-finite derived values. Zero spread is valid. Future rows are removed before their price values are validated so data unavailable at the decision time cannot contaminate the decision.

## Promotion gate

V1 remains standalone until controlled chronological OOS ablation demonstrates incremental net-utility value after realistic execution costs. Window length, sampling thresholds, ATR normalization, spread-change dispersion, mid-return dispersion, and quote-direction synchronization remain provisional research choices. No profitability claim is made.
