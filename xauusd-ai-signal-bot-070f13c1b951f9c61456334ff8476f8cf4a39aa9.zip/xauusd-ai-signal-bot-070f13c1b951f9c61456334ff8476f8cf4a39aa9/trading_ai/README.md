# Trading AI shadow core

This directory is the start of the new Trading AI that is intended to replace the legacy XAU/USD bot after validation.

Current state: SHADOW ONLY. No order execution is permitted from this package.

## Architecture

Market data -> AI Analyst (independent fundamental context) <-> AI Trader -> deterministic Safety Engine -> execution adapter.

The Trader must read numeric LIVE market data directly: ticks, bid/ask, spread, OHLC/volume and M1/M5/M15/M30/H1 context. The Analyst remains an independent source; news agreement is not a hard entry rule.

## Promotion path

1. Data contracts and shadow logging.
2. Historical dataset/window builder with strict no-leakage rules.
3. Baseline sequence model for direction, continuation, pullback, reversal and entry quality.
4. Walk-forward/out-of-sample evaluation after spread/slippage.
5. LIVE SHADOW comparison against the legacy bot.
6. DEMO execution through the existing deterministic Safety Engine only after objective promotion gates pass.
7. Legacy bot replacement only after the new system proves superior and stable.

## Safety invariant

`TradingAIShadowTrader` always emits `execution_allowed=False`. A trained model must not be allowed to bypass DEMO/account/risk/margin/spread/stale-data/SL/dedup/no-hedge/ownership guards.


## Stage 1 Unified Brain

`trading_ai/unified_brain.py` (`unified-brain-v3-stage1`) is the single Stage 1 reasoning-and-learning core. It is deliberately separate from the shadow trading model and never authorizes execution.

One cycle:

`INPUT -> MEMORY -> STATE -> REASONING -> HYPOTHESIS -> EVIDENCE -> DECISION`

Resolution:

`OUTCOME -> ERROR -> LEARNING (quarantined challenger) -> MEMORY (recalled by later decisions)`

Invariants, each enforced by a test in `trading_ai/tests/test_unified_brain.py`:
- **Domain.** The core reasons only about a target moving UP or DOWN, or abstaining. A `DecisionDomain` names the target and the action labels. XAU/USD (`XAUUSD_DOMAIN`, BUY/SELL/WAIT) is the default adapter at the end of the module, and another domain runs the same loop unchanged.
- **Point in time.**
  - Nothing with `available_at > as_of` can enter a state, an evidence item or an outcome (`LeakageError`).
  - A lesson is recalled, and an accepted policy applies (`policy_at(as_of)`), only for decisions after it was learned and validated.
- **Memory.**
  - Persistent memory is append-only and hash-chained: edits, reorders, gaps, corrupt rows and a rolled-back policy history are refused on start.
  - Writes are atomic, and serialized across connections and processes.
  - Working memory keeps the most recently available observations and is identical after a restart. If it may have evicted a still-fresh input, the state's uncertainty is 1.0 (WAIT).
- **Hypotheses.** They carry an explicit direction and causal path; a direction is never parsed from text. Causal links are data, and the project graph is the intended provider.
- **Decisions.**
  - Made only on a world state the brain itself perceived.
  - Confidence is always recomputed from evidence: an input confidence is ignored, and a caller prior can only lower it.
  - Uncertainty, contradictions, conflicting hypotheses and a top hypothesis without positive supporting evidence force WAIT.
  - Evidence must cite a real observation of the state, and its reliability comes from the policy for that observation's source.
  - A caller may raise the confidence threshold but never lower it. NaN/inf inputs are refused.
- **Reproducibility.**
  - The trace id covers every field and input.
  - `replay_decision(trace_id)` rebuilds the decision from memory alone: observations, a verified policy in effect at its as_of, raw inputs and causal links. It raises `MemoryConflict` on any difference.
  - Outcomes are recorded only for decisions that replay.
- **Outcomes.** An outcome needs an `available_at_ms`. Its data cannot exist before the decision horizon ends or after its resolution, and each decision has exactly one outcome.
- **Policy changes.**
  - A lesson never changes behaviour. The active policy changes only through challenger -> held-out sandbox validation -> `accept_challenger(approved_by=...)`, recorded as an append-only policy event with an `effective_from_ms`.
  - Lessons and challengers must re-derive from the stored decision, outcome and parent policy, so records injected into memory are refused.
  - Unresolved or correct outcomes teach nothing, and one lesson is applied at most once.
  - A challenger based on a superseded policy can be neither validated nor accepted, and none is accepted twice.
- **Concurrency.** One brain instance per thread or process. Instances may share one SQLite file, but each instance's working memory sees another instance's new observations only after a restart.

Tightened public contracts: `record_outcome` requires `Outcome.available_at_ms`, and `recall_lessons` requires `as_of_ms`. `decide` re-evaluates hypotheses against `evidence` and refuses a state the brain did not perceive. `propose_challenger` refuses no-change and already-applied lessons. `DecisionTrace.action` is the domain's label, with new `direction` and `domain` fields. A SQLite memory file without the integrity chain is refused.

Audit, fixes, CI diagnosis and BLOCKED items are in `trading_ai/STAGE1_UNIFIED_BRAIN_AUDIT.md`.
