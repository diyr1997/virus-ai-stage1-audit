# ALL indicators status

- Stack: `TRADING_AI_ALL_INDICATORS_V1`
- Scope: research/shadow only; no REAL trading authorization.
- Simultaneous current-data indicator stack implemented.
- Exact-head regression safety expanded with context-length, degenerate-Fibonacci, DST-transition opening-range, and default/DEMO isolation tests.
- Exact-head Railway verification on `470dd37d39a51b3bc8ea88a04b8d4d953b1e5f6f`: **175 passed, 0 failed** (`6f363a7e-25f3-45a3-9914-db0ac6fe3a93`).
- DeepSeek exact-head source review on preceding source-equivalent head `6c272b46ef0372b52bb39b2d5921681e5e0a3400`: `PASS_RESEARCH_MERGE`; the later delta is tests/status only.
- Next gate: merge research stack, then run ALL-vs-baseline chronological OOS and leave-family-out ablations. Final profitability/edge claims remain forbidden until executable after-cost evaluation is complete.
