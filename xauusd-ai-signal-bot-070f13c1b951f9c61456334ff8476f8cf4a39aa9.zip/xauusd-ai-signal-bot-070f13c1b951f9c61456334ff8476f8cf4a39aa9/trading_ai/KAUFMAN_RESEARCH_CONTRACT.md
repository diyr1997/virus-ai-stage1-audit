# Kaufman ER/KAMA research contract v1

Research/shadow only. This candidate block does **not** modify production execution, DEMO/live trading, risk sizing, or the default Trading AI feature vector.

- Defaults `ER=10`, `fast=2`, `slow=30` are research hypotheses to ablate, not trading rules or claims of edge.
- ER at decision index `t` uses exactly `n` closed-price transitions from `C[t-n]` through `C[t]`.
- A completely flat denominator maps to `ER=0`, not `ER=1`.
- KAMA seed is frozen at index `n-1` as `SMA(C[0]..C[n-1])`; the first ER-based update occurs at index `n`.
- Seed-affected internal values are explicitly marked `kaufman_warmup=1` while `t < n + slow_period`.
- Mathematical `KaufmanResult.status=READY` means ER/KAMA are calculable, but the exported model block is stricter: during seed warmup it emits `kaufman_ready=0` and zero candidate values. Therefore a consumer that obeys readiness cannot accidentally train on seed-affected values.
- The adaptive smoothing constant is internal because, for fixed fast/slow periods, it is a deterministic transform of ER and would be redundant as a model feature.
- Raw KAMA price is not exposed. Candidate features are readiness, warmup, ER, ATR-normalized distance, and ATR-normalized one-bar KAMA slope.
- Invalid/non-positive prices and missing/non-positive ATR fail closed to `NOT_READY`; the numeric feature block remains finite and schema-stable.
- If a decision timestamp is supplied, future candles are ignored and the timestamp must match an available closed bar exactly.
- Each timeframe is computed independently from its own closed candles.
- V1 remains standalone until controlled chronological ablation demonstrates incremental value beyond simpler EMA/trend features.
- Required ablation: baseline EMA/trend context vs baseline + KER/KAMA across multiple chronological OOS blocks, using net utility after execution costs; no promotion based only on in-sample fit.
- Initial integration remains disabled: this module is a candidate library until exact-head tests, post-review, and ablation gates are satisfied.
