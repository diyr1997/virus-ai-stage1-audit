from __future__ import annotations

from dataclasses import dataclass
from math import sqrt
from typing import Mapping, Sequence

from .labels import DirectionLabel, LabeledSample
from .pipeline import TrainingSample


@dataclass(frozen=True)
class BaselineMetrics:
    samples: int
    directional_accuracy: float
    mean_signed_return: float
    rmse: float


@dataclass(frozen=True)
class ClassificationMetrics:
    samples: int
    three_class_accuracy: float
    coverage: float
    active_direction_accuracy: float


@dataclass(frozen=True)
class LinearBaselineModel:
    horizon: int
    feature_names: tuple[str, ...]
    means: Mapping[str, float]
    scales: Mapping[str, float]
    weights: Mapping[str, float]
    intercept: float

    def predict_one(self, features: Mapping[str, float]) -> float:
        total = float(self.intercept)
        for name in self.feature_names:
            scale = float(self.scales.get(name, 1.0)) or 1.0
            x = (float(features.get(name, 0.0)) - float(self.means.get(name, 0.0))) / scale
            total += float(self.weights.get(name, 0.0)) * x
        return total


def _mean(values: Sequence[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def _std(values: Sequence[float], mean_value: float) -> float:
    if len(values) < 2:
        return 1.0
    value = sqrt(sum((x - mean_value) ** 2 for x in values) / (len(values) - 1))
    return value if value > 1e-12 else 1.0


def fit_linear_baseline(samples: Sequence[TrainingSample], *, horizon: int = 5, max_features: int = 64) -> LinearBaselineModel:
    """Fit a tiny dependency-free ridge-style baseline using univariate standardized correlations.

    This is deliberately simple: it provides a reproducible hurdle model, not a claim
    of production trading quality. All fitting must be performed on the chronological
    training split only.
    """
    rows = [s for s in samples if horizon in s.future_returns]
    if not rows:
        raise ValueError("no samples contain requested horizon")
    names = sorted({key for row in rows for key in row.features})[: max(1, int(max_features))]
    y = [float(row.future_returns[horizon]) for row in rows]
    y_mean = _mean(y)

    means: dict[str, float] = {}
    scales: dict[str, float] = {}
    weights: dict[str, float] = {}
    for name in names:
        xs = [float(row.features.get(name, 0.0)) for row in rows]
        xm = _mean(xs)
        scale = _std(xs, xm)
        means[name] = xm
        scales[name] = scale
        zs = [(x - xm) / scale for x in xs]
        denom = sum(z * z for z in zs) + 10.0
        weights[name] = sum(z * (target - y_mean) for z, target in zip(zs, y)) / denom if denom > 0 else 0.0

    return LinearBaselineModel(
        horizon=int(horizon),
        feature_names=tuple(names),
        means=means,
        scales=scales,
        weights=weights,
        intercept=y_mean,
    )


def evaluate(model: LinearBaselineModel, samples: Sequence[TrainingSample]) -> BaselineMetrics:
    rows = [s for s in samples if model.horizon in s.future_returns]
    if not rows:
        return BaselineMetrics(0, 0.0, 0.0, 0.0)
    squared = 0.0
    correct = 0
    signed_returns = []
    for row in rows:
        target = float(row.future_returns[model.horizon])
        prediction = model.predict_one(row.features)
        squared += (prediction - target) ** 2
        pred_sign = 1 if prediction > 0 else -1 if prediction < 0 else 0
        target_sign = 1 if target > 0 else -1 if target < 0 else 0
        correct += int(pred_sign == target_sign)
        signed_returns.append(target * pred_sign)
    return BaselineMetrics(
        samples=len(rows),
        directional_accuracy=correct / len(rows),
        mean_signed_return=_mean(signed_returns),
        rmse=sqrt(squared / len(rows)),
    )


def predict_label(model: LinearBaselineModel, features: Mapping[str, float], threshold: float) -> DirectionLabel:
    prediction = model.predict_one(features)
    threshold = max(float(threshold), 0.0)
    if prediction > threshold:
        return DirectionLabel.BUY
    if prediction < -threshold:
        return DirectionLabel.SELL
    return DirectionLabel.WAIT


def evaluate_classification(model: LinearBaselineModel, labeled_samples: Sequence[LabeledSample]) -> ClassificationMetrics:
    rows = [row for row in labeled_samples if model.horizon in row.labels and model.horizon in row.thresholds]
    if not rows:
        return ClassificationMetrics(0, 0.0, 0.0, 0.0)

    correct_all = 0
    active = 0
    active_correct = 0
    for row in rows:
        actual = row.labels[model.horizon]
        predicted = predict_label(model, row.sample.features, row.thresholds[model.horizon])
        correct_all += int(predicted == actual)
        if predicted != DirectionLabel.WAIT:
            active += 1
            active_correct += int(predicted == actual)

    return ClassificationMetrics(
        samples=len(rows),
        three_class_accuracy=correct_all / len(rows),
        coverage=active / len(rows),
        active_direction_accuracy=(active_correct / active) if active else 0.0,
    )
