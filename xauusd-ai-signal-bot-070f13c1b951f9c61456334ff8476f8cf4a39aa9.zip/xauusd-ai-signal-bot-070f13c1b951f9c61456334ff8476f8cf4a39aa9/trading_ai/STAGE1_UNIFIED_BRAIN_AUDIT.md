# Stage 1 Unified Brain — technical audit (2026-09-23, final adversarial round 4)

- Scope: `trading_ai/unified_brain.py` (version `unified-brain-v3-stage1`) and `trading_ai/tests/test_unified_brain.py`.
- Research/shadow only. The brain never authorizes execution (`DecisionTrace.execution_allowed` is always False). It does not touch `TradingAIShadowTrader`, the active trading model, the DEMO worker or any promotion path.
- No readiness percentage is claimed. Each item below is backed by the named test, or it is marked BLOCKED / NOT DONE.

## 1. Defects found in the v1 brain (and fixed)

| # | v1 defect | Consequence | Fix |
|---|---|---|---|
| 1 | Memory used `INSERT OR REPLACE` | A decision, lesson or outcome could be silently overwritten, so history was mutable | The store is append-only. An identical rewrite is a no-op; a different payload raises `MemoryConflict` |
| 2 | Action parsed from free text (`"BUY" in statement`) | "do not BUY here" became BUY | Hypotheses carry an explicit `direction` (UP/DOWN/UNKNOWN). UNKNOWN always gives WAIT |
| 3 | `uncertainty` was never computed (always 1.0) and never used | The decision ignored uncertainty | Uncertainty is computed from coverage and staleness. WAIT when it exceeds `max_uncertainty` |
| 4 | No working memory; world state held only the current call's inputs | No short-term context; nothing rebuilt after a restart | `WorkingMemory` is bounded, PIT-filtered per as_of, drops stale inputs, and is rebuilt from persistent memory |
| 5 | Lessons were stored but never read | The loop never closed: learning did not reach the next reasoning step | `recall_lessons()` attaches lessons of the same causal paths to later traces (advisory; behaviour unchanged) |
| 6 | Challenger had no validation and no acceptance path | "Self-learning" could not be governed | challenger → held-out validation in a sandbox → explicit `accept_challenger(approved_by=…)` → versioned policy event |
| 7 | Outcome check was `resolved >= as_of`, with no horizon and no outcome PIT | An outcome could resolve at the decision instant, use later data, or be recorded twice | The outcome must be after the decision **and** after the horizon; `observed_at` and `available_at` are checked against `resolved_at`; and there is one outcome per decision |
| 8 | Error analysis only had RIGHT/WRONG, and blame went nowhere | Nothing to learn from | Errors are classified as CORRECT / WRONG / OVERCONFIDENT_WRONG / MISSED_MOVE / CORRECT_ABSTENTION / UNRESOLVED. Blame goes to the sources of the observations that supported the chosen hypothesis only |
| 9 | Several items from one observation added up | False confidence | Evidence is aggregated once per observation |
| 10 | Competing hypotheses with opposite directions and near-equal confidence still traded; direct contradictions could still be ignored | Contradictions were not handled consistently | WAIT on `CONFLICTED_HYPOTHESES` **and** on any recorded contradictory evidence; evidence attribution and duplicate IDs are validated |
| 11 | State identity omitted observation payload details | Different world states with the same observation IDs/timestamps could collide | `WorldState.state_hash()` now hashes the complete normalized observations plus stale/regime/uncertainty state |
| 12 | Future data raised a plain `ValueError` | Differed from the project's no-leakage type | `trading_ai.dataset.LeakageError` is reused (it subclasses `ValueError`) |
| 13 | Learning objects could be forged or accepted after their parent policy became stale | Challenger provenance could be bypassed or roll back policy state | Lessons/proposals are checked against immutable memory; validation/acceptance require the proposal to be quarantined and based on the current champion; a challenger cannot be accepted twice |

## 1b. Audit round 3: holes found in the hardened brain at `c53a7d84` (all fixed)

**Method.** A probe script ran each suspected hole against the unmodified `c53a7d84` module, and every one reproduced. Each was then fixed, and a regression test was added.

**Mutation check.** All 14 new tests fail against the `c53a7d84` module; some fail only because an API they need, such as `replay_decision`, did not exist yet. All of them pass after the fix.

**Baseline finding.** At `c53a7d84`, `test_evidence_integrity_rejects_misattribution_and_duplicates` already **failed** (1 failed, 14 passed). It had been pushed without being executed. Its "opposite direction" case never declared contradicting evidence, so the check it was meant to test never ran. The test is fixed and now exercises that check.

| # | Hole (probe result at `c53a7d84`) | Risk | Fix | Regression test |
|---|---|---|---|---|
| 14 | A lesson resolved at `36001000` was recalled by a decision with `as_of=500` | Look-ahead: the future leaks into a past trace | `recall_lessons(..., as_of_ms=)` only returns lessons whose `created_at_ms <= as_of` | `test_future_lessons_are_never_recalled_by_an_earlier_decision` |
| 15 | Two decisions on the same state with different evidence got the same `trace_id`, and the second raised `MemoryConflict` | Trace identity collision; a decision crashes instead of being recorded | The trace id hashes every trace field plus the full inputs; identical calls are idempotent | `test_trace_identity_covers_every_input_and_repeats_are_idempotent` |
| 16 | No way to re-derive a decision; the trace did not store evidence, the threshold or the raw inputs | A decision could not be reproduced or audited | `decision_input` record plus `replay_decision(trace_id)`. It rebuilds the state from stored observations (hash must match), the policy from its record, and regenerates and re-evaluates hypotheses from raw inputs and causal links. Recalled lessons must exist and predate the decision. `record_outcome` learns only from decisions that replay | `test_every_decision_is_reproducible_from_memory_and_tampering_is_detected`, `test_decision_on_a_caller_built_state_is_replayable_and_learnable` |
| 17 | `decide()` gave **BUY** for a bare hypothesis with confidence 0.99 and zero evidence | An action not attributable to evidence | WAIT `UNSUPPORTED_HYPOTHESIS` unless positive evidence from the state supports the top hypothesis | `test_directional_decision_needs_traceable_evidence_and_threshold_cannot_be_loosened` |
| 18 | `think(minimum_confidence=0.1)` silently lowered the policy threshold | Behaviour changed without the challenger path | A caller may only raise the threshold; the effective threshold is stored in the trace and checked by replay | same |
| 19 | Evidence could claim any `source`/`reliability` (confidence 0.75 from a mismatched source) | A distrusted source can vouch for itself | Source must match the observation; reliability = min(evidence, policy reliability of the observation's source) | `test_evidence_provenance_is_checked_against_the_observation` |
| 20 | A hypothesis citing non-existent evidence was accepted, and the trace listed the ghost id | Mismatched evidence in the trace | Cited supporting or contradicting evidence must be supplied | same |
| 21 | An outcome with `available_at_ms=None` was accepted, and so was one available **before the horizon ended** | A lesson learned from data of unknown or impossible timing | `available_at_ms` is mandatory; outcome data (observed or available) cannot predate the horizon's end | `test_outcome_needs_availability_after_the_horizon` |
| 22 | Working memory: re-perceiving an evicted observation gave state `[x, z]` before a restart and `[y, z]` after | Restart changes decisions | Retention is by (available_at, id) only: top-`capacity` observations, independent of insertion order | `test_working_memory_eviction_is_restart_invariant_and_fails_closed` |
| 23 | Capacity overflow silently dropped a **fresh** observation, with uncertainty 0.53 | A decision on an incomplete state | If an evicted observation may still be fresh, `working_memory_complete=False`, uncertainty is 1.0 and the decision is WAIT; this flag is part of the state hash | same, `test_state_identity_distinguishes_every_reasoning_input` |
| 24 | A lesson written directly into memory produced a challenger | Forged learning | A lesson must re-derive from its stored decision and outcome | `test_forged_lessons_are_rejected` |
| 25 | A challenger written directly into memory (with `minimum_confidence=0`) passed provenance and entered validation | Forged policy | A challenger must re-derive from its genuine lesson and its stored parent policy | `test_forged_challengers_are_rejected` |
| 26 | A policy record edited via SQL (`minimum_confidence` 0.65→0.01) became the active policy | Corrupted active policy | Each policy event records `policy_hash`, checked on every read | `test_corrupted_active_policy_or_history_is_detected` |
| 27 | A policy event outside the history (`seq` 7, no parent link) became active; only the latest event was checked | Rollback or injection through history | The full history is verified: contiguous `seq`, record hash, parent chain, no version activated twice. The sandbox now uses `initial_policy` instead of a fake `"9999"` event | same |
| 28 | Stale-challenger rollback and duplicate acceptance had no dedicated test | Regression risk | Existing guards kept; new test: A and B both from `policy-v1`, both validated; after A is accepted, B cannot be validated or accepted, and A cannot be accepted twice | `test_stale_challenger_cannot_roll_back_and_acceptance_is_once` |
| 29 | Execution isolation was tested only on a fresh trace | A stored trace could claim execution rights | A restart refuses a stored decision with `execution_allowed=true`; the module's imports are pinned to stdlib + `core` + `dataset` (no broker/MT5/order path) | `test_execution_is_isolated_from_the_brain` |
| 30 | Restart after policy acceptance was untested | Policy or replay drift after restart | The accepted policy, open decisions and replay survive a restart from the SQLite file | `test_restart_preserves_policy_history_and_replay` |

**Backward compatibility.** `grep` finds no caller of `unified_brain` outside its own module and tests (only README/audit mentions). The changes to existing callers' contracts are:
- new dataclass fields have defaults;
- `Outcome.available_at_ms` is now **required by `record_outcome`**, and `recall_lessons` now takes `as_of_ms`. Both are deliberate fail-closed changes; the existing tests were updated accordingly.

**Residual risks (not fixable without new infrastructure, documented, not hidden):**
- **Memory is the trust root.**
  - Someone with raw write access to the store can insert a "passing" validation report for a *genuine* challenger. Acceptance still requires an explicit `approved_by`.
  - A coordinated SQL rewrite of a policy record *and* its event hash is not detectable without signing.
  - Both need signed or externally anchored memory, which is not in Stage 1.
- Observations that are surely stale when evicted are forgotten by design, so the stale share only counts retained observations.
- `regime` is always `UNKNOWN`; no regime classifier is part of Stage 1.

## 1c. Final adversarial round 4: holes found at `e3e24f03` (all fixed)

**Method.**
- A probe script (13 attacks) ran against the unmodified `e3e24f03` module, and each attack below reproduced before it was fixed.
- One more hole (#43) surfaced while the crash-recovery tests were being written, and was fixed the same way.
- Every fix has a regression test.

**Mutation check.** New and updated tests were run against the `e3e24f03` module. The domain classes did not exist there, so they were stubbed for collection only. Result: **20 failed, 38 passed**.
- The 38 passes are the earlier rounds' guards and the new confirmation tests (PIT, replay mutations, idempotency), which already held.
- The race test failed nondeterministically on the old module (1 of 3 runs, `IntegrityError`) and passed 10 of 10 times on the new one.

| # | Hole (probe result at `e3e24f03`) | Risk | Fix | Regression test |
|---|---|---|---|---|
| 31 | The core hard-coded the trading domain. Hypothesis text said "implies XAU"; the decision alphabet was BUY/SELL; outcome scoring and validation branched on BUY | Unified Brain silently specialised into one market | The core reasons with `direction` (UP/DOWN/NONE). `DecisionDomain` supplies the target and action labels. The XAU/USD adapter (`DecisionAction`, `XAUUSD_DOMAIN`, market/analyst converters) is moved to the end of the module. An AST check keeps trading vocabulary out of `UnifiedBrain` | `test_reasoning_core_is_domain_neutral` (a full governed loop in a non-trading domain) |
| 32 | `decide()` trusted the caller's hypothesis confidence: **BUY at 0.99** with evidence of strength 0.01 | Confidence inflated by editing an input object | `decide` always re-evaluates hypotheses against their evidence, and input confidence is ignored | `test_confidence_cannot_be_raised_by_editing_input_objects` |
| 33 | A caller prior of 1.0 gave **BUY at 1.0** from one weak item | Same | Prior = min(caller prior, 0.5): a caller can be more sceptical, never more confident | same |
| 34 | A caller-built `WorldState` with uncertainty 0.0 from one observation was accepted, and so was a cherry-picked subset | Forged state bypasses the uncertainty and completeness gates | Decisions only on a state the brain perceived (the stored `world_state` record must match). Replay also recomputes uncertainty | `test_decisions_are_made_only_on_states_the_brain_perceived` |
| 35 | A NaN input became hypothesis `H:usd:UP` | Missing data read as a signal | `Observation.validate` refuses NaN/inf; the generator skips non-finite values; `realized_return` must be finite | `test_confidence_cannot_…`, `test_outcome_and_lesson_provenance_…` |
| 36 | Duplicate hypothesis ids (one UP, one DOWN) were evaluated side by side | Ambiguous attribution | Duplicate `hypothesis_id` raises | `test_confidence_cannot_…` |
| 37 | **Future policy:** a policy learned from outcomes after as_of=500 governed a decision at as_of=500 | Look-ahead through learning | Policy events carry `effective_from_ms`, whose floor is max(lesson time, the validation report's `knowledge_until_ms`, previous policy time). An earlier value raises `LeakageError`. Decisions use `policy_at(as_of)`; replay accepts only a verified policy in effect at the trace's as_of | `test_future_policy_never_reaches_an_earlier_decision` |
| 38 | Deleting the latest `policy_event` silently rolled back to `policy-v1` | Undetected rollback | Every policy record must have its activation event; a hash chain covers every row | `test_memory_integrity_chain_refuses_edits_reorders_gaps_and_corruption` |
| 39 | `replay_decision` loaded the policy without checking its hash; a policy edited via SQL still replayed `True` | Replay proves nothing about the policy | Replay uses the verified history (hash, chain, effective time) | `test_replay_detects_every_single_mutation[policy…]` |
| 40 | A corrupt JSON row crashed a restart with `JSONDecodeError`; an edited record the brain never rereads (event `reason`) passed | Silent corruption | `SQLiteMemoryStore` hash-chains every row (seq, kind, key, payload). `verify()` on start refuses edits, reorders, gaps and corrupt JSON. A legacy table without the chain is refused | same |
| 41 | A challenger was proposed from an **UNRESOLVED** outcome | Learning from an unconfirmed result | Unresolved or correct lessons imply no change, and `propose_challenger` refuses them | `test_outcome_and_lesson_provenance_cannot_be_borrowed_or_forged` |
| 42 | Concurrent writers: `sqlite3.IntegrityError` (check-then-insert race) | Crash or lost write under concurrency | `BEGIN IMMEDIATE` transactions: check+insert is atomic across connections and processes; `put_many` is all-or-nothing | `test_writes_are_atomic_and_serialized_across_connections`, `test_concurrent_acceptances_admit_exactly_one` |
| 43 | **Found by the crash-recovery test.** After a lesson's challenger was accepted, the same lesson produced a new challenger from the new champion (reliability 0.9 → 0.8 again) | One loss learned twice (compounding) | A lesson already applied by a policy event cannot be proposed again; re-proposing against the same champion is idempotent | `test_one_lesson_is_applied_at_most_once` |

**Crash recovery (new test).** The process is killed right after each committed write: observation, world_state, decision, outcome, challenger, validation, policy_event. After a restart, re-running the whole process (twice) gives exactly the records of an uninterrupted run, with no duplicates and a verified chain and policy history. The paired writes (decision_input+decision, outcome+lesson, policy+policy_event) are single atomic batches.

**Confirmation tests** (the guards held at `e3e24f03` and are now pinned down):
- **PIT across the loop:** a future observation, future evidence, a restart with far-future data, and a backfilled record with a correct timestamp written after the decision (the old decision still replays unchanged; a new one gets a new id).
- **Replay against single mutations:** observation value, raw evidence strength, raw prior, causal link sign, threshold, world-state uncertainty, observation order, a deleted observation.
- **Identity:** identical re-runs add no rows; six input variants get six distinct ids.
- **Provenance:** a lesson borrowed from another decision's outcome, a lesson edited after creation, a second outcome for a trace.
- **Foreign challenger:** a challenger from another policy line is refused.

## 2. Architecture map (loop stage → code → test)

| Stage | Mechanism | Test |
|---|---|---|
| INPUT / perception | `normalize_observation`, `observation_from_market` (existing `core.MarketSnapshot`), `observation_from_analyst` (existing `core.AnalystContext`) | `test_input_normalization_and_existing_contracts` |
| PIT / no-lookahead | `LeakageError` in state, evidence and outcome; outcome `available_at` is checked | `test_future_information_is_rejected_everywhere`, `test_outcome_clock_and_single_outcome` |
| Persistent memory | `SQLiteMemoryStore` (append-only; the Protocol allows PostgreSQL) | `test_persistent_memory_is_append_only`, `test_memory_survives_restart_and_rebuilds_working_memory` |
| Working memory | `WorkingMemory` | same + `test_stale_observations_raise_uncertainty_and_leave_the_state` |
| World state and uncertainty | `perceive` → `WorldState(uncertainty, stale_observation_ids)`; state hash includes all reasoning-relevant state fields | `test_stale_observations_…`, `test_contradiction_conflict_and_uncertainty_force_wait` |
| Causal reasoning and hypothesis generation | `CausalLink` (data) → `generate_hypotheses` (competing, explicit direction, causal path) | `test_causal_hypotheses_compete_and_carry_explicit_direction`, `test_direction_is_never_parsed_from_text` |
| Evidence aggregation | `evaluate` | `test_evidence_from_one_observation_counts_once` |
| Contradiction handling | contradicting evidence and explicit WAIT safety gate | `test_contradiction_conflict_and_uncertainty_force_wait`, `test_evidence_integrity_rejects_misattribution_and_duplicates` |
| Decision trace and replay | `DecisionTrace` (state hash, policy version, path, recalled lessons, supporting observations, threshold), `decision_input`, `replay_decision` | `test_every_decision_is_reproducible_…`, `test_trace_identity_…` |
| Outcome journal | `record_outcome` | `test_outcome_clock_and_single_outcome` |
| Error analysis | `_classify` | `test_error_analysis_attributes_blame_and_learning_is_quarantined` |
| Controlled learning | `propose_challenger` → QUARANTINED | same |
| Challenger / validation / acceptance | `validate_challenger` (held-out, sandboxed, provenance-checked), `accept_challenger` (passing report + approver + current-parent check, idempotency guard) | `test_challenger_needs_held_out_validation_and_explicit_approval` |
| Unified loop | `think` + `record_outcome` + `propose_challenger` + recall | `test_full_closed_loop_input_to_memory` |
| Domain neutrality | `DecisionDomain` (target + action labels); core reasons in UP/DOWN/NONE; XAU/USD adapter at module end | `test_reasoning_core_is_domain_neutral` |
| Crash recovery / concurrency | atomic `put_many`, `BEGIN IMMEDIATE`, hash chain `verify()` on start | `test_crash_after_any_write_recovers_without_duplicates[*]`, `test_concurrent_acceptances_admit_exactly_one`, `test_memory_integrity_chain_…` |

## 3. Integration decisions (no second architecture)

- **Inputs** reuse `trading_ai.core.MarketSnapshot` / `AnalystContext`. **Leakage** reuses `trading_ai.dataset.LeakageError`.
- **Causal model.** The brain contains no economic rules; causal links arrive as `CausalLink` data. The project's causal graph (`global_causal/graph.js`, `dynamic_paths.js`) lives in PR #240 and is **not on this branch**.
  - Wiring it in (export the graph's signed paths as `CausalLink` rows) is therefore **BLOCKED until #240 is merged**.
  - A second graph was not written in Python.
- **Execution** stays with the existing deterministic Safety Engine / DEMO worker. The brain produces no order and changes no policy on its own.

## 4. CI — actual cause of "Trading AI Research Tests" / "Weekend Trainer Safety" failing with `steps=[]`

Measured through the GitHub API on 2026-09-23:
- job 107352217494 (`trainer-safety`) has `runner_id: 0` and an empty `runner_name`, and completed 2 s after creation. **No runner was ever assigned**, so no step ran.
- Every workflow in the repository failed the same way in the last 40 completed runs: Trading AI, Weekend Trainer, Global Causal, V9 Worker Safety, First Bot Compact UI, Trading School, Historical News …, on `main`, on PR branches and on push. Each took 2–10 s.
- A failure that no workflow change can influence, across unrelated workflows, points to an **account-level block on GitHub-hosted runners**. The workflows themselves note a 2,000-minute free-tier allowance, and this looks like exhausted minutes or a billing/spending-limit lock.
- It is **not** a test or workflow-content failure. Both workflows' commands run green locally (below).
- Fixing it needs the account owner: GitHub → Settings → Billing and plans (Actions minutes / spending limit / payment). **BLOCKED — cannot be fixed from the repository.**

Real repository defects found while diagnosing, and fixed:
- `.github/workflows/package-home-worker.yml` and `.github/workflows/v9-worker-tests.yml` were **invalid YAML**. Heredoc bodies at column 0 ended the `run: |` block, so GitHub listed them as nameless runs that failed at 0 s.
- The heredoc lines were indented to the block indentation. YAML strips that indentation again, so the scripts are byte-identical in their heredoc content (checked by parsing).
- All 29 workflow files now parse.

## 5. Verification actually run (local, final round)

- **Environment:** Python **3.11.15**, the version both workflows pin, in a venv from `trading_ai/requirements-dev.txt` (`pytest==8.3.2`, `pytest-timeout==2.3.1`) plus the Weekend Trainer's `numpy pandas joblib scikit-learn`.
- **Code under test:** `e3e24f03` plus this round's diff (committed right after, see §6).
- **Commands:** the workflow commands.

| Check | Result |
|---|---|
| `pytest trading_ai/tests --collect-only -q` | 239 tests collected |
| `pytest trading_ai/tests -q --tb=short --timeout=300` | **239 passed** |
| `pytest trading_ai/tests/test_unified_brain.py` | 58 passed (31 → 58) |
| Mutation check: new/updated tests against the `e3e24f03` module | 20 failed, 38 passed (see §1c) |
| Concurrency and crash tests repeated 10× | 10 of 10 runs: 9 passed |
| `unittest discover -s trading_ai/tests` | OK (11) |
| `compileall -q trading_ai` | OK |
| Weekend Trainer: `py_compile` list + `unittest` (5 modules) | OK, 64 tests |
| Whole repository `pytest -q` | **388 passed, 2 skipped** (the skips need `V9_TEST_DATABASE_URL`/`psycopg2`) |
| Those 2 Postgres tests, run separately against a throwaway local **PostgreSQL 16.13** cluster (`psycopg2-binary`), then stopped and deleted | **2 passed**, so every repository pytest test ran: 390 passed |
| Node test suites | **Not run**: this round changes no JS/JSON, and no Node code imports the brain |
| GitHub Actions | See §6 C: not a pass while no runner is assigned |

## 6. Stage 1 status (final adversarial round)

### A. Closed (found, fixed, regression-tested)
Holes #1–#43 across four rounds (§1, §1b, §1c). The closed areas are:
- PIT through the whole loop, including lessons and **policies**;
- world-state identity, and decisions only on states the brain perceived;
- evidence provenance, reliability and confidence integrity (input confidence and prior can't inflate);
- contradiction → WAIT;
- reproducible decisions (`replay_decision`, verified policy);
- append-only, hash-chained, atomic and serialized memory;
- restart- and eviction-invariant working memory;
- outcome availability;
- lesson and challenger provenance; one lesson, one learning step;
- stale, rollback and duplicate acceptance guards;
- execution isolation;
- domain-neutral core.

### B. Verified by tests (this session, locally)
- All of §5.
- 58 Unified Brain tests, including:
  - crash recovery after each of the 7 kinds of committed write;
  - 9 single-field replay mutations;
  - thread races on shared SQLite files;
  - a full governed loop in a non-trading domain.

### C. Not verifiable here (infrastructure)
- **GitHub Actions:** no runner is assigned (`runner_id: 0`, jobs end in 2–3 s, no step runs; §4). The CI result of this commit is recorded below the commit once pushed, and is **not** counted as a pass.
- **Causal-link provider from the project graph:** BLOCKED until PR #240 merges (§3).
- **Multi-host concurrency** (network filesystems, a PostgreSQL memory adapter): not tested. Only threads and connections on one local SQLite file were tested.

### D. Real residual limitations (documented, not hidden)
1. **Memory is the trust root.**
   - The hash chain is unkeyed. It catches corruption, naive edits, reorders, gaps and a rolled-back policy event, but not an attacker who rewrites the tail and recomputes the chain, nor truncation of the last rows together.
   - A writer that uses the store API directly (bypassing the brain) can insert self-consistent fabricated records, for example a passing validation report. Acceptance still needs an explicit `approved_by`.
   - Both need a keyed MAC or signatures plus an external anchor.
2. **Evidence strength and causal-link strength are input claims.** Their effect is bounded:
   - evidence counts once per observation;
   - it is capped by the policy's source reliability;
   - it needs ≥3 fresh inputs for low uncertainty, and contradictions force WAIT.

   Their truth cannot be verified until link strengths are learned and calibrated, which is out of Stage 1 scope.
3. **Validation knowledge time** assumes each held-out case resolves within the default 1 h horizon (`knowledge_until_ms`). A case measured over a longer horizon should pass an explicit, later `effective_from_ms` to `accept_challenger`.
4. **Concurrency model.**
   - One brain instance per thread or process; sharing an instance across threads fails loudly, which is tested.
   - Instances share committed memory safely, but each one's working memory sees another's new observations only after a restart.
5. **Working memory.** Observations that are surely stale when evicted are forgotten by design, so the stale share only counts retained observations.
6. **Regime.** `regime` is always `UNKNOWN`; no regime classifier is part of Stage 1.
7. **Tightened contracts** (`available_at_ms`, `as_of_ms`, perceived-state-only `decide`, no-change lessons refused, chain-less SQLite files refused) are deliberate fail-closed breaks. `grep` over all tracked files finds no caller besides the brain's own tests. No service imports it, and no other code reads its table or JSON records.

### E. Deliberately deferred to Stage 2 (by instruction)
- Learning edge and link strengths or indicators from data;
- a regime classifier;
- a PostgreSQL memory adapter;
- keyed or signed memory;
- the causal-graph provider (after #240);
- any historical replay (including January 2020);
- trading accuracy or strategy work;
- live execution. It stays impossible: `execution_allowed` is always False, and the module has no broker, MT5, network or environment access, which an AST test checks.

### Verdict
- After the adversarial round, no known critical architectural hole is left unfixed.
- Every criterion in the round's checklist is met by the local evidence in §5:
  - PIT, memory integrity, reproducibility, evidence integrity, provenance, policy lifecycle;
  - crash recovery, execution isolation, domain neutrality;
  - the full local suite.
- The residual limits are listed in D.
- The only unmet external item is GitHub Actions confirmation (C), which is blocked at the account level, not by the code.
- This is a verified reasoning/learning **foundation**, not a claim of general intelligence or of trading skill.
