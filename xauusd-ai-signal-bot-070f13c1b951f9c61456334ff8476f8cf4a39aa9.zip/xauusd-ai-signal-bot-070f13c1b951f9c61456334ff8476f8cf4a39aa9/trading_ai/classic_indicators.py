from __future__ import annotations

from math import isfinite, sqrt
from statistics import mean
from typing import Sequence

from .dataset import Candle, validate_candles


def _safe_div(a: float, b: float) -> float:
    return float(a) / float(b) if abs(float(b)) > 1e-12 else 0.0


def _ema_series(values: Sequence[float], period: int) -> list[float | None]:
    if period <= 0:
        raise ValueError("period must be positive")
    out: list[float | None] = [None] * len(values)
    if len(values) < period:
        return out
    seed_index = period - 1
    out[seed_index] = mean(values[:period])
    alpha = 2.0 / (period + 1.0)
    for i in range(seed_index + 1, len(values)):
        previous = out[i - 1]
        if previous is None:
            return out
        out[i] = previous + alpha * (values[i] - previous)
    return out


def _wilder_rsi(closes: Sequence[float], period: int = 14) -> float | None:
    if len(closes) < period + 1:
        return None
    gains = []
    losses = []
    for a, b in zip(closes[:period], closes[1 : period + 1]):
        delta = b - a
        gains.append(max(delta, 0.0))
        losses.append(max(-delta, 0.0))
    avg_gain = mean(gains)
    avg_loss = mean(losses)
    for i in range(period + 1, len(closes)):
        delta = closes[i] - closes[i - 1]
        gain = max(delta, 0.0)
        loss = max(-delta, 0.0)
        avg_gain = ((period - 1) * avg_gain + gain) / period
        avg_loss = ((period - 1) * avg_loss + loss) / period
    if avg_gain <= 1e-15 and avg_loss <= 1e-15:
        return 50.0
    if avg_loss <= 1e-15:
        return 100.0
    rs = avg_gain / avg_loss
    return 100.0 - 100.0 / (1.0 + rs)


def _std_population(values: Sequence[float]) -> float:
    if not values:
        return 0.0
    m = mean(values)
    return sqrt(sum((x - m) ** 2 for x in values) / len(values))


def classic_indicator_feature_block(
    candles: Sequence[Candle],
    *,
    prefix: str,
    atr_value: float | None,
) -> dict[str, float]:
    """Causal classic-indicator context for the simultaneous-indicators experiment.

    The block contains numerical context only. Nothing here emits a BUY/SELL rule.
    Every calculation uses only the supplied closed candles. Raw price-level outputs
    are avoided where an ATR-normalized distance is more portable across regimes.
    """

    try:
        validate_candles(candles)
    except (TypeError, ValueError):
        candles = ()

    closes = [float(c.close) for c in candles]
    if any((not isfinite(x) or x <= 0.0) for x in closes):
        closes = []

    atr_ready = (
        atr_value is not None
        and not isinstance(atr_value, bool)
        and isfinite(float(atr_value))
        and float(atr_value) > 0.0
    )
    atr = float(atr_value) if atr_ready else 1.0
    last = closes[-1] if closes else 0.0

    values: dict[str, float] = {}

    # EMA family: trend location and slope, not hard direction rules.
    for period in (9, 21, 50):
        series = _ema_series(closes, period) if closes else []
        current = series[-1] if series else None
        previous = series[-2] if len(series) >= 2 else None
        ready = atr_ready and current is not None and previous is not None
        values[f"{prefix}_ema{period}_ready"] = float(ready)
        values[f"{prefix}_ema{period}_dist_atr"] = (
            (last - float(current)) / atr if ready else 0.0
        )
        values[f"{prefix}_ema{period}_slope_atr"] = (
            (float(current) - float(previous)) / atr if ready else 0.0
        )

    # RSI: bounded momentum / mean-reversion context.
    rsi = _wilder_rsi(closes, 14) if closes else None
    values[f"{prefix}_rsi14_ready"] = float(rsi is not None)
    values[f"{prefix}_rsi14_01"] = (float(rsi) / 100.0) if rsi is not None else 0.0
    values[f"{prefix}_rsi14_centered"] = (
        (float(rsi) - 50.0) / 50.0 if rsi is not None else 0.0
    )

    # MACD 12/26/9, all ATR-normalized to avoid raw-price scale leakage.
    fast = _ema_series(closes, 12) if closes else []
    slow = _ema_series(closes, 26) if closes else []
    macd_values: list[float] = []
    macd_indices: list[int] = []
    for i in range(len(closes)):
        if i < len(fast) and i < len(slow) and fast[i] is not None and slow[i] is not None:
            macd_indices.append(i)
            macd_values.append(float(fast[i]) - float(slow[i]))
    signal_series = _ema_series(macd_values, 9) if macd_values else []
    macd_ready = bool(
        atr_ready
        and macd_values
        and signal_series
        and signal_series[-1] is not None
        and macd_indices[-1] == len(closes) - 1
    )
    macd_line = macd_values[-1] if macd_ready else 0.0
    macd_signal = float(signal_series[-1]) if macd_ready else 0.0
    values[f"{prefix}_macd_ready"] = float(macd_ready)
    values[f"{prefix}_macd_line_atr"] = macd_line / atr if macd_ready else 0.0
    values[f"{prefix}_macd_signal_atr"] = macd_signal / atr if macd_ready else 0.0
    values[f"{prefix}_macd_hist_atr"] = (
        (macd_line - macd_signal) / atr if macd_ready else 0.0
    )

    # Bollinger 20,2: location and compression/expansion context.
    bb_ready = len(closes) >= 20
    if bb_ready:
        window = closes[-20:]
        middle = mean(window)
        sigma = _std_population(window)
        upper = middle + 2.0 * sigma
        lower = middle - 2.0 * sigma
        width = upper - lower
        percent_b = _safe_div(last - lower, width) if width > 1e-15 else 0.5
        zscore = _safe_div(last - middle, sigma) if sigma > 1e-15 else 0.0
        bandwidth = _safe_div(width, middle)
    else:
        percent_b = zscore = bandwidth = 0.0
    values[f"{prefix}_bb20_ready"] = float(bb_ready)
    values[f"{prefix}_bb20_percent_b"] = percent_b
    values[f"{prefix}_bb20_zscore"] = zscore
    values[f"{prefix}_bb20_bandwidth"] = bandwidth

    # Donchian 20 and 55: breakout/location context.
    for period in (20, 55):
        ready = len(candles) >= period and atr_ready
        if ready:
            recent = candles[-period:]
            high = max(float(c.high) for c in recent)
            low = min(float(c.low) for c in recent)
            width = high - low
            position = _safe_div(last - low, width) if width > 1e-15 else 0.5
            upper_dist = (high - last) / atr
            lower_dist = (last - low) / atr
            range_atr = width / atr
        else:
            position = upper_dist = lower_dist = range_atr = 0.0
        values[f"{prefix}_donchian{period}_ready"] = float(ready)
        values[f"{prefix}_donchian{period}_position"] = position
        values[f"{prefix}_donchian{period}_upper_dist_atr"] = upper_dist
        values[f"{prefix}_donchian{period}_lower_dist_atr"] = lower_dist
        values[f"{prefix}_donchian{period}_range_atr"] = range_atr

    # Fibonacci retracement levels over a causal 55-bar range. These are neutral
    # price-location features; no OTE win-rate or directional claim is encoded.
    fib_ready = len(candles) >= 55 and atr_ready
    if fib_ready:
        recent = candles[-55:]
        high = max(float(c.high) for c in recent)
        low = min(float(c.low) for c in recent)
        range_value = max(high - low, 0.0)
        values[f"{prefix}_fib55_range_atr"] = range_value / atr
        nearest = None
        for ratio in (0.5, 0.618, 0.786):
            level = low + ratio * range_value
            dist = (last - level) / atr
            key = str(ratio).replace(".", "_")
            values[f"{prefix}_fib55_{key}_dist_atr"] = dist
            absolute = abs(dist)
            nearest = absolute if nearest is None else min(nearest, absolute)
        values[f"{prefix}_fib55_nearest_abs_dist_atr"] = float(nearest or 0.0)
    else:
        values[f"{prefix}_fib55_range_atr"] = 0.0
        for key in ("0_5", "0_618", "0_786"):
            values[f"{prefix}_fib55_{key}_dist_atr"] = 0.0
        values[f"{prefix}_fib55_nearest_abs_dist_atr"] = 0.0
    values[f"{prefix}_fib55_ready"] = float(fib_ready)

    return values
