from __future__ import annotations

from typing import Mapping, Sequence

from .anchored_price import DEFAULT_ANCHORED_PRICE_CONFIG, AnchoredPriceConfig
from .dataset import Candle
from .features import FeatureVector, timeframe_features
from .indicator_universe import (
    BROKER_TICK_VOLUME_PROVENANCE,
    INDICATOR_FAMILY_IDS,
    INDICATOR_WARMUP_BARS,
    IndicatorUniverseSnapshot,
    compute_indicator_universe_at,
)
from .kaufman import DEFAULT_KAUFMAN_CONFIG, KaufmanConfig, kaufman_feature_block
from .market_structure import (
    DEFAULT_MARKET_STRUCTURE_CONFIG,
    MarketStructureConfig,
    wilder_atr,
)
from .mtf import MTFContext, build_mtf_context
from .sampled_quotes import SampledQuoteFeatureBlock
from .session_context import session_features
from .video_context import (
    DEFAULT_VIDEO_CONTEXT_CONFIG,
    VideoContextConfig,
    video_method_feature_block,
)


ALL_INDICATOR_STACK_VERSION = "TRADING_AI_ALL_INDICATORS_V1"

# Top-10 needs 250 closed bars.  The ordinary MTF context deliberately uses
# shorter lookbacks, so an all-indicator experiment must request a dedicated
# longer context rather than silently marking higher timeframes unavailable.
ALL_INDICATOR_MTF_LOOKBACKS: Mapping[str, int] = {
    "M1": 400,   # also covers the 2/4/5/6h timing-hypothesis block
    "M5": 320,
    "M15": 320,
    "M30": 320,
    "H1": 320,
}

# Stable key contracts for the Council-reviewed Top-10 indicator universe. A
# missing family keeps the same schema with ready=0 and zero values, so model
# input shape never changes merely because one data source is unavailable.
INDICATOR_FAMILY_FEATURE_KEYS: Mapping[str, tuple[str, ...]] = {
    "F01_EMA_TREND_STRUCTURE": (
        "ema8_distance",
        "ema21_distance",
        "ema55_distance",
        "ema8_21_spread",
        "ema21_55_spread",
        "ema8_slope",
        "ema21_slope",
        "ema55_slope",
    ),
    "F02_MACD_PPO": ("ppo", "ppo_signal", "ppo_histogram"),
    "F03_WILDER_RSI": ("rsi7", "rsi14", "rsi14_delta"),
    "F04_STOCHASTIC": ("stochastic_k14", "stochastic_d3"),
    "F05_CCI": ("cci20",),
    "F06_ADX_DMI": ("adx14", "plus_di14", "minus_di14"),
    "F07_ATR_REALIZED_VOLATILITY": (
        "atr14_fraction",
        "realized_vol20",
        "realized_vol60",
        "realized_vol_ratio20_60",
    ),
    "F08_BOLLINGER_KELTNER": (
        "bollinger_z20",
        "bollinger_width20",
        "keltner_width20",
        "compression_ratio",
        "squeeze_on",
    ),
    "F09_DONCHIAN": (
        "prior_high20",
        "prior_low20",
        "channel_position20",
        "signed_breakout_distance20",
        "prior_high55",
        "prior_low55",
        "channel_position55",
        "signed_breakout_distance55",
    ),
    "F10_SESSION_VWAP_VOLUME_FLOW": (
        "broker_tick_volume_session_vwap_distance",
        "broker_tick_volume_obv_normalized",
        "broker_tick_volume_cmf20",
        "broker_tick_volume_mfi20",
    ),
}

# These are analysis roles, not trading commands. They let later explainability
# and mixture-of-experts experiments ask which type of evidence contributed while
# still feeding all available indicators to the model simultaneously.
INDICATOR_ROLE_MAP: Mapping[str, tuple[str, ...]] = {
    "TREND": (
        "BASE_RETURNS_MTF",
        "F01_EMA_TREND_STRUCTURE",
        "F02_MACD_PPO",
        "F06_ADX_DMI",
        "KAUFMAN_ER_KAMA",
    ),
    "MOMENTUM_MEAN_REVERSION": (
        "F03_WILDER_RSI",
        "F04_STOCHASTIC",
        "F05_CCI",
        "F08_BOLLINGER_KELTNER",
        "FIBONACCI_OTE",
    ),
    "VOLATILITY": (
        "ATR_STRUCTURE",
        "F07_ATR_REALIZED_VOLATILITY",
        "F08_BOLLINGER_KELTNER",
    ),
    "STRUCTURE_BREAKOUT": (
        "ATR_STRUCTURE",
        "F09_DONCHIAN",
        "OPENING_RANGE",
    ),
    "ANCHORED_LEVELS": ("ANCHORED_PRICE", "FIBONACCI_OTE"),
    "VOLUME_PROXY": ("F10_SESSION_VWAP_VOLUME_FLOW", "TIME_AT_PRICE_PROXY"),
    "SESSION_TIME": ("SESSION_CONTEXT", "OPENING_RANGE", "TIMING_HYPOTHESIS"),
    "MICROSTRUCTURE": ("SAMPLED_BID_ASK",),
}


def _family_slug(family_id: str) -> str:
    return family_id.lower()


def flatten_indicator_snapshot(
    snapshot: IndicatorUniverseSnapshot,
    *,
    prefix: str,
) -> dict[str, float]:
    """Flatten all Top-10 families into one stable simultaneous model schema."""

    by_family = snapshot.by_family()
    values: dict[str, float] = {}
    for family_id in INDICATOR_FAMILY_IDS:
        family = by_family[family_id]
        slug = _family_slug(family_id)
        values[f"{prefix}_{slug}_ready"] = float(family.available)
        observed = family.as_dict() if family.available else {}
        for key in INDICATOR_FAMILY_FEATURE_KEYS[family_id]:
            values[f"{prefix}_{slug}_{key}"] = float(observed.get(key, 0.0))
    return values


def build_all_indicator_mtf_context(
    m1_candles: Sequence[Candle],
    *,
    end_timestamp_ms: int,
    lookbacks: Mapping[str, int] | None = None,
    require_top10_ready: bool = True,
) -> MTFContext:
    """Build the longer causal MTF context required by the all-indicator trial."""

    requested = dict(lookbacks or ALL_INDICATOR_MTF_LOOKBACKS)
    context = build_mtf_context(
        m1_candles,
        end_timestamp_ms=end_timestamp_ms,
        lookbacks=requested,
    )
    if require_top10_ready:
        short = {
            timeframe: len(candles)
            for timeframe, candles in context.candles_by_timeframe.items()
            if len(candles) < INDICATOR_WARMUP_BARS
        }
        if short:
            details = ", ".join(f"{tf}={count}" for tf, count in sorted(short.items()))
            raise ValueError(
                f"all-indicator context requires >= {INDICATOR_WARMUP_BARS} closed bars per timeframe; {details}"
            )
    return context


def timeframe_all_indicator_features(
    candles: Sequence[Candle],
    *,
    prefix: str,
    volume_provenance: str | None = None,
    market_structure_config: MarketStructureConfig = DEFAULT_MARKET_STRUCTURE_CONFIG,
    anchored_price_config: AnchoredPriceConfig = DEFAULT_ANCHORED_PRICE_CONFIG,
    kaufman_config: KaufmanConfig = DEFAULT_KAUFMAN_CONFIG,
) -> dict[str, float]:
    """Compute every currently supported candle-derived family at once.

    This is deliberately an all-in research stack. It does not vote indicator
    signals and does not emit BUY/SELL. The model receives all numerical context
    simultaneously and later OOS ablation decides which families add value.
    """

    rows = tuple(candles)
    values = timeframe_features(
        rows,
        prefix=prefix,
        market_structure_config=market_structure_config,
        anchored_price_config=anchored_price_config,
    )
    atr_value = wilder_atr(rows, period=market_structure_config.atr_period) if rows else 0.0
    values.update(
        kaufman_feature_block(
            rows,
            prefix=prefix,
            atr_value=atr_value,
            config=kaufman_config,
        )
    )
    snapshot = compute_indicator_universe_at(
        rows,
        volume_provenance=volume_provenance,
    )
    values.update(flatten_indicator_snapshot(snapshot, prefix=prefix))
    return values


def build_all_indicator_feature_vector(
    context: MTFContext,
    *,
    volume_provenance_by_timeframe: Mapping[str, str | None] | None = None,
    sampled_quote_block: SampledQuoteFeatureBlock | None = None,
    market_structure_config: MarketStructureConfig = DEFAULT_MARKET_STRUCTURE_CONFIG,
    anchored_price_config: AnchoredPriceConfig = DEFAULT_ANCHORED_PRICE_CONFIG,
    kaufman_config: KaufmanConfig = DEFAULT_KAUFMAN_CONFIG,
    video_context_config: VideoContextConfig = DEFAULT_VIDEO_CONTEXT_CONFIG,
) -> FeatureVector:
    """Build the simultaneous all-indicator MTF research vector.

    Candle-derived families are calculated independently for every timeframe in
    the supplied context. Video-method features that are inherently minute/session
    based are calculated once from M1. Sampled BID/ASK predictors are appended
    only when their separate quality contract marks them ready. True Footprint,
    CVD, OFI, real Volume Profile and L2 heatmap remain absent because current
    data cannot honestly support those semantics.
    """

    provenance = dict(volume_provenance_by_timeframe or {})
    values: dict[str, float] = {}
    for timeframe, candles in context.candles_by_timeframe.items():
        prefix = timeframe.lower()
        values.update(
            timeframe_all_indicator_features(
                candles,
                prefix=prefix,
                volume_provenance=provenance.get(timeframe),
                market_structure_config=market_structure_config,
                anchored_price_config=anchored_price_config,
                kaufman_config=kaufman_config,
            )
        )

    directional = []
    for tf in ("M1", "M5", "M15", "M30", "H1"):
        key = f"{tf.lower()}_ret_3"
        if key in values:
            directional.append(1.0 if values[key] > 0 else -1.0 if values[key] < 0 else 0.0)
    values["mtf_direction_agreement"] = sum(directional) / len(directional) if directional else 0.0
    values.update(session_features(context.end_timestamp_ms))

    m1 = context.candles_by_timeframe.get("M1", ())
    if m1:
        m1_atr = wilder_atr(m1, period=market_structure_config.atr_period)
        values.update(
            video_method_feature_block(
                m1,
                atr_value=m1_atr,
                end_timestamp_ms=context.end_timestamp_ms,
                config=video_context_config,
            )
        )

    # Quote quality remains a gate, not a predictor. Only readiness flags plus
    # the explicitly approved predictor dictionary can enter the model vector.
    if sampled_quote_block is not None:
        values["sampled_quote_ready"] = float(sampled_quote_block.quote_ready)
        values["sampled_quote_atr_ready"] = float(sampled_quote_block.atr_ready)
        values.update(sampled_quote_block.predictors)
    else:
        values["sampled_quote_ready"] = 0.0
        values["sampled_quote_atr_ready"] = 0.0

    return FeatureVector(end_timestamp_ms=context.end_timestamp_ms, values=values)


__all__ = [
    "ALL_INDICATOR_STACK_VERSION",
    "ALL_INDICATOR_MTF_LOOKBACKS",
    "BROKER_TICK_VOLUME_PROVENANCE",
    "INDICATOR_FAMILY_FEATURE_KEYS",
    "INDICATOR_ROLE_MAP",
    "flatten_indicator_snapshot",
    "build_all_indicator_mtf_context",
    "timeframe_all_indicator_features",
    "build_all_indicator_feature_vector",
]
