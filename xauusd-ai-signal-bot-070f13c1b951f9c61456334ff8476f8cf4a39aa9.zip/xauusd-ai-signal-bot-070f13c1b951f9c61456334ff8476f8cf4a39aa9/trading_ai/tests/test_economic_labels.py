from __future__ import annotations

import math

import pytest

from trading_ai.economic_labels import (
    ActionUtilities,
    EconomicCostSpec,
    EconomicLabel,
    ExecutableQuote,
    choose_economic_label,
    label_from_executable_quotes,
    round_trip_utilities,
)


def test_wait_beats_less_bad_buy_and_sell():
    decision = label_from_executable_quotes(
        ExecutableQuote(bid=99.90, ask=100.10),
        ExecutableQuote(bid=99.95, ask=100.15),
    )
    assert decision.utilities is not None
    assert decision.utilities.buy == pytest.approx(-0.15)
    assert decision.utilities.sell == pytest.approx(-0.25)
    assert decision.utilities.wait == 0.0
    assert decision.label is EconomicLabel.WAIT


def test_wait_utility_is_invariant_zero_and_nonzero_override_is_rejected():
    assert choose_economic_label(ActionUtilities(buy=0.2, sell=-0.1, wait=0.0)).label is EconomicLabel.BUY
    with pytest.raises(ValueError, match="WAIT utility is invariant"):
        choose_economic_label(ActionUtilities(buy=0.2, sell=-0.1, wait=0.01))
    with pytest.raises(ValueError, match="WAIT utility is invariant"):
        choose_economic_label(ActionUtilities(buy=0.2, sell=-0.1, wait=-0.01))


def test_long_uses_entry_ask_and_exit_bid_without_extra_spread_subtraction():
    utilities = round_trip_utilities(
        ExecutableQuote(bid=100.00, ask=100.10),
        ExecutableQuote(bid=100.40, ask=100.50),
    )
    assert utilities.buy == pytest.approx(0.30)
    assert utilities.sell == pytest.approx(-0.50)


def test_short_uses_entry_bid_and_exit_ask_without_extra_spread_subtraction():
    utilities = round_trip_utilities(
        ExecutableQuote(bid=100.00, ask=100.10),
        ExecutableQuote(bid=99.40, ask=99.50),
    )
    assert utilities.buy == pytest.approx(-0.70)
    assert utilities.sell == pytest.approx(0.50)


def test_zero_spread_quote_is_valid():
    decision = label_from_executable_quotes(
        ExecutableQuote(bid=100.0, ask=100.0),
        ExecutableQuote(bid=100.2, ask=100.2),
    )
    assert decision.label is EconomicLabel.BUY
    assert decision.utilities is not None
    assert decision.utilities.buy == pytest.approx(0.2)


def test_slippage_and_commission_are_counted_once_per_side():
    costs = EconomicCostSpec(
        quantity=2.0,
        entry_slippage_price=0.02,
        exit_slippage_price=0.03,
        commission_per_unit_per_side=0.01,
    )
    utilities = round_trip_utilities(
        ExecutableQuote(bid=100.00, ask=100.10),
        ExecutableQuote(bid=100.40, ask=100.50),
        costs=costs,
    )
    # LONG price PnL = (100.40-0.03) - (100.10+0.02) = 0.25.
    # quantity=2 => 0.50; commission=2 sides*0.01*2 units=0.04 => 0.46.
    assert utilities.buy == pytest.approx(0.46)


def test_slippage_penalizes_long_and_short_equally_in_price_units():
    entry = ExecutableQuote(100.0, 100.0)
    exit_ = ExecutableQuote(101.0, 101.0)
    clean = round_trip_utilities(entry, exit_)
    slipped = round_trip_utilities(
        entry,
        exit_,
        costs=EconomicCostSpec(entry_slippage_price=0.01, exit_slippage_price=0.02),
    )
    assert clean.buy - slipped.buy == pytest.approx(0.03)
    assert clean.sell - slipped.sell == pytest.approx(0.03)


def test_quantity_scales_price_pnl_and_per_unit_commission_consistently():
    one = round_trip_utilities(
        ExecutableQuote(100.00, 100.10),
        ExecutableQuote(100.40, 100.50),
        costs=EconomicCostSpec(quantity=1.0, commission_per_unit_per_side=0.01),
    )
    three = round_trip_utilities(
        ExecutableQuote(100.00, 100.10),
        ExecutableQuote(100.40, 100.50),
        costs=EconomicCostSpec(quantity=3.0, commission_per_unit_per_side=0.01),
    )
    assert three.buy == pytest.approx(one.buy * 3.0)
    assert three.sell == pytest.approx(one.sell * 3.0)


def test_min_net_utility_is_strict_and_can_force_wait():
    utilities = ActionUtilities(buy=0.20, sell=-0.30)
    assert choose_economic_label(utilities, min_net_utility=0.20).label is EconomicLabel.WAIT
    assert choose_economic_label(utilities, min_net_utility=0.19).label is EconomicLabel.BUY


def test_both_directions_negative_even_when_unequal_are_wait():
    decision = choose_economic_label(ActionUtilities(buy=-0.01, sell=-0.50))
    assert decision.label is EconomicLabel.WAIT


def test_tie_epsilon_is_inclusive_at_boundary():
    epsilon = 0.02
    assert choose_economic_label(
        ActionUtilities(buy=1.0, sell=1.0 + epsilon), tie_epsilon=epsilon
    ).label is EconomicLabel.WAIT
    assert choose_economic_label(
        ActionUtilities(buy=1.0, sell=1.0 + epsilon + 1e-9), tie_epsilon=epsilon
    ).label is EconomicLabel.SELL


def test_tie_epsilon_precedes_action_margin_by_contract():
    # Both directional utilities are positive and within the tie band. The
    # decision remains WAIT even if the action-margin threshold is smaller.
    decision = choose_economic_label(
        ActionUtilities(buy=0.20, sell=0.21),
        tie_epsilon=0.02,
        min_action_margin=0.005,
    )
    assert decision.label is EconomicLabel.WAIT
    assert decision.reason == "directional_tie_within_epsilon"


def test_action_margin_is_strict_and_compares_against_wait():
    utilities = ActionUtilities(buy=0.05, sell=-1.0)
    assert choose_economic_label(utilities, min_action_margin=0.05).label is EconomicLabel.WAIT
    assert choose_economic_label(utilities, min_action_margin=0.049).label is EconomicLabel.BUY


def test_missing_nonfinite_bool_or_crossed_quote_is_unavailable_not_wait():
    valid_exit = ExecutableQuote(100.2, 100.3)
    assert label_from_executable_quotes(None, valid_exit).label is EconomicLabel.UNAVAILABLE
    assert label_from_executable_quotes(ExecutableQuote(float("nan"), 100.1), valid_exit).label is EconomicLabel.UNAVAILABLE
    assert label_from_executable_quotes(ExecutableQuote(100.0, float("inf")), valid_exit).label is EconomicLabel.UNAVAILABLE
    assert label_from_executable_quotes(ExecutableQuote(True, 100.1), valid_exit).label is EconomicLabel.UNAVAILABLE
    assert label_from_executable_quotes(ExecutableQuote(100.2, 100.1), valid_exit).label is EconomicLabel.UNAVAILABLE


def test_non_scalar_or_bool_costs_are_rejected():
    with pytest.raises(TypeError):
        round_trip_utilities(
            ExecutableQuote(100.0, 100.1),
            ExecutableQuote(100.2, 100.3),
            costs=EconomicCostSpec(entry_slippage_price=True),
        )
    with pytest.raises(TypeError):
        round_trip_utilities(
            ExecutableQuote(100.0, 100.1),
            ExecutableQuote(100.2, 100.3),
            costs=EconomicCostSpec(entry_slippage_price=[0.01]),
        )


def test_invalid_cost_contract_fails_closed():
    with pytest.raises(ValueError):
        round_trip_utilities(
            ExecutableQuote(100.0, 100.1),
            ExecutableQuote(100.2, 100.3),
            costs=EconomicCostSpec(quantity=0.0),
        )
    with pytest.raises(ValueError):
        round_trip_utilities(
            ExecutableQuote(100.0, 100.1),
            ExecutableQuote(100.2, 100.3),
            costs=EconomicCostSpec(quantity=-1.0),
        )
    with pytest.raises(ValueError):
        round_trip_utilities(
            ExecutableQuote(100.0, 100.1),
            ExecutableQuote(100.2, 100.3),
            costs=EconomicCostSpec(entry_slippage_price=float("nan")),
        )
    with pytest.raises(ValueError):
        choose_economic_label(ActionUtilities(0.1, -0.1), min_action_margin=-0.01)
    with pytest.raises(ValueError):
        choose_economic_label(ActionUtilities(math.inf, -0.1))
