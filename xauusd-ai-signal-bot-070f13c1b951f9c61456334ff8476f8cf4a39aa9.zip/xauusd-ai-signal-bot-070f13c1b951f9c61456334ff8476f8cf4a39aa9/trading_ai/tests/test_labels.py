from __future__ import annotations

import unittest

from trading_ai.labels import DirectionLabel, label_direction
from trading_ai.pipeline import TrainingSample


MINUTE = 60_000


def sample(ts: int, ret: float, *, horizon: int = 1) -> TrainingSample:
    return TrainingSample(
        end_timestamp_ms=ts,
        features={"x": float(ts)},
        future_returns={horizon: ret},
        max_favorable_move={horizon: max(ret, 0.0)},
        max_adverse_move={horizon: min(ret, 0.0)},
    )


class LabelTests(unittest.TestCase):
    def test_direction_labels(self):
        samples = [sample(MINUTE, 0.0001), sample(2 * MINUTE, -0.0002), sample(3 * MINUTE, 0.0)]
        labeled = label_direction(samples, horizons=(1,), minimum_return=0.00002, volatility_multiplier=0.0)
        self.assertEqual(labeled[0].labels[1], DirectionLabel.BUY)
        self.assertEqual(labeled[1].labels[1], DirectionLabel.SELL)
        self.assertEqual(labeled[2].labels[1], DirectionLabel.WAIT)

    def test_default_horizons_include_30_and_60_minutes(self):
        horizons = (1, 3, 5, 10, 15, 30, 60)
        returns = {h: 0.0001 for h in horizons}
        row = TrainingSample(
            end_timestamp_ms=MINUTE,
            features={"x": 1.0},
            future_returns=returns,
            max_favorable_move=returns,
            max_adverse_move={h: 0.0 for h in horizons},
        )
        labeled = label_direction([row], minimum_return=0.0, volatility_multiplier=0.0)
        self.assertEqual(set(labeled[0].labels), set(horizons))

    def test_current_future_return_does_not_change_its_threshold(self):
        prior = [sample((i + 1) * MINUTE, 0.0001 if i % 2 == 0 else -0.0001) for i in range(20)]
        current_ts = 30 * MINUTE
        a = prior + [sample(current_ts, 0.0003)]
        b = prior + [sample(current_ts, 0.03)]
        la = label_direction(a, horizons=(1,), minimum_return=0.0, volatility_multiplier=0.5)
        lb = label_direction(b, horizons=(1,), minimum_return=0.0, volatility_multiplier=0.5)
        self.assertAlmostEqual(la[-1].thresholds[1], lb[-1].thresholds[1], places=12)

    def test_unresolved_prior_horizon_is_not_used_by_bar_count(self):
        h = 15
        # Horizon h means h future candles, not h wall-clock minutes. At sample
        # index 15 only index 0 has matured (0 + 15 <= 15). Indexes 1..14 are
        # still unresolved regardless of how much wall-clock time has elapsed.
        samples = [sample(1 * MINUTE, 0.0010, horizon=h)]
        samples.extend(sample((i + 1) * MINUTE, 0.1000, horizon=h) for i in range(1, 15))
        # Simulate a weekend / long data gap before the current candle. The old
        # timestamp+h-minutes implementation would incorrectly treat all prior
        # outcomes as known here and leak future information into the threshold.
        samples.append(sample(3 * 24 * 60 * MINUTE, 0.0020, horizon=h))

        labeled = label_direction(
            samples,
            horizons=(h,),
            minimum_return=0.0,
            volatility_multiplier=1.0,
            volatility_lookback=240,
        )
        self.assertAlmostEqual(labeled[-1].thresholds[h], 0.0010, places=12)

    def test_no_prior_horizon_is_used_before_enough_future_bars_exist(self):
        h = 5
        samples = [sample((i + 1) * MINUTE, 0.0500, horizon=h) for i in range(5)]
        labeled = label_direction(
            samples,
            horizons=(h,),
            minimum_return=0.0,
            volatility_multiplier=1.0,
        )
        self.assertAlmostEqual(labeled[-1].thresholds[h], 0.0, places=12)


if __name__ == "__main__":
    unittest.main()
