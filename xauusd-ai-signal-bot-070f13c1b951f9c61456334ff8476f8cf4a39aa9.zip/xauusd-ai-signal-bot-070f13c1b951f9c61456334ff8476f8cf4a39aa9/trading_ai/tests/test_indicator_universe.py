from datetime import datetime, timezone

import pytest

from trading_ai.dataset import Candle
from trading_ai.indicator_universe import (
    BROKER_TICK_VOLUME_PROVENANCE,
    INDICATOR_FAMILY_IDS,
    INDICATOR_WARMUP_BARS,
    _true_ranges,
    compute_indicator_universe_at,
)


def _candles(count=320, *, start_ms=None):
    start = start_ms or int(datetime(2026, 1, 5, 0, 0, tzinfo=timezone.utc).timestamp() * 1000)
    rows = []
    for index in range(count):
        close = 2600.0 + index * 0.1
        rows.append(
            Candle(
                timestamp_ms=start + index * 60_000,
                open=close - 0.02,
                high=close + 0.20,
                low=close - 0.20,
                close=close,
                volume=100.0 + index % 7,
            )
        )
    return rows


def test_top10_is_complete_finite_and_shadow_only():
    snapshot = compute_indicator_universe_at(
        _candles(), volume_provenance=BROKER_TICK_VOLUME_PROVENANCE
    )
    assert tuple(family.family_id for family in snapshot.families) == INDICATOR_FAMILY_IDS
    assert all(family.available for family in snapshot.families)
    assert snapshot.research_only is True
    assert snapshot.execution_allowed is False
    assert snapshot.by_family()["F03_WILDER_RSI"].as_dict()["rsi14"] == pytest.approx(100.0)
    assert snapshot.by_family()["F04_STOCHASTIC"].as_dict()["stochastic_k14"] <= 100.0


def test_cutoff_is_prefix_invariant():
    rows = _candles(330)
    prefix = compute_indicator_universe_at(
        rows[:300], volume_provenance=BROKER_TICK_VOLUME_PROVENANCE
    )
    cutoff = compute_indicator_universe_at(
        rows,
        cutoff_timestamp_ms=rows[299].timestamp_ms,
        volume_provenance=BROKER_TICK_VOLUME_PROVENANCE,
    )
    assert cutoff == prefix


def test_warmup_and_volume_provenance_fail_closed():
    short = compute_indicator_universe_at(_candles(INDICATOR_WARMUP_BARS - 1))
    assert all(not family.available for family in short.families)
    assert {family.missing_reason for family in short.families} == {"INSUFFICIENT_250_BAR_WARMUP"}

    snapshot = compute_indicator_universe_at(_candles())
    volume = snapshot.by_family()["F10_SESSION_VWAP_VOLUME_FLOW"]
    assert volume.available is False
    assert volume.values == ()
    assert volume.missing_reason == "BROKER_TICK_VOLUME_PROVENANCE_REQUIRED"


def test_donchian_prior_boundary_excludes_current_candle():
    rows = _candles()
    previous = rows[-1]
    rows[-1] = Candle(
        timestamp_ms=previous.timestamp_ms,
        open=2700.0,
        high=3000.0,
        low=2500.0,
        close=2900.0,
        volume=previous.volume,
    )
    expected_prior_high = max(row.high for row in rows[-21:-1])
    expected_prior_low = min(row.low for row in rows[-21:-1])
    values = compute_indicator_universe_at(
        rows, volume_provenance=BROKER_TICK_VOLUME_PROVENANCE
    ).by_family()["F09_DONCHIAN"].as_dict()
    assert values["prior_high20"] == expected_prior_high
    assert values["prior_low20"] == expected_prior_low
    assert values["signed_breakout_distance20"] > 0.0


def test_session_vwap_resets_at_midnight_utc():
    start = int(datetime(2026, 1, 4, 19, 30, tzinfo=timezone.utc).timestamp() * 1000)
    rows = _candles(300, start_ms=start)
    values = compute_indicator_universe_at(
        rows, volume_provenance=BROKER_TICK_VOLUME_PROVENANCE
    ).by_family()["F10_SESSION_VWAP_VOLUME_FLOW"].as_dict()
    same_day = [row for row in rows if datetime.fromtimestamp(row.timestamp_ms / 1000, tz=timezone.utc).date() == datetime(2026, 1, 5, tzinfo=timezone.utc).date()]
    expected_vwap = sum(((row.high + row.low + row.close) / 3) * row.volume for row in same_day) / sum(row.volume for row in same_day)
    assert values["broker_tick_volume_session_vwap_distance"] == pytest.approx(
        (rows[-1].close - expected_vwap) / rows[-1].close
    )


def test_flat_known_value_fixture_covers_every_indicator_family():
    start = int(datetime(2026, 2, 2, 0, 0, tzinfo=timezone.utc).timestamp() * 1000)
    rows = [
        Candle(start + index * 60_000, 2600.0, 2601.0, 2599.0, 2600.0, 100.0)
        for index in range(300)
    ]
    families = compute_indicator_universe_at(
        rows, volume_provenance=BROKER_TICK_VOLUME_PROVENANCE
    ).by_family()
    assert families["F01_EMA_TREND_STRUCTURE"].as_dict() == {
        "ema8_distance": 0.0,
        "ema21_distance": 0.0,
        "ema55_distance": 0.0,
        "ema8_21_spread": 0.0,
        "ema21_55_spread": 0.0,
        "ema8_slope": 0.0,
        "ema21_slope": 0.0,
        "ema55_slope": 0.0,
    }
    assert families["F02_MACD_PPO"].as_dict() == {
        "ppo": 0.0,
        "ppo_signal": 0.0,
        "ppo_histogram": 0.0,
    }
    assert families["F03_WILDER_RSI"].as_dict() == {
        "rsi7": 50.0,
        "rsi14": 50.0,
        "rsi14_delta": 0.0,
    }
    assert families["F04_STOCHASTIC"].as_dict() == {
        "stochastic_k14": 50.0,
        "stochastic_d3": 50.0,
    }
    assert families["F05_CCI"].as_dict() == {"cci20": 0.0}
    assert families["F06_ADX_DMI"].as_dict() == {"adx14": 0.0, "plus_di14": 0.0, "minus_di14": 0.0}
    assert families["F07_ATR_REALIZED_VOLATILITY"].as_dict() == {
        "atr14_fraction": pytest.approx(2.0 / 2600.0),
        "realized_vol20": 0.0,
        "realized_vol60": 0.0,
        "realized_vol_ratio20_60": 0.0,
    }
    compression = families["F08_BOLLINGER_KELTNER"].as_dict()
    assert compression["bollinger_z20"] == 0.0
    assert compression["bollinger_width20"] == 0.0
    assert compression["keltner_width20"] == pytest.approx(8.0 / 2600.0)
    assert compression["compression_ratio"] == 0.0
    assert compression["squeeze_on"] == 1.0
    donchian = families["F09_DONCHIAN"].as_dict()
    assert donchian["channel_position20"] == 0.5
    assert donchian["channel_position55"] == 0.5
    assert donchian["signed_breakout_distance20"] == 0.0
    assert donchian["signed_breakout_distance55"] == 0.0
    volume = families["F10_SESSION_VWAP_VOLUME_FLOW"].as_dict()
    assert volume == {
        "broker_tick_volume_session_vwap_distance": 0.0,
        "broker_tick_volume_obv_normalized": 0.0,
        "broker_tick_volume_cmf20": 0.0,
        "broker_tick_volume_mfi20": 50.0,
    }
    assert all(key.startswith("broker_tick_volume_") for key in volume)


def test_true_range_uses_previous_close_and_bad_timestamps_fail_closed():
    rows = (
        Candle(1, 100.0, 101.0, 99.0, 100.0, 1.0),
        Candle(2, 110.0, 111.0, 109.0, 110.0, 1.0),
        Candle(3, 109.0, 112.0, 108.0, 111.0, 1.0),
    )
    assert _true_ranges(rows) == [2.0, 11.0, 4.0]
    with pytest.raises(ValueError, match="strictly increasing"):
        compute_indicator_universe_at((rows[0], rows[0]))
    with pytest.raises(ValueError, match="finite and positive"):
        prefix = _candles(250)[:-1]
        bad = Candle(prefix[-1].timestamp_ms + 60_000, 100.0, float("inf"), 99.0, 100.0, 1.0)
        compute_indicator_universe_at(tuple(prefix) + (bad,))
