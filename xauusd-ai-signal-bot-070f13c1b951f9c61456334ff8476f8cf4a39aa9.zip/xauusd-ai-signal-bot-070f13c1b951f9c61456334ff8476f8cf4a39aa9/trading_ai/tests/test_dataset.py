import unittest

from trading_ai.dataset import Candle, build_training_windows


class DatasetWindowTests(unittest.TestCase):
    def test_feature_window_never_contains_future_label_candles(self):
        candles = []
        base = 1_700_000_000_000
        price = 2000.0
        for i in range(30):
            close = price + i
            candles.append(
                Candle(
                    timestamp_ms=base + i * 60_000,
                    open=close - 0.25,
                    high=close + 0.75,
                    low=close - 0.75,
                    close=close,
                    volume=100 + i,
                )
            )

        windows = build_training_windows(candles, lookback=5, horizons=(1, 3, 5))
        self.assertTrue(windows)
        for window in windows:
            self.assertEqual(len(window.candles), 5)
            self.assertEqual(window.candles[-1].timestamp_ms, window.end_timestamp_ms)
            self.assertEqual(set(window.future_returns), {1, 3, 5})

    def test_short_history_returns_no_windows(self):
        candles = [
            Candle(1_700_000_000_000 + i * 60_000, 1, 2, 0.5, 1.5, 1)
            for i in range(5)
        ]
        self.assertEqual(build_training_windows(candles, lookback=5, horizons=(5,)), [])


if __name__ == "__main__":
    unittest.main()
