from __future__ import annotations

import math

import pytest

from trading_ai.anchored_price import (
    MODEL_FEATURE_BASES,
    AnchoredPriceConfig,
    AnchoredPriceStatus,
    PriceBasis,
    VolumeSemantics,
    WeightingMode,
    anchored_price_feature_block,
    anchored_price_result,
)
from trading_ai.dataset import Candle, validate_candles
from trading_ai.features import FEATURE_VECTOR_VERSION, build_feature_vector, timeframe_features
from trading_ai.mtf import MTFContext


MINUTE = 60_000


def candle(i: int, price: float, *, volume: float = 1.0, spread: float = 1.0) -> Candle:
    return Candle(
        timestamp_ms=(i + 1) * MINUTE,
        open=price,
        high=price + spread,
        low=price - spread,
        close=price,
        volume=volume,
    )


def flat_candle(i: int, price: float, *, volume: float = 1.0) -> Candle:
    return Candle(
        timestamp_ms=(i + 1) * MINUTE,
        open=price,
        high=price,
        low=price,
        close=price,
        volume=volume,
    )


def time_cfg(*, window: int = 20, basis: PriceBasis = PriceBasis.TYPICAL_HLC3) -> AnchoredPriceConfig:
    return AnchoredPriceConfig(
        weighting=WeightingMode.TIME_WEIGHTED,
        volume_semantics=VolumeSemantics.UNKNOWN,
        price_basis=basis,
        window_bars=window,
    )


def tick_cfg(*, window: int = 20) -> AnchoredPriceConfig:
    return AnchoredPriceConfig(
        weighting=WeightingMode.CANDLE_VOLUME,
        volume_semantics=VolumeSemantics.TICK_COUNT,
        price_basis=PriceBasis.TYPICAL_HLC3,
        window_bars=window,
    )


def trade_cfg(*, window: int = 20) -> AnchoredPriceConfig:
    return AnchoredPriceConfig(
        weighting=WeightingMode.CANDLE_VOLUME,
        volume_semantics=VolumeSemantics.TRADE_VOLUME,
        price_basis=PriceBasis.TYPICAL_HLC3,
        window_bars=window,
    )


def unknown_volume_cfg(*, window: int = 20) -> AnchoredPriceConfig:
    return AnchoredPriceConfig(
        weighting=WeightingMode.CANDLE_VOLUME,
        volume_semantics=VolumeSemantics.UNKNOWN,
        price_basis=PriceBasis.TYPICAL_HLC3,
        window_bars=window,
    )


def expected_schema(prefix: str) -> set[str]:
    result: set[str] = set()
    for feature_base in MODEL_FEATURE_BASES:
        result.update(
            {
                f"{prefix}_{feature_base}_ready",
                f"{prefix}_{feature_base}_dist_atr",
                f"{prefix}_{feature_base}_slope_atr_per_bar",
                f"{prefix}_{feature_base}_anchor_age_bars",
            }
        )
    return result


def test_explicit_anchor_timestamp_is_included_and_must_precede_decision():
    candles = [flat_candle(0, 100.0), flat_candle(1, 110.0), flat_candle(2, 120.0)]
    validate_candles(candles)
    result = anchored_price_result(
        candles,
        atr_value=10.0,
        config=time_cfg(),
        anchor_timestamp_ms=candles[1].timestamp_ms,
    )
    assert result.status is AnchoredPriceStatus.READY
    assert result.weighted_price == pytest.approx(115.0)
    assert result.anchor_age_bars == 1

    current_anchor = anchored_price_result(
        candles,
        atr_value=10.0,
        config=time_cfg(),
        anchor_timestamp_ms=candles[-1].timestamp_ms,
    )
    assert current_anchor.status is AnchoredPriceStatus.NOT_READY
    assert current_anchor.reason == "anchor_not_available_before_decision"


def test_explicit_index_and_timestamp_anchor_match():
    candles = [flat_candle(i, 100.0 + 10.0 * i) for i in range(4)]
    by_index = anchored_price_result(candles, atr_value=5.0, config=time_cfg(), anchor_index=1)
    by_time = anchored_price_result(
        candles,
        atr_value=5.0,
        config=time_cfg(),
        anchor_timestamp_ms=candles[1].timestamp_ms,
    )
    assert by_index.status is AnchoredPriceStatus.READY
    assert by_time.status is AnchoredPriceStatus.READY
    assert by_index.weighted_price == pytest.approx(by_time.weighted_price)
    assert by_index.distance_atr == pytest.approx(by_time.distance_atr)


def test_anchor_off_by_one_rejects_current_bar_index():
    candles = [flat_candle(0, 100.0), flat_candle(1, 101.0)]
    result = anchored_price_result(candles, atr_value=1.0, config=time_cfg(), anchor_index=1)
    assert result.status is AnchoredPriceStatus.NOT_READY
    assert result.reason == "anchor_not_available_before_decision"


def test_explicit_anchor_near_series_start_is_ready_with_partial_anchor_age():
    candles = [flat_candle(0, 100.0), flat_candle(1, 110.0), flat_candle(2, 120.0)]
    result = anchored_price_result(candles, atr_value=10.0, config=time_cfg(window=20), anchor_index=0)
    assert result.status is AnchoredPriceStatus.READY
    assert result.anchor_age_bars == 2
    assert result.bars_used == 3
    assert result.weighted_price == pytest.approx(110.0)


def test_future_perturbation_after_decision_cannot_change_result():
    base = [
        flat_candle(0, 100.0),
        flat_candle(1, 101.0),
        flat_candle(2, 102.0),
        flat_candle(3, 103.0),
        flat_candle(4, 104.0),
    ]
    changed = list(base)
    changed[4] = flat_candle(4, 10_000.0, volume=999_999.0)
    decision = base[2].timestamp_ms
    a = anchored_price_result(base, atr_value=2.0, config=time_cfg(window=3), decision_timestamp_ms=decision)
    b = anchored_price_result(changed, atr_value=2.0, config=time_cfg(window=3), decision_timestamp_ms=decision)
    assert a == b


def test_decision_timestamp_discard_keeps_decision_bar_and_drops_future():
    candles = [
        flat_candle(0, 100.0),
        flat_candle(1, 110.0),
        flat_candle(2, 120.0),
        flat_candle(3, 10_000.0),
    ]
    result = anchored_price_result(
        candles,
        atr_value=10.0,
        config=time_cfg(window=3),
        decision_timestamp_ms=candles[2].timestamp_ms,
    )
    assert result.status is AnchoredPriceStatus.READY
    assert result.bars_used == 3
    assert result.weighted_price == pytest.approx(110.0)
    assert result.distance_atr == pytest.approx(1.0)


def test_decision_timestamp_must_match_an_available_closed_bar():
    candles = [flat_candle(0, 100.0), flat_candle(1, 101.0), flat_candle(2, 102.0)]
    result = anchored_price_result(
        candles,
        atr_value=1.0,
        config=time_cfg(),
        decision_timestamp_ms=candles[1].timestamp_ms + 1,
    )
    assert result.status is AnchoredPriceStatus.NOT_READY
    assert result.reason == "decision_not_available"


def test_tick_weighted_price_is_scale_invariant():
    one = [flat_candle(0, 100.0, volume=1.0), flat_candle(1, 110.0, volume=2.0), flat_candle(2, 120.0, volume=3.0)]
    ten = [flat_candle(0, 100.0, volume=10.0), flat_candle(1, 110.0, volume=20.0), flat_candle(2, 120.0, volume=30.0)]
    a = anchored_price_result(one, atr_value=10.0, config=tick_cfg(window=3))
    b = anchored_price_result(ten, atr_value=10.0, config=tick_cfg(window=3))
    assert a.status is AnchoredPriceStatus.READY
    assert b.status is AnchoredPriceStatus.READY
    assert a.weighted_price == pytest.approx(b.weighted_price)
    assert a.distance_atr == pytest.approx(b.distance_atr)
    assert a.slope_atr_per_bar == pytest.approx(b.slope_atr_per_bar)
    assert b.cumulative_weight == pytest.approx(a.cumulative_weight * 10.0)


def test_time_weighted_and_tick_weighted_modes_are_distinct_and_named_honestly():
    candles = [
        flat_candle(0, 100.0, volume=1.0),
        flat_candle(1, 110.0, volume=1.0),
        flat_candle(2, 120.0, volume=10.0),
    ]
    time_result = anchored_price_result(candles, atr_value=10.0, config=time_cfg(window=3))
    tick_result = anchored_price_result(candles, atr_value=10.0, config=tick_cfg(window=3))
    assert time_result.feature_base == "anchored_mean"
    assert tick_result.feature_base == "tick_weighted_price"
    assert "vwap" not in tick_result.feature_base
    assert time_result.weighted_price == pytest.approx(110.0)
    assert tick_result.weighted_price != pytest.approx(time_result.weighted_price)


def test_trade_volume_bar_proxy_is_not_named_vwap():
    candles = [flat_candle(0, 100.0, volume=1.0), flat_candle(1, 110.0, volume=2.0)]
    result = anchored_price_result(candles, atr_value=2.0, config=trade_cfg(window=2))
    assert result.status is AnchoredPriceStatus.READY
    assert result.feature_base == "trade_volume_weighted_bar_price"
    assert "vwap" not in result.feature_base


def test_missing_volume_semantics_is_not_ready_and_never_falls_back():
    candles = [flat_candle(0, 100.0, volume=1.0), flat_candle(1, 110.0, volume=2.0), flat_candle(2, 120.0, volume=3.0)]
    result = anchored_price_result(candles, atr_value=2.0, config=unknown_volume_cfg(window=3))
    assert result.status is AnchoredPriceStatus.NOT_READY
    assert result.reason == "missing_volume_semantics"
    assert result.feature_base == "volume_weighted_price_unknown"

    block = anchored_price_feature_block(candles, prefix="m1", atr_value=2.0, config=unknown_volume_cfg(window=3))
    assert set(block) == expected_schema("m1")
    assert all(value == 0.0 for value in block.values())


@pytest.mark.parametrize("bad", [-1.0, float("nan"), float("inf")])
def test_invalid_candle_weights_are_not_ready(bad: float):
    candles = [flat_candle(0, 100.0, volume=1.0), flat_candle(1, 110.0, volume=bad), flat_candle(2, 120.0, volume=3.0)]
    result = anchored_price_result(candles, atr_value=2.0, config=tick_cfg(window=3))
    assert result.status is AnchoredPriceStatus.NOT_READY
    assert result.reason == "invalid_weights"


def test_all_zero_volume_is_not_ready():
    candles = [flat_candle(0, 100.0, volume=0.0), flat_candle(1, 110.0, volume=0.0), flat_candle(2, 120.0, volume=0.0)]
    result = anchored_price_result(candles, atr_value=2.0, config=tick_cfg(window=3))
    assert result.status is AnchoredPriceStatus.NOT_READY
    assert result.reason == "non_positive_effective_weight"


def test_non_contiguous_zero_weights_are_kept_without_truncation():
    candles = [
        flat_candle(0, 100.0, volume=1.0),
        flat_candle(1, 110.0, volume=0.0),
        flat_candle(2, 120.0, volume=3.0),
    ]
    result = anchored_price_result(candles, atr_value=5.0, config=tick_cfg(window=3))
    assert result.status is AnchoredPriceStatus.READY
    assert result.bars_used == 3
    assert result.cumulative_weight == pytest.approx(4.0)
    assert result.weighted_price == pytest.approx(115.0)


def test_atr_not_ready_returns_explicit_not_ready_and_safe_stable_numeric_block():
    candles = [flat_candle(0, 100.0), flat_candle(1, 101.0)]
    result = anchored_price_result(candles, atr_value=0.0, config=time_cfg(window=2))
    assert result.status is AnchoredPriceStatus.NOT_READY
    assert result.reason == "atr_not_ready"
    block = anchored_price_feature_block(candles, prefix="m1", atr_value=0.0, config=time_cfg(window=2))
    assert set(block) == expected_schema("m1")
    assert all(math.isfinite(float(value)) for value in block.values())
    assert all(value == 0.0 for value in block.values())


def test_bounded_window_start_limits_anchor_age():
    candles = [flat_candle(i, 100.0 + i) for i in range(10)]
    result = anchored_price_result(candles, atr_value=2.0, config=time_cfg(window=4))
    assert result.status is AnchoredPriceStatus.READY
    assert result.bars_used == 4
    assert result.anchor_age_bars == 3
    assert result.weighted_price == pytest.approx((106.0 + 107.0 + 108.0 + 109.0) / 4.0)


def test_partial_window_warmup_uses_available_closed_history():
    candles = [flat_candle(0, 100.0), flat_candle(1, 110.0), flat_candle(2, 120.0)]
    result = anchored_price_result(candles, atr_value=10.0, config=time_cfg(window=20))
    assert result.status is AnchoredPriceStatus.READY
    assert result.bars_used == 3
    assert result.anchor_age_bars == 2
    assert result.weighted_price == pytest.approx(110.0)


def test_feature_block_has_stable_schema_and_drops_raw_price_and_redundant_price_above_flag():
    candles = [flat_candle(i, 100.0 + i, volume=float(i + 1)) for i in range(20)]
    blocks = [
        anchored_price_feature_block(candles, prefix="m1", atr_value=2.0, config=time_cfg(window=20)),
        anchored_price_feature_block(candles, prefix="m1", atr_value=2.0, config=tick_cfg(window=20)),
        anchored_price_feature_block(candles, prefix="m1", atr_value=2.0, config=trade_cfg(window=20)),
    ]
    assert all(set(block) == expected_schema("m1") for block in blocks)
    assert len({tuple(sorted(block)) for block in blocks}) == 1
    assert not any(key.endswith("_price") for key in blocks[0])
    assert not any("price_above" in key for key in blocks[0])


def test_feature_schema_stays_identical_across_weighting_modes_but_only_active_group_is_ready():
    candles = [candle(i, 100.0 + i, volume=float(i + 1), spread=1.0) for i in range(25)]
    time_values = timeframe_features(candles, prefix="m1", anchored_price_config=time_cfg(window=20))
    tick_values = timeframe_features(candles, prefix="m1", anchored_price_config=tick_cfg(window=20))
    trade_values = timeframe_features(candles, prefix="m1", anchored_price_config=trade_cfg(window=20))

    anchored_keys = expected_schema("m1")
    assert anchored_keys <= set(time_values)
    assert anchored_keys <= set(tick_values)
    assert anchored_keys <= set(trade_values)
    assert {key for key in time_values if key in anchored_keys} == anchored_keys
    assert {key for key in tick_values if key in anchored_keys} == anchored_keys
    assert {key for key in trade_values if key in anchored_keys} == anchored_keys

    assert time_values["m1_anchored_mean_ready"] == 1.0
    assert time_values["m1_tick_weighted_price_ready"] == 0.0
    assert time_values["m1_trade_volume_weighted_bar_price_ready"] == 0.0

    assert tick_values["m1_anchored_mean_ready"] == 0.0
    assert tick_values["m1_tick_weighted_price_ready"] == 1.0
    assert tick_values["m1_trade_volume_weighted_bar_price_ready"] == 0.0

    assert trade_values["m1_anchored_mean_ready"] == 0.0
    assert trade_values["m1_tick_weighted_price_ready"] == 0.0
    assert trade_values["m1_trade_volume_weighted_bar_price_ready"] == 1.0


def test_price_basis_is_explicit_and_ablatable():
    candles = [
        Candle(MINUTE, 100.0, 110.0, 90.0, 108.0, 1.0),
        Candle(2 * MINUTE, 108.0, 112.0, 100.0, 110.0, 1.0),
    ]
    hlc3 = anchored_price_result(candles, atr_value=5.0, config=time_cfg(window=2, basis=PriceBasis.TYPICAL_HLC3))
    close = anchored_price_result(candles, atr_value=5.0, config=time_cfg(window=2, basis=PriceBasis.CLOSE))
    ohlc4 = anchored_price_result(candles, atr_value=5.0, config=time_cfg(window=2, basis=PriceBasis.OHLC4))
    assert hlc3.status is AnchoredPriceStatus.READY
    assert close.status is AnchoredPriceStatus.READY
    assert ohlc4.status is AnchoredPriceStatus.READY
    assert len({round(hlc3.weighted_price, 8), round(close.weighted_price, 8), round(ohlc4.weighted_price, 8)}) == 3


def test_time_mode_rejects_irrelevant_volume_semantics():
    with pytest.raises(ValueError):
        AnchoredPriceConfig(
            weighting=WeightingMode.TIME_WEIGHTED,
            volume_semantics=VolumeSemantics.TICK_COUNT,
        ).validate()


def test_feature_vector_v4_adds_stable_semantic_groups_independently_per_timeframe():
    m1 = tuple(candle(i, 100.0 + 0.1 * i, spread=1.0) for i in range(25))
    m5 = tuple(candle(i, 200.0 + 0.2 * i, spread=2.0) for i in range(25))
    context = MTFContext(
        end_timestamp_ms=m1[-1].timestamp_ms,
        candles_by_timeframe={"M1": m1, "M5": m5},
    )
    vector = build_feature_vector(context)
    assert FEATURE_VECTOR_VERSION == "TRADING_AI_FEATURE_VECTOR_V4_ANCHORED_PRICE"
    assert vector.values["m1_anchored_mean_ready"] == 1.0
    assert vector.values["m5_anchored_mean_ready"] == 1.0
    assert vector.values["m1_tick_weighted_price_ready"] == 0.0
    assert vector.values["m1_trade_volume_weighted_bar_price_ready"] == 0.0
    assert expected_schema("m1") <= set(vector.values)
    assert expected_schema("m5") <= set(vector.values)


def test_non_default_tick_semantics_use_same_schema_without_silent_alias():
    candles = [candle(i, 100.0 + i, volume=float(i + 1), spread=1.0) for i in range(25)]
    values = timeframe_features(candles, prefix="m1", anchored_price_config=tick_cfg(window=20))
    assert expected_schema("m1") <= set(values)
    assert values["m1_tick_weighted_price_ready"] == 1.0
    assert values["m1_anchored_mean_ready"] == 0.0
    assert values["m1_trade_volume_weighted_bar_price_ready"] == 0.0
