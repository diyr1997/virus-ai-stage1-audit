import math

import pytest

from trading_ai.sampled_quotes import (
    DEFAULT_SAMPLED_QUOTE_CONFIG,
    SampledQuote,
    SampledQuoteConfig,
    SampledQuoteStatus,
    sampled_quote_feature_block,
    sampled_quote_result,
)


SECOND = 1_000


def q(t_s: float, bid: float, ask: float, *, broker_s: float | None = None) -> SampledQuote:
    return SampledQuote(
        received_at_ms=int(t_s * SECOND),
        bid=bid,
        ask=ask,
        broker_time_ms=None if broker_s is None else int(broker_s * SECOND),
    )


def cfg(**kwargs) -> SampledQuoteConfig:
    base = dict(
        window_ms=60_000,
        min_samples=8,
        max_latest_age_ms=15_000,
        max_gap_ms=20_000,
        expected_interval_ms=5_000,
    )
    base.update(kwargs)
    return SampledQuoteConfig(**base)


def regular_quotes(
    *,
    start_s: float = 0,
    count: int = 13,
    step_s: float = 5,
    start_mid: float = 100.0,
    delta: float = 0.01,
    spread: float = 0.02,
):
    rows = []
    for i in range(count):
        mid = start_mid + delta * i
        rows.append(q(start_s + i * step_s, mid - spread / 2.0, mid + spread / 2.0))
    return rows


def test_default_config_is_explicit_research_starting_point():
    assert DEFAULT_SAMPLED_QUOTE_CONFIG == SampledQuoteConfig(60_000, 8, 15_000, 20_000, 5_000)
    assert DEFAULT_SAMPLED_QUOTE_CONFIG.validate() is DEFAULT_SAMPLED_QUOTE_CONFIG


@pytest.mark.parametrize(
    "bad",
    [
        SampledQuoteConfig(window_ms=0),
        SampledQuoteConfig(min_samples=1),
        SampledQuoteConfig(max_latest_age_ms=0),
        SampledQuoteConfig(max_gap_ms=0),
        SampledQuoteConfig(expected_interval_ms=0),
        SampledQuoteConfig(window_ms=1_000, expected_interval_ms=5_000),
    ],
)
def test_invalid_config_rejected(bad):
    with pytest.raises(ValueError):
        bad.validate()


def test_exactly_min_samples_passes_and_one_less_fails():
    eight = regular_quotes(count=8)
    seven = regular_quotes(count=7)
    assert sampled_quote_result(eight, decision_available_at_ms=35_000, atr_value=1.0).status is SampledQuoteStatus.READY
    result = sampled_quote_result(seven, decision_available_at_ms=30_000, atr_value=1.0)
    assert result.status is SampledQuoteStatus.NOT_READY
    assert result.reason == "insufficient_samples"


def test_future_quote_perturbation_cannot_change_features():
    base = regular_quotes()
    changed = list(base) + [q(61, 10_000.0, 10_000.5), q(70, 1.0, 2.0)]
    a = sampled_quote_result(base, decision_available_at_ms=60_000, atr_value=1.0)
    b = sampled_quote_result(changed, decision_available_at_ms=60_000, atr_value=1.0)
    assert a == b


def test_quote_at_decision_is_included_and_t_plus_1ms_is_excluded():
    config = cfg(min_samples=2, window_ms=10_000, expected_interval_ms=5_000)
    rows = [q(0, 99.99, 100.01), q(10, 100.99, 101.01)]
    rows.append(SampledQuote(received_at_ms=10_001, bid=500.0, ask=501.0))
    result = sampled_quote_result(rows, decision_available_at_ms=10_000, atr_value=2.0, config=config)
    assert result.status is SampledQuoteStatus.READY
    assert result.mid_return_bps == pytest.approx(100.0)


def test_inclusive_lower_window_edge_and_one_ms_before_is_excluded():
    config = cfg(min_samples=2, window_ms=10_000, expected_interval_ms=5_000)
    rows = [
        SampledQuote(received_at_ms=9_999, bid=90.0, ask=90.02),
        SampledQuote(received_at_ms=10_000, bid=99.99, ask=100.01),
        SampledQuote(received_at_ms=20_000, bid=100.99, ask=101.01),
    ]
    result = sampled_quote_result(rows, decision_available_at_ms=20_000, atr_value=1.0, config=config)
    assert result.status is SampledQuoteStatus.READY
    assert result.samples_used == 2
    assert result.mid_return_bps == pytest.approx(100.0)


def test_broker_time_never_overrides_server_receipt_time():
    rows = [
        q(0, 99.99, 100.01, broker_s=10_000),
        q(5, 100.09, 100.11, broker_s=20_000),
    ]
    result = sampled_quote_result(
        rows,
        decision_available_at_ms=5_000,
        atr_value=1.0,
        config=cfg(min_samples=2, window_ms=5_000),
    )
    assert result.status is SampledQuoteStatus.READY
    assert result.mid_return_bps is not None and result.mid_return_bps > 0.0


@pytest.mark.parametrize("different_price", [False, True])
def test_duplicate_received_timestamp_always_fails_closed(different_price):
    rows = regular_quotes(count=8)
    duplicate = q(35, 200.0, 200.1) if different_price else rows[-1]
    result = sampled_quote_result(rows + [duplicate], decision_available_at_ms=35_000, atr_value=1.0)
    assert result.status is SampledQuoteStatus.NOT_READY
    assert result.reason == "duplicate_received_at"
    assert result.duplicate_received_at is True
    assert result.spread_bps is None


def test_reverse_chronological_input_is_sorted_deterministically():
    rows = regular_quotes(count=8)
    a = sampled_quote_result(rows, decision_available_at_ms=35_000, atr_value=1.0)
    b = sampled_quote_result(list(reversed(rows)), decision_available_at_ms=35_000, atr_value=1.0)
    assert a == b


@pytest.mark.parametrize("bad", [float("nan"), float("inf"), -1.0, 0.0])
def test_invalid_current_price_fails_closed(bad):
    rows = regular_quotes(count=8)
    rows[-1] = SampledQuote(received_at_ms=35_000, bid=bad, ask=100.0)
    result = sampled_quote_result(rows, decision_available_at_ms=35_000, atr_value=1.0)
    assert result.status is SampledQuoteStatus.NOT_READY
    assert result.reason == "invalid_quote_price"
    assert result.mid_return_bps is None


def test_crossed_quote_fails_closed():
    rows = regular_quotes(count=8)
    rows[-1] = q(35, 101.0, 100.0)
    result = sampled_quote_result(rows, decision_available_at_ms=35_000, atr_value=1.0)
    assert result.status is SampledQuoteStatus.NOT_READY
    assert result.reason == "crossed_quote"


def test_zero_spread_is_valid_and_finite():
    rows = [q(i * 5, 100.0 + i * 0.01, 100.0 + i * 0.01) for i in range(8)]
    result = sampled_quote_result(rows, decision_available_at_ms=35_000, atr_value=1.0)
    assert result.status is SampledQuoteStatus.READY
    assert result.spread_bps == 0.0
    assert result.spread_atr_ratio == 0.0
    assert result.spread_change_dispersion_bps == 0.0


def test_latest_age_boundary_exact_passes_and_plus_one_ms_fails():
    rows = regular_quotes(start_s=10, count=8)  # final quote at 45s
    exact = sampled_quote_result(rows, decision_available_at_ms=60_000, atr_value=1.0)
    late = sampled_quote_result(rows, decision_available_at_ms=60_001, atr_value=1.0)
    assert exact.status is SampledQuoteStatus.READY
    assert exact.latest_age_ms == 15_000.0
    assert late.status is SampledQuoteStatus.NOT_READY
    assert late.reason == "stale_latest_quote"
    assert late.latest_age_ms == 15_001.0


def test_max_gap_boundary_exact_passes_and_plus_one_ms_fails():
    exact_times = [0, 5, 10, 15, 20, 25, 45, 50]
    exact_rows = [q(t, 99.99 + 0.01 * i, 100.01 + 0.01 * i) for i, t in enumerate(exact_times)]
    exact = sampled_quote_result(exact_rows, decision_available_at_ms=50_000, atr_value=1.0)
    assert exact.status is SampledQuoteStatus.READY
    assert exact.max_gap_ms == 20_000.0

    late_times = [0, 5, 10, 15, 20, 25, 45.001, 50.001]
    late_rows = [q(t, 99.99 + 0.01 * i, 100.01 + 0.01 * i) for i, t in enumerate(late_times)]
    late = sampled_quote_result(late_rows, decision_available_at_ms=50_001, atr_value=1.0)
    assert late.status is SampledQuoteStatus.NOT_READY
    assert late.reason == "excessive_gap"
    assert late.max_gap_ms == 20_001.0


def test_temporal_coverage_is_clipped_and_quality_only():
    rows = regular_quotes(count=13)
    result = sampled_quote_result(rows, decision_available_at_ms=60_000, atr_value=1.0)
    assert result.status is SampledQuoteStatus.READY
    assert result.coverage_ratio == 1.0


def test_identical_quotes_have_real_zero_dynamics_not_missing_values():
    rows = [q(i * 5, 99.99, 100.01) for i in range(8)]
    result = sampled_quote_result(rows, decision_available_at_ms=35_000, atr_value=2.0)
    assert result.status is SampledQuoteStatus.READY
    assert result.mid_return_bps == 0.0
    assert result.mid_velocity_bps_per_sec == 0.0
    assert result.mid_return_dispersion_bps == 0.0
    assert result.mid_change_fraction == 0.0
    assert result.quote_direction_sync == 0.0


def test_known_rising_quotes_have_positive_velocity_and_quote_sync():
    rows = regular_quotes(count=8, delta=0.10, spread=0.02)
    result = sampled_quote_result(rows, decision_available_at_ms=35_000, atr_value=2.0)
    assert result.status is SampledQuoteStatus.READY
    expected_return = ((100.7 / 100.0) - 1.0) * 10_000.0
    assert result.mid_return_bps == pytest.approx(expected_return)
    assert result.mid_velocity_bps_per_sec == pytest.approx(expected_return / 35.0)
    assert result.mid_change_fraction == 1.0
    assert result.quote_direction_sync == 1.0
    assert result.spread_atr_ratio == pytest.approx(0.01)


def test_atr_unavailable_keeps_non_atr_predictors_and_marks_atr_missing():
    rows = regular_quotes(count=8)
    result = sampled_quote_result(rows, decision_available_at_ms=35_000, atr_value=None)
    assert result.status is SampledQuoteStatus.READY
    assert result.atr_ready is False
    assert result.spread_atr_ratio is None
    assert result.spread_bps is not None
    assert result.mid_return_bps is not None

    block = sampled_quote_feature_block(
        rows,
        prefix="m1",
        decision_available_at_ms=35_000,
        atr_value=None,
    )
    assert block.quote_ready is True
    assert block.atr_ready is False
    assert "m1_sampled_spread_atr_ratio" not in block.predictors
    assert "m1_sampled_spread_bps" in block.predictors
    assert "m1_sampled_mid_return_bps" in block.predictors
    assert block.quality["m1_sampled_atr_ready"] == 0.0


def test_quote_not_ready_exports_no_predictors_instead_of_ambiguous_zeros():
    rows = regular_quotes(count=7)
    block = sampled_quote_feature_block(
        rows,
        prefix="m1",
        decision_available_at_ms=30_000,
        atr_value=1.0,
    )
    assert block.quote_ready is False
    assert block.reason == "insufficient_samples"
    assert block.predictors == {}
    assert block.quality["m1_sampled_quote_ready"] == 0.0
    assert all(math.isfinite(float(value)) for value in block.quality.values())


def test_quality_fields_are_separate_from_predictive_namespace():
    rows = regular_quotes(count=8)
    block = sampled_quote_feature_block(
        rows,
        prefix="m5",
        decision_available_at_ms=35_000,
        atr_value=1.0,
    )
    assert block.quote_ready is True
    assert set(block.predictors).isdisjoint(block.quality)
    assert all("sampled" in name for name in block.predictors)
    assert all("sampled" in name for name in block.quality)
    forbidden_predictor_tokens = ("ready", "coverage", "age_ms", "max_gap", "duplicate", "samples_used")
    assert not any(token in name for name in block.predictors for token in forbidden_predictor_tokens)


def test_names_do_not_claim_order_flow_or_realized_volatility():
    rows = regular_quotes(count=8)
    block = sampled_quote_feature_block(
        rows,
        prefix="m5",
        decision_available_at_ms=35_000,
        atr_value=1.0,
    )
    names = list(block.predictors) + list(block.quality)
    forbidden = ("ofi", "cvd", "footprint", "aggressor", "order_flow", "realized_vol", "direction_balance")
    assert not any(token in name.lower() for name in names for token in forbidden)
    assert "m5_sampled_spread_change_dispersion_bps" in block.predictors
    assert "m5_sampled_mid_return_dispersion_bps" in block.predictors
    assert "m5_sampled_quote_direction_sync" in block.predictors


def test_sampling_frequency_change_preserves_window_return_and_velocity_for_same_endpoints():
    slow = regular_quotes(count=13, step_s=5, start_mid=100.0, delta=0.05, spread=0.02)
    fast = []
    for i in range(25):
        mid = 100.0 + (0.60 / 24.0) * i
        fast.append(q(i * 2.5, mid - 0.01, mid + 0.01))
    a = sampled_quote_result(slow, decision_available_at_ms=60_000, atr_value=1.0)
    b = sampled_quote_result(
        fast,
        decision_available_at_ms=60_000,
        atr_value=1.0,
        config=cfg(expected_interval_ms=2_500),
    )
    assert a.status is SampledQuoteStatus.READY
    assert b.status is SampledQuoteStatus.READY
    assert a.mid_return_bps == pytest.approx(b.mid_return_bps, abs=1e-9)
    assert a.mid_velocity_bps_per_sec == pytest.approx(b.mid_velocity_bps_per_sec, abs=1e-12)


def test_irregular_sampling_metric_is_explicitly_dispersion_not_realized_vol():
    times = [0, 1, 6, 16, 21, 41, 46, 51]
    rows = [q(t, 99.99 + 0.02 * i, 100.01 + 0.02 * i) for i, t in enumerate(times)]
    result = sampled_quote_result(rows, decision_available_at_ms=51_000, atr_value=1.0)
    assert result.status is SampledQuoteStatus.READY
    assert result.mid_return_dispersion_bps is not None
    assert math.isfinite(result.mid_return_dispersion_bps)


def test_mtf_decision_boundary_uses_only_quotes_available_by_that_close():
    rows = regular_quotes(start_s=240, count=25, step_s=5, start_mid=100.0, delta=0.01)
    m5_close = 300_000
    a = sampled_quote_result(rows, decision_available_at_ms=m5_close, atr_value=1.0)
    changed = list(rows) + [q(300.001, 1_000.0, 1_001.0)]
    b = sampled_quote_result(changed, decision_available_at_ms=m5_close, atr_value=1.0)
    assert a == b


def test_invalid_future_quote_is_irrelevant_at_current_decision():
    rows = regular_quotes(count=8)
    bad_future = SampledQuote(received_at_ms=40_000, bid=float("nan"), ask=0.0)
    a = sampled_quote_result(rows, decision_available_at_ms=35_000, atr_value=1.0)
    b = sampled_quote_result(rows + [bad_future], decision_available_at_ms=35_000, atr_value=1.0)
    assert a == b


def test_all_future_rows_are_not_available():
    rows = regular_quotes(start_s=100, count=8)
    result = sampled_quote_result(rows, decision_available_at_ms=50_000, atr_value=1.0)
    assert result.status is SampledQuoteStatus.NOT_READY
    assert result.reason == "insufficient_samples"
    assert result.samples_used == 0


def test_out_of_window_invalid_price_is_irrelevant():
    rows = regular_quotes(start_s=100, count=8)
    old_bad = SampledQuote(received_at_ms=0, bid=float("nan"), ask=-1.0)
    result = sampled_quote_result(
        [old_bad] + rows,
        decision_available_at_ms=135_000,
        atr_value=1.0,
        config=cfg(window_ms=40_000),
    )
    assert result.status is SampledQuoteStatus.READY


def test_quote_direction_sync_is_only_bid_ask_co_movement():
    rows = [
        q(0, 99.99, 100.01),
        q(5, 100.00, 100.02),  # both up => +1
        q(10, 99.99, 100.01),  # both down => -1
        q(15, 100.00, 100.00), # bid up, ask down => 0
    ]
    result = sampled_quote_result(
        rows,
        decision_available_at_ms=15_000,
        atr_value=1.0,
        config=cfg(min_samples=4, window_ms=15_000),
    )
    assert result.status is SampledQuoteStatus.READY
    assert result.quote_direction_sync == pytest.approx(0.0)
