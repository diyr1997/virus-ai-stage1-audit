import pytest

from trading_ai.dataset import Candle
from trading_ai.kaufman import KaufmanConfig, KaufmanStatus, kaufman_feature_block, kaufman_result


MINUTE = 60_000


def candle(i: int, close: float) -> Candle:
    return Candle(
        timestamp_ms=(i + 1) * MINUTE,
        open=close,
        high=close + 1.0,
        low=close - 1.0,
        close=close,
        volume=0.0,
    )


def test_calculable_seed_warmup_is_not_model_ready():
    config = KaufmanConfig(er_period=3, fast_period=2, slow_period=5)
    candles = [candle(i, 100.0 + i) for i in range(4)]  # current index=3: first KAMA update

    result = kaufman_result(candles, atr_value=2.0, config=config)
    block = kaufman_feature_block(candles, prefix="m1", atr_value=2.0, config=config)

    assert result.status is KaufmanStatus.READY
    assert result.warmup is True
    assert result.efficiency_ratio == pytest.approx(1.0)
    assert block["m1_kaufman_warmup"] == 1.0
    assert block["m1_kaufman_ready"] == 0.0
    assert block["m1_kaufman_er"] == 0.0
    assert block["m1_kama_dist_atr"] == 0.0
    assert block["m1_kama_slope_atr_per_bar"] == 0.0


def test_first_post_warmup_bar_becomes_model_ready():
    config = KaufmanConfig(er_period=3, fast_period=2, slow_period=5)
    candles = [candle(i, 100.0 + i) for i in range(9)]  # current index=8 == n+slow

    result = kaufman_result(candles, atr_value=2.0, config=config)
    block = kaufman_feature_block(candles, prefix="m1", atr_value=2.0, config=config)

    assert result.status is KaufmanStatus.READY
    assert result.warmup is False
    assert block["m1_kaufman_warmup"] == 0.0
    assert block["m1_kaufman_ready"] == 1.0
    assert block["m1_kaufman_er"] == pytest.approx(result.efficiency_ratio)
    assert block["m1_kama_dist_atr"] == pytest.approx(result.distance_atr)
    assert block["m1_kama_slope_atr_per_bar"] == pytest.approx(result.slope_atr_per_bar)


def test_invalid_data_and_warmup_are_distinguishable_but_both_fail_closed():
    config = KaufmanConfig(er_period=3, fast_period=2, slow_period=5)
    warmup = [candle(i, 100.0 + i) for i in range(4)]
    invalid = list(warmup)
    invalid[-1] = Candle(
        timestamp_ms=invalid[-1].timestamp_ms,
        open=0.0,
        high=0.0,
        low=0.0,
        close=0.0,
        volume=0.0,
    )

    warmup_block = kaufman_feature_block(warmup, prefix="m1", atr_value=2.0, config=config)
    invalid_result = kaufman_result(invalid, atr_value=2.0, config=config)
    invalid_block = kaufman_feature_block(invalid, prefix="m1", atr_value=2.0, config=config)

    assert warmup_block["m1_kaufman_ready"] == 0.0
    assert warmup_block["m1_kaufman_warmup"] == 1.0
    assert invalid_result.status is KaufmanStatus.NOT_READY
    assert invalid_result.reason == "invalid_price_input"
    assert invalid_block["m1_kaufman_ready"] == 0.0
