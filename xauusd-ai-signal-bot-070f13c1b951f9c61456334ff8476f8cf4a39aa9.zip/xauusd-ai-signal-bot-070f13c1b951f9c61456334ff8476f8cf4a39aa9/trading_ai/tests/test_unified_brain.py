"""Architectural invariants of the Stage 1 Unified Brain (synthetic inputs only)."""

import ast
import os
import tempfile
from dataclasses import asdict, replace
from pathlib import Path

import pytest

from trading_ai.core import AnalystContext, MarketSnapshot
from trading_ai.dataset import LeakageError
from trading_ai.unified_brain import (
    CausalLink,
    DecisionAction,
    Evidence,
    Hypothesis,
    ChallengerProposal,
    Lesson,
    ReasoningPolicy,
    WorldState,
    MemoryConflict,
    Observation,
    Outcome,
    SQLiteMemoryStore,
    UnifiedBrain,
    normalize_observation,
    observation_from_analyst,
    observation_from_market,
)

H = 3600_000
LINKS = [
    CausalLink("real_yields", "US10Y_REAL", -1, 0.6, ("US_REAL_YIELDS", "XAU")),
    CausalLink("usd", "DXY", -1, 0.6, ("USD", "XAU")),
]


def obs(oid, t, values, source="feed", avail=None):
    return Observation(oid, t, t if avail is None else avail, source, values)


def rich(t, dy=-0.1, ddxy=-0.2, src=("a", "b", "c")):
    # three fresh observations -> low uncertainty; both factors falling -> XAU UP on both paths
    return [obs(f"{src[0]}{t}", t, {"US10Y_REAL": dy}, src[0]), obs(f"{src[1]}{t}", t, {"DXY": ddxy}, src[1]), obs(f"{src[2]}{t}", t, {"DXY": ddxy}, src[2])]


# ---------------------------------------------------------------- PIT / input

def test_input_normalization_and_existing_contracts():
    o = normalize_observation({"observation_id": "x", "observed_at_ms": 10, "available_at_ms": 12, "source": "s", "values": {"a": 1}, "pit_safe": True})
    assert o.values == {"a": 1}
    with pytest.raises(LeakageError):
        normalize_observation({"observation_id": "x", "observed_at_ms": 10, "available_at_ms": 12, "source": "s", "values": {}})  # pit_safe not asserted
    m = observation_from_market(MarketSnapshot("XAUUSD", 1000, 2000.0, 2000.3, 0.3, features={"atr": 1.5}), available_at_ms=1001, source="mt5")
    assert m.values["spread"] == 0.3 and m.values["atr"] == 1.5
    a = observation_from_analyst(AnalystContext("buy", 50, 0.7), observed_at_ms=900, available_at_ms=950, source="analyst")
    assert a.values["analyst_direction"] == "BUY"


def test_future_information_is_rejected_everywhere():
    brain = UnifiedBrain()
    with pytest.raises(LeakageError):
        brain.perceive([obs("o1", 1000, {"DXY": 1}, avail=1100)], as_of_ms=1050)
    state = brain.perceive([obs("o1", 1000, {"DXY": 1})], as_of_ms=1050)
    with pytest.raises(LeakageError):
        brain.evaluate(state, [], [Evidence("e", "not-in-state", "h", 0.5)])
    # an observation seen earlier is not visible to an as_of before it became available
    brain.perceive([obs("late", 5000, {"DXY": 1})], as_of_ms=5000)
    assert "late" not in {o.observation_id for o in brain.perceive([], as_of_ms=2000).observations}


# ------------------------------------------------------------------- memory

def test_persistent_memory_is_append_only():
    store = SQLiteMemoryStore()
    store.put("k", "1", {"v": 1})
    store.put("k", "1", {"v": 1})  # identical: no-op
    with pytest.raises(MemoryConflict):
        store.put("k", "1", {"v": 2})
    assert store.list_kind("k") == [{"v": 1}]


def test_active_policy_pointer_cannot_disagree_with_policy_record():
    store = SQLiteMemoryStore()
    store.put("policy", "policy-v1", {"version": "policy-v1"})
    store.put("policy_event", "0001", {"seq": 1, "active": "missing", "reason": "CORRUPT"})
    brain = UnifiedBrain.__new__(UnifiedBrain)
    brain.memory = store
    with pytest.raises(MemoryConflict):
        _ = brain.active_policy


def test_memory_survives_restart_and_rebuilds_working_memory():
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    try:
        b1 = UnifiedBrain(SQLiteMemoryStore(path))
        t = b1.think(rich(1000), as_of_ms=1000, links=LINKS)
        b2 = UnifiedBrain(SQLiteMemoryStore(path))
        assert t.trace_id in b2.working.open_decisions
        assert {o.observation_id for o in b2.perceive([], as_of_ms=1000).observations} == set(t.observation_ids)
    finally:
        os.remove(path)


def test_stale_observations_raise_uncertainty_and_leave_the_state():
    brain = UnifiedBrain()
    brain.perceive(rich(1000), as_of_ms=1000)
    later = brain.perceive([], as_of_ms=1000 + 25 * H)
    assert later.observations == () and len(later.stale_observation_ids) == 3
    assert later.uncertainty == 1.0
    assert later.state_hash() != brain.perceive(rich(1000), as_of_ms=1000).state_hash()
    altered = Observation("a1000", 1000, 1000, "a", {"DXY": -0.25})
    original = brain.perceive(rich(1000), as_of_ms=1000)
    changed = WorldState(original.as_of_ms, (altered,), original.regime, original.uncertainty, original.stale_observation_ids)
    assert changed.state_hash() != original.state_hash()


# -------------------------------------------------- reasoning / decision

def test_causal_hypotheses_compete_and_carry_explicit_direction():
    brain = UnifiedBrain()
    state = brain.perceive([obs("y", 1000, {"US10Y_REAL": 0.1}, "a"), obs("d", 1000, {"DXY": -0.2}, "b"), obs("d2", 1000, {"DXY": -0.1}, "c")], as_of_ms=1000)
    hs, ev = brain.generate_hypotheses(state, LINKS)
    dirs = {h.hypothesis_id: h.direction for h in hs}
    assert dirs == {"H:real_yields:DOWN": "DOWN", "H:usd:UP": "UP"}, "real yields up -> DOWN; dollar down -> UP"
    up = next(h for h in hs if h.direction == "UP")
    assert set(up.contradicting_evidence_ids) == {e.evidence_id for e in ev if e.supports == "H:real_yields:DOWN"}
    assert up.causal_path == ("USD", "XAU")


def test_direction_is_never_parsed_from_text():
    brain = UnifiedBrain()
    state = brain.perceive(rich(1000), as_of_ms=1000)
    t = brain.decide(state, [Hypothesis("h", "do not BUY here", 0.9, 0.95)])
    assert t.action is DecisionAction.WAIT and t.reason == "NO_DIRECTIONAL_HYPOTHESIS"


def test_evidence_from_one_observation_counts_once():
    brain = UnifiedBrain()
    state = brain.perceive(rich(1000), as_of_ms=1000)
    h = Hypothesis("h", "s", 0.5, 0.5, ("e1", "e2"), (), "UP")
    once, _ = brain.evaluate(state, [h], [Evidence("e1", "a1000", "h", 0.4), Evidence("e2", "a1000", "h", 0.4)])
    assert once[0].confidence == pytest.approx(0.7)


def test_evidence_integrity_rejects_misattribution_and_duplicates():
    brain = UnifiedBrain()
    state = brain.perceive(rich(1000), as_of_ms=1000)
    h1 = Hypothesis("h1", "up", 0.5, 0.5, ("e1",), (), "UP")
    h2 = Hypothesis("h2", "down", 0.5, 0.5, (), ("e2",), "DOWN")
    with pytest.raises(ValueError, match="supports a different"):
        brain.evaluate(state, [h1, h2], [Evidence("e1", "a1000", "h2", 0.4)])
    with pytest.raises(ValueError, match="duplicate"):
        brain.evaluate(state, [h1], [Evidence("e1", "a1000", "h1", 0.4), Evidence("e1", "a1000", "h1", 0.4)])
    with pytest.raises(ValueError, match="opposite direction"):
        brain.evaluate(state, [Hypothesis("h1", "up", 0.5, 0.5, ("e1",), ("e2",), "UP"), Hypothesis("h2", "also up", 0.5, 0.5, ("e2",), (), "UP")],
                       [Evidence("e1", "a1000", "h1", 0.4), Evidence("e2", "b1000", "h2", 0.4)])


def test_contradiction_conflict_and_uncertainty_force_wait():
    brain = UnifiedBrain()
    state = brain.perceive(rich(1000), as_of_ms=1000)
    up, down = Hypothesis("u", "s", 0.5, 0.5, ("eu",), direction="UP"), Hypothesis("d", "s", 0.5, 0.5, ("ed",), direction="DOWN")
    ev = [Evidence("eu", "a1000", "u", 0.5), Evidence("ed", "b1000", "d", 0.45)]  # confidences 0.75 vs 0.725
    assert brain.decide(state, [up, down], evidence=ev).reason == "CONFLICTED_HYPOTHESES"
    assert brain.decide(state, [up], evidence=ev[:1], contradiction_ids=("e1",)).action is DecisionAction.WAIT
    assert brain.decide(state, [up], evidence=ev[:1], contradiction_ids=("e1",)).reason == "CONTRADICTORY_EVIDENCE"
    thin = brain.perceive([], as_of_ms=1000 + 30 * H)
    assert brain.decide(thin, [Hypothesis("u", "s", 0.5, 0.99, direction="UP")]).reason == "UNCERTAINTY_TOO_HIGH"
    trace = brain.decide(state, [Hypothesis("u", "s", 0.5, 0.99, ("eu",), direction="UP")], evidence=[Evidence("eu", "a1000", "u", 0.5)])
    assert trace.action is DecisionAction.BUY and trace.execution_allowed is False
    with pytest.raises(ValueError):
        trace.__class__(**{**trace.__dict__, "execution_allowed": True})


# ------------------------------------------------ outcome / error / learning

def test_outcome_clock_and_single_outcome():
    brain = UnifiedBrain()
    t = brain.think(rich(1000), as_of_ms=1000, links=LINKS, horizon_ms=H)
    with pytest.raises(ValueError, match="before decision"):
        brain.record_outcome(Outcome(t.trace_id, 900, "X", 0.01))
    with pytest.raises(ValueError, match="horizon"):
        brain.record_outcome(Outcome(t.trace_id, 1000 + H - 1, "X", 0.01))
    with pytest.raises(LeakageError):
        brain.record_outcome(Outcome(t.trace_id, 1000 + H, "X", 0.01, observed_at_ms=1000 + 2 * H, available_at_ms=1000 + 2 * H))
    with pytest.raises(LeakageError, match="unavailable"):
        brain.record_outcome(Outcome(t.trace_id, 1000 + H, "X", 0.01, available_at_ms=1000 + H + 1))
    with pytest.raises(ValueError, match="cannot precede"):
        brain.record_outcome(Outcome(t.trace_id, 1000 + H, "X", 0.01, observed_at_ms=1000 + H, available_at_ms=1000 + H - 1))
    brain.record_outcome(Outcome(t.trace_id, 1000 + H, "WIN", 0.01, observed_at_ms=1000 + H, available_at_ms=1000 + H))
    with pytest.raises(MemoryConflict):
        brain.record_outcome(Outcome(t.trace_id, 1000 + H, "LOSS", -0.01, available_at_ms=1000 + H))


def test_error_analysis_attributes_blame_and_learning_is_quarantined():
    brain = UnifiedBrain()
    t = brain.think(rich(1000), as_of_ms=1000, links=LINKS, horizon_ms=H)
    assert t.action is DecisionAction.BUY
    lesson = brain.record_outcome(Outcome(t.trace_id, 1000 + H, "LOSS", -0.02, available_at_ms=1000 + H))
    assert lesson.error_type in ("WRONG_DIRECTION", "OVERCONFIDENT_WRONG_DIRECTION")
    supporting_sources = {brain.memory.get("observation", o)["source"] for o in t.supporting_observation_ids}
    assert supporting_sources and set(lesson.blamed_sources) == supporting_sources
    before = brain.active_policy
    proposal = brain.propose_challenger(lesson)
    assert proposal.status == "QUARANTINED" and proposal.requires_validation
    assert brain.active_policy == before, "a lesson never changes the active policy"


def test_challenger_needs_held_out_validation_and_explicit_approval():
    weak = [CausalLink("usd", "DXY", -1, 0.32, ("USD", "XAU"))]
    noise = lambda t: [obs(f"n1{t}", t, {"OTHER": 1}, "b"), obs(f"n2{t}", t, {"OTHER": 1}, "c")]
    brain = UnifiedBrain()
    t = brain.think([obs("bad1000", 1000, {"DXY": -0.5}, "bad"), *noise(1000)], as_of_ms=1000, links=weak, horizon_ms=H)
    assert t.action is DecisionAction.BUY and t.supporting_observation_ids == ("bad1000",)
    lesson = brain.record_outcome(Outcome(t.trace_id, 1000 + H, "LOSS", -0.02, available_at_ms=1000 + H))
    assert lesson.blamed_sources == ("bad",), "only the source behind the wrong call is blamed"
    proposal = brain.propose_challenger(lesson)
    assert proposal.policy["source_reliability"] == {"bad": 0.9} and brain.active_policy.version == "policy-v1"
    # Held-out cases strictly after the lesson: 'bad' keeps calling UP while the price falls.
    cases = [([obs(f"bad{at}", at, {"DXY": -0.5}, "bad"), *noise(at)], weak, at, -0.01) for at in (1000 + (2 + i) * H for i in range(25))]
    report = brain.validate_challenger(proposal, cases)
    assert (report.cases, report.passed, report.reason) == (25, True, "CHALLENGER_BETTER")
    assert report.challenger_score > report.champion_score
    assert brain.active_policy.version == "policy-v1", "validation alone changes nothing"
    with pytest.raises(PermissionError):
        brain.accept_challenger(proposal, report, approved_by="")
    forged = report.__class__(**{**report.__dict__, "passed": True, "cases": 99})
    with pytest.raises(PermissionError):
        brain.accept_challenger(proposal, forged, approved_by="council")
    too_few = brain.validate_challenger(proposal, cases[:3])
    assert too_few.passed is False and too_few.reason == "INSUFFICIENT_HELD_OUT_CASES"
    in_sample = brain.validate_challenger(proposal, [(o, l, 900, r) for o, l, _, r in cases])
    assert in_sample.cases == 0, "cases from before the lesson are not validation"
    new = brain.accept_challenger(proposal, report, approved_by="council")
    assert brain.active_policy == new and new.parent == "policy-v1" and new.reliability("bad") == 0.9
    after = brain.think([obs("bad9", 1000 + 40 * H, {"DXY": -0.5}, "bad"), *noise(1000 + 40 * H)], as_of_ms=1000 + 40 * H, links=weak)
    assert after.action is DecisionAction.WAIT and after.policy_version == new.version
    events = brain.memory.list_kind("policy_event")
    assert [e["active"] for e in events] == ["policy-v1", new.version], "policy history is append-only"
    with pytest.raises(PermissionError):
        brain.validate_challenger(proposal, cases)
    with pytest.raises(PermissionError):
        brain.validate_challenger(ChallengerProposal("fake", "reasoning_policy", "x", True, "fake-version", proposal.policy, "QUARANTINED", proposal.created_at_ms), cases)
    fake_lesson = lesson.__class__(**{**lesson.__dict__, "statement": "forged"})
    with pytest.raises(PermissionError):
        brain.propose_challenger(fake_lesson)
    with pytest.raises(MemoryConflict):
        brain.accept_challenger(proposal, report, approved_by="council")


def test_full_closed_loop_input_to_memory():
    """INPUT -> MEMORY -> STATE -> REASONING -> HYPOTHESIS -> EVIDENCE -> DECISION
    -> OUTCOME -> ERROR -> LEARNING -> MEMORY, and the next cycle recalls it."""
    store = SQLiteMemoryStore()
    brain = UnifiedBrain(store)
    t1 = brain.think(rich(1000), as_of_ms=1000, links=LINKS, horizon_ms=H)            # INPUT..DECISION
    assert store.get("decision", t1.trace_id)["state_hash"] == t1.state_hash          # MEMORY holds the trace
    assert t1.causal_path and t1.evidence_ids and t1.hypothesis_ids                   # REASONING/HYPOTHESIS/EVIDENCE
    lesson = brain.record_outcome(Outcome(t1.trace_id, 1000 + H, "LOSS", -0.02, available_at_ms=1000 + H))       # OUTCOME + ERROR
    proposal = brain.propose_challenger(lesson)                                      # LEARNING (quarantined)
    assert store.get("lesson", lesson.lesson_id) and store.get("challenger", proposal.challenger_version)
    t2 = brain.think(rich(1000 + 2 * H), as_of_ms=1000 + 2 * H, links=LINKS, horizon_ms=H)
    assert lesson.lesson_id in t2.recalled_lesson_ids                                 # MEMORY -> next REASONING
    assert t2.policy_version == t1.policy_version == "policy-v1"                      # behaviour unchanged
    assert t1.trace_id not in brain.working.open_decisions and t2.trace_id in brain.working.open_decisions


# ------------------------------------------- regression tests for audited holes

def done(t, r, result="X"):
    end = t.as_of_ms + t.horizon_ms
    return Outcome(t.trace_id, end, result, r, observed_at_ms=end, available_at_ms=end)


def tamper(store, kind, key, old, new):
    store.db.execute("UPDATE brain_memory SET payload=replace(payload,?,?) WHERE kind=? AND key=?", (old, new, kind, key))
    store.db.commit()


WEAK = [CausalLink("usd", "DXY", -1, 0.32, ("USD", "XAU"))]


def bad_case(src, at):
    return [obs(f"{src}{at}", at, {"DXY": -0.5}, src), obs(f"n1{at}", at, {"OTHER": 1}, "b"), obs(f"n2{at}", at, {"OTHER": 1}, "c")]


def lesson_blaming(brain, src, at):
    t = brain.think(bad_case(src, at), as_of_ms=at, links=WEAK, horizon_ms=H)
    assert t.action is DecisionAction.BUY
    return brain.record_outcome(done(t, -0.02, "LOSS"))


def held_out(src, start):
    return [(bad_case(src, at), WEAK, at, -0.01) for at in (start + i * H for i in range(25))]


def test_future_lessons_are_never_recalled_by_an_earlier_decision():
    brain = UnifiedBrain()
    t = brain.think(rich(1000), as_of_ms=1000, links=LINKS, horizon_ms=10 * H)
    lesson = brain.record_outcome(done(t, -0.02, "LOSS"))
    earlier = brain.think(rich(500), as_of_ms=500, links=LINKS)
    assert lesson.lesson_id not in earlier.recalled_lesson_ids, "lesson created at resolution cannot reach an earlier as_of"
    later = brain.think(rich(1000 + 10 * H), as_of_ms=1000 + 10 * H, links=LINKS)
    assert lesson.lesson_id in later.recalled_lesson_ids
    assert brain.replay_decision(later.trace_id) == later


def test_every_decision_is_reproducible_from_memory_and_tampering_is_detected():
    store = SQLiteMemoryStore()
    brain = UnifiedBrain(store)
    t = brain.think(rich(1000), as_of_ms=1000, links=LINKS, minimum_confidence=0.7)
    assert brain.replay_decision(t.trace_id) == t and t.threshold == 0.7
    state = brain.perceive([], as_of_ms=1000)
    direct = brain.decide(state, [Hypothesis("u", "s", 0.5, 0.99, ("eu",), (), "UP")], evidence=[Evidence("eu", "a1000", "u", 0.5)])
    assert brain.replay_decision(direct.trace_id) == direct
    tamper(store, "observation", "b1000", "-0.2", "0.2")  # an input changed after the decision
    with pytest.raises(MemoryConflict, match="state hash"):
        brain.replay_decision(t.trace_id)
    store2 = SQLiteMemoryStore()
    b2 = UnifiedBrain(store2)
    t2 = b2.think(rich(1000), as_of_ms=1000, links=LINKS)
    tamper(store2, "decision", t2.trace_id, '"reason":"TOP_HYPOTHESIS"', '"reason":"FORGED"')
    with pytest.raises(MemoryConflict, match="not reproducible"):
        b2.replay_decision(t2.trace_id)
    t3 = b2.think(rich(2000), as_of_ms=2000, links=LINKS)
    tamper(store2, "decision_input", t3.trace_id, '"strength":0.6', '"strength":0.1')  # rewritten causal link
    with pytest.raises(MemoryConflict, match="not reproducible"):
        b2.replay_decision(t3.trace_id)
    with pytest.raises(MemoryConflict):
        b2.record_outcome(done(t2, 0.01))  # no learning from a decision memory cannot reproduce


def test_trace_identity_covers_every_input_and_repeats_are_idempotent():
    brain = UnifiedBrain()
    state = brain.perceive(rich(1000), as_of_ms=1000)
    h = Hypothesis("h", "s", 0.5, 0.9, ("e1",), (), "UP")
    a = brain.decide(state, [h], evidence=[Evidence("e1", "a1000", "h", 0.5)])
    b = brain.decide(state, [h], evidence=[Evidence("e1", "b1000", "h", 0.5)])  # same body, other evidence
    assert a.trace_id != b.trace_id and a.supporting_observation_ids != b.supporting_observation_ids
    assert brain.decide(state, [h], evidence=[Evidence("e1", "a1000", "h", 0.5)]) == a
    looser = brain.decide(state, [h], evidence=[Evidence("e1", "a1000", "h", 0.5)], minimum_confidence=0.95)
    assert looser.trace_id != a.trace_id and looser.action is DecisionAction.WAIT and looser.threshold == 0.95


def test_directional_decision_needs_traceable_evidence_and_threshold_cannot_be_loosened():
    brain = UnifiedBrain()
    state = brain.perceive(rich(1000), as_of_ms=1000)
    bare = brain.decide(state, [Hypothesis("u", "s", 0.5, 0.99, direction="UP")])
    assert bare.action is DecisionAction.WAIT and bare.confidence == 0.5, "an input confidence is never trusted"
    lax = UnifiedBrain(initial_policy=ReasoningPolicy(minimum_confidence=0.5))  # threshold at the neutral prior
    lax_state = lax.perceive(rich(1000), as_of_ms=1000)
    assert lax.decide(lax_state, [Hypothesis("u", "s", 0.5, 0.99, direction="UP")]).reason == "UNSUPPORTED_HYPOTHESIS"
    against = lax.decide(lax_state, [Hypothesis("u", "s", 0.5, 0.99, ("eu",), (), "UP")], evidence=[Evidence("eu", "a1000", "u", -0.5)])
    assert against.action is DecisionAction.WAIT, "negative evidence does not support"
    t = brain.think(rich(3000), as_of_ms=3000, links=LINKS, minimum_confidence=0.1)
    assert t.threshold == brain.active_policy.minimum_confidence, "a caller can be stricter, never looser"


def test_evidence_provenance_is_checked_against_the_observation():
    brain = UnifiedBrain()
    state = brain.perceive(rich(1000), as_of_ms=1000)
    h = Hypothesis("h", "s", 0.5, 0.5, ("e1",), (), "UP")
    with pytest.raises(ValueError, match="source does not match"):
        brain.evaluate(state, [h], [Evidence("e1", "a1000", "h", 0.5, 1.0, "", "trusted-looking")])
    with pytest.raises(ValueError, match="not supplied"):
        brain.evaluate(state, [Hypothesis("h", "s", 0.5, 0.5, ("ghost",), (), "UP")], [])
    with pytest.raises(ValueError, match="not supplied"):
        brain.evaluate(state, [Hypothesis("h", "s", 0.5, 0.5, (), ("ghost",), "UP")], [])
    distrust = UnifiedBrain(initial_policy=ReasoningPolicy(source_reliability={"a": 0.0}))
    s2 = distrust.perceive(rich(1000), as_of_ms=1000)
    evaluated, _ = distrust.evaluate(s2, [h], [Evidence("e1", "a1000", "h", 0.5, reliability=1.0)])
    assert evaluated[0].confidence == pytest.approx(0.5), "evidence cannot override the policy's source reliability"


def test_contradictory_causal_evidence_leads_to_wait():
    brain = UnifiedBrain()
    mixed = [obs("y", 1000, {"US10Y_REAL": 0.1}, "a"), obs("d", 1000, {"DXY": -0.2}, "b"), obs("d2", 1000, {"DXY": -0.1}, "c")]
    t = brain.think(mixed, as_of_ms=1000, links=LINKS)
    assert t.action is DecisionAction.WAIT and t.reason == "CONTRADICTORY_EVIDENCE" and t.contradiction_ids
    assert brain.replay_decision(t.trace_id) == t


def test_outcome_needs_availability_after_the_horizon():
    brain = UnifiedBrain()
    t = brain.think(rich(1000), as_of_ms=1000, links=LINKS, horizon_ms=H)
    end = 1000 + H
    with pytest.raises(LeakageError, match="required"):
        brain.record_outcome(Outcome(t.trace_id, end, "WIN", 0.01))
    with pytest.raises(ValueError, match="horizon"):
        brain.record_outcome(Outcome(t.trace_id, end, "WIN", 0.01, observed_at_ms=1001, available_at_ms=1001))
    with pytest.raises(ValueError, match="horizon"):
        brain.record_outcome(Outcome(t.trace_id, end + 5, "WIN", 0.01, observed_at_ms=end - 1, available_at_ms=end + 5))
    with pytest.raises(ValueError, match="unknown decision"):
        brain.record_outcome(Outcome("nope", end, "WIN", 0.01, available_at_ms=end))
    lesson = brain.record_outcome(done(t, 0.01, "WIN"))
    assert lesson.created_at_ms == end and brain.record_outcome(done(t, 0.01, "WIN")) == lesson, "identical re-record is idempotent"


def test_working_memory_eviction_is_restart_invariant_and_fails_closed():
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    try:
        b1 = UnifiedBrain(SQLiteMemoryStore(path), working_capacity=2)
        x, y, z = obs("x", 1000, {"DXY": -1}), obs("y", 1000, {"DXY": -1}), obs("z", 1000, {"DXY": -1})
        full = b1.perceive([x, y, z], as_of_ms=1000)
        assert len(full.observations) == 2 and full.working_memory_complete is False and full.uncertainty == 1.0
        assert b1.think([], as_of_ms=1000, links=LINKS).reason == "UNCERTAINTY_TOO_HIGH", "a possibly-missing fresh input forces WAIT"
        before = b1.perceive([x], as_of_ms=1000)  # re-perceiving an evicted observation does not reorder memory
        after = UnifiedBrain(SQLiteMemoryStore(path), working_capacity=2).perceive([], as_of_ms=1000)
        assert before.state_hash() == after.state_hash()
        later = UnifiedBrain(SQLiteMemoryStore(path), working_capacity=2).perceive([], as_of_ms=1000 + 25 * H)
        assert later.working_memory_complete is True, "an evicted observation that is surely stale is forgotten by design"
        with pytest.raises(ValueError):
            UnifiedBrain(working_capacity=0)
    finally:
        os.remove(path)


def test_state_identity_distinguishes_every_reasoning_input():
    base = WorldState(1000, (obs("o", 1000, {"DXY": -0.2}),), "UNKNOWN", 0.5, ())
    variants = [
        WorldState(1000, (obs("o", 1000, {"DXY": -0.3}),), "UNKNOWN", 0.5, ()),
        WorldState(1000, (obs("o", 1000, {"DXY": -0.2}, "other"),), "UNKNOWN", 0.5, ()),
        WorldState(1000, (obs("o", 1000, {"DXY": -0.2}),), "UNKNOWN", 0.5, ("s",)),
        WorldState(1000, (obs("o", 1000, {"DXY": -0.2}),), "UNKNOWN", 0.6, ()),
        WorldState(1000, (obs("o", 1000, {"DXY": -0.2}),), "UNKNOWN", 0.5, (), False),
        WorldState(1001, (obs("o", 1000, {"DXY": -0.2}),), "UNKNOWN", 0.5, ()),
    ]
    hashes = {base.state_hash(), *(v.state_hash() for v in variants)}
    assert len(hashes) == 1 + len(variants)


def test_forged_lessons_are_rejected():
    brain = UnifiedBrain()
    lesson = lesson_blaming(brain, "bad", 1000)
    injected = Lesson("fake", lesson.trace_id, "MISSED_MOVE", "x", 0.0, False, ("USD", "XAU"), ("a", "b", "c"), lesson.created_at_ms)
    brain.memory.put("lesson", "fake", asdict(injected))  # written past the brain, straight into memory
    with pytest.raises(PermissionError, match="does not follow"):
        brain.propose_challenger(injected)
    t = brain.think(rich(9000), as_of_ms=9000, links=LINKS)
    orphan = Lesson("orphan", t.trace_id, "WRONG_DIRECTION", "x", -0.05, False, t.causal_path, ("a",), 9000 + H)
    brain.memory.put("lesson", "orphan", asdict(orphan))
    with pytest.raises(PermissionError, match="decision and outcome"):
        brain.propose_challenger(orphan)
    with pytest.raises(PermissionError, match="immutable"):
        brain.propose_challenger(Lesson(**{**asdict(lesson), "blamed_sources": ("a",), "causal_path": lesson.causal_path}))
    assert brain.active_policy.version == "policy-v1"


def test_forged_challengers_are_rejected():
    brain = UnifiedBrain()
    lesson = lesson_blaming(brain, "bad", 1000)
    real = brain.propose_challenger(lesson)
    evil_policy = {**real.policy, "minimum_confidence": 0.0, "version": "challenger-evil"}
    evil = ChallengerProposal(lesson.lesson_id, "reasoning_policy", real.change, True, "challenger-evil", evil_policy, "QUARANTINED", real.created_at_ms)
    brain.memory.put("challenger", "challenger-evil", asdict(evil))
    with pytest.raises(PermissionError, match="does not follow"):
        brain.validate_challenger(evil, held_out("bad", 1000 + 2 * H))
    report = brain.validate_challenger(real, held_out("bad", 1000 + 2 * H))
    assert report.passed
    brain.memory.put("validation", "challenger-evil:x", {**asdict(report), "challenger_version": "challenger-evil"})
    with pytest.raises(PermissionError):
        brain.accept_challenger(evil, report, approved_by="council")
    unstored = ChallengerProposal(**{**asdict(real), "change": "something else"})
    with pytest.raises(PermissionError, match="not the quarantined"):
        brain.accept_challenger(unstored, report, approved_by="council")
    with pytest.raises(PermissionError, match="quarantined"):
        brain.validate_challenger(ChallengerProposal(**{**asdict(real), "status": "ACCEPTED"}), held_out("bad", 1000 + 2 * H))
    assert brain.active_policy.version == "policy-v1"


def test_stale_challenger_cannot_roll_back_and_acceptance_is_once():
    brain = UnifiedBrain()
    pa = brain.propose_challenger(lesson_blaming(brain, "bad", 1000))
    pb = brain.propose_challenger(lesson_blaming(brain, "worse", 1000 + 2 * H))
    ra = brain.validate_challenger(pa, held_out("bad", 1000 + 4 * H))
    rb = brain.validate_challenger(pb, held_out("worse", 1000 + 4 * H))
    assert ra.passed and rb.passed and pa.policy["parent"] == pb.policy["parent"] == "policy-v1"
    accepted = brain.accept_challenger(pa, ra, approved_by="council")
    with pytest.raises(PermissionError, match="stale"):
        brain.accept_challenger(pb, rb, approved_by="council")  # would silently drop A's change
    with pytest.raises(PermissionError, match="stale"):
        brain.validate_challenger(pb, held_out("worse", 1000 + 4 * H))
    with pytest.raises(MemoryConflict, match="already accepted"):
        brain.accept_challenger(pa, ra, approved_by="someone-else")
    assert brain.active_policy == accepted
    assert [e["active"] for e in brain.memory.list_kind("policy_event")] == ["policy-v1", accepted.version]


def _policy_row(version, parent, **kw):
    return asdict(ReasoningPolicy(version=version, parent=parent, **kw))


def test_corrupted_active_policy_or_history_is_detected():
    store = SQLiteMemoryStore()
    brain = UnifiedBrain(store)
    tamper(store, "policy", "policy-v1", '"minimum_confidence":0.65', '"minimum_confidence":0.01')
    with pytest.raises(MemoryConflict, match="hash"):
        _ = brain.active_policy
    with pytest.raises(MemoryConflict):
        brain.think(rich(1000), as_of_ms=1000, links=LINKS)

    def fresh_with(event_key, event):
        b = UnifiedBrain()
        b.memory.put("policy", event["active"], _policy_row(event["active"], event.pop("_parent"), minimum_confidence=0.0))
        event["policy_hash"] = ReasoningPolicy(**{**b.memory.get("policy", event["active"])}).policy_hash()
        b.memory.put("policy_event", event_key, event)
        return b

    with pytest.raises(MemoryConflict, match="contiguous"):
        _ = fresh_with("0007", {"seq": 7, "active": "rogue", "reason": "x", "_parent": "policy-v1"}).active_policy
    with pytest.raises(MemoryConflict, match="parent chain"):
        _ = fresh_with("0002", {"seq": 2, "active": "orphan", "reason": "x", "_parent": "elsewhere"}).active_policy
    b = UnifiedBrain()
    b.memory.put("policy_event", "0002", {"seq": 2, "active": "policy-v1", "reason": "rollback", "policy_hash": ReasoningPolicy().policy_hash()})
    with pytest.raises(MemoryConflict, match="twice"):
        _ = b.active_policy


def test_execution_is_isolated_from_the_brain():
    store = SQLiteMemoryStore()
    brain = UnifiedBrain(store)
    t = brain.think(rich(1000), as_of_ms=1000, links=LINKS)
    assert t.action is DecisionAction.BUY and t.execution_allowed is False
    assert store.get("decision", t.trace_id)["execution_allowed"] is False
    tamper(store, "decision", t.trace_id, '"execution_allowed":false', '"execution_allowed":true')
    with pytest.raises(ValueError, match="never authorizes"):
        brain.replay_decision(t.trace_id)  # the stored decision cannot even be loaded
    with pytest.raises(MemoryConflict, match="chain"):
        UnifiedBrain(store)  # and a restart refuses the edited memory before reading it
    with pytest.raises(ValueError, match="never authorizes"):
        replace(t, execution_allowed=True)
    tree = ast.parse(Path(__file__).resolve().parents[1].joinpath("unified_brain.py").read_text())
    imported = {n.module if isinstance(n, ast.ImportFrom) else a.name for n in ast.walk(tree) if isinstance(n, (ast.Import, ast.ImportFrom)) for a in n.names}
    assert imported <= {"__future__", "bisect", "hashlib", "json", "math", "sqlite3", "dataclasses", "enum", "typing", "core", "dataset"}, imported
    names = {n.id for n in ast.walk(tree) if isinstance(n, ast.Name)} | {n.attr for n in ast.walk(tree) if isinstance(n, ast.Attribute)}
    assert not names & {"os", "environ", "getenv", "subprocess", "socket", "requests", "urlopen", "MetaTrader5", "mt5", "order_send"}
    public = {m for m in dir(UnifiedBrain) if not m.startswith("_")}
    assert not {m for m in public if any(w in m.lower() for w in ("order", "execute", "trade", "send", "broker"))}, public


def test_restart_preserves_policy_history_and_replay():
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    try:
        b1 = UnifiedBrain(SQLiteMemoryStore(path))
        proposal = b1.propose_challenger(lesson_blaming(b1, "bad", 1000))
        accepted = b1.accept_challenger(proposal, b1.validate_challenger(proposal, held_out("bad", 1000 + 2 * H)), approved_by="council")
        t = b1.think(rich(1000 + 40 * H), as_of_ms=1000 + 40 * H, links=LINKS)
        b2 = UnifiedBrain(SQLiteMemoryStore(path))
        assert b2.active_policy == accepted and b2.replay_decision(t.trace_id) == t
        assert t.trace_id in b2.working.open_decisions
    finally:
        os.remove(path)


def test_decisions_are_made_only_on_states_the_brain_perceived():
    brain = UnifiedBrain()
    brain.perceive([obs("a", 1000, {"DXY": -1}, "a")], as_of_ms=1000)
    forged = WorldState(1000, (obs("a", 1000, {"DXY": -1}, "a"),), "UNKNOWN", 0.0, ())  # uncertainty 0 from one input
    with pytest.raises(PermissionError, match="perceived"):
        brain.decide(forged, [Hypothesis("u", "s", 0.5, 0.9, ("e",), (), "UP")], evidence=[Evidence("e", "a", "u", 0.5)])
    subset = WorldState(1000, tuple(rich(1000))[:1], "UNKNOWN", 0.3, ())  # cherry-picked inputs
    with pytest.raises(PermissionError, match="perceived"):
        brain.decide(subset, [])
    state = brain.perceive(rich(1000), as_of_ms=1000)
    t = brain.decide(state, [Hypothesis("u", "s", 0.5, 0.9, ("eu",), (), "UP")], evidence=[Evidence("eu", "a1000", "u", 0.5)], horizon_ms=H)
    assert brain.replay_decision(t.trace_id) == t
    assert brain.record_outcome(done(t, -0.01, "LOSS")).blamed_sources == ("a",)
    with pytest.raises(MemoryConflict):
        brain.perceive([obs("a1000", 1000, {"US10Y_REAL": 0.9}, "a")], as_of_ms=1000)  # same id, different content


# --------------------------------- final adversarial round (Stage 1 hardening)

import sqlite3
import threading

from trading_ai.unified_brain import DecisionDomain, NO_DIRECTION


def test_reasoning_core_is_domain_neutral():
    weather = DecisionDomain("GARDEN", "SOIL_MOISTURE", {"UP": "SKIP_WATERING", "DOWN": "WATER"}, "OBSERVE")
    brain = UnifiedBrain(domain=weather)
    rain = [CausalLink("rain", "RAIN_MM", 1, 0.32, ("RAIN", "SOIL_MOISTURE"))]
    case = lambda src, at: [obs(f"{src}{at}", at, {"RAIN_MM": 3.0}, src), obs(f"x{at}", at, {"SUN": 1}, "b"), obs(f"y{at}", at, {"SUN": 1}, "c")]
    t = brain.think(case("gauge", 1000), as_of_ms=1000, links=rain, horizon_ms=H)
    assert t.action == "SKIP_WATERING" and t.direction == "UP" and t.domain == "GARDEN"
    assert all("XAU" not in h for h in brain.memory.get("decision_input", t.trace_id)["evaluated"][0]["statement"].split())
    lesson = brain.record_outcome(done(t, -0.02, "DRIED_OUT"))
    assert lesson.blamed_sources == ("gauge",)
    proposal = brain.propose_challenger(lesson)
    report = brain.validate_challenger(proposal, [(case("gauge", at), rain, at, -0.01) for at in (1000 + (2 + i) * H for i in range(25))])
    accepted = brain.accept_challenger(proposal, report, approved_by="gardener")
    later = brain.think(case("gauge", 1000 + 40 * H), as_of_ms=1000 + 40 * H, links=rain)
    assert later.action == "OBSERVE" and later.policy_version == accepted.version and brain.replay_decision(later.trace_id) == later
    with pytest.raises(MemoryConflict):
        UnifiedBrain(brain.memory).replay_decision(t.trace_id)  # read with the trading domain: refused, not reinterpreted
    with pytest.raises(ValueError):
        DecisionDomain("X", "T", {"UP": "A", "DOWN": "A"}).validate()
    # No trading vocabulary inside the reasoning core (the default domain is chosen only in __init__).
    tree = ast.parse(Path(__file__).resolve().parents[1].joinpath("unified_brain.py").read_text())
    core = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "UnifiedBrain")
    body = [m for m in core.body if not (isinstance(m, ast.FunctionDef) and m.name == "__init__")]
    words = {n.value for m in body for n in ast.walk(m) if isinstance(n, ast.Constant) and isinstance(n.value, str)}
    refs = {n.id for m in body for n in ast.walk(m) if isinstance(n, ast.Name)}
    assert not {w for w in words if any(k in w for k in ("BUY", "SELL", "XAU"))}, words
    assert not refs & {"DecisionAction", "XAUUSD_DOMAIN", "MarketSnapshot", "AnalystContext"}


def _loop(brain, at=1000):
    """One complete governed cycle; every step is idempotent when re-run on the same memory."""
    t = brain.think(bad_case("bad", at), as_of_ms=at, links=WEAK, horizon_ms=H)
    lesson = brain.record_outcome(done(t, -0.02, "LOSS"))
    try:
        proposal = brain.propose_challenger(lesson)
    except MemoryConflict:
        return t, lesson, None, None  # the lesson is already applied: nothing left to redo
    report = brain.validate_challenger(proposal, held_out("bad", at + 2 * H))
    brain.accept_challenger(proposal, report, approved_by="council")
    return t, lesson, proposal, report


def _rows(path):
    with sqlite3.connect(path) as c:
        return sorted(c.execute("SELECT kind, key, payload FROM brain_memory").fetchall())


class Crash(Exception):
    pass


class CrashAfter(SQLiteMemoryStore):
    """Simulates the process dying right after a write of ``kind`` was committed."""

    def __init__(self, path, kind):
        super().__init__(path)
        self.kind, self.fired = kind, False

    def put_many(self, items):
        super().put_many(items)
        if not self.fired and any(k == self.kind for k, _, _ in items):
            self.fired = True
            raise Crash(self.kind)


@pytest.mark.parametrize("kind", ["observation", "world_state", "decision", "outcome", "challenger", "validation", "policy_event"])
def test_crash_after_any_write_recovers_without_duplicates(kind, tmp_path):
    clean = str(tmp_path / "clean.db")
    _loop(UnifiedBrain(SQLiteMemoryStore(clean)))
    crashed = str(tmp_path / "crashed.db")
    with pytest.raises(Crash):
        _loop(UnifiedBrain(CrashAfter(crashed, kind)))
    resumed = UnifiedBrain(SQLiteMemoryStore(crashed))  # restart: integrity chain + policy history verified
    _loop(resumed)  # re-running the whole process is idempotent
    _loop(UnifiedBrain(SQLiteMemoryStore(crashed)))  # and so is a second re-run
    assert _rows(crashed) == _rows(clean), "same records as an uninterrupted run: nothing lost, nothing doubled"
    assert [e["active"] for e in resumed.memory.list_kind("policy_event")][0] == "policy-v1"
    assert len(resumed.memory.list_kind("policy_event")) == 2


def test_writes_are_atomic_and_serialized_across_connections(tmp_path):
    store = SQLiteMemoryStore()
    store.put("k", "taken", {"v": 1})
    with pytest.raises(MemoryConflict):
        store.put_many([("k", "new", {"v": 1}), ("k", "taken", {"v": 2})])
    assert store.get("k", "new") is None, "a failed batch leaves nothing behind"
    path = str(tmp_path / "shared.db")
    SQLiteMemoryStore(path)
    errors = []

    def writer(i):
        st = SQLiteMemoryStore(path)
        for k in range(150):
            try:
                st.put("same", str(k), {"v": k})  # identical records from every writer
                st.put("own", f"{i}:{k}", {"v": k})
            except Exception as exc:  # noqa: BLE001 - the test records any failure
                errors.append(repr(exc))

    threads = [threading.Thread(target=writer, args=(i,)) for i in range(4)]
    [t.start() for t in threads]
    [t.join() for t in threads]
    assert errors == []
    final = SQLiteMemoryStore(path)
    final.verify()
    assert len(final.list_kind("same")) == 150 and len(final.list_kind("own")) == 600


def test_concurrent_acceptances_admit_exactly_one(tmp_path):
    path = str(tmp_path / "race.db")
    brain = UnifiedBrain(SQLiteMemoryStore(path))
    pa = brain.propose_challenger(lesson_blaming(brain, "bad", 1000))
    pb = brain.propose_challenger(lesson_blaming(brain, "worse", 1000 + 2 * H))
    ra = brain.validate_challenger(pa, held_out("bad", 1000 + 4 * H))
    rb = brain.validate_challenger(pb, held_out("worse", 1000 + 4 * H))
    barrier, results = threading.Barrier(2), {}

    def accept(name, proposal, report):
        b = UnifiedBrain(SQLiteMemoryStore(path))  # one brain per thread (documented concurrency model)
        barrier.wait()
        try:
            results[name] = b.accept_challenger(proposal, report, approved_by=name).version
        except (MemoryConflict, PermissionError) as exc:
            results[name] = type(exc).__name__
        except Exception as exc:  # noqa: BLE001 - an unexpected error must fail the test, not vanish in the thread
            results[name + "!"] = repr(exc)

    threads = [threading.Thread(target=accept, args=("a", pa, ra)), threading.Thread(target=accept, args=("b", pb, rb))]
    [t.start() for t in threads]
    [t.join() for t in threads]
    assert set(results) == {"a", "b"}, "both racers finished with a result or a clean refusal (no crash)"
    winners = [v for v in results.values() if v.startswith("challenger-")]
    assert len(winners) == 1, results
    after = UnifiedBrain(SQLiteMemoryStore(path))
    assert [e["active"] for e in after.memory.list_kind("policy_event")] == ["policy-v1", winners[0]]
    seen = []

    def misuse():
        try:
            after.memory.get("policy", "policy-v1")
        except sqlite3.ProgrammingError as exc:
            seen.append(exc)

    worker = threading.Thread(target=misuse)
    worker.start()
    worker.join()
    assert len(seen) == 1, "documented limitation: an instance is bound to its thread; sharing it fails loudly"


def test_memory_integrity_chain_refuses_edits_reorders_gaps_and_corruption(tmp_path):
    def fresh():
        path = str(tmp_path / f"m{len(list(tmp_path.iterdir()))}.db")
        _loop(UnifiedBrain(SQLiteMemoryStore(path)))
        return path

    attacks = {
        "edit an unused record": "UPDATE brain_memory SET payload=replace(payload,'INITIAL','EDITED') WHERE kind='policy_event'",
        "corrupt payload": "UPDATE brain_memory SET payload='{broken' WHERE seq=3",
        "reorder": "UPDATE brain_memory SET seq=-seq WHERE seq IN (2,3); UPDATE brain_memory SET seq=CASE seq WHEN -2 THEN 3 ELSE 2 END WHERE seq<0",
        "delete in the middle": "DELETE FROM brain_memory WHERE seq=4",
        "delete the latest policy event": "DELETE FROM brain_memory WHERE kind='policy_event' AND key='0002'",
    }
    for name, sql in attacks.items():
        path = fresh()
        with sqlite3.connect(path) as c:
            c.executescript(sql)
        with pytest.raises(MemoryConflict):
            UnifiedBrain(SQLiteMemoryStore(path))
    legacy = str(tmp_path / "legacy.db")
    with sqlite3.connect(legacy) as c:
        c.execute("CREATE TABLE brain_memory (kind TEXT, key TEXT, payload TEXT, seq INTEGER, PRIMARY KEY(kind, key))")
    with pytest.raises(MemoryConflict, match="predates"):
        SQLiteMemoryStore(legacy)


def test_future_policy_never_reaches_an_earlier_decision():
    brain = UnifiedBrain()
    before = brain.think(rich(1000 + 100 * H), as_of_ms=1000 + 100 * H, links=LINKS)  # a later as_of, decided before acceptance
    proposal = brain.propose_challenger(lesson_blaming(brain, "bad", 1000))
    report = brain.validate_challenger(proposal, held_out("bad", 1000 + 2 * H))
    assert report.knowledge_until_ms == 1000 + 26 * H + H
    with pytest.raises(LeakageError, match="take effect"):
        brain.accept_challenger(proposal, report, approved_by="council", effective_from_ms=1000 + 3 * H)
    new = brain.accept_challenger(proposal, report, approved_by="council")
    past = brain.think(rich(500), as_of_ms=500, links=LINKS)
    assert past.policy_version == "policy-v1", "a policy learned from later outcomes cannot govern an earlier decision"
    assert brain.policy_at(1000 + 27 * H - 1).version == "policy-v1" and brain.policy_at(1000 + 27 * H) == new
    assert brain.replay_decision(before.trace_id) == before, "decisions made under the policy then in effect still replay"
    assert brain.replay_decision(past.trace_id) == past


def test_pit_adversarial_across_the_loop(tmp_path):
    path = str(tmp_path / "pit.db")
    b1 = UnifiedBrain(SQLiteMemoryStore(path))
    b1.perceive([obs("future", 10**9, {"DXY": -1}, "a")], as_of_ms=10**9)  # memory already holds a far-future input
    b2 = UnifiedBrain(SQLiteMemoryStore(path))  # restart with future data present
    state = b2.perceive(rich(1000), as_of_ms=1000)
    assert "future" not in {o.observation_id for o in state.observations}
    with pytest.raises(LeakageError):
        b2.evaluate(state, [Hypothesis("h", "s", 0.5, 0.5, ("e",), (), "UP")], [Evidence("e", "future", "h", 0.9)])  # future evidence
    t = b2.think([], as_of_ms=1000, links=LINKS)
    b2.perceive([obs("backfill", 900, {"DXY": -1}, "late")], as_of_ms=1000)  # correct timestamp, recorded after the decision
    assert b2.replay_decision(t.trace_id) == t and "backfill" not in t.observation_ids
    t_again = b2.think([], as_of_ms=1000, links=LINKS)
    assert "backfill" in t_again.observation_ids and t_again.trace_id != t.trace_id
    tiny = UnifiedBrain(SQLiteMemoryStore(path), working_capacity=2)  # future inputs fill a small working memory
    assert tiny.think([], as_of_ms=1000, links=LINKS).reason == "UNCERTAINTY_TOO_HIGH"


def _mutation_target():
    store = SQLiteMemoryStore()
    brain = UnifiedBrain(store)
    t = brain.think(rich(1000), [Hypothesis("u", "s", 0.5, 0.5, ("eu",), (), "UP")], [Evidence("eu", "a1000", "u", 0.3)],
                    as_of_ms=1000, links=LINKS)
    assert t.action is DecisionAction.BUY
    return store, brain, t


@pytest.mark.parametrize("kind,key,old,new", [
    ("observation", "b1000", '"DXY":-0.2', '"DXY":-0.3'),
    ("decision_input", None, '"strength":0.3', '"strength":0.9'),
    ("decision_input", None, '"prior":0.5', '"prior":0.4'),
    ("decision_input", None, '"sign":-1', '"sign":1'),
    ("policy", "policy-v1", '"conflict_margin":0.1', '"conflict_margin":0.2'),
    ("decision", None, '"threshold":0.65', '"threshold":0.7'),
    ("world_state", "STATE", '"uncertainty":0.3', '"uncertainty":0.2'),
    ("world_state", "STATE", '["a1000","b1000","c1000"]', '["c1000","b1000","a1000"]'),
    ("DELETE", "c1000", None, None),
])
def test_replay_detects_every_single_mutation(kind, key, old, new):
    store, brain, t = _mutation_target()
    assert brain.replay_decision(t.trace_id) == t
    key = {None: t.trace_id, "STATE": t.state_hash}.get(key, key)
    if kind == "DELETE":
        store.db.execute("DELETE FROM brain_memory WHERE kind='observation' AND key=?", (key,))
    else:
        before = store.get(kind, key)
        tamper(store, kind, key, old, new)
        assert store.get(kind, key) != before, "the mutation must actually change the record"
    with pytest.raises(MemoryConflict):
        brain.replay_decision(t.trace_id)


def test_identical_decisions_are_idempotent_and_distinct_inputs_never_share_an_id():
    store, brain, t = _mutation_target()
    rows = store.db.execute("SELECT COUNT(*) FROM brain_memory").fetchone()[0]
    again = brain.think(rich(1000), [Hypothesis("u", "s", 0.5, 0.5, ("eu",), (), "UP")], [Evidence("eu", "a1000", "u", 0.3)],
                        as_of_ms=1000, links=LINKS)
    assert again == t and store.db.execute("SELECT COUNT(*) FROM brain_memory").fetchone()[0] == rows
    variants = [
        brain.think([], [Hypothesis("u", "s", 0.5, 0.5, ("eu",), (), "UP")], [Evidence("eu", "a1000", "u", 0.31)], as_of_ms=1000, links=LINKS),
        brain.think([], [Hypothesis("u", "s", 0.5, 0.5, ("eu",), (), "UP")], [Evidence("eu", "b1000", "u", 0.3)], as_of_ms=1000, links=LINKS),
        brain.think([], as_of_ms=1000, links=LINKS),
        brain.think([], as_of_ms=1000, links=LINKS, horizon_ms=2 * H),
        brain.think([], as_of_ms=1000, links=LINKS, minimum_confidence=0.7),
        brain.think([], as_of_ms=1000, links=LINKS[:1]),
    ]
    assert len({t.trace_id, *(v.trace_id for v in variants)}) == 1 + len(variants)


def test_confidence_cannot_be_raised_by_editing_input_objects():
    brain = UnifiedBrain()
    state = brain.perceive(rich(1000), as_of_ms=1000)
    ev = Evidence("e", "a1000", "h", 0.3)
    base = brain.evaluate(state, [Hypothesis("h", "s", 0.5, 0.5, ("e",), (), "UP")], [ev])[0][0].confidence
    inflated = [
        brain.evaluate(state, [Hypothesis("h", "s", 0.5, 0.99, ("e",), (), "UP")], [ev]),  # claimed confidence
        brain.evaluate(state, [Hypothesis("h", "s", 1.0, 0.5, ("e",), (), "UP")], [ev]),  # claimed prior
        brain.evaluate(state, [Hypothesis("h", "s", 0.5, 0.5, ("e", "e"), (), "UP")], [ev]),  # cited twice
        brain.evaluate(state, [Hypothesis("h", "s", 0.5, 0.5, ("e", "e2"), (), "UP")], [ev, Evidence("e2", "a1000", "h", 0.3)]),  # same observation again
    ]
    assert all(r[0][0].confidence == pytest.approx(base) for r in inflated)
    distrust = UnifiedBrain(initial_policy=ReasoningPolicy(source_reliability={"a": 0.2}))
    s2 = distrust.perceive(rich(1000), as_of_ms=1000)
    assert distrust.evaluate(s2, [Hypothesis("h", "s", 0.5, 0.5, ("e",), (), "UP")], [Evidence("e", "a1000", "h", 0.3, reliability=1.0)])[0][0].confidence \
        == pytest.approx(0.5 + 0.5 * 0.3 * 0.2), "claimed reliability is capped by policy"
    for bad in ([Evidence("e", "a1000", "h", 0.3, source="b")], [ev, ev], [Evidence("e", "a1000", "other", 0.3)]):
        with pytest.raises(ValueError):
            brain.evaluate(state, [Hypothesis("h", "s", 0.5, 0.5, ("e",), (), "UP")], bad)
    with pytest.raises(ValueError, match="duplicate hypothesis"):
        brain.evaluate(state, [Hypothesis("h", "s", 0.5, 0.5, (), (), "UP"), Hypothesis("h", "s", 0.5, 0.5, (), (), "DOWN")], [])
    with pytest.raises(ValueError, match="non-finite"):
        brain.perceive([obs("nan", 1000, {"DXY": float("nan")})], as_of_ms=1000)
    lax = UnifiedBrain(initial_policy=ReasoningPolicy(minimum_confidence=0.5))
    s3 = lax.perceive(rich(1000), as_of_ms=1000)
    assert lax.decide(s3, [Hypothesis("h", "s", 1.0, 1.0, direction="UP")]).direction == NO_DIRECTION, "no positive evidence -> WAIT"


def test_outcome_and_lesson_provenance_cannot_be_borrowed_or_forged():
    brain = UnifiedBrain()
    l1 = lesson_blaming(brain, "bad", 1000)
    l2 = lesson_blaming(brain, "worse", 1000 + 2 * H)
    borrowed = Lesson(**{**asdict(l2), "lesson_id": "borrowed", "trace_id": l1.trace_id})  # another decision's outcome
    brain.memory.put("lesson", "borrowed", asdict(borrowed))
    with pytest.raises(PermissionError, match="does not follow"):
        brain.propose_challenger(borrowed)
    tamper(brain.memory, "lesson", l1.lesson_id, "LOSS", "WIN")  # a lesson edited after creation
    edited = Lesson(**{**brain.memory.get("lesson", l1.lesson_id), "causal_path": l1.causal_path, "blamed_sources": l1.blamed_sources})
    with pytest.raises(PermissionError, match="does not follow"):
        brain.propose_challenger(edited)
    with pytest.raises(MemoryConflict):
        brain.record_outcome(Outcome(l2.trace_id, 1000 + 3 * H, "WIN", 0.05, observed_at_ms=1000 + 3 * H, available_at_ms=1000 + 3 * H))
    t = brain.think(rich(1000 + 10 * H), as_of_ms=1000 + 10 * H, links=LINKS, horizon_ms=H)
    unresolved = brain.record_outcome(done(t, None, "PENDING"))
    with pytest.raises(ValueError, match="nothing to learn"):
        brain.propose_challenger(unresolved)
    t2 = brain.think(rich(1000 + 20 * H), as_of_ms=1000 + 20 * H, links=LINKS, horizon_ms=H)
    with pytest.raises(ValueError, match="nothing to learn"):
        brain.propose_challenger(brain.record_outcome(done(t2, 0.02, "WIN")))
    with pytest.raises(ValueError, match="finite"):
        t3 = brain.think(rich(1000 + 30 * H), as_of_ms=1000 + 30 * H, links=LINKS, horizon_ms=H)
        brain.record_outcome(done(t3, float("inf"), "X"))


def test_challenger_from_another_policy_line_is_refused():
    brain = UnifiedBrain()
    lesson = lesson_blaming(brain, "bad", 1000)
    foreign_parent = ReasoningPolicy(version="foreign-v1", minimum_confidence=0.6)
    foreign = UnifiedBrain._derive_challenger(lesson, foreign_parent)  # genuine lesson, parent outside this history
    brain.memory.put("challenger", foreign.challenger_version, asdict(foreign))
    with pytest.raises(PermissionError, match="parent policy"):
        brain.validate_challenger(foreign, held_out("bad", 1000 + 2 * H))
    brain.memory.put("policy", foreign_parent.version, asdict(foreign_parent))  # smuggle the parent in as well
    with pytest.raises(MemoryConflict, match="without its activation event"):
        _ = brain.active_policy


def test_one_lesson_is_applied_at_most_once():
    brain = UnifiedBrain()
    lesson = lesson_blaming(brain, "bad", 1000)
    proposal = brain.propose_challenger(lesson)
    assert brain.propose_challenger(lesson) == proposal, "re-proposing against the same champion is idempotent"
    brain.accept_challenger(proposal, brain.validate_challenger(proposal, held_out("bad", 1000 + 2 * H)), approved_by="council")
    with pytest.raises(MemoryConflict, match="already applied"):
        brain.propose_challenger(lesson)  # would reduce 'bad' again: 0.9 -> 0.8 from the same single loss
    assert brain.active_policy.reliability("bad") == 0.9
