from datetime import datetime, timezone
import math

from trading_ai.features import FEATURE_VECTOR_VERSION
from trading_ai.session_context import session_context, session_features


def _ms(year: int, month: int, day: int, hour: int, minute: int = 0) -> int:
    return int(datetime(year, month, day, hour, minute, tzinfo=timezone.utc).timestamp() * 1000)


def test_feature_vector_is_explicitly_versioned_for_session_aware_shadow_ai():
    assert FEATURE_VECTOR_VERSION == "TRADING_AI_FEATURE_VECTOR_V4_ANCHORED_PRICE"


def test_winter_sessions_and_london_new_york_overlap():
    asia = session_context(_ms(2026, 1, 15, 1))
    assert asia.active_sessions == ("ASIA",)
    assert asia.features["session_asia"] == 1.0
    assert asia.features["session_london"] == 0.0
    assert asia.features["session_new_york"] == 0.0

    overlap = session_context(_ms(2026, 1, 15, 14))
    assert overlap.active_sessions == ("LONDON", "NEW_YORK")
    assert overlap.features["session_london_new_york_overlap"] == 1.0
    assert overlap.features["session_active_count"] == 2.0


def test_summer_dst_shifts_london_and_new_york_one_hour_earlier_utc():
    london_open = session_context(_ms(2026, 7, 15, 7))
    assert london_open.london_dst is True
    assert london_open.features["session_london"] == 1.0
    assert london_open.active_sessions == ("ASIA", "LONDON")

    ny_open = session_context(_ms(2026, 7, 15, 12))
    assert ny_open.new_york_dst is True
    assert ny_open.features["session_new_york"] == 1.0
    assert ny_open.features["session_london_new_york_overlap"] == 1.0


def test_exact_winter_session_boundaries_are_half_open():
    assert session_context(_ms(2026, 1, 15, 0)).features["session_asia"] == 1.0
    assert session_context(_ms(2026, 1, 15, 8, 59)).features["session_asia"] == 1.0
    assert session_context(_ms(2026, 1, 15, 9)).features["session_asia"] == 0.0

    assert session_context(_ms(2026, 1, 15, 8)).features["session_london"] == 1.0
    assert session_context(_ms(2026, 1, 15, 16, 59)).features["session_london"] == 1.0
    assert session_context(_ms(2026, 1, 15, 17)).features["session_london"] == 0.0

    assert session_context(_ms(2026, 1, 15, 13)).features["session_new_york"] == 1.0
    assert session_context(_ms(2026, 1, 15, 21, 59)).features["session_new_york"] == 1.0
    assert session_context(_ms(2026, 1, 15, 22)).features["session_new_york"] == 0.0


def test_exact_summer_session_boundaries_are_half_open():
    assert session_context(_ms(2026, 7, 15, 7)).features["session_london"] == 1.0
    assert session_context(_ms(2026, 7, 15, 16)).features["session_london"] == 0.0
    assert session_context(_ms(2026, 7, 15, 12)).features["session_new_york"] == 1.0
    assert session_context(_ms(2026, 7, 15, 21)).features["session_new_york"] == 0.0


def test_2026_dst_transition_instants_are_deterministic():
    london_before = session_context(_ms(2026, 3, 29, 0, 59))
    london_after = session_context(_ms(2026, 3, 29, 1, 0))
    assert london_before.london_dst is False
    assert london_after.london_dst is True

    ny_before = session_context(_ms(2026, 3, 8, 6, 59))
    ny_after = session_context(_ms(2026, 3, 8, 7, 0))
    assert ny_before.new_york_dst is False
    assert ny_after.new_york_dst is True


def test_all_uk_us_dst_state_combinations_are_representable():
    both_off = session_context(_ms(2026, 1, 15, 14))
    assert (both_off.london_dst, both_off.new_york_dst) == (False, False)

    us_only = session_context(_ms(2026, 3, 20, 12, 30))
    assert (us_only.london_dst, us_only.new_york_dst) == (False, True)

    both_on = session_context(_ms(2026, 7, 15, 13))
    assert (both_on.london_dst, both_on.new_york_dst) == (True, True)

    # In 2006 the UK entered DST before the US under the pre-2007 US rule.
    uk_only = session_context(_ms(2006, 3, 30, 13))
    assert (uk_only.london_dst, uk_only.new_york_dst) == (True, False)


def test_transition_weeks_keep_london_and_new_york_dst_independent():
    march_gap = session_context(_ms(2026, 3, 20, 12, 30))
    assert march_gap.active_sessions == ("LONDON", "NEW_YORK")
    assert march_gap.features["session_london_new_york_overlap"] == 1.0

    october_gap = session_context(_ms(2026, 10, 28, 12, 30))
    assert october_gap.london_dst is False
    assert october_gap.new_york_dst is True
    assert october_gap.active_sessions == ("LONDON", "NEW_YORK")


def test_2007_us_dst_rule_change_is_applied():
    # 2006: US still used the first-Sunday-in-April rule.
    assert session_context(_ms(2006, 3, 20, 13)).new_york_dst is False
    # 2007: Energy Policy Act rule makes the second Sunday in March the start.
    assert session_context(_ms(2007, 3, 20, 13)).new_york_dst is True


def test_leap_year_dst_calculation_remains_valid():
    for year in (2004, 2008, 2012, 2016, 2020, 2024):
        winter = session_context(_ms(year, 2, 29, 14))
        assert winter.london_dst is False
        assert winter.new_york_dst is False
        assert winter.features["session_london"] == 1.0


def test_overlap_windows_follow_independent_dst_states():
    winter = session_context(_ms(2026, 1, 15, 13))
    assert winter.features["session_london_new_york_overlap"] == 1.0
    assert session_context(_ms(2026, 1, 15, 17)).features["session_london_new_york_overlap"] == 0.0

    summer = session_context(_ms(2026, 7, 15, 12))
    assert summer.features["session_london_new_york_overlap"] == 1.0
    assert session_context(_ms(2026, 7, 15, 16)).features["session_london_new_york_overlap"] == 0.0


def test_session_features_are_finite_timestamp_only_model_inputs():
    values = session_features(_ms(2026, 9, 4, 15, 30))
    expected = {
        "session_asia",
        "session_london",
        "session_new_york",
        "session_asia_london_overlap",
        "session_london_new_york_overlap",
        "session_active_count",
        "session_off_hours",
        "session_asia_progress",
        "session_london_progress",
        "session_new_york_progress",
        "session_london_dst",
        "session_new_york_dst",
        "session_utc_hour_sin",
        "session_utc_hour_cos",
        "session_weekday_sin",
        "session_weekday_cos",
    }
    assert set(values) == expected
    assert all(math.isfinite(value) for value in values.values())
    assert all("future" not in key.lower() for key in values)
    for name in ("session_asia_progress", "session_london_progress", "session_new_york_progress"):
        assert 0.0 <= values[name] < 1.0


def test_same_timestamp_is_bitwise_deterministic_at_python_float_level():
    ts = _ms(2026, 9, 4, 15, 30)
    first = session_features(ts)
    for _ in range(20):
        assert session_features(ts) == first


def test_invalid_timestamp_fails_closed():
    for value in (0, -1):
        try:
            session_context(value)
        except ValueError:
            pass
        else:
            raise AssertionError("non-positive timestamps must fail closed")
