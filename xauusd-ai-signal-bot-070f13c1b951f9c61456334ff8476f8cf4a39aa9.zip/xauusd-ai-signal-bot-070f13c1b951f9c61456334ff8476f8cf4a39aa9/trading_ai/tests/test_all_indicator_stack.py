from __future__ import annotations

import math

from trading_ai.all_indicator_stack import (
    INDICATOR_FAMILY_FEATURE_KEYS,
    INDICATOR_ROLE_MAP,
    build_all_indicator_feature_vector,
    timeframe_all_indicator_features,
)
from trading_ai.dataset import Candle
from trading_ai.indicator_universe import BROKER_TICK_VOLUME_PROVENANCE, INDICATOR_FAMILY_IDS
from trading_ai.mtf import MTFContext


def _candles(count: int = 320, *, step_ms: int = 60_000, start_ms: int = 1_700_000_000_000):
    rows = []
    for index in range(count):
        trend = index * 0.08
        wave = ((index % 17) - 8) * 0.015
        close = 2000.0 + trend + wave
        open_ = close - (0.03 if index % 2 == 0 else -0.02)
        rows.append(
            Candle(
                timestamp_ms=start_ms + index * step_ms,
                open=open_,
                high=max(open_, close) + 0.25,
                low=min(open_, close) - 0.23,
                close=close,
                volume=100.0 + (index % 11),
            )
        )
    return tuple(rows)


def test_every_current_indicator_family_is_present_simultaneously():
    values = timeframe_all_indicator_features(
        _candles(),
        prefix="m1",
        volume_provenance=BROKER_TICK_VOLUME_PROVENANCE,
    )

    # Existing price-action / ATR / structure / anchored-price context remains.
    for key in (
        "m1_body_pct",
        "m1_atr_ready",
        "m1_structure_breakout_up_now",
        "m1_anchored_mean_ready",
        "m1_kaufman_ready",
    ):
        assert key in values

    # The complete Top-10 universe is in the same flat model vector at once.
    for family_id in INDICATOR_FAMILY_IDS:
        slug = family_id.lower()
        assert values[f"m1_{slug}_ready"] == 1.0
        for feature_name in INDICATOR_FAMILY_FEATURE_KEYS[family_id]:
            key = f"m1_{slug}_{feature_name}"
            assert key in values
            assert math.isfinite(float(values[key]))


def test_volume_family_fails_closed_without_provenance_but_schema_stays_stable():
    values = timeframe_all_indicator_features(_candles(), prefix="m1")

    assert values["m1_f10_session_vwap_volume_flow_ready"] == 0.0
    for feature_name in INDICATOR_FAMILY_FEATURE_KEYS["F10_SESSION_VWAP_VOLUME_FLOW"]:
        assert values[f"m1_f10_session_vwap_volume_flow_{feature_name}"] == 0.0

    for family_id in INDICATOR_FAMILY_IDS[:-1]:
        assert values[f"m1_{family_id.lower()}_ready"] == 1.0


def test_short_history_keeps_all_family_keys_but_marks_top10_not_ready():
    values = timeframe_all_indicator_features(_candles(120), prefix="m1")
    assert "m1_body_pct" in values
    for family_id in INDICATOR_FAMILY_IDS:
        assert values[f"m1_{family_id.lower()}_ready"] == 0.0
        for feature_name in INDICATOR_FAMILY_FEATURE_KEYS[family_id]:
            assert f"m1_{family_id.lower()}_{feature_name}" in values


def test_full_mtf_vector_uses_all_families_and_keeps_quote_gate_explicit():
    end = 1_800_000_000_000
    by_tf = {
        "M1": _candles(start_ms=end - 319 * 60_000, step_ms=60_000),
        "M5": _candles(start_ms=end - 319 * 300_000, step_ms=300_000),
        "M15": _candles(start_ms=end - 319 * 900_000, step_ms=900_000),
        "M30": _candles(start_ms=end - 319 * 1_800_000, step_ms=1_800_000),
        "H1": _candles(start_ms=end - 319 * 3_600_000, step_ms=3_600_000),
    }
    context = MTFContext(end_timestamp_ms=end, candles_by_timeframe=by_tf)
    provenance = {timeframe: BROKER_TICK_VOLUME_PROVENANCE for timeframe in by_tf}

    vector = build_all_indicator_feature_vector(
        context,
        volume_provenance_by_timeframe=provenance,
    )

    assert vector.end_timestamp_ms == end
    assert vector.values["sampled_quote_ready"] == 0.0
    assert vector.values["sampled_quote_atr_ready"] == 0.0
    assert "mtf_direction_agreement" in vector.values
    assert "session_london" in vector.values

    for timeframe in ("m1", "m5", "m15", "m30", "h1"):
        assert vector.values[f"{timeframe}_f01_ema_trend_structure_ready"] == 1.0
        assert vector.values[f"{timeframe}_f10_session_vwap_volume_flow_ready"] == 1.0
        assert vector.values[f"{timeframe}_kaufman_ready"] == 1.0


def test_role_map_covers_specialized_evidence_types_without_buy_sell_rules():
    expected_roles = {
        "TREND",
        "MOMENTUM_MEAN_REVERSION",
        "VOLATILITY",
        "STRUCTURE_BREAKOUT",
        "ANCHORED_LEVELS",
        "VOLUME_PROXY",
        "SESSION_TIME",
        "MICROSTRUCTURE",
    }
    assert set(INDICATOR_ROLE_MAP) == expected_roles
    flattened = {item for families in INDICATOR_ROLE_MAP.values() for item in families}
    for family_id in INDICATOR_FAMILY_IDS:
        assert family_id in flattened
