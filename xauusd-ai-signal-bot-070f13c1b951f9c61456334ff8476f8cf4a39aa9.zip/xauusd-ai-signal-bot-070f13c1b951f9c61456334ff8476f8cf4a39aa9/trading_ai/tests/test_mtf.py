import unittest

from trading_ai.dataset import Candle
from trading_ai.mtf import aggregate_closed_candles, build_mtf_context


class MTFTests(unittest.TestCase):
    def _candles(self, n=180):
        rows = []
        base = 1_800_000_000_000
        base -= base % 60_000
        price = 2000.0
        for i in range(n):
            ts = base + i * 60_000
            o = price + i * 0.1
            c = o + 0.05
            rows.append(Candle(ts, o, c + 0.02, o - 0.02, c, 1.0))
        return rows

    def test_partial_higher_tf_is_not_emitted(self):
        candles = self._candles(7)
        out = aggregate_closed_candles(candles, timeframe_minutes=5, as_of_timestamp_ms=candles[-1].timestamp_ms)
        self.assertEqual(len(out), 1)
        self.assertLessEqual(out[-1].timestamp_ms, candles[-1].timestamp_ms)

    def test_gap_invalidates_bucket(self):
        candles = self._candles(10)
        broken = candles[:2] + candles[3:]
        out = aggregate_closed_candles(broken, timeframe_minutes=5, as_of_timestamp_ms=broken[-1].timestamp_ms)
        self.assertEqual(len(out), 1)

    def test_context_contains_no_future_candles(self):
        candles = self._candles(180)
        end = candles[149].timestamp_ms
        ctx = build_mtf_context(candles, end_timestamp_ms=end)
        self.assertEqual(ctx.candles_by_timeframe["M1"][-1].timestamp_ms, end)
        for rows in ctx.candles_by_timeframe.values():
            self.assertTrue(all(c.timestamp_ms <= end for c in rows))

    def test_h1_requires_full_hour(self):
        candles = self._candles(59)
        out = aggregate_closed_candles(candles, timeframe_minutes=60, as_of_timestamp_ms=candles[-1].timestamp_ms)
        self.assertEqual(out, [])


if __name__ == "__main__":
    unittest.main()
