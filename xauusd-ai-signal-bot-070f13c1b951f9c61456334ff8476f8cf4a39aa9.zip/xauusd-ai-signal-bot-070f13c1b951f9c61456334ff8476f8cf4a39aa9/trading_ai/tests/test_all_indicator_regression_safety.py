from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from trading_ai.all_indicator_stack import (
    ALL_INDICATOR_MTF_LOOKBACKS,
    build_all_indicator_mtf_context,
)
from trading_ai.dataset import Candle
from trading_ai.market_structure import wilder_atr
from trading_ai.session_context import session_context
from trading_ai.video_context import fibonacci_ote_features, opening_range_features


MINUTE_MS = 60_000


def _series(count: int, *, start_ms: int) -> tuple[Candle, ...]:
    rows: list[Candle] = []
    price = 2000.0
    for index in range(count):
        drift = 0.02 if index % 7 < 4 else -0.01
        open_ = price
        close = price + drift
        rows.append(
            Candle(
                timestamp_ms=start_ms + index * MINUTE_MS,
                open=open_,
                high=max(open_, close) + 0.15,
                low=min(open_, close) - 0.15,
                close=close,
                volume=100.0 + (index % 13),
            )
        )
        price = close
    return tuple(rows)


def test_all_indicator_context_uses_exact_long_lookbacks_when_history_is_available():
    assert ALL_INDICATOR_MTF_LOOKBACKS == {
        "M1": 400,
        "M5": 320,
        "M15": 320,
        "M30": 320,
        "H1": 320,
    }
    start_ms = int(datetime(2026, 1, 1, tzinfo=timezone.utc).timestamp() * 1000)
    rows = _series(320 * 60, start_ms=start_ms)
    context = build_all_indicator_mtf_context(
        rows,
        end_timestamp_ms=rows[-1].timestamp_ms,
        require_top10_ready=True,
    )
    assert {tf: len(candles) for tf, candles in context.candles_by_timeframe.items()} == {
        "M1": 400,
        "M5": 320,
        "M15": 320,
        "M30": 320,
        "H1": 320,
    }


def test_same_bar_swing_high_and_low_cannot_create_degenerate_fibonacci_leg():
    start_ms = int(datetime(2026, 2, 2, tzinfo=timezone.utc).timestamp() * 1000)
    rows = [
        Candle(start_ms + 0 * MINUTE_MS, 100.0, 102.0, 98.0, 100.0, 10.0),
        Candle(start_ms + 1 * MINUTE_MS, 100.0, 103.0, 97.0, 100.0, 10.0),
        # Strictly above every neighboring high and below every neighboring low:
        # confirmed_swings therefore emits HIGH and LOW at the same pivot index.
        Candle(start_ms + 2 * MINUTE_MS, 100.0, 110.0, 90.0, 100.0, 10.0),
        Candle(start_ms + 3 * MINUTE_MS, 100.0, 103.0, 97.0, 100.0, 10.0),
        Candle(start_ms + 4 * MINUTE_MS, 100.0, 102.0, 98.0, 100.0, 10.0),
        Candle(start_ms + 5 * MINUTE_MS, 100.0, 101.0, 99.0, 100.0, 10.0),
    ]
    features = fibonacci_ote_features(rows, atr_value=2.0)
    assert features["fib_ready"] == 0.0
    assert features["fib_leg_range_atr"] == 0.0
    assert features["fib_ote_zone"] == 0.0


def test_london_opening_range_uses_bst_start_on_exact_2026_dst_transition_day():
    # UK DST starts at 01:00 UTC on 2026-03-29. London therefore opens at
    # 07:00 UTC in this project's session contract, so its 60-minute opening
    # range is complete at the 08:00 decision bar.
    start_ms = int(datetime(2026, 3, 29, 0, 0, tzinfo=timezone.utc).timestamp() * 1000)
    rows = _series(8 * 60 + 1, start_ms=start_ms)
    end_ms = rows[-1].timestamp_ms
    assert datetime.fromtimestamp(end_ms / 1000.0, tz=timezone.utc).hour == 8
    assert session_context(end_ms).london_dst is True
    atr = wilder_atr(rows, 14)
    features = opening_range_features(rows, end_timestamp_ms=end_ms, atr_value=atr)
    assert features["opening_range_london_60m_ready"] == 1.0
    assert features["opening_range_london_30m_ready"] == 1.0
    assert features["opening_range_london_15m_ready"] == 1.0


def test_all_indicator_stack_is_isolated_from_default_and_demo_execution_modules():
    repo_root = Path(__file__).resolve().parents[2]
    targets = [repo_root / "trading_ai" / "features.py"]
    demo_root = repo_root / "demo_mt5_worker"
    if demo_root.exists():
        targets.extend(sorted(demo_root.rglob("*.py")))

    assert targets
    offenders: list[str] = []
    for path in targets:
        text = path.read_text(encoding="utf-8")
        if "all_indicator_stack" in text:
            offenders.append(str(path.relative_to(repo_root)))
    assert offenders == []
