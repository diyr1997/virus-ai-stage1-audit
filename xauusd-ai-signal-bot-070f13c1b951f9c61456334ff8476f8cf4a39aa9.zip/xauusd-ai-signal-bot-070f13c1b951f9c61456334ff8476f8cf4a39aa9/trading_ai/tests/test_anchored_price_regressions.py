import pytest

from trading_ai.anchored_price import (
    AnchoredPriceConfig,
    AnchoredPriceStatus,
    PriceBasis,
    VolumeSemantics,
    WeightingMode,
    anchored_price_result,
)
from trading_ai.dataset import Candle, validate_candles


MINUTE = 60_000


def time_cfg(*, window: int) -> AnchoredPriceConfig:
    return AnchoredPriceConfig(
        weighting=WeightingMode.TIME_WEIGHTED,
        volume_semantics=VolumeSemantics.UNKNOWN,
        price_basis=PriceBasis.TYPICAL_HLC3,
        window_bars=window,
    )


def flat_candle(i: int, price: float) -> Candle:
    return Candle(
        timestamp_ms=(i + 1) * MINUTE,
        open=price,
        high=price,
        low=price,
        close=price,
        volume=1.0,
    )


def test_rolling_window_slope_uses_previous_decisions_own_window():
    # Current 3-bar window at bar 4 is [100, 130, 130] => mean 120.
    # Previous decision's 3-bar window is [100, 100, 130] => mean 110.
    # A truncated current window [100, 130] would incorrectly give 115.
    candles = [
        flat_candle(0, 100.0),
        flat_candle(1, 100.0),
        flat_candle(2, 100.0),
        flat_candle(3, 130.0),
        flat_candle(4, 130.0),
    ]
    validate_candles(candles)
    result = anchored_price_result(candles, atr_value=10.0, config=time_cfg(window=3))
    assert result.status is AnchoredPriceStatus.READY
    assert result.weighted_price == pytest.approx(120.0)
    assert result.previous_weighted_price == pytest.approx(110.0)
    assert result.slope_atr_per_bar == pytest.approx(1.0)


def test_explicit_anchor_slope_keeps_same_anchor_for_previous_decision():
    candles = [
        flat_candle(0, 100.0),
        flat_candle(1, 110.0),
        flat_candle(2, 120.0),
        flat_candle(3, 130.0),
    ]
    validate_candles(candles)
    result = anchored_price_result(
        candles,
        atr_value=10.0,
        config=time_cfg(window=2),
        anchor_index=0,
    )
    assert result.status is AnchoredPriceStatus.READY
    assert result.weighted_price == pytest.approx(115.0)
    assert result.previous_weighted_price == pytest.approx(110.0)
    assert result.slope_atr_per_bar == pytest.approx(0.5)
