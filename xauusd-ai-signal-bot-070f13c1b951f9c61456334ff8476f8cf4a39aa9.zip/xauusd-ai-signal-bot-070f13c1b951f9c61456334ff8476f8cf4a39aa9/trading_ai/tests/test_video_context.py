from __future__ import annotations

from datetime import datetime, timezone

import pytest

from trading_ai.dataset import Candle
from trading_ai.video_context import (
    fibonacci_ote_features,
    opening_range_features,
    time_at_price_proxy_features,
    timed_pullback_hypothesis_features,
    video_method_feature_block,
)


def _m1_rows(count=400, *, start=None):
    start_ms = start or int(datetime(2026, 1, 5, 0, 0, tzinfo=timezone.utc).timestamp() * 1000)
    rows = []
    for index in range(count):
        close = 2000.0 + 0.03 * index + ((index % 13) - 6) * 0.025
        rows.append(
            Candle(
                timestamp_ms=start_ms + index * 60_000,
                open=close - 0.03,
                high=close + 0.22,
                low=close - 0.21,
                close=close,
                volume=100.0,
            )
        )
    return tuple(rows)


def test_fibonacci_ote_uses_only_confirmed_alternating_swing_leg():
    closes = [100, 99, 97, 99, 101, 104, 108, 106, 104, 103, 102]
    rows = tuple(
        Candle(index * 60_000 + 1, close, close + 0.4, close - 0.4, close, 1.0)
        for index, close in enumerate(closes)
    )
    values = fibonacci_ote_features(rows, atr_value=2.0)
    assert values["fib_ready"] == 1.0
    assert values["fib_leg_direction"] == 1.0
    assert values["fib_leg_range_atr"] > 0.0
    assert all(key in values for key in ("fib_dist_050_atr", "fib_dist_0618_atr", "fib_dist_0786_atr", "fib_ote_zone"))


def test_opening_range_becomes_ready_only_after_complete_range():
    rows = _m1_rows(90)
    at_14 = rows[14].timestamp_ms
    before = opening_range_features(rows[:15], end_timestamp_ms=at_14, atr_value=1.0)
    assert before["opening_range_asia_15m_ready"] == 0.0

    at_15 = rows[15].timestamp_ms
    after = opening_range_features(rows[:16], end_timestamp_ms=at_15, atr_value=1.0)
    assert after["opening_range_asia_15m_ready"] == 1.0
    assert after["opening_range_asia_15m_width_atr"] > 0.0
    assert after["opening_range_asia_30m_ready"] == 0.0


def test_timed_pullback_encodes_2_4_5_6h_as_hypotheses_not_rules():
    rows = list(_m1_rows(400))
    # Create one dominant 5-minute upward displacement well inside the search window.
    endpoint = 200
    for index in range(endpoint - 4, endpoint + 1):
        base = rows[index]
        bump = (index - (endpoint - 5)) * 2.0
        close = base.close + bump
        rows[index] = Candle(base.timestamp_ms, close - 0.1, close + 0.3, close - 0.3, close, base.volume)

    values = timed_pullback_hypothesis_features(tuple(rows), atr_value=2.0)
    assert values["timed_impulse_ready"] == 1.0
    assert values["timed_impulse_size_atr"] > 0.0
    for target in (120, 240, 300, 360):
        assert f"timed_impulse_age_minus_{target}m_scaled" in values
    # No hard statement such as 2h=BUY is emitted.
    assert not any("buy" in key.lower() or "sell" in key.lower() for key in values)


def test_time_at_price_is_explicit_proxy_and_finite():
    values = time_at_price_proxy_features(_m1_rows(140), atr_value=1.0)
    assert values["time_at_price_proxy_ready"] == 1.0
    assert 0.0 <= values["time_at_price_proxy_modal_occupancy"] <= 1.0
    assert 0.0 <= values["time_at_price_proxy_entropy"] <= 1.0


def test_combined_video_block_contains_all_currently_computable_video_methods():
    rows = _m1_rows(400)
    values = video_method_feature_block(
        rows,
        atr_value=1.0,
        end_timestamp_ms=rows[-1].timestamp_ms,
    )
    assert "fib_ready" in values
    assert "opening_range_asia_60m_ready" in values
    assert "timed_impulse_ready" in values
    assert "time_at_price_proxy_ready" in values
    assert all(float(value) == pytest.approx(float(value)) for value in values.values())
