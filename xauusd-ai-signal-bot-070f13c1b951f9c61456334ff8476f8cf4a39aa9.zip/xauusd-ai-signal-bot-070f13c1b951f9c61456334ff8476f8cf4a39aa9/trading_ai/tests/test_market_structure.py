from __future__ import annotations

import math

import pytest

from trading_ai.dataset import Candle, validate_candles
from trading_ai.features import FEATURE_VECTOR_VERSION, timeframe_features
from trading_ai.market_structure import (
    ConfirmedSwing,
    MarketStructureConfig,
    _latest_active_breakout_before_current,
    confirmed_swings,
    market_structure_features,
    wilder_atr,
)


MINUTE = 60_000


def candle(i: int, *, open_: float, high: float, low: float, close: float) -> Candle:
    return Candle(
        timestamp_ms=(i + 1) * MINUTE,
        open=open_,
        high=high,
        low=low,
        close=close,
        volume=1.0,
    )


def cfg(*, left: int = 1, right: int = 1, atr_period: int = 14, tolerance: float = 0.15):
    return MarketStructureConfig(
        atr_period=atr_period,
        swing_left=left,
        swing_right=right,
        retest_tolerance_atr=tolerance,
    )


def test_wilder_atr_constant_true_range_is_stable():
    candles = [candle(i, open_=100.0, high=101.0, low=99.0, close=100.0) for i in range(20)]
    validate_candles(candles)
    assert wilder_atr(candles, period=14) == pytest.approx(2.0)


def test_wilder_atr_returns_zero_until_full_warmup_period():
    candles = [candle(i, open_=100.0, high=101.0, low=99.0, close=100.0) for i in range(13)]
    validate_candles(candles)
    assert wilder_atr(candles, period=14) == 0.0
    fourteen = candles + [candle(13, open_=100.0, high=101.0, low=99.0, close=100.0)]
    validate_candles(fourteen)
    assert wilder_atr(fourteen, 14) == pytest.approx(2.0)


def test_wilder_atr_rejects_non_integer_periods_and_bool():
    candles = [candle(0, open_=100.0, high=101.0, low=99.0, close=100.0)]
    with pytest.raises(ValueError):
        wilder_atr(candles, period=True)
    with pytest.raises(ValueError):
        wilder_atr(candles, period=14.5)  # type: ignore[arg-type]


def test_swing_is_not_visible_until_right_side_confirmation_bar_exists():
    first_two = [
        candle(0, open_=1.0, high=2.0, low=0.5, close=1.5),
        candle(1, open_=2.0, high=5.0, low=1.0, close=3.0),
    ]
    validate_candles(first_two)
    assert confirmed_swings(first_two, left=1, right=1) == []
    confirmed_input = first_two + [candle(2, open_=3.0, high=3.5, low=1.5, close=2.5)]
    validate_candles(confirmed_input)
    confirmed = confirmed_swings(confirmed_input, left=1, right=1)
    highs = [item for item in confirmed if item.kind == "HIGH"]
    assert len(highs) == 1
    assert highs[0].index == 1
    assert highs[0].confirmation_index == 2
    assert highs[0].price == pytest.approx(5.0)


def test_equal_high_plateau_is_not_forced_into_an_arbitrary_swing():
    candles = [
        candle(0, open_=1.0, high=2.0, low=0.5, close=1.5),
        candle(1, open_=2.0, high=5.0, low=1.0, close=3.0),
        candle(2, open_=3.0, high=5.0, low=1.5, close=2.5),
        candle(3, open_=2.5, high=3.0, low=1.7, close=2.0),
    ]
    validate_candles(candles)
    assert not [item for item in confirmed_swings(candles, left=1, right=1) if item.kind == "HIGH"]


def _known_high_sequence(*, current_close: float, current_high: float = 106.0, current_low: float = 100.0):
    candles = [
        candle(0, open_=99.0, high=100.0, low=98.0, close=99.0),
        candle(1, open_=100.0, high=105.0, low=99.0, close=102.0),
        candle(2, open_=102.0, high=103.0, low=100.0, close=101.0),
        candle(3, open_=101.0, high=current_high, low=current_low, close=current_close),
    ]
    validate_candles(candles)
    return candles


def _known_low_sequence(*, current_close: float, current_high: float = 100.0, current_low: float = 94.0):
    candles = [
        candle(0, open_=101.0, high=102.0, low=100.0, close=101.0),
        candle(1, open_=100.0, high=101.0, low=95.0, close=98.0),
        candle(2, open_=98.0, high=100.0, low=97.0, close=98.5),
        candle(3, open_=98.5, high=current_high, low=current_low, close=current_close),
    ]
    validate_candles(candles)
    return candles


def test_sweep_rejection_uses_only_a_level_known_before_current_bar():
    values = market_structure_features(_known_high_sequence(current_close=104.0), atr_value=2.0, config=cfg())
    assert values["structure_sweep_high_reject_now"] == 1.0
    assert values["structure_breakout_up_now"] == 0.0
    assert values["structure_sweep_high_depth_atr"] == pytest.approx(0.5)


def test_close_cross_above_confirmed_swing_is_breakout_feature_not_trade_rule():
    values = market_structure_features(
        _known_high_sequence(current_close=106.0, current_high=107.0), atr_value=2.0, config=cfg()
    )
    assert values["structure_breakout_up_now"] == 1.0
    assert values["structure_sweep_high_reject_now"] == 0.0


def test_downside_breakout_and_sweep_are_symmetric():
    breakout = market_structure_features(
        _known_low_sequence(current_close=94.0, current_low=93.0), atr_value=2.0, config=cfg()
    )
    assert breakout["structure_breakout_down_now"] == 1.0
    assert breakout["structure_sweep_low_reject_now"] == 0.0
    sweep = market_structure_features(
        _known_low_sequence(current_close=96.0, current_low=94.0), atr_value=2.0, config=cfg()
    )
    assert sweep["structure_breakout_down_now"] == 0.0
    assert sweep["structure_sweep_low_reject_now"] == 1.0
    assert sweep["structure_sweep_low_depth_atr"] == pytest.approx(0.5)


def test_retest_requires_a_prior_active_breakout_of_an_already_confirmed_level():
    candles = [
        candle(0, open_=99.0, high=100.0, low=98.0, close=99.0),
        candle(1, open_=100.0, high=105.0, low=99.0, close=102.0),
        candle(2, open_=102.0, high=103.0, low=100.0, close=101.0),
        candle(3, open_=101.0, high=107.0, low=101.0, close=106.0),
        candle(4, open_=106.0, high=106.2, low=104.9, close=105.4),
    ]
    validate_candles(candles)
    values = market_structure_features(candles, atr_value=2.0, config=cfg(tolerance=0.10))
    assert values["structure_retest_up_now"] == 1.0
    assert values["structure_bars_since_breakout_up"] == 1.0


def test_downside_retest_requires_prior_active_breakout():
    candles = [
        candle(0, open_=101.0, high=102.0, low=100.0, close=101.0),
        candle(1, open_=100.0, high=101.0, low=95.0, close=98.0),
        candle(2, open_=98.0, high=100.0, low=97.0, close=98.5),
        candle(3, open_=98.5, high=99.0, low=93.0, close=94.0),
        candle(4, open_=94.0, high=95.1, low=93.8, close=94.6),
    ]
    validate_candles(candles)
    values = market_structure_features(candles, atr_value=2.0, config=cfg(tolerance=0.10))
    assert values["structure_retest_down_now"] == 1.0
    assert values["structure_bars_since_breakout_down"] == 1.0


def test_invalidated_breakout_cannot_emit_stale_retest():
    candles = [
        candle(0, open_=99.0, high=100.0, low=98.0, close=99.0),
        candle(1, open_=100.0, high=105.0, low=99.0, close=102.0),
        candle(2, open_=102.0, high=103.0, low=100.0, close=101.0),
        candle(3, open_=101.0, high=107.0, low=101.0, close=106.0),
        candle(4, open_=106.0, high=106.0, low=103.0, close=104.0),
        candle(5, open_=104.0, high=105.1, low=103.9, close=104.9),
    ]
    validate_candles(candles)
    values = market_structure_features(candles, atr_value=2.0, config=cfg(tolerance=0.10))
    assert values["structure_retest_up_now"] == 0.0
    assert values["structure_bars_since_breakout_up"] == 0.0


def test_crossing_before_confirmation_is_ignored_by_active_breakout_state():
    candles = [
        candle(0, open_=100.0, high=101.0, low=99.0, close=100.0),
        candle(1, open_=100.0, high=105.0, low=99.0, close=102.0),
        candle(2, open_=102.0, high=107.0, low=101.0, close=106.0),
        candle(3, open_=106.0, high=106.5, low=103.0, close=104.0),
        candle(4, open_=104.0, high=105.2, low=104.0, close=105.1),
    ]
    validate_candles(candles)
    swing = ConfirmedSwing("HIGH", index=1, confirmation_index=3, price=105.0)
    assert _latest_active_breakout_before_current(candles, swing, direction="UP") is None


def test_swing_confirmed_on_current_bar_is_context_only_not_current_event():
    candles = [
        candle(0, open_=99.0, high=100.0, low=98.0, close=99.0),
        candle(1, open_=100.0, high=105.0, low=99.0, close=102.0),
        candle(2, open_=102.0, high=103.0, low=100.0, close=101.0),
        candle(3, open_=101.0, high=104.0, low=100.0, close=103.0),
    ]
    validate_candles(candles)
    values = market_structure_features(candles, atr_value=2.0, config=cfg(left=1, right=2))
    assert values["structure_has_swing_high"] == 1.0
    assert values["structure_swing_high_age_since_confirmation_bars"] == 0.0
    assert values["structure_breakout_up_now"] == 0.0
    assert values["structure_sweep_high_reject_now"] == 0.0
    assert values["structure_retest_up_now"] == 0.0


def test_primary_swing_age_starts_at_confirmation_not_pivot():
    values = market_structure_features(_known_high_sequence(current_close=104.0), atr_value=2.0, config=cfg())
    confirmation_age = values["structure_swing_high_age_since_confirmation_bars"]
    pivot_age = values["structure_swing_high_age_since_pivot_bars"]
    assert confirmation_age == 1.0
    assert pivot_age == 2.0
    assert pivot_age - confirmation_age == 1.0


def test_retest_tolerance_boundary_is_inclusive_but_just_outside_is_not():
    tolerance = 0.15
    atr = 2.0
    boundary_low = 105.0 + tolerance * atr
    base = [
        candle(0, open_=99.0, high=100.0, low=98.0, close=99.0),
        candle(1, open_=100.0, high=105.0, low=99.0, close=102.0),
        candle(2, open_=102.0, high=103.0, low=100.0, close=101.0),
        candle(3, open_=101.0, high=107.0, low=101.0, close=106.0),
    ]
    at_boundary = base + [candle(4, open_=106.0, high=106.0, low=boundary_low, close=105.5)]
    just_outside = base + [candle(4, open_=106.0, high=106.0, low=boundary_low + 1e-6, close=105.5)]
    validate_candles(at_boundary)
    validate_candles(just_outside)
    assert market_structure_features(at_boundary, atr_value=atr, config=cfg(tolerance=tolerance))[
        "structure_retest_up_now"
    ] == 1.0
    assert market_structure_features(just_outside, atr_value=atr, config=cfg(tolerance=tolerance))[
        "structure_retest_up_now"
    ] == 0.0


def test_latest_confirmed_swing_is_used_for_current_breakout_event():
    candles = [
        candle(0, open_=99.0, high=100.0, low=98.0, close=99.0),
        candle(1, open_=100.0, high=110.0, low=99.0, close=105.0),
        candle(2, open_=100.5, high=101.0, low=98.0, close=100.0),
        candle(3, open_=100.0, high=105.0, low=99.0, close=103.0),
        candle(4, open_=101.0, high=102.0, low=98.0, close=101.0),
        candle(5, open_=101.0, high=107.0, low=100.0, close=106.0),
    ]
    validate_candles(candles)
    values = market_structure_features(candles, atr_value=2.0, config=cfg())
    assert values["structure_breakout_up_now"] == 1.0


def test_zero_atr_sets_not_ready_and_never_propagates_nan_or_inf():
    candles = [candle(i, open_=100.0, high=100.0, low=100.0, close=100.0) for i in range(20)]
    validate_candles(candles)
    values = timeframe_features(candles, prefix="m1")
    assert values["m1_atr_ready"] == 0.0
    assert values["m1_atr_pct"] == 0.0
    assert values["m1_body_atr"] == 0.0
    assert values["m1_range_atr"] == 0.0
    assert all(math.isfinite(float(value)) for value in values.values())


def test_custom_research_config_is_threaded_through_feature_builder():
    candles = [candle(i, open_=100.0, high=101.0, low=99.0, close=100.0) for i in range(5)]
    validate_candles(candles)
    custom = cfg(atr_period=3, left=1, right=1, tolerance=0.25)
    values = timeframe_features(candles, prefix="m1", market_structure_config=custom)
    assert values["m1_atr_ready"] == 1.0
    assert values["m1_atr_pct"] == pytest.approx(0.02)


def test_invalid_research_config_is_rejected():
    with pytest.raises(ValueError):
        MarketStructureConfig(atr_period=0).validate()
    with pytest.raises(ValueError):
        MarketStructureConfig(swing_left=True).validate()
    with pytest.raises(ValueError):
        MarketStructureConfig(retest_tolerance_atr=float("nan")).validate()


def test_feature_integration_is_additive_and_versioned():
    candles = [
        candle(i, open_=100.0, high=101.0, low=99.0, close=100.0 + (0.1 if i % 2 else 0.0))
        for i in range(25)
    ]
    validate_candles(candles)
    values = timeframe_features(candles, prefix="m1")
    assert FEATURE_VECTOR_VERSION == "TRADING_AI_FEATURE_VECTOR_V4_ANCHORED_PRICE"
    assert "m1_body_pct" in values
    assert "m1_atr_ready" in values
    assert "m1_atr_pct" in values
    assert "m1_body_atr" in values
    assert "m1_close_location" in values
    assert "m1_structure_dist_to_swing_high_atr" in values
    assert "m1_structure_sweep_high_reject_now" in values
    assert "m1_structure_swing_high_age_since_confirmation_bars" in values
