import math

import pytest

from trading_ai.dataset import Candle
from trading_ai.kaufman import (
    DEFAULT_KAUFMAN_CONFIG,
    KaufmanConfig,
    KaufmanStatus,
    kaufman_feature_block,
    kaufman_result,
)


MINUTE = 60_000


def flat_candle(i: int, price: float) -> Candle:
    return Candle(
        timestamp_ms=(i + 1) * MINUTE,
        open=price,
        high=price,
        low=price,
        close=price,
        volume=0.0,
    )


def candle(i: int, close: float) -> Candle:
    return Candle(
        timestamp_ms=(i + 1) * MINUTE,
        open=close,
        high=close + 1.0,
        low=close - 1.0,
        close=close,
        volume=0.0,
    )


def cfg(*, n: int = 10, fast: int = 2, slow: int = 30) -> KaufmanConfig:
    return KaufmanConfig(er_period=n, fast_period=fast, slow_period=slow)


def test_default_config_is_versioned_hypothesis_and_valid():
    assert DEFAULT_KAUFMAN_CONFIG == KaufmanConfig(10, 2, 30)
    assert DEFAULT_KAUFMAN_CONFIG.validate() is DEFAULT_KAUFMAN_CONFIG


@pytest.mark.parametrize(
    "config",
    [
        KaufmanConfig(0, 2, 30),
        KaufmanConfig(10, 0, 30),
        KaufmanConfig(10, 2, 0),
        KaufmanConfig(10, 30, 30),
        KaufmanConfig(10, 31, 30),
    ],
)
def test_invalid_config_fails_closed(config: KaufmanConfig):
    with pytest.raises(ValueError):
        config.validate()


def test_exact_known_values_freeze_seed_and_first_updates():
    # n=2 seed at index 1: SMA(100, 102)=101.
    # t=2: ER=|101-100|/(|102-100|+|101-102|)=1/3 and close equals seed,
    # so KAMA remains 101.
    # t=3: ER=2/4=0.5, SC=(0.5*(2/3-2/5)+2/5)^2=(8/15)^2=64/225.
    closes = [100.0, 102.0, 101.0, 104.0]
    candles = [candle(i, value) for i, value in enumerate(closes)]
    result = kaufman_result(candles, atr_value=2.0, config=cfg(n=2, fast=2, slow=4))
    assert result.status is KaufmanStatus.READY
    assert result.first_output_index == 2
    assert result.efficiency_ratio == pytest.approx(0.5)
    assert result.previous_kama == pytest.approx(101.0)
    assert result.kama == pytest.approx(101.0 + (64.0 / 225.0) * 3.0)
    assert result.slope_atr_per_bar == pytest.approx(((64.0 / 225.0) * 3.0) / 2.0)


def test_er_uses_exactly_n_causal_transitions():
    # For n=3 at t=3: change=|104-100|=4; path=|102-100|+|101-102|+|104-101|=6.
    candles = [candle(i, value) for i, value in enumerate([100.0, 102.0, 101.0, 104.0])]
    result = kaufman_result(candles, atr_value=2.0, config=cfg(n=3, fast=2, slow=5))
    assert result.status is KaufmanStatus.READY
    assert result.efficiency_ratio == pytest.approx(4.0 / 6.0)


def test_flat_path_has_zero_efficiency_not_perfect_trend():
    candles = [flat_candle(i, 100.0) for i in range(45)]
    result = kaufman_result(candles, atr_value=1.0)
    assert result.status is KaufmanStatus.READY
    assert result.efficiency_ratio == 0.0
    assert result.kama == pytest.approx(100.0)
    assert result.previous_kama == pytest.approx(100.0)
    assert result.distance_atr == 0.0
    assert result.slope_atr_per_bar == 0.0
    assert result.warmup is False


def test_strict_monotonic_path_has_efficiency_one():
    candles = [candle(i, 100.0 + i) for i in range(45)]
    result = kaufman_result(candles, atr_value=2.0)
    assert result.status is KaufmanStatus.READY
    assert result.efficiency_ratio == pytest.approx(1.0)
    assert result.kama < candles[-1].close
    assert result.kama > candles[-11].close
    assert result.slope_atr_per_bar > 0.0


def test_single_jump_spikes_er_then_decays_when_jump_leaves_window():
    prices = [100.0] * 20 + [110.0] + [110.0] * 12
    at_jump = kaufman_result(
        [flat_candle(i, value) for i, value in enumerate(prices)],
        atr_value=2.0,
        config=cfg(n=10, fast=2, slow=30),
        decision_timestamp_ms=(21 * MINUTE),
    )
    after_window = kaufman_result(
        [flat_candle(i, value) for i, value in enumerate(prices)],
        atr_value=2.0,
        config=cfg(n=10, fast=2, slow=30),
    )
    assert at_jump.status is KaufmanStatus.READY
    assert at_jump.efficiency_ratio == pytest.approx(1.0)
    assert after_window.status is KaufmanStatus.READY
    assert after_window.efficiency_ratio == pytest.approx(0.0)


def test_future_perturbation_after_decision_cannot_change_result():
    base = [candle(i, 100.0 + 0.5 * i) for i in range(50)]
    changed = list(base)
    for i in range(35, 50):
        changed[i] = candle(i, 10_000.0 + i)
    decision = base[34].timestamp_ms
    a = kaufman_result(base, atr_value=2.0, decision_timestamp_ms=decision)
    b = kaufman_result(changed, atr_value=2.0, decision_timestamp_ms=decision)
    assert a == b


def test_decision_timestamp_must_match_closed_bar():
    candles = [candle(i, 100.0 + i) for i in range(20)]
    result = kaufman_result(candles, atr_value=2.0, decision_timestamp_ms=candles[15].timestamp_ms + 1)
    assert result.status is KaufmanStatus.NOT_READY
    assert result.reason == "decision_not_available"


def test_exact_first_output_and_warmup_boundary():
    config = cfg(n=3, fast=2, slow=5)
    too_short = [candle(i, 100.0 + i) for i in range(3)]  # current index 2 < n
    first = [candle(i, 100.0 + i) for i in range(4)]      # current index 3 == n
    before_mature = [candle(i, 100.0 + i) for i in range(8)]  # index 7 < n+slow=8
    mature = [candle(i, 100.0 + i) for i in range(9)]          # index 8

    a = kaufman_result(too_short, atr_value=2.0, config=config)
    b = kaufman_result(first, atr_value=2.0, config=config)
    c = kaufman_result(before_mature, atr_value=2.0, config=config)
    d = kaufman_result(mature, atr_value=2.0, config=config)

    assert a.status is KaufmanStatus.NOT_READY
    assert b.status is KaufmanStatus.READY
    assert b.first_output_index == 3
    assert b.warmup is True
    assert c.warmup is True
    assert d.warmup is False


def test_invalid_or_nonpositive_price_is_not_ready_without_nan():
    candles = [candle(i, 100.0 + i) for i in range(12)]
    candles[-1] = Candle(
        timestamp_ms=candles[-1].timestamp_ms,
        open=0.0,
        high=0.0,
        low=0.0,
        close=0.0,
        volume=0.0,
    )
    result = kaufman_result(candles, atr_value=2.0)
    assert result.status is KaufmanStatus.NOT_READY
    assert result.reason == "invalid_price_input"
    block = kaufman_feature_block(candles, prefix="m1", atr_value=2.0)
    assert all(math.isfinite(float(value)) for value in block.values())


@pytest.mark.parametrize("atr", [None, 0.0, -1.0, float("nan"), float("inf")])
def test_atr_not_ready_fails_closed_with_stable_numeric_features(atr):
    candles = [candle(i, 100.0 + i) for i in range(45)]
    result = kaufman_result(candles, atr_value=atr)
    assert result.status is KaufmanStatus.NOT_READY
    assert result.reason == "atr_not_ready"
    block = kaufman_feature_block(candles, prefix="m1", atr_value=atr)
    assert block["m1_kaufman_ready"] == 0.0
    assert block["m1_kaufman_er"] == 0.0
    assert block["m1_kama_dist_atr"] == 0.0
    assert block["m1_kama_slope_atr_per_bar"] == 0.0
    assert all(math.isfinite(float(value)) for value in block.values())


def test_feature_block_omits_raw_kama_and_deterministic_smoothing_constant():
    candles = [candle(i, 100.0 + i) for i in range(45)]
    block = kaufman_feature_block(candles, prefix="m1", atr_value=2.0)
    assert set(block) == {
        "m1_kaufman_ready",
        "m1_kaufman_warmup",
        "m1_kaufman_er",
        "m1_kama_dist_atr",
        "m1_kama_slope_atr_per_bar",
    }
    assert "m1_kaufman_sc" not in block
    assert "m1_kama" not in block


def test_custom_config_changes_candidate_without_global_state():
    candles = [candle(i, 100.0 + (i % 5) + 0.2 * i) for i in range(60)]
    fast = kaufman_result(candles, atr_value=2.0, config=cfg(n=5, fast=2, slow=20))
    slow = kaufman_result(candles, atr_value=2.0, config=cfg(n=15, fast=3, slow=40))
    again = kaufman_result(candles, atr_value=2.0, config=cfg(n=5, fast=2, slow=20))
    assert fast.status is KaufmanStatus.READY
    assert slow.status is KaufmanStatus.READY
    assert fast == again
    assert (fast.efficiency_ratio, fast.kama) != pytest.approx((slow.efficiency_ratio, slow.kama))


def test_separate_timeframe_calls_are_independent():
    m1 = [candle(i, 100.0 + i) for i in range(45)]
    m5 = [candle(i, 200.0 - 0.5 * i) for i in range(45)]
    a1 = kaufman_feature_block(m1, prefix="m1", atr_value=2.0)
    b = kaufman_feature_block(m5, prefix="m5", atr_value=3.0)
    a2 = kaufman_feature_block(m1, prefix="m1", atr_value=2.0)
    assert a1 == a2
    assert a1["m1_kaufman_er"] == pytest.approx(1.0)
    assert b["m5_kaufman_er"] == pytest.approx(1.0)
    assert a1["m1_kama_slope_atr_per_bar"] > 0.0
    assert b["m5_kama_slope_atr_per_bar"] < 0.0
