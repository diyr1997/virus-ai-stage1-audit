from __future__ import annotations

import math

from trading_ai.dataset import Candle, validate_candles
from trading_ai.features import build_feature_vector
from trading_ai.market_structure import MarketStructureConfig, market_structure_features
from trading_ai.mtf import MTFContext


MINUTE = 60_000


def candle(i: int, *, open_: float, high: float, low: float, close: float) -> Candle:
    return Candle(
        timestamp_ms=(i + 1) * MINUTE,
        open=open_,
        high=high,
        low=low,
        close=close,
        volume=1.0,
    )


def config(*, atr_period: int = 14, tolerance: float = 0.15) -> MarketStructureConfig:
    return MarketStructureConfig(
        atr_period=atr_period,
        swing_left=1,
        swing_right=1,
        retest_tolerance_atr=tolerance,
    )


def test_same_bar_breakout_and_retest_not_both():
    # Swing high 105 is confirmed at bar 2. Bar 3 breaks out. Bar 4 closes
    # exactly on the level, which does not invalidate the prior breakout under
    # the v1 strict close-through rule. Equal highs on bars 3/4 deliberately
    # prevent either from becoming a newer strict pivot. Bar 5 re-crosses above
    # 105 and touches the retest zone; current breakout must suppress retest.
    candles = [
        candle(0, open_=99.0, high=100.0, low=98.0, close=99.0),
        candle(1, open_=100.0, high=105.0, low=99.0, close=102.0),
        candle(2, open_=102.0, high=103.0, low=100.0, close=101.0),
        candle(3, open_=101.0, high=107.0, low=101.0, close=106.0),
        candle(4, open_=106.0, high=107.0, low=104.8, close=105.0),
        candle(5, open_=105.0, high=106.5, low=104.9, close=106.0),
    ]
    validate_candles(candles)
    values = market_structure_features(candles, atr_value=2.0, config=config(tolerance=0.10))
    assert values["structure_breakout_up_now"] == 1.0
    assert values["structure_retest_up_now"] == 0.0


def test_downside_breakout_invalidates_on_close_above_level():
    candles = [
        candle(0, open_=101.0, high=102.0, low=100.0, close=101.0),
        candle(1, open_=100.0, high=101.0, low=95.0, close=98.0),
        candle(2, open_=98.0, high=100.0, low=97.0, close=98.5),  # confirms 95
        candle(3, open_=98.5, high=99.0, low=93.0, close=94.0),  # breakout down
        candle(4, open_=94.0, high=96.2, low=93.8, close=96.0),  # closes above 95 -> invalid
        candle(5, open_=96.0, high=96.1, low=94.9, close=95.1),  # returns near level
    ]
    validate_candles(candles)
    values = market_structure_features(candles, atr_value=2.0, config=config(tolerance=0.10))
    assert values["structure_retest_down_now"] == 0.0
    assert values["structure_bars_since_breakout_down"] == 0.0


def test_build_feature_vector_threads_non_default_market_structure_config():
    candles = tuple(
        candle(i, open_=100.0, high=101.0, low=99.0, close=100.0)
        for i in range(5)
    )
    validate_candles(candles)
    context = MTFContext(end_timestamp_ms=candles[-1].timestamp_ms, candles_by_timeframe={"M1": candles})

    default_vector = build_feature_vector(context)
    custom_vector = build_feature_vector(
        context,
        market_structure_config=config(atr_period=3, tolerance=0.25),
    )
    assert default_vector.values["m1_atr_ready"] == 0.0
    assert custom_vector.values["m1_atr_ready"] == 1.0
    assert custom_vector.values["m1_atr_pct"] == 0.02


def test_atr_not_ready_returns_safe_finite_defaults():
    candles = tuple(
        candle(i, open_=100.0, high=101.0, low=99.0, close=100.0)
        for i in range(5)
    )
    validate_candles(candles)
    context = MTFContext(end_timestamp_ms=candles[-1].timestamp_ms, candles_by_timeframe={"M1": candles})
    vector = build_feature_vector(context)
    assert vector.values["m1_atr_ready"] == 0.0
    for key, value in vector.values.items():
        assert math.isfinite(float(value)), key


def test_same_bar_down_breakout_and_retest_not_both():
    # Downside mirror. Equal lows on bars 3/4 prevent a newer strict swing low,
    # so the current event is tested against the original confirmed level 95.
    candles = [
        candle(0, open_=101.0, high=102.0, low=100.0, close=101.0),
        candle(1, open_=100.0, high=101.0, low=95.0, close=98.0),
        candle(2, open_=98.0, high=100.0, low=97.0, close=98.5),
        candle(3, open_=98.5, high=99.0, low=93.0, close=94.0),
        candle(4, open_=94.0, high=95.2, low=93.0, close=95.0),
        candle(5, open_=95.0, high=95.1, low=93.5, close=94.0),
    ]
    validate_candles(candles)
    values = market_structure_features(candles, atr_value=2.0, config=config(tolerance=0.10))
    assert values["structure_breakout_down_now"] == 1.0
    assert values["structure_retest_down_now"] == 0.0
