from trading_ai.baseline import evaluate, fit_linear_baseline
from trading_ai.dataset import Candle
from trading_ai.pipeline import DEFAULT_HORIZONS, TrainingSample, build_training_samples, chronological_split


MINUTE = 60_000


def _candles(count: int = 3600):
    out = []
    price = 2000.0
    for i in range(count):
        drift = 0.05 if (i // 50) % 2 == 0 else -0.03
        open_ = price
        close = max(1.0, open_ + drift)
        high = max(open_, close) + 0.02
        low = min(open_, close) - 0.02
        out.append(Candle(timestamp_ms=(i + 1) * MINUTE, open=open_, high=high, low=low, close=close, volume=1.0))
        price = close
    return out


def _synthetic_samples(count=1000, horizon=60):
    return [
        TrainingSample(
            end_timestamp_ms=(i + 1) * MINUTE,
            features={"x": float(i)},
            future_returns={horizon: 0.0},
            max_favorable_move={horizon: 0.0},
            max_adverse_move={horizon: 0.0},
        )
        for i in range(count)
    ]


def test_pipeline_is_chronological_and_future_is_not_in_features():
    samples = build_training_samples(_candles(), warmup_m1=3000)
    assert samples
    first = samples[0]
    assert first.end_timestamp_ms == 3000 * MINUTE
    assert DEFAULT_HORIZONS == (1, 3, 5, 10, 15, 30, 60)
    assert set(DEFAULT_HORIZONS).issubset(first.future_returns)
    assert all("future" not in key.lower() for key in first.features)
    train, validation, test = chronological_split(samples)
    assert train and validation and test
    assert train[-1].end_timestamp_ms < validation[0].end_timestamp_ms
    assert validation[-1].end_timestamp_ms < test[0].end_timestamp_ms


def test_purge_equal_to_horizon_is_sufficient_without_off_by_one_overlap():
    # The split uses half-open Python slices. With purge=h:
    # last_train_index = train_end-h-1, so its h-th future target ends at
    # train_end-1; validation starts at train_end. There is no overlap.
    h = 60
    samples = _synthetic_samples(horizon=h)
    train, validation, test = chronological_split(samples, purge_bars=h)
    assert train and validation and test

    train_last_index = train[-1].end_timestamp_ms // MINUTE - 1
    validation_first_index = validation[0].end_timestamp_ms // MINUTE - 1
    validation_last_index = validation[-1].end_timestamp_ms // MINUTE - 1
    test_first_index = test[0].end_timestamp_ms // MINUTE - 1

    assert train_last_index + h < validation_first_index
    assert validation_last_index + h < test_first_index
    # Exact boundary arithmetic: the target window ends one sample before the
    # next feature block begins. h+1 would merely over-purge one extra sample.
    assert train_last_index + h == validation_first_index - 1
    assert validation_last_index + h == test_first_index - 1


def test_purge_smaller_than_horizon_is_rejected():
    samples = _synthetic_samples(horizon=15)
    try:
        chronological_split(samples, purge_bars=14)
    except ValueError as exc:
        assert "purge_bars must be >= maximum label horizon" in str(exc)
    else:
        raise AssertionError("purge<horizon must fail closed")


def test_baseline_fits_train_and_evaluates_unseen_split():
    samples = build_training_samples(_candles(), warmup_m1=3000)
    train, validation, test = chronological_split(samples)
    model = fit_linear_baseline(train, horizon=5)
    validation_metrics = evaluate(model, validation)
    test_metrics = evaluate(model, test)
    assert validation_metrics.samples == len(validation)
    assert test_metrics.samples == len(test)
    assert 0.0 <= validation_metrics.directional_accuracy <= 1.0
    assert 0.0 <= test_metrics.directional_accuracy <= 1.0
