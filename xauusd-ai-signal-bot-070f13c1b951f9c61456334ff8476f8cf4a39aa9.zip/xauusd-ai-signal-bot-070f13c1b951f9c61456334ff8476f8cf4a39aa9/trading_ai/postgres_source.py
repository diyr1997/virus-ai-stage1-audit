from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Iterable

from .dataset import Candle, validate_candles


def _database_url(explicit: str | None = None) -> str:
    url = (explicit or os.getenv("DATABASE_PUBLIC_URL") or os.getenv("DATABASE_URL") or "").strip()
    if not url:
        raise RuntimeError("DATABASE_PUBLIC_URL or DATABASE_URL is required")
    return url


def load_m1_candles(
    *,
    database_url: str | None = None,
    start: datetime | None = None,
    end: datetime | None = None,
    sources: Iterable[str] | None = None,
    limit: int | None = None,
) -> list[Candle]:
    """Load canonical closed M1 candles from xauusd_candles in ascending UTC order.

    This loader is intentionally read-only. It accepts optional source filtering so
    training runs can distinguish imported history from live MT5 rows when needed.
    """
    try:
        import psycopg2
    except ImportError as exc:  # pragma: no cover - environment dependent
        raise RuntimeError("psycopg2 is required to read PostgreSQL history") from exc

    clauses = ["timeframe = 'M1'"]
    params: list[object] = []

    if start is not None:
        if start.tzinfo is None:
            start = start.replace(tzinfo=timezone.utc)
        clauses.append("candle_time >= %s")
        params.append(start.astimezone(timezone.utc))
    if end is not None:
        if end.tzinfo is None:
            end = end.replace(tzinfo=timezone.utc)
        clauses.append("candle_time <= %s")
        params.append(end.astimezone(timezone.utc))

    source_values = tuple(str(s).strip() for s in (sources or ()) if str(s).strip())
    if source_values:
        clauses.append("source = ANY(%s)")
        params.append(list(source_values))

    sql = f"""
        SELECT candle_time, open, high, low, close, volume
        FROM xauusd_candles
        WHERE {' AND '.join(clauses)}
        ORDER BY candle_time ASC
    """
    if limit is not None:
        limit = int(limit)
        if limit <= 0:
            raise ValueError("limit must be positive")
        sql += " LIMIT %s"
        params.append(limit)

    conn = psycopg2.connect(_database_url(database_url), connect_timeout=15, application_name="trading_ai_dataset")
    try:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            rows = cur.fetchall()
    finally:
        conn.close()

    candles: list[Candle] = []
    for ts, o, h, l, c, v in rows:
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=timezone.utc)
        ts = ts.astimezone(timezone.utc)
        candles.append(
            Candle(
                timestamp_ms=int(ts.timestamp() * 1000),
                open=float(o),
                high=float(h),
                low=float(l),
                close=float(c),
                volume=float(v or 0.0),
            )
        )

    validate_candles(candles)
    return candles


def history_summary(candles: Iterable[Candle]) -> dict[str, object]:
    rows = tuple(candles)
    if not rows:
        return {"rows": 0, "first_utc": None, "last_utc": None}
    validate_candles(rows)
    return {
        "rows": len(rows),
        "first_utc": datetime.fromtimestamp(rows[0].timestamp_ms / 1000, tz=timezone.utc).isoformat(),
        "last_utc": datetime.fromtimestamp(rows[-1].timestamp_ms / 1000, tz=timezone.utc).isoformat(),
    }
