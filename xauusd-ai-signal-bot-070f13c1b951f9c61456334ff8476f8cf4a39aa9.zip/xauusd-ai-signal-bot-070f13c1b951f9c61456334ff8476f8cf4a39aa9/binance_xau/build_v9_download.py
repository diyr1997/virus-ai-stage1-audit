from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "demo_mt5_worker"
OUTPUTS = (
    ROOT / "xauusd-demo-worker-v9-v5-fast80-watchdog.zip",
    ROOT / "xauusd-demo-worker-v9.zip",
)
PREFIX = "xauusd-demo-worker-v9/"
REQUIRED_ARCHIVE_FILES = {
    "BUILD_MANIFEST.json",
    "windows_launcher.py",
    "verify_v9_package.py",
    "prepare_update_from_old_worker.bat",
    "trader_v9_hardened_v4.py",
    "trader_v9_hardened_v7.py",
    "fast_entry_shadow.py",
    "fast_entry_shadow_integration.py",
    "shadow_outcome_tracker.py",
    "shadow_calibration_report.py",
    "shadow_calibration_integration.py",
    "regime_shadow.py",
    "regime_shadow_integration.py",
    "profit_lock_shadow.py",
    "reverse_shadow.py",
    "reverse_shadow_integration.py",
}
REQUIRED_LAUNCHER_MARKERS = (
    "FAST80 WAIT-FIX ACTIVE",
    "FAST80 DIAGNOSTICS ACTIVE",
    "PACKAGE BUILD_ID:",
)
FEATURES = [
    "DEMO_ONLY",
    "FRESH_ACCOUNT_SEND_GUARD_V7",
    "FAST80_WAIT_FIX",
    "FAST80_DIAGNOSTICS",
    "NO_HEDGE",
    "SAFE_CONFIG_MIGRATION",
    "LATE_ENTRY_SHADOW",
    "PROFIT_LOCK_SHADOW",
    "REVERSE_SHADOW",
    "REGIME_SHADOW",
    "SHADOW_OUTCOME_TRACKER",
    "SHADOW_CALIBRATION",
]


def include(path: Path) -> bool:
    rel = path.relative_to(SOURCE)
    if "__pycache__" in rel.parts:
        return False
    if path.suffix.lower() in {".pyc", ".pyo"}:
        return False
    if path.name.lower() in {"config_private.bat", "build_manifest.json"}:
        return False
    return path.is_file()


def windows_bytes(path: Path) -> bytes:
    """Emit Windows batch files as UTF-8 without BOM and CRLF line endings."""
    if path.suffix.lower() not in {".bat", ".cmd"}:
        return path.read_bytes()
    text = path.read_text(encoding="utf-8-sig")
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    return text.replace("\n", "\r\n").encode("utf-8")


def source_fingerprint(files: list[Path]) -> str:
    h = hashlib.sha256()
    for path in files:
        rel = str(path.relative_to(SOURCE)).replace("\\", "/")
        h.update(rel.encode("utf-8"))
        h.update(b"\0")
        h.update(hashlib.sha256(windows_bytes(path)).digest())
    return h.hexdigest()


def build_manifest(files: list[Path]) -> dict[str, object]:
    fingerprint = source_fingerprint(files)
    launcher = (SOURCE / "windows_launcher.py").read_text(encoding="utf-8-sig")
    version = "unknown"
    for line in launcher.splitlines():
        if line.startswith("VERSION = "):
            version = line.split("=", 1)[1].strip().strip('"').strip("'")
            break
    return {
        "schema": 1,
        "package": "xauusd-demo-worker-v9",
        "version": version,
        "build_id": fingerprint[:16],
        "source_sha256": fingerprint,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "file_count": len(files),
        "features": FEATURES,
        "execution_scope": "DEMO_ONLY",
    }


def verify_archive(output: Path) -> None:
    with ZipFile(output, "r") as archive:
        names = set(archive.namelist())
        missing = sorted(name for name in REQUIRED_ARCHIVE_FILES if PREFIX + name not in names)
        if missing:
            raise SystemExit(f"ZIP VERIFY FAILED {output.name}: missing " + ", ".join(missing))

        launcher = archive.read(PREFIX + "windows_launcher.py").decode("utf-8-sig")
        for marker in REQUIRED_LAUNCHER_MARKERS:
            if marker not in launcher:
                raise SystemExit(f"ZIP VERIFY FAILED {output.name}: launcher marker missing: {marker}")

        verify_text = archive.read(PREFIX + "verify_v9_package.py").decode("utf-8-sig")
        for marker in (
            "DemoTrader = V9HardenedV7DemoTrader",
            "FRESH_ACCOUNT_NOT_DEMO",
            "FAST_ENTRY_WAIT_IGNORED",
            "FAST_ENTRY_SLOT_BLOCKED",
            "FAST80 startup markers present",
            "safe config migration helper present",
        ):
            if marker not in verify_text:
                raise SystemExit(f"ZIP VERIFY FAILED {output.name}: self-check marker missing: {marker}")

        migrate_text = archive.read(PREFIX + "prepare_update_from_old_worker.bat").decode("utf-8-sig")
        for marker in ("Refusing to overwrite", "does NOT start the worker", "Old worker folder was NOT deleted or changed"):
            if marker not in migrate_text:
                raise SystemExit(f"ZIP VERIFY FAILED {output.name}: migration safety marker missing: {marker}")

        manifest = json.loads(archive.read(PREFIX + "BUILD_MANIFEST.json").decode("utf-8"))
        if manifest.get("execution_scope") != "DEMO_ONLY" or not manifest.get("build_id"):
            raise SystemExit(f"ZIP VERIFY FAILED {output.name}: invalid BUILD_MANIFEST.json")
        for feature in (
            "FRESH_ACCOUNT_SEND_GUARD_V7",
            "FAST80_WAIT_FIX",
            "FAST80_DIAGNOSTICS",
            "SAFE_CONFIG_MIGRATION",
            "SHADOW_CALIBRATION",
        ):
            if feature not in manifest.get("features", []):
                raise SystemExit(f"ZIP VERIFY FAILED {output.name}: manifest feature missing: {feature}")

        forbidden = [
            name for name in names
            if name.lower().endswith("/config_private.bat")
            or "/__pycache__/" in name.lower()
            or name.lower().endswith((".pyc", ".pyo"))
        ]
        if forbidden:
            raise SystemExit(f"ZIP VERIFY FAILED {output.name}: forbidden files: " + ", ".join(sorted(forbidden)))

    print(f"verified {output.name}: V7 DEMO guard + manifest + FAST80 + safe migration + SHADOW modules present")


def write_sha256(output: Path) -> None:
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    checksum = output.with_name(output.name + ".sha256")
    checksum.write_text(f"{digest}  {output.name}\n", encoding="ascii")
    print(f"sha256 {output.name}: {digest}")


def main() -> None:
    if not SOURCE.is_dir():
        raise SystemExit("demo_mt5_worker directory missing")

    files = sorted(path for path in SOURCE.rglob("*") if include(path))
    if not files:
        raise SystemExit("no DEMO worker files found")

    manifest = build_manifest(files)
    manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode("utf-8")

    for output in OUTPUTS:
        if output.exists():
            output.unlink()
        checksum = output.with_name(output.name + ".sha256")
        manifest_sidecar = output.with_name(output.name + ".manifest.json")
        for sidecar in (checksum, manifest_sidecar):
            if sidecar.exists():
                sidecar.unlink()
        with ZipFile(output, "w", compression=ZIP_DEFLATED, compresslevel=9) as archive:
            for path in files:
                arcname = Path("xauusd-demo-worker-v9") / path.relative_to(SOURCE)
                archive.writestr(str(arcname).replace("\\", "/"), windows_bytes(path))
            archive.writestr(PREFIX + "BUILD_MANIFEST.json", manifest_bytes)
        verify_archive(output)
        write_sha256(output)
        manifest_sidecar.write_bytes(manifest_bytes)
        print(
            f"built {output.name} files={len(files)} bytes={output.stat().st_size} "
            f"build_id={manifest['build_id']}"
        )


if __name__ == "__main__":
    main()
