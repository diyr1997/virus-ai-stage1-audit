Binance-derived XAU context collector and verified Windows V9 download helper.

Download-service build creates:
- xauusd-demo-worker-v9.zip
- xauusd-demo-worker-v9-v5-fast80-watchdog.zip

Both archives are generated only after the DEMO worker package compiles and verify_v9_package.py passes.
