"use strict";

const { startCouncilGateway } = require("./ai-council-gateway");

const started = startCouncilGateway();
let fastNewsStarted = false;
try {
  const { startFastNewsWatcher } = require("./fast-news-watcher-v2");
  fastNewsStarted = startFastNewsWatcher();
} catch (error) {
  // Council must remain available even if the optional watcher cannot start.
  console.warn(`FAST_NEWS_V2_BOOTSTRAP_ERROR ${error.message}`);
}

module.exports = { started, fastNewsStarted };
