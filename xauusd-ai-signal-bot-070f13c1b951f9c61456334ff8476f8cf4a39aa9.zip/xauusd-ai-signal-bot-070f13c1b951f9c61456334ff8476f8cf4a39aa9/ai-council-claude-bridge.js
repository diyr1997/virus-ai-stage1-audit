"use strict";

/**
 * Claude Code Cloud external-advisor bridge (GitHub issue #212).
 *
 * Lets the existing `claude` AI Council advisor be answered by Claude Code
 * Cloud through GitHub instead of the Anthropic Messages API, when no
 * ANTHROPIC_API_KEY is configured and CLAUDE_CODE_BRIDGE_ENABLED=1.
 *
 * This module owns only: publishing task payloads to
 * .ai-council-queue/claude-tasks/, validating + importing result payloads
 * from .ai-council-queue/claude-results/, and the durable bookkeeping used
 * to wake the configured Claude Routine exactly once per (task_id, phase).
 * It never writes to ai_council_runs directly and never touches production
 * `main` - it only reads/writes the ai-council-queue branch via GitHub.
 *
 * Deliberately has no dependency on any other Council runtime module, to
 * avoid the ai-council-dynamic.js / ai-council-persistent.js cycle. The only
 * local dependency below is a leaf Routine HTTP helper with no Council/DB
 * imports of its own.
 */

const crypto = require("crypto");
const { Pool } = require("pg");
const {
  routineAutofireConfigured,
  initialRoutineFireStatus,
  routineFireTimeoutMs,
  retryAfterDelayMs,
  validateRoutineFireTarget,
  classifyRoutineFireFailure,
  fireClaudeRoutine,
} = require("./ai-council-claude-routine-fire");

const DATABASE_URL = String(process.env.DATABASE_URL || "").trim();
const pool = DATABASE_URL ? new Pool({ connectionString: DATABASE_URL }) : null;

const GITHUB_TOKEN = String(process.env.GITHUB_REVIEW_TOKEN || "").trim();
const GITHUB_REPO = String(
  process.env.GITHUB_COUNCIL_REPO || "diyr1997/xauusd-ai-signal-bot"
).trim();
const ALLOWED_LOGIN = String(
  process.env.GITHUB_COUNCIL_ALLOWED_LOGIN || "diyr1997"
).trim().toLowerCase();
const QUEUE_BRANCH = String(
  process.env.GITHUB_COUNCIL_QUEUE_BRANCH || "ai-council-queue"
).trim();
const TASKS_DIR = String(
  process.env.CLAUDE_BRIDGE_TASKS_DIR || ".ai-council-queue/claude-tasks"
).trim().replace(/^\/+|\/+$/g, "");
const RESULTS_DIR = String(
  process.env.CLAUDE_BRIDGE_RESULTS_DIR || ".ai-council-queue/claude-results"
).trim().replace(/^\/+|\/+$/g, "");

const TASK_TRANSPORT = "AI_COUNCIL_CLAUDE_TASK_V1";
const RESULT_TRANSPORT = "AI_COUNCIL_CLAUDE_RESULT_V1";
const ROUTINE_MAX_SAFE_ATTEMPTS = 3;

function requirePool() {
  if (!pool) throw new Error("DATABASE_URL is not configured");
  return pool;
}

function claudeBridgeEnabled() {
  return /^1$/.test(String(process.env.CLAUDE_CODE_BRIDGE_ENABLED || "").trim());
}

function hasAnthropicApiKey() {
  return Boolean(String(process.env.ANTHROPIC_API_KEY || "").trim());
}

function claudeBridgeActive() {
  return claudeBridgeEnabled() && !hasAnthropicApiKey();
}

function redactPotentialSecrets(text) {
  return String(text || "")
    .replace(
      /\b(api[_-]?key|token|password|secret|authorization)\b\s*[:=]\s*([^\s\n]+)/gi,
      "$1=[REDACTED]"
    )
    .replace(/Bearer\s+[A-Za-z0-9._~+\/-]{16,}/gi, "Bearer [REDACTED]");
}

function safeSegment(value) {
  return String(value || "")
    .trim()
    .replace(/[^A-Za-z0-9_.:-]+/g, "_")
    .slice(0, 160);
}

function taskFilePath(taskId, phase) {
  return `${TASKS_DIR}/${safeSegment(taskId)}__${safeSegment(phase)}.json`;
}

function resultFilePath(taskId, phase) {
  return `${RESULTS_DIR}/${safeSegment(taskId)}__${safeSegment(phase)}.json`;
}

function sha256(text) {
  return crypto.createHash("sha256").update(String(text || ""), "utf8").digest("hex");
}

async function githubRequest(path, options = {}) {
  if (!GITHUB_TOKEN) throw new Error("GITHUB_REVIEW_TOKEN is not configured");
  const response = await fetch(`https://api.github.com${path}`, {
    ...options,
    headers: {
      accept: "application/vnd.github+json",
      authorization: `Bearer ${GITHUB_TOKEN}`,
      "x-github-api-version": "2022-11-28",
      "user-agent": "xauusd-ai-council-claude-bridge",
      ...(options.headers || {}),
    },
  });
  const raw = await response.text();
  let data = null;
  if (raw) {
    try {
      data = JSON.parse(raw);
    } catch {
      data = raw;
    }
  }
  if (!response.ok) {
    const error = new Error(
      `GitHub API ${response.status}: ${String(data?.message || raw).slice(0, 800)}`
    );
    error.statusCode = response.status;
    return { ok: false, status: response.status, data, error };
  }
  return { ok: true, status: response.status, data };
}

function repoParts() {
  const [owner, repo] = GITHUB_REPO.split("/");
  if (!owner || !repo) throw new Error("GITHUB_COUNCIL_REPO must be owner/repo");
  return { owner, repo };
}

async function ensureBridgeSchema() {
  const db = requirePool();
  await db.query(`
    CREATE TABLE IF NOT EXISTS ai_council_claude_bridge (
      task_id TEXT NOT NULL,
      phase TEXT NOT NULL,
      task_sha256 TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'PUBLISHED',
      result_sha TEXT,
      imported_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      PRIMARY KEY (task_id, phase)
    )
  `);
  await db.query(`
    ALTER TABLE ai_council_claude_bridge
      ADD COLUMN IF NOT EXISTS routine_fire_status TEXT,
      ADD COLUMN IF NOT EXISTS routine_fire_error TEXT,
      ADD COLUMN IF NOT EXISTS routine_fire_attempts INTEGER NOT NULL DEFAULT 0,
      ADD COLUMN IF NOT EXISTS routine_fired_at TIMESTAMPTZ,
      ADD COLUMN IF NOT EXISTS routine_session_id TEXT,
      ADD COLUMN IF NOT EXISTS routine_retry_after_at TIMESTAMPTZ
  `);

  await db.query(`
    UPDATE ai_council_claude_bridge
    SET routine_fire_status='DISABLED'
    WHERE routine_fire_status IS NULL
  `);

  await db.query(
    `UPDATE ai_council_claude_bridge
     SET routine_fire_status='FAILED_HTTP_AMBIGUOUS',
         routine_fire_error='STALE_FIRING_RECOVERY',
         updated_at=NOW()
     WHERE routine_fire_status='FIRING'
       AND updated_at <= NOW() - make_interval(secs => $1::double precision)`,
    [(2 * routineFireTimeoutMs()) / 1000]
  );
}

async function getBridgeRow(taskId, phase) {
  const { rows } = await requirePool().query(
    "SELECT * FROM ai_council_claude_bridge WHERE task_id=$1 AND phase=$2",
    [taskId, phase]
  );
  return rows[0] || null;
}

async function fetchTaskFile(taskId, phase) {
  const { owner, repo } = repoParts();
  const taskPath = taskFilePath(taskId, phase);
  const path = taskPath.split("/").map(encodeURIComponent).join("/");
  const fileResult = await githubRequest(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents/${path}?ref=${encodeURIComponent(QUEUE_BRANCH)}`
  );
  if (!fileResult.ok) throw fileResult.error;
  const file = fileResult.data;
  if (String(file?.encoding || "").toLowerCase() !== "base64") {
    throw new Error(`Task file for ${taskId} (${phase}) is not base64 encoded`);
  }
  const text = Buffer.from(
    String(file.content || "").replace(/\s+/g, ""),
    "base64"
  ).toString("utf8");
  return { sha: file.sha, text, taskPath };
}

async function claimRoutineFireAttempt(taskId, phase) {
  const { rows } = await requirePool().query(
    `UPDATE ai_council_claude_bridge
     SET routine_fire_status='FIRING',
         routine_fire_error=NULL,
         routine_retry_after_at=NULL,
         routine_fire_attempts=COALESCE(routine_fire_attempts, 0) + 1,
         updated_at=NOW()
     WHERE task_id=$1 AND phase=$2
       AND COALESCE(routine_fire_attempts, 0) < $3
       AND (
         routine_fire_status='PENDING'
         OR (
           routine_fire_status='FAILED_HTTP_SAFE'
           AND (routine_retry_after_at IS NULL OR routine_retry_after_at <= NOW())
         )
       )
     RETURNING *`,
    [taskId, phase, ROUTINE_MAX_SAFE_ATTEMPTS]
  );
  return rows[0] || null;
}

async function recordRoutineFireOutcome(
  taskId,
  phase,
  { status, errorMessage = null, sessionId = null, retryAfterAt = null } = {}
) {
  const cleanStatus = String(status || "FAILED_HTTP_AMBIGUOUS").slice(0, 80);
  const cleanError = errorMessage
    ? redactPotentialSecrets(String(errorMessage)).slice(0, 240)
    : null;
  const cleanSessionId = sessionId ? String(sessionId).slice(0, 240) : null;
  await requirePool().query(
    `UPDATE ai_council_claude_bridge
     SET routine_fire_status=$3,
         routine_fire_error=$4,
         routine_session_id=COALESCE($5, routine_session_id),
         routine_retry_after_at=$6,
         routine_fired_at=CASE WHEN $3='FIRED' THEN NOW() ELSE routine_fired_at END,
         updated_at=NOW()
     WHERE task_id=$1 AND phase=$2`,
    [taskId, phase, cleanStatus, cleanError, cleanSessionId, retryAfterAt]
  );
}

function safeRetryDelayMs(attempts, retryAfter) {
  const fromHeader = retryAfterDelayMs(retryAfter);
  if (fromHeader > 0) return fromHeader;
  const attempt = Math.max(1, Number(attempts) || 1);
  if (attempt <= 1) return 5_000;
  if (attempt === 2) return 30_000;
  return 120_000;
}

async function maybeFireRoutine({ taskId, phase }) {
  if (!routineAutofireConfigured()) return false;

  let claim;
  try {
    claim = await claimRoutineFireAttempt(taskId, phase);
  } catch (error) {
    console.warn(
      `⚠️ CLAUDE ROUTINE claim failed task=${safeSegment(taskId)} phase=${safeSegment(phase)}: ${redactPotentialSecrets(error.message).slice(0, 180)}`
    );
    return false;
  }
  if (!claim) return false;

  const taskPath = taskFilePath(taskId, phase);
  try {
    const file = await fetchTaskFile(taskId, phase);
    const validation = validateRoutineFireTarget({
      taskId,
      phase,
      taskPath,
      rawTaskText: file.text,
      expectedTaskSha256: claim.task_sha256,
    });
    if (!validation.ok) {
      await recordRoutineFireOutcome(taskId, phase, {
        status: "FAILED_VALIDATION",
        errorMessage: validation.reason,
      });
      console.warn(
        `⚠️ CLAUDE ROUTINE validation failed task=${safeSegment(taskId)} phase=${safeSegment(phase)} reason=${validation.reason}`
      );
      return false;
    }

    const fired = await fireClaudeRoutine({
      taskId,
      phase,
      taskPath,
      taskSha256: claim.task_sha256,
    });
    await recordRoutineFireOutcome(taskId, phase, {
      status: "FIRED",
      sessionId: fired.sessionId,
    });
    console.log(
      `🧠 CLAUDE ROUTINE fire acknowledged task=${safeSegment(taskId)} phase=${safeSegment(phase)}`
    );
    return true;
  } catch (error) {
    const classified = classifyRoutineFireFailure(error);
    let retryAfterAt = null;
    if (classified.status === "FAILED_HTTP_SAFE") {
      const delayMs = safeRetryDelayMs(claim.routine_fire_attempts, error?.retryAfter);
      retryAfterAt = new Date(Date.now() + delayMs);
    }
    await recordRoutineFireOutcome(taskId, phase, {
      status: classified.status,
      errorMessage: error?.message || "Routine fire failed",
      retryAfterAt,
    });
    console.warn(
      `⚠️ CLAUDE ROUTINE fire failed task=${safeSegment(taskId)} phase=${safeSegment(phase)} status=${classified.status}`
    );
    return false;
  }
}

async function publishClaudeTask({
  taskId,
  phase,
  taskType,
  task,
  contextSnapshot,
  peerResponses = [],
}) {
  if (!taskId || !phase || !task) {
    throw new Error("publishClaudeTask requires taskId, phase and task");
  }
  await ensureBridgeSchema();

  const existing = await getBridgeRow(taskId, phase);
  if (existing) {
    await maybeFireRoutine({ taskId, phase });
    return getBridgeRow(taskId, phase);
  }

  const payload = {
    transport: TASK_TRANSPORT,
    task_id: taskId,
    phase,
    task_type: String(taskType || "general"),
    task: redactPotentialSecrets(task).slice(0, 60_000),
    context_snapshot: redactPotentialSecrets(contextSnapshot || "").slice(0, 60_000),
    peer_responses: Array.isArray(peerResponses)
      ? peerResponses.map((entry) => ({
          advisor: String(entry?.advisor || ""),
          response: redactPotentialSecrets(entry?.response || "").slice(0, 20_000),
        }))
      : [],
    created_at: new Date().toISOString(),
  };
  const taskSha256 = sha256(
    JSON.stringify({
      task_id: payload.task_id,
      phase: payload.phase,
      task: payload.task,
      context_snapshot: payload.context_snapshot,
      peer_responses: payload.peer_responses,
    })
  );
  payload.task_sha256 = taskSha256;

  const { owner, repo } = repoParts();
  const path = taskFilePath(taskId, phase).split("/").map(encodeURIComponent).join("/");
  const putResult = await githubRequest(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents/${path}`,
    {
      method: "PUT",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        message: `ai-council: publish claude bridge task ${taskId} (${phase})`,
        content: Buffer.from(JSON.stringify(payload, null, 2), "utf8").toString("base64"),
        branch: QUEUE_BRANCH,
      }),
    }
  );
  if (!putResult.ok) throw putResult.error;

  const fireStatus = initialRoutineFireStatus();
  await requirePool().query(
    `INSERT INTO ai_council_claude_bridge(
       task_id, phase, task_sha256, status, routine_fire_status
     )
     VALUES ($1, $2, $3, 'PUBLISHED', $4)
     ON CONFLICT (task_id, phase) DO NOTHING`,
    [taskId, phase, taskSha256, fireStatus]
  );

  await maybeFireRoutine({ taskId, phase });
  return getBridgeRow(taskId, phase);
}

async function fetchResultFile(taskId, phase) {
  const { owner, repo } = repoParts();
  const path = resultFilePath(taskId, phase).split("/").map(encodeURIComponent).join("/");
  const fileResult = await githubRequest(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents/${path}?ref=${encodeURIComponent(QUEUE_BRANCH)}`
  );
  if (!fileResult.ok) {
    if (fileResult.status === 404) return null;
    throw fileResult.error;
  }
  const file = fileResult.data;
  if (String(file?.encoding || "").toLowerCase() !== "base64") {
    throw new Error(`Result file for ${taskId} (${phase}) is not base64 encoded`);
  }
  const text = Buffer.from(String(file.content || "").replace(/\s+/g, ""), "base64").toString("utf8");

  const commitsResult = await githubRequest(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/commits?sha=${encodeURIComponent(QUEUE_BRANCH)}&path=${encodeURIComponent(resultFilePath(taskId, phase))}&per_page=1`
  );
  const commit = commitsResult.ok && Array.isArray(commitsResult.data) ? commitsResult.data[0] : null;

  return { sha: file.sha, text, commit };
}

function isAllowedAuthor(commit) {
  if (!ALLOWED_LOGIN) return true;
  const author = String(commit?.author?.login || "").toLowerCase();
  const committer = String(commit?.committer?.login || "").toLowerCase();
  return author === ALLOWED_LOGIN || committer === ALLOWED_LOGIN;
}

function validateClaudeResultPayload({ rawText, commit, taskId, phase, taskSha256 }) {
  if (!isAllowedAuthor(commit)) {
    return { ok: false, reason: "WRONG_AUTHOR" };
  }

  let data;
  try {
    data = JSON.parse(rawText);
  } catch {
    return { ok: false, reason: "MALFORMED_JSON" };
  }

  if (String(data?.transport || "") !== RESULT_TRANSPORT) {
    return { ok: false, reason: "WRONG_TRANSPORT_MARKER" };
  }
  if (String(data?.task_id || "") !== taskId) {
    return { ok: false, reason: "WRONG_TASK_ID" };
  }
  if (String(data?.phase || "") !== phase) {
    return { ok: false, reason: "WRONG_PHASE" };
  }
  if (String(data?.task_sha256 || "") !== taskSha256) {
    return { ok: false, reason: "STALE_OR_CHANGED_TASK" };
  }
  const response = redactPotentialSecrets(String(data?.response || "").trim()).slice(0, 60_000);
  if (!response) {
    return { ok: false, reason: "EMPTY_RESPONSE" };
  }

  return { ok: true, response };
}

function decideImportOutcome({ bridgeRow, file, taskId, phase }) {
  if (!bridgeRow) return { success: false, reason: "UNKNOWN_TASK" };
  if (!file) return { success: false, reason: "WAITING" };

  if (bridgeRow.status === "IMPORTED") {
    if (bridgeRow.result_sha && file.sha === bridgeRow.result_sha) {
      return { success: false, reason: "DUPLICATE_RESULT" };
    }
    return { success: false, reason: "STALE_OR_CHANGED_RESULT" };
  }

  const validated = validateClaudeResultPayload({
    rawText: file.text,
    commit: file.commit,
    taskId,
    phase,
    taskSha256: bridgeRow.task_sha256,
  });
  if (!validated.ok) return { success: false, reason: validated.reason };
  return { success: true, response: validated.response, resultSha: file.sha };
}

async function importClaudeResult({ taskId, phase }) {
  await ensureBridgeSchema();
  const bridgeRow = await getBridgeRow(taskId, phase);
  if (!bridgeRow) return { success: false, reason: "UNKNOWN_TASK" };

  let file;
  try {
    file = await fetchResultFile(taskId, phase);
  } catch (error) {
    return { success: false, reason: `FETCH_ERROR:${error.message}` };
  }

  const outcome = decideImportOutcome({ bridgeRow, file, taskId, phase });
  if (!outcome.success) return outcome;

  await requirePool().query(
    `UPDATE ai_council_claude_bridge
     SET status='IMPORTED', result_sha=$3, imported_at=NOW(), updated_at=NOW()
     WHERE task_id=$1 AND phase=$2`,
    [taskId, phase, outcome.resultSha]
  );

  return { success: true, response: outcome.response };
}

module.exports = {
  TASK_TRANSPORT,
  RESULT_TRANSPORT,
  ROUTINE_MAX_SAFE_ATTEMPTS,
  claudeBridgeEnabled,
  hasAnthropicApiKey,
  claudeBridgeActive,
  redactPotentialSecrets,
  sha256,
  isAllowedAuthor,
  validateClaudeResultPayload,
  decideImportOutcome,
  taskFilePath,
  resultFilePath,
  ensureBridgeSchema,
  getBridgeRow,
  fetchTaskFile,
  claimRoutineFireAttempt,
  recordRoutineFireOutcome,
  safeRetryDelayMs,
  maybeFireRoutine,
  publishClaudeTask,
  importClaudeResult,
};
