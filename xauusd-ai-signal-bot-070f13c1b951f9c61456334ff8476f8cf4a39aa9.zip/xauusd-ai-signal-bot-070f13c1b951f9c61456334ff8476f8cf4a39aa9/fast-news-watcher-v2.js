"use strict";

/*
 * FAST NEWS WATCHER V2 — research/shadow only.
 *
 * News is PRESSURE/EVIDENCE, never an executable direction by itself.
 * A final BUY/SELL is emitted only when a fresh validated internal AUTO analysis
 * independently agrees. Otherwise final_direction=WAIT.
 *
 * REAL trading remains disabled; this module only sends Telegram alerts.
 */

const crypto = require("crypto");
const WebSocket = require("ws");
const { Pool } = require("pg");

const ENABLED = /^(1|true|yes|enabled)$/i.test(String(process.env.FAST_NEWS_WATCHER_ENABLED || "0"));
const TOKEN = String(process.env.TELEGRAM_BOT_TOKEN || "").trim();
const CHAT_ID = String(process.env.TELEGRAM_OWNER_CHAT_ID || "").trim();
const DATABASE_URL = String(process.env.DATABASE_URL || "").trim();
const TE_KEY = String(process.env.TRADING_ECONOMICS_API_KEY || process.env.TRADING_ECONOMICS_STREAM_KEY || "").trim();
const RSS_POLL_MS = Math.max(5_000, Number(process.env.FAST_NEWS_RSS_POLL_MS || 15_000));
const AI_MAX_AGE_MS = Math.max(15_000, Number(process.env.FAST_NEWS_AI_MAX_AGE_MS || 120_000));
const RECONNECT_MS = Math.max(5_000, Number(process.env.FAST_NEWS_RECONNECT_MS || 15_000));
const MIN_AI_STRENGTH = Math.max(60, Math.min(100, Number(process.env.FAST_NEWS_MIN_AI_STRENGTH || 60)));

const OFFICIAL_FAST_FEEDS = Object.freeze([
  { name: "BLS PPI", url: "https://www.bls.gov/feed/ppi.rss", impact: 95 },
  { name: "BLS CPI", url: "https://www.bls.gov/feed/cpi.rss", impact: 98 },
  { name: "BLS Employment/NFP", url: "https://www.bls.gov/feed/empsit.rss", impact: 98 },
  { name: "BLS JOLTS", url: "https://www.bls.gov/feed/jolts.rss", impact: 86 },
  { name: "Federal Reserve", url: "https://www.federalreserve.gov/feeds/press_monetary.xml", impact: 98 },
]);

const pool = DATABASE_URL
  ? new Pool({ connectionString: DATABASE_URL, max: 2, idleTimeoutMillis: 30_000, connectionTimeoutMillis: 5_000 })
  : null;

const seen = new Map();
const feedState = new Map();
let rssPrimed = false;
let rssTimer = null;
let teSocket = null;
let reconnectTimer = null;
let started = false;

function clamp100(v) {
  return Math.max(0, Math.min(100, Math.round(Number(v) || 0)));
}

function esc(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function decodeXml(value) {
  return String(value || "")
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function tag(block, names) {
  for (const name of names) {
    const match = String(block).match(new RegExp(`<${name}[^>]*>([\\s\\S]*?)<\\/${name}>`, "i"));
    if (match) return decodeXml(match[1]);
  }
  return "";
}

function attrLink(block) {
  const match = String(block).match(/<link[^>]+href=["']([^"']+)["'][^>]*>/i);
  return match ? decodeXml(match[1]) : "";
}

function hash(parts) {
  return crypto.createHash("sha256").update(parts.map((x) => String(x ?? "")).join("|")).digest("hex");
}

function parseRss(xml, source) {
  const blocks = String(xml || "").match(/<item\b[\s\S]*?<\/item>|<entry\b[\s\S]*?<\/entry>/gi) || [];
  return blocks.map((block) => {
    const title = tag(block, ["title"]);
    const description = tag(block, ["description", "summary", "content"]);
    const link = tag(block, ["link"]) || attrLink(block);
    const published = tag(block, ["pubDate", "published", "updated"]);
    const guid = tag(block, ["guid", "id"]);
    const identity = guid || link || `${title}|${published}`;
    return {
      key: hash(["RSS", source.name, identity]),
      revisionFingerprint: hash([title, description, published]),
      transport: "OFFICIAL_RSS",
      sourceType: "RSS_KEYWORD",
      source: source.name,
      title,
      description,
      url: link,
      eventTime: published || null,
      publishedAt: published || null,
      actual: null,
      forecast: null,
      previous: null,
      impact: source.impact,
      receivedAt: Date.now(),
    };
  }).filter((x) => x.title);
}

function extractPeriod(raw) {
  const text = String(raw || "").toLowerCase();
  if (/\bmom\b|month[- ]over[- ]month|month on month/.test(text)) return "MOM";
  if (/\byoy\b|year[- ]over[- ]year|year on year/.test(text)) return "YOY";
  if (/\bqoq\b|quarter[- ]over[- ]quarter|quarter on quarter/.test(text)) return "QOQ";
  if (/annualized|annualised|annual rate/.test(text)) return "ANNUALIZED";
  return null;
}

function parseMeasurement(value) {
  if (value === null || value === undefined || String(value).trim() === "") {
    return { ok: false, value: null, unit: null, period: null, raw: value, reason: "MISSING" };
  }
  const raw = String(value).trim();
  if (/^(?:n\/?a|--|—|null|none)$/i.test(raw)) {
    return { ok: false, value: null, unit: null, period: extractPeriod(raw), raw, reason: "MISSING" };
  }
  if (/^[<>~≈]/.test(raw)) {
    return { ok: false, value: null, unit: null, period: extractPeriod(raw), raw, reason: "APPROX_OR_BOUND" };
  }
  const tokens = raw.replace(/,/g, "").match(/[-+]?\d+(?:\.\d+)?/g) || [];
  if (tokens.length !== 1) {
    return { ok: false, value: null, unit: null, period: extractPeriod(raw), raw, reason: "AMBIGUOUS_NUMBER_COUNT" };
  }
  let n = Number(tokens[0]);
  if (!Number.isFinite(n)) {
    return { ok: false, value: null, unit: null, period: extractPeriod(raw), raw, reason: "NONFINITE" };
  }
  let unit = "SCALAR";
  if (/%/.test(raw)) unit = "PERCENT";
  else if (/\b(?:k)\b/i.test(raw) || /\dK\b/i.test(raw)) { unit = "COUNT"; n *= 1e3; }
  else if (/\b(?:m)\b/i.test(raw) || /\dM\b/.test(raw)) { unit = "COUNT"; n *= 1e6; }
  else if (/\b(?:b)\b/i.test(raw) || /\dB\b/.test(raw)) { unit = "COUNT"; n *= 1e9; }
  return { ok: true, value: n, unit, period: extractPeriod(raw), raw, reason: "OK" };
}

function parseNumber(value) {
  const parsed = parseMeasurement(value);
  return parsed.ok ? parsed.value : null;
}

function normalizeTeMessage(message) {
  const root = message && typeof message === "object" ? message : {};
  const data = root.data && typeof root.data === "object" ? root.data : root;
  const actual = data.Actual ?? data.actual ?? null;
  const forecast = data.Forecast ?? data.forecast ?? data.TEForecast ?? data.teForecast ?? null;
  const previous = data.Previous ?? data.previous ?? null;
  const title = String(data.Event ?? data.event ?? data.Title ?? data.title ?? data.Category ?? data.category ?? "Trading Economics event").trim();
  const category = String(data.Category ?? data.category ?? title).trim();
  const country = String(data.Country ?? data.country ?? "").trim();
  const eventTime = data.Date ?? data.date ?? data.LastUpdate ?? data.lastUpdate ?? null;
  const id = data.CalendarId ?? data.calendarId ?? data.Id ?? data.id ?? "";
  const topic = String(root.topic || "unknown");
  // Event identity deliberately excludes Actual/Forecast. Updates to those fields
  // are revisions of one event, not distinct events.
  const identity = id || [country, category, title, eventTime].join("|");
  return {
    key: hash(["TE", topic, identity]),
    revisionFingerprint: hash([actual, forecast, previous, data.LastUpdate ?? data.lastUpdate ?? ""]),
    transport: `TE_WEBSOCKET:${topic}`,
    sourceType: "TE_STRUCTURED",
    source: "Trading Economics",
    title,
    description: String(data.Description ?? data.description ?? "").trim(),
    country,
    category,
    actual,
    forecast,
    previous,
    impact: clamp100((Number(data.Importance ?? data.importance ?? 2) || 2) * 32),
    eventTime: eventTime ? String(eventTime) : null,
    publishedAt: eventTime ? String(eventTime) : null,
    receivedAt: Date.now(),
  };
}

function comparableMeasurements(event) {
  const actual = parseMeasurement(event.actual);
  const forecast = parseMeasurement(event.forecast);
  if (!actual.ok || !forecast.ok) return { ok: false, actual, forecast, reason: "MISSING_OR_UNPARSEABLE" };
  if (actual.unit !== forecast.unit) return { ok: false, actual, forecast, reason: "UNIT_OR_PERIOD_MISMATCH" };
  const contextPeriod = extractPeriod(`${event.category || ""} ${event.title || ""}`);
  const ap = actual.period || contextPeriod;
  const fp = forecast.period || contextPeriod;
  if (ap && fp && ap !== fp) return { ok: false, actual, forecast, reason: "UNIT_OR_PERIOD_MISMATCH" };
  return { ok: true, actual, forecast, period: ap || fp || null, reason: "OK" };
}

function inferNewsPressure(event) {
  const text = `${event.category || ""} ${event.title || ""} ${event.description || ""}`.toLowerCase();
  const cmp = comparableMeasurements(event);

  let family = "OTHER";
  let positiveSurpriseGoldPressure = null;
  if (/consumer price|\bcpi\b|producer price|\bppi\b|pce|inflation/.test(text)) {
    family = "INFLATION"; positiveSurpriseGoldPressure = "SELL";
  } else if (/unemployment rate|jobless claim|unemployment claim/.test(text)) {
    family = "LABOR_WEAKNESS"; positiveSurpriseGoldPressure = "BUY";
  } else if (/nonfarm|payroll|employment change|jobs added|retail sales|gdp|ism/.test(text)) {
    family = "GROWTH_LABOR"; positiveSurpriseGoldPressure = "SELL";
  } else if (/interest rate|fed funds|rate decision|policy rate/.test(text)) {
    family = "RATES"; positiveSurpriseGoldPressure = "SELL";
  }

  if (event.actual !== null && event.forecast !== null && !cmp.ok && positiveSurpriseGoldPressure) {
    return { pressure: "NEUTRAL", confidence: 30, family, reason: cmp.reason, evidence: "structured values refused" };
  }

  if (cmp.ok && cmp.actual.value !== cmp.forecast.value && positiveSurpriseGoldPressure) {
    const positive = cmp.actual.value > cmp.forecast.value;
    const pressure = positive
      ? positiveSurpriseGoldPressure
      : (positiveSurpriseGoldPressure === "BUY" ? "SELL" : "BUY");
    return {
      pressure,
      confidence: 68,
      family,
      reason: `first-order macro pressure only: actual ${event.actual} vs forecast ${event.forecast}`,
      evidence: `unit=${cmp.actual.unit};period=${cmp.period || "UNKNOWN"}`,
    };
  }

  if (/missile|airstrike|attack|war escalation|invasion|sanction|strait of hormuz|red sea/.test(text)) {
    return { pressure: "BUY", confidence: 50, family: "GEOPOLITICS", reason: "risk-off headline pressure only", evidence: "keyword" };
  }
  if (/ceasefire|peace deal|de-escalat/.test(text)) {
    return { pressure: "SELL", confidence: 48, family: "GEOPOLITICS", reason: "risk-premium easing pressure only", evidence: "keyword" };
  }

  if (family === "INFLATION" && event.sourceType === "RSS_KEYWORD") {
    if (/declin|fell|falls|decreas|cool/.test(text)) return { pressure: "BUY", confidence: 42, family, reason: "RSS inflation keyword pressure; no verified surprise", evidence: "keyword" };
    if (/rose|rises|increas|accelerat|hotter/.test(text)) return { pressure: "SELL", confidence: 42, family, reason: "RSS inflation keyword pressure; no verified surprise", evidence: "keyword" };
  }

  return { pressure: "NEUTRAL", confidence: 25, family, reason: "no verified directional news pressure", evidence: "none" };
}

// Backward-compatible export name for older callers/tests. It now returns a
// pressure object and must never be treated as an executable direction.
function inferDirection(event) {
  const pressure = inferNewsPressure(event);
  return { ...pressure, direction: pressure.pressure === "NEUTRAL" ? "WAIT" : pressure.pressure };
}

async function latestInternalAi() {
  if (!pool) return { fresh: false, reason: "DATABASE_NOT_CONFIGURED" };
  try {
    const { rows } = await pool.query(
      `SELECT analyzed_at,timeframe,source,action,direction,strength,analysis_price
       FROM analysis_runs
       WHERE analyzed_at >= NOW() - ($1::bigint * INTERVAL '1 millisecond')
         AND strength >= $2
         AND LOWER(COALESCE(source,'')) NOT IN ('manual','fallback','cloud_fallback','dukascopy')
       ORDER BY analyzed_at DESC,id DESC LIMIT 1`,
      [AI_MAX_AGE_MS, MIN_AI_STRENGTH]
    );
    if (!rows.length) return { fresh: false, reason: "NO_FRESH_VALIDATED_INTERNAL_AI" };
    const row = rows[0];
    const direction = String(row.action || row.direction || "WAIT").toUpperCase();
    if (!["BUY", "SELL"].includes(direction)) return { fresh: false, reason: "INTERNAL_AI_WAIT" };
    return {
      fresh: true,
      analyzedAt: row.analyzed_at,
      timeframe: String(row.timeframe || ""),
      source: String(row.source || ""),
      direction,
      strength: clamp100(row.strength),
      price: row.analysis_price === null ? null : Number(row.analysis_price),
    };
  } catch (error) {
    return { fresh: false, reason: `AI_DB_ERROR:${error.message}` };
  }
}

function combine(newsPressure, ai) {
  const pressure = String(newsPressure?.pressure || newsPressure?.direction || "NEUTRAL").toUpperCase();
  const normalizedPressure = ["BUY", "SELL"].includes(pressure) ? pressure : "NEUTRAL";
  if (!ai?.fresh) {
    return { direction: "WAIT", confidence: 0, reason: "NO_VALIDATED_DIRECTIONAL_SOURCE", newsPressure: normalizedPressure };
  }
  const ad = ["BUY", "SELL"].includes(String(ai.direction || "").toUpperCase())
    ? String(ai.direction).toUpperCase()
    : "WAIT";
  if (normalizedPressure === "NEUTRAL") {
    return { direction: "WAIT", confidence: 0, reason: "NEWS_PRESSURE_NEUTRAL", newsPressure: normalizedPressure };
  }
  if (ad === "WAIT") {
    return { direction: "WAIT", confidence: 0, reason: "INTERNAL_AI_WAIT", newsPressure: normalizedPressure };
  }
  if (ad !== normalizedPressure) {
    return { direction: "WAIT", confidence: Math.min(55, Math.round((clamp100(newsPressure.confidence) + clamp100(ai.strength)) / 2)), reason: "CONFLICT", newsPressure: normalizedPressure };
  }
  return {
    direction: ad,
    confidence: Math.min(90, Math.max(clamp100(newsPressure.confidence), clamp100(ai.strength))),
    reason: "NEWS_PRESSURE_AND_VALIDATED_INTERNAL_AI_AGREE",
    newsPressure: normalizedPressure,
  };
}

async function sendTelegram(text) {
  if (!TOKEN || !CHAT_ID) throw new Error("TELEGRAM_NOT_CONFIGURED");
  const startedAt = Date.now();
  const response = await fetch(`https://api.telegram.org/bot${TOKEN}/sendMessage`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ chat_id: CHAT_ID, text, parse_mode: "HTML", disable_web_page_preview: true }),
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok || body?.ok === false) throw new Error(`TELEGRAM_HTTP_${response.status}:${body?.description || "unknown"}`);
  return Date.now() - startedAt;
}

function revisionState(event) {
  const previous = seen.get(event.key);
  const fingerprint = event.revisionFingerprint || hash([event.title, event.actual, event.forecast, event.previous]);
  if (!previous) {
    seen.set(event.key, { fingerprint, revision: 0, pressure: null, at: Date.now() });
    return { duplicate: false, revision: 0, revised: false, previousPressure: null };
  }
  if (previous.fingerprint === fingerprint) return { duplicate: true, revision: previous.revision, revised: false, previousPressure: previous.pressure };
  const revision = previous.revision + 1;
  seen.set(event.key, { ...previous, fingerprint, revision, at: Date.now() });
  return { duplicate: false, revision, revised: true, previousPressure: previous.pressure };
}

function storePressure(event, pressure) {
  const state = seen.get(event.key);
  if (state) seen.set(event.key, { ...state, pressure: pressure.pressure, at: Date.now() });
  const cutoff = Date.now() - 24 * 60 * 60_000;
  for (const [k, value] of seen) if ((value.at || 0) < cutoff) seen.delete(k);
}

function prime(event) {
  const fingerprint = event.revisionFingerprint || hash([event.title, event.actual, event.forecast, event.previous]);
  seen.set(event.key, { fingerprint, revision: 0, pressure: null, at: Date.now() });
}

async function processEvent(event, { notify = true } = {}) {
  if (!event?.key) return false;
  const revision = revisionState(event);
  if (revision.duplicate) return false;
  if (!notify) return false;

  const start = Date.now();
  const pressure = inferNewsPressure(event);
  if (revision.revised && revision.previousPressure === pressure.pressure) {
    storePressure(event, pressure);
    console.log(`FAST_NEWS_REVISION_NO_DIRECTION_CHANGE key=${event.key.slice(0, 10)} revision=${revision.revision}`);
    return false;
  }
  const ai = await latestInternalAi();
  const final = combine(pressure, ai);
  const receiptToDecisionMs = Date.now() - start;
  storePressure(event, pressure);

  const finalIcon = final.direction === "BUY" ? "🟢" : final.direction === "SELL" ? "🔴" : "⚪";
  const pressureIcon = pressure.pressure === "BUY" ? "⬆️" : pressure.pressure === "SELL" ? "⬇️" : "➖";
  const values = event.actual !== null && event.actual !== undefined
    ? `Actual: <b>${esc(event.actual)}</b>${event.forecast !== null && event.forecast !== undefined ? ` | Forecast: <b>${esc(event.forecast)}</b>` : ""}${event.previous !== null && event.previous !== undefined ? ` | Previous: ${esc(event.previous)}` : ""}`
    : "Actual/Forecast: нет структурированных данных";
  const aiLine = ai?.fresh
    ? `${esc(ai.timeframe)} ${esc(ai.direction)} ${ai.strength}/100 | source=${esc(ai.source)}`
    : `нет валидного свежего направления (${esc(ai?.reason || "unknown")})`;
  const revisionLine = revision.revised ? `🔁 REVISION ${revision.revision}` : "RELEASE";
  const text = [
    `⚡ <b>FAST NEWS V2 — XAU/USD</b>`,
    `<b>${esc(event.title)}</b>`,
    `Источник: ${esc(event.source)} | ${esc(event.sourceType)} | ${revisionLine}`,
    values,
    `${pressureIcon} NEWS PRESSURE: <b>${pressure.pressure} ${clamp100(pressure.confidence)}/100</b>`,
    `Основание: ${esc(pressure.reason)}`,
    `Наш AI: ${aiLine}`,
    `${finalIcon} FINAL: <b>${final.direction} ${clamp100(final.confidence)}/100</b>`,
    `Итог: ${esc(final.reason)}`,
    `⏱ receipt_to_decision=${receiptToDecisionMs} ms`,
    event.eventTime ? `event_time(source): ${esc(event.eventTime)}` : null,
    `🛡 RESEARCH/SHADOW — REAL trading disabled`,
  ].filter(Boolean).join("\n");

  const telegramApiAckMs = await sendTelegram(text);
  console.log(`FAST_NEWS_V2_SENT key=${event.key.slice(0, 10)} pressure=${pressure.pressure} final=${final.direction} receipt_to_decision_ms=${receiptToDecisionMs} telegram_api_ack_ms=${telegramApiAckMs}`);
  return true;
}

async function fetchFeed(source) {
  const state = feedState.get(source.url) || {};
  const headers = { "user-agent": "VIRUS-AI-FastNews/2.0 (research RSS reader)" };
  if (state.etag) headers["if-none-match"] = state.etag;
  if (state.lastModified) headers["if-modified-since"] = state.lastModified;
  const response = await fetch(source.url, { headers, signal: AbortSignal.timeout(8_000) });
  if (response.status === 304) return [];
  if (!response.ok) throw new Error(`${source.name}_HTTP_${response.status}`);
  feedState.set(source.url, {
    etag: response.headers.get("etag") || state.etag || null,
    lastModified: response.headers.get("last-modified") || state.lastModified || null,
  });
  return parseRss(await response.text(), source);
}

async function pollRssOnce() {
  const batches = await Promise.allSettled(OFFICIAL_FAST_FEEDS.map(fetchFeed));
  const events = [];
  for (const batch of batches) {
    if (batch.status === "fulfilled") events.push(...batch.value);
    else console.warn(`FAST_NEWS_RSS_ERROR ${batch.reason?.message || batch.reason}`);
  }
  events.sort((a, b) => String(a.publishedAt || "").localeCompare(String(b.publishedAt || "")));
  if (!rssPrimed) {
    for (const event of events) prime(event);
    rssPrimed = true;
    console.log(`FAST_NEWS_V2_RSS_PRIMED items=${events.length} poll_ms=${RSS_POLL_MS}`);
    return;
  }
  for (const event of events) await processEvent(event, { notify: true });
}

function startRssFallback() {
  pollRssOnce().catch((e) => console.warn(`FAST_NEWS_RSS_PRIME_ERROR ${e.message}`));
  rssTimer = setInterval(() => pollRssOnce().catch((e) => console.warn(`FAST_NEWS_RSS_POLL_ERROR ${e.message}`)), RSS_POLL_MS);
  rssTimer.unref?.();
}

function scheduleTeReconnect() {
  if (reconnectTimer || !TE_KEY) return;
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    startTradingEconomicsStream();
  }, RECONNECT_MS);
  reconnectTimer.unref?.();
}

function startTradingEconomicsStream() {
  if (!TE_KEY) {
    console.log("FAST_NEWS_V2_TE_STREAM NOT_CONFIGURED (set key:secret)");
    return false;
  }
  if (teSocket && [WebSocket.OPEN, WebSocket.CONNECTING].includes(teSocket.readyState)) return true;
  const url = `wss://stream.tradingeconomics.com/?client=${encodeURIComponent(TE_KEY)}`;
  teSocket = new WebSocket(url, { perMessageDeflate: false, handshakeTimeout: 10_000 });
  teSocket.on("open", () => {
    console.log("FAST_NEWS_V2_TE_STREAM CONNECTED");
    teSocket.send(JSON.stringify({ topic: "subscribe", to: "calendar" }));
    teSocket.send(JSON.stringify({ topic: "subscribe", to: "news" }));
  });
  teSocket.on("message", (raw) => {
    try {
      const msg = JSON.parse(raw.toString());
      if (!msg?.topic || msg.topic === "keepalive") return;
      processEvent(normalizeTeMessage(msg), { notify: true }).catch((e) => console.warn(`FAST_NEWS_TE_EVENT_ERROR ${e.message}`));
    } catch (error) {
      console.warn(`FAST_NEWS_TE_PARSE_ERROR ${error.message}`);
    }
  });
  teSocket.on("error", (error) => console.warn(`FAST_NEWS_TE_STREAM_ERROR ${error.message}`));
  teSocket.on("close", () => {
    console.warn("FAST_NEWS_TE_STREAM CLOSED");
    scheduleTeReconnect();
  });
  return true;
}

function startFastNewsWatcher() {
  if (started) return true;
  if (!ENABLED) {
    console.log("FAST_NEWS_WATCHER_V2 DISABLED");
    return false;
  }
  if (!TOKEN || !CHAT_ID) {
    console.warn("FAST_NEWS_WATCHER_V2 NOT_CONFIGURED telegram token/chat missing");
    return false;
  }
  started = true;
  console.log(`FAST_NEWS_WATCHER_V2 START rss_poll_ms=${RSS_POLL_MS} te_stream=${TE_KEY ? "configured" : "not_configured"} db_ai=${pool ? "configured" : "not_configured"} real_trading=false`);
  startRssFallback();
  startTradingEconomicsStream();
  return true;
}

function stopFastNewsWatcher() {
  if (rssTimer) clearInterval(rssTimer);
  if (reconnectTimer) clearTimeout(reconnectTimer);
  if (teSocket) teSocket.close();
  rssTimer = reconnectTimer = teSocket = null;
  started = false;
}

module.exports = {
  OFFICIAL_FAST_FEEDS,
  parseRss,
  extractPeriod,
  parseMeasurement,
  parseNumber,
  normalizeTeMessage,
  comparableMeasurements,
  inferNewsPressure,
  inferDirection,
  combine,
  processEvent,
  startFastNewsWatcher,
  stopFastNewsWatcher,
};
