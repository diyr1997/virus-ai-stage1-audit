"use strict";

/**
 * Solo advisor guard.
 *
 * User-requested mode: continue first-bot engineering without external AI
 * advisors. Keep the normal Gemini+Google NEWS path available, but block
 * Council/project-review/book-review/self-improvement advisor calls before
 * they can reach an external provider.
 */

const providers = require("./ai-providers");

const EXTERNAL_ADVISORS_ENABLED = !/^(0|false|no|disabled)$/i.test(
  String(process.env.EXTERNAL_ADVISORS_ENABLED || "1")
);

function disabledError(provider) {
  const error = new Error(`EXTERNAL_ADVISORS_DISABLED: ${provider}`);
  error.code = "EXTERNAL_ADVISORS_DISABLED";
  return error;
}

function isAdvisorGroundedPrompt(prompt) {
  const text = String(prompt || "");
  // Do not match the bare word "council": legitimate gold-news prompts name
  // World Gold Council as an official market source. Match only explicit AI
  // council/advisor workflow language.
  return /\bAI\s+Council\b|\bcouncil\s+(?:review|member|task|decision|advis(?:or|ory))\b|weekly engineering review|self-improvement|project review|architecture review|independent reviewer|research advisor|book discovery|advisory audit/i.test(text);
}

if (!EXTERNAL_ADVISORS_ENABLED) {
  const originalGrounded = providers.callGeminiGrounded;

  providers.callGemini = async () => {
    throw disabledError("gemini-advisor");
  };
  providers.callDeepSeek = async () => {
    throw disabledError("deepseek");
  };
  providers.callClaude = async () => {
    throw disabledError("claude");
  };
  providers.callProvider = async (provider) => {
    throw disabledError(provider || "provider");
  };
  providers.callGeminiGrounded = async (prompt) => {
    if (isAdvisorGroundedPrompt(prompt)) {
      throw disabledError("gemini-grounded-advisor");
    }
    return originalGrounded(prompt);
  };

  console.log("🛡 SOLO ADVISOR GUARD: external advisor calls blocked; Gemini news path preserved");
}

module.exports = { EXTERNAL_ADVISORS_ENABLED, isAdvisorGroundedPrompt };
