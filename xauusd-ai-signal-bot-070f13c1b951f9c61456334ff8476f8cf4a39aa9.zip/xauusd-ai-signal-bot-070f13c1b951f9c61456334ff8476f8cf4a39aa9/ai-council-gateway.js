"use strict";

const { Pool } = require("pg");
const { enqueueCouncilTask, ensureCouncilSchema } = require("./ai-council-persistent");
const { processCouncilTask, getCouncilSnapshot } = require("./ai-council-dynamic");

const DATABASE_URL = String(process.env.DATABASE_URL || "").trim();
const GITHUB_TOKEN = String(process.env.GITHUB_REVIEW_TOKEN || "").trim();
const GITHUB_REPO = String(
  process.env.GITHUB_COUNCIL_REPO || "diyr1997/xauusd-ai-signal-bot"
).trim();
const ALLOWED_LOGIN = String(
  process.env.GITHUB_COUNCIL_ALLOWED_LOGIN || "diyr1997"
).trim().toLowerCase();
const TRANSPORT = String(
  process.env.GITHUB_COUNCIL_TRANSPORT || "contents"
).trim().toLowerCase();
const QUEUE_BRANCH = String(
  process.env.GITHUB_COUNCIL_QUEUE_BRANCH || "ai-council-queue"
).trim();
const QUEUE_DIR = String(
  process.env.GITHUB_COUNCIL_QUEUE_DIR || ".ai-council-queue/tasks"
).trim().replace(/^\/+|\/+$/g, "");
const ENABLED = !/^(0|false|no|disabled)$/i.test(
  String(process.env.AI_COUNCIL_GATEWAY_ENABLED || "1")
);
const START_DELAY_MS = Math.max(
  5_000,
  Number(process.env.AI_COUNCIL_GATEWAY_START_DELAY_MS || 20_000)
);
const INTERVAL_MS = Math.max(
  30_000,
  Number(process.env.AI_COUNCIL_GATEWAY_INTERVAL_MS || 60_000)
);
const RESULT_CHUNK_CHARS = Math.max(
  800,
  Math.min(6000, Number(process.env.AI_COUNCIL_RESULT_CHUNK_CHARS || 2600))
);
const RETRY_BATCH_LIMIT = Math.max(
  1,
  Math.min(20, Number(process.env.AI_COUNCIL_GATEWAY_RETRY_LIMIT || 5))
);
// Floor on how recently a task's ai_council_tasks row must have been
// touched before the gateway will re-attempt it. Keeps a normal poll
// interval from hammering the same stuck task every single pass; this is
// a simple minimum-age guard, not a scheduler.
const RETRY_MIN_AGE_SECONDS = Math.max(
  0,
  Number(process.env.AI_COUNCIL_GATEWAY_RETRY_MIN_AGE_MS || 20_000)
) / 1000;

const pool = DATABASE_URL ? new Pool({ connectionString: DATABASE_URL }) : null;
let timer = null;
let busy = false;

function requirePool() {
  if (!pool) throw new Error("DATABASE_URL is not configured");
  return pool;
}

function repoParts() {
  const [owner, repo] = GITHUB_REPO.split("/");
  if (!owner || !repo) throw new Error("GITHUB_COUNCIL_REPO must be owner/repo");
  return { owner, repo };
}

function taskIdForIssue(issueNumber) {
  return `CHAT_GITHUB_ISSUE_${Number(issueNumber)}`;
}

function safeTaskId(value, fallback = "CHAT_QUEUE_TASK") {
  const cleaned = String(value || "")
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9_.:-]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 180);
  return cleaned || fallback;
}

function taskIdForQueueFile(file) {
  const stem = String(file?.name || "")
    .replace(/\.json$/i, "")
    .replace(/[^A-Za-z0-9_.:-]+/g, "_")
    .slice(0, 120);
  const sha = String(file?.sha || "").slice(0, 12);
  return safeTaskId(`CHAT_QUEUE_${stem}_${sha}`);
}

function isGatewayIssue(issue) {
  const title = String(issue?.title || "");
  const body = String(issue?.body || "");
  const login = String(issue?.user?.login || "").toLowerCase();
  if (issue?.pull_request) return false;
  if (!/^\[AI COUNCIL\]/i.test(title)) return false;
  if (!body.includes("<!-- AI_COUNCIL_GATEWAY -->")) return false;
  if (ALLOWED_LOGIN && login !== ALLOWED_LOGIN) return false;
  return true;
}

function redactPotentialSecrets(text) {
  return String(text || "")
    .replace(
      /\b(api[_-]?key|token|password|secret|authorization)\b\s*[:=]\s*([^\s\n]+)/gi,
      "$1=[REDACTED]"
    )
    .replace(/Bearer\s+[A-Za-z0-9._~+\/-]{16,}/gi, "Bearer [REDACTED]");
}

function issueTaskText(issue) {
  const title = String(issue?.title || "").replace(/^\[AI COUNCIL\]\s*/i, "").trim();
  const body = String(issue?.body || "")
    .replace("<!-- AI_COUNCIL_GATEWAY -->", "")
    .trim();
  return redactPotentialSecrets([title, body].filter(Boolean).join("\n\n")).slice(0, 60_000);
}

// A queue file whose JSON is broken, whose transport marker is wrong, whose
// task is empty or whose author is not allowed will never become valid by being
// read again: the defect is in the file, not in the attempt. Errors marked this
// way are remembered against the exact sha that produced them, so the gateway
// reports each dead file once instead of re-fetching and re-logging the same
// ones every 30 seconds forever. Kept in memory on purpose - writing to the
// queue branch is what exhausted the repository's Actions budget.
function permanentQueueDefect(message) {
  const error = new Error(message);
  error.permanentQueueDefect = true;
  return error;
}

const MAX_REMEMBERED_QUEUE_FILES = Math.max(
  50,
  Number(process.env.AI_COUNCIL_GATEWAY_REMEMBERED_FILES || 500)
);
const rejectedQueueShas = new Map();
const reportedDriftShas = new Map();

// Already reported at exactly this sha, so there is nothing new to say.
function alreadyReported(memory, file) {
  const path = String(file?.path || file?.name || "");
  if (!path) return false;
  return memory.has(path) && String(memory.get(path)) === String(file?.sha || "");
}

function rememberReported(memory, file, max = MAX_REMEMBERED_QUEUE_FILES) {
  const path = String(file?.path || file?.name || "");
  if (!path) return memory;
  memory.delete(path);
  memory.set(path, String(file?.sha || ""));
  // Bounded so a long-lived gateway cannot grow this without limit.
  while (memory.size > Math.max(1, Number(max) || 1)) {
    const oldest = memory.keys().next().value;
    memory.delete(oldest);
  }
  return memory;
}

function parseQueuePayload(text, file = {}) {
  let data;
  try {
    data = JSON.parse(String(text || ""));
  } catch {
    throw permanentQueueDefect(`Queue file ${file.name || "?"} is not valid JSON`);
  }

  if (String(data?.transport || "") !== "AI_COUNCIL_GATEWAY_V1") {
    throw permanentQueueDefect(`Queue file ${file.name || "?"} has invalid transport marker`);
  }

  const task = redactPotentialSecrets(String(data?.task || "").trim()).slice(0, 60_000);
  if (!task) throw permanentQueueDefect(`Queue file ${file.name || "?"} has empty task`);

  return {
    taskId: safeTaskId(data?.task_id, taskIdForQueueFile(file)),
    taskType: String(data?.task_type || "chat_gateway").trim().slice(0, 80) || "chat_gateway",
    task,
    requestedBy: String(data?.requested_by || "").trim().toLowerCase(),
  };
}

function isAllowedQueueAuthor(commit) {
  if (!ALLOWED_LOGIN) return true;
  const author = String(commit?.author?.login || "").toLowerCase();
  const committer = String(commit?.committer?.login || "").toLowerCase();
  return author === ALLOWED_LOGIN || committer === ALLOWED_LOGIN;
}

async function githubRequest(path, options = {}) {
  if (!GITHUB_TOKEN) throw new Error("GITHUB_REVIEW_TOKEN is not configured");
  const response = await fetch(`https://api.github.com${path}`, {
    ...options,
    headers: {
      accept: "application/vnd.github+json",
      authorization: `Bearer ${GITHUB_TOKEN}`,
      "x-github-api-version": "2022-11-28",
      "user-agent": "xauusd-ai-council-gateway",
      ...(options.headers || {}),
    },
  });
  const raw = await response.text();
  let data = null;
  if (raw) {
    try {
      data = JSON.parse(raw);
    } catch {
      data = raw;
    }
  }
  if (!response.ok) {
    const error = new Error(
      `GitHub API ${response.status}: ${String(data?.message || raw).slice(0, 800)}`
    );
    error.statusCode = response.status;
    throw error;
  }
  return data;
}

async function ensureGatewaySchema() {
  await ensureCouncilSchema();
  const db = requirePool();
  await db.query(`
    CREATE TABLE IF NOT EXISTS ai_council_gateway_issues (
      issue_number BIGINT PRIMARY KEY,
      task_id TEXT NOT NULL UNIQUE,
      last_published_revision INTEGER NOT NULL DEFAULT -1,
      last_published_status TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await db.query(`
    CREATE TABLE IF NOT EXISTS ai_council_gateway_files (
      path TEXT PRIMARY KEY,
      blob_sha TEXT NOT NULL,
      task_id TEXT NOT NULL UNIQUE,
      last_published_revision INTEGER NOT NULL DEFAULT -1,
      last_published_status TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
}

async function listOpenGatewayIssues() {
  const { owner, repo } = repoParts();
  const issues = await githubRequest(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/issues?state=open&per_page=50&sort=created&direction=asc`
  );
  return (Array.isArray(issues) ? issues : []).filter(isGatewayIssue);
}

async function listQueueFiles() {
  const { owner, repo } = repoParts();
  const path = QUEUE_DIR.split("/").map(encodeURIComponent).join("/");
  const items = await githubRequest(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents/${path}?ref=${encodeURIComponent(QUEUE_BRANCH)}`
  );
  return (Array.isArray(items) ? items : [])
    .filter((item) => item?.type === "file" && /\.json$/i.test(String(item?.name || "")))
    .sort((a, b) => String(a.name).localeCompare(String(b.name)));
}

async function fetchQueueFile(file) {
  const { owner, repo } = repoParts();
  const path = String(file?.path || "").split("/").map(encodeURIComponent).join("/");
  const data = await githubRequest(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents/${path}?ref=${encodeURIComponent(QUEUE_BRANCH)}`
  );
  if (String(data?.encoding || "").toLowerCase() !== "base64") {
    throw new Error(`Queue file ${file?.name || "?"} is not base64 encoded`);
  }
  return Buffer.from(String(data?.content || "").replace(/\s+/g, ""), "base64").toString("utf8");
}

async function latestQueueCommit(file) {
  const { owner, repo } = repoParts();
  const commits = await githubRequest(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/commits?sha=${encodeURIComponent(QUEUE_BRANCH)}&path=${encodeURIComponent(String(file?.path || ""))}&per_page=1`
  );
  return Array.isArray(commits) ? commits[0] || null : null;
}

async function getIssueMapping(issueNumber) {
  const { rows } = await requirePool().query(
    "SELECT * FROM ai_council_gateway_issues WHERE issue_number=$1",
    [Number(issueNumber)]
  );
  return rows[0] || null;
}

async function createIssueMapping(issueNumber, taskId) {
  await requirePool().query(
    `INSERT INTO ai_council_gateway_issues(issue_number, task_id)
     VALUES($1, $2)
     ON CONFLICT(issue_number) DO NOTHING`,
    [Number(issueNumber), taskId]
  );
  return getIssueMapping(issueNumber);
}

async function getFileMapping(path) {
  const { rows } = await requirePool().query(
    "SELECT * FROM ai_council_gateway_files WHERE path=$1",
    [String(path)]
  );
  return rows[0] || null;
}

async function createFileMapping(path, blobSha, taskId) {
  await requirePool().query(
    `INSERT INTO ai_council_gateway_files(path, blob_sha, task_id)
     VALUES($1, $2, $3)
     ON CONFLICT(path) DO NOTHING`,
    [String(path), String(blobSha), taskId]
  );
  return getFileMapping(path);
}

async function postIssueComment(issueNumber, body) {
  const { owner, repo } = repoParts();
  return githubRequest(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/issues/${Number(issueNumber)}/comments`,
    {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ body: String(body || "").slice(0, 60_000) }),
    }
  );
}

function compactUnavailable(items) {
  if (!items?.length) return "none";
  return items
    .map((item) => `${item.advisor}: ${String(item.error || "UNAVAILABLE").slice(0, 180)}`)
    .join("; ");
}

function buildResultText(snapshot) {
  const task = snapshot?.task || {};
  const ready = snapshot?.readyAdvisors?.length ? snapshot.readyAdvisors.join(", ") : "none";
  const unavailable = compactUnavailable(snapshot?.unavailableAdvisors);
  const finalPlan = String(task?.final_plan || "").trim();

  return [
    `task=${task.id}`,
    `status=${task.status}`,
    `revision=${Number(task.revision || 0)}`,
    `ready_advisors=${ready}`,
    `quorum=${snapshot?.quorum}`,
    `unavailable=${unavailable}`,
    "",
    finalPlan || "No synthesized plan yet. The task is waiting for the minimum working quorum.",
  ].join("\n");
}

function logResultChunks(taskId, text) {
  const clean = String(text || "");
  const total = Math.max(1, Math.ceil(clean.length / RESULT_CHUNK_CHARS));
  for (let index = 0; index < total; index += 1) {
    const chunk = clean.slice(index * RESULT_CHUNK_CHARS, (index + 1) * RESULT_CHUNK_CHARS);
    console.log(`🧠 AI COUNCIL RESULT ${taskId} PART ${index + 1}/${total} | ${chunk}`);
  }
}

async function publishFileResultIfChanged(mapping) {
  const snapshot = await getCouncilSnapshot(mapping.task_id);
  if (!snapshot) return false;
  const revision = Number(snapshot.task?.revision || 0);
  const status = String(snapshot.task?.status || "PENDING");
  if (
    Number(mapping.last_published_revision) === revision &&
    String(mapping.last_published_status || "") === status
  ) {
    return false;
  }

  logResultChunks(mapping.task_id, buildResultText(snapshot));
  await requirePool().query(
    `UPDATE ai_council_gateway_files
     SET last_published_revision=$2, last_published_status=$3, updated_at=NOW()
     WHERE path=$1`,
    [mapping.path, revision, status]
  );
  return true;
}

async function publishIssueIfChanged(issueNumber, mapping) {
  const snapshot = await getCouncilSnapshot(mapping.task_id);
  if (!snapshot) return false;
  const revision = Number(snapshot.task?.revision || 0);
  const status = String(snapshot.task?.status || "PENDING");
  const hasPlan = Boolean(String(snapshot.task?.final_plan || "").trim());

  if (
    Number(mapping.last_published_revision) === revision &&
    String(mapping.last_published_status || "") === status
  ) {
    return false;
  }
  if (!hasPlan && status === "PENDING") return false;

  await postIssueComment(issueNumber, `## AI Council result\n\n${buildResultText(snapshot)}`);
  await requirePool().query(
    `UPDATE ai_council_gateway_issues
     SET last_published_revision=$2, last_published_status=$3, updated_at=NOW()
     WHERE issue_number=$1`,
    [Number(issueNumber), revision, status]
  );
  return true;
}

async function acceptNewIssue(issue) {
  let mapping = await getIssueMapping(issue.number);
  if (mapping) return mapping;

  const taskId = taskIdForIssue(issue.number);
  const task = issueTaskText(issue);
  if (!task) throw new Error(`Gateway issue #${issue.number} has empty task`);

  await enqueueCouncilTask({ taskId, taskType: "chat_gateway", task });
  mapping = await createIssueMapping(issue.number, taskId);
  console.log(`🧠 AI COUNCIL GATEWAY: accepted issue #${issue.number} -> ${taskId}`);
  await processCouncilTask(taskId);
  return mapping;
}

async function acceptQueueFile(file) {
  let mapping = await getFileMapping(file.path);
  if (mapping) {
    if (String(mapping.blob_sha) !== String(file.sha) && !alreadyReported(reportedDriftShas, file)) {
      rememberReported(reportedDriftShas, file);
      console.warn(`⚠️ AI COUNCIL GATEWAY: queue file changed after acceptance; ignored path=${file.path}`);
    }
    return mapping;
  }

  const commit = await latestQueueCommit(file);
  if (!isAllowedQueueAuthor(commit)) {
    throw permanentQueueDefect(`Queue file ${file.name} latest commit is not from allowed GitHub login`);
  }

  const payload = parseQueuePayload(await fetchQueueFile(file), file);
  if (payload.requestedBy && ALLOWED_LOGIN && payload.requestedBy !== ALLOWED_LOGIN) {
    throw permanentQueueDefect(`Queue file ${file.name} requested_by is not allowed`);
  }

  await enqueueCouncilTask({
    taskId: payload.taskId,
    taskType: payload.taskType,
    task: payload.task,
  });
  mapping = await createFileMapping(file.path, file.sha, payload.taskId);
  console.log(`🧠 AI COUNCIL GATEWAY: accepted queue ${file.path} -> ${payload.taskId}`);
  await processCouncilTask(payload.taskId);
  return mapping;
}

async function runIssuePass() {
  const issues = await listOpenGatewayIssues();
  const results = [];
  for (const issue of issues) {
    try {
      const mapping = await acceptNewIssue(issue);
      const published = await publishIssueIfChanged(issue.number, mapping);
      results.push({ issue: issue.number, taskId: mapping.task_id, published });
    } catch (error) {
      console.warn(`⚠️ AI COUNCIL GATEWAY issue #${issue.number}: ${error.message}`);
    }
  }
  return results;
}

async function runContentsPass() {
  const files = await listQueueFiles();
  const results = [];
  for (const file of files) {
    if (alreadyReported(rejectedQueueShas, file)) continue;
    try {
      const mapping = await acceptQueueFile(file);
      const published = await publishFileResultIfChanged(mapping);
      results.push({ path: file.path, taskId: mapping.task_id, published });
    } catch (error) {
      // Only a defect in the file itself is remembered. A network or API
      // failure is transient and must be retried on the next poll.
      if (error?.permanentQueueDefect) rememberReported(rejectedQueueShas, file);
      console.warn(`⚠️ AI COUNCIL GATEWAY queue ${file?.path || file?.name}: ${error.message}`);
    }
  }
  return results;
}

// Tasks accepted via acceptNewIssue/acceptQueueFile only ever call
// processCouncilTask() once, at acceptance time. An advisor phase that comes
// back RETRY/PENDING there (e.g. the Claude Code Cloud bridge publishing a
// task and waiting for its result file) is never re-attempted afterwards by
// this gateway on its own — nothing else in this process re-invokes
// processCouncilTask for it.
//
// Deliberately scoped to THIS gateway's own tasks only (task_id present in
// ai_council_gateway_issues or ai_council_gateway_files), not the shared
// ai_council_tasks table at large: other producers (book refresh,
// self-review, repo audit, ...) can leave their own non-COMPLETE rows
// there, and this gateway re-driving those on every poll would mean
// unrelated advisor calls/API spend and a possible retry storm that has
// nothing to do with this gateway's job.
async function retryPendingGatewayCouncilTasks(limit = RETRY_BATCH_LIMIT) {
  const db = requirePool();
  const { rows } = await db.query(
    `SELECT t.id
     FROM ai_council_tasks t
     WHERE t.status <> 'COMPLETE'
       AND t.updated_at <= NOW() - make_interval(secs => $2::double precision)
       AND t.id IN (
         SELECT task_id FROM ai_council_gateway_issues
         UNION
         SELECT task_id FROM ai_council_gateway_files
       )
     ORDER BY t.updated_at ASC
     LIMIT $1`,
    [Math.max(1, Math.min(20, Number(limit) || RETRY_BATCH_LIMIT)), RETRY_MIN_AGE_SECONDS]
  );

  const results = [];
  for (const row of rows) {
    try {
      results.push(await processCouncilTask(row.id));
    } catch (error) {
      console.warn(`⚠️ AI COUNCIL GATEWAY retry task ${row.id}: ${error.message}`);
    }
  }
  return results;
}

async function retryPendingCouncilTasks() {
  try {
    return await retryPendingGatewayCouncilTasks(RETRY_BATCH_LIMIT);
  } catch (error) {
    console.warn(`⚠️ AI COUNCIL GATEWAY retry pass: ${error.message}`);
    return [];
  }
}

async function runGatewayPass() {
  if (!ENABLED || !GITHUB_TOKEN || busy) return [];
  busy = true;
  try {
    await ensureGatewaySchema();
    await retryPendingCouncilTasks();
    if (TRANSPORT === "issues") return await runIssuePass();
    if (TRANSPORT !== "contents") throw new Error(`Unsupported gateway transport: ${TRANSPORT}`);
    return await runContentsPass();
  } finally {
    busy = false;
  }
}

function startCouncilGateway() {
  if (!ENABLED) {
    console.log("🧠 AI COUNCIL GATEWAY: disabled");
    return false;
  }
  if (!GITHUB_TOKEN) {
    console.warn("⚠️ AI COUNCIL GATEWAY: GITHUB_REVIEW_TOKEN missing; bridge disabled");
    return false;
  }
  if (timer) return true;

  console.log(
    `🧠 AI COUNCIL GATEWAY: armed; transport=${TRANSPORT}; repo=${GITHUB_REPO}; queue=${QUEUE_BRANCH}:${QUEUE_DIR}; starts in ${Math.round(START_DELAY_MS / 1000)} sec; polls every ${Math.round(INTERVAL_MS / 1000)} sec`
  );

  timer = setTimeout(() => {
    runGatewayPass().catch((error) =>
      console.warn(`⚠️ AI COUNCIL GATEWAY: ${error.message}`)
    );
    setInterval(() => {
      runGatewayPass().catch((error) =>
        console.warn(`⚠️ AI COUNCIL GATEWAY: ${error.message}`)
      );
    }, INTERVAL_MS).unref();
  }, START_DELAY_MS);
  timer.unref();
  return true;
}

module.exports = {
  ENABLED,
  GITHUB_REPO,
  TRANSPORT,
  QUEUE_BRANCH,
  QUEUE_DIR,
  taskIdForIssue,
  taskIdForQueueFile,
  safeTaskId,
  isGatewayIssue,
  redactPotentialSecrets,
  issueTaskText,
  parseQueuePayload,
  permanentQueueDefect,
  alreadyReported,
  rememberReported,
  MAX_REMEMBERED_QUEUE_FILES,
  isAllowedQueueAuthor,
  buildResultText,
  ensureGatewaySchema,
  retryPendingCouncilTasks,
  retryPendingGatewayCouncilTasks,
  runGatewayPass,
  startCouncilGateway,
};
