# VIRUS AI — canonical context for engineering agents

Durable architecture, terminology, invariants and research rules. This file
changes slowly. Current phase, blockers and the resume cursor live in
`PROJECT_STATE.md`. The task-execution contract lives in `AGENTS.md`.

Originally drafted on the unmerged `ai/integrate-agent-toolbox-2026-09-10`
branch; ported on 2026-09-15 with the toolbox section corrected to match
verified evidence rather than the aspirational state that branch assumed.

**Status: canonical on `main` since merge commit
`b29eb13840a06969dddba9c406e8289367fdb78a` (PR #225).**

## Mission and current status

VIRUS AI is a trading-AI project with a single decision core and specialized
data, research, analysis, execution, risk, safety and monitoring modules. The
name is a metaphor for spreading intelligence across authorized data sources and
modules; it is not malware and must never self-propagate or access systems
without authorization.

The current market is XAU/USD. The system is under development, research,
historical validation and DEMO/shadow preparation. **It is not proven profitable
and is not authorized for REAL trading.** After the first XAU/USD system is
completed and validated, the planned next major stage is Binance DEMO.

## Runtime architecture

```
DATA / SOURCES -> NEWS + MACRO + MARKET STATE -> FEATURES / MODELS
  -> RESEARCH / VALIDATION -> SINGLE DECISION CORE (BUY/SELL/WAIT)
  -> RISK -> EXECUTION ADAPTER -> MONITORING / MEMORY
```

- **Data Layer**: market prices/candles/ticks plus news, macro, CFTC, intermarket and later order-flow sources.
- **Analyzer / Market State**: regime, pressure/direction, volatility, structure, impulse, liquidity, opportunity quality.
- **Signal Layer**: BUY, SELL, WAIT. WAIT is a real alternative with utility 0; never choose the less-bad side when both sides are negative.
- **Execution Layer**: bid/ask, spread, slippage, commissions, liquidity, terminal/account state, actual executability.
- **Risk Manager**: position size, portfolio exposure, margin and loss constraints.
- **Safety Layer**: fail closed on stale/inconsistent data, unknown positions/orders, broken ownership/fencing, non-DEMO account, or unverified runtime state.
- **Monitoring/Logging**: record inputs, versions, decision reasons, orders, outcomes and errors so decisions can be reproduced.

There is exactly one decision core. External tools and advisors contribute
evidence, algorithms and critique; they never become separate trading brains or
independent BUY/SELL voters.

## Data and market rules

Use closed candles for candle-based models. Tick/order-flow modules are separate
and must not pretend an incomplete candle is closed. Timeframes keep their own
context; do not mechanically convert one timeframe's signal into another.

All historical external data must be strictly as-of the time it became public.
Planned explanatory data includes DXY, Treasury/real-yield context, GC/COMEX vs
CFD/spot, CFTC, macro releases, news surprise/impact and session/time-of-day.
Asia/London/New York are features/regimes, not hard BUY/SELL rules.

For XAU/USD CFD/spot, distinguish broker tick volume from centralized exchange
volume. **Never label MT5 tick volume as COMEX volume.**

Different gold venues (XAUUSD spot, COMEX GC, LBMA/SGE/MCX/TOCOM) stay
independent evidence layers with provenance. Agreement may be a feature and
divergence may be a feature; neither substitutes for the other.

News and macro sources are merged **by event**, not summed as independent votes.
One official primary source is one canonical event id; secondary outlets may
confirm or enrich but never double the impact.

## Research indicators and features

Candidates include VWAP/AVWAP, Volume Profile (POC/VAH/VAL/HVN/LVN), Footprint
where real data exists, EMA, ATR, RSI, MACD, Bollinger state/%B/Width,
Fibonacci/OTE, swing pivots and liquidity sweeps, ORB, Donchian, KAMA/Kaufman
ER, Hurst, fractional differentiation, cumulative delta/OFI, GC-vs-CFD spread,
Market Profile/TPO and other evidence-backed candidates.

Do not add everything and majority-vote. Each feature/family must be tested
under its own valid definition, timeframe, data requirements and applicability
conditions. Ten methods built on similar OHLC/returns are not ten independent
confirmations: redundancy must be measured (correlation/error overlap,
conditional mutual information or equivalent), with ablation by family and
multiple-testing control.

## BUY / SELL / WAIT and validation

For entry from a flat state, compute expected net utility after bid/ask and
available execution costs. Compare the best trading alternative against a
positive `min_net_utility` relative to WAIT. Keep equality tolerance
(`tie_epsilon`) and any experimental action-margin threshold separate. If both
sides are negative, the best side is below threshold, or required data is
unavailable, return WAIT.

A signal score such as 0-100 is not evidence of profitability until calibrated
out-of-sample so that a higher score corresponds to a better expected net
outcome after costs.

Backtests must prevent leakage/look-ahead, respect as-of timestamps, use
purge/embargo when samples overlap, retain an untouched final holdout, and use
appropriate walk-forward/time-series validation. Report net P&L/expectancy after
spread, slippage and commission, drawdown, profit factor, trade count, stability
by year/regime, and uncertainty/confidence intervals. An improvement is real
only if it reproduces outside its training sample.

Preserve Research -> Challenger -> Validation -> DEMO/Shadow -> Champion.

## AI Council

ChatGPT is the primary coordinator. Gemini, Claude, DeepSeek, Grok, Kimi,
Perplexity and others may act as independent engineering/research/audit
advisors. Their opinions are not runtime trading commands. Advisors must not
fabricate measurements or infrastructure status. A recommendation should state
what to change, why, risks introduced, how to test it, metrics to record and
acceptance/rejection criteria. An unavailable advisor is recorded as
unavailable, never counted as having agreed.

## External tool policy

Every external tool passes:

`DISCOVER -> RESOLVE EXACT UPSTREAM/VERSION -> LICENSE CHECK -> SECURITY SCAN -> ISOLATED INSTALL -> FUNCTIONAL TEST -> COUNCIL REVIEW -> ADOPT / WATCH / REJECT`

Hard rules:

- A failed security gate is not silently bypassed. Overriding a finding requires
  a written manual review of that specific finding.
- `git clone` is not "installed". `pip install` is not "working". `import x` is
  not "useful". Every accepted tool needs a real functional test.
- No external tool ever receives REAL-trading authority, MT5/broker credentials,
  Telegram tokens, Railway production secrets or production database credentials.
- Research libraries stay research-only and are never imported by production
  trading/execution/risk paths (`tools/research_env/`).
- Donor projects contribute algorithms, features, data adapters, validation
  methods, safety mechanisms and tests — preferably reimplemented VIRUS-native
  under a compatible license. Never copy proprietary internals, closed weights,
  or incompatibly licensed code.

Current verified tool status always comes from `AI_AGENT_TOOLBOX_STATUS.md` and
`AI_TOOLBOX_MASTER_INVENTORY_2026-09-15.json`, never from this file.

## Durable project memory

- `CONTEXT.md` (this file): durable architecture, terminology, invariants, research rules.
- `PROJECT_STATE.md`: current phase, last verified work, blockers, resume cursor.
- `AGENTS.md`: the mandatory task-execution contract.
- `AI_AGENT_TOOLBOX_STATUS.md` + the master inventory/adoption-matrix JSONs: tool status and evidence.
- GitHub issues/commits/PRs: detailed durable decisions and evidence.
- Graphify (`graphify-out/graph.json`, git-ignored, rebuild locally): cross-file
  structural relationships. It is a derived artifact — always rebuildable, never
  a source of truth.

For work spanning many sessions: record destination, decisions so far, active
frontier/blockers, not-yet-specified work and out-of-scope items. Do not restart
from the beginning each session.

## Cloud-first workflow

GitHub stores code, issues and durable engineering state. Google Drive stores
project-control documents. Railway hosts isolated services and research jobs.
PostgreSQL is the central market/research/runtime database. **Do not make the
system depend on a single local computer.** Ephemeral caches, venvs and runtime
scratch space are acceptable only as temporary working environments; anything
that must survive must be committed or stored in a cloud system.

## Future Binance and order-flow work

After XAU/USD validation: Binance DEMO with full-market scan, MOVE RADAR,
Binance-only LISTING RADAR, WHALE/ORDER-FLOW RADAR, and crypto news/calendar.
Later, a separate event-driven ORDER-FLOW SCALPER using ticks/book/trades with
its own latency, execution and risk tests. Do not call a retail cloud stack HFT
or claim microsecond execution without measured evidence.

## How to continue work

1. Read `AGENTS.md`, then this file, then `PROJECT_STATE.md`.
2. Continue from `PROJECT_STATE.md -> Resume cursor`; do not repeat completed discovery.
3. Verify current branch, tests, data, deployments and runtime rather than trusting stale status prose.
4. Rebuild/query Graphify when current code structure or impact analysis matters.
5. Define a falsifiable hypothesis and success criterion before a meaningful change.
6. Prefer the smallest change that can be verified — without removing validation, error handling, security measures or observability.
7. If data, execution costs, ownership, account mode or validation is uncertain, fail closed and fix the source of uncertainty instead of bypassing the guard.
8. After a meaningful verified change, update `PROJECT_STATE.md` with evidence and the next resume cursor.

Goal: sustainable positive net expectancy after realistic costs that reproduces
on unseen data and then survives DEMO/forward validation — not maximum signal
count or a visually attractive backtest.
