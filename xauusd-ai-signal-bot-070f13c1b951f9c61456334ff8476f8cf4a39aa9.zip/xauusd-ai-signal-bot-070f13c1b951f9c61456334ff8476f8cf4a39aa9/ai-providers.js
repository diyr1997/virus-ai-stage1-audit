"use strict";

const { callPerplexity } = require("./perplexity-provider");
const { callLocalQwen } = require("./local-advisor");

const GEMINI_NEWS_429_BACKOFF_MS = [
  Math.max(60_000, Number(process.env.GEMINI_NEWS_429_FIRST_MS || 5 * 60_000)),
  Math.max(60_000, Number(process.env.GEMINI_NEWS_429_SECOND_MS || 10 * 60_000)),
  Math.max(60_000, Number(process.env.GEMINI_NEWS_429_MAX_MS || 20 * 60_000)),
];

let geminiGroundedRateLimitUntil = 0;
let geminiGroundedRateLimitLevel = 0;

function isGeminiRateLimitError(error) {
  const message = String(error?.message || error || "");
  return Number(error?.statusCode || 0) === 429 || /AI API 429|RESOURCE_EXHAUSTED|quota|rate.?limit/i.test(message);
}

function extractGeminiQuotaInfo(error) {
  const apiError = error?.apiData?.error || error?.apiData || {};
  const details = Array.isArray(apiError?.details) ? apiError.details : [];
  const violations = [];
  let retryDelay = null;
  for (const detail of details) {
    const type = String(detail?.["@type"] || "");
    if (/QuotaFailure$/i.test(type) && Array.isArray(detail?.violations)) {
      for (const violation of detail.violations) {
        violations.push({
          quotaMetric: String(violation?.quotaMetric || ""),
          quotaId: String(violation?.quotaId || ""),
          quotaValue: violation?.quotaValue === undefined ? null : String(violation.quotaValue),
          quotaDimensions: violation?.quotaDimensions && typeof violation.quotaDimensions === "object" ? violation.quotaDimensions : {},
        });
      }
    }
    if (/RetryInfo$/i.test(type) && detail?.retryDelay) retryDelay = String(detail.retryDelay);
  }
  return {
    statusCode: Number(error?.statusCode || apiError?.code || 429),
    status: String(apiError?.status || "RESOURCE_EXHAUSTED"),
    message: String(apiError?.message || error?.message || "").slice(0, 1000),
    retryAfterHeader: error?.retryAfter ? String(error.retryAfter) : null,
    retryDelay,
    violations,
  };
}

async function postJson(url, headers, body, timeoutMs = 120_000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json", ...headers },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    const raw = await response.text();
    let data;
    try { data = JSON.parse(raw); } catch { data = { raw }; }
    if (!response.ok) {
      const error = new Error(`AI API ${response.status}: ${String(data?.error?.message || raw || "Unknown API error").slice(0, 1000)}`);
      error.statusCode = response.status;
      error.apiData = data;
      error.retryAfter = response.headers.get("retry-after");
      throw error;
    }
    return data;
  } finally {
    clearTimeout(timer);
  }
}

function extractOpenAIResponseText(data) {
  const direct = String(data?.output_text || "").trim();
  if (direct) return direct;
  const pieces = [];
  for (const item of Array.isArray(data?.output) ? data.output : []) {
    for (const part of Array.isArray(item?.content) ? item.content : []) {
      if (part?.type === "output_text" && part?.text) pieces.push(String(part.text));
    }
  }
  return pieces.join("").trim();
}

async function callOpenAI(prompt) {
  const key = process.env.OPENAI_API_KEY;
  if (!key) throw new Error("OPENAI_API_KEY is not configured");
  const model = process.env.OPENAI_MODEL || "gpt-5.6-sol";
  const timeoutMs = Math.max(20_000, Number(process.env.OPENAI_TIMEOUT_MS || 180_000));
  const maxOutputTokens = Math.max(500, Number(process.env.OPENAI_MAX_OUTPUT_TOKENS || 4000));
  const reasoningEffort = String(process.env.OPENAI_REASONING_EFFORT || "medium").trim().toLowerCase();
  const data = await postJson(
    "https://api.openai.com/v1/responses",
    { authorization: `Bearer ${key}` },
    {
      model,
      input: String(prompt || ""),
      reasoning: { effort: reasoningEffort },
      max_output_tokens: maxOutputTokens,
      store: false,
    },
    timeoutMs
  );
  const text = extractOpenAIResponseText(data);
  if (!text) throw new Error("OpenAI Responses API returned empty text");
  return text;
}

async function callGemini(prompt) {
  const key = process.env.GEMINI_API_KEY;
  if (!key) throw new Error("GEMINI_API_KEY is not configured");
  const model = process.env.GEMINI_MODEL || "gemini-2.5-flash";
  const data = await postJson(
    `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`,
    {},
    { contents: [{ role: "user", parts: [{ text: prompt }] }], generationConfig: { temperature: 0.2, maxOutputTokens: 12000 } }
  );
  return data?.candidates?.[0]?.content?.parts?.map((p) => p.text || "").join("") || "";
}

function extractGeminiGrounding(data) {
  const candidate = data?.candidates?.[0] || {};
  const metadata = candidate?.groundingMetadata || {};
  const sources = [];
  const seen = new Set();
  for (const chunk of metadata?.groundingChunks || []) {
    const url = String(chunk?.web?.uri || "").trim();
    const title = String(chunk?.web?.title || "Источник").trim();
    if (!url || seen.has(url)) continue;
    seen.add(url);
    sources.push({ title, url });
  }
  return {
    text: candidate?.content?.parts?.map((part) => String(part?.text || "")).join("").trim() || "",
    sources,
    queries: Array.isArray(metadata?.webSearchQueries) ? metadata.webSearchQueries.map(String) : [],
  };
}

async function callGeminiGrounded(prompt) {
  const key = process.env.GEMINI_API_KEY;
  if (!key) throw new Error("GEMINI_API_KEY is not configured");
  const model = process.env.GEMINI_NEWS_MODEL || process.env.GEMINI_MODEL || "gemini-2.5-flash";
  const timeoutMs = Math.max(20_000, Number(process.env.GEMINI_NEWS_TIMEOUT_MS || 90_000));
  const now = Date.now();
  if (now < geminiGroundedRateLimitUntil) {
    return { text: "", sources: [], queries: [], model, rateLimited: true, retryAt: new Date(geminiGroundedRateLimitUntil).toISOString() };
  }
  let data;
  try {
    data = await postJson(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,
      { "x-goog-api-key": key },
      { contents: [{ role: "user", parts: [{ text: String(prompt || "") }] }], tools: [{ googleSearch: {} }], generationConfig: { temperature: 0.1, maxOutputTokens: 2600 } },
      timeoutMs
    );
  } catch (error) {
    if (!isGeminiRateLimitError(error)) throw error;
    const quotaInfo = extractGeminiQuotaInfo(error);
    console.warn(`📏 GEMINI QUOTA DETAILS: ${JSON.stringify(quotaInfo)}`);
    const cooldownMs = GEMINI_NEWS_429_BACKOFF_MS[Math.min(geminiGroundedRateLimitLevel, GEMINI_NEWS_429_BACKOFF_MS.length - 1)];
    geminiGroundedRateLimitUntil = Date.now() + cooldownMs;
    geminiGroundedRateLimitLevel = Math.min(geminiGroundedRateLimitLevel + 1, GEMINI_NEWS_429_BACKOFF_MS.length - 1);
    console.warn(`⚠️ GEMINI + GOOGLE NEWS: 429 quota/rate limit. Автопауза ${Math.round(cooldownMs / 60_000)} мин до ${new Date(geminiGroundedRateLimitUntil).toISOString()}; основной новостной движок продолжает работать.`);
    return { text: "", sources: [], queries: [], model, rateLimited: true, retryAt: new Date(geminiGroundedRateLimitUntil).toISOString(), quotaInfo };
  }
  geminiGroundedRateLimitUntil = 0;
  geminiGroundedRateLimitLevel = 0;
  const grounded = extractGeminiGrounding(data);
  if (!grounded.text) throw new Error("Gemini не вернул текст новостной проверки");
  return { ...grounded, model };
}

async function callDeepSeek(prompt) {
  const key = process.env.DEEPSEEK_API_KEY;
  if (!key) throw new Error("DEEPSEEK_API_KEY is not configured");
  const thinkingEnabled = /^(1|true|yes|enabled)$/i.test(String(process.env.DEEPSEEK_THINKING || "disabled"));
  const timeoutMs = Math.max(20_000, Number(process.env.DEEPSEEK_TIMEOUT_MS || 180_000));
  const maxTokens = Math.max(500, Number(process.env.DEEPSEEK_MAX_OUTPUT_TOKENS || 6000));
  const body = {
    model: process.env.DEEPSEEK_MODEL || "deepseek-v4-flash",
    messages: [{ role: "user", content: prompt }],
    max_tokens: maxTokens,
    thinking: { type: thinkingEnabled ? "enabled" : "disabled" },
  };
  if (thinkingEnabled) body.reasoning_effort = process.env.DEEPSEEK_REASONING_EFFORT || "low";
  else body.temperature = 0.2;
  const data = await postJson("https://api.deepseek.com/chat/completions", { authorization: `Bearer ${key}` }, body, timeoutMs);
  return data?.choices?.[0]?.message?.content || "";
}

async function callClaude(prompt) {
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) throw new Error("ANTHROPIC_API_KEY is not configured");
  const data = await postJson(
    "https://api.anthropic.com/v1/messages",
    { "x-api-key": key, "anthropic-version": "2023-06-01" },
    { model: process.env.CLAUDE_MODEL || "claude-sonnet-4-5", max_tokens: 4000, messages: [{ role: "user", content: prompt }] }
  );
  return data?.content?.map((p) => p.text || "").join("") || "";
}

async function callProvider(provider, prompt) {
  if (provider === "chatgpt") return callOpenAI(prompt);
  if (provider === "gemini") return callGemini(prompt);
  if (provider === "deepseek") return callDeepSeek(prompt);
  if (provider === "claude") return callClaude(prompt);
  if (provider === "perplexity") return callPerplexity(prompt);
  if (provider === "local-qwen") return callLocalQwen(prompt);
  if (provider === "coordinator") {
    if (String(process.env.OPENAI_API_KEY || "").trim()) return callOpenAI(prompt);
    return callGemini(prompt);
  }
  throw new Error(`Unknown AI provider: ${provider}`);
}

module.exports = {
  callProvider,
  callOpenAI,
  callGemini,
  callGeminiGrounded,
  callDeepSeek,
  callClaude,
  callPerplexity,
  callLocalQwen,
  extractOpenAIResponseText,
  extractGeminiGrounding,
  extractGeminiQuotaInfo,
};