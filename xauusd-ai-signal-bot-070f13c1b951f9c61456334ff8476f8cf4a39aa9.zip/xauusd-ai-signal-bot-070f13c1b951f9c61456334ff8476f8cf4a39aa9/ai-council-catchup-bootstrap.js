"use strict";

const fs = require("fs");
const path = require("path");
const { enqueueCouncilTask } = require("./ai-council-persistent");
const { processPendingCouncilTasks } = require("./ai-council-dynamic");
const { startCouncilGateway } = require("./ai-council-gateway");
const { seedAndAdvanceRepoAudit } = require("./ai-council-repo-audit");

const ENABLED = !/^(0|false|no|disabled)$/i.test(
  String(process.env.AI_COUNCIL_PERSISTENT_ENABLED || "1")
);
const START_DELAY_MS = Math.max(
  10_000,
  Number(process.env.AI_COUNCIL_CATCHUP_START_DELAY_MS || 90_000)
);
const INTERVAL_MS = Math.max(
  60_000,
  Number(process.env.AI_COUNCIL_CATCHUP_INTERVAL_MS || 15 * 60_000)
);
const MAX_TASKS_PER_PASS = Math.max(
  1,
  Math.min(20, Number(process.env.AI_COUNCIL_MAX_TASKS_PER_PASS || 3))
);

const BOOK_TASK_ID = "BOOK_REFRESH_OPEN_FREE_2026_08_20_R1";
const SELF_REVIEW_TASK_ID = "AI_COUNCIL_ARCHITECTURE_SELF_REVIEW_2026_08_20_R1";
const DYNAMIC_POSITION_COUNT_TASK_ID = "DYNAMIC_POSITION_COUNT_NO_HARD_CAP_2026_08_21_R1";
const TELEGRAM_MENU_REVIEW_TASK_ID = "TELEGRAM_MENU_CLEANUP_2026_08_21_R1";
const GRAPH_V7_REVIEW_TASK_ID = "GRAPH_SCENARIO_V7_REVIEW_2026_08_21_R1";

function readText(name) {
  return fs.readFileSync(path.join(__dirname, name), "utf8");
}

async function seedBookRefreshTask() {
  if (/^(0|false|no|disabled)$/i.test(String(process.env.AI_COUNCIL_BOOK_REFRESH_ENABLED || "1"))) {
    return;
  }
  await enqueueCouncilTask({
    taskId: BOOK_TASK_ID,
    taskType: "book_research",
    task: readText("AI_COUNCIL_BOOK_REFRESH_TASK.md"),
  });
}

async function seedSelfReviewTask() {
  if (/^(0|false|no|disabled)$/i.test(String(process.env.AI_COUNCIL_SELF_REVIEW_ENABLED || "1"))) {
    return;
  }
  const roadmap = readText("AI_COUNCIL_ROADMAP_2026-08-20.md");
  const reviewTask = readText("AI_COUNCIL_SELF_REVIEW_TASK.md");
  await enqueueCouncilTask({
    taskId: SELF_REVIEW_TASK_ID,
    taskType: "architecture_review",
    task: `${reviewTask}\n\n===== SHARED ROADMAP TO CRITIQUE =====\n${roadmap}`,
  });
}

async function seedDynamicPositionCountTask() {
  if (/^(0|false|no|disabled)$/i.test(String(process.env.AI_COUNCIL_DYNAMIC_POSITION_COUNT_ENABLED || "1"))) {
    return;
  }
  await enqueueCouncilTask({
    taskId: DYNAMIC_POSITION_COUNT_TASK_ID,
    taskType: "trading_architecture_review",
    task: readText("AI_COUNCIL_DYNAMIC_POSITION_COUNT_TASK.md"),
  });
}

async function seedTelegramMenuReviewTask() {
  if (/^(0|false|no|disabled)$/i.test(String(process.env.AI_COUNCIL_TELEGRAM_MENU_REVIEW_ENABLED || "1"))) {
    return;
  }
  await enqueueCouncilTask({
    taskId: TELEGRAM_MENU_REVIEW_TASK_ID,
    taskType: "telegram_ux_review",
    task: readText("AI_COUNCIL_TELEGRAM_MENU_REVIEW_TASK.md"),
  });
}

async function seedGraphV7ReviewTask() {
  if (/^(0|false|no|disabled)$/i.test(String(process.env.AI_COUNCIL_GRAPH_V7_REVIEW_ENABLED || "1"))) {
    return;
  }
  await enqueueCouncilTask({
    taskId: GRAPH_V7_REVIEW_TASK_ID,
    taskType: "graph_forecast_ux_review",
    task: readText("AI_COUNCIL_GRAPH_V7_REVIEW_TASK.md"),
  });
}

async function seedInitialCouncilTasks() {
  await seedSelfReviewTask();
  await seedBookRefreshTask();
  await seedDynamicPositionCountTask();
  await seedTelegramMenuReviewTask();
  await seedGraphV7ReviewTask();
  await seedAndAdvanceRepoAudit();
}

async function runCatchup() {
  try {
    await seedInitialCouncilTasks();
    const results = await processPendingCouncilTasks(MAX_TASKS_PER_PASS);
    await seedAndAdvanceRepoAudit();
    if (results.length) {
      console.log(`🧠 AI COUNCIL CATCH-UP: ${JSON.stringify(results)}`);
    }
  } catch (error) {
    console.warn(`⚠️ AI COUNCIL CATCH-UP: ${error.message}`);
  }
}

if (ENABLED) {
  startCouncilGateway();

  console.log(
    `🧠 AI COUNCIL CATCH-UP: armed; starts in ${Math.round(
      START_DELAY_MS / 1000
    )} sec; repeats every ${Math.round(
      INTERVAL_MS / 60_000
    )} min; max tasks/pass=${MAX_TASKS_PER_PASS}`
  );

  const timer = setTimeout(() => {
    runCatchup();
    setInterval(runCatchup, INTERVAL_MS).unref();
  }, START_DELAY_MS);
  timer.unref();
}

module.exports = {
  BOOK_TASK_ID,
  SELF_REVIEW_TASK_ID,
  DYNAMIC_POSITION_COUNT_TASK_ID,
  TELEGRAM_MENU_REVIEW_TASK_ID,
  GRAPH_V7_REVIEW_TASK_ID,
  seedBookRefreshTask,
  seedSelfReviewTask,
  seedDynamicPositionCountTask,
  seedTelegramMenuReviewTask,
  seedGraphV7ReviewTask,
  seedInitialCouncilTasks,
  runCatchup,
};
