# COUNCIL_FIRST implementation boundary

This branch contains the **foundation only**. It is intentionally dormant until a separately reviewed wiring change connects real project mutation entry points to it.

## What this foundation does
- Persists the raw owner request and frozen project-context hash.
- Reuses the existing AI Council task/provider/catch-up system.
- Distinguishes `PROVISIONAL_REVIEW` from full `REVIEWED` status.
- Issues stage-bound HMAC-SHA256 authorization tokens only after Council review.
- Requires a second Council review of the draft/diff before merge authorization.
- Invalidates authorization if the related Council task revision changes.
- Defaults unknown mutation kinds to Council review.
- Keeps only exact read-only operations and narrowly scoped Council persistence operations outside the mutation gate.
- Independently blocks REAL-account mutations and cross-bot state mixing.

## What this branch does NOT yet do
- It does not intercept every Telegram owner message.
- It does not wrap every GitHub/config/database/runtime mutation path.
- It does not alter M1/M5 entries, M15/M30/H1 confirmation, news, graph, risk, models, or training.
- It does not deploy or alter the local MT5 DEMO worker.
- It cannot automatically intercept a message typed inside the ChatGPT application. ChatGPT-originated project changes must explicitly enqueue the request into the Council intake before repository/project mutation.

Therefore merging this foundation alone must **not** be described as full enforcement.

## Required environment before authorization functions can be used
`COUNCIL_FIRST_AUTH_SECRET` — random server-side secret of at least 32 characters. Never commit it to GitHub or log it.

## Next separately reviewed wiring slice
After this foundation passes CI and Council post-diff review, inspect and wire mutation entry points one group at a time: owner Telegram mutation commands, GitHub Council gateway mutation requests, internal maintenance/config changes, then any other identified write paths. Each wiring diff requires its own Council review before merge/deploy.

Automatic execution remains DEMO only throughout.
