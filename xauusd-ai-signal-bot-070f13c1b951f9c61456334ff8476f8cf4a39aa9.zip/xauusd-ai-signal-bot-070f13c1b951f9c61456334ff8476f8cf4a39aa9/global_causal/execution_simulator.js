"use strict";

/*
 * Historical execution simulator. Research-only: it consumes already sealed
 * PIT forecasts and market candles; it never creates forecasts or signals.
 *
 * Purpose: evaluate whether a higher-frequency execution policy can express
 * multiple independent opportunities during a day instead of artificially
 * limiting the replay to one trade per event/day.
 *
 * Default benchmark:
 * - starting balance: $100
 * - 0.01 XAUUSD lot = 1 oz
 * - max 10 simultaneous positions
 * - 5-minute entry cooldown
 * - close each position at its selected horizon
 * - direction comes ONLY from the sealed forecast lean
 * - no future data is used for entry
 */

const MINUTE = 60_000;

function validateConfig(c = {}) {
  const out = {
    starting_balance_usd: Number.isFinite(c.starting_balance_usd) ? c.starting_balance_usd : 100,
    lot_size: Number.isFinite(c.lot_size) ? c.lot_size : 0.01,
    max_open_positions: Number.isInteger(c.max_open_positions) ? c.max_open_positions : 10,
    cooldown_minutes: Number.isFinite(c.cooldown_minutes) ? c.cooldown_minutes : 5,
    horizon: c.horizon || "5m",
    min_abs_lean: Number.isFinite(c.min_abs_lean) ? c.min_abs_lean : 0.02,
    pip_value_per_lot: Number.isFinite(c.pip_value_per_lot) ? c.pip_value_per_lot : 100,
  };
  if (out.starting_balance_usd <= 0 || out.lot_size <= 0 || out.max_open_positions < 1 ||
      out.cooldown_minutes < 0 || out.min_abs_lean < 0) {
    throw new Error("INVALID_EXECUTION_CONFIG");
  }
  return out;
}

function candleAtOrBefore(candles, ms) {
  let best = null;
  for (const c of candles) {
    const t = Number(c.timestamp);
    if (!Number.isFinite(t) || t > ms) continue;
    if (!best || t > Number(best.timestamp)) best = c;
  }
  return best;
}

function candleAtOrAfter(candles, ms) {
  let best = null;
  for (const c of candles) {
    const t = Number(c.timestamp);
    if (!Number.isFinite(t) || t < ms) continue;
    if (!best || t < Number(best.timestamp)) best = c;
  }
  return best;
}

function horizonMinutes(h) {
  const m = { "1m": 1, "5m": 5, "15m": 15, "30m": 30, "60m": 60, "4h": 240, "1d": 1440 };
  if (!m[h]) throw new Error(`UNKNOWN_HORIZON ${h}`);
  return m[h];
}

function simulateForecasts(forecasts, candles, config = {}) {
  const cfg = validateConfig(config);
  const rows = [...(forecasts || [])].sort((a, b) => Date.parse(a.as_of) - Date.parse(b.as_of) ||
    String(a.forecast_id).localeCompare(String(b.forecast_id)));
  const trades = [];
  let balance = cfg.starting_balance_usd;
  let lastEntry = -Infinity;
  const daily = new Map();

  for (const f of rows) {
    const h = f.forecast?.horizons?.[cfg.horizon];
    if (!h || !Number.isFinite(h.lean) && typeof h.lean !== "string") continue;
    const lean = h.lean === "UP" ? 1 : h.lean === "DOWN" ? -1 : 0;
    if (!lean) continue;
    const asOf = Date.parse(f.as_of);
    if (!Number.isFinite(asOf) || asOf < lastEntry + cfg.cooldown_minutes * MINUTE) continue;

    const openCount = trades.filter(t => !t.closed_at && t.entry_time <= asOf && t.exit_time > asOf).length;
    if (openCount >= cfg.max_open_positions) continue;

    const entry = candleAtOrAfter(candles, asOf);
    if (!entry || !Number.isFinite(Number(entry.open))) continue;

    const exit = candleAtOrAfter(candles, asOf + horizonMinutes(cfg.horizon) * MINUTE);
    if (!exit || !Number.isFinite(Number(exit.close))) continue;

    const entryPrice = Number(entry.open);
    const exitPrice = Number(exit.close);
    const move = (exitPrice - entryPrice) * lean;
    const pnl = move * cfg.lot_size * cfg.pip_value_per_lot / 100;
    const before = balance;
    balance += pnl;
    const date = new Date(asOf).toISOString().slice(0, 10);
    const d = daily.get(date) || { date, trades: 0, wins: 0, losses: 0, flat: 0, pnl_usd: 0, start_balance: before, end_balance: before };
    d.trades++;
    if (pnl > 0) d.wins++; else if (pnl < 0) d.losses++; else d.flat++;
    d.pnl_usd += pnl;
    d.end_balance = balance;
    daily.set(date, d);

    trades.push({
      trade_id: `TRD-${trades.length + 1}`,
      forecast_id: f.forecast_id,
      as_of: f.as_of,
      direction: lean > 0 ? "UP" : "DOWN",
      horizon: cfg.horizon,
      lot_size: cfg.lot_size,
      entry_time: new Date(Number(entry.timestamp)).toISOString(),
      entry_price: entryPrice,
      exit_time: new Date(Number(exit.timestamp)).toISOString(),
      exit_price: exitPrice,
      pnl_usd: Number(pnl.toFixed(6)),
      balance_before: Number(before.toFixed(6)),
      balance_after: Number(balance.toFixed(6)),
      result: pnl > 0 ? "WIN" : pnl < 0 ? "LOSS" : "FLAT",
      closed_at: Number(exit.timestamp),
    });
    lastEntry = asOf;
  }

  const wins = trades.filter(t => t.result === "WIN").length;
  const losses = trades.filter(t => t.result === "LOSS").length;
  return {
    config: cfg,
    summary: {
      starting_balance_usd: cfg.starting_balance_usd,
      ending_balance_usd: Number(balance.toFixed(6)),
      net_pnl_usd: Number((balance - cfg.starting_balance_usd).toFixed(6)),
      trades: trades.length,
      wins,
      losses,
      flat: trades.length - wins - losses,
      win_rate_pct: trades.length ? Number((wins / trades * 100).toFixed(4)) : null,
    },
    daily: [...daily.values()].sort((a, b) => a.date.localeCompare(b.date)),
    trades,
  };
}

module.exports = { validateConfig, simulateForecasts, horizonMinutes };
