#!/usr/bin/env python3
import argparse
import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")

import joblib
import numpy as np
import pandas as pd

from trading_school.features_v1 import add_trading_school_features

TF_MINUTES = [5, 15, 30, 60]

TF_FEATURE_TEMPLATE = [
    "ret1", "ret2", "ret3", "body_pct", "range_pct", "ema5_gap", "ema10_gap",
    "ema20_gap", "ema5_20_spread", "vol5", "vol10", "rsi14", "atr14_pct",
    "dist_high10", "dist_low10", "dist_high20", "dist_low20",
]


def rsi(series: pd.Series, period=14):
    diff = series.diff()
    gain = diff.clip(lower=0)
    loss = -diff.clip(upper=0)
    avg_gain = gain.ewm(alpha=1 / period, adjust=False, min_periods=period).mean()
    avg_loss = loss.ewm(alpha=1 / period, adjust=False, min_periods=period).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    return (100 - (100 / (1 + rs))).fillna(50.0)


def atr_from_ohlc(o, h, l, c, period=14):
    prev_close = c.shift(1)
    tr = pd.concat(
        [(h - l), (h - prev_close).abs(), (l - prev_close).abs()], axis=1
    ).max(axis=1)
    return tr.ewm(alpha=1 / period, adjust=False, min_periods=period).mean()


def safe_div(a, b):
    return a / b.replace(0, np.nan)


def add_m1_features(df: pd.DataFrame):
    c, o, h, l = df["close"], df["open"], df["high"], df["low"]
    safe_c = c.replace(0, np.nan)

    for n in [1, 2, 3, 5, 10, 15, 30, 60]:
        df[f"m1_ret{n}"] = c.pct_change(n)

    df["m1_body_pct"] = (c - o) / safe_c
    df["m1_range_pct"] = (h - l) / safe_c
    df["m1_upper_wick_pct"] = (
        h - pd.concat([o, c], axis=1).max(axis=1)
    ) / safe_c
    df["m1_lower_wick_pct"] = (
        pd.concat([o, c], axis=1).min(axis=1) - l
    ) / safe_c

    emas = {}
    for span in [5, 10, 20, 50, 100, 200]:
        emas[span] = c.ewm(span=span, adjust=False, min_periods=span).mean()
        df[f"m1_ema{span}_gap"] = (c - emas[span]) / safe_c

    df["m1_ema5_20_spread"] = (emas[5] - emas[20]) / safe_c
    df["m1_ema20_50_spread"] = (emas[20] - emas[50]) / safe_c
    df["m1_ema50_100_spread"] = (emas[50] - emas[100]) / safe_c

    r1 = df["m1_ret1"]
    for n in [5, 15, 30, 60]:
        df[f"m1_vol{n}"] = r1.rolling(n, min_periods=n).std()

    df["m1_rsi7"] = rsi(c, 7) / 100.0
    df["m1_rsi14"] = rsi(c, 14) / 100.0
    df["m1_rsi28"] = rsi(c, 28) / 100.0
    a14 = atr_from_ohlc(o, h, l, c, 14)
    a50 = atr_from_ohlc(o, h, l, c, 50)
    df["m1_atr14_pct"] = a14 / safe_c
    df["m1_atr50_pct"] = a50 / safe_c

    for n in [20, 60, 120]:
        rh = h.rolling(n, min_periods=n).max()
        rl = l.rolling(n, min_periods=n).min()
        df[f"m1_dist_high{n}"] = (c - rh) / safe_c
        df[f"m1_dist_low{n}"] = (c - rl) / safe_c

    df["m1_momentum_5_20"] = df["m1_ret5"] - c.pct_change(20)
    df["m1_momentum_15_60"] = df["m1_ret15"] - df["m1_ret60"]
    range5 = (
        h.rolling(5, min_periods=5).max() - l.rolling(5, min_periods=5).min()
    ) / safe_c
    range30 = (
        h.rolling(30, min_periods=30).max() - l.rolling(30, min_periods=30).min()
    ) / safe_c
    df["m1_range_ratio_5_30"] = safe_div(range5, range30)

    dt = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
    mod = dt.dt.hour * 60 + dt.dt.minute
    df["hour_sin"] = np.sin(2 * np.pi * mod / 1440.0)
    df["hour_cos"] = np.cos(2 * np.pi * mod / 1440.0)
    dow = dt.dt.dayofweek
    df["dow_sin"] = np.sin(2 * np.pi * dow / 7.0)
    df["dow_cos"] = np.cos(2 * np.pi * dow / 7.0)
    return df


def build_tf_feature_frame(df: pd.DataFrame, tf: int):
    x = df[["timestamp", "open", "high", "low", "close"]].copy()
    x["dt"] = pd.to_datetime(x["timestamp"], unit="ms", utc=True)
    x = x.set_index("dt")
    bars = x.resample(
        f"{tf}min", label="right", closed="right", origin="epoch"
    ).agg(
        {
            "open": "first",
            "high": "max",
            "low": "min",
            "close": "last",
            "timestamp": "last",
        }
    ).dropna(subset=["open", "high", "low", "close"])

    if len(bars) < 25:
        return pd.DataFrame(
            columns=["timestamp"] + [f"m{tf}_{n}" for n in TF_FEATURE_TEMPLATE]
        )

    c, o, h, l = bars["close"], bars["open"], bars["high"], bars["low"]
    safe_c = c.replace(0, np.nan)
    vals = pd.DataFrame(index=bars.index)
    vals["timestamp"] = (bars.index.view("int64") // 1_000_000).astype("int64")

    for n in [1, 2, 3]:
        vals[f"m{tf}_ret{n}"] = c.pct_change(n)

    vals[f"m{tf}_body_pct"] = (c - o) / safe_c
    vals[f"m{tf}_range_pct"] = (h - l) / safe_c
    emas = {}
    for span in [5, 10, 20]:
        emas[span] = c.ewm(span=span, adjust=False, min_periods=span).mean()
        vals[f"m{tf}_ema{span}_gap"] = (c - emas[span]) / safe_c

    vals[f"m{tf}_ema5_20_spread"] = (emas[5] - emas[20]) / safe_c
    rr = c.pct_change(1)
    vals[f"m{tf}_vol5"] = rr.rolling(5, min_periods=5).std()
    vals[f"m{tf}_vol10"] = rr.rolling(10, min_periods=10).std()
    vals[f"m{tf}_rsi14"] = rsi(c, 14) / 100.0
    vals[f"m{tf}_atr14_pct"] = atr_from_ohlc(o, h, l, c, 14) / safe_c

    for n in [10, 20]:
        rh = h.rolling(n, min_periods=n).max()
        rl = l.rolling(n, min_periods=n).min()
        vals[f"m{tf}_dist_high{n}"] = (c - rh) / safe_c
        vals[f"m{tf}_dist_low{n}"] = (c - rl) / safe_c

    vals = vals.reset_index(drop=True)
    return vals[["timestamp"] + [f"m{tf}_{n}" for n in TF_FEATURE_TEMPLATE]]


def add_multitimeframe_features(df: pd.DataFrame):
    base = df.sort_values("timestamp").reset_index(drop=True)
    for tf in TF_MINUTES:
        feat = build_tf_feature_frame(base, tf).sort_values("timestamp")
        base = pd.merge_asof(
            base.sort_values("timestamp"),
            feat,
            on="timestamp",
            direction="backward",
            allow_exact_matches=True,
        )
    return base


def add_all_features(df: pd.DataFrame):
    """Single feature pipeline shared by prediction and challenger training."""
    out = add_m1_features(df)
    out = add_multitimeframe_features(out)
    out = add_trading_school_features(out)
    return out


def reason_text(reason):
    return {
        "signal": "условия AI выполнены",
        "models_disagree": "классификатор и прогноз движения не совпали",
        "confidence_below_threshold": "уверенность ниже порога",
        "move_below_threshold": "ожидаемое движение слишком маленькое",
    }.get(reason, reason)


def load_bundle(model_path):
    bundle = joblib.load(model_path)
    if not isinstance(bundle, dict):
        raise RuntimeError("Unexpected model bundle format")
    if 60 not in bundle.get("direction_models", {}):
        raise RuntimeError("H1 direction model missing")
    if 60 not in bundle.get("return_models", {}):
        raise RuntimeError("H1 return model missing")
    return bundle


def model_status(bundle):
    thr = bundle["thresholds"][60]
    return {
        "ok": True,
        "model_version": bundle.get("version"),
        "horizon_minutes": 60,
        "feature_count": len(bundle.get("features", [])),
        "thresholds": {
            "direction_confidence": float(thr["direction_confidence"]),
            "predicted_strength_ratio": float(thr["predicted_strength_ratio"]),
            "target_scale_bps": float(thr["target_scale_bps"]),
        },
        "metadata": bundle.get("metadata", {}),
    }


def predict(bundle, candles_path):
    raw = json.loads(Path(candles_path).read_text(encoding="utf-8"))
    if not isinstance(raw, list) or len(raw) < 2400:
        raise RuntimeError(
            f"Need >=2400 M1 candles, got {len(raw) if isinstance(raw, list) else 0}"
        )

    df = pd.DataFrame(raw)
    required = ["timestamp", "open", "high", "low", "close"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise RuntimeError("Missing candle fields: " + ", ".join(missing))

    for col in required:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = (
        df.dropna(subset=required)
        .sort_values("timestamp")
        .drop_duplicates("timestamp")
        .reset_index(drop=True)
    )
    df["timestamp"] = df["timestamp"].astype("int64")
    for col in ["open", "high", "low", "close"]:
        df[col] = df[col].astype("float64")

    if len(df) < 2400:
        raise RuntimeError(f"Only {len(df)} valid candles after cleaning")

    # Preserve the historical context and reproduce training engineering exactly.
    df = add_all_features(df.tail(7000).copy())

    features = list(bundle["features"])
    missing_features = [c for c in features if c not in df.columns]
    if missing_features:
        raise RuntimeError(
            "Model feature columns missing: " + ", ".join(missing_features[:12])
        )

    usable = df.replace([np.inf, -np.inf], np.nan).dropna(subset=features)
    if usable.empty:
        raise RuntimeError("No row has all AI features")

    row = usable.iloc[-1]
    X = row[features].to_numpy(dtype=np.float32).reshape(1, -1)

    direction_model = bundle["direction_models"][60]
    return_model = bundle["return_models"][60]
    thr = bundle["thresholds"][60]

    probs = direction_model.predict_proba(X)[0]
    classes = np.asarray(direction_model.classes_)
    idx = int(np.argmax(probs))
    sign = int(classes[idx])
    confidence = float(probs[idx])

    predicted_return_bps = float(return_model.predict(X)[0])
    reg_sign = 1 if predicted_return_bps >= 0 else -1
    agreement = bool(sign == reg_sign)

    target_scale = max(float(thr["target_scale_bps"]), 1e-9)
    strength_ratio = abs(predicted_return_bps) / target_scale
    conf_thr = float(thr["direction_confidence"])
    strength_thr = float(thr["predicted_strength_ratio"])

    if not agreement:
        emit, reason = False, "models_disagree"
    elif confidence < conf_thr:
        emit, reason = False, "confidence_below_threshold"
    elif strength_ratio < strength_thr:
        emit, reason = False, "move_below_threshold"
    else:
        emit, reason = True, "signal"

    direction = "BUY" if sign > 0 else "SELL"
    action = direction if emit else "WAIT"
    price = float(row["close"])
    predicted_price = price * (1.0 + predicted_return_bps / 10000.0)

    school_values = {
        key: float(row[key])
        for key in row.index
        if str(key).startswith("school_") and pd.notna(row[key])
    }

    return {
        "ok": True,
        "model_version": bundle.get("version"),
        "horizon_minutes": 60,
        "feature_count": len(features),
        "feature_timestamp": int(row["timestamp"]),
        "feature_timestamp_utc": pd.to_datetime(
            int(row["timestamp"]), unit="ms", utc=True
        ).isoformat(),
        "input_last_timestamp": int(df["timestamp"].iloc[-1]),
        "input_last_timestamp_utc": pd.to_datetime(
            int(df["timestamp"].iloc[-1]), unit="ms", utc=True
        ).isoformat(),
        "price": price,
        "action": action,
        "direction": direction,
        "confidence": confidence,
        "predicted_return_bps": predicted_return_bps,
        "predicted_price_60m": predicted_price,
        "strength_ratio": float(strength_ratio),
        "agreement": agreement,
        "emit": emit,
        "reason": reason,
        "reason_ru": reason_text(reason),
        "trading_school": school_values,
        "thresholds": {
            "direction_confidence": conf_thr,
            "predicted_strength_ratio": strength_thr,
            "target_scale_bps": target_scale,
        },
        "classifier_probabilities": {
            str(int(cls)): float(prob) for cls, prob in zip(classes, probs)
        },
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", required=True)
    p.add_argument("--candles")
    p.add_argument("--status", action="store_true")
    args = p.parse_args()

    try:
        bundle = load_bundle(args.model)
        if args.status:
            result = model_status(bundle)
        else:
            if not args.candles:
                raise RuntimeError("--candles is required unless --status is used")
            result = predict(bundle, args.candles)
        print(json.dumps(result, ensure_ascii=False, allow_nan=False))
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, allow_nan=False))
        sys.exit(2)


if __name__ == "__main__":
    main()
