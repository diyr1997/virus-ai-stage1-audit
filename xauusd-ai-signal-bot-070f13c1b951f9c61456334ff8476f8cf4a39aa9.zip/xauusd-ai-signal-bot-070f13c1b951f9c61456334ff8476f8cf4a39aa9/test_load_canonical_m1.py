"""Tests for the canonical M1 loader.

Two properties carry the safety of this script:

* a bundle that is not bit-for-bit the manifest's file is refused outright;
* every row that reaches the database is a row the verifier counted as
  canonical, which means quarantined conflicts and collapsed duplicates can
  never be written.

The second is tested by driving the real verifier over a synthetic bundle
built to contain one of each case, rather than by trusting that the loader and
the verifier happen to agree.
"""

from __future__ import annotations

import hashlib
import io
import json
import struct
import tempfile
import unittest
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

from ai_global_trader import canonical_history
from ops.load_canonical_m1 import (
    CandleWriter,
    download_to,
    obtain_bundle,
    resolve_source_url,
    verify_bundle,
)

INNER_NAME = "TEST_XAUUSD_M1_2020.zip"
CSV_NAME = "DAT_ASCII_XAUUSD_M1_2020.csv"


def est_to_utc_ms(text: str) -> int:
    """HistData stamps are fixed EST (UTC-05:00) with no daylight saving."""
    local = datetime.strptime(text, "%Y%m%d %H%M%S")
    return int((local + timedelta(hours=5)).replace(tzinfo=timezone.utc).timestamp() * 1000)


def build_bundle(tmp: Path):
    """An archive holding one unique bar, one duplicated bar, one conflict.

    raw 6 rows -> 3 canonical, 1 identical duplicate collapsed, 1 timestamp
    quarantined.
    """
    a, b, c, d = "20200106 090000", "20200106 091000", "20200106 092000", "20200106 093000"
    lines = [
        f"{a};1550.00;1550.50;1549.80;1550.20;0",
        f"{b};1551.00;1551.50;1550.80;1551.20;0",
        f"{b};1551.00;1551.50;1550.80;1551.20;0",   # identical duplicate
        f"{c};1552.00;1552.50;1551.80;1552.20;0",
        f"{c};1552.00;1552.50;1551.80;9999.99;0",   # conflicting close
        f"{d};1553.00;1553.50;1552.80;1553.20;0",
    ]

    inner_buf = io.BytesIO()
    with zipfile.ZipFile(inner_buf, "w", zipfile.ZIP_DEFLATED) as inner:
        inner.writestr(CSV_NAME, "\r\n".join(lines) + "\r\n")
    inner_bytes = inner_buf.getvalue()
    inner_sha = hashlib.sha256(inner_bytes).hexdigest()

    bundle_path = tmp / "bundle.zip"
    with zipfile.ZipFile(bundle_path, "w", zipfile.ZIP_DEFLATED) as outer:
        outer.writestr(INNER_NAME, inner_bytes)

    first_utc = datetime.fromtimestamp(est_to_utc_ms(a) / 1000, tz=timezone.utc).isoformat()
    last_utc = datetime.fromtimestamp(est_to_utc_ms(d) / 1000, tz=timezone.utc).isoformat()

    manifest = {
        "total_raw_rows": 6,
        "total_rows": 3,
        "identical_duplicate_rows_removed": 1,
        "quarantined_conflicting_timestamps": 1,
        "first_utc": first_utc,
        "last_utc": last_utc,
        "files": [
            {
                "file": INNER_NAME,
                "sha256": inner_sha,
                "raw_rows": 6,
                "canonical_rows": 3,
                "identical_duplicate_rows": 1,
                "first_utc": first_utc,
                "last_utc": last_utc,
                "conflict_timestamp_count": 1,
            }
        ],
    }
    quarantine = {"files": {INNER_NAME: [est_to_utc_ms(c)]}}

    manifest_path = tmp / "history_manifest.json"
    quarantine_path = tmp / "history_quarantine.json"
    quarantine_sha_path = tmp / "history_quarantine.sha256"

    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    quarantine_bytes = json.dumps(quarantine).encode("utf-8")
    quarantine_path.write_bytes(quarantine_bytes)
    quarantine_sha_path.write_text(
        hashlib.sha256(quarantine_bytes).hexdigest(), encoding="ascii"
    )

    expected = {
        "a_ms": est_to_utc_ms(a),
        "b_ms": est_to_utc_ms(b),
        "conflict_ms": est_to_utc_ms(c),
        "d_ms": est_to_utc_ms(d),
        "manifest_path": manifest_path,
        "quarantine_path": quarantine_path,
        "quarantine_sha_path": quarantine_sha_path,
    }
    return bundle_path, expected


class BundleVerificationTest(unittest.TestCase):
    def test_a_wrong_hash_is_refused_rather_than_loaded(self):
        with tempfile.TemporaryDirectory() as raw:
            path = Path(raw) / "b.zip"
            path.write_bytes(b"not the canonical bundle")
            with self.assertRaises(SystemExit) as caught:
                verify_bundle(path, expected_sha="0" * 64)
            self.assertIn("SHA256 mismatch", str(caught.exception))

    def test_a_missing_bundle_is_refused(self):
        with self.assertRaises(SystemExit):
            verify_bundle(Path("/nonexistent/bundle.zip"), expected_sha="0" * 64)

    def test_a_matching_hash_passes_and_reports_size(self):
        with tempfile.TemporaryDirectory() as raw:
            path = Path(raw) / "b.zip"
            payload = b"canonical-ish bytes"
            path.write_bytes(payload)
            info = verify_bundle(
                path, expected_sha=hashlib.sha256(payload).hexdigest()
            )
            self.assertEqual(info["size_bytes"], len(payload))

    def test_the_shipped_expected_hash_is_the_drive_bundle(self):
        # Recorded on Google Drive beside the archive, in
        # XAUUSD_M1_CANONICAL_2009_2026_08.sha256 and CANONICAL_DATASET_RECORD.json.
        from ops.load_canonical_m1 import EXPECTED_BUNDLE_BYTES, EXPECTED_BUNDLE_SHA256

        self.assertEqual(
            EXPECTED_BUNDLE_SHA256,
            "b73c989c182d240d1a68302a052805984e3ae5f00d81507e49a2a09f0ceb84f5",
        )
        self.assertEqual(EXPECTED_BUNDLE_BYTES, 68_910_640)


class UrlResolutionTest(unittest.TestCase):
    FILE_ID = "1KNxCqerh0U_ZFCDpKRmAG_SF4yndvCkU"
    DIRECT = (
        "https://drive.usercontent.google.com/download"
        f"?id={FILE_ID}&export=download&confirm=t"
    )

    def test_a_drive_share_link_becomes_a_direct_download(self):
        share = f"https://drive.google.com/file/d/{self.FILE_ID}/view?usp=drivesdk"
        self.assertEqual(resolve_source_url(share), self.DIRECT)

    def test_a_bare_file_id_becomes_a_direct_download(self):
        self.assertEqual(resolve_source_url(self.FILE_ID), self.DIRECT)

    def test_the_uc_export_form_is_rewritten_to_the_usercontent_host(self):
        # uc?export=download answers a 68 MB file with a virus-scan page.
        old = f"https://drive.google.com/uc?export=download&id={self.FILE_ID}"
        self.assertEqual(resolve_source_url(old), self.DIRECT)

    def test_a_non_drive_url_is_left_alone(self):
        url = "https://example.invalid/data/bundle.zip"
        self.assertEqual(resolve_source_url(url), url)

    def test_an_unusable_drive_url_is_refused(self):
        with self.assertRaises(SystemExit):
            resolve_source_url("https://drive.google.com/drive/my-drive")

    def test_an_empty_url_is_refused(self):
        with self.assertRaises(SystemExit):
            resolve_source_url("   ")


class DownloadTest(unittest.TestCase):
    """Exercised against a real local HTTP server, not a stubbed client."""

    def serve(self, payload: bytes, *, content_type="application/zip"):
        import http.server
        import threading

        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):  # noqa: N802
                self.send_response(200)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)

            def log_message(self, *args):
                return

        server = http.server.HTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        return f"http://127.0.0.1:{server.server_port}/bundle.zip"

    def test_it_streams_a_file_to_disk(self):
        payload = b"canonical bundle bytes" * 5_000
        url = self.serve(payload)
        with tempfile.TemporaryDirectory() as raw:
            dest = Path(raw) / "b.zip"
            download_to(url, dest, expected_bytes=len(payload))
            self.assertEqual(dest.read_bytes(), payload)

    def test_a_truncated_download_is_deleted_not_kept(self):
        payload = b"short"
        url = self.serve(payload)
        with tempfile.TemporaryDirectory() as raw:
            dest = Path(raw) / "b.zip"
            with self.assertRaises(SystemExit) as caught:
                download_to(url, dest, expected_bytes=999_999)
            self.assertIn("truncated", str(caught.exception))
            self.assertFalse(dest.exists())
            self.assertFalse(dest.with_suffix(".zip.part").exists())

    def test_an_html_page_is_recognised_as_a_sharing_problem(self):
        url = self.serve(b"<html>Sign in to continue</html>", content_type="text/html")
        with tempfile.TemporaryDirectory() as raw:
            dest = Path(raw) / "b.zip"
            with self.assertRaises(SystemExit) as caught:
                download_to(url, dest)
            self.assertIn("Anyone with the link", str(caught.exception))
            self.assertFalse(dest.exists())

    def test_a_verified_cached_copy_is_reused_instead_of_refetched(self):
        payload = b"already here"
        sha = hashlib.sha256(payload).hexdigest()
        with tempfile.TemporaryDirectory() as raw:
            cache = Path(raw) / "cached.zip"
            cache.write_bytes(payload)
            got = obtain_bundle(
                bundle=None,
                url="https://example.invalid/unreachable.zip",
                cache=cache,
                expected_sha=sha,
                expected_bytes=len(payload),
            )
            self.assertEqual(got, cache)

    def test_a_stale_cached_copy_is_not_trusted(self):
        payload = b"the real bundle"
        url = self.serve(payload)
        with tempfile.TemporaryDirectory() as raw:
            cache = Path(raw) / "cached.zip"
            cache.write_bytes(b"an older, different download")
            got = obtain_bundle(
                bundle=None,
                url=url,
                cache=cache,
                expected_sha=hashlib.sha256(payload).hexdigest(),
                expected_bytes=len(payload),
            )
            self.assertEqual(got.read_bytes(), payload)

    def test_an_explicit_bundle_path_skips_downloading_entirely(self):
        with tempfile.TemporaryDirectory() as raw:
            local = Path(raw) / "local.zip"
            local.write_bytes(b"x")
            got = obtain_bundle(
                bundle=str(local),
                url=None,
                cache=Path(raw) / "unused.zip",
                expected_sha="0" * 64,
                expected_bytes=1,
            )
            self.assertEqual(got, local.resolve())


class CandleWriterTest(unittest.TestCase):
    def test_it_unpacks_the_verified_fingerprint_not_a_reparsed_row(self):
        writer = CandleWriter(None, dry_run=True, batch_rows=100)
        ms = est_to_utc_ms("20200106 090000")
        writer(ms, struct.pack("!5d", 1550.0, 1550.5, 1549.8, 1550.2, 7.0))

        self.assertEqual(len(writer.buffer), 1)
        timeframe, candle_time, o, h, l, c, v, source = writer.buffer[0]
        self.assertEqual(timeframe, "M1")
        self.assertEqual(source, "histdata")
        self.assertEqual((o, h, l, c, v), (1550.0, 1550.5, 1549.8, 1550.2, 7.0))
        self.assertEqual(candle_time.tzinfo, timezone.utc)
        self.assertEqual(int(candle_time.timestamp() * 1000), ms)

    def test_it_flushes_on_the_batch_boundary(self):
        writer = CandleWriter(None, dry_run=True, batch_rows=3)
        packed = struct.pack("!5d", 1.0, 1.0, 1.0, 1.0, 0.0)
        for i in range(7):
            writer(1_600_000_000_000 + i * 60_000, packed)

        self.assertEqual(writer.written, 6)  # two full batches flushed
        self.assertEqual(len(writer.buffer), 1)
        writer.flush()
        self.assertEqual(writer.written, 7)
        self.assertEqual(writer.buffer, [])

    def test_flushing_an_empty_buffer_is_harmless(self):
        writer = CandleWriter(None, dry_run=True)
        writer.flush()
        self.assertEqual(writer.written, 0)


class SinkIntegrationTest(unittest.TestCase):
    """Drive the real verifier and watch what reaches the writer."""

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        tmp = Path(self._tmp.name)
        self.bundle, self.expected = build_bundle(tmp)

        self._saved = (
            canonical_history.MANIFEST_PATH,
            canonical_history.QUARANTINE_PATH,
            canonical_history.QUARANTINE_SHA_PATH,
        )
        canonical_history.MANIFEST_PATH = self.expected["manifest_path"]
        canonical_history.QUARANTINE_PATH = self.expected["quarantine_path"]
        canonical_history.QUARANTINE_SHA_PATH = self.expected["quarantine_sha_path"]

    def tearDown(self):
        (
            canonical_history.MANIFEST_PATH,
            canonical_history.QUARANTINE_PATH,
            canonical_history.QUARANTINE_SHA_PATH,
        ) = self._saved
        self._tmp.cleanup()

    def test_a_quarantined_conflict_never_reaches_the_database(self):
        # A large batch size keeps every row in the buffer, so the exact rows
        # bound for the database can be read back instead of inferred.
        writer = CandleWriter(None, dry_run=True, batch_rows=10_000)
        summary = canonical_history.scan_canonical_history(self.bundle, sink=writer)

        self.assertEqual(summary["canonical_rows"], 3)
        self.assertEqual(summary["quarantined_timestamps"], 1)
        self.assertEqual(writer.seen, 3)

        queued_ms = sorted(int(row[1].timestamp() * 1000) for row in writer.buffer)
        self.assertNotIn(self.expected["conflict_ms"], queued_ms)
        self.assertEqual(
            queued_ms,
            sorted([self.expected["a_ms"], self.expected["b_ms"], self.expected["d_ms"]]),
        )

        # The bad close from the conflicting pair must be nowhere in the batch.
        self.assertNotIn(9999.99, [row[5] for row in writer.buffer])

    def test_an_identical_duplicate_is_written_once(self):
        collected: list[int] = []
        canonical_history.scan_canonical_history(
            self.bundle, sink=lambda ms, packed: collected.append(ms)
        )
        self.assertEqual(collected.count(self.expected["b_ms"]), 1)

    def test_rows_arrive_in_timestamp_order(self):
        collected: list[int] = []
        canonical_history.scan_canonical_history(
            self.bundle, sink=lambda ms, packed: collected.append(ms)
        )
        self.assertEqual(collected, sorted(collected))

    def test_a_tampered_inner_archive_stops_the_load(self):
        # Rewrite the outer archive with different inner bytes so the recorded
        # per-file SHA256 no longer matches.
        tampered = Path(self._tmp.name) / "tampered.zip"
        inner_buf = io.BytesIO()
        with zipfile.ZipFile(inner_buf, "w", zipfile.ZIP_DEFLATED) as inner:
            inner.writestr(CSV_NAME, "20200106 090000;1.0;1.0;1.0;1.0;0\r\n")
        with zipfile.ZipFile(tampered, "w", zipfile.ZIP_DEFLATED) as outer:
            outer.writestr(INNER_NAME, inner_buf.getvalue())

        writer = CandleWriter(None, dry_run=True)
        with self.assertRaises(RuntimeError) as caught:
            canonical_history.scan_canonical_history(tampered, sink=writer)
        self.assertIn("SHA mismatch", str(caught.exception))

    def test_verification_still_passes_without_a_sink(self):
        summary = canonical_history.scan_canonical_history(self.bundle)
        self.assertEqual(summary["raw_rows"], 6)
        self.assertEqual(summary["canonical_rows"], 3)
        self.assertEqual(summary["identical_duplicates_removed"], 1)


if __name__ == "__main__":
    unittest.main()
